
//--TRIMMABLE-BOUNDARY-START(45171)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc) {
    "use strict";
    let _;
    let _b3b50399_9d76_417e_985c_a195018a83ac;
    let _3eb80b94_b55d_4cdf_b676_3ed9fc279674;
    let _7fbabd69_9806_4e90_b870_dd093faabadd;
    let _8358bb93_bb12_40f0_98a3_e92b83a690d1;
    let _ab9d8651_e336_4fda_ba99_9040c2c58b9f;
    let _b75cd2ef_bdaf_4858_93e4_0608b2aa2a16;
    let _fffcbf50_92c6_44d2_ad8b_54d16e3c9ace;
    let _4e99497c_bc43_4eb5_b6ab_e8a80cff232a;
    let _8100b783_df50_4cbc_bd2b_fa67425a2e9d;
    let _5779fa67_2447_4b53_8278_3e8d37eb169c;
    let _40379018_07b8_4128_8240_95e33b2d2dbe;
    let _3d723f97_1418_4b17_af52_f889b6f84063;
    let _600cb916_c407_420b_afaa_7467aaabab50;
    let _3e7954bb_9efc_4322_b134_25dd7b064dd2;
    let _1b970076_2302_41ca_bf55_1f10d3d4a281;
    let _cc3ba6cc_9f30_4412_b21f_53a82cddff61;
    let _a5a475b3_6b80_45f1_8168_d573de117f46;
    let _ecf043b5_49da_4105_b48b_e45271dcad70;
    let _66a72f3d_f32a_4271_b71a_212c31357d77;
    let _48a93d7f_cd33_47eb_a9f0_d483544a5e68;
    let _36764e52_3fb3_49ae_b8b3_cb62b1368d7b;
    let _101927e5_255c_42f4_9203_d99fad3e6dd0;
    let _bd96a7a5_5aaf_46f7_8e15_16b8e14c65f2;
    let _689ef095_240f_4ca8_a1d3_d348f921015e;
    let _9580cd63_4e0a_4879_957a_798b817c1962;
    let _e521c6d4_39ea_4909_93df_bdd6114bed38;
    let _a337dae8_63fd_40c6_b846_ba15f6bcc4ee;
    let _6f0ecabf_f578_490b_90b6_6dc2c11c0af0;
    let _1d6e94bd_6aed_4b6c_bca0_287ac68f3bd7;
    let _3d592cf7_62fb_4d4e_8ab3_739b9a6b06b1;
    let _cc17cd60_1da3_4e80_b2d3_a1ad8494e5a3;
    let _abd454da_4fe2_45a7_a407_cbfef83faf87;
    let _d958bcbf_c1bc_4df1_93d7_7b50c6cec2c6;
    let _29e1823d_5449_4711_9d80_5e38931f806b;
    let _5b4cca77_25b2_4c60_96fa_ab7e388e7b29;
    let _8d14a3da_b0a3_4a4a_9940_13cb734d7748;
    let _f6eb3afb_1d66_4c1c_8854_793a51c3551f;
    let _62660f65_64d4_49de_90b5_df295dd466de;
    let _7c5d505a_6969_4759_ab9e_21dcea1ed9b3;
    
    
    
	$.$asm(
    "NetJs.DynamicExpresso.Core", 
    {
  "h": 45171,
  "f": "DynamicExpresso.Core",
  "v": "0.0.1.0",
  "a": [
    {
      "t": 159514625,
      "c": 13044416513,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106692609,
      "c": 8696627201,
      "a": [
        {
          "v": "DynamicExpresso",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 8696692737,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Davide Icardi",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "C# expression interpreter/evaluator",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "0.0.1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "0.0.1\u002Bad167c0f396127de6df1f0b555d2916992345713",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "DynamicExpresso.Core",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108331009,
      "c": 8698265601,
      "a": [
        {
          "v": "DynamicExpresso.Core",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108462081,
      "c": 8698396673,
      "a": [
        {
          "v": "0.0.1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107544577,
      "c": 12992446465,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/dynamicexpresso/DynamicExpresso.git",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2732147)
        $asm.$cls(`$HnZw.DR$1.IConvertibleToWritableBinder`, ($self) => class IConvertibleToWritableBinder
        {
            static $h = 2732147;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297699443),
    {
      "r": 42860581,
      "n": "ToWritableBinder",
      "o": "DR$1$IConvertibleToWritableBinder$ToWritableBinder",
      "d": 2732147,
      "h": 4297699443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297699443)
  ],
  "h": 2732147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.IConvertibleToWritableBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}IConvertibleToWritableBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2732147)
        
        

        //--TRIMMABLE-BOUNDARY-START(1749107)
        $asm.$cls(`$HnZw.DP.ParserConstants`, ($self) => class ParserConstants
        {
            //--TRIMMABLE-BOUNDARY-START(30066520179)
            /*Expression*/ static NullLiteralExpression = null;
            //--TRIMMABLE-BOUNDARY-END(30066520179)
            
            //--TRIMMABLE-BOUNDARY-START(8591683699)
            /*string*/ static KeywordAs = null;
            //--TRIMMABLE-BOUNDARY-END(8591683699)
            
            //--TRIMMABLE-BOUNDARY-START(17181618291)
            /*string*/ static KeywordIs = null;
            //--TRIMMABLE-BOUNDARY-END(17181618291)
            
            //--TRIMMABLE-BOUNDARY-START(21476585587)
            /*string*/ static KeywordNew = null;
            //--TRIMMABLE-BOUNDARY-END(21476585587)
            
            //--TRIMMABLE-BOUNDARY-START(25771552883)
            /*string*/ static KeywordTypeof = null;
            //--TRIMMABLE-BOUNDARY-END(25771552883)
            
            //--TRIMMABLE-BOUNDARY-START(12886650995)
            /*string*/ static KeywordDefault = null;
            //--TRIMMABLE-BOUNDARY-END(12886650995)
            
            //--TRIMMABLE-BOUNDARY-START(34361487475)
            /*string[]*/ static ReservedKeywords = null;
            //--TRIMMABLE-BOUNDARY-END(34361487475)
            
            //--TRIMMABLE-BOUNDARY-START(4296716403)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296716403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066520179)
                    this.NullLiteralExpression = $.$sle.SLE.Expression.Constant$1(null);
                    //--TRIMMABLE-BOUNDARY-END(30066520179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591683699)
                    this.KeywordAs = "as";
                    //--TRIMMABLE-BOUNDARY-END(8591683699)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181618291)
                    this.KeywordIs = "is";
                    //--TRIMMABLE-BOUNDARY-END(17181618291)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476585587)
                    this.KeywordNew = "new";
                    //--TRIMMABLE-BOUNDARY-END(21476585587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771552883)
                    this.KeywordTypeof = "typeof";
                    //--TRIMMABLE-BOUNDARY-END(25771552883)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886650995)
                    this.KeywordDefault = "default";
                    //--TRIMMABLE-BOUNDARY-END(12886650995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361487475)
                    this.ReservedKeywords = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["as"/*KeywordAs*/, "is"/*KeywordIs*/, "new"/*KeywordNew*/, "typeof"/*KeywordTypeof*/, "default"/*KeywordDefault*/], null, null);
                    //--TRIMMABLE-BOUNDARY-END(34361487475)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296716403)
            
            static $h = 1749107;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066520179),
    {
      "t": 8781861,
      "n": "NullLiteralExpression",
      "d": 1749107,
      "h": 30066520179,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066520179),
//--TRIMMABLE-BOUNDARY-START(8591683699),
    {
      "t": 1310721,
      "n": "KeywordAs",
      "d": 1749107,
      "h": 8591683699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591683699),
//--TRIMMABLE-BOUNDARY-START(17181618291),
    {
      "t": 1310721,
      "n": "KeywordIs",
      "d": 1749107,
      "h": 17181618291,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181618291),
//--TRIMMABLE-BOUNDARY-START(21476585587),
    {
      "t": 1310721,
      "n": "KeywordNew",
      "d": 1749107,
      "h": 21476585587,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476585587),
//--TRIMMABLE-BOUNDARY-START(25771552883),
    {
      "t": 1310721,
      "n": "KeywordTypeof",
      "d": 1749107,
      "h": 25771552883,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771552883),
//--TRIMMABLE-BOUNDARY-START(12886650995),
    {
      "t": 1310721,
      "n": "KeywordDefault",
      "d": 1749107,
      "h": 12886650995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886650995),
//--TRIMMABLE-BOUNDARY-START(34361487475),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "ReservedKeywords",
      "d": 1749107,
      "h": 34361487475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361487475)
  ],
  "h": 1749107
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.ParserConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}ParserConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1749107)
        
        

        //--TRIMMABLE-BOUNDARY-START(962675)
        $asm.$cls(`$HnZw.D.IdentifiersInfo`, ($self) => class IdentifiersInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180831859)
            $ctor$1(/*IEnumerable<string>*/ unknownIdentifiers, /*IEnumerable<Identifier>*/ identifiers, /*IEnumerable<ReferenceType>*/ types)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180831859);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UnknownIdentifiers = $.$sl.SL.Enumerable.ToList($.$$.S.String, unknownIdentifiers);
                    this.Identifiers = $.$sl.SL.Enumerable.ToList($.$HnZw.D.Identifier, identifiers);
                    this.Types = $.$sl.SL.Enumerable.ToList($.$HnZw.D.ReferenceType, types);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180831859)
            
            //--TRIMMABLE-BOUNDARY-START(81605341299)
            /*IEnumerable<string>*/ UnknownIdentifiers = null;
            //--TRIMMABLE-BOUNDARY-END(81605341299)
            
            //--TRIMMABLE-BOUNDARY-START(47245602931)
            /*IEnumerable<Identifier>*/ Identifiers = null;
            //--TRIMMABLE-BOUNDARY-END(47245602931)
            
            //--TRIMMABLE-BOUNDARY-START(77310374003)
            /*IEnumerable<ReferenceType>*/ Types = null;
            //--TRIMMABLE-BOUNDARY-END(77310374003)
            
            static $h = 962675;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605341299),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950635635,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015406707,
        "f": 83886082
      },
      "n": "UnknownIdentifiers",
      "d": 962675,
      "h": 81605341299,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605341299),
//--TRIMMABLE-BOUNDARY-START(47245602931),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770766451,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835537523,
        "f": 83886082
      },
      "n": "Identifiers",
      "d": 962675,
      "h": 47245602931,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245602931),
//--TRIMMABLE-BOUNDARY-START(77310374003),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360701043,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425472115,
        "f": 83886082
      },
      "n": "Types",
      "d": 962675,
      "h": 77310374003,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310374003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180831859),
    {
      "p": [
        {
          "n": "unknownIdentifiers",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "identifiers",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h
        },
        {
          "n": "types",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 962675,
      "h": 17180831859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180831859)
  ],
  "h": 962675
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.IdentifiersInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}IdentifiersInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(962675)
        
        

        //--TRIMMABLE-BOUNDARY-START(2273395)
        $asm.$cls(`$HnZw.DR.MethodData`, ($self) => class MethodData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182142579)
            /*MethodBase*/ MethodBase = null;
            //--TRIMMABLE-BOUNDARY-END(17182142579)
            
            //--TRIMMABLE-BOUNDARY-START(21477109875)
            /*IList<ParameterInfo>*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(21477109875)
            
            //--TRIMMABLE-BOUNDARY-START(25772077171)
            /*IList<Expression>*/ PromotedParameters = null;
            //--TRIMMABLE-BOUNDARY-END(25772077171)
            
            //--TRIMMABLE-BOUNDARY-START(12887175283)
            /*bool*/ HasParamsArray = false;
            //--TRIMMABLE-BOUNDARY-END(12887175283)
            
            //--TRIMMABLE-BOUNDARY-START(8592207987)
            static /*MethodData */ Gen(/*MethodBase*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592207987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$HnZw.DR.MethodData()
                    const $t1 = $.$HnZw.DR.MethodData;
                    const $i1 = new $t1();
                    $i1.MethodBase = method;
                    $i1.Parameters = method.GetParameters();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8592207987)
            
            //--TRIMMABLE-BOUNDARY-START(30067044467)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067044467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$dsp(this.MethodBase, $.$$.S.Object, ($t) => $t.ToString);
            }
            //--TRIMMABLE-BOUNDARY-END(30067044467)
            
            //--TRIMMABLE-BOUNDARY-START(4297240691)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297240691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297240691)
            
            //--TRIMMABLE-BOUNDARY-START(4297240691)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297240691)
            
            static $h = 2273395;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592207987),
    {
      "r": 2273395,
      "p": [
        {
          "n": "method",
          "p": 116457473
        }
      ],
      "n": "Gen",
      "d": 2273395,
      "h": 8592207987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592207987),
//--TRIMMABLE-BOUNDARY-START(30067044467),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2273395,
      "h": 30067044467,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067044467)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182142579),
    {
      "t": 116457473,
      "n": "MethodBase",
      "d": 2273395,
      "h": 17182142579,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17182142579),
//--TRIMMABLE-BOUNDARY-START(21477109875),
    {
      "t": $.$$.SCG.IList$$($.$$.SR.ParameterInfo).$h,
      "n": "Parameters",
      "d": 2273395,
      "h": 21477109875,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21477109875),
//--TRIMMABLE-BOUNDARY-START(25772077171),
    {
      "t": $.$$.SCG.IList$$($.$sle.SLE.Expression).$h,
      "n": "PromotedParameters",
      "d": 2273395,
      "h": 25772077171,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25772077171),
//--TRIMMABLE-BOUNDARY-START(12887175283),
    {
      "t": 262145,
      "n": "HasParamsArray",
      "d": 2273395,
      "h": 12887175283,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12887175283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297240691),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2273395,
      "h": 4297240691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297240691)
  ],
  "h": 2273395
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.MethodData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}MethodData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2273395)
        
        

        //--TRIMMABLE-BOUNDARY-START(2666611)
        $asm.$cls(`$HnZw.DR$1.ExpressionUtils`, ($self) => class ExpressionUtils
        {
            //--TRIMMABLE-BOUNDARY-START(4297633907)
            static /*Expression */ PromoteExpression(/*Expression*/ expr, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297633907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(expr.Type, type))
                {
                    return expr;
                }
                let ce;
                if ($.$is(expr, $.$sle.SLE.ConstantExpression, { set $v(v){ ce = v; } }) && ce === $.$HnZw.DP.ParserConstants.NullLiteralExpression)
                {
                    if (type.ContainsGenericParameters$1)
                    {
                        return null;
                    }
                    if (!type.IsValueType || $.$HnZw.DR.TypeUtils.IsNullableType(type))
                    {
                        return $.$sle.SLE.Expression.Constant(null, type);
                    }
                }
                let ie;
                if ($.$is(expr, $.$HnZw.DP.InterpreterExpression, { set $v(v){ ie = v; } }))
                {
                    if (!ie.IsCompatibleWithDelegate(type))
                    {
                        return null;
                    }
                    if (!type.ContainsGenericParameters$1)
                    {
                        return ie.EvalAs(type);
                    }
                    return expr;
                }
                if (type.IsAssignableFrom(expr.Type))
                {
                    return $.$sle.SLE.Expression.Convert$1(expr, type);
                }
                if (type.IsGenericType && !$.$HnZw.DR.TypeUtils.IsNumericType(type))
                {
                    /*var*/ let genericType = $.$HnZw.DR.TypeUtils.FindAssignableGenericType(expr.Type, type);
                    if ($.$$.S.Type.op_Inequality$1(genericType, null))
                    {
                        return $.$sle.SLE.Expression.Convert$1(expr, genericType);
                    }
                }
                if ($.$HnZw.DR.TypeUtils.IsCompatibleWith(expr.Type, type))
                {
                    return $.$sle.SLE.Expression.Convert$1(expr, type);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4297633907)
            
            static $h = 2666611;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297633907),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "PromoteExpression",
      "d": 2666611,
      "h": 4297633907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297633907)
  ],
  "h": 2666611
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.ExpressionUtils`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}ExpressionUtils`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2666611)
        
        

        //--TRIMMABLE-BOUNDARY-START(1421427)
        $asm.$cls(`$HnZw.D.Parameter`, ($self) => class Parameter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771225203)
            $ctor$2(/*string*/ name, /*object*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771225203);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (value === null)
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("value");
                    }
                    this.Name = name;
                    this.Type = $.$$.S.Object.GetType.call(value);
                    this.Value = value;
                    this.Expression = $.$sle.SLE.Expression.Parameter(this.Type, name);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771225203)
            
            //--TRIMMABLE-BOUNDARY-START(21476257907)
            $ctor$1(/*ParameterExpression*/ parameterExpression)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476257907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = parameterExpression.Name;
                    this.Type = parameterExpression.Type;
                    this.Value = null;
                    this.Expression = parameterExpression;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476257907)
            
            //--TRIMMABLE-BOUNDARY-START(30066192499)
            $ctor$3(/*string*/ name, /*Type*/ type, /*object*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066192499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Type = type;
                    this.Value = value;
                    this.Expression = $.$sle.SLE.Expression.Parameter(type, name);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066192499)
            
            //--TRIMMABLE-BOUNDARY-START(34361159795)
            static /*Parameter */ Create(T, /*string*/ name, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361159795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.D.Parameter().$ctor$3(name, T.$type, $.$box(value, T));
            }
            //--TRIMMABLE-BOUNDARY-END(34361159795)
            
            //--TRIMMABLE-BOUNDARY-START(77310832755)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(77310832755)
            
            //--TRIMMABLE-BOUNDARY-START(115965538419)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(115965538419)
            
            //--TRIMMABLE-BOUNDARY-START(120260505715)
            /*object*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(120260505715)
            
            //--TRIMMABLE-BOUNDARY-START(38656127091)
            /*ParameterExpression*/ Expression = null;
            //--TRIMMABLE-BOUNDARY-END(38656127091)
            
            static $h = 1421427;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310832755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835996275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490701939,
        "f": 83886082
      },
      "n": "Name",
      "d": 1421427,
      "h": 77310832755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310832755),
//--TRIMMABLE-BOUNDARY-START(115965538419),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425930867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080636531,
        "f": 83886082
      },
      "n": "Type",
      "d": 1421427,
      "h": 115965538419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965538419),
//--TRIMMABLE-BOUNDARY-START(120260505715),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015865459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670571123,
        "f": 83886082
      },
      "n": "Value",
      "d": 1421427,
      "h": 120260505715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260505715),
//--TRIMMABLE-BOUNDARY-START(38656127091),
    {
      "p": 40566821,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246061683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900767347,
        "f": 83886082
      },
      "n": "Expression",
      "d": 1421427,
      "h": 38656127091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656127091)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361159795),
    {
      "r": 1421427,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Create",
      "d": 1421427,
      "h": 34361159795,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361159795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771225203),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1421427,
      "h": 25771225203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771225203),
//--TRIMMABLE-BOUNDARY-START(21476257907),
    {
      "p": [
        {
          "n": "parameterExpression",
          "p": 40566821
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1421427,
      "h": 21476257907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476257907),
//--TRIMMABLE-BOUNDARY-START(30066192499),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "value",
          "p": 131073,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1421427,
      "h": 30066192499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066192499)
  ],
  "h": 1421427
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parameter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parameter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1421427)
        
        

        //--TRIMMABLE-BOUNDARY-START(2076787)
        $asm.$cls(`$HnZw.D.ReferenceType`, ($self) => class ReferenceType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85901422707)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(85901422707)
            
            //--TRIMMABLE-BOUNDARY-START(55836651635)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55836651635)
            
            //--TRIMMABLE-BOUNDARY-START(25771880563)
            /*IList<MethodInfo>*/ ExtensionMethods = null;
            //--TRIMMABLE-BOUNDARY-END(25771880563)
            
            //--TRIMMABLE-BOUNDARY-START(17181945971)
            $ctor$1(/*string*/ name, /*Type*/ type)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181945971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrWhiteSpace(name))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                    }
                    if ($.$$.S.Type.op_Equality$1(type, null))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("type");
                    }
                    if (type.IsGenericType && !type.IsGenericTypeDefinition)
                    {
                        /*var*/ let genericType = type.GetGenericTypeDefinition();
                        /*var*/ let genericTypeName = $.$$.S.String.Substring.call(genericType.Name, 0, $.$$.S.String.IndexOf$3.call(genericType.Name, /*`*/ 96));
                        genericTypeName += `<${$.$$.S.String.Create(/*,*/ 44, ((genericType.GetGenericArguments().length - 1) | 0))}>`;
                        throw new $.$$.S.ArgumentException().$ctor$14($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.GenericTypeReference, genericTypeName));
                    }
                    this.Type = type;
                    this.Name = name;
                    this.ExtensionMethods = $.$sl.SL.Enumerable.ToList($.$$.SR.MethodInfo, $.$HnZw.DR.ReflectionExtensions.GetExtensionMethods(type));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181945971)
            
            //--TRIMMABLE-BOUNDARY-START(21476913267)
            $ctor$2(/*Type*/ type)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476913267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.Type.op_Equality$1(type, null))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("type");
                    }
                    this.Type = type;
                    this.Name = type.Name;
                    this.ExtensionMethods = $.$sl.SL.Enumerable.ToList($.$$.SR.MethodInfo, $.$HnZw.DR.ReflectionExtensions.GetExtensionMethods(type));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476913267)
            
            static $h = 2076787;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85901422707),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541684339,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606455411,
        "f": 83886082
      },
      "n": "Type",
      "d": 2076787,
      "h": 85901422707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901422707),
//--TRIMMABLE-BOUNDARY-START(55836651635),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951749747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016520819,
        "f": 83886082
      },
      "n": "Name",
      "d": 2076787,
      "h": 55836651635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836651635),
//--TRIMMABLE-BOUNDARY-START(25771880563),
    {
      "p": $.$$.SCG.IList$$($.$$.SR.MethodInfo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361815155,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426586227,
        "f": 83886082
      },
      "n": "ExtensionMethods",
      "d": 2076787,
      "h": 25771880563,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771880563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181945971),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2076787,
      "h": 17181945971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181945971),
//--TRIMMABLE-BOUNDARY-START(21476913267),
    {
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2076787,
      "h": 21476913267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476913267)
  ],
  "h": 2076787
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.ReferenceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}ReferenceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2076787)
        
        

        //--TRIMMABLE-BOUNDARY-START(1224819)
        $asm.$cls(`$HnZw.D.LanguageConstants`, ($self) => class LanguageConstants
        {
            //--TRIMMABLE-BOUNDARY-START(34360963187)
            /*string*/ static This = null;
            //--TRIMMABLE-BOUNDARY-END(34360963187)
            
            //--TRIMMABLE-BOUNDARY-START(21476061299)
            /*ReferenceType[]*/ static PrimitiveTypes = null;
            //--TRIMMABLE-BOUNDARY-END(21476061299)
            
            //--TRIMMABLE-BOUNDARY-START(12886126707)
            /*ReferenceType[]*/ static CSharpPrimitiveTypes = null;
            //--TRIMMABLE-BOUNDARY-END(12886126707)
            
            //--TRIMMABLE-BOUNDARY-START(8591159411)
            /*ReferenceType[]*/ static CommonTypes = null;
            //--TRIMMABLE-BOUNDARY-END(8591159411)
            
            //--TRIMMABLE-BOUNDARY-START(17181094003)
            /*Identifier[]*/ static Literals = null;
            //--TRIMMABLE-BOUNDARY-END(17181094003)
            
            //--TRIMMABLE-BOUNDARY-START(30065995891)
            /*string[]*/ static ReserverKeywords = null;
            //--TRIMMABLE-BOUNDARY-END(30065995891)
            
            //--TRIMMABLE-BOUNDARY-START(25771028595)
            /*string[]*/ static ReservedKeywords = null;
            //--TRIMMABLE-BOUNDARY-END(25771028595)
            
            //--TRIMMABLE-BOUNDARY-START(4296192115)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296192115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34360963187)
                    this.This = "this";
                    //--TRIMMABLE-BOUNDARY-END(34360963187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476061299)
                    this.PrimitiveTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.ReferenceType), [new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Object.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Boolean.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Char.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.String.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.SByte.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Byte.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Int16.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.UInt16.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Int32.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.UInt32.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Int64.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.UInt64.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Single.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Double.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Decimal.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.DateTime.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.TimeSpan.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Guid.$type)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(21476061299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886126707)
                    this.CSharpPrimitiveTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.ReferenceType), [new $.$HnZw.D.ReferenceType().$ctor$1("object", $.$$.S.Object.$type), new $.$HnZw.D.ReferenceType().$ctor$1("string", $.$$.S.String.$type), new $.$HnZw.D.ReferenceType().$ctor$1("char", $.$$.S.Char.$type), new $.$HnZw.D.ReferenceType().$ctor$1("bool", $.$$.S.Boolean.$type), new $.$HnZw.D.ReferenceType().$ctor$1("sbyte", $.$$.S.SByte.$type), new $.$HnZw.D.ReferenceType().$ctor$1("byte", $.$$.S.Byte.$type), new $.$HnZw.D.ReferenceType().$ctor$1("short", $.$$.S.Int16.$type), new $.$HnZw.D.ReferenceType().$ctor$1("ushort", $.$$.S.UInt16.$type), new $.$HnZw.D.ReferenceType().$ctor$1("int", $.$$.S.Int32.$type), new $.$HnZw.D.ReferenceType().$ctor$1("uint", $.$$.S.UInt32.$type), new $.$HnZw.D.ReferenceType().$ctor$1("long", $.$$.S.Int64.$type), new $.$HnZw.D.ReferenceType().$ctor$1("ulong", $.$$.S.UInt64.$type), new $.$HnZw.D.ReferenceType().$ctor$1("float", $.$$.S.Single.$type), new $.$HnZw.D.ReferenceType().$ctor$1("double", $.$$.S.Double.$type), new $.$HnZw.D.ReferenceType().$ctor$1("decimal", $.$$.S.Decimal.$type)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12886126707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591159411)
                    this.CommonTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.ReferenceType), [new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Math.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$$.S.Convert.$type), new $.$HnZw.D.ReferenceType().$ctor$2($.$sl.SL.Enumerable.$type)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(8591159411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181094003)
                    this.Literals = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.Identifier), [new $.$HnZw.D.Identifier().$ctor$1("true", $.$sle.SLE.Expression.Constant$1($.$box(true, $.$$.S.Boolean))), new $.$HnZw.D.Identifier().$ctor$1("false", $.$sle.SLE.Expression.Constant$1($.$box(false, $.$$.S.Boolean))), new $.$HnZw.D.Identifier().$ctor$1("null", $.$HnZw.DP.ParserConstants.NullLiteralExpression)], null, null);
                    //--TRIMMABLE-BOUNDARY-END(17181094003)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065995891)
                    this.ReserverKeywords = $.$HnZw.DP.ParserConstants.ReservedKeywords;
                    //--TRIMMABLE-BOUNDARY-END(30065995891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771028595)
                    this.ReservedKeywords = $.$HnZw.DP.ParserConstants.ReservedKeywords;
                    //--TRIMMABLE-BOUNDARY-END(25771028595)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296192115)
            
            static $h = 1224819;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360963187),
    {
      "t": 1310721,
      "n": "This",
      "d": 1224819,
      "h": 34360963187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360963187),
//--TRIMMABLE-BOUNDARY-START(21476061299),
    {
      "t": $.$typeArray($.$HnZw.D.ReferenceType).$h,
      "n": "PrimitiveTypes",
      "d": 1224819,
      "h": 21476061299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476061299),
//--TRIMMABLE-BOUNDARY-START(12886126707),
    {
      "t": $.$typeArray($.$HnZw.D.ReferenceType).$h,
      "n": "CSharpPrimitiveTypes",
      "d": 1224819,
      "h": 12886126707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886126707),
//--TRIMMABLE-BOUNDARY-START(8591159411),
    {
      "t": $.$typeArray($.$HnZw.D.ReferenceType).$h,
      "n": "CommonTypes",
      "d": 1224819,
      "h": 8591159411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591159411),
//--TRIMMABLE-BOUNDARY-START(17181094003),
    {
      "t": $.$typeArray($.$HnZw.D.Identifier).$h,
      "n": "Literals",
      "d": 1224819,
      "h": 17181094003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181094003),
//--TRIMMABLE-BOUNDARY-START(30065995891),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "ReserverKeywords",
      "d": 1224819,
      "h": 30065995891,
      "f": 4194337,
      "a": [
        {
          "t": 104005633,
          "c": 30168776705,
          "a": [
            {
              "v": "Use ReservedKeywords",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065995891),
//--TRIMMABLE-BOUNDARY-START(25771028595),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "ReservedKeywords",
      "d": 1224819,
      "h": 25771028595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771028595)
  ],
  "h": 1224819
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.LanguageConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}LanguageConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1224819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1814643)
        $asm.$cls(`$HnZw.DP.ParserSettings`, ($self) => class ParserSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591749235)
            /*Dictionary<string, Identifier>*/ _identifiers = null;
            //--TRIMMABLE-BOUNDARY-END(8591749235)
            
            //--TRIMMABLE-BOUNDARY-START(12886716531)
            /*Dictionary<string, ReferenceType>*/ _knownTypes = null;
            //--TRIMMABLE-BOUNDARY-END(12886716531)
            
            //--TRIMMABLE-BOUNDARY-START(4296781939)
            /*HashSet<MethodInfo>*/ _extensionMethods = null;
            //--TRIMMABLE-BOUNDARY-END(4296781939)
            
            //--TRIMMABLE-BOUNDARY-START(17181683827)
            /*HashSet<ExpressionVisitor>*/ _visitors = null;
            //--TRIMMABLE-BOUNDARY-END(17181683827)
            
            //--TRIMMABLE-BOUNDARY-START(51541422195)
            $ctor$1(/*bool*/ caseInsensitive, /*bool*/ lateBindObject)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541422195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CaseInsensitive = caseInsensitive;
                    this.LateBindObject = lateBindObject;
                    this.KeyComparer = this.CaseInsensitive ? $.$$.S.StringComparer.InvariantCultureIgnoreCase : $.$$.S.StringComparer.InvariantCulture;
                    this.KeyComparison = this.CaseInsensitive ? 3/*StringComparison.InvariantCultureIgnoreCase*/ : 2/*StringComparison.InvariantCulture*/;
                    this._identifiers = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Identifier))().$ctor$6(this.KeyComparer);
                    this._knownTypes = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.ReferenceType))().$ctor$6(this.KeyComparer);
                    this._extensionMethods = new ($.$$.SCG.HashSet$$($.$$.SR.MethodInfo))().$ctor$1();
                    this._visitors = new ($.$$.SCG.HashSet$$($.$sle.SLE.ExpressionVisitor))().$ctor$1();
                    this.AssignmentOperators = 1/*AssignmentOperators.All*/;
                    this.DefaultNumberType = 0/*DefaultNumberType.Default*/;
                    this.LambdaExpressions = false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541422195)
            
            //--TRIMMABLE-BOUNDARY-START(55836389491)
            $ctor$2(/*ParserSettings*/ other)
            {
                this.$ctor$1(other.CaseInsensitive, other.LateBindObject);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836389491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._knownTypes = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.ReferenceType))().$ctor$2(other._knownTypes, other._knownTypes.Comparer);
                    this._identifiers = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Identifier))().$ctor$2(other._identifiers, other._identifiers.Comparer);
                    this._extensionMethods = new ($.$$.SCG.HashSet$$($.$$.SR.MethodInfo))().$ctor$3(other._extensionMethods);
                    this._visitors = new ($.$$.SCG.HashSet$$($.$sle.SLE.ExpressionVisitor))().$ctor$3(other._visitors);
                    this.AssignmentOperators = other.AssignmentOperators;
                    this.DefaultNumberType = other.DefaultNumberType;
                    this.LambdaExpressions = other.LambdaExpressions;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836389491)
            
            //--TRIMMABLE-BOUNDARY-START(68721291379)
            /*ParserSettings */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721291379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DP.ParserSettings().$ctor$2(this);
            }
            //--TRIMMABLE-BOUNDARY-END(68721291379)
            
            //--TRIMMABLE-BOUNDARY-START(188980375667)
            /*IDictionary<string, ReferenceType> */ get KnownTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030702707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._knownTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(188980375667)
            
            //--TRIMMABLE-BOUNDARY-START(176095473779)
            /*IDictionary<string, Identifier> */ get Identifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260898931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._identifiers;
            }
            //--TRIMMABLE-BOUNDARY-END(176095473779)
            
            //--TRIMMABLE-BOUNDARY-START(77311225971)
            /*HashSet<MethodInfo> */ get ExtensionMethods()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670964339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._extensionMethods;
            }
            //--TRIMMABLE-BOUNDARY-END(77311225971)
            
            //--TRIMMABLE-BOUNDARY-START(227635081331)
            /*ISet<ExpressionVisitor> */ get Visitors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800506483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._visitors;
            }
            //--TRIMMABLE-BOUNDARY-END(227635081331)
            
            //--TRIMMABLE-BOUNDARY-START(64426324083)
            /*bool*/ CaseInsensitive = false;
            //--TRIMMABLE-BOUNDARY-END(64426324083)
            
            //--TRIMMABLE-BOUNDARY-START(197570310259)
            /*bool*/ LateBindObject = false;
            //--TRIMMABLE-BOUNDARY-END(197570310259)
            
            //--TRIMMABLE-BOUNDARY-START(184685408371)
            /*StringComparison*/ KeyComparison = 0;
            //--TRIMMABLE-BOUNDARY-END(184685408371)
            
            //--TRIMMABLE-BOUNDARY-START(180390441075)
            /*IEqualityComparer<string>*/ KeyComparer = null;
            //--TRIMMABLE-BOUNDARY-END(180390441075)
            
            //--TRIMMABLE-BOUNDARY-START(73016258675)
            /*DefaultNumberType*/ DefaultNumberType = 0;
            //--TRIMMABLE-BOUNDARY-END(73016258675)
            
            //--TRIMMABLE-BOUNDARY-START(60131356787)
            /*AssignmentOperators*/ AssignmentOperators = 0;
            //--TRIMMABLE-BOUNDARY-END(60131356787)
            
            //--TRIMMABLE-BOUNDARY-START(193275342963)
            /*bool*/ LambdaExpressions = false;
            //--TRIMMABLE-BOUNDARY-END(193275342963)
            
            static $h = 1814643;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(188980375667),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$HnZw.D.ReferenceType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030702707,
        "f": 50331649
      },
      "n": "KnownTypes",
      "d": 1814643,
      "h": 188980375667,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980375667),
//--TRIMMABLE-BOUNDARY-START(176095473779),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$HnZw.D.Identifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260898931,
        "f": 50331649
      },
      "n": "Identifiers",
      "d": 1814643,
      "h": 176095473779,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095473779),
//--TRIMMABLE-BOUNDARY-START(77311225971),
    {
      "p": $.$$.SCG.HashSet$$($.$$.SR.MethodInfo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670964339,
        "f": 50331649
      },
      "n": "ExtensionMethods",
      "d": 1814643,
      "h": 77311225971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311225971),
//--TRIMMABLE-BOUNDARY-START(227635081331),
    {
      "p": $.$$.SCG.ISet$$($.$sle.SLE.ExpressionVisitor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800506483,
        "f": 50331649
      },
      "n": "Visitors",
      "d": 1814643,
      "h": 227635081331,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227635081331),
//--TRIMMABLE-BOUNDARY-START(64426324083),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491095155,
        "f": 50331649
      },
      "n": "CaseInsensitive",
      "d": 1814643,
      "h": 64426324083,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426324083),
//--TRIMMABLE-BOUNDARY-START(197570310259),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210571891,
        "f": 50331649
      },
      "n": "LateBindObject",
      "d": 1814643,
      "h": 197570310259,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570310259),
//--TRIMMABLE-BOUNDARY-START(184685408371),
    {
      "p": 163840001,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440768115,
        "f": 50331649
      },
      "n": "KeyComparison",
      "d": 1814643,
      "h": 184685408371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685408371),
//--TRIMMABLE-BOUNDARY-START(180390441075),
    {
      "p": $.$$.SCG.IEqualityComparer$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850833523,
        "f": 50331649
      },
      "n": "KeyComparer",
      "d": 1814643,
      "h": 180390441075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390441075),
//--TRIMMABLE-BOUNDARY-START(73016258675),
    {
      "p": 176243,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081029747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750179443,
        "f": 83886081
      },
      "n": "DefaultNumberType",
      "d": 1814643,
      "h": 73016258675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016258675),
//--TRIMMABLE-BOUNDARY-START(60131356787),
    {
      "p": 110707,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901160563,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160244851,
        "f": 83886081
      },
      "n": "AssignmentOperators",
      "d": 1814643,
      "h": 60131356787,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131356787),
//--TRIMMABLE-BOUNDARY-START(193275342963),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620637299,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340114035,
        "f": 83886081
      },
      "n": "LambdaExpressions",
      "d": 1814643,
      "h": 193275342963,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275342963)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721291379),
    {
      "r": 1814643,
      "n": "Clone",
      "d": 1814643,
      "h": 68721291379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721291379)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591749235),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Identifier).$h,
      "n": "_identifiers",
      "d": 1814643,
      "h": 8591749235,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591749235),
//--TRIMMABLE-BOUNDARY-START(12886716531),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.ReferenceType).$h,
      "n": "_knownTypes",
      "d": 1814643,
      "h": 12886716531,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886716531),
//--TRIMMABLE-BOUNDARY-START(4296781939),
    {
      "t": $.$$.SCG.HashSet$$($.$$.SR.MethodInfo).$h,
      "n": "_extensionMethods",
      "d": 1814643,
      "h": 4296781939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296781939),
//--TRIMMABLE-BOUNDARY-START(17181683827),
    {
      "t": $.$$.SCG.HashSet$$($.$sle.SLE.ExpressionVisitor).$h,
      "n": "_visitors",
      "d": 1814643,
      "h": 17181683827,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181683827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541422195),
    {
      "p": [
        {
          "n": "caseInsensitive",
          "p": 262145
        },
        {
          "n": "lateBindObject",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1814643,
      "h": 51541422195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541422195),
//--TRIMMABLE-BOUNDARY-START(55836389491),
    {
      "p": [
        {
          "n": "other",
          "p": 1814643
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1814643,
      "h": 55836389491,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836389491)
  ],
  "h": 1814643
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.ParserSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}ParserSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1814643)
        
        

        //--TRIMMABLE-BOUNDARY-START(1552499)
        $asm.$cls(`$HnZw.D.ParserArguments`, ($self) => class ParserArguments extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296519795)
            /*Dictionary<string, Parameter>*/ _declaredParameters = null;
            //--TRIMMABLE-BOUNDARY-END(4296519795)
            
            //--TRIMMABLE-BOUNDARY-START(12886454387)
            /*HashSet<Parameter>*/ _usedParameters = null;
            //--TRIMMABLE-BOUNDARY-END(12886454387)
            
            //--TRIMMABLE-BOUNDARY-START(17181421683)
            /*HashSet<ReferenceType>*/ _usedTypes = null;
            //--TRIMMABLE-BOUNDARY-END(17181421683)
            
            //--TRIMMABLE-BOUNDARY-START(8591487091)
            /*HashSet<Identifier>*/ _usedIdentifiers = null;
            //--TRIMMABLE-BOUNDARY-END(8591487091)
            
            //--TRIMMABLE-BOUNDARY-START(38656258163)
            $ctor$1(/*string*/ expressionText, /*ParserSettings*/ settings, /*Type*/ expressionReturnType, /*IEnumerable<Parameter>*/ declaredParameters, /*bool*/ reflectionEnabled)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656258163);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ExpressionText = expressionText;
                    this.ExpressionReturnType = expressionReturnType;
                    this.Settings = settings;
                    this.ReflectionEnabled = reflectionEnabled;
                    this._declaredParameters = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Parameter))().$ctor$6(settings.KeyComparer);
                    var $en3 = declaredParameters.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        var pe = $en3.SCG$IEnumerator$$$Current;
                        {
                            try
                            {
                                this._declaredParameters.Add(pe.Name, pe);
                            }
                            catch($e)
                            {
                                throw new $.$HnZw.DE.DuplicateParameterException().$ctor$10(pe.Name);
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656258163)
            
            //--TRIMMABLE-BOUNDARY-START(171800244339)
            /*ParserSettings*/ Settings = null;
            //--TRIMMABLE-BOUNDARY-END(171800244339)
            
            //--TRIMMABLE-BOUNDARY-START(133145538675)
            /*bool*/ ReflectionEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(133145538675)
            
            //--TRIMMABLE-BOUNDARY-START(51541160051)
            /*string*/ ExpressionText = null;
            //--TRIMMABLE-BOUNDARY-END(51541160051)
            
            //--TRIMMABLE-BOUNDARY-START(47246192755)
            /*Type*/ ExpressionReturnType = null;
            //--TRIMMABLE-BOUNDARY-END(47246192755)
            
            //--TRIMMABLE-BOUNDARY-START(42951225459)
            /*IEnumerable<Parameter> */ get DeclaredParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131094643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._declaredParameters.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(42951225459)
            
            //--TRIMMABLE-BOUNDARY-START(193275080819)
            /*IEnumerable<Parameter> */ get UsedParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670702195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._usedParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(193275080819)
            
            //--TRIMMABLE-BOUNDARY-START(197570048115)
            /*IEnumerable<ReferenceType> */ get UsedTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260636787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._usedTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(197570048115)
            
            //--TRIMMABLE-BOUNDARY-START(188980113523)
            /*IEnumerable<Identifier> */ get UsedIdentifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080767603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._usedIdentifiers;
            }
            //--TRIMMABLE-BOUNDARY-END(188980113523)
            
            //--TRIMMABLE-BOUNDARY-START(180390178931)
            /*bool */ TryGetKnownType(/*string*/ name, /*out Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390178931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let reference;
                if (this.Settings.KnownTypes.SCG$IDictionary$$$$TryGetValue(name, $.$ref(() => reference, ($v) => reference = $v, $.$HnZw.D.ReferenceType)))
                {
                    this._usedTypes.Add(reference);
                    type.$v = reference.Type;
                    return true;
                }
                type.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(180390178931)
            
            //--TRIMMABLE-BOUNDARY-START(128850571379)
            /*bool */ HasKnownGenericTypeDefinition(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850571379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let regex = new $.$str.STR.Regex().$ctor$7("^" + name + "`\\d+$");
                return $.$sl.SL.Enumerable.Any($.$HnZw.D.ReferenceType, this.Settings.KnownTypes.SCG$IDictionary$$$$Values, new ($.$$.S.Func$$$($.$HnZw.D.ReferenceType, $.$$.S.Boolean))().$ctor(this,  (/*refType*/ refType) =>
                {
                    return regex.IsMatch$9(refType.Name) && refType.Type.IsGenericTypeDefinition;
                }, _3eb80b94_b55d_4cdf_b676_3ed9fc279674 ??= {"r":262145,"p":[{"n":"refType","p":2076787}],"n":"","d":1552499,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(128850571379)
            
            //--TRIMMABLE-BOUNDARY-START(176095211635)
            /*bool */ TryGetIdentifier(/*string*/ name, /*out Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095211635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let identifier;
                if (this.Settings.Identifiers.SCG$IDictionary$$$$TryGetValue(name, $.$ref(() => identifier, ($v) => identifier = $v, $.$HnZw.D.Identifier)))
                {
                    this._usedIdentifiers.Add(identifier);
                    expression.$v = identifier.Expression;
                    return true;
                }
                expression.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(176095211635)
            
            //--TRIMMABLE-BOUNDARY-START(184685146227)
            /*bool */ TryGetParameters(/*string*/ name, /*out ParameterExpression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685146227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameter;
                if (this._declaredParameters.TryGetValue(name, $.$ref(() => parameter, ($v) => parameter = $v, $.$HnZw.D.Parameter)))
                {
                    this._usedParameters.Add(parameter);
                    expression.$v = parameter.Expression;
                    return true;
                }
                expression.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(184685146227)
            
            //--TRIMMABLE-BOUNDARY-START(124555604083)
            /*IEnumerable<MethodInfo> */ GetExtensionMethods(/*string*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555604083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let comparer = this.Settings.KeyComparer;
                return $.$sl.SL.Enumerable.Where($.$$.SR.MethodInfo, this.Settings.ExtensionMethods, new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return comparer.SCG$IEqualityComparer$System$String$Equals(p.Name, methodName);
                }, _7fbabd69_9806_4e90_b870_dd093faabadd ??= {"r":262145,"p":[{"n":"p","p":117112833}],"n":"","d":1552499,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(124555604083)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886454387)
                this._usedParameters = new ($.$$.SCG.HashSet$$($.$HnZw.D.Parameter))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12886454387)
                
                //--TRIMMABLE-BOUNDARY-START(17181421683)
                this._usedTypes = new ($.$$.SCG.HashSet$$($.$HnZw.D.ReferenceType))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17181421683)
                
                //--TRIMMABLE-BOUNDARY-START(8591487091)
                this._usedIdentifiers = new ($.$$.SCG.HashSet$$($.$HnZw.D.Identifier))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8591487091)
                
            }
            static $h = 1552499;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(171800244339),
    {
      "p": 1814643,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490833011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505277043,
        "f": 83886082
      },
      "n": "Settings",
      "d": 1552499,
      "h": 171800244339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171800244339),
//--TRIMMABLE-BOUNDARY-START(133145538675),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900898419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915342451,
        "f": 83886082
      },
      "n": "ReflectionEnabled",
      "d": 1552499,
      "h": 133145538675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145538675),
//--TRIMMABLE-BOUNDARY-START(51541160051),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310963827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325407859,
        "f": 83886082
      },
      "n": "ExpressionText",
      "d": 1552499,
      "h": 51541160051,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541160051),
//--TRIMMABLE-BOUNDARY-START(47246192755),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721029235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735473267,
        "f": 83886082
      },
      "n": "ExpressionReturnType",
      "d": 1552499,
      "h": 47246192755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246192755),
//--TRIMMABLE-BOUNDARY-START(42951225459),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131094643,
        "f": 50331649
      },
      "n": "DeclaredParameters",
      "d": 1552499,
      "h": 42951225459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951225459),
//--TRIMMABLE-BOUNDARY-START(193275080819),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670702195,
        "f": 50331649
      },
      "n": "UsedParameters",
      "d": 1552499,
      "h": 193275080819,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275080819),
//--TRIMMABLE-BOUNDARY-START(197570048115),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260636787,
        "f": 50331649
      },
      "n": "UsedTypes",
      "d": 1552499,
      "h": 197570048115,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570048115),
//--TRIMMABLE-BOUNDARY-START(188980113523),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080767603,
        "f": 50331649
      },
      "n": "UsedIdentifiers",
      "d": 1552499,
      "h": 188980113523,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980113523)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180390178931),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785,
          "f": 2
        }
      ],
      "n": "TryGetKnownType",
      "d": 1552499,
      "h": 180390178931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180390178931),
//--TRIMMABLE-BOUNDARY-START(128850571379),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "HasKnownGenericTypeDefinition",
      "d": 1552499,
      "h": 128850571379,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(128850571379),
//--TRIMMABLE-BOUNDARY-START(176095211635),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "expression",
          "p": 8781861,
          "f": 2
        }
      ],
      "n": "TryGetIdentifier",
      "d": 1552499,
      "h": 176095211635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176095211635),
//--TRIMMABLE-BOUNDARY-START(184685146227),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "expression",
          "p": 40566821,
          "f": 2
        }
      ],
      "n": "TryGetParameters",
      "d": 1552499,
      "h": 184685146227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184685146227),
//--TRIMMABLE-BOUNDARY-START(124555604083),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SR.MethodInfo).$h,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": "GetExtensionMethods",
      "d": 1552499,
      "h": 124555604083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555604083)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296519795),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Parameter).$h,
      "n": "_declaredParameters",
      "d": 1552499,
      "h": 4296519795,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296519795),
//--TRIMMABLE-BOUNDARY-START(12886454387),
    {
      "t": $.$$.SCG.HashSet$$($.$HnZw.D.Parameter).$h,
      "n": "_usedParameters",
      "d": 1552499,
      "h": 12886454387,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886454387),
//--TRIMMABLE-BOUNDARY-START(17181421683),
    {
      "t": $.$$.SCG.HashSet$$($.$HnZw.D.ReferenceType).$h,
      "n": "_usedTypes",
      "d": 1552499,
      "h": 17181421683,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181421683),
//--TRIMMABLE-BOUNDARY-START(8591487091),
    {
      "t": $.$$.SCG.HashSet$$($.$HnZw.D.Identifier).$h,
      "n": "_usedIdentifiers",
      "d": 1552499,
      "h": 8591487091,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591487091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656258163),
    {
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "settings",
          "p": 1814643
        },
        {
          "n": "expressionReturnType",
          "p": 188022785
        },
        {
          "n": "declaredParameters",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h
        },
        {
          "n": "reflectionEnabled",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1552499,
      "h": 38656258163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656258163)
  ],
  "h": 1552499
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.ParserArguments`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}ParserArguments`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1552499)
        
        

        //--TRIMMABLE-BOUNDARY-START(2207859)
        $asm.$cls(`$HnZw.DR.MemberFinder`, ($self) => class MemberFinder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297175155)
            /*ParserArguments*/ _arguments = null;
            //--TRIMMABLE-BOUNDARY-END(4297175155)
            
            //--TRIMMABLE-BOUNDARY-START(8592142451)
            /*BindingFlags*/ _bindingCase = 0;
            //--TRIMMABLE-BOUNDARY-END(8592142451)
            
            //--TRIMMABLE-BOUNDARY-START(12887109747)
            /*MemberFilter*/ _memberFilterCase = null;
            //--TRIMMABLE-BOUNDARY-END(12887109747)
            
            //--TRIMMABLE-BOUNDARY-START(17182077043)
            $ctor$1(/*ParserArguments*/ $arguments)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182077043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arguments = $arguments;
                    this._bindingCase = $arguments.Settings.CaseInsensitive ? 1/*BindingFlags.IgnoreCase*/ : 0/*BindingFlags.Default*/;
                    this._memberFilterCase = $arguments.Settings.CaseInsensitive ? $.$$.S.Type.FilterNameIgnoreCase : $.$$.S.Type.FilterName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182077043)
            
            //--TRIMMABLE-BOUNDARY-START(42951880819)
            /*MemberInfo */ FindPropertyOrField(/*Type*/ type, /*string*/ memberName, /*bool*/ staticAccess)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951880819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let flags = 16/*BindingFlags.Public*/ | 2/*BindingFlags.DeclaredOnly*/ | (staticAccess ? 8/*BindingFlags.Static*/ : 4/*BindingFlags.Instance*/) | this._bindingCase;
                var $en2 = $.$HnZw.DR.MemberFinder.SelfAndBaseTypes(type).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var t = $en2.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let members = t.FindMembers(16/*MemberTypes.Property*/ | 4/*MemberTypes.Field*/, flags, this._memberFilterCase, memberName);
                        if (members.length !== 0)
                        {
                            return $.$$.System.Array.$ReadT1.call(members, 0);
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(42951880819)
            
            //--TRIMMABLE-BOUNDARY-START(38656913523)
            /*IList<MethodData> */ FindMethods(/*Type*/ type, /*string*/ methodName, /*bool*/ staticAccess, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656913523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let flags = 16/*BindingFlags.Public*/ | 2/*BindingFlags.DeclaredOnly*/ | (staticAccess ? 8/*BindingFlags.Static*/ : 4/*BindingFlags.Instance*/) | this._bindingCase;
                var $en2 = $.$HnZw.DR.MemberFinder.SelfAndBaseTypes(type).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var t = $en2.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let members = t.FindMembers(8/*MemberTypes.Method*/, flags, this._memberFilterCase, methodName);
                        /*var*/ let applicableMethods = $.$HnZw.DR$1.MethodResolution.FindBestMethod$1($.$sl.SL.Enumerable.Cast($.$$.SR.MethodBase, members), args);
                        if (applicableMethods.SCG$ICollection$$$Count > 0)
                        {
                            return applicableMethods;
                        }
                    }
                }
                return $.$$.S.Array.Empty($.$HnZw.DR.MethodData);
            }
            //--TRIMMABLE-BOUNDARY-END(38656913523)
            
            //--TRIMMABLE-BOUNDARY-START(34361946227)
            static /*MethodBase */ FindInvokeMethod(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361946227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let flags = 16/*BindingFlags.Public*/ | 2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/;
                var $en2 = $.$HnZw.DR.MemberFinder.SelfAndBaseTypes(type).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var t = $en2.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let method = $.$sl.SL.Enumerable.SingleOrDefault$3($.$$.SR.MethodBase, $.$sl.SL.Enumerable.Cast($.$$.SR.MethodBase, t.FindMembers(8/*MemberTypes.Method*/, flags, $.$$.S.Type.FilterName, "Invoke")));
                        if ($.$$.SR.MethodBase.op_Inequality$1(method, null))
                        {
                            return method;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34361946227)
            
            //--TRIMMABLE-BOUNDARY-START(25772011635)
            /*IList<MethodData> */ FindExtensionMethods(/*string*/ methodName, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772011635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let matchMethods = this._arguments.GetExtensionMethods(methodName);
                return $.$HnZw.DR$1.MethodResolution.FindBestMethod$1($.$$.N.InterfaceVarianceStubHandler.Create(matchMethods, $.$$.SCG.IEnumerable$$($.$$.SR.MethodInfo), $.$$.SCG.IEnumerable$$($.$$.SR.MethodBase)), args);
            }
            //--TRIMMABLE-BOUNDARY-END(25772011635)
            
            //--TRIMMABLE-BOUNDARY-START(30066978931)
            /*IList<MethodData> */ FindIndexer(/*Type*/ type, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066978931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = $.$HnZw.DR.MemberFinder.SelfAndBaseTypes(type).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var t = $en2.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let members = t.GetDefaultMembers();
                        if (members.length !== 0)
                        {
                            /*var*/ let methods = $.$sl.SL.Enumerable.Select$1($.$$.SR.PropertyInfo, $.$HnZw.DR.MethodData, $.$sl.SL.Enumerable.OfType($.$$.SR.PropertyInfo, members), new ($.$$.S.Func$$$($.$$.SR.PropertyInfo, $.$HnZw.DR.MethodData))().$ctor(this,  (/*p*/ p) =>
                            {
                                return new $.$HnZw.DR.IndexerData().$ctor$2(p);
                            }, _8358bb93_bb12_40f0_98a3_e92b83a690d1 ??= {"r":2273395,"p":[{"n":"p","p":119144449}],"n":"","d":2207859,"h":0,"f":17825794}));
                            /*var*/ let applicableMethods = $.$HnZw.DR$1.MethodResolution.FindBestMethod(methods, args);
                            if (applicableMethods.SCG$ICollection$$$Count > 0)
                            {
                                return applicableMethods;
                            }
                        }
                    }
                }
                return $.$$.S.Array.Empty($.$HnZw.DR.MethodData);
            }
            //--TRIMMABLE-BOUNDARY-END(30066978931)
            
            //--TRIMMABLE-BOUNDARY-START(51541815411)
            static /*IEnumerable<Type> */ SelfAndBaseTypes(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541815411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsInterface)
                {
                    /*var*/ let types = new ($.$$.SCG.List$$($.$$.S.Type))().$ctor$1();
                    $.$HnZw.DR.MemberFinder.AddInterface(types, type);
                    types.Add($.$$.S.Object.$type);
                    return types;
                }
                return $.$HnZw.DR.MemberFinder.SelfAndBaseClasses(type);
            }
            //--TRIMMABLE-BOUNDARY-END(51541815411)
            
            //--TRIMMABLE-BOUNDARY-START(47246848115)
            static /*IEnumerable<Type> */ SelfAndBaseClasses(/*Type*/ type)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Type))().$ctor$1(function*()
                {
                    while($.$$.S.Type.op_Inequality$1(type, null))
                    {
                        yield type;
                        type = type.BaseType;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(47246848115)
            
            //--TRIMMABLE-BOUNDARY-START(21477044339)
            static /*void */ AddInterface(/*List<Type>*/ types, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477044339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!types.Contains(type))
                {
                    types.Add(type);
                    let $i1 = 0;
                    let $arr1 = type.GetInterfaces();
                    while ($i1 < $arr1.length)
                    {
                        let t = $arr1[$i1++];
                        $.$HnZw.DR.MemberFinder.AddInterface(types, t);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477044339)
            
            static $h = 2207859;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951880819),
    {
      "r": 115736577,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "staticAccess",
          "p": 262145
        }
      ],
      "n": "FindPropertyOrField",
      "d": 2207859,
      "h": 42951880819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951880819),
//--TRIMMABLE-BOUNDARY-START(38656913523),
    {
      "r": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "staticAccess",
          "p": 262145
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "FindMethods",
      "d": 2207859,
      "h": 38656913523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656913523),
//--TRIMMABLE-BOUNDARY-START(34361946227),
    {
      "r": 116457473,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "FindInvokeMethod",
      "d": 2207859,
      "h": 34361946227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361946227),
//--TRIMMABLE-BOUNDARY-START(25772011635),
    {
      "r": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "FindExtensionMethods",
      "d": 2207859,
      "h": 25772011635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772011635),
//--TRIMMABLE-BOUNDARY-START(30066978931),
    {
      "r": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "FindIndexer",
      "d": 2207859,
      "h": 30066978931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066978931),
//--TRIMMABLE-BOUNDARY-START(51541815411),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "SelfAndBaseTypes",
      "d": 2207859,
      "h": 51541815411,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541815411),
//--TRIMMABLE-BOUNDARY-START(47246848115),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Type).$h,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "SelfAndBaseClasses",
      "d": 2207859,
      "h": 47246848115,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246848115),
//--TRIMMABLE-BOUNDARY-START(21477044339),
    {
      "r": 65537,
      "p": [
        {
          "n": "types",
          "p": $.$$.SCG.List$$($.$$.S.Type).$h
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "AddInterface",
      "d": 2207859,
      "h": 21477044339,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21477044339)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297175155),
    {
      "t": 1552499,
      "n": "_arguments",
      "d": 2207859,
      "h": 4297175155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297175155),
//--TRIMMABLE-BOUNDARY-START(8592142451),
    {
      "t": 108593153,
      "n": "_bindingCase",
      "d": 2207859,
      "h": 8592142451,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592142451),
//--TRIMMABLE-BOUNDARY-START(12887109747),
    {
      "t": 115671041,
      "n": "_memberFilterCase",
      "d": 2207859,
      "h": 12887109747,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887109747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182077043),
    {
      "p": [
        {
          "n": "arguments",
          "p": 1552499
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2207859,
      "h": 17182077043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182077043)
  ],
  "h": 2207859
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.MemberFinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}MemberFinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2207859)
        
        

        //--TRIMMABLE-BOUNDARY-START(241779)
        $asm.$cls(`$HnZw.D.Detector`, ($self) => class Detector extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295209075)
            /*ParserSettings*/ _settings = null;
            //--TRIMMABLE-BOUNDARY-END(4295209075)
            
            //--TRIMMABLE-BOUNDARY-START(51539849331)
            /*Regex*/ static RootIdentifierDetectionRegex = null;
            //--TRIMMABLE-BOUNDARY-END(51539849331)
            
            //--TRIMMABLE-BOUNDARY-START(25770045555)
            /*string*/ static Id = null;
            //--TRIMMABLE-BOUNDARY-END(25770045555)
            
            //--TRIMMABLE-BOUNDARY-START(60129783923)
            /*string*/ static Type = null;
            //--TRIMMABLE-BOUNDARY-END(60129783923)
            
            //--TRIMMABLE-BOUNDARY-START(34359980147)
            /*Regex*/ static LambdaDetectionRegex = null;
            //--TRIMMABLE-BOUNDARY-END(34359980147)
            
            //--TRIMMABLE-BOUNDARY-START(55834816627)
            /*Regex*/ static StringDetectionRegex = null;
            //--TRIMMABLE-BOUNDARY-END(55834816627)
            
            //--TRIMMABLE-BOUNDARY-START(17180110963)
            /*Regex*/ static CharDetectionRegex = null;
            //--TRIMMABLE-BOUNDARY-END(17180110963)
            
            //--TRIMMABLE-BOUNDARY-START(12885143667)
            $ctor$1(/*ParserSettings*/ settings)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885143667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._settings = settings;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885143667)
            
            //--TRIMMABLE-BOUNDARY-START(21475078259)
            /*IdentifiersInfo */ DetectIdentifiers(/*string*/ expression, /*DetectorOptions*/ option)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475078259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                expression = $.$HnZw.D.Detector.PrepareExpression(expression);
                /*var*/ let unknownIdentifiers = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$4(this._settings.KeyComparer);
                /*var*/ let knownIdentifiers = new ($.$$.SCG.HashSet$$($.$HnZw.D.Identifier))().$ctor$1();
                /*var*/ let knownTypes = new ($.$$.SCG.HashSet$$($.$HnZw.D.ReferenceType))().$ctor$1();
                /*var*/ let lambdaParameters = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$HnZw.D.Identifier))().$ctor$1();
                var $en2 = $.$HnZw.D.Detector.LambdaDetectionRegex.Matches$4(expression).GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var match = $en2.SC$1$IEnumerator$Current;
                    {
                        /*var*/ let withtypes = match.Groups.get_Item$2("withtype").Captures;
                        /*var*/ let types = match.Groups.get_Item$2("type").Captures;
                        /*var*/ let identifiers = match.Groups.get_Item$2("id").Captures;
                        /*var*/ let t = 0;
                        for(/*var*/ let i = 0; i < withtypes.Count; i++)
                        {
                            /*var*/ let withtype = withtypes.get_Item$1(i).Value;
                            /*var*/ let identifier = identifiers.get_Item$1(i).Value;
                            /*var*/ let type = $.$$.S.Object.$type;
                            if ($.$$.S.String.op_Inequality(withtype, identifier))
                            {
                                /*var*/ let typeName = types.get_Item$1(t).Value;
                                /*var*/ let knownType;
                                if (this._settings.KnownTypes.SCG$IDictionary$$$$TryGetValue(typeName, $.$ref(() => knownType, ($v) => knownType = $v, $.$HnZw.D.ReferenceType)))
                                {
                                    type = knownType.Type;
                                }
                                t++;
                            }
                            /*var*/ let already;
                            if (lambdaParameters.TryGetValue(identifier, $.$ref(() => already, ($v) => already = $v, $.$HnZw.D.Identifier)) && $.$$.S.Type.op_Inequality$1(already.Expression.Type, type))
                            {
                                type = $.$$.S.Object.$type;
                            }
                            /*var*/ let defaultValue = type.IsValueType ? $.$$.S.Activator.CreateInstance$9(type) : null;
                            lambdaParameters.set_Item(identifier, new $.$HnZw.D.Identifier().$ctor$1(identifier, $.$sle.SLE.Expression.Constant(defaultValue, type)));
                        }
                    }
                }
                var $en2 = $.$HnZw.D.Detector.RootIdentifierDetectionRegex.Matches$4(expression).GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var match = $en2.SC$1$IEnumerator$Current;
                    {
                        /*var*/ let idGroup = match.Groups.get_Item$2("id");
                        /*var*/ let identifier = idGroup.Value;
                        if (this.IsReservedKeyword(identifier))
                        {
                            continue;
                        }
                        if (option === 0/*DetectorOptions.None*/ && idGroup.Index > 0)
                        {
                            /*var*/ let previousChar = $.$$.S.String.get_Chars.call(expression, ((idGroup.Index - 1) | 0));
                            if (previousChar === /*.*/ 46)
                            {
                                continue;
                            }
                            if ($.$$.S.Char.IsDigit$1(previousChar))
                            {
                                continue;
                            }
                        }
                        /*var*/ let knownIdentifier;
                        /*var*/ let knownLambdaParam;
                        /*var*/ let knownType;
                        if (this._settings.Identifiers.SCG$IDictionary$$$$TryGetValue(identifier, $.$ref(() => knownIdentifier, ($v) => knownIdentifier = $v, $.$HnZw.D.Identifier)))
                        {
                            knownIdentifiers.Add(knownIdentifier);
                        }
                        else if (lambdaParameters.TryGetValue(identifier, $.$ref(() => knownLambdaParam, ($v) => knownLambdaParam = $v, $.$HnZw.D.Identifier)))
                        {
                            knownIdentifiers.Add(knownLambdaParam);
                        }
                        else if (this._settings.KnownTypes.SCG$IDictionary$$$$TryGetValue(identifier, $.$ref(() => knownType, ($v) => knownType = $v, $.$HnZw.D.ReferenceType)))
                        {
                            knownTypes.Add(knownType);
                        }
                        else 
                        {
                            unknownIdentifiers.Add(identifier);
                        }
                    }
                }
                return new $.$HnZw.D.IdentifiersInfo().$ctor$1(unknownIdentifiers, knownIdentifiers, knownTypes);
            }
            //--TRIMMABLE-BOUNDARY-END(21475078259)
            
            //--TRIMMABLE-BOUNDARY-START(38654947443)
            static /*string */ PrepareExpression(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654947443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                expression = expression ?? $.$$.S.String.Empty;
                expression = $.$HnZw.D.Detector.RemoveStringLiterals(expression);
                expression = $.$HnZw.D.Detector.RemoveCharLiterals(expression);
                return expression;
            }
            //--TRIMMABLE-BOUNDARY-END(38654947443)
            
            //--TRIMMABLE-BOUNDARY-START(47244882035)
            static /*string */ RemoveStringLiterals(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244882035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.D.Detector.StringDetectionRegex.Replace$8(expression, "");
            }
            //--TRIMMABLE-BOUNDARY-END(47244882035)
            
            //--TRIMMABLE-BOUNDARY-START(42949914739)
            static /*string */ RemoveCharLiterals(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949914739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.D.Detector.CharDetectionRegex.Replace$8(expression, "");
            }
            //--TRIMMABLE-BOUNDARY-END(42949914739)
            
            //--TRIMMABLE-BOUNDARY-START(30065012851)
            /*bool */ IsReservedKeyword(/*string*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065012851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1($.$HnZw.DP.ParserConstants.ReservedKeywords), identifier, this._settings.KeyComparer);
            }
            //--TRIMMABLE-BOUNDARY-END(30065012851)
            
            //--TRIMMABLE-BOUNDARY-START(8590176371)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590176371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51539849331)
                    this.RootIdentifierDetectionRegex = new $.$str.STR.Regex().$ctor$6("(?<=[^\\w@]|^)(?<id>@?[\\p{L}\\p{Nl}_][\\p{L}\\p{Nl}\\p{Nd}\\p{Mn}\\p{Mc}\\p{Pc}\\p{Cf}_]*)", 8/*RegexOptions.Compiled*/);
                    //--TRIMMABLE-BOUNDARY-END(51539849331)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770045555)
                    this.Id = $.$HnZw.D.Detector.RootIdentifierDetectionRegex.ToString();
                    //--TRIMMABLE-BOUNDARY-END(25770045555)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129783923)
                    this.Type = $.$$.S.String.Replace$3.call($.$HnZw.D.Detector.Id, "<id>", "<type>");
                    //--TRIMMABLE-BOUNDARY-END(60129783923)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359980147)
                    this.LambdaDetectionRegex = new $.$str.STR.Regex().$ctor$6(`(\\((((?<withtype>(${$.$HnZw.D.Detector.Type}\\s+)?${$.$HnZw.D.Detector.Id}))(\\s*,\\s*)?)+\\)|(?<withtype>${$.$HnZw.D.Detector.Id}))\\s*=>`, 8/*RegexOptions.Compiled*/);
                    //--TRIMMABLE-BOUNDARY-END(34359980147)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834816627)
                    this.StringDetectionRegex = new $.$str.STR.Regex().$ctor$6("(?<!\\\\)?\".*?(?<!\\\\)\"", 8/*RegexOptions.Compiled*/);
                    //--TRIMMABLE-BOUNDARY-END(55834816627)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180110963)
                    this.CharDetectionRegex = new $.$str.STR.Regex().$ctor$6("(?<!\\\\)?'.{1,2}?(?<!\\\\)'", 8/*RegexOptions.Compiled*/);
                    //--TRIMMABLE-BOUNDARY-END(17180110963)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590176371)
            
            static $h = 241779;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475078259),
    {
      "r": 962675,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "option",
          "p": 307315
        }
      ],
      "n": "DetectIdentifiers",
      "d": 241779,
      "h": 21475078259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475078259),
//--TRIMMABLE-BOUNDARY-START(38654947443),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "PrepareExpression",
      "d": 241779,
      "h": 38654947443,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654947443),
//--TRIMMABLE-BOUNDARY-START(47244882035),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "RemoveStringLiterals",
      "d": 241779,
      "h": 47244882035,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244882035),
//--TRIMMABLE-BOUNDARY-START(42949914739),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "RemoveCharLiterals",
      "d": 241779,
      "h": 42949914739,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949914739),
//--TRIMMABLE-BOUNDARY-START(30065012851),
    {
      "r": 262145,
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "n": "IsReservedKeyword",
      "d": 241779,
      "h": 30065012851,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065012851)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295209075),
    {
      "t": 1814643,
      "n": "_settings",
      "d": 241779,
      "h": 4295209075,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295209075),
//--TRIMMABLE-BOUNDARY-START(51539849331),
    {
      "t": 1900602,
      "n": "RootIdentifierDetectionRegex",
      "d": 241779,
      "h": 51539849331,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539849331),
//--TRIMMABLE-BOUNDARY-START(25770045555),
    {
      "t": 1310721,
      "n": "Id",
      "d": 241779,
      "h": 25770045555,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770045555),
//--TRIMMABLE-BOUNDARY-START(60129783923),
    {
      "t": 1310721,
      "n": "Type",
      "d": 241779,
      "h": 60129783923,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129783923),
//--TRIMMABLE-BOUNDARY-START(34359980147),
    {
      "t": 1900602,
      "n": "LambdaDetectionRegex",
      "d": 241779,
      "h": 34359980147,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359980147),
//--TRIMMABLE-BOUNDARY-START(55834816627),
    {
      "t": 1900602,
      "n": "StringDetectionRegex",
      "d": 241779,
      "h": 55834816627,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834816627),
//--TRIMMABLE-BOUNDARY-START(17180110963),
    {
      "t": 1900602,
      "n": "CharDetectionRegex",
      "d": 241779,
      "h": 17180110963,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180110963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885143667),
    {
      "p": [
        {
          "n": "settings",
          "p": 1814643
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 241779,
      "h": 12885143667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885143667)
  ],
  "h": 241779
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Detector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Detector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(241779)
        
        

        //--TRIMMABLE-BOUNDARY-START(897139)
        $asm.$cls(`$HnZw.D.Identifier`, ($self) => class Identifier extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180766323)
            /*Expression*/ Expression = null;
            //--TRIMMABLE-BOUNDARY-END(17180766323)
            
            //--TRIMMABLE-BOUNDARY-START(38655602803)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(38655602803)
            
            //--TRIMMABLE-BOUNDARY-START(12885799027)
            $ctor$1(/*string*/ name, /*Expression*/ expression)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885799027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrWhiteSpace(name))
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                    }
                    if (expression === null)
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("expression");
                    }
                    this.Expression = expression;
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885799027)
            
            static $h = 897139;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180766323),
    {
      "p": 8781861,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770700915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245537395,
        "f": 83886082
      },
      "n": "Expression",
      "d": 897139,
      "h": 17180766323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180766323),
//--TRIMMABLE-BOUNDARY-START(38655602803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360635507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835471987,
        "f": 83886082
      },
      "n": "Name",
      "d": 897139,
      "h": 38655602803,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655602803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885799027),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 897139,
      "h": 12885799027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885799027)
  ],
  "h": 897139
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Identifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Identifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(897139)
        
        

        //--TRIMMABLE-BOUNDARY-START(2338931)
        $asm.$cls(`$HnZw.DR.ReflectionExtensions`, ($self) => class ReflectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(47246979187)
            /*MethodInfo*/ static StringConcatMethod = null;
            //--TRIMMABLE-BOUNDARY-END(47246979187)
            
            //--TRIMMABLE-BOUNDARY-START(42952011891)
            /*MethodInfo*/ static ObjectToStringMethod = null;
            //--TRIMMABLE-BOUNDARY-END(42952011891)
            
            //--TRIMMABLE-BOUNDARY-START(12887240819)
            static /*DelegateInfo */ GetDelegateInfo(/*Type*/ delegateType, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887240819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let method = delegateType.GetMethod$12("Invoke");
                if ($.$$.SR.MethodInfo.op_Equality$2(method, null))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14("The specified type is not a delegate");
                }
                /*var*/ let delegateParameters = method.GetParameters();
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.Parameter), null, [delegateParameters.length], null);
                /*var*/ let useCustomNames = parametersNames !== null && parametersNames.length > 0;
                if (useCustomNames && parametersNames.length !== parameters.length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$$.S.String.Format$9("Provided parameters names doesn't match delegate parameters, {0} parameters expected.", $.$box(parameters.length, $.$$.S.Int32)));
                }
                for(/*var*/ let i = 0; i < parameters.length; i++)
                {
                    /*var*/ let paramName = useCustomNames ? $.$$.System.Array.$ReadT1.call(parametersNames, i) : $.$$.System.Array.$ReadT1.call(delegateParameters, i).Name;
                    /*var*/ let paramType = $.$$.System.Array.$ReadT1.call(delegateParameters, i).ParameterType;
                    $.$$.System.Array.$WriteT1.call(parameters, new $.$HnZw.D.Parameter().$ctor$3(paramName, paramType, null), i);
                }
                return new $.$HnZw.DR.ReflectionExtensions.DelegateInfo().$ctor$1(method.ReturnType, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(12887240819)
            
            //--TRIMMABLE-BOUNDARY-START(17182208115)
            static /*IEnumerable<MethodInfo> */ GetExtensionMethods(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182208115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsSealed$1 && type.IsAbstract$1 && !type.IsGenericType && !type.IsNested)
                {
                    /*var*/ let query = $.$sl.SL.Enumerable.Select$1($.$$.SR.MethodInfo, $.$$.SR.MethodInfo, $.$sl.SL.Enumerable.Where($.$$.SR.MethodInfo, type.GetMethods$1(8/*BindingFlags.Static*/ | 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/), new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$$.S.Boolean))().$ctor(this,  (/*method*/ method) =>
                    {
                        return method.IsDefined($.$$.SRC.ExtensionAttribute.$type, false);
                    }, _b75cd2ef_bdaf_4858_93e4_0608b2aa2a16 ??= {"r":262145,"p":[{"n":"method","p":117112833}],"n":"","d":2338931,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$$.SR.MethodInfo))().$ctor(this,  (/*method*/ method) =>
                    {
                        return method;
                    }, _fffcbf50_92c6_44d2_ad8b_54d16e3c9ace ??= {"r":117112833,"p":[{"n":"method","p":117112833}],"n":"","d":2338931,"h":0,"f":17825794}));
                    return query;
                }
                return $.$sl.SL.Enumerable.Empty($.$$.SR.MethodInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(17182208115)
            
            //--TRIMMABLE-BOUNDARY-START(2404467)
            static $_DelegateInfo;
            static get DelegateInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2404467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$HnZw.DR.ReflectionExtensions;
                return $cls.$_DelegateInfo ??= $asm.$ncls(`$HnZw.DR.ReflectionExtensions.DelegateInfo`, ($self) => class DelegateInfo extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12887306355)
                    $ctor$1(/*Type*/ returnType, /*Parameter[]*/ parameters)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12887306355);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.ReturnType = returnType;
                            this.Parameters = parameters;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887306355)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657110131)
                    /*Type*/ ReturnType = null;
                    //--TRIMMABLE-BOUNDARY-END(38657110131)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362142835)
                    /*Parameter[]*/ Parameters = null;
                    //--TRIMMABLE-BOUNDARY-END(34362142835)
                    
                    static $h = 2404467;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657110131),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067175539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836979315,
        "f": 83886082
      },
      "n": "ReturnType",
      "d": 2404467,
      "h": 38657110131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657110131),
//--TRIMMABLE-BOUNDARY-START(34362142835),
    {
      "p": $.$typeArray($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477240947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247044723,
        "f": 83886082
      },
      "n": "Parameters",
      "d": 2404467,
      "h": 34362142835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362142835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887306355),
    {
      "p": [
        {
          "n": "returnType",
          "p": 188022785
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2404467,
      "h": 12887306355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887306355)
  ],
  "d": 2338931,
  "h": 2404467
}; }
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.ReflectionExtensions+DelegateInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}ReflectionExtensions${separator}DelegateInfo`; }
                }, $cls, ($v) => $cls.$_DelegateInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2404467)
            
            //--TRIMMABLE-BOUNDARY-START(34362077299)
            static /*MethodInfo */ GetStringConcatMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362077299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let methodInfo = $.$$.S.String.$type.GetMethod$11("Concat", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$$.S.String.$type, $.$$.S.String.$type], null, null));
                if ($.$$.SR.MethodInfo.op_Equality$2(methodInfo, null))
                {
                    throw new $.$$.S.Exception().$ctor$4("String concat method not found");
                }
                return methodInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(34362077299)
            
            //--TRIMMABLE-BOUNDARY-START(25772142707)
            static /*MethodInfo */ GetObjectToStringMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772142707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let toStringMethod = $.$$.S.Object.$type.GetMethod$11("ToString", $.$$.S.Type.EmptyTypes);
                if ($.$$.SR.MethodInfo.op_Equality$2(toStringMethod, null))
                {
                    throw new $.$$.S.Exception().$ctor$4("ToString method not found");
                }
                return toStringMethod;
            }
            //--TRIMMABLE-BOUNDARY-END(25772142707)
            
            //--TRIMMABLE-BOUNDARY-START(21477175411)
            static /*Type */ GetFuncType(/*int*/ parameterCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477175411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Func$$().$type.Assembly.GetType$3(`System.Func\`${((parameterCount + 1) | 0)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(21477175411)
            
            //--TRIMMABLE-BOUNDARY-START(8592273523)
            static /*Type */ GetActionType(/*int*/ parameterCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592273523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Action$$().$type.Assembly.GetType$3(`System.Action\`${parameterCount}`);
            }
            //--TRIMMABLE-BOUNDARY-END(8592273523)
            
            //--TRIMMABLE-BOUNDARY-START(38657044595)
            static /*bool */ HasParamsArrayType(/*ParameterInfo*/ parameterInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657044595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return parameterInfo.IsDefined($.$$.S.ParamArrayAttribute.$type, false);
            }
            //--TRIMMABLE-BOUNDARY-END(38657044595)
            
            //--TRIMMABLE-BOUNDARY-START(30067110003)
            static /*Type */ GetParameterType(/*ParameterInfo*/ parameterInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067110003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let isParamsArray = $.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(parameterInfo);
                /*var*/ let type = isParamsArray ? parameterInfo.ParameterType.GetElementType() : parameterInfo.ParameterType;
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(30067110003)
            
            //--TRIMMABLE-BOUNDARY-START(4297306227)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297306227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47246979187)
                    this.StringConcatMethod = $.$HnZw.DR.ReflectionExtensions.GetStringConcatMethod();
                    //--TRIMMABLE-BOUNDARY-END(47246979187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952011891)
                    this.ObjectToStringMethod = $.$HnZw.DR.ReflectionExtensions.GetObjectToStringMethod();
                    //--TRIMMABLE-BOUNDARY-END(42952011891)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297306227)
            
            static $h = 2338931;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887240819),
    {
      "r": 2404467,
      "p": [
        {
          "n": "delegateType",
          "p": 188022785
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetDelegateInfo",
      "d": 2338931,
      "h": 12887240819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887240819),
//--TRIMMABLE-BOUNDARY-START(17182208115),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SR.MethodInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "GetExtensionMethods",
      "d": 2338931,
      "h": 17182208115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182208115),
//--TRIMMABLE-BOUNDARY-START(34362077299),
    {
      "r": 117112833,
      "n": "GetStringConcatMethod",
      "d": 2338931,
      "h": 34362077299,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34362077299),
//--TRIMMABLE-BOUNDARY-START(25772142707),
    {
      "r": 117112833,
      "n": "GetObjectToStringMethod",
      "d": 2338931,
      "h": 25772142707,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25772142707),
//--TRIMMABLE-BOUNDARY-START(21477175411),
    {
      "r": 188022785,
      "p": [
        {
          "n": "parameterCount",
          "p": 655361
        }
      ],
      "n": "GetFuncType",
      "d": 2338931,
      "h": 21477175411,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477175411),
//--TRIMMABLE-BOUNDARY-START(8592273523),
    {
      "r": 188022785,
      "p": [
        {
          "n": "parameterCount",
          "p": 655361
        }
      ],
      "n": "GetActionType",
      "d": 2338931,
      "h": 8592273523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592273523),
//--TRIMMABLE-BOUNDARY-START(38657044595),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118620161
        }
      ],
      "n": "HasParamsArrayType",
      "d": 2338931,
      "h": 38657044595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657044595),
//--TRIMMABLE-BOUNDARY-START(30067110003),
    {
      "r": 188022785,
      "p": [
        {
          "n": "parameterInfo",
          "p": 118620161
        }
      ],
      "n": "GetParameterType",
      "d": 2338931,
      "h": 30067110003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067110003)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47246979187),
    {
      "t": 117112833,
      "n": "StringConcatMethod",
      "d": 2338931,
      "h": 47246979187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246979187),
//--TRIMMABLE-BOUNDARY-START(42952011891),
    {
      "t": 117112833,
      "n": "ObjectToStringMethod",
      "d": 2338931,
      "h": 42952011891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952011891)
  ],
  "j": [2404467
  ],
  "h": 2338931
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.ReflectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}ReflectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2338931)
        
        

        //--TRIMMABLE-BOUNDARY-START(1880179)
        $asm.$cls(`$HnZw.DP.ParseSignatures`, ($self) => class ParseSignatures
        {
            //--TRIMMABLE-BOUNDARY-START(34361618547)
            static /*MethodBase[] */ MakeUnarySignatures(/*params Type[]*/ possibleOperandTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361618547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let signatures = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.MethodBase), null, [possibleOperandTypes.length], null);
                for(/*var*/ let i = 0; i < possibleOperandTypes.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(signatures, new $.$HnZw.DR.SimpleMethodSignature().$ctor$5($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$$.System.Array.$ReadT1.call(possibleOperandTypes, i) ], null, null)), i);
                }
                return signatures;
            }
            //--TRIMMABLE-BOUNDARY-END(34361618547)
            
            //--TRIMMABLE-BOUNDARY-START(30066651251)
            static /*MethodBase[] */ MakeBinarySignatures(/*IList<(Type, Type)>*/ possibleOperandTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066651251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let signatures = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.MethodBase), null, [possibleOperandTypes.SCG$ICollection$$$Count], null);
                for(/*var*/ let i = 0; i < possibleOperandTypes.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let  [ left, right ] = $.$destructure(possibleOperandTypes.SCG$IList$$$get_Item(i));
                    $.$$.System.Array.$WriteT1.call(signatures, new $.$HnZw.DR.SimpleMethodSignature().$ctor$5($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ left, right ], null, null)), i);
                }
                return signatures;
            }
            //--TRIMMABLE-BOUNDARY-END(30066651251)
            
            //--TRIMMABLE-BOUNDARY-START(25771683955)
            /*MethodBase[]*/ static LogicalSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(25771683955)
            
            //--TRIMMABLE-BOUNDARY-START(12886782067)
            /*MethodBase[]*/ static ArithmeticSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(12886782067)
            
            //--TRIMMABLE-BOUNDARY-START(47246520435)
            /*MethodBase[]*/ static RelationalSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(47246520435)
            
            //--TRIMMABLE-BOUNDARY-START(21476716659)
            /*MethodBase[]*/ static EqualitySignatures = null;
            //--TRIMMABLE-BOUNDARY-END(21476716659)
            
            //--TRIMMABLE-BOUNDARY-START(8591814771)
            /*MethodBase[]*/ static AddSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(8591814771)
            
            //--TRIMMABLE-BOUNDARY-START(55836455027)
            /*MethodBase[]*/ static SubtractSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(55836455027)
            
            //--TRIMMABLE-BOUNDARY-START(38656585843)
            /*MethodBase[]*/ static NegationSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(38656585843)
            
            //--TRIMMABLE-BOUNDARY-START(42951553139)
            /*MethodBase[]*/ static NotSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(42951553139)
            
            //--TRIMMABLE-BOUNDARY-START(17181749363)
            /*MethodBase[]*/ static BitwiseComplementSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(17181749363)
            
            //--TRIMMABLE-BOUNDARY-START(51541487731)
            /*MethodBase[]*/ static ShiftSignatures = null;
            //--TRIMMABLE-BOUNDARY-END(51541487731)
            
            //--TRIMMABLE-BOUNDARY-START(4296847475)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296847475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25771683955)
                    this.LogicalSignatures = $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Boolean.$type, $.$$.S.Boolean.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Boolean).$type, $.$typeNullable($.$$.S.Boolean).$type)], null, null));
                    //--TRIMMABLE-BOUNDARY-END(25771683955)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886782067)
                    this.ArithmeticSignatures = $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Int32.$type, $.$$.S.Int32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.UInt32.$type, $.$$.S.UInt32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Int64.$type, $.$$.S.Int64.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.UInt64.$type, $.$$.S.UInt64.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Single.$type, $.$$.S.Single.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Double.$type, $.$$.S.Double.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Decimal.$type, $.$$.S.Decimal.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Int32).$type, $.$typeNullable($.$$.S.Int32).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.UInt32).$type, $.$typeNullable($.$$.S.UInt32).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Int64).$type, $.$typeNullable($.$$.S.Int64).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.UInt64).$type, $.$typeNullable($.$$.S.UInt64).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Single).$type, $.$typeNullable($.$$.S.Single).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Double).$type, $.$typeNullable($.$$.S.Double).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Decimal).$type, $.$typeNullable($.$$.S.Decimal).$type)], null, null));
                    //--TRIMMABLE-BOUNDARY-END(12886782067)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246520435)
                    this.RelationalSignatures = $.$sl.SL.Enumerable.ToArray($.$$.SR.MethodBase, $.$sl.SL.Enumerable.Concat($.$$.SR.MethodBase, $.$HnZw.DP.ParseSignatures.ArithmeticSignatures, $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.String.$type, $.$$.S.String.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Char.$type, $.$$.S.Char.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.DateTime.$type, $.$$.S.DateTime.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.TimeSpan.$type, $.$$.S.TimeSpan.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Char).$type, $.$typeNullable($.$$.S.Char).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.DateTime).$type, $.$typeNullable($.$$.S.DateTime).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.TimeSpan).$type, $.$typeNullable($.$$.S.TimeSpan).$type)], null, null))));
                    //--TRIMMABLE-BOUNDARY-END(47246520435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476716659)
                    this.EqualitySignatures = $.$sl.SL.Enumerable.ToArray($.$$.SR.MethodBase, $.$sl.SL.Enumerable.Concat($.$$.SR.MethodBase, $.$HnZw.DP.ParseSignatures.RelationalSignatures, $.$HnZw.DP.ParseSignatures.LogicalSignatures));
                    //--TRIMMABLE-BOUNDARY-END(21476716659)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591814771)
                    this.AddSignatures = $.$sl.SL.Enumerable.ToArray($.$$.SR.MethodBase, $.$sl.SL.Enumerable.Concat($.$$.SR.MethodBase, $.$HnZw.DP.ParseSignatures.ArithmeticSignatures, $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.DateTime.$type, $.$$.S.TimeSpan.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.TimeSpan.$type, $.$$.S.TimeSpan.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.DateTime).$type, $.$typeNullable($.$$.S.TimeSpan).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.TimeSpan).$type, $.$typeNullable($.$$.S.TimeSpan).$type)], null, null))));
                    //--TRIMMABLE-BOUNDARY-END(8591814771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836455027)
                    this.SubtractSignatures = $.$sl.SL.Enumerable.ToArray($.$$.SR.MethodBase, $.$sl.SL.Enumerable.Concat($.$$.SR.MethodBase, $.$HnZw.DP.ParseSignatures.AddSignatures, $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.DateTime.$type, $.$$.S.DateTime.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.DateTime).$type, $.$typeNullable($.$$.S.DateTime).$type)], null, null))));
                    //--TRIMMABLE-BOUNDARY-END(55836455027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656585843)
                    this.NegationSignatures = $.$HnZw.DP.ParseSignatures.MakeUnarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$$.S.Int32.$type, $.$$.S.UInt32.$type, $.$$.S.Int64.$type, $.$$.S.UInt64.$type, $.$$.S.Single.$type, $.$$.S.Double.$type, $.$$.S.Decimal.$type, $.$typeNullable($.$$.S.Int32).$type, $.$typeNullable($.$$.S.UInt32).$type, $.$typeNullable($.$$.S.Int64).$type, $.$typeNullable($.$$.S.UInt64).$type, $.$typeNullable($.$$.S.Single).$type, $.$typeNullable($.$$.S.Double).$type, $.$typeNullable($.$$.S.Decimal).$type ], null, null));
                    //--TRIMMABLE-BOUNDARY-END(38656585843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951553139)
                    this.NotSignatures = $.$HnZw.DP.ParseSignatures.MakeUnarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$$.S.Boolean.$type, $.$typeNullable($.$$.S.Boolean).$type ], null, null));
                    //--TRIMMABLE-BOUNDARY-END(42951553139)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181749363)
                    this.BitwiseComplementSignatures = $.$HnZw.DP.ParseSignatures.MakeUnarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$$.S.Int32.$type, $.$$.S.UInt32.$type, $.$$.S.Int64.$type, $.$$.S.UInt64.$type, $.$typeNullable($.$$.S.Int32).$type, $.$typeNullable($.$$.S.UInt32).$type, $.$typeNullable($.$$.S.Int64).$type, $.$typeNullable($.$$.S.UInt64).$type ], null, null));
                    //--TRIMMABLE-BOUNDARY-END(17181749363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541487731)
                    this.ShiftSignatures = $.$HnZw.DP.ParseSignatures.MakeBinarySignatures($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)), [new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Int32.$type, $.$$.S.Int32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.UInt32.$type, $.$$.S.Int32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.Int64.$type, $.$$.S.Int32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$$.S.UInt64.$type, $.$$.S.Int32.$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Int32).$type, $.$typeNullable($.$$.S.Int32).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.UInt32).$type, $.$typeNullable($.$$.S.Int32).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.Int64).$type, $.$typeNullable($.$$.S.Int32).$type), new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type))().$ctor$3($.$typeNullable($.$$.S.UInt64).$type, $.$typeNullable($.$$.S.Int32).$type)], null, null));
                    //--TRIMMABLE-BOUNDARY-END(51541487731)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296847475)
            
            static $h = 1880179;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361618547),
    {
      "r": $.$typeArray($.$$.SR.MethodBase).$h,
      "p": [
        {
          "n": "possibleOperandTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 16
        }
      ],
      "n": "MakeUnarySignatures",
      "d": 1880179,
      "h": 34361618547,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361618547),
//--TRIMMABLE-BOUNDARY-START(30066651251),
    {
      "r": $.$typeArray($.$$.SR.MethodBase).$h,
      "p": [
        {
          "n": "possibleOperandTypes",
          "p": $.$$.SCG.IList$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Type)).$h
        }
      ],
      "n": "MakeBinarySignatures",
      "d": 1880179,
      "h": 30066651251,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066651251)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771683955),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "LogicalSignatures",
      "d": 1880179,
      "h": 25771683955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771683955),
//--TRIMMABLE-BOUNDARY-START(12886782067),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "ArithmeticSignatures",
      "d": 1880179,
      "h": 12886782067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886782067),
//--TRIMMABLE-BOUNDARY-START(47246520435),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "RelationalSignatures",
      "d": 1880179,
      "h": 47246520435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246520435),
//--TRIMMABLE-BOUNDARY-START(21476716659),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "EqualitySignatures",
      "d": 1880179,
      "h": 21476716659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476716659),
//--TRIMMABLE-BOUNDARY-START(8591814771),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "AddSignatures",
      "d": 1880179,
      "h": 8591814771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591814771),
//--TRIMMABLE-BOUNDARY-START(55836455027),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "SubtractSignatures",
      "d": 1880179,
      "h": 55836455027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836455027),
//--TRIMMABLE-BOUNDARY-START(38656585843),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "NegationSignatures",
      "d": 1880179,
      "h": 38656585843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656585843),
//--TRIMMABLE-BOUNDARY-START(42951553139),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "NotSignatures",
      "d": 1880179,
      "h": 42951553139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951553139),
//--TRIMMABLE-BOUNDARY-START(17181749363),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "BitwiseComplementSignatures",
      "d": 1880179,
      "h": 17181749363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181749363),
//--TRIMMABLE-BOUNDARY-START(51541487731),
    {
      "t": $.$typeArray($.$$.SR.MethodBase).$h,
      "n": "ShiftSignatures",
      "d": 1880179,
      "h": 51541487731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541487731)
  ],
  "h": 1880179
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.ParseSignatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}ParseSignatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1880179)
        
        

        //--TRIMMABLE-BOUNDARY-START(2601075)
        $asm.$cls(`$HnZw.DR.TypeUtils`, ($self) => class TypeUtils
        {
            //--TRIMMABLE-BOUNDARY-START(38657306739)
            static /*bool */ IsNullableType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657306739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR.TypeUtils.TryGetNonNullableType(type, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(38657306739)
            
            //--TRIMMABLE-BOUNDARY-START(34362339443)
            static /*bool */ IsDynamicType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362339443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.SD.IDynamicMetaObjectProvider.$type.IsAssignableFrom(type);
            }
            //--TRIMMABLE-BOUNDARY-END(34362339443)
            
            //--TRIMMABLE-BOUNDARY-START(64427110515)
            static /*bool */ TryGetNonNullableType(/*Type*/ type, /*out Type*/ nonNullableType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427110515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                nonNullableType.$v = $.$$.S.Nullable.GetUnderlyingType(type);
                return $.$$.S.Type.op_Inequality$1(nonNullableType.$v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64427110515)
            
            //--TRIMMABLE-BOUNDARY-START(17182470259)
            static /*Type */ GetNonNullableType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182470259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let underlyingType;
                return $.$HnZw.DR.TypeUtils.TryGetNonNullableType(type, $.$ref(() => underlyingType, ($v) => underlyingType = $v, $.$$.S.Type)) ? underlyingType : type;
            }
            //--TRIMMABLE-BOUNDARY-END(17182470259)
            
            //--TRIMMABLE-BOUNDARY-START(55837175923)
            static /*Type */ MakeNullable(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837175923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Nullable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ type ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55837175923)
            
            //--TRIMMABLE-BOUNDARY-START(25772404851)
            static /*string */ GetTypeName(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772404851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let baseType = $.$HnZw.DR.TypeUtils.GetNonNullableType(type);
                /*var*/ let s = baseType.Name;
                if ($.$$.S.Type.op_Inequality$1(type, baseType))
                {
                    s = $.$$.S.String.op_Addition(s, $.$box(/*?*/ 63, $.$$.S.Char));
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(25772404851)
            
            //--TRIMMABLE-BOUNDARY-START(42952274035)
            static /*bool */ IsNumericType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952274035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR.TypeUtils.GetNumericTypeKind(type) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(42952274035)
            
            //--TRIMMABLE-BOUNDARY-START(47247241331)
            static /*bool */ IsSignedIntegralType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247241331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR.TypeUtils.GetNumericTypeKind(type) === 2;
            }
            //--TRIMMABLE-BOUNDARY-END(47247241331)
            
            //--TRIMMABLE-BOUNDARY-START(51542208627)
            static /*bool */ IsUnsignedIntegralType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542208627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR.TypeUtils.GetNumericTypeKind(type) === 3;
            }
            //--TRIMMABLE-BOUNDARY-END(51542208627)
            
            //--TRIMMABLE-BOUNDARY-START(21477437555)
            static /*int */ GetNumericTypeKind(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477437555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                type = $.$HnZw.DR.TypeUtils.GetNonNullableType(type);
                if (type.IsEnum)
                {
                    return 0;
                }
                let $switch1 = $.$$.S.Type.GetTypeCode(type);
                switch($switch1)
                {
                    case 4/*TypeCode.Char*/:
                    case 13/*TypeCode.Single*/:
                    case 14/*TypeCode.Double*/:
                    case 15/*TypeCode.Decimal*/:
                    return 1;
                    case 5/*TypeCode.SByte*/:
                    case 7/*TypeCode.Int16*/:
                    case 9/*TypeCode.Int32*/:
                    case 11/*TypeCode.Int64*/:
                    return 2;
                    case 6/*TypeCode.Byte*/:
                    case 8/*TypeCode.UInt16*/:
                    case 10/*TypeCode.UInt32*/:
                    case 12/*TypeCode.UInt64*/:
                    return 3;
                    default:
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477437555)
            
            //--TRIMMABLE-BOUNDARY-START(30067372147)
            static /*bool */ IsCompatibleWith(/*Type*/ source, /*Type*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067372147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(source, target))
                {
                    return true;
                }
                if (target.IsGenericParameter)
                {
                    return true;
                }
                if (!target.IsValueType)
                {
                    return target.IsAssignableFrom(source);
                }
                /*var*/ let st = $.$HnZw.DR.TypeUtils.GetNonNullableType(source);
                /*var*/ let tt = $.$HnZw.DR.TypeUtils.GetNonNullableType(target);
                if ($.$$.S.Type.op_Inequality$1(st, source) && $.$$.S.Type.op_Equality$1(tt, target))
                {
                    return false;
                }
                /*var*/ let sc = st.IsEnum ? 1/*TypeCode.Object*/ : $.$$.S.Type.GetTypeCode(st);
                /*var*/ let tc = tt.IsEnum ? 1/*TypeCode.Object*/ : $.$$.S.Type.GetTypeCode(tt);
                switch(sc)
                {
                    case 5/*TypeCode.SByte*/:
                    switch(tc)
                    {
                        case 5/*TypeCode.SByte*/:
                        case 7/*TypeCode.Int16*/:
                        case 9/*TypeCode.Int32*/:
                        case 11/*TypeCode.Int64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 6/*TypeCode.Byte*/:
                    switch(tc)
                    {
                        case 6/*TypeCode.Byte*/:
                        case 7/*TypeCode.Int16*/:
                        case 8/*TypeCode.UInt16*/:
                        case 9/*TypeCode.Int32*/:
                        case 10/*TypeCode.UInt32*/:
                        case 11/*TypeCode.Int64*/:
                        case 12/*TypeCode.UInt64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 7/*TypeCode.Int16*/:
                    switch(tc)
                    {
                        case 7/*TypeCode.Int16*/:
                        case 9/*TypeCode.Int32*/:
                        case 11/*TypeCode.Int64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 8/*TypeCode.UInt16*/:
                    switch(tc)
                    {
                        case 8/*TypeCode.UInt16*/:
                        case 9/*TypeCode.Int32*/:
                        case 10/*TypeCode.UInt32*/:
                        case 11/*TypeCode.Int64*/:
                        case 12/*TypeCode.UInt64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 9/*TypeCode.Int32*/:
                    switch(tc)
                    {
                        case 9/*TypeCode.Int32*/:
                        case 11/*TypeCode.Int64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 10/*TypeCode.UInt32*/:
                    switch(tc)
                    {
                        case 10/*TypeCode.UInt32*/:
                        case 11/*TypeCode.Int64*/:
                        case 12/*TypeCode.UInt64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 11/*TypeCode.Int64*/:
                    switch(tc)
                    {
                        case 11/*TypeCode.Int64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 12/*TypeCode.UInt64*/:
                    switch(tc)
                    {
                        case 12/*TypeCode.UInt64*/:
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        case 15/*TypeCode.Decimal*/:
                        return true;
                    }
                    break;
                    case 13/*TypeCode.Single*/:
                    switch(tc)
                    {
                        case 13/*TypeCode.Single*/:
                        case 14/*TypeCode.Double*/:
                        return true;
                    }
                    break;
                    default:
                    if ($.$$.S.Type.op_Equality$1(st, tt))
                    {
                        return true;
                    }
                    break;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30067372147)
            
            //--TRIMMABLE-BOUNDARY-START(4297568371)
            static /*int */ CompareConversions(/*Type*/ s, /*Type*/ t1, /*Type*/ t2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297568371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(t1, t2))
                {
                    return 0;
                }
                if ($.$$.S.Type.op_Equality$1(s, t1))
                {
                    return 1;
                }
                if ($.$$.S.Type.op_Equality$1(s, t2))
                {
                    return -1;
                }
                /*var*/ let assignableT1 = t1.IsAssignableFrom(s);
                /*var*/ let assignableT2 = t2.IsAssignableFrom(s);
                if (assignableT1 && !assignableT2)
                {
                    return 1;
                }
                if (assignableT2 && !assignableT1)
                {
                    return -1;
                }
                /*var*/ let compatibleT1T2 = $.$HnZw.DR.TypeUtils.IsCompatibleWith(t1, t2);
                /*var*/ let compatibleT2T1 = $.$HnZw.DR.TypeUtils.IsCompatibleWith(t2, t1);
                if (compatibleT1T2 && !compatibleT2T1)
                {
                    return 1;
                }
                if (compatibleT2T1 && !compatibleT1T2)
                {
                    return -1;
                }
                if ($.$HnZw.DR.TypeUtils.IsSignedIntegralType(t1) && $.$HnZw.DR.TypeUtils.IsUnsignedIntegralType(t2))
                {
                    return 1;
                }
                if ($.$HnZw.DR.TypeUtils.IsSignedIntegralType(t2) && $.$HnZw.DR.TypeUtils.IsUnsignedIntegralType(t1))
                {
                    return -1;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(4297568371)
            
            //--TRIMMABLE-BOUNDARY-START(60132143219)
            static /*Type */ RemoveArrayType(/*Type*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132143219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(t, null) || t.IsArray)
                {
                    return null;
                }
                return t;
            }
            //--TRIMMABLE-BOUNDARY-END(60132143219)
            
            //--TRIMMABLE-BOUNDARY-START(8592535667)
            static /*Type */ FindAssignableGenericType(/*Type*/ givenType, /*Type*/ constructedGenericType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592535667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let genericTypeDefinition = constructedGenericType.GetGenericTypeDefinition();
                /*var*/ let interfaceTypes = givenType.GetInterfaces();
                let $i1 = 0;
                let $arr1 = interfaceTypes;
                while ($i1 < $arr1.length)
                {
                    let it = $arr1[$i1++];
                    if (it.IsGenericType && $.$$.S.Type.op_Equality$1(it.GetGenericTypeDefinition(), genericTypeDefinition))
                    {
                        return it;
                    }
                }
                if (givenType.IsGenericType && $.$$.S.Type.op_Equality$1(givenType.GetGenericTypeDefinition(), genericTypeDefinition))
                {
                    /*var*/ let givenTypeGenericsArgs = givenType.GenericTypeArguments;
                    /*var*/ let constructedGenericsArgs = constructedGenericType.GenericTypeArguments;
                    if ($.$sl.SL.Enumerable.Any($.$$.S.Boolean, $.$sl.SL.Enumerable.Zip($.$$.S.Type, $.$$.S.Type, $.$$.S.Boolean, givenTypeGenericsArgs, constructedGenericsArgs, new ($.$$.S.Func$$$$($.$$.S.Type, $.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*g*/ g, /*c*/ c) =>
                    {
                        return $.$HnZw.DR.TypeUtils.IsCompatibleWith(g, c);
                    }, _4e99497c_bc43_4eb5_b6ab_e8a80cff232a ??= {"r":262145,"p":[{"n":"g","p":188022785},{"n":"c","p":188022785}],"n":"","d":2601075,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.Boolean, $.$$.S.Boolean))().$ctor(this,  (/*compatible*/ compatible) =>
                    {
                        return !compatible;
                    }, _8100b783_df50_4cbc_bd2b_fa67425a2e9d ??= {"r":262145,"p":[{"n":"compatible","p":262145}],"n":"","d":2601075,"h":0,"f":17825794})))
                    {
                        return null;
                    }
                    return givenType;
                }
                /*var*/ let baseType = givenType.BaseType;
                if ($.$$.S.Type.op_Equality$1(baseType, null))
                {
                    return null;
                }
                return $.$HnZw.DR.TypeUtils.FindAssignableGenericType(baseType, genericTypeDefinition);
            }
            //--TRIMMABLE-BOUNDARY-END(8592535667)
            
            //--TRIMMABLE-BOUNDARY-START(12887502963)
            static /*Type */ GetConcreteTypeForGenericMethod(/*Type*/ type, /*List<Expression>*/ promotedArgs, /*MethodData*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887502963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsGenericType)
                {
                    /*var*/ let genericArguments = type.GetGenericArguments();
                    /*var*/ let concreteTypeParameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [genericArguments.length], null);
                    for(/*var*/ let i = 0; i < genericArguments.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(concreteTypeParameters, $.$HnZw.DR.TypeUtils.GetConcreteTypeForGenericMethod($.$$.System.Array.$ReadT1.call(genericArguments, i), promotedArgs, method), i);
                    }
                    return type.GetGenericTypeDefinition().MakeGenericType(concreteTypeParameters);
                }
                else if (type.ContainsGenericParameters$1)
                {
                    for(/*var*/ let i = 0; i < promotedArgs.Count; i++)
                    {
                        if ($.$$.S.Type.op_Equality$1(method.Parameters.SCG$IList$$$get_Item(i).ParameterType, type))
                        {
                            return promotedArgs.get_Item(i).Type;
                        }
                    }
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(12887502963)
            
            static $h = 2601075;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657306739),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "IsNullableType",
      "d": 2601075,
      "h": 38657306739,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657306739),
//--TRIMMABLE-BOUNDARY-START(34362339443),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "IsDynamicType",
      "d": 2601075,
      "h": 34362339443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362339443),
//--TRIMMABLE-BOUNDARY-START(64427110515),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "nonNullableType",
          "p": 188022785,
          "f": 2
        }
      ],
      "n": "TryGetNonNullableType",
      "d": 2601075,
      "h": 64427110515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64427110515),
//--TRIMMABLE-BOUNDARY-START(17182470259),
    {
      "r": 188022785,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "GetNonNullableType",
      "d": 2601075,
      "h": 17182470259,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17182470259),
//--TRIMMABLE-BOUNDARY-START(55837175923),
    {
      "r": 188022785,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "MakeNullable",
      "d": 2601075,
      "h": 55837175923,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55837175923),
//--TRIMMABLE-BOUNDARY-START(25772404851),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "GetTypeName",
      "d": 2601075,
      "h": 25772404851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772404851),
//--TRIMMABLE-BOUNDARY-START(42952274035),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "IsNumericType",
      "d": 2601075,
      "h": 42952274035,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42952274035),
//--TRIMMABLE-BOUNDARY-START(47247241331),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "IsSignedIntegralType",
      "d": 2601075,
      "h": 47247241331,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47247241331),
//--TRIMMABLE-BOUNDARY-START(51542208627),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "IsUnsignedIntegralType",
      "d": 2601075,
      "h": 51542208627,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51542208627),
//--TRIMMABLE-BOUNDARY-START(21477437555),
    {
      "r": 655361,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "GetNumericTypeKind",
      "d": 2601075,
      "h": 21477437555,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21477437555),
//--TRIMMABLE-BOUNDARY-START(30067372147),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": 188022785
        },
        {
          "n": "target",
          "p": 188022785
        }
      ],
      "n": "IsCompatibleWith",
      "d": 2601075,
      "h": 30067372147,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067372147),
//--TRIMMABLE-BOUNDARY-START(4297568371),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 188022785
        },
        {
          "n": "t1",
          "p": 188022785
        },
        {
          "n": "t2",
          "p": 188022785
        }
      ],
      "n": "CompareConversions",
      "d": 2601075,
      "h": 4297568371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297568371),
//--TRIMMABLE-BOUNDARY-START(60132143219),
    {
      "r": 188022785,
      "p": [
        {
          "n": "t",
          "p": 188022785
        }
      ],
      "n": "RemoveArrayType",
      "d": 2601075,
      "h": 60132143219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60132143219),
//--TRIMMABLE-BOUNDARY-START(8592535667),
    {
      "r": 188022785,
      "p": [
        {
          "n": "givenType",
          "p": 188022785
        },
        {
          "n": "constructedGenericType",
          "p": 188022785
        }
      ],
      "n": "FindAssignableGenericType",
      "d": 2601075,
      "h": 8592535667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592535667),
//--TRIMMABLE-BOUNDARY-START(12887502963),
    {
      "r": 188022785,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "promotedArgs",
          "p": $.$$.SCG.List$$($.$sle.SLE.Expression).$h
        },
        {
          "n": "method",
          "p": 2273395
        }
      ],
      "n": "GetConcreteTypeForGenericMethod",
      "d": 2601075,
      "h": 12887502963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887502963)
  ],
  "h": 2601075
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.TypeUtils`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}TypeUtils`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2601075)
        
        

        //--TRIMMABLE-BOUNDARY-START(3321971)
        $asm.$cls(`$HnZw.DR$2.ErrorMessages`, ($self) => class ErrorMessages extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(828932010099)
            /*System.Resources.ResourceManager*/ static resourceMan = null;
            //--TRIMMABLE-BOUNDARY-END(828932010099)
            
            //--TRIMMABLE-BOUNDARY-START(824637042803)
            /*System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(824637042803)
            
            //--TRIMMABLE-BOUNDARY-START(4298289267)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298289267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298289267)
            
            //--TRIMMABLE-BOUNDARY-START(833226977395)
            static /*System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627068547187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.Equals(null, $.$HnZw.DR$2.ErrorMessages.resourceMan))
                {
                    /*System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("DynamicExpresso.Resources.ErrorMessages", $.$HnZw.DR$2.ErrorMessages.$type.Assembly);
                    $.$HnZw.DR$2.ErrorMessages.resourceMan = temp;
                }
                return $.$HnZw.DR$2.ErrorMessages.resourceMan;
            }
            //--TRIMMABLE-BOUNDARY-END(833226977395)
            
            //--TRIMMABLE-BOUNDARY-START(90197635187)
            static /*System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240967283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.resourceCulture;
            }
            static /*System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841816911987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HnZw.DR$2.ErrorMessages.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90197635187)
            
            //--TRIMMABLE-BOUNDARY-START(21478158451)
            static /*string */ get AmbiguousIndexerInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171802013811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousIndexerInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(21478158451)
            
            //--TRIMMABLE-BOUNDARY-START(25773125747)
            static /*string */ get AmbiguousMethodInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391948403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousMethodInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(25773125747)
            
            //--TRIMMABLE-BOUNDARY-START(34363060339)
            static /*string */ get ArgsIncompatibleWithDelegate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571817587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ArgsIncompatibleWithDelegate", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(34363060339)
            
            //--TRIMMABLE-BOUNDARY-START(38658027635)
            static /*string */ get ArgsIncompatibleWithLambda()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161752179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ArgsIncompatibleWithLambda", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(38658027635)
            
            //--TRIMMABLE-BOUNDARY-START(51542929523)
            static /*string */ get BothTypesConvertToOther()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931555955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("BothTypesConvertToOther", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(51542929523)
            
            //--TRIMMABLE-BOUNDARY-START(55837896819)
            static /*string */ get CannotConvertValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240521490547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CannotConvertValue", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(55837896819)
            
            //--TRIMMABLE-BOUNDARY-START(60132864115)
            static /*string */ get CloseBracketOrCommaExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111425139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CloseBracketOrCommaExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(60132864115)
            
            //--TRIMMABLE-BOUNDARY-START(68722798707)
            static /*string */ get CloseParenOrCommaExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291294323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CloseParenOrCommaExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(68722798707)
            
            //--TRIMMABLE-BOUNDARY-START(73017766003)
            static /*string */ get CloseParenOrOperatorExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881228915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CloseParenOrOperatorExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(73017766003)
            
            //--TRIMMABLE-BOUNDARY-START(85902667891)
            static /*string */ get ColonExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300651032691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ColonExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(85902667891)
            
            //--TRIMMABLE-BOUNDARY-START(94492602483)
            static /*string */ get DigitExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830901875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("DigitExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(94492602483)
            
            //--TRIMMABLE-BOUNDARY-START(98787569779)
            static /*string */ get DotOrOpenParenExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420836467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("DotOrOpenParenExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(98787569779)
            
            //--TRIMMABLE-BOUNDARY-START(115967438963)
            static /*string */ get ExpressionExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780574835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ExpressionExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(115967438963)
            
            //--TRIMMABLE-BOUNDARY-START(120262406259)
            static /*string */ get ExpressionMustBeWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370509427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ExpressionMustBeWritable", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(120262406259)
            
            //--TRIMMABLE-BOUNDARY-START(124557373555)
            static /*string */ get FirstExprMustBeBool()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377960444019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("FirstExprMustBeBool", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(124557373555)
            
            //--TRIMMABLE-BOUNDARY-START(128852340851)
            static /*string */ get Format()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386550378611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("Format", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(128852340851)
            
            //--TRIMMABLE-BOUNDARY-START(717262860403)
            static /*string */ get IdentifierExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320182387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("IdentifierExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(717262860403)
            
            //--TRIMMABLE-BOUNDARY-START(721557827699)
            static /*string */ get IncompatibleOperand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910116979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("IncompatibleOperand", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(721557827699)
            
            //--TRIMMABLE-BOUNDARY-START(725852794995)
            static /*string */ get IncompatibleOperands()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429500051571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("IncompatibleOperands", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(725852794995)
            
            //--TRIMMABLE-BOUNDARY-START(730147762291)
            static /*string */ get IncorrectNumberOfIndexes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438089986163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("IncorrectNumberOfIndexes", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(730147762291)
            
            //--TRIMMABLE-BOUNDARY-START(734442729587)
            static /*string */ get InvalidCharacter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679920755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidCharacter", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(734442729587)
            
            //--TRIMMABLE-BOUNDARY-START(738737696883)
            static /*string */ get InvalidCharacterLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269855347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidCharacterLiteral", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(738737696883)
            
            //--TRIMMABLE-BOUNDARY-START(743032664179)
            static /*string */ get InvalidEscapeSequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859789939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidEscapeSequence", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(743032664179)
            
            //--TRIMMABLE-BOUNDARY-START(747327631475)
            static /*string */ get InvalidIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449724531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidIndex", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(747327631475)
            
            //--TRIMMABLE-BOUNDARY-START(755917566067)
            static /*string */ get InvalidIntegerLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489629593715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidIntegerLiteral", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(755917566067)
            
            //--TRIMMABLE-BOUNDARY-START(760212533363)
            static /*string */ get InvalidMethodCall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498219528307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidMethodCall", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(760212533363)
            
            //--TRIMMABLE-BOUNDARY-START(773097435251)
            static /*string */ get InvalidRealLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523989332083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidRealLiteral", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(773097435251)
            
            //--TRIMMABLE-BOUNDARY-START(785982337139)
            static /*string */ get NeitherTypeConvertsToOther()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549759135859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("NeitherTypeConvertsToOther", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(785982337139)
            
            //--TRIMMABLE-BOUNDARY-START(794572271731)
            static /*string */ get NoApplicableConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566939005043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("NoApplicableConstructor", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(794572271731)
            
            //--TRIMMABLE-BOUNDARY-START(798867239027)
            static /*string */ get NoApplicableIndexer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575528939635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("NoApplicableIndexer", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(798867239027)
            
            //--TRIMMABLE-BOUNDARY-START(807457173619)
            static /*string */ get OpenParenExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592708808819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("OpenParenExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(807457173619)
            
            //--TRIMMABLE-BOUNDARY-START(846111879283)
            static /*string */ get SyntaxError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635658481779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("SyntaxError", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(846111879283)
            
            //--TRIMMABLE-BOUNDARY-START(850406846579)
            static /*string */ get TypeHasNoNullableForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644248416371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("TypeHasNoNullableForm", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(850406846579)
            
            //--TRIMMABLE-BOUNDARY-START(854701813875)
            static /*string */ get TypeIdentifierExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652838350963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("TypeIdentifierExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(854701813875)
            
            //--TRIMMABLE-BOUNDARY-START(858996781171)
            static /*string */ get TypeofRequiresAType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661428285555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("TypeofRequiresAType", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(858996781171)
            
            //--TRIMMABLE-BOUNDARY-START(863291748467)
            static /*string */ get TypeofRequiresOneArg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670018220147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("TypeofRequiresOneArg", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(863291748467)
            
            //--TRIMMABLE-BOUNDARY-START(876176650355)
            static /*string */ get UnknownPropertyOrField()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695788023923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("UnknownPropertyOrField", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(876176650355)
            
            //--TRIMMABLE-BOUNDARY-START(884766584947)
            static /*string */ get UnterminatedStringLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712967893107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("UnterminatedStringLiteral", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(884766584947)
            
            //--TRIMMABLE-BOUNDARY-START(768802467955)
            static /*string */ get InvalidOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515399397491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidOperation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(768802467955)
            
            //--TRIMMABLE-BOUNDARY-START(8593256563)
            static /*string */ get AmbiguousBinaryOperatorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032210035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousBinaryOperatorInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(8593256563)
            
            //--TRIMMABLE-BOUNDARY-START(30068093043)
            static /*string */ get AmbiguousUnaryOperatorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981882995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousUnaryOperatorInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(30068093043)
            
            //--TRIMMABLE-BOUNDARY-START(17183191155)
            static /*string */ get AmbiguousDelegateInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212079219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousDelegateInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(17183191155)
            
            //--TRIMMABLE-BOUNDARY-START(64427831411)
            static /*string */ get CloseCurlyBracketExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257701359731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CloseCurlyBracketExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(64427831411)
            
            //--TRIMMABLE-BOUNDARY-START(803162206323)
            static /*string */ get OpenCurlyBracketExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584118874227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("OpenCurlyBracketExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(803162206323)
            
            //--TRIMMABLE-BOUNDARY-START(111672471667)
            static /*string */ get EqualExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190640243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("EqualExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(111672471667)
            
            //--TRIMMABLE-BOUNDARY-START(77312733299)
            static /*string */ get CloseTypeArgumentListExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283471163507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CloseTypeArgumentListExpected", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(77312733299)
            
            //--TRIMMABLE-BOUNDARY-START(777392402547)
            static /*string */ get MethodTypeParametersCantBeInferred()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532579266675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("MethodTypeParametersCantBeInferred", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(777392402547)
            
            //--TRIMMABLE-BOUNDARY-START(811752140915)
            static /*string */ get ParamsArrayTypeNotAnArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601298743411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ParamsArrayTypeNotAnArray", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(811752140915)
            
            //--TRIMMABLE-BOUNDARY-START(12888223859)
            static /*string */ get AmbiguousConstructorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622144627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AmbiguousConstructorInvocation", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(12888223859)
            
            //--TRIMMABLE-BOUNDARY-START(880471617651)
            static /*string */ get UnsupportedMultidimensionalArrays()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704377958515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("UnsupportedMultidimensionalArrays", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(880471617651)
            
            //--TRIMMABLE-BOUNDARY-START(751622598771)
            static /*string */ get InvalidInitializerMemberDeclarator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481039659123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidInitializerMemberDeclarator", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(751622598771)
            
            //--TRIMMABLE-BOUNDARY-START(81607700595)
            static /*string */ get CollectionInitializationNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292061098099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("CollectionInitializationNotSupported", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(81607700595)
            
            //--TRIMMABLE-BOUNDARY-START(867586715763)
            static /*string */ get UnableToFindAppropriateAddMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678608154739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("UnableToFindAppropriateAddMethod", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(867586715763)
            
            //--TRIMMABLE-BOUNDARY-START(820342075507)
            static /*string */ get ReservedWord()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618478612595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ReservedWord", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(820342075507)
            
            //--TRIMMABLE-BOUNDARY-START(42952994931)
            static /*string */ get ArgumentCountMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751686771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ArgumentCountMismatch", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(42952994931)
            
            //--TRIMMABLE-BOUNDARY-START(137442275443)
            static /*string */ get GenericTypeReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730247795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("GenericTypeReference", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(137442275443)
            
            //--TRIMMABLE-BOUNDARY-START(47247962227)
            static /*string */ get AssignmentOperatorNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341621363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("AssignmentOperatorNotAllowed", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(47247962227)
            
            //--TRIMMABLE-BOUNDARY-START(107377504371)
            static /*string */ get DuplicateParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343600705651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("DuplicateParameter", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(107377504371)
            
            //--TRIMMABLE-BOUNDARY-START(764507500659)
            static /*string */ get InvalidMethodCall2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506809462899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("InvalidMethodCall2", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(764507500659)
            
            //--TRIMMABLE-BOUNDARY-START(816047108211)
            static /*string */ get ReflectionNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609888678003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("ReflectionNotAllowed", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(816047108211)
            
            //--TRIMMABLE-BOUNDARY-START(871881683059)
            static /*string */ get UnknownIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687198089331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("UnknownIdentifier", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(871881683059)
            
            //--TRIMMABLE-BOUNDARY-START(103082537075)
            static /*string */ get DuplicateLocalParameterDeclaration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010771059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("DuplicateLocalParameterDeclaration", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(103082537075)
            
            //--TRIMMABLE-BOUNDARY-START(781687369843)
            static /*string */ get MultipleLambdaParametersWithoutBrace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541169201267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("MultipleLambdaParametersWithoutBrace", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(781687369843)
            
            //--TRIMMABLE-BOUNDARY-START(133147308147)
            static /*string */ get GenericArgumentCountMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140313203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("GenericArgumentCountMismatch", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(133147308147)
            
            //--TRIMMABLE-BOUNDARY-START(790277304435)
            static /*string */ get NextTokenAtEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558349070451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessages.ResourceManager.GetString("NextTokenAtEnd", $.$HnZw.DR$2.ErrorMessages.resourceCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(790277304435)
            
            //--TRIMMABLE-BOUNDARY-START(4298289267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298289267)
            
            static $h = 3321971;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(833226977395),
    {
      "p": 123076609,
      "g": {
        "r": 0,
        "d": 0,
        "h": 627068547187,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 3321971,
      "h": 833226977395,
      "f": 2097192,
      "a": [
        {
          "t": 64487425,
          "c": 12949389313,
          "a": [
            {
              "v": 2,
              "t": 64552961
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(833226977395),
//--TRIMMABLE-BOUNDARY-START(90197635187),
    {
      "p": 84213761,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309240967283,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 841816911987,
        "f": 83886120
      },
      "n": "Culture",
      "d": 3321971,
      "h": 90197635187,
      "f": 2097192,
      "a": [
        {
          "t": 64487425,
          "c": 12949389313,
          "a": [
            {
              "v": 2,
              "t": 64552961
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90197635187),
//--TRIMMABLE-BOUNDARY-START(21478158451),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171802013811,
        "f": 50331688
      },
      "n": "AmbiguousIndexerInvocation",
      "d": 3321971,
      "h": 21478158451,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(21478158451),
//--TRIMMABLE-BOUNDARY-START(25773125747),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180391948403,
        "f": 50331688
      },
      "n": "AmbiguousMethodInvocation",
      "d": 3321971,
      "h": 25773125747,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25773125747),
//--TRIMMABLE-BOUNDARY-START(34363060339),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197571817587,
        "f": 50331688
      },
      "n": "ArgsIncompatibleWithDelegate",
      "d": 3321971,
      "h": 34363060339,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34363060339),
//--TRIMMABLE-BOUNDARY-START(38658027635),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206161752179,
        "f": 50331688
      },
      "n": "ArgsIncompatibleWithLambda",
      "d": 3321971,
      "h": 38658027635,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(38658027635),
//--TRIMMABLE-BOUNDARY-START(51542929523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231931555955,
        "f": 50331688
      },
      "n": "BothTypesConvertToOther",
      "d": 3321971,
      "h": 51542929523,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(51542929523),
//--TRIMMABLE-BOUNDARY-START(55837896819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240521490547,
        "f": 50331688
      },
      "n": "CannotConvertValue",
      "d": 3321971,
      "h": 55837896819,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(55837896819),
//--TRIMMABLE-BOUNDARY-START(60132864115),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249111425139,
        "f": 50331688
      },
      "n": "CloseBracketOrCommaExpected",
      "d": 3321971,
      "h": 60132864115,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60132864115),
//--TRIMMABLE-BOUNDARY-START(68722798707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266291294323,
        "f": 50331688
      },
      "n": "CloseParenOrCommaExpected",
      "d": 3321971,
      "h": 68722798707,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(68722798707),
//--TRIMMABLE-BOUNDARY-START(73017766003),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274881228915,
        "f": 50331688
      },
      "n": "CloseParenOrOperatorExpected",
      "d": 3321971,
      "h": 73017766003,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(73017766003),
//--TRIMMABLE-BOUNDARY-START(85902667891),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300651032691,
        "f": 50331688
      },
      "n": "ColonExpected",
      "d": 3321971,
      "h": 85902667891,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(85902667891),
//--TRIMMABLE-BOUNDARY-START(94492602483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317830901875,
        "f": 50331688
      },
      "n": "DigitExpected",
      "d": 3321971,
      "h": 94492602483,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(94492602483),
//--TRIMMABLE-BOUNDARY-START(98787569779),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326420836467,
        "f": 50331688
      },
      "n": "DotOrOpenParenExpected",
      "d": 3321971,
      "h": 98787569779,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(98787569779),
//--TRIMMABLE-BOUNDARY-START(115967438963),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360780574835,
        "f": 50331688
      },
      "n": "ExpressionExpected",
      "d": 3321971,
      "h": 115967438963,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(115967438963),
//--TRIMMABLE-BOUNDARY-START(120262406259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369370509427,
        "f": 50331688
      },
      "n": "ExpressionMustBeWritable",
      "d": 3321971,
      "h": 120262406259,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(120262406259),
//--TRIMMABLE-BOUNDARY-START(124557373555),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377960444019,
        "f": 50331688
      },
      "n": "FirstExprMustBeBool",
      "d": 3321971,
      "h": 124557373555,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(124557373555),
//--TRIMMABLE-BOUNDARY-START(128852340851),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386550378611,
        "f": 50331688
      },
      "n": "Format",
      "d": 3321971,
      "h": 128852340851,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(128852340851),
//--TRIMMABLE-BOUNDARY-START(717262860403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412320182387,
        "f": 50331688
      },
      "n": "IdentifierExpected",
      "d": 3321971,
      "h": 717262860403,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(717262860403),
//--TRIMMABLE-BOUNDARY-START(721557827699),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420910116979,
        "f": 50331688
      },
      "n": "IncompatibleOperand",
      "d": 3321971,
      "h": 721557827699,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(721557827699),
//--TRIMMABLE-BOUNDARY-START(725852794995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429500051571,
        "f": 50331688
      },
      "n": "IncompatibleOperands",
      "d": 3321971,
      "h": 725852794995,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(725852794995),
//--TRIMMABLE-BOUNDARY-START(730147762291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 438089986163,
        "f": 50331688
      },
      "n": "IncorrectNumberOfIndexes",
      "d": 3321971,
      "h": 730147762291,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(730147762291),
//--TRIMMABLE-BOUNDARY-START(734442729587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 446679920755,
        "f": 50331688
      },
      "n": "InvalidCharacter",
      "d": 3321971,
      "h": 734442729587,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(734442729587),
//--TRIMMABLE-BOUNDARY-START(738737696883),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 455269855347,
        "f": 50331688
      },
      "n": "InvalidCharacterLiteral",
      "d": 3321971,
      "h": 738737696883,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(738737696883),
//--TRIMMABLE-BOUNDARY-START(743032664179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 463859789939,
        "f": 50331688
      },
      "n": "InvalidEscapeSequence",
      "d": 3321971,
      "h": 743032664179,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(743032664179),
//--TRIMMABLE-BOUNDARY-START(747327631475),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 472449724531,
        "f": 50331688
      },
      "n": "InvalidIndex",
      "d": 3321971,
      "h": 747327631475,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(747327631475),
//--TRIMMABLE-BOUNDARY-START(755917566067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 489629593715,
        "f": 50331688
      },
      "n": "InvalidIntegerLiteral",
      "d": 3321971,
      "h": 755917566067,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(755917566067),
//--TRIMMABLE-BOUNDARY-START(760212533363),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 498219528307,
        "f": 50331688
      },
      "n": "InvalidMethodCall",
      "d": 3321971,
      "h": 760212533363,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(760212533363),
//--TRIMMABLE-BOUNDARY-START(773097435251),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 523989332083,
        "f": 50331688
      },
      "n": "InvalidRealLiteral",
      "d": 3321971,
      "h": 773097435251,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(773097435251),
//--TRIMMABLE-BOUNDARY-START(785982337139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 549759135859,
        "f": 50331688
      },
      "n": "NeitherTypeConvertsToOther",
      "d": 3321971,
      "h": 785982337139,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(785982337139),
//--TRIMMABLE-BOUNDARY-START(794572271731),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 566939005043,
        "f": 50331688
      },
      "n": "NoApplicableConstructor",
      "d": 3321971,
      "h": 794572271731,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(794572271731),
//--TRIMMABLE-BOUNDARY-START(798867239027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 575528939635,
        "f": 50331688
      },
      "n": "NoApplicableIndexer",
      "d": 3321971,
      "h": 798867239027,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(798867239027),
//--TRIMMABLE-BOUNDARY-START(807457173619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 592708808819,
        "f": 50331688
      },
      "n": "OpenParenExpected",
      "d": 3321971,
      "h": 807457173619,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(807457173619),
//--TRIMMABLE-BOUNDARY-START(846111879283),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 635658481779,
        "f": 50331688
      },
      "n": "SyntaxError",
      "d": 3321971,
      "h": 846111879283,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(846111879283),
//--TRIMMABLE-BOUNDARY-START(850406846579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 644248416371,
        "f": 50331688
      },
      "n": "TypeHasNoNullableForm",
      "d": 3321971,
      "h": 850406846579,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(850406846579),
//--TRIMMABLE-BOUNDARY-START(854701813875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 652838350963,
        "f": 50331688
      },
      "n": "TypeIdentifierExpected",
      "d": 3321971,
      "h": 854701813875,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(854701813875),
//--TRIMMABLE-BOUNDARY-START(858996781171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 661428285555,
        "f": 50331688
      },
      "n": "TypeofRequiresAType",
      "d": 3321971,
      "h": 858996781171,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(858996781171),
//--TRIMMABLE-BOUNDARY-START(863291748467),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 670018220147,
        "f": 50331688
      },
      "n": "TypeofRequiresOneArg",
      "d": 3321971,
      "h": 863291748467,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(863291748467),
//--TRIMMABLE-BOUNDARY-START(876176650355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 695788023923,
        "f": 50331688
      },
      "n": "UnknownPropertyOrField",
      "d": 3321971,
      "h": 876176650355,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(876176650355),
//--TRIMMABLE-BOUNDARY-START(884766584947),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 712967893107,
        "f": 50331688
      },
      "n": "UnterminatedStringLiteral",
      "d": 3321971,
      "h": 884766584947,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(884766584947),
//--TRIMMABLE-BOUNDARY-START(768802467955),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 515399397491,
        "f": 50331688
      },
      "n": "InvalidOperation",
      "d": 3321971,
      "h": 768802467955,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(768802467955),
//--TRIMMABLE-BOUNDARY-START(8593256563),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146032210035,
        "f": 50331688
      },
      "n": "AmbiguousBinaryOperatorInvocation",
      "d": 3321971,
      "h": 8593256563,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8593256563),
//--TRIMMABLE-BOUNDARY-START(30068093043),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188981882995,
        "f": 50331688
      },
      "n": "AmbiguousUnaryOperatorInvocation",
      "d": 3321971,
      "h": 30068093043,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(30068093043),
//--TRIMMABLE-BOUNDARY-START(17183191155),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163212079219,
        "f": 50331688
      },
      "n": "AmbiguousDelegateInvocation",
      "d": 3321971,
      "h": 17183191155,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(17183191155),
//--TRIMMABLE-BOUNDARY-START(64427831411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257701359731,
        "f": 50331688
      },
      "n": "CloseCurlyBracketExpected",
      "d": 3321971,
      "h": 64427831411,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(64427831411),
//--TRIMMABLE-BOUNDARY-START(803162206323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 584118874227,
        "f": 50331688
      },
      "n": "OpenCurlyBracketExpected",
      "d": 3321971,
      "h": 803162206323,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(803162206323),
//--TRIMMABLE-BOUNDARY-START(111672471667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352190640243,
        "f": 50331688
      },
      "n": "EqualExpected",
      "d": 3321971,
      "h": 111672471667,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111672471667),
//--TRIMMABLE-BOUNDARY-START(77312733299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283471163507,
        "f": 50331688
      },
      "n": "CloseTypeArgumentListExpected",
      "d": 3321971,
      "h": 77312733299,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(77312733299),
//--TRIMMABLE-BOUNDARY-START(777392402547),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 532579266675,
        "f": 50331688
      },
      "n": "MethodTypeParametersCantBeInferred",
      "d": 3321971,
      "h": 777392402547,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(777392402547),
//--TRIMMABLE-BOUNDARY-START(811752140915),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 601298743411,
        "f": 50331688
      },
      "n": "ParamsArrayTypeNotAnArray",
      "d": 3321971,
      "h": 811752140915,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(811752140915),
//--TRIMMABLE-BOUNDARY-START(12888223859),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154622144627,
        "f": 50331688
      },
      "n": "AmbiguousConstructorInvocation",
      "d": 3321971,
      "h": 12888223859,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(12888223859),
//--TRIMMABLE-BOUNDARY-START(880471617651),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 704377958515,
        "f": 50331688
      },
      "n": "UnsupportedMultidimensionalArrays",
      "d": 3321971,
      "h": 880471617651,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(880471617651),
//--TRIMMABLE-BOUNDARY-START(751622598771),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 481039659123,
        "f": 50331688
      },
      "n": "InvalidInitializerMemberDeclarator",
      "d": 3321971,
      "h": 751622598771,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(751622598771),
//--TRIMMABLE-BOUNDARY-START(81607700595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292061098099,
        "f": 50331688
      },
      "n": "CollectionInitializationNotSupported",
      "d": 3321971,
      "h": 81607700595,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(81607700595),
//--TRIMMABLE-BOUNDARY-START(867586715763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 678608154739,
        "f": 50331688
      },
      "n": "UnableToFindAppropriateAddMethod",
      "d": 3321971,
      "h": 867586715763,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(867586715763),
//--TRIMMABLE-BOUNDARY-START(820342075507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 618478612595,
        "f": 50331688
      },
      "n": "ReservedWord",
      "d": 3321971,
      "h": 820342075507,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(820342075507),
//--TRIMMABLE-BOUNDARY-START(42952994931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214751686771,
        "f": 50331688
      },
      "n": "ArgumentCountMismatch",
      "d": 3321971,
      "h": 42952994931,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(42952994931),
//--TRIMMABLE-BOUNDARY-START(137442275443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403730247795,
        "f": 50331688
      },
      "n": "GenericTypeReference",
      "d": 3321971,
      "h": 137442275443,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(137442275443),
//--TRIMMABLE-BOUNDARY-START(47247962227),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223341621363,
        "f": 50331688
      },
      "n": "AssignmentOperatorNotAllowed",
      "d": 3321971,
      "h": 47247962227,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(47247962227),
//--TRIMMABLE-BOUNDARY-START(107377504371),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343600705651,
        "f": 50331688
      },
      "n": "DuplicateParameter",
      "d": 3321971,
      "h": 107377504371,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(107377504371),
//--TRIMMABLE-BOUNDARY-START(764507500659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 506809462899,
        "f": 50331688
      },
      "n": "InvalidMethodCall2",
      "d": 3321971,
      "h": 764507500659,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(764507500659),
//--TRIMMABLE-BOUNDARY-START(816047108211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 609888678003,
        "f": 50331688
      },
      "n": "ReflectionNotAllowed",
      "d": 3321971,
      "h": 816047108211,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(816047108211),
//--TRIMMABLE-BOUNDARY-START(871881683059),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 687198089331,
        "f": 50331688
      },
      "n": "UnknownIdentifier",
      "d": 3321971,
      "h": 871881683059,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(871881683059),
//--TRIMMABLE-BOUNDARY-START(103082537075),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335010771059,
        "f": 50331688
      },
      "n": "DuplicateLocalParameterDeclaration",
      "d": 3321971,
      "h": 103082537075,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(103082537075),
//--TRIMMABLE-BOUNDARY-START(781687369843),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 541169201267,
        "f": 50331688
      },
      "n": "MultipleLambdaParametersWithoutBrace",
      "d": 3321971,
      "h": 781687369843,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(781687369843),
//--TRIMMABLE-BOUNDARY-START(133147308147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395140313203,
        "f": 50331688
      },
      "n": "GenericArgumentCountMismatch",
      "d": 3321971,
      "h": 133147308147,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(133147308147),
//--TRIMMABLE-BOUNDARY-START(790277304435),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 558349070451,
        "f": 50331688
      },
      "n": "NextTokenAtEnd",
      "d": 3321971,
      "h": 790277304435,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(790277304435)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(828932010099),
    {
      "t": 123076609,
      "n": "resourceMan",
      "d": 3321971,
      "h": 828932010099,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(828932010099),
//--TRIMMABLE-BOUNDARY-START(824637042803),
    {
      "t": 84213761,
      "n": "resourceCulture",
      "d": 3321971,
      "h": 824637042803,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(824637042803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298289267),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3321971,
      "h": 4298289267,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298289267)
  ],
  "h": 3321971,
  "a": [
    {
      "t": 54525953,
      "c": 12939427841,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "4.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 4365680641
    },
    {
      "t": 126091265,
      "c": 4421058561
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resources.ErrorMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resources${separator}ErrorMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3321971)
        
        

        //--TRIMMABLE-BOUNDARY-START(2797683)
        $asm.$cls(`$HnZw.DR$1.LateBindingSecurity`, ($self) => class LateBindingSecurity
        {
            //--TRIMMABLE-BOUNDARY-START(4297764979)
            static /*void */ ValidateReflectionTarget(/*object*/ target, /*string*/ memberName, /*bool*/ reflectionEnabled, /*bool*/ allowNameMember)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297764979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!reflectionEnabled && ($.$is(target, $.$$.S.Type) || $.$is(target, $.$$.SR.MemberInfo)) && (!allowNameMember || $.$$.S.String.op_Inequality(memberName, "Name")))
                {
                    throw new $.$HnZw.DE.ReflectionNotAllowedException().$ctor$12();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297764979)
            
            static $h = 2797683;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297764979),
    {
      "r": 65537,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "reflectionEnabled",
          "p": 262145
        },
        {
          "n": "allowNameMember",
          "p": 262145
        }
      ],
      "n": "ValidateReflectionTarget",
      "d": 2797683,
      "h": 4297764979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297764979)
  ],
  "h": 2797683
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateBindingSecurity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateBindingSecurity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2797683)
        
        

        //--TRIMMABLE-BOUNDARY-START(3256435)
        $asm.$cls(`$HnZw.DR$1.MethodResolution`, ($self) => class MethodResolution
        {
            //--TRIMMABLE-BOUNDARY-START(17183125619)
            static /*IList<MethodData> */ FindBestMethod$1(/*IEnumerable<MethodBase>*/ methods, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183125619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$1.MethodResolution.FindBestMethod($.$sl.SL.Enumerable.Select$1($.$$.SR.MethodBase, $.$HnZw.DR.MethodData, methods, new ($.$$.S.Func$$$($.$$.SR.MethodBase, $.$HnZw.DR.MethodData))().$ctor($.$HnZw.DR.MethodData, $.$HnZw.DR.MethodData.Gen)), args);
            }
            //--TRIMMABLE-BOUNDARY-END(17183125619)
            
            //--TRIMMABLE-BOUNDARY-START(12888158323)
            static /*IList<MethodData> */ FindBestMethod(/*IEnumerable<MethodData>*/ methods, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888158323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let applicable = new ($.$$.SCG.List$$($.$HnZw.DR.MethodData))().$ctor$1();
                var $en2 = methods.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var method = $en2.SCG$IEnumerator$$$Current;
                    {
                        if ($.$HnZw.DR$1.MethodResolution.CheckIfMethodIsApplicableAndPrepareIt(method, args))
                        {
                            applicable.Add(method);
                        }
                    }
                }
                if (applicable.Count > 1)
                {
                    /*var*/ let bestCandidates = new ($.$$.SCG.List$$($.$HnZw.DR.MethodData))().$ctor$3(applicable.Count);
                    var $en3 = applicable.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var candidate = $en3.Current;
                        {
                            if ($.$HnZw.DR$1.MethodResolution.IsBetterThanAllCandidates(candidate, applicable, args))
                            {
                                bestCandidates.Add(candidate);
                            }
                        }
                    }
                    if (bestCandidates.Count > 0)
                    {
                        return bestCandidates;
                    }
                }
                return applicable;
            }
            //--TRIMMABLE-BOUNDARY-END(12888158323)
            
            //--TRIMMABLE-BOUNDARY-START(21478092915)
            static /*bool */ IsBetterThanAllCandidates(/*MethodData*/ candidate, /*IList<MethodData>*/ otherCandidates, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478092915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = otherCandidates.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var other = $en2.SCG$IEnumerator$$$Current;
                    {
                        if (candidate !== other && !$.$HnZw.DR$1.MethodResolution.MethodHasPriority(args, candidate, other))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21478092915)
            
            //--TRIMMABLE-BOUNDARY-START(4298223731)
            static /*bool */ CheckIfMethodIsApplicableAndPrepareIt(/*MethodData*/ method, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298223731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Count($.$$.SR.ParameterInfo, method.Parameters, new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$$.S.Boolean))().$ctor(this,  (/*y*/ y) =>
                {
                    return !y.HasDefaultValue && !$.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(y);
                }, _cc3ba6cc_9f30_4412_b21f_53a82cddff61 ??= {"r":262145,"p":[{"n":"y","p":118620161}],"n":"","d":3256435,"h":0,"f":17825794})) > args.length)
                {
                    return false;
                }
                /*var*/ let promotedArgs = new ($.$$.SCG.List$$($.$sle.SLE.Expression))().$ctor$3(method.Parameters.SCG$ICollection$$$Count);
                /*var*/ let declaredWorkingParameters = 0;
                /*Type*/ let paramsArrayTypeFound = null;
                /*List<Expression>*/ let paramsArrayPromotedArgument = null;
                let $i1 = 0;
                let $arr1 = args;
                while ($i1 < $arr1.length)
                {
                    let currentArgument = $arr1[$i1++];
                    /*Type*/ let parameterType;
                    if ($.$$.S.Type.op_Inequality$1(paramsArrayTypeFound, null))
                    {
                        parameterType = paramsArrayTypeFound;
                    }
                    else 
                    {
                        if (declaredWorkingParameters >= method.Parameters.SCG$ICollection$$$Count)
                        {
                            return false;
                        }
                        /*var*/ let parameterDeclaration = method.Parameters.SCG$IList$$$get_Item(declaredWorkingParameters);
                        if (parameterDeclaration.IsOut)
                        {
                            return false;
                        }
                        parameterType = parameterDeclaration.ParameterType;
                        if ($.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(parameterDeclaration))
                        {
                            paramsArrayTypeFound = parameterType;
                        }
                        declaredWorkingParameters++;
                    }
                    if (paramsArrayPromotedArgument === null && ($.$$.S.Type.op_Equality$1(paramsArrayTypeFound, null) || args.length === method.Parameters.SCG$ICollection$$$Count))
                    {
                        if (parameterType.IsGenericParameter)
                        {
                            if ($.$is(currentArgument, $.$HnZw.DP.InterpreterExpression))
                            {
                                return false;
                            }
                            promotedArgs.Add(currentArgument);
                            continue;
                        }
                        /*var*/ let promoted = $.$HnZw.DR$1.ExpressionUtils.PromoteExpression(currentArgument, parameterType);
                        if (promoted !== null)
                        {
                            promotedArgs.Add(promoted);
                            continue;
                        }
                    }
                    if ($.$$.S.Type.op_Inequality$1(paramsArrayTypeFound, null))
                    {
                        /*var*/ let paramsArrayElementType = paramsArrayTypeFound.GetElementType();
                        if (paramsArrayElementType.IsGenericParameter)
                        {
                            paramsArrayPromotedArgument = paramsArrayPromotedArgument ?? new ($.$$.SCG.List$$($.$sle.SLE.Expression))().$ctor$1();
                            paramsArrayPromotedArgument.Add(currentArgument);
                            continue;
                        }
                        /*var*/ let promoted = $.$HnZw.DR$1.ExpressionUtils.PromoteExpression(currentArgument, paramsArrayElementType);
                        if (promoted !== null)
                        {
                            paramsArrayPromotedArgument = paramsArrayPromotedArgument ?? new ($.$$.SCG.List$$($.$sle.SLE.Expression))().$ctor$1();
                            paramsArrayPromotedArgument.Add(promoted);
                            continue;
                        }
                    }
                    return false;
                }
                if (paramsArrayPromotedArgument !== null)
                {
                    method.HasParamsArray = true;
                    /*var*/ let paramsArrayElementType = paramsArrayTypeFound.GetElementType();
                    if ($.$$.S.Type.op_Equality$1(paramsArrayElementType, null))
                    {
                        throw $.$HnZw.DE.ParseException.Create(-1, $.$HnZw.DR$2.ErrorMessages.ParamsArrayTypeNotAnArray, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    if (paramsArrayElementType.IsGenericParameter)
                    {
                        /*var*/ let actualTypes = $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Distinct$1($.$$.S.Type, $.$sl.SL.Enumerable.Select$1($.$sle.SLE.Expression, $.$$.S.Type, paramsArrayPromotedArgument, new ($.$$.S.Func$$$($.$sle.SLE.Expression, $.$$.S.Type))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return _.Type;
                        }, _a5a475b3_6b80_45f1_8168_d573de117f46 ??= {"r":188022785,"p":[{"n":"_","p":8781861}],"n":"","d":3256435,"h":0,"f":17825794}))));
                        if (actualTypes.length !== 1)
                        {
                            throw $.$HnZw.DE.ParseException.Create(-1, $.$HnZw.DR$2.ErrorMessages.MethodTypeParametersCantBeInferred, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ method.MethodBase ], null, null));
                        }
                        paramsArrayElementType = $.$$.System.Array.$ReadT1.call(actualTypes, 0);
                    }
                    promotedArgs.Add($.$sle.SLE.Expression.NewArrayInit(paramsArrayElementType, paramsArrayPromotedArgument));
                }
                var $en2 = $.$sl.SL.Enumerable.Skip($.$$.SR.ParameterInfo, method.Parameters, promotedArgs.Count).SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var parameter = $en2.SCG$IEnumerator$$$Current;
                    {
                        if (parameter.HasDefaultValue)
                        {
                            /*var*/ let parameterType = $.$HnZw.DR.TypeUtils.GetConcreteTypeForGenericMethod(parameter.ParameterType, promotedArgs, method);
                            /*var*/ let defaultValue = parameter.DefaultValue;
                            if (defaultValue === null && parameterType.IsValueType)
                            {
                                defaultValue = $.$$.S.Activator.CreateInstance$9(parameterType);
                            }
                            promotedArgs.Add($.$sle.SLE.Expression.Constant(defaultValue, parameterType));
                        }
                        else if ($.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(parameter))
                        {
                            method.HasParamsArray = true;
                            promotedArgs.Add($.$sle.SLE.Expression.NewArrayInit$1(parameter.ParameterType.GetElementType(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [  ], null, null)));
                        }
                        else 
                        {
                            throw new $.$$.S.Exception().$ctor$4("No default value found!");
                        }
                    }
                }
                method.PromotedParameters = promotedArgs;
                if ($.$$.SR.MethodBase.op_Inequality$1(method.MethodBase, null) && method.MethodBase.IsGenericMethodDefinition && $.$is(method.MethodBase, $.$$.SR.MethodInfo))
                {
                    /*var*/ let genericMethod = $.$HnZw.DR$1.MethodResolution.MakeGenericMethod(method);
                    if ($.$$.SR.MethodInfo.op_Equality$2(genericMethod, null))
                    {
                        return false;
                    }
                    /*var*/ let actualMethodParameters = genericMethod.GetParameters();
                    for(/*var*/ let i = 0; i < method.PromotedParameters.SCG$ICollection$$$Count; i++)
                    {
                        let ie;
                        if ($.$is(method.PromotedParameters.SCG$IList$$$get_Item(i), $.$HnZw.DP.InterpreterExpression, { set $v(v){ ie = v; } }))
                        {
                            /*var*/ let actualParamInfo = $.$$.System.Array.$ReadT1.call(actualMethodParameters, i);
                            /*var*/ let lambdaExpr = ie.EvalAs(actualParamInfo.ParameterType);
                            if (lambdaExpr === null)
                            {
                                return false;
                            }
                            method.PromotedParameters.SCG$IList$$$set_Item(i, lambdaExpr);
                            genericMethod = $.$HnZw.DR$1.MethodResolution.MakeGenericMethod(method);
                        }
                    }
                    method.MethodBase = genericMethod;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4298223731)
            
            //--TRIMMABLE-BOUNDARY-START(30068027507)
            static /*bool */ MethodHasPriority(/*Expression[]*/ args, /*MethodData*/ method, /*MethodData*/ otherMethod)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068027507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let better = false;
                for(/*int*/ let i = 0, m = 0, o = 0; i < args.length; i++)
                {
                    /*var*/ let arg = $.$$.System.Array.$ReadT1.call(args, i);
                    /*var*/ let methodParam = method.Parameters.SCG$IList$$$get_Item(m);
                    /*var*/ let otherMethodParam = otherMethod.Parameters.SCG$IList$$$get_Item(o);
                    /*var*/ let methodParamType = $.$HnZw.DR.ReflectionExtensions.GetParameterType(methodParam);
                    /*var*/ let otherMethodParamType = $.$HnZw.DR.ReflectionExtensions.GetParameterType(otherMethodParam);
                    if (methodParamType.ContainsGenericParameters$1)
                    {
                        methodParamType = method.PromotedParameters.SCG$IList$$$get_Item(i).Type;
                    }
                    if (otherMethodParamType.ContainsGenericParameters$1)
                    {
                        otherMethodParamType = otherMethod.PromotedParameters.SCG$IList$$$get_Item(i).Type;
                    }
                    /*var*/ let c = $.$HnZw.DR.TypeUtils.CompareConversions(arg.Type, methodParamType, otherMethodParamType);
                    if (c < 0)
                    {
                        return false;
                    }
                    if (c > 0)
                    {
                        better = true;
                    }
                    if (!$.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(methodParam))
                    {
                        m++;
                    }
                    if (!$.$HnZw.DR.ReflectionExtensions.HasParamsArrayType(otherMethodParam))
                    {
                        o++;
                    }
                }
                if (better)
                {
                    return true;
                }
                if ($.$$.SR.MethodBase.op_Inequality$1(method.MethodBase, null) && $.$$.SR.MethodBase.op_Inequality$1(otherMethod.MethodBase, null) && !method.MethodBase.IsGenericMethod && otherMethod.MethodBase.IsGenericMethod)
                {
                    return true;
                }
                if (!method.HasParamsArray && otherMethod.HasParamsArray)
                {
                    return true;
                }
                if (method.HasParamsArray && otherMethod.HasParamsArray && method.Parameters.SCG$ICollection$$$Count > otherMethod.Parameters.SCG$ICollection$$$Count)
                {
                    return true;
                }
                let indexer;
                let otherIndexer;
                if ($.$is(method, $.$HnZw.DR.IndexerData, { set $v(v){ indexer = v; } }) && $.$is(otherMethod, $.$HnZw.DR.IndexerData, { set $v(v){ otherIndexer = v; } }))
                {
                    /*var*/ let declaringType = indexer.Indexer.DeclaringType;
                    /*var*/ let otherDeclaringType = otherIndexer.Indexer.DeclaringType;
                    /*var*/ let isOtherIndexerIsInParentType = otherDeclaringType.IsAssignableFrom(declaringType);
                    if (isOtherIndexerIsInParentType)
                    {
                        /*var*/ let isIndexerIsInDescendantType = !declaringType.IsAssignableFrom(otherDeclaringType);
                        return isIndexerIsInDescendantType;
                    }
                }
                return better;
            }
            //--TRIMMABLE-BOUNDARY-END(30068027507)
            
            //--TRIMMABLE-BOUNDARY-START(25773060211)
            static /*MethodInfo */ MakeGenericMethod(/*MethodData*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773060211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let methodInfo = $.$cast(method.MethodBase, $.$$.SR.MethodInfo);
                /*var*/ let actualGenericArgs = $.$HnZw.DR$1.MethodResolution.ExtractActualGenericArguments($.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Select$1($.$$.SR.ParameterInfo, $.$$.S.Type, method.Parameters, new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$$.S.Type))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.ParameterType;
                }, _ecf043b5_49da_4105_b48b_e45271dcad70 ??= {"r":188022785,"p":[{"n":"p","p":118620161}],"n":"","d":3256435,"h":0,"f":17825794}))), $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Select$1($.$sle.SLE.Expression, $.$$.S.Type, method.PromotedParameters, new ($.$$.S.Func$$$($.$sle.SLE.Expression, $.$$.S.Type))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Type;
                }, _66a72f3d_f32a_4271_b71a_212c31357d77 ??= {"r":188022785,"p":[{"n":"p","p":8781861}],"n":"","d":3256435,"h":0,"f":17825794}))));
                /*var*/ let genericArgs = $.$sl.SL.Enumerable.ToArray($.$$.S.Type, $.$sl.SL.Enumerable.Select$1($.$$.S.Type, $.$$.S.Type, methodInfo.GetGenericArguments(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Type))().$ctor(this,  (/*p*/ p) =>
                {
                    /*var*/ let typ;
                    return actualGenericArgs.TryGetValue(p.Name, $.$ref(() => typ, ($v) => typ = $v, $.$$.S.Type)) ? typ : $.$$.S.Object.$type;
                }, _48a93d7f_cd33_47eb_a9f0_d483544a5e68 ??= {"r":188022785,"p":[{"n":"p","p":188022785}],"n":"","d":3256435,"h":0,"f":17825794})));
                /*MethodInfo*/ let genericMethod = null;
                try
                {
                    genericMethod = methodInfo.MakeGenericMethod(genericArgs);
                }
                catch(e)
                {
                    return null;
                }
                return genericMethod;
            }
            //--TRIMMABLE-BOUNDARY-END(25773060211)
            
            //--TRIMMABLE-BOUNDARY-START(8593191027)
            static /*Dictionary<string, Type> */ ExtractActualGenericArguments(/*Type[]*/ methodGenericParameters, /*Type[]*/ methodActualParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593191027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let extractedGenericTypes = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Type))().$ctor$1();
                for(/*var*/ let i = 0; i < methodGenericParameters.length; i++)
                {
                    /*var*/ let requestedType = $.$$.System.Array.$ReadT1.call(methodGenericParameters, i);
                    /*var*/ let actualType = $.$$.System.Array.$ReadT1.call(methodActualParameters, i);
                    if (requestedType.IsGenericParameter)
                    {
                        if (!actualType.IsGenericParameter)
                        {
                            extractedGenericTypes.set_Item(requestedType.Name, actualType);
                        }
                    }
                    else if (requestedType.IsArray && actualType.IsArray)
                    {
                        /*var*/ let innerGenericTypes = $.$HnZw.DR$1.MethodResolution.ExtractActualGenericArguments($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [requestedType.GetElementType()], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [actualType.GetElementType()], null, null));
                        var $en4 = innerGenericTypes.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var innerGenericType = $en4.Current;
                            {
                                extractedGenericTypes.set_Item(innerGenericType.Key, innerGenericType.Value);
                            }
                        }
                    }
                    else if (requestedType.ContainsGenericParameters$1)
                    {
                        if (actualType.IsGenericParameter)
                        {
                            extractedGenericTypes.set_Item(actualType.Name, requestedType);
                        }
                        else 
                        {
                            /*var*/ let requestedInnerGenericArgs = requestedType.GetGenericArguments();
                            /*var*/ let actualInnerGenericArgs = actualType.GetGenericArguments();
                            if (requestedInnerGenericArgs.length !== actualInnerGenericArgs.length)
                            {
                                continue;
                            }
                            /*var*/ let innerGenericTypes = $.$HnZw.DR$1.MethodResolution.ExtractActualGenericArguments(requestedInnerGenericArgs, actualInnerGenericArgs);
                            var $en5 = innerGenericTypes.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var innerGenericType = $en5.Current;
                                {
                                    extractedGenericTypes.set_Item(innerGenericType.Key, innerGenericType.Value);
                                }
                            }
                        }
                    }
                }
                return extractedGenericTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(8593191027)
            
            static $h = 3256435;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183125619),
    {
      "r": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h,
      "p": [
        {
          "n": "methods",
          "p": $.$$.SCG.IEnumerable$$($.$$.SR.MethodBase).$h
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "FindBestMethod",
      "o": "@$1",
      "d": 3256435,
      "h": 17183125619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17183125619),
//--TRIMMABLE-BOUNDARY-START(12888158323),
    {
      "r": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h,
      "p": [
        {
          "n": "methods",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.DR.MethodData).$h
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "FindBestMethod",
      "d": 3256435,
      "h": 12888158323,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888158323),
//--TRIMMABLE-BOUNDARY-START(21478092915),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidate",
          "p": 2273395
        },
        {
          "n": "otherCandidates",
          "p": $.$$.SCG.IList$$($.$HnZw.DR.MethodData).$h
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "IsBetterThanAllCandidates",
      "d": 3256435,
      "h": 21478092915,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21478092915),
//--TRIMMABLE-BOUNDARY-START(4298223731),
    {
      "r": 262145,
      "p": [
        {
          "n": "method",
          "p": 2273395
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "CheckIfMethodIsApplicableAndPrepareIt",
      "d": 3256435,
      "h": 4298223731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298223731),
//--TRIMMABLE-BOUNDARY-START(30068027507),
    {
      "r": 262145,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        },
        {
          "n": "method",
          "p": 2273395
        },
        {
          "n": "otherMethod",
          "p": 2273395
        }
      ],
      "n": "MethodHasPriority",
      "d": 3256435,
      "h": 30068027507,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30068027507),
//--TRIMMABLE-BOUNDARY-START(25773060211),
    {
      "r": 117112833,
      "p": [
        {
          "n": "method",
          "p": 2273395
        }
      ],
      "n": "MakeGenericMethod",
      "d": 3256435,
      "h": 25773060211,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25773060211),
//--TRIMMABLE-BOUNDARY-START(8593191027),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Type).$h,
      "p": [
        {
          "n": "methodGenericParameters",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "methodActualParameters",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "ExtractActualGenericArguments",
      "d": 3256435,
      "h": 8593191027,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8593191027)
  ],
  "h": 3256435
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.MethodResolution`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}MethodResolution`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3256435)
        
        

        //--TRIMMABLE-BOUNDARY-START(1159283)
        $asm.$cls(`$HnZw.D.Lambda`, ($self) => class Lambda extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591093875)
            /*Expression*/ _expression = null;
            //--TRIMMABLE-BOUNDARY-END(8591093875)
            
            //--TRIMMABLE-BOUNDARY-START(12886061171)
            /*ParserArguments*/ _parserArguments = null;
            //--TRIMMABLE-BOUNDARY-END(12886061171)
            
            //--TRIMMABLE-BOUNDARY-START(4296126579)
            /*Lazy<Delegate>*/ _delegate = null;
            //--TRIMMABLE-BOUNDARY-END(4296126579)
            
            //--TRIMMABLE-BOUNDARY-START(17181028467)
            $ctor$1(/*Expression*/ expression, /*ParserArguments*/ parserArguments)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181028467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._expression = $.$firstOf(expression, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("expression") });
                    this._parserArguments = $.$firstOf(parserArguments, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("parserArguments") });
                    this._delegate = new ($.$$.S.Lazy$$($.$$.S.Delegate))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Delegate))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9(this._expression, $.$sl.SL.Enumerable.ToArray($.$sle.SLE.ParameterExpression, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression, this._parserArguments.UsedParameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Expression;
                        }, _36764e52_3fb3_49ae_b8b3_cb62b1368d7b ??= {"r":40566821,"p":[{"n":"p","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794})))).Compile();
                    }, _101927e5_255c_42f4_9203_d99fad3e6dd0 ??= {"r":66977793,"n":"","d":1159283,"h":0,"f":17825794}));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181028467)
            
            //--TRIMMABLE-BOUNDARY-START(38655864947)
            /*Expression */ get Expression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720636019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._expression;
            }
            //--TRIMMABLE-BOUNDARY-END(38655864947)
            
            //--TRIMMABLE-BOUNDARY-START(21475995763)
            /*bool */ get CaseInsensitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540766835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.Settings.CaseInsensitive;
            }
            //--TRIMMABLE-BOUNDARY-END(21475995763)
            
            //--TRIMMABLE-BOUNDARY-START(42950832243)
            /*string */ get ExpressionText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310570611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.ExpressionText;
            }
            //--TRIMMABLE-BOUNDARY-END(42950832243)
            
            //--TRIMMABLE-BOUNDARY-START(163209916531)
            /*Type */ get ReturnType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080374387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Expression.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(163209916531)
            
            //--TRIMMABLE-BOUNDARY-START(158914949235)
            /*IEnumerable<Parameter> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490439795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.UsedParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(158914949235)
            
            //--TRIMMABLE-BOUNDARY-START(176094818419)
            /*IEnumerable<Parameter> */ get UsedParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260243571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.UsedParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(176094818419)
            
            //--TRIMMABLE-BOUNDARY-START(34360897651)
            /*IEnumerable<Parameter> */ get DeclaredParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130701427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.DeclaredParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(34360897651)
            
            //--TRIMMABLE-BOUNDARY-START(171799851123)
            /*IEnumerable<ReferenceType> */ get Types()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670308979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.UsedTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(171799851123)
            
            //--TRIMMABLE-BOUNDARY-START(124555210867)
            /*IEnumerable<Identifier> */ get Identifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900505203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parserArguments.UsedIdentifiers;
            }
            //--TRIMMABLE-BOUNDARY-END(124555210867)
            
            //--TRIMMABLE-BOUNDARY-START(128850178163)
            /*object */ Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850178163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeWithUsedParameters($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [0], null));
            }
            //--TRIMMABLE-BOUNDARY-END(128850178163)
            
            //--TRIMMABLE-BOUNDARY-START(133145145459)
            /*object */ Invoke$1(/*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145145459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke$2(parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(133145145459)
            
            //--TRIMMABLE-BOUNDARY-START(137440112755)
            /*object */ Invoke$2(/*IEnumerable<Parameter>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440112755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let args = $.$sl.SL.Enumerable.ToArray($.$$.S.Object, ($.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.S.Object, $.$sl.SL.Enumerable.SelectMany($.$HnZw.D.Parameter, $.$HnZw.D.Parameter, $.$$.S.Object, this.UsedParameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter)))().$ctor(this,  (/*usedParameter*/ usedParameter) =>
                {
                    return parameters;
                }, _bd96a7a5_5aaf_46f7_8e15_16b8e14c65f2 ??= {"r":$.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,"p":[{"n":"usedParameter","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$HnZw.D.Parameter, $.$HnZw.D.Parameter, $.$$.S.Object))().$ctor(this,  (/*usedParameter*/ usedParameter, /*actualParameter*/ actualParameter) =>
                {
                    return { usedParameter : usedParameter, actualParameter : actualParameter };
                }, _689ef095_240f_4ca8_a1d3_d348f921015e ??= {"r":0,"p":[{"n":"usedParameter","p":1421427},{"n":"actualParameter","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$$.S.String.Equals$2.call(t.usedParameter.Name, t.actualParameter.Name, this._parserArguments.Settings.KeyComparison);
                }, _9580cd63_4e0a_4879_957a_798b817c1962 ??= {"r":262145,"p":[{"n":"t","p":0}],"n":"","d":1159283,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Object))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.actualParameter.Value;
                }, _e521c6d4_39ea_4909_93df_bdd6114bed38 ??= {"r":131073,"p":[{"n":"t","p":0}],"n":"","d":1159283,"h":0,"f":17825794}))));
                return this.InvokeWithUsedParameters(args);
            }
            //--TRIMMABLE-BOUNDARY-END(137440112755)
            
            //--TRIMMABLE-BOUNDARY-START(141735080051)
            /*object */ Invoke$3(/*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735080051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = new ($.$$.SCG.List$$($.$HnZw.D.Parameter))().$ctor$1();
                /*var*/ let declaredParameters = $.$sl.SL.Enumerable.ToArray($.$HnZw.D.Parameter, this.DeclaredParameters);
                if (args !== null)
                {
                    if (declaredParameters.length !== args.length)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$HnZw.DR$2.ErrorMessages.ArgumentCountMismatch);
                    }
                    for(/*var*/ let i = 0; i < args.length; i++)
                    {
                        /*var*/ let parameter = new $.$HnZw.D.Parameter().$ctor$3($.$$.System.Array.$ReadT1.call(declaredParameters, i).Name, $.$$.System.Array.$ReadT1.call(declaredParameters, i).Type, $.$$.System.Array.$ReadT1.call(args, i));
                        parameters.Add(parameter);
                    }
                }
                return this.Invoke$2(parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(141735080051)
            
            //--TRIMMABLE-BOUNDARY-START(146030047347)
            /*object */ InvokeWithUsedParameters(/*object[]*/ orderedArgs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030047347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return this._delegate.Value.DynamicInvoke(orderedArgs);
                }
                catch(exc)
                {
                    if (exc.InnerException !== null)
                    {
                        $.$$.SRE$1.ExceptionDispatchInfo.Capture(exc.InnerException).Throw();
                    }
                    throw exc;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030047347)
            
            //--TRIMMABLE-BOUNDARY-START(167504883827)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504883827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ExpressionText;
            }
            //--TRIMMABLE-BOUNDARY-END(167504883827)
            
            //--TRIMMABLE-BOUNDARY-START(25770963059)
            /*TDelegate */ Compile(TDelegate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770963059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lambdaExpression = this.LambdaExpression$1(TDelegate);
                return lambdaExpression.Compile$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770963059)
            
            //--TRIMMABLE-BOUNDARY-START(30065930355)
            /*TDelegate */ Compile$1(TDelegate, /*IEnumerable<Parameter>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065930355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lambdaExpression = $.$sle.SLE.Expression.Lambda$15(TDelegate, this._expression, $.$sl.SL.Enumerable.ToArray($.$sle.SLE.ParameterExpression, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression, parameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Expression;
                }, _a337dae8_63fd_40c6_b846_ba15f6bcc4ee ??= {"r":40566821,"p":[{"n":"p","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794}))));
                return lambdaExpression.Compile$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065930355)
            
            //--TRIMMABLE-BOUNDARY-START(154619981939)
            /*Expression<TDelegate> */ LambdaExpression$1(TDelegate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619981939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.SLE.Expression.Lambda$15(TDelegate, this._expression, $.$sl.SL.Enumerable.ToArray($.$sle.SLE.ParameterExpression, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression, this.DeclaredParameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Expression;
                }, _6f0ecabf_f578_490b_90b6_6dc2c11c0af0 ??= {"r":40566821,"p":[{"n":"p","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(154619981939)
            
            //--TRIMMABLE-BOUNDARY-START(150325014643)
            /*LambdaExpression */ LambdaExpression(/*Type*/ delegateType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325014643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameterExpressions = $.$sl.SL.Enumerable.ToArray($.$sle.SLE.ParameterExpression, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression, this.DeclaredParameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$sle.SLE.ParameterExpression))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Expression;
                }, _1d6e94bd_6aed_4b6c_bca0_287ac68f3bd7 ??= {"r":40566821,"p":[{"n":"p","p":1421427}],"n":"","d":1159283,"h":0,"f":17825794})));
                /*var*/ let types = delegateType.GetGenericArguments();
                if ($.$$.S.Type.op_Equality$1(delegateType.GetGenericTypeDefinition(), $.$HnZw.DR.ReflectionExtensions.GetFuncType(parameterExpressions.length)))
                {
                    $.$$.System.Array.$WriteT1.call(types, this._expression.Type, ((types.length - 1) | 0));
                }
                /*var*/ let genericType = delegateType.GetGenericTypeDefinition();
                /*var*/ let inferredDelegateType = genericType.MakeGenericType(types);
                return $.$sle.SLE.Expression.Lambda$3(inferredDelegateType, this._expression, parameterExpressions);
            }
            //--TRIMMABLE-BOUNDARY-END(150325014643)
            
            static $h = 1159283;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655864947),
    {
      "p": 8781861,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720636019,
        "f": 50331649
      },
      "n": "Expression",
      "d": 1159283,
      "h": 38655864947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655864947),
//--TRIMMABLE-BOUNDARY-START(21475995763),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540766835,
        "f": 50331649
      },
      "n": "CaseInsensitive",
      "d": 1159283,
      "h": 21475995763,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475995763),
//--TRIMMABLE-BOUNDARY-START(42950832243),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310570611,
        "f": 50331649
      },
      "n": "ExpressionText",
      "d": 1159283,
      "h": 42950832243,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950832243),
//--TRIMMABLE-BOUNDARY-START(163209916531),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080374387,
        "f": 50331649
      },
      "n": "ReturnType",
      "d": 1159283,
      "h": 163209916531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209916531),
//--TRIMMABLE-BOUNDARY-START(158914949235),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490439795,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1159283,
      "h": 158914949235,
      "f": 2097153,
      "a": [
        {
          "t": 104005633,
          "c": 30168776705,
          "a": [
            {
              "v": "Use UsedParameters or DeclaredParameters",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914949235),
//--TRIMMABLE-BOUNDARY-START(176094818419),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260243571,
        "f": 50331649
      },
      "n": "UsedParameters",
      "d": 1159283,
      "h": 176094818419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094818419),
//--TRIMMABLE-BOUNDARY-START(34360897651),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130701427,
        "f": 50331649
      },
      "n": "DeclaredParameters",
      "d": 1159283,
      "h": 34360897651,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360897651),
//--TRIMMABLE-BOUNDARY-START(171799851123),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670308979,
        "f": 50331649
      },
      "n": "Types",
      "d": 1159283,
      "h": 171799851123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799851123),
//--TRIMMABLE-BOUNDARY-START(124555210867),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900505203,
        "f": 50331649
      },
      "n": "Identifiers",
      "d": 1159283,
      "h": 124555210867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555210867)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850178163),
    {
      "r": 131073,
      "n": "Invoke",
      "d": 1159283,
      "h": 128850178163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850178163),
//--TRIMMABLE-BOUNDARY-START(133145145459),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 1159283,
      "h": 133145145459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145145459),
//--TRIMMABLE-BOUNDARY-START(137440112755),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h
        }
      ],
      "n": "Invoke",
      "o": "@$2",
      "d": 1159283,
      "h": 137440112755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440112755),
//--TRIMMABLE-BOUNDARY-START(141735080051),
    {
      "r": 131073,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "Invoke",
      "o": "@$3",
      "d": 1159283,
      "h": 141735080051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735080051),
//--TRIMMABLE-BOUNDARY-START(146030047347),
    {
      "r": 131073,
      "p": [
        {
          "n": "orderedArgs",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "InvokeWithUsedParameters",
      "d": 1159283,
      "h": 146030047347,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146030047347),
//--TRIMMABLE-BOUNDARY-START(167504883827),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1159283,
      "h": 167504883827,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504883827),
//--TRIMMABLE-BOUNDARY-START(25770963059),
    {
      "r": (TDelegate) => TDelegate.$h,
      "g": [
        "TDelegate"
      ],
      "n": "Compile",
      "d": 1159283,
      "h": 25770963059,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770963059),
//--TRIMMABLE-BOUNDARY-START(30065930355),
    {
      "r": (TDelegate) => TDelegate.$h,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Parameter).$h
        }
      ],
      "g": [
        "TDelegate"
      ],
      "n": "Compile",
      "o": "@$1",
      "d": 1159283,
      "h": 30065930355,
      "f": 16908289,
      "a": [
        {
          "t": 104005633,
          "c": 30168776705,
          "a": [
            {
              "v": "Use Compile\u003CTDelegate\u003E()",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065930355),
//--TRIMMABLE-BOUNDARY-START(154619981939),
    {
      "r": (TDelegate) => $.$sle.SLE.Expression$$(TDelegate).$h,
      "g": [
        "TDelegate"
      ],
      "n": "LambdaExpression",
      "o": "@$1",
      "d": 1159283,
      "h": 154619981939,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(154619981939),
//--TRIMMABLE-BOUNDARY-START(150325014643),
    {
      "r": 38797349,
      "p": [
        {
          "n": "delegateType",
          "p": 188022785
        }
      ],
      "n": "LambdaExpression",
      "d": 1159283,
      "h": 150325014643,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150325014643)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591093875),
    {
      "t": 8781861,
      "n": "_expression",
      "d": 1159283,
      "h": 8591093875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591093875),
//--TRIMMABLE-BOUNDARY-START(12886061171),
    {
      "t": 1552499,
      "n": "_parserArguments",
      "d": 1159283,
      "h": 12886061171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886061171),
//--TRIMMABLE-BOUNDARY-START(4296126579),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Delegate).$h,
      "n": "_delegate",
      "d": 1159283,
      "h": 4296126579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296126579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181028467),
    {
      "p": [
        {
          "n": "expression",
          "p": 8781861
        },
        {
          "n": "parserArguments",
          "p": 1552499
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1159283,
      "h": 17181028467,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181028467)
  ],
  "h": 1159283
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Lambda`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Lambda`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1159283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1028211)
        $asm.$cls(`$HnZw.D.Interpreter`, ($self) => class Interpreter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295995507)
            /*ParserSettings*/ _settings = null;
            //--TRIMMABLE-BOUNDARY-END(4295995507)
            
            //--TRIMMABLE-BOUNDARY-START(8590962803)
            $ctor$1()
            {
                this.$ctor$2(7/*InterpreterOptions.Default*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590962803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590962803)
            
            //--TRIMMABLE-BOUNDARY-START(12885930099)
            $ctor$2(/*InterpreterOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885930099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let caseInsensitive = ((options & (8/*InterpreterOptions.CaseInsensitive*/)) == (8/*InterpreterOptions.CaseInsensitive*/));
                    /*var*/ let lateBindObject = ((options & (16/*InterpreterOptions.LateBindObject*/)) == (16/*InterpreterOptions.LateBindObject*/));
                    this._settings = new $.$HnZw.DP.ParserSettings().$ctor$1(caseInsensitive, lateBindObject);
                    if ((options & 2/*InterpreterOptions.SystemKeywords*/) === 2/*InterpreterOptions.SystemKeywords*/)
                    {
                        this.SetIdentifiers($.$HnZw.D.LanguageConstants.Literals);
                    }
                    if ((options & 1/*InterpreterOptions.PrimitiveTypes*/) === 1/*InterpreterOptions.PrimitiveTypes*/)
                    {
                        this.Reference$1($.$HnZw.D.LanguageConstants.PrimitiveTypes);
                        this.Reference$1($.$HnZw.D.LanguageConstants.CSharpPrimitiveTypes);
                    }
                    if ((options & 4/*InterpreterOptions.CommonTypes*/) === 4/*InterpreterOptions.CommonTypes*/)
                    {
                        this.Reference$1($.$HnZw.D.LanguageConstants.CommonTypes);
                    }
                    if ((options & 32/*InterpreterOptions.LambdaExpressions*/) === 32/*InterpreterOptions.LambdaExpressions*/)
                    {
                        this._settings.LambdaExpressions = true;
                    }
                    this.Visitors.SCG$ISet$$$Add(new $.$HnZw.DV.DisableReflectionVisitor().$ctor$2());
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885930099)
            
            //--TRIMMABLE-BOUNDARY-START(17180897395)
            $ctor$3(/*ParserSettings*/ settings)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180897395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._settings = settings;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180897395)
            
            //--TRIMMABLE-BOUNDARY-START(25770831987)
            /*bool */ get CaseInsensitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015472243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._settings.CaseInsensitive;
            }
            //--TRIMMABLE-BOUNDARY-END(25770831987)
            
            //--TRIMMABLE-BOUNDARY-START(163209785459)
            /*IEnumerable<ReferenceType> */ get ReferencedTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195341427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToList($.$HnZw.D.ReferenceType, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.ReferenceType), $.$HnZw.D.ReferenceType, this._settings.KnownTypes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.ReferenceType), $.$HnZw.D.ReferenceType))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Value;
                }, _3d592cf7_62fb_4d4e_8ab3_739b9a6b06b1 ??= {"r":2076787,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.ReferenceType).$h}],"n":"","d":1028211,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(163209785459)
            
            //--TRIMMABLE-BOUNDARY-START(103080243315)
            /*IEnumerable<Identifier> */ get Identifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605406835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToList($.$HnZw.D.Identifier, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.Identifier), $.$HnZw.D.Identifier, this._settings.Identifiers, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.Identifier), $.$HnZw.D.Identifier))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Value;
                }, _cc17cd60_1da3_4e80_b2d3_a1ad8494e5a3 ??= {"r":897139,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$HnZw.D.Identifier).$h}],"n":"","d":1028211,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(103080243315)
            
            //--TRIMMABLE-BOUNDARY-START(21475864691)
            /*AssignmentOperators */ get AssignmentOperators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425537651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._settings.AssignmentOperators;
            }
            //--TRIMMABLE-BOUNDARY-END(21475864691)
            
            //--TRIMMABLE-BOUNDARY-START(167504752755)
            /*Interpreter */ SetDefaultNumberType(/*DefaultNumberType*/ defaultNumberType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504752755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._settings.DefaultNumberType = defaultNumberType;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(167504752755)
            
            //--TRIMMABLE-BOUNDARY-START(38655733875)
            /*Interpreter */ EnableAssignment(/*AssignmentOperators*/ assignmentOperators)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655733875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._settings.AssignmentOperators = assignmentOperators;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655733875)
            
            //--TRIMMABLE-BOUNDARY-START(219044360307)
            /*ISet<ExpressionVisitor> */ get Visitors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785276019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._settings.Visitors;
            }
            //--TRIMMABLE-BOUNDARY-END(219044360307)
            
            //--TRIMMABLE-BOUNDARY-START(42950701171)
            /*Interpreter */ EnableReflection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950701171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let visitor = $.$sl.SL.Enumerable.FirstOrDefault$1($.$sle.SLE.ExpressionVisitor, this.Visitors, new ($.$$.S.Func$$$($.$sle.SLE.ExpressionVisitor, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$is(p, $.$HnZw.DV.DisableReflectionVisitor);
                }, _abd454da_4fe2_45a7_a407_cbfef83faf87 ??= {"r":262145,"p":[{"n":"p","p":11337765}],"n":"","d":1028211,"h":0,"f":17825794}));
                if (visitor !== null)
                {
                    this.Visitors.SCG$ICollection$$$Remove(visitor);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950701171)
            
            //--TRIMMABLE-BOUNDARY-START(176094687347)
            /*Interpreter */ SetFunction(/*string*/ name, /*Delegate*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094687347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                /*var*/ let identifier;
                let fIdentifier;
                if (this._settings.Identifiers.SCG$IDictionary$$$$TryGetValue(name, $.$ref(() => identifier, ($v) => identifier = $v, $.$HnZw.D.Identifier)) && $.$is(identifier, $.$HnZw.D.FunctionIdentifier, { set $v(v){ fIdentifier = v; } }))
                {
                    fIdentifier.AddOverload(value);
                }
                else 
                {
                    this.SetIdentifier(new $.$HnZw.D.FunctionIdentifier().$ctor$2(name, value));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(176094687347)
            
            //--TRIMMABLE-BOUNDARY-START(193274556531)
            /*Interpreter */ SetVariable$1(/*string*/ name, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274556531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                return this.SetExpression(name, $.$sle.SLE.Expression.Constant$1(value));
            }
            //--TRIMMABLE-BOUNDARY-END(193274556531)
            
            //--TRIMMABLE-BOUNDARY-START(197569523827)
            /*Interpreter */ SetVariable$2(T, /*string*/ name, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569523827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetVariable(name, $.$box(value, T), T.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(197569523827)
            
            //--TRIMMABLE-BOUNDARY-START(188979589235)
            /*Interpreter */ SetVariable(/*string*/ name, /*object*/ value, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979589235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(type, null))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("type");
                }
                if ($.$$.S.String.IsNullOrWhiteSpace(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                return this.SetExpression(name, $.$sle.SLE.Expression.Constant(value, type));
            }
            //--TRIMMABLE-BOUNDARY-END(188979589235)
            
            //--TRIMMABLE-BOUNDARY-START(171799720051)
            /*Interpreter */ SetExpression(/*string*/ name, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799720051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetIdentifier(new $.$HnZw.D.Identifier().$ctor$1(name, expression));
            }
            //--TRIMMABLE-BOUNDARY-END(171799720051)
            
            //--TRIMMABLE-BOUNDARY-START(184684621939)
            /*Interpreter */ SetIdentifiers(/*IEnumerable<Identifier>*/ identifiers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684621939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = identifiers.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var i = $en2.SCG$IEnumerator$$$Current;
                    {
                        this.SetIdentifier(i);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(184684621939)
            
            //--TRIMMABLE-BOUNDARY-START(180389654643)
            /*Interpreter */ SetIdentifier(/*Identifier*/ identifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389654643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (identifier === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("identifier");
                }
                if ($.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1($.$HnZw.D.LanguageConstants.ReservedKeywords), identifier.Name))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.ReservedWord, identifier.Name));
                }
                this._settings.Identifiers.SCG$IDictionary$$$$set_Item(identifier.Name, identifier);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(180389654643)
            
            //--TRIMMABLE-BOUNDARY-START(206159458419)
            /*Interpreter */ UnsetFunction(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159458419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnsetIdentifier(name);
            }
            //--TRIMMABLE-BOUNDARY-END(206159458419)
            
            //--TRIMMABLE-BOUNDARY-START(214749393011)
            /*Interpreter */ UnsetVariable(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749393011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnsetIdentifier(name);
            }
            //--TRIMMABLE-BOUNDARY-END(214749393011)
            
            //--TRIMMABLE-BOUNDARY-START(201864491123)
            /*Interpreter */ UnsetExpression(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864491123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnsetIdentifier(name);
            }
            //--TRIMMABLE-BOUNDARY-END(201864491123)
            
            //--TRIMMABLE-BOUNDARY-START(210454425715)
            /*Interpreter */ UnsetIdentifier(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454425715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                this._settings.Identifiers.SCG$IDictionary$$$$Remove(name);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(210454425715)
            
            //--TRIMMABLE-BOUNDARY-START(158914818163)
            /*Interpreter */ Reference$3(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914818163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(type, null))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("type");
                }
                return this.Reference$2(type, type.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(158914818163)
            
            //--TRIMMABLE-BOUNDARY-START(150324883571)
            /*Interpreter */ Reference$1(/*IEnumerable<ReferenceType>*/ types)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324883571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (types === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("types");
                }
                var $en2 = types.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var t = $en2.SCG$IEnumerator$$$Current;
                    {
                        this.Reference(t);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(150324883571)
            
            //--TRIMMABLE-BOUNDARY-START(154619850867)
            /*Interpreter */ Reference$2(/*Type*/ type, /*string*/ typeName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619850867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reference(new $.$HnZw.D.ReferenceType().$ctor$1(typeName, type));
            }
            //--TRIMMABLE-BOUNDARY-END(154619850867)
            
            //--TRIMMABLE-BOUNDARY-START(146029916275)
            /*Interpreter */ Reference(/*ReferenceType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029916275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("type");
                }
                this._settings.KnownTypes.SCG$IDictionary$$$$set_Item(type.Name, type);
                this._settings.ExtensionMethods.UnionWith(type.ExtensionMethods);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(146029916275)
            
            //--TRIMMABLE-BOUNDARY-START(107375210611)
            /*Lambda */ Parse(/*string*/ expressionText, /*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375210611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parse$1(expressionText, $.$$.S.Void.$type, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(107375210611)
            
            //--TRIMMABLE-BOUNDARY-START(111670177907)
            /*Lambda */ Parse$1(/*string*/ expressionText, /*Type*/ expressionType, /*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670177907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseAsLambda(expressionText, expressionType, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(111670177907)
            
            //--TRIMMABLE-BOUNDARY-START(115965145203)
            /*TDelegate */ Parse$2(TDelegate, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965145203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseAsDelegate(TDelegate, expressionText, parametersNames);
            }
            //--TRIMMABLE-BOUNDARY-END(115965145203)
            
            //--TRIMMABLE-BOUNDARY-START(128850047091)
            /*TDelegate */ ParseAsDelegate(TDelegate, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850047091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lambda = this.ParseAs$1(TDelegate, expressionText, parametersNames);
                return lambda.Compile(TDelegate);
            }
            //--TRIMMABLE-BOUNDARY-END(128850047091)
            
            //--TRIMMABLE-BOUNDARY-START(137439981683)
            /*Expression<TDelegate> */ ParseAsExpression$1(TDelegate, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439981683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lambda = this.ParseAs$1(TDelegate, expressionText, parametersNames);
                return lambda.LambdaExpression$1(TDelegate);
            }
            //--TRIMMABLE-BOUNDARY-END(137439981683)
            
            //--TRIMMABLE-BOUNDARY-START(133145014387)
            /*LambdaExpression */ ParseAsExpression(/*Type*/ delegateType, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145014387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let delegateInfo = $.$HnZw.DR.ReflectionExtensions.GetDelegateInfo(delegateType, parametersNames);
                /*var*/ let returnType = delegateInfo.ReturnType;
                if ($.$$.S.Type.op_Equality$1(returnType, $.$$.S.Object.$type))
                {
                    returnType = $.$$.S.Void.$type;
                }
                /*var*/ let lambda = this.ParseAsLambda(expressionText, returnType, delegateInfo.Parameters);
                return lambda.LambdaExpression(delegateType);
            }
            //--TRIMMABLE-BOUNDARY-END(133145014387)
            
            //--TRIMMABLE-BOUNDARY-START(124555079795)
            /*Lambda */ ParseAs$1(TDelegate, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555079795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseAs(TDelegate.$type, expressionText, parametersNames);
            }
            //--TRIMMABLE-BOUNDARY-END(124555079795)
            
            //--TRIMMABLE-BOUNDARY-START(120260112499)
            /*Lambda */ ParseAs(/*Type*/ delegateType, /*string*/ expressionText, /*params string[]*/ parametersNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260112499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let delegateInfo = $.$HnZw.DR.ReflectionExtensions.GetDelegateInfo(delegateType, parametersNames);
                return this.ParseAsLambda(expressionText, delegateInfo.ReturnType, delegateInfo.Parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(120260112499)
            
            //--TRIMMABLE-BOUNDARY-START(47245668467)
            /*object */ Eval(/*string*/ expressionText, /*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245668467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Eval$1(expressionText, $.$$.S.Void.$type, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(47245668467)
            
            //--TRIMMABLE-BOUNDARY-START(55835603059)
            /*T */ Eval$2(T, /*string*/ expressionText, /*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835603059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.Eval$1(expressionText, T.$type, parameters), T);
            }
            //--TRIMMABLE-BOUNDARY-END(55835603059)
            
            //--TRIMMABLE-BOUNDARY-START(51540635763)
            /*object */ Eval$1(/*string*/ expressionText, /*Type*/ expressionType, /*params Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540635763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parse$1(expressionText, expressionType, parameters).Invoke$1(parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(51540635763)
            
            //--TRIMMABLE-BOUNDARY-START(34360766579)
            /*IdentifiersInfo */ DetectIdentifiers$1(/*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360766579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let detector = new $.$HnZw.D.Detector().$ctor$1(this._settings);
                return detector.DetectIdentifiers(expression, 0/*DetectorOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34360766579)
            
            //--TRIMMABLE-BOUNDARY-START(30065799283)
            /*IdentifiersInfo */ DetectIdentifiers(/*string*/ expression, /*DetectorOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065799283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let detector = new $.$HnZw.D.Detector().$ctor$1(this._settings);
                return detector.DetectIdentifiers(expression, options);
            }
            //--TRIMMABLE-BOUNDARY-END(30065799283)
            
            //--TRIMMABLE-BOUNDARY-START(141734948979)
            /*Lambda */ ParseAsLambda(/*string*/ expressionText, /*Type*/ expressionType, /*Parameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734948979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let $arguments = new $.$HnZw.D.ParserArguments().$ctor$1(expressionText, this._settings, expressionType, parameters, !$.$sl.SL.Enumerable.Any($.$sle.SLE.ExpressionVisitor, this.Visitors, new ($.$$.S.Func$$$($.$sle.SLE.ExpressionVisitor, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$is(p, $.$HnZw.DV.DisableReflectionVisitor);
                }, _d958bcbf_c1bc_4df1_93d7_7b50c6cec2c6 ??= {"r":262145,"p":[{"n":"p","p":11337765}],"n":"","d":1028211,"h":0,"f":17825794})));
                /*var*/ let expression = $.$HnZw.DP.Parser.Parse$1($arguments);
                var $en2 = this.Visitors.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    var visitor = $en2.SCG$IEnumerator$$$Current;
                    {
                        expression = visitor.Visit$1(expression);
                    }
                }
                /*var*/ let lambda = new $.$HnZw.D.Lambda().$ctor$1(expression, $arguments);
                return lambda;
            }
            //--TRIMMABLE-BOUNDARY-END(141734948979)
            
            //--TRIMMABLE-BOUNDARY-START(8590962803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590962803)
            
            static $h = 1028211;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770831987),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015472243,
        "f": 50331649
      },
      "n": "CaseInsensitive",
      "d": 1028211,
      "h": 25770831987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770831987),
//--TRIMMABLE-BOUNDARY-START(163209785459),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195341427,
        "f": 50331649
      },
      "n": "ReferencedTypes",
      "d": 1028211,
      "h": 163209785459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209785459),
//--TRIMMABLE-BOUNDARY-START(103080243315),
    {
      "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605406835,
        "f": 50331649
      },
      "n": "Identifiers",
      "d": 1028211,
      "h": 103080243315,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080243315),
//--TRIMMABLE-BOUNDARY-START(21475864691),
    {
      "p": 110707,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425537651,
        "f": 50331649
      },
      "n": "AssignmentOperators",
      "d": 1028211,
      "h": 21475864691,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475864691),
//--TRIMMABLE-BOUNDARY-START(219044360307),
    {
      "p": $.$$.SCG.ISet$$($.$sle.SLE.ExpressionVisitor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785276019,
        "f": 50331649
      },
      "n": "Visitors",
      "d": 1028211,
      "h": 219044360307,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044360307)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504752755),
    {
      "r": 1028211,
      "p": [
        {
          "n": "defaultNumberType",
          "p": 176243
        }
      ],
      "n": "SetDefaultNumberType",
      "d": 1028211,
      "h": 167504752755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504752755),
//--TRIMMABLE-BOUNDARY-START(38655733875),
    {
      "r": 1028211,
      "p": [
        {
          "n": "assignmentOperators",
          "p": 110707
        }
      ],
      "n": "EnableAssignment",
      "d": 1028211,
      "h": 38655733875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655733875),
//--TRIMMABLE-BOUNDARY-START(42950701171),
    {
      "r": 1028211,
      "n": "EnableReflection",
      "d": 1028211,
      "h": 42950701171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950701171),
//--TRIMMABLE-BOUNDARY-START(176094687347),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 66977793
        }
      ],
      "n": "SetFunction",
      "d": 1028211,
      "h": 176094687347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094687347),
//--TRIMMABLE-BOUNDARY-START(193274556531),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetVariable",
      "o": "@$1",
      "d": 1028211,
      "h": 193274556531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274556531),
//--TRIMMABLE-BOUNDARY-START(197569523827),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetVariable",
      "o": "@$2",
      "d": 1028211,
      "h": 197569523827,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(197569523827),
//--TRIMMABLE-BOUNDARY-START(188979589235),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "SetVariable",
      "d": 1028211,
      "h": 188979589235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979589235),
//--TRIMMABLE-BOUNDARY-START(171799720051),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "SetExpression",
      "d": 1028211,
      "h": 171799720051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799720051),
//--TRIMMABLE-BOUNDARY-START(184684621939),
    {
      "r": 1028211,
      "p": [
        {
          "n": "identifiers",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.Identifier).$h
        }
      ],
      "n": "SetIdentifiers",
      "d": 1028211,
      "h": 184684621939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684621939),
//--TRIMMABLE-BOUNDARY-START(180389654643),
    {
      "r": 1028211,
      "p": [
        {
          "n": "identifier",
          "p": 897139
        }
      ],
      "n": "SetIdentifier",
      "d": 1028211,
      "h": 180389654643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389654643),
//--TRIMMABLE-BOUNDARY-START(206159458419),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "UnsetFunction",
      "d": 1028211,
      "h": 206159458419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159458419),
//--TRIMMABLE-BOUNDARY-START(214749393011),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "UnsetVariable",
      "d": 1028211,
      "h": 214749393011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749393011),
//--TRIMMABLE-BOUNDARY-START(201864491123),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "UnsetExpression",
      "d": 1028211,
      "h": 201864491123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864491123),
//--TRIMMABLE-BOUNDARY-START(210454425715),
    {
      "r": 1028211,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "UnsetIdentifier",
      "d": 1028211,
      "h": 210454425715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454425715),
//--TRIMMABLE-BOUNDARY-START(158914818163),
    {
      "r": 1028211,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "Reference",
      "o": "@$3",
      "d": 1028211,
      "h": 158914818163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914818163),
//--TRIMMABLE-BOUNDARY-START(150324883571),
    {
      "r": 1028211,
      "p": [
        {
          "n": "types",
          "p": $.$$.SCG.IEnumerable$$($.$HnZw.D.ReferenceType).$h
        }
      ],
      "n": "Reference",
      "o": "@$1",
      "d": 1028211,
      "h": 150324883571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324883571),
//--TRIMMABLE-BOUNDARY-START(154619850867),
    {
      "r": 1028211,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "n": "Reference",
      "o": "@$2",
      "d": 1028211,
      "h": 154619850867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619850867),
//--TRIMMABLE-BOUNDARY-START(146029916275),
    {
      "r": 1028211,
      "p": [
        {
          "n": "type",
          "p": 2076787
        }
      ],
      "n": "Reference",
      "d": 1028211,
      "h": 146029916275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029916275),
//--TRIMMABLE-BOUNDARY-START(107375210611),
    {
      "r": 1159283,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "n": "Parse",
      "d": 1028211,
      "h": 107375210611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375210611),
//--TRIMMABLE-BOUNDARY-START(111670177907),
    {
      "r": 1159283,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "expressionType",
          "p": 188022785
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1028211,
      "h": 111670177907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670177907),
//--TRIMMABLE-BOUNDARY-START(115965145203),
    {
      "r": (TDelegate) => TDelegate.$h,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TDelegate"
      ],
      "n": "Parse",
      "o": "@$2",
      "d": 1028211,
      "h": 115965145203,
      "f": 16908289,
      "a": [
        {
          "t": 104005633,
          "c": 30168776705,
          "a": [
            {
              "v": "Use ParseAsDelegate\u003CTDelegate\u003E(string, params string[])",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965145203),
//--TRIMMABLE-BOUNDARY-START(128850047091),
    {
      "r": (TDelegate) => TDelegate.$h,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TDelegate"
      ],
      "n": "ParseAsDelegate",
      "d": 1028211,
      "h": 128850047091,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(128850047091),
//--TRIMMABLE-BOUNDARY-START(137439981683),
    {
      "r": (TDelegate) => $.$sle.SLE.Expression$$(TDelegate).$h,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TDelegate"
      ],
      "n": "ParseAsExpression",
      "o": "@$1",
      "d": 1028211,
      "h": 137439981683,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(137439981683),
//--TRIMMABLE-BOUNDARY-START(133145014387),
    {
      "r": 38797349,
      "p": [
        {
          "n": "delegateType",
          "p": 188022785
        },
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "ParseAsExpression",
      "d": 1028211,
      "h": 133145014387,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(133145014387),
//--TRIMMABLE-BOUNDARY-START(124555079795),
    {
      "r": 1159283,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TDelegate"
      ],
      "n": "ParseAs",
      "o": "@$1",
      "d": 1028211,
      "h": 124555079795,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(124555079795),
//--TRIMMABLE-BOUNDARY-START(120260112499),
    {
      "r": 1159283,
      "p": [
        {
          "n": "delegateType",
          "p": 188022785
        },
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parametersNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "ParseAs",
      "d": 1028211,
      "h": 120260112499,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120260112499),
//--TRIMMABLE-BOUNDARY-START(47245668467),
    {
      "r": 131073,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "n": "Eval",
      "d": 1028211,
      "h": 47245668467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245668467),
//--TRIMMABLE-BOUNDARY-START(55835603059),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "Eval",
      "o": "@$2",
      "d": 1028211,
      "h": 55835603059,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(55835603059),
//--TRIMMABLE-BOUNDARY-START(51540635763),
    {
      "r": 131073,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "expressionType",
          "p": 188022785
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h,
          "f": 16
        }
      ],
      "n": "Eval",
      "o": "@$1",
      "d": 1028211,
      "h": 51540635763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540635763),
//--TRIMMABLE-BOUNDARY-START(34360766579),
    {
      "r": 962675,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "DetectIdentifiers",
      "o": "@$1",
      "d": 1028211,
      "h": 34360766579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360766579),
//--TRIMMABLE-BOUNDARY-START(30065799283),
    {
      "r": 962675,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 307315
        }
      ],
      "n": "DetectIdentifiers",
      "d": 1028211,
      "h": 30065799283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065799283),
//--TRIMMABLE-BOUNDARY-START(141734948979),
    {
      "r": 1159283,
      "p": [
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "expressionType",
          "p": 188022785
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.Parameter).$h
        }
      ],
      "n": "ParseAsLambda",
      "d": 1028211,
      "h": 141734948979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734948979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295995507),
    {
      "t": 1814643,
      "n": "_settings",
      "d": 1028211,
      "h": 4295995507,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295995507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590962803),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1028211,
      "h": 8590962803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590962803),
//--TRIMMABLE-BOUNDARY-START(12885930099),
    {
      "p": [
        {
          "n": "options",
          "p": 1093747
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1028211,
      "h": 12885930099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885930099),
//--TRIMMABLE-BOUNDARY-START(17180897395),
    {
      "p": [
        {
          "n": "settings",
          "p": 1814643
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1028211,
      "h": 17180897395,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180897395)
  ],
  "h": 1028211
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Interpreter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Interpreter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1028211)
        
        

        //--TRIMMABLE-BOUNDARY-START(3387507)
        $asm.$cls(`$HnZw.DR$2.ErrorMessagesde`, ($self) => class ErrorMessagesde
        {
            //--TRIMMABLE-BOUNDARY-START(953486127219)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(953486127219)
            
            //--TRIMMABLE-BOUNDARY-START(944896192627)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(944896192627)
            
            //--TRIMMABLE-BOUNDARY-START(949191159923)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747327697011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$HnZw.DR$2.ErrorMessagesde.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("DynamicExpresso.Core", $.$HnZw.DR$2.ErrorMessagesde.$type.Assembly);
                    $.$HnZw.DR$2.ErrorMessagesde.s_resourceManager = temp;
                }
                return $.$HnZw.DR$2.ErrorMessagesde.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(949191159923)
            
            //--TRIMMABLE-BOUNDARY-START(85902733427)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429500117107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DR$2.ErrorMessagesde.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(962076061811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HnZw.DR$2.ErrorMessagesde.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85902733427)
            
            //--TRIMMABLE-BOUNDARY-START(4298354803)
            static /*string */ get AmbiguousBinaryOperatorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291359859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf des Nutzer-definierten Opeators '{0}' mit Typen '{1}' und '{2}'";
            }
            //--TRIMMABLE-BOUNDARY-END(4298354803)
            
            //--TRIMMABLE-BOUNDARY-START(128852406387)
            static /*string */ FormatAmbiguousBinaryOperatorInvocation(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852406387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Mehrdeutiger Aufruf des Nutzer-definierten Opeators '{0}' mit Typen '{1}' und '{2}'", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(128852406387)
            
            //--TRIMMABLE-BOUNDARY-START(8593322099)
            static /*string */ get AmbiguousConstructorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881294451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf eines Konstruktors des Typen '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(8593322099)
            
            //--TRIMMABLE-BOUNDARY-START(133147373683)
            static /*string */ FormatAmbiguousConstructorInvocation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147373683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Mehrdeutiger Aufruf eines Konstruktors des Typen '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133147373683)
            
            //--TRIMMABLE-BOUNDARY-START(12888289395)
            static /*string */ get AmbiguousDelegateInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283471229043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf eines Delegats (mehrere \u00DCberladungen gefunden)";
            }
            //--TRIMMABLE-BOUNDARY-END(12888289395)
            
            //--TRIMMABLE-BOUNDARY-START(17183256691)
            static /*string */ get AmbiguousIndexerInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292061163635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf eines Indexers des Typen '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(17183256691)
            
            //--TRIMMABLE-BOUNDARY-START(137442340979)
            static /*string */ FormatAmbiguousIndexerInvocation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442340979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Mehrdeutiger Aufruf eines Indexers des Typen '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137442340979)
            
            //--TRIMMABLE-BOUNDARY-START(21478223987)
            static /*string */ get AmbiguousMethodInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300651098227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf der Methode '{0}' mit Typen '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(21478223987)
            
            //--TRIMMABLE-BOUNDARY-START(141737308275)
            static /*string */ FormatAmbiguousMethodInvocation(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737308275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Mehrdeutiger Aufruf der Methode '{0}' mit Typen '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(141737308275)
            
            //--TRIMMABLE-BOUNDARY-START(25773191283)
            static /*string */ get AmbiguousUnaryOperatorInvocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309241032819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdeutiger Aufruf des Nutzer-definierten Operators '{0}' mit Typen '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(25773191283)
            
            //--TRIMMABLE-BOUNDARY-START(146032275571)
            static /*string */ FormatAmbiguousUnaryOperatorInvocation(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032275571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Mehrdeutiger Aufruf des Nutzer-definierten Operators '{0}' mit Typen '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(146032275571)
            
            //--TRIMMABLE-BOUNDARY-START(30068158579)
            static /*string */ get ArgsIncompatibleWithDelegate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830967411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Argument-Liste inkompatibel mit Delegaten-Ausdruck";
            }
            //--TRIMMABLE-BOUNDARY-END(30068158579)
            
            //--TRIMMABLE-BOUNDARY-START(34363125875)
            static /*string */ get ArgsIncompatibleWithLambda()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420902003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Argument-Liste inkompatibel mit Lambda-Ausdruck";
            }
            //--TRIMMABLE-BOUNDARY-END(34363125875)
            
            //--TRIMMABLE-BOUNDARY-START(47248027763)
            static /*string */ get BothTypesConvertToOther()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190705779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Beide Typen '{0}' und '{1}' k\u00F6nnen zueinander konvertiert werden";
            }
            //--TRIMMABLE-BOUNDARY-END(47248027763)
            
            //--TRIMMABLE-BOUNDARY-START(154622210163)
            static /*string */ FormatBothTypesConvertToOther(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622210163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Beide Typen '{0}' und '{1}' k\u00F6nnen zueinander konvertiert werden", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(154622210163)
            
            //--TRIMMABLE-BOUNDARY-START(51542995059)
            static /*string */ get CannotConvertValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780640371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Ein Wert mit Typ '{0}' kann nicht zum Typ '{1}' konvertiert werden";
            }
            //--TRIMMABLE-BOUNDARY-END(51542995059)
            
            //--TRIMMABLE-BOUNDARY-START(158917177459)
            static /*string */ FormatCannotConvertValue(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917177459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Ein Wert mit Typ '{0}' kann nicht zum Typ '{1}' konvertiert werden", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(158917177459)
            
            //--TRIMMABLE-BOUNDARY-START(55837962355)
            static /*string */ get CloseBracketOrCommaExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370574963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "']' oder ',' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(55837962355)
            
            //--TRIMMABLE-BOUNDARY-START(60132929651)
            static /*string */ get CloseCurlyBracketExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377960509555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'}}' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(60132929651)
            
            //--TRIMMABLE-BOUNDARY-START(64427896947)
            static /*string */ get CloseParenOrCommaExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386550444147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "')' oder ',' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(64427896947)
            
            //--TRIMMABLE-BOUNDARY-START(68722864243)
            static /*string */ get CloseParenOrOperatorExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140378739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "')' oder Operator erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(68722864243)
            
            //--TRIMMABLE-BOUNDARY-START(73017831539)
            static /*string */ get CloseTypeArgumentListExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730313331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'>' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(73017831539)
            
            //--TRIMMABLE-BOUNDARY-START(77312798835)
            static /*string */ get CollectionInitializationNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320247923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Der Typ '{0}' kann nicht mit einem Auflistungsinitialisierer initialisiert werden, da es '{1}' nicht implementiert";
            }
            //--TRIMMABLE-BOUNDARY-END(77312798835)
            
            //--TRIMMABLE-BOUNDARY-START(163212144755)
            static /*string */ FormatCollectionInitializationNotSupported(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212144755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Der Typ '{0}' kann nicht mit einem Auflistungsinitialisierer initialisiert werden, da es '{1}' nicht implementiert", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(163212144755)
            
            //--TRIMMABLE-BOUNDARY-START(81607766131)
            static /*string */ get ColonExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910182515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "':' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(81607766131)
            
            //--TRIMMABLE-BOUNDARY-START(90197700723)
            static /*string */ get DigitExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438090051699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Ziffer erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(90197700723)
            
            //--TRIMMABLE-BOUNDARY-START(94492668019)
            static /*string */ get DotOrOpenParenExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679986291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'.' oder '(' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(94492668019)
            
            //--TRIMMABLE-BOUNDARY-START(107377569907)
            static /*string */ get EqualExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449790067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'=' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(107377569907)
            
            //--TRIMMABLE-BOUNDARY-START(111672537203)
            static /*string */ get ExpressionExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481039724659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Ausdruck erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(111672537203)
            
            //--TRIMMABLE-BOUNDARY-START(115967504499)
            static /*string */ get ExpressionMustBeWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489629659251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Ausdruck muss schreibbar sein";
            }
            //--TRIMMABLE-BOUNDARY-END(115967504499)
            
            //--TRIMMABLE-BOUNDARY-START(120262471795)
            static /*string */ get FirstExprMustBeBool()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498219593843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Der erste Ausdruck muss vom Typ 'Boolean' sein";
            }
            //--TRIMMABLE-BOUNDARY-END(120262471795)
            
            //--TRIMMABLE-BOUNDARY-START(124557439091)
            static /*string */ get Format()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506809528435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} (an Stelle {1})";
            }
            //--TRIMMABLE-BOUNDARY-END(124557439091)
            
            //--TRIMMABLE-BOUNDARY-START(176097046643)
            static /*string */ FormatFormat(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176097046643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("{0} (an Stelle {1})", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(176097046643)
            
            //--TRIMMABLE-BOUNDARY-START(837522010227)
            static /*string */ get IdentifierExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532579332211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Bezeichner erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(837522010227)
            
            //--TRIMMABLE-BOUNDARY-START(841816977523)
            static /*string */ get IncompatibleOperand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541169266803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Operator '{0}' ist nicht kompatibel mit Operand von Typ '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(841816977523)
            
            //--TRIMMABLE-BOUNDARY-START(184686981235)
            static /*string */ FormatIncompatibleOperand(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686981235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Operator '{0}' ist nicht kompatibel mit Operand von Typ '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(184686981235)
            
            //--TRIMMABLE-BOUNDARY-START(846111944819)
            static /*string */ get IncompatibleOperands()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549759201395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Operator '{0}' ist nicht kompatibel mit Operanden von Typen '{1}' und '{2}'";
            }
            //--TRIMMABLE-BOUNDARY-END(846111944819)
            
            //--TRIMMABLE-BOUNDARY-START(188981948531)
            static /*string */ FormatIncompatibleOperands(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981948531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Operator '{0}' ist nicht kompatibel mit Operanden von Typen '{1}' und '{2}'", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(188981948531)
            
            //--TRIMMABLE-BOUNDARY-START(850406912115)
            static /*string */ get IncorrectNumberOfIndexes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558349135987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Falsche Anzahl an Indexen";
            }
            //--TRIMMABLE-BOUNDARY-END(850406912115)
            
            //--TRIMMABLE-BOUNDARY-START(854701879411)
            static /*string */ get InvalidCharacter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566939070579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Syntax Fehler '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(854701879411)
            
            //--TRIMMABLE-BOUNDARY-START(193276915827)
            static /*string */ FormatInvalidCharacter(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276915827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Syntax Fehler '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(193276915827)
            
            //--TRIMMABLE-BOUNDARY-START(858996846707)
            static /*string */ get InvalidCharacterLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575529005171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Zeichenliteral muss genau ein Zeichen beinhalten";
            }
            //--TRIMMABLE-BOUNDARY-END(858996846707)
            
            //--TRIMMABLE-BOUNDARY-START(863291814003)
            static /*string */ get InvalidEscapeSequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584118939763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalide Escapezeichen-Sequenz";
            }
            //--TRIMMABLE-BOUNDARY-END(863291814003)
            
            //--TRIMMABLE-BOUNDARY-START(867586781299)
            static /*string */ get InvalidIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592708874355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Array-Index muss ein Integer-Ausdruck sein";
            }
            //--TRIMMABLE-BOUNDARY-END(867586781299)
            
            //--TRIMMABLE-BOUNDARY-START(871881748595)
            static /*string */ get InvalidInitializerMemberDeclarator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601298808947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalide Deklaration eines Member-Intialisierers";
            }
            //--TRIMMABLE-BOUNDARY-END(871881748595)
            
            //--TRIMMABLE-BOUNDARY-START(876176715891)
            static /*string */ get InvalidIntegerLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609888743539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalides Integer-Literal '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(876176715891)
            
            //--TRIMMABLE-BOUNDARY-START(197571883123)
            static /*string */ FormatInvalidIntegerLiteral(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571883123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalides Integer-Literal '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(197571883123)
            
            //--TRIMMABLE-BOUNDARY-START(880471683187)
            static /*string */ get InvalidMethodCall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618478678131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keine zutreffende Methode gefunden im Typ '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(880471683187)
            
            //--TRIMMABLE-BOUNDARY-START(201866850419)
            static /*string */ FormatInvalidMethodCall(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866850419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Keine zutreffende Methode gefunden im Typ '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(201866850419)
            
            //--TRIMMABLE-BOUNDARY-START(889061617779)
            static /*string */ get InvalidOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635658547315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalide Operation";
            }
            //--TRIMMABLE-BOUNDARY-END(889061617779)
            
            //--TRIMMABLE-BOUNDARY-START(893356585075)
            static /*string */ get InvalidRealLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644248481907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalides Kommazahl-Literal '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(893356585075)
            
            //--TRIMMABLE-BOUNDARY-START(210456785011)
            static /*string */ FormatInvalidRealLiteral(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210456785011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalides Kommazahl-Literal '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(210456785011)
            
            //--TRIMMABLE-BOUNDARY-START(897651552371)
            static /*string */ get MethodTypeParametersCantBeInferred()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652838416499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Die Argumenttypen f\u00FCr die Methode '{0}' kann nicht von ihrer Nutzung erschlossen werden.";
            }
            //--TRIMMABLE-BOUNDARY-END(897651552371)
            
            //--TRIMMABLE-BOUNDARY-START(214751752307)
            static /*string */ FormatMethodTypeParametersCantBeInferred(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751752307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Die Argumenttypen f\u00FCr die Methode '{0}' kann nicht von ihrer Nutzung erschlossen werden.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214751752307)
            
            //--TRIMMABLE-BOUNDARY-START(906241486963)
            static /*string */ get NeitherTypeConvertsToOther()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670018285683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keine der beiden Typen '{0}' und '{1}' kann zueinander konvertiert werden";
            }
            //--TRIMMABLE-BOUNDARY-END(906241486963)
            
            //--TRIMMABLE-BOUNDARY-START(219046719603)
            static /*string */ FormatNeitherTypeConvertsToOther(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046719603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Keine der beiden Typen '{0}' und '{1}' kann zueinander konvertiert werden", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(219046719603)
            
            //--TRIMMABLE-BOUNDARY-START(914831421555)
            static /*string */ get NoApplicableConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687198154867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Kein zutreffender Konstruktor existiert im Typ '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(914831421555)
            
            //--TRIMMABLE-BOUNDARY-START(223341686899)
            static /*string */ FormatNoApplicableConstructor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341686899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Kein zutreffender Konstruktor existiert im Typ '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(223341686899)
            
            //--TRIMMABLE-BOUNDARY-START(919126388851)
            static /*string */ get NoApplicableIndexer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695788089459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Kein zutreffender Indexer existiert im Typ '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(919126388851)
            
            //--TRIMMABLE-BOUNDARY-START(227636654195)
            static /*string */ FormatNoApplicableIndexer(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227636654195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Kein zutreffender Indexer existiert im Typ '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(227636654195)
            
            //--TRIMMABLE-BOUNDARY-START(923421356147)
            static /*string */ get OpenCurlyBracketExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704378024051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{{' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(923421356147)
            
            //--TRIMMABLE-BOUNDARY-START(927716323443)
            static /*string */ get OpenParenExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712967958643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'(' erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(927716323443)
            
            //--TRIMMABLE-BOUNDARY-START(932011290739)
            static /*string */ get ParamsArrayTypeNotAnArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721557893235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Params Array Typ ist kein Array, Element nicht gefunden";
            }
            //--TRIMMABLE-BOUNDARY-END(932011290739)
            
            //--TRIMMABLE-BOUNDARY-START(966371029107)
            static /*string */ get SyntaxError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755917631603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Syntax Fehler";
            }
            //--TRIMMABLE-BOUNDARY-END(966371029107)
            
            //--TRIMMABLE-BOUNDARY-START(970665996403)
            static /*string */ get TypeHasNoNullableForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764507566195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Typ '{0}' hat keine Nullable-Form";
            }
            //--TRIMMABLE-BOUNDARY-END(970665996403)
            
            //--TRIMMABLE-BOUNDARY-START(236226588787)
            static /*string */ FormatTypeHasNoNullableForm(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226588787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Typ '{0}' hat keine Nullable-Form", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(236226588787)
            
            //--TRIMMABLE-BOUNDARY-START(974960963699)
            static /*string */ get TypeIdentifierExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773097500787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Typ-Bezeichner erwartet";
            }
            //--TRIMMABLE-BOUNDARY-END(974960963699)
            
            //--TRIMMABLE-BOUNDARY-START(979255930995)
            static /*string */ get TypeofRequiresAType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781687435379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Das 'typeof'-Schl\u00FCsselwort ben\u00F6tigt einen Typen als Argument";
            }
            //--TRIMMABLE-BOUNDARY-END(979255930995)
            
            //--TRIMMABLE-BOUNDARY-START(983550898291)
            static /*string */ get TypeofRequiresOneArg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790277369971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Das 'typeof'-Schl\u00FCsselwort ben\u00F6tigt 1 Argument";
            }
            //--TRIMMABLE-BOUNDARY-END(983550898291)
            
            //--TRIMMABLE-BOUNDARY-START(987845865587)
            static /*string */ get UnableToFindAppropriateAddMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798867304563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Die beste \u00DCberladung der Add-Methode '{0}.Add' f\u00FCr den Auflistungsinitialisierer hat invalide Argumente";
            }
            //--TRIMMABLE-BOUNDARY-END(987845865587)
            
            //--TRIMMABLE-BOUNDARY-START(240521556083)
            static /*string */ FormatUnableToFindAppropriateAddMethod(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240521556083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Die beste \u00DCberladung der Add-Methode '{0}.Add' f\u00FCr den Auflistungsinitialisierer hat invalide Argumente", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(240521556083)
            
            //--TRIMMABLE-BOUNDARY-START(996435800179)
            static /*string */ get UnknownPropertyOrField()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816047173747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keine Eigenschaft oder Feld '{0}' existiert am Typ '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(996435800179)
            
            //--TRIMMABLE-BOUNDARY-START(249111490675)
            static /*string */ FormatUnknownPropertyOrField(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111490675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Keine Eigenschaft oder Feld '{0}' existiert am Typ '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(249111490675)
            
            //--TRIMMABLE-BOUNDARY-START(1000730767475)
            static /*string */ get UnsupportedMultidimensionalArrays()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824637108339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrdimensionale Arrays werden nicht unterst\u00FCtzt";
            }
            //--TRIMMABLE-BOUNDARY-END(1000730767475)
            
            //--TRIMMABLE-BOUNDARY-START(1005025734771)
            static /*string */ get UnterminatedStringLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833227042931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Nicht-beendetes Zeichenfolgenliteral";
            }
            //--TRIMMABLE-BOUNDARY-END(1005025734771)
            
            //--TRIMMABLE-BOUNDARY-START(940601225331)
            static /*string */ get ReservedWord()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738737762419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} ist ein reserviertes Wort";
            }
            //--TRIMMABLE-BOUNDARY-END(940601225331)
            
            //--TRIMMABLE-BOUNDARY-START(231931621491)
            static /*string */ FormatReservedWord(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931621491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("{0} ist ein reserviertes Wort", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(231931621491)
            
            //--TRIMMABLE-BOUNDARY-START(38658093171)
            static /*string */ get ArgumentCountMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010836595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Argumentzahl unpassend";
            }
            //--TRIMMABLE-BOUNDARY-END(38658093171)
            
            //--TRIMMABLE-BOUNDARY-START(257701425267)
            static /*string */ get GenericTypeReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523989397619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Generische Typen m\u00FCssen mittels generischer Definition referenziert werden: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(257701425267)
            
            //--TRIMMABLE-BOUNDARY-START(180392013939)
            static /*string */ FormatGenericTypeReference(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180392013939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Generische Typen m\u00FCssen mittels generischer Definition referenziert werden: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(180392013939)
            
            //--TRIMMABLE-BOUNDARY-START(42953060467)
            static /*string */ get AssignmentOperatorNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343600771187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Zuweisungsoperator '{0}' ist nicht erlaubt";
            }
            //--TRIMMABLE-BOUNDARY-END(42953060467)
            
            //--TRIMMABLE-BOUNDARY-START(150327242867)
            static /*string */ FormatAssignmentOperatorNotAllowed(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327242867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Zuweisungsoperator '{0}' ist nicht erlaubt", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(150327242867)
            
            //--TRIMMABLE-BOUNDARY-START(103082602611)
            static /*string */ get DuplicateParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859855475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Der Parameter '{0}' wurde mehrmals definiert";
            }
            //--TRIMMABLE-BOUNDARY-END(103082602611)
            
            //--TRIMMABLE-BOUNDARY-START(171802079347)
            static /*string */ FormatDuplicateParameter(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171802079347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Der Parameter '{0}' wurde mehrmals definiert", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(171802079347)
            
            //--TRIMMABLE-BOUNDARY-START(884766650483)
            static /*string */ get InvalidMethodCall2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627068612723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keine zutreffende Methode '{0}' gefunden im Typ '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(884766650483)
            
            //--TRIMMABLE-BOUNDARY-START(206161817715)
            static /*string */ FormatInvalidMethodCall2(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161817715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Keine zutreffende Methode '{0}' gefunden im Typ '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(206161817715)
            
            //--TRIMMABLE-BOUNDARY-START(936306258035)
            static /*string */ get ReflectionNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730147827827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Spiegelungsausdr\u00FCcke sind nicht erlaubt. Aktivieren Sie Spiegelung mittels Interpreter.EnableReflection().";
            }
            //--TRIMMABLE-BOUNDARY-END(936306258035)
            
            //--TRIMMABLE-BOUNDARY-START(992140832883)
            static /*string */ get UnknownIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807457239155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unbekannter Bezeichner '{0}'";
            }
            //--TRIMMABLE-BOUNDARY-END(992140832883)
            
            //--TRIMMABLE-BOUNDARY-START(244816523379)
            static /*string */ FormatUnknownIdentifier(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244816523379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unbekannter Bezeichner '{0}'", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(244816523379)
            
            //--TRIMMABLE-BOUNDARY-START(98787635315)
            static /*string */ get DuplicateLocalParameterDeclaration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269920883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Eine locale Variable oder Parameter '{0}' kann nicht in dieser Zugriffsebene deklariert werden, da dieser Name bereits in einer h\u00F6heren Zugriffsebene verwendet wird, um eine lokale Variable oder Parameter zu definieren";
            }
            //--TRIMMABLE-BOUNDARY-END(98787635315)
            
            //--TRIMMABLE-BOUNDARY-START(167507112051)
            static /*string */ FormatDuplicateLocalParameterDeclaration(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507112051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Eine locale Variable oder Parameter '{0}' kann nicht in dieser Zugriffsebene deklariert werden, da dieser Name bereits in einer h\u00F6heren Zugriffsebene verwendet wird, um eine lokale Variable oder Parameter zu definieren", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(167507112051)
            
            //--TRIMMABLE-BOUNDARY-START(901946519667)
            static /*string */ get MultipleLambdaParametersWithoutBrace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661428351091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mehrere Lambda-Funktionsparameter erkannt, aber keine umgebenden Klammern gegeben";
            }
            //--TRIMMABLE-BOUNDARY-END(901946519667)
            
            //--TRIMMABLE-BOUNDARY-START(253406457971)
            static /*string */ get GenericArgumentCountMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515399463027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Die Anzahl an Typargumenten f\u00FCr den generischen Typ stimmt nicht mit der Stelligkeit der Definition \u00FCberein";
            }
            //--TRIMMABLE-BOUNDARY-END(253406457971)
            
            //--TRIMMABLE-BOUNDARY-START(910536454259)
            static /*string */ get NextTokenAtEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678608220275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "NextToken wurde am Ende des Ausdrucks aufgerufen";
            }
            //--TRIMMABLE-BOUNDARY-END(910536454259)
            
            static $h = 3387507;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(949191159923),
    {
      "p": 123076609,
      "g": {
        "r": 0,
        "d": 0,
        "h": 747327697011,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 3387507,
      "h": 949191159923,
      "f": 2097192,
      "a": [
        {
          "t": 64487425,
          "c": 12949389313,
          "a": [
            {
              "v": 2,
              "t": 64552961
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(949191159923),
//--TRIMMABLE-BOUNDARY-START(85902733427),
    {
      "p": 84213761,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429500117107,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 962076061811,
        "f": 83886120
      },
      "n": "Culture",
      "d": 3387507,
      "h": 85902733427,
      "f": 2097192,
      "a": [
        {
          "t": 64487425,
          "c": 12949389313,
          "a": [
            {
              "v": 2,
              "t": 64552961
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85902733427),
//--TRIMMABLE-BOUNDARY-START(4298354803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266291359859,
        "f": 50331688
      },
      "n": "AmbiguousBinaryOperatorInvocation",
      "d": 3387507,
      "h": 4298354803,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(4298354803),
//--TRIMMABLE-BOUNDARY-START(8593322099),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274881294451,
        "f": 50331688
      },
      "n": "AmbiguousConstructorInvocation",
      "d": 3387507,
      "h": 8593322099,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8593322099),
//--TRIMMABLE-BOUNDARY-START(12888289395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283471229043,
        "f": 50331688
      },
      "n": "AmbiguousDelegateInvocation",
      "d": 3387507,
      "h": 12888289395,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(12888289395),
//--TRIMMABLE-BOUNDARY-START(17183256691),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292061163635,
        "f": 50331688
      },
      "n": "AmbiguousIndexerInvocation",
      "d": 3387507,
      "h": 17183256691,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(17183256691),
//--TRIMMABLE-BOUNDARY-START(21478223987),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300651098227,
        "f": 50331688
      },
      "n": "AmbiguousMethodInvocation",
      "d": 3387507,
      "h": 21478223987,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(21478223987),
//--TRIMMABLE-BOUNDARY-START(25773191283),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309241032819,
        "f": 50331688
      },
      "n": "AmbiguousUnaryOperatorInvocation",
      "d": 3387507,
      "h": 25773191283,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25773191283),
//--TRIMMABLE-BOUNDARY-START(30068158579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317830967411,
        "f": 50331688
      },
      "n": "ArgsIncompatibleWithDelegate",
      "d": 3387507,
      "h": 30068158579,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(30068158579),
//--TRIMMABLE-BOUNDARY-START(34363125875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326420902003,
        "f": 50331688
      },
      "n": "ArgsIncompatibleWithLambda",
      "d": 3387507,
      "h": 34363125875,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34363125875),
//--TRIMMABLE-BOUNDARY-START(47248027763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352190705779,
        "f": 50331688
      },
      "n": "BothTypesConvertToOther",
      "d": 3387507,
      "h": 47248027763,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(47248027763),
//--TRIMMABLE-BOUNDARY-START(51542995059),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360780640371,
        "f": 50331688
      },
      "n": "CannotConvertValue",
      "d": 3387507,
      "h": 51542995059,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(51542995059),
//--TRIMMABLE-BOUNDARY-START(55837962355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369370574963,
        "f": 50331688
      },
      "n": "CloseBracketOrCommaExpected",
      "d": 3387507,
      "h": 55837962355,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(55837962355),
//--TRIMMABLE-BOUNDARY-START(60132929651),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377960509555,
        "f": 50331688
      },
      "n": "CloseCurlyBracketExpected",
      "d": 3387507,
      "h": 60132929651,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60132929651),
//--TRIMMABLE-BOUNDARY-START(64427896947),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386550444147,
        "f": 50331688
      },
      "n": "CloseParenOrCommaExpected",
      "d": 3387507,
      "h": 64427896947,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(64427896947),
//--TRIMMABLE-BOUNDARY-START(68722864243),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395140378739,
        "f": 50331688
      },
      "n": "CloseParenOrOperatorExpected",
      "d": 3387507,
      "h": 68722864243,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(68722864243),
//--TRIMMABLE-BOUNDARY-START(73017831539),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403730313331,
        "f": 50331688
      },
      "n": "CloseTypeArgumentListExpected",
      "d": 3387507,
      "h": 73017831539,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(73017831539),
//--TRIMMABLE-BOUNDARY-START(77312798835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412320247923,
        "f": 50331688
      },
      "n": "CollectionInitializationNotSupported",
      "d": 3387507,
      "h": 77312798835,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(77312798835),
//--TRIMMABLE-BOUNDARY-START(81607766131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420910182515,
        "f": 50331688
      },
      "n": "ColonExpected",
      "d": 3387507,
      "h": 81607766131,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(81607766131),
//--TRIMMABLE-BOUNDARY-START(90197700723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 438090051699,
        "f": 50331688
      },
      "n": "DigitExpected",
      "d": 3387507,
      "h": 90197700723,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(90197700723),
//--TRIMMABLE-BOUNDARY-START(94492668019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 446679986291,
        "f": 50331688
      },
      "n": "DotOrOpenParenExpected",
      "d": 3387507,
      "h": 94492668019,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(94492668019),
//--TRIMMABLE-BOUNDARY-START(107377569907),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 472449790067,
        "f": 50331688
      },
      "n": "EqualExpected",
      "d": 3387507,
      "h": 107377569907,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(107377569907),
//--TRIMMABLE-BOUNDARY-START(111672537203),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 481039724659,
        "f": 50331688
      },
      "n": "ExpressionExpected",
      "d": 3387507,
      "h": 111672537203,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111672537203),
//--TRIMMABLE-BOUNDARY-START(115967504499),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 489629659251,
        "f": 50331688
      },
      "n": "ExpressionMustBeWritable",
      "d": 3387507,
      "h": 115967504499,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(115967504499),
//--TRIMMABLE-BOUNDARY-START(120262471795),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 498219593843,
        "f": 50331688
      },
      "n": "FirstExprMustBeBool",
      "d": 3387507,
      "h": 120262471795,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(120262471795),
//--TRIMMABLE-BOUNDARY-START(124557439091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 506809528435,
        "f": 50331688
      },
      "n": "Format",
      "d": 3387507,
      "h": 124557439091,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(124557439091),
//--TRIMMABLE-BOUNDARY-START(837522010227),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 532579332211,
        "f": 50331688
      },
      "n": "IdentifierExpected",
      "d": 3387507,
      "h": 837522010227,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(837522010227),
//--TRIMMABLE-BOUNDARY-START(841816977523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 541169266803,
        "f": 50331688
      },
      "n": "IncompatibleOperand",
      "d": 3387507,
      "h": 841816977523,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(841816977523),
//--TRIMMABLE-BOUNDARY-START(846111944819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 549759201395,
        "f": 50331688
      },
      "n": "IncompatibleOperands",
      "d": 3387507,
      "h": 846111944819,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(846111944819),
//--TRIMMABLE-BOUNDARY-START(850406912115),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 558349135987,
        "f": 50331688
      },
      "n": "IncorrectNumberOfIndexes",
      "d": 3387507,
      "h": 850406912115,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(850406912115),
//--TRIMMABLE-BOUNDARY-START(854701879411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 566939070579,
        "f": 50331688
      },
      "n": "InvalidCharacter",
      "d": 3387507,
      "h": 854701879411,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(854701879411),
//--TRIMMABLE-BOUNDARY-START(858996846707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 575529005171,
        "f": 50331688
      },
      "n": "InvalidCharacterLiteral",
      "d": 3387507,
      "h": 858996846707,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(858996846707),
//--TRIMMABLE-BOUNDARY-START(863291814003),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 584118939763,
        "f": 50331688
      },
      "n": "InvalidEscapeSequence",
      "d": 3387507,
      "h": 863291814003,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(863291814003),
//--TRIMMABLE-BOUNDARY-START(867586781299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 592708874355,
        "f": 50331688
      },
      "n": "InvalidIndex",
      "d": 3387507,
      "h": 867586781299,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(867586781299),
//--TRIMMABLE-BOUNDARY-START(871881748595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 601298808947,
        "f": 50331688
      },
      "n": "InvalidInitializerMemberDeclarator",
      "d": 3387507,
      "h": 871881748595,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(871881748595),
//--TRIMMABLE-BOUNDARY-START(876176715891),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 609888743539,
        "f": 50331688
      },
      "n": "InvalidIntegerLiteral",
      "d": 3387507,
      "h": 876176715891,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(876176715891),
//--TRIMMABLE-BOUNDARY-START(880471683187),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 618478678131,
        "f": 50331688
      },
      "n": "InvalidMethodCall",
      "d": 3387507,
      "h": 880471683187,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(880471683187),
//--TRIMMABLE-BOUNDARY-START(889061617779),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 635658547315,
        "f": 50331688
      },
      "n": "InvalidOperation",
      "d": 3387507,
      "h": 889061617779,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(889061617779),
//--TRIMMABLE-BOUNDARY-START(893356585075),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 644248481907,
        "f": 50331688
      },
      "n": "InvalidRealLiteral",
      "d": 3387507,
      "h": 893356585075,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(893356585075),
//--TRIMMABLE-BOUNDARY-START(897651552371),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 652838416499,
        "f": 50331688
      },
      "n": "MethodTypeParametersCantBeInferred",
      "d": 3387507,
      "h": 897651552371,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(897651552371),
//--TRIMMABLE-BOUNDARY-START(906241486963),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 670018285683,
        "f": 50331688
      },
      "n": "NeitherTypeConvertsToOther",
      "d": 3387507,
      "h": 906241486963,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(906241486963),
//--TRIMMABLE-BOUNDARY-START(914831421555),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 687198154867,
        "f": 50331688
      },
      "n": "NoApplicableConstructor",
      "d": 3387507,
      "h": 914831421555,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(914831421555),
//--TRIMMABLE-BOUNDARY-START(919126388851),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 695788089459,
        "f": 50331688
      },
      "n": "NoApplicableIndexer",
      "d": 3387507,
      "h": 919126388851,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(919126388851),
//--TRIMMABLE-BOUNDARY-START(923421356147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 704378024051,
        "f": 50331688
      },
      "n": "OpenCurlyBracketExpected",
      "d": 3387507,
      "h": 923421356147,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(923421356147),
//--TRIMMABLE-BOUNDARY-START(927716323443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 712967958643,
        "f": 50331688
      },
      "n": "OpenParenExpected",
      "d": 3387507,
      "h": 927716323443,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(927716323443),
//--TRIMMABLE-BOUNDARY-START(932011290739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 721557893235,
        "f": 50331688
      },
      "n": "ParamsArrayTypeNotAnArray",
      "d": 3387507,
      "h": 932011290739,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(932011290739),
//--TRIMMABLE-BOUNDARY-START(966371029107),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 755917631603,
        "f": 50331688
      },
      "n": "SyntaxError",
      "d": 3387507,
      "h": 966371029107,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(966371029107),
//--TRIMMABLE-BOUNDARY-START(970665996403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 764507566195,
        "f": 50331688
      },
      "n": "TypeHasNoNullableForm",
      "d": 3387507,
      "h": 970665996403,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(970665996403),
//--TRIMMABLE-BOUNDARY-START(974960963699),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 773097500787,
        "f": 50331688
      },
      "n": "TypeIdentifierExpected",
      "d": 3387507,
      "h": 974960963699,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(974960963699),
//--TRIMMABLE-BOUNDARY-START(979255930995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 781687435379,
        "f": 50331688
      },
      "n": "TypeofRequiresAType",
      "d": 3387507,
      "h": 979255930995,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(979255930995),
//--TRIMMABLE-BOUNDARY-START(983550898291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 790277369971,
        "f": 50331688
      },
      "n": "TypeofRequiresOneArg",
      "d": 3387507,
      "h": 983550898291,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(983550898291),
//--TRIMMABLE-BOUNDARY-START(987845865587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 798867304563,
        "f": 50331688
      },
      "n": "UnableToFindAppropriateAddMethod",
      "d": 3387507,
      "h": 987845865587,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(987845865587),
//--TRIMMABLE-BOUNDARY-START(996435800179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 816047173747,
        "f": 50331688
      },
      "n": "UnknownPropertyOrField",
      "d": 3387507,
      "h": 996435800179,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(996435800179),
//--TRIMMABLE-BOUNDARY-START(1000730767475),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 824637108339,
        "f": 50331688
      },
      "n": "UnsupportedMultidimensionalArrays",
      "d": 3387507,
      "h": 1000730767475,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(1000730767475),
//--TRIMMABLE-BOUNDARY-START(1005025734771),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 833227042931,
        "f": 50331688
      },
      "n": "UnterminatedStringLiteral",
      "d": 3387507,
      "h": 1005025734771,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(1005025734771),
//--TRIMMABLE-BOUNDARY-START(940601225331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 738737762419,
        "f": 50331688
      },
      "n": "ReservedWord",
      "d": 3387507,
      "h": 940601225331,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(940601225331),
//--TRIMMABLE-BOUNDARY-START(38658093171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335010836595,
        "f": 50331688
      },
      "n": "ArgumentCountMismatch",
      "d": 3387507,
      "h": 38658093171,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(38658093171),
//--TRIMMABLE-BOUNDARY-START(257701425267),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 523989397619,
        "f": 50331688
      },
      "n": "GenericTypeReference",
      "d": 3387507,
      "h": 257701425267,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(257701425267),
//--TRIMMABLE-BOUNDARY-START(42953060467),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343600771187,
        "f": 50331688
      },
      "n": "AssignmentOperatorNotAllowed",
      "d": 3387507,
      "h": 42953060467,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(42953060467),
//--TRIMMABLE-BOUNDARY-START(103082602611),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 463859855475,
        "f": 50331688
      },
      "n": "DuplicateParameter",
      "d": 3387507,
      "h": 103082602611,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(103082602611),
//--TRIMMABLE-BOUNDARY-START(884766650483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 627068612723,
        "f": 50331688
      },
      "n": "InvalidMethodCall2",
      "d": 3387507,
      "h": 884766650483,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(884766650483),
//--TRIMMABLE-BOUNDARY-START(936306258035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 730147827827,
        "f": 50331688
      },
      "n": "ReflectionNotAllowed",
      "d": 3387507,
      "h": 936306258035,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(936306258035),
//--TRIMMABLE-BOUNDARY-START(992140832883),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 807457239155,
        "f": 50331688
      },
      "n": "UnknownIdentifier",
      "d": 3387507,
      "h": 992140832883,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(992140832883),
//--TRIMMABLE-BOUNDARY-START(98787635315),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 455269920883,
        "f": 50331688
      },
      "n": "DuplicateLocalParameterDeclaration",
      "d": 3387507,
      "h": 98787635315,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(98787635315),
//--TRIMMABLE-BOUNDARY-START(901946519667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 661428351091,
        "f": 50331688
      },
      "n": "MultipleLambdaParametersWithoutBrace",
      "d": 3387507,
      "h": 901946519667,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(901946519667),
//--TRIMMABLE-BOUNDARY-START(253406457971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 515399463027,
        "f": 50331688
      },
      "n": "GenericArgumentCountMismatch",
      "d": 3387507,
      "h": 253406457971,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(253406457971),
//--TRIMMABLE-BOUNDARY-START(910536454259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 678608220275,
        "f": 50331688
      },
      "n": "NextTokenAtEnd",
      "d": 3387507,
      "h": 910536454259,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(910536454259)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128852406387),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        },
        {
          "n": "arg3",
          "p": 131073
        }
      ],
      "n": "FormatAmbiguousBinaryOperatorInvocation",
      "d": 3387507,
      "h": 128852406387,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128852406387),
//--TRIMMABLE-BOUNDARY-START(133147373683),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatAmbiguousConstructorInvocation",
      "d": 3387507,
      "h": 133147373683,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(133147373683),
//--TRIMMABLE-BOUNDARY-START(137442340979),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatAmbiguousIndexerInvocation",
      "d": 3387507,
      "h": 137442340979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(137442340979),
//--TRIMMABLE-BOUNDARY-START(141737308275),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatAmbiguousMethodInvocation",
      "d": 3387507,
      "h": 141737308275,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(141737308275),
//--TRIMMABLE-BOUNDARY-START(146032275571),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatAmbiguousUnaryOperatorInvocation",
      "d": 3387507,
      "h": 146032275571,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(146032275571),
//--TRIMMABLE-BOUNDARY-START(154622210163),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatBothTypesConvertToOther",
      "d": 3387507,
      "h": 154622210163,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(154622210163),
//--TRIMMABLE-BOUNDARY-START(158917177459),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatCannotConvertValue",
      "d": 3387507,
      "h": 158917177459,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(158917177459),
//--TRIMMABLE-BOUNDARY-START(163212144755),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatCollectionInitializationNotSupported",
      "d": 3387507,
      "h": 163212144755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163212144755),
//--TRIMMABLE-BOUNDARY-START(176097046643),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatFormat",
      "d": 3387507,
      "h": 176097046643,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(176097046643),
//--TRIMMABLE-BOUNDARY-START(184686981235),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatIncompatibleOperand",
      "d": 3387507,
      "h": 184686981235,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(184686981235),
//--TRIMMABLE-BOUNDARY-START(188981948531),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        },
        {
          "n": "arg3",
          "p": 131073
        }
      ],
      "n": "FormatIncompatibleOperands",
      "d": 3387507,
      "h": 188981948531,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(188981948531),
//--TRIMMABLE-BOUNDARY-START(193276915827),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatInvalidCharacter",
      "d": 3387507,
      "h": 193276915827,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(193276915827),
//--TRIMMABLE-BOUNDARY-START(197571883123),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatInvalidIntegerLiteral",
      "d": 3387507,
      "h": 197571883123,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(197571883123),
//--TRIMMABLE-BOUNDARY-START(201866850419),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatInvalidMethodCall",
      "d": 3387507,
      "h": 201866850419,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(201866850419),
//--TRIMMABLE-BOUNDARY-START(210456785011),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatInvalidRealLiteral",
      "d": 3387507,
      "h": 210456785011,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(210456785011),
//--TRIMMABLE-BOUNDARY-START(214751752307),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatMethodTypeParametersCantBeInferred",
      "d": 3387507,
      "h": 214751752307,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(214751752307),
//--TRIMMABLE-BOUNDARY-START(219046719603),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatNeitherTypeConvertsToOther",
      "d": 3387507,
      "h": 219046719603,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(219046719603),
//--TRIMMABLE-BOUNDARY-START(223341686899),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatNoApplicableConstructor",
      "d": 3387507,
      "h": 223341686899,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(223341686899),
//--TRIMMABLE-BOUNDARY-START(227636654195),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatNoApplicableIndexer",
      "d": 3387507,
      "h": 227636654195,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(227636654195),
//--TRIMMABLE-BOUNDARY-START(236226588787),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatTypeHasNoNullableForm",
      "d": 3387507,
      "h": 236226588787,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(236226588787),
//--TRIMMABLE-BOUNDARY-START(240521556083),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatUnableToFindAppropriateAddMethod",
      "d": 3387507,
      "h": 240521556083,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(240521556083),
//--TRIMMABLE-BOUNDARY-START(249111490675),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatUnknownPropertyOrField",
      "d": 3387507,
      "h": 249111490675,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(249111490675),
//--TRIMMABLE-BOUNDARY-START(231931621491),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatReservedWord",
      "d": 3387507,
      "h": 231931621491,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(231931621491),
//--TRIMMABLE-BOUNDARY-START(180392013939),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatGenericTypeReference",
      "d": 3387507,
      "h": 180392013939,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(180392013939),
//--TRIMMABLE-BOUNDARY-START(150327242867),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatAssignmentOperatorNotAllowed",
      "d": 3387507,
      "h": 150327242867,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(150327242867),
//--TRIMMABLE-BOUNDARY-START(171802079347),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatDuplicateParameter",
      "d": 3387507,
      "h": 171802079347,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171802079347),
//--TRIMMABLE-BOUNDARY-START(206161817715),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatInvalidMethodCall2",
      "d": 3387507,
      "h": 206161817715,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(206161817715),
//--TRIMMABLE-BOUNDARY-START(244816523379),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatUnknownIdentifier",
      "d": 3387507,
      "h": 244816523379,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(244816523379),
//--TRIMMABLE-BOUNDARY-START(167507112051),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatDuplicateLocalParameterDeclaration",
      "d": 3387507,
      "h": 167507112051,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167507112051)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(953486127219),
    {
      "t": 123076609,
      "n": "s_resourceManager",
      "d": 3387507,
      "h": 953486127219,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(953486127219),
//--TRIMMABLE-BOUNDARY-START(944896192627),
    {
      "t": 84213761,
      "n": "resourceCulture",
      "d": 3387507,
      "h": 944896192627,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(944896192627)
  ],
  "h": 3387507,
  "a": [
    {
      "t": 54525953,
      "c": 12939427841,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 4365680641
    },
    {
      "t": 126091265,
      "c": 4421058561
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resources.ErrorMessagesde`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resources${separator}ErrorMessagesde`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3387507)
        
        

        //--TRIMMABLE-BOUNDARY-START(1683571)
        $asm.$cls(`$HnZw.DP.Parser`, ($self) => class Parser extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(219045015667)
            static /*Expression */ Parse$1(/*ParserArguments*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045015667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DP.Parser().$ctor$1($arguments).Parse();
            }
            //--TRIMMABLE-BOUNDARY-END(219045015667)
            
            //--TRIMMABLE-BOUNDARY-START(377958805619)
            /*NumberStyles*/ static ParseLiteralNumberStyle = 4;
            //--TRIMMABLE-BOUNDARY-END(377958805619)
            
            //--TRIMMABLE-BOUNDARY-START(382253772915)
            /*NumberStyles*/ static ParseLiteralUnsignedNumberStyle = 4;
            //--TRIMMABLE-BOUNDARY-END(382253772915)
            
            //--TRIMMABLE-BOUNDARY-START(373663838323)
            /*NumberStyles*/ static ParseLiteralHexNumberStyle = 515;
            //--TRIMMABLE-BOUNDARY-END(373663838323)
            
            //--TRIMMABLE-BOUNDARY-START(365073903731)
            /*NumberStyles*/ static ParseLiteralDecimalNumberStyle = 36;
            //--TRIMMABLE-BOUNDARY-END(365073903731)
            
            //--TRIMMABLE-BOUNDARY-START(369368871027)
            /*NumberStyles*/ static ParseLiteralDoubleNumberStyle = 164;
            //--TRIMMABLE-BOUNDARY-END(369368871027)
            
            //--TRIMMABLE-BOUNDARY-START(274879590515)
            /*CultureInfo*/ static ParseCulture = null;
            //--TRIMMABLE-BOUNDARY-END(274879590515)
            
            //--TRIMMABLE-BOUNDARY-START(4296650867)
            /*ParserArguments*/ _arguments = null;
            //--TRIMMABLE-BOUNDARY-END(4296650867)
            
            //--TRIMMABLE-BOUNDARY-START(30066454643)
            /*int*/ _parsePosition = 0;
            //--TRIMMABLE-BOUNDARY-END(30066454643)
            
            //--TRIMMABLE-BOUNDARY-START(12886585459)
            /*string*/ _expressionText = null;
            //--TRIMMABLE-BOUNDARY-END(12886585459)
            
            //--TRIMMABLE-BOUNDARY-START(17181552755)
            /*int*/ _expressionTextLength = 0;
            //--TRIMMABLE-BOUNDARY-END(17181552755)
            
            //--TRIMMABLE-BOUNDARY-START(25771487347)
            /*char*/ _parseChar = 0;
            //--TRIMMABLE-BOUNDARY-END(25771487347)
            
            //--TRIMMABLE-BOUNDARY-START(34361421939)
            /*Token*/ _token;
            //--TRIMMABLE-BOUNDARY-END(34361421939)
            
            //--TRIMMABLE-BOUNDARY-START(21476520051)
            /*MemberFinder*/ _memberFinder = null;
            //--TRIMMABLE-BOUNDARY-END(21476520051)
            
            //--TRIMMABLE-BOUNDARY-START(8591618163)
            /*DefaultNumberType*/ _defaultNumberType = 0;
            //--TRIMMABLE-BOUNDARY-END(8591618163)
            
            //--TRIMMABLE-BOUNDARY-START(42951356531)
            $ctor$1(/*ParserArguments*/ $arguments)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951356531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arguments = $arguments;
                    this._memberFinder = new $.$HnZw.DR.MemberFinder().$ctor$1($arguments);
                    this._defaultNumberType = $arguments.Settings.DefaultNumberType;
                    this._expressionText = $arguments.ExpressionText ?? $.$$.S.String.Empty;
                    this._expressionTextLength = this._expressionText.length;
                    this.SetTextPos(0);
                    this.NextToken();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951356531)
            
            //--TRIMMABLE-BOUNDARY-START(214750048371)
            /*Expression */ Parse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750048371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let expr = this.ParseExpressionSegment$1(this._arguments.ExpressionReturnType);
                this.ValidateToken(1/*TokenId.End*/, $.$HnZw.DR$2.ErrorMessages.SyntaxError);
                return expr;
            }
            //--TRIMMABLE-BOUNDARY-END(214750048371)
            
            //--TRIMMABLE-BOUNDARY-START(313534296179)
            /*Expression */ ParseExpressionSegment$1(/*Type*/ returnType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534296179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let expression = this.ParseExpressionSegment();
                if ($.$$.S.Type.op_Inequality$1(returnType, $.$$.S.Void.$type))
                {
                    return this.GenerateConversion(expression, returnType, errorPos);
                }
                return expression;
            }
            //--TRIMMABLE-BOUNDARY-END(313534296179)
            
            //--TRIMMABLE-BOUNDARY-START(309239328883)
            /*Expression */ ParseExpressionSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239328883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if (this._arguments.Settings.LambdaExpressions)
                    {
                        /*var*/ let lambdaExpr = this.ParseLambdaExpression();
                        if (lambdaExpr !== null)
                        {
                            return lambdaExpr;
                        }
                    }
                    return this.ParseAssignment();
                }
                catch(ex)
                {
                    throw $.$HnZw.DP.Parser.WrapWithParseException(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidOperation, ex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309239328883)
            
            //--TRIMMABLE-BOUNDARY-START(343599067251)
            /*Expression */ ParseLambdaExpression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599067251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let originalPos = this._token.pos;
                /*var*/ let isLambda = false;
                try
                {
                    /*var*/ let parameters = this.ParseLambdaParameterList();
                    this.ValidateToken$1(37/*TokenId.LambdaArrow*/);
                    /*var*/ let startExpr = this._parsePosition;
                    /*var*/ let parenCount = 0;
                    /*var*/ let inLambdaBody = true;
                    while(inLambdaBody)
                    {
                        this.NextToken();
                        if (this._token.id === 1/*TokenId.End*/)
                        {
                            inLambdaBody = false;
                        }
                        if (this._token.id === 9/*TokenId.OpenParen*/ || this._token.id === 35/*TokenId.OpenCurlyBracket*/)
                        {
                            parenCount++;
                        }
                        if (this._token.id === 10/*TokenId.CloseParen*/ || this._token.id === 36/*TokenId.CloseCurlyBracket*/)
                        {
                            parenCount--;
                        }
                        if (parenCount === 0 && this._token.id === 13/*TokenId.Comma*/)
                        {
                            inLambdaBody = false;
                        }
                        if (parenCount < 0)
                        {
                            inLambdaBody = false;
                        }
                    }
                    /*var*/ let lambdaBodyExp = $.$$.S.String.Substring.call(this._expressionText, startExpr, ((this._token.pos - startExpr) | 0));
                    isLambda = true;
                    return new $.$HnZw.DP.InterpreterExpression().$ctor$3(this._arguments, lambdaBodyExp, parameters);
                }
                catch($e)
                {
                    if (isLambda)
                    {
                        throw $e;
                    }
                    this.SetTextPos(originalPos);
                    this.NextToken();
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343599067251)
            
            //--TRIMMABLE-BOUNDARY-START(356483969139)
            /*ParameterWithPosition[] */ ParseLambdaParameterList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483969139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hasOpenParen = this._token.id === 9/*TokenId.OpenParen*/;
                if (hasOpenParen)
                {
                    this.NextToken();
                }
                /*var*/ let parameters = this._token.id !== 10/*TokenId.CloseParen*/ ? this.ParseLambdaParameters() : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$HnZw.D.ParameterWithPosition), null, [0], null);
                if (hasOpenParen)
                {
                    this.ValidateToken(10/*TokenId.CloseParen*/, $.$HnZw.DR$2.ErrorMessages.CloseParenOrCommaExpected);
                    this.NextToken();
                }
                if (!hasOpenParen && parameters.length > 1)
                {
                    throw new $.$HnZw.DE.ParseException().$ctor$11($.$HnZw.DR$2.ErrorMessages.MultipleLambdaParametersWithoutBrace, this._parsePosition);
                }
                return parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(356483969139)
            
            //--TRIMMABLE-BOUNDARY-START(360778936435)
            /*ParameterWithPosition[] */ ParseLambdaParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778936435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argList = new ($.$$.SCG.List$$($.$HnZw.D.ParameterWithPosition))().$ctor$1();
                while(true)
                {
                    argList.Add(this.ParseLambdaParameter());
                    if (this._token.id !== 13/*TokenId.Comma*/)
                    {
                        break;
                    }
                    this.NextToken();
                }
                return argList.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(360778936435)
            
            //--TRIMMABLE-BOUNDARY-START(352189001843)
            /*ParameterWithPosition */ ParseLambdaParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189001843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(2/*TokenId.Identifier*/);
                /*var*/ let name = this._token.text;
                /*var*/ let pos = this._token.pos;
                /*var*/ let type;
                if (this.TryParseKnownType(name, $.$ref(() => type, ($v) => type = $v, $.$$.S.Type)))
                {
                    this.ValidateToken$1(2/*TokenId.Identifier*/);
                    name = this._token.text;
                }
                else 
                {
                    type = $.$$.S.Object.$type;
                }
                this.NextToken();
                return new $.$HnZw.D.ParameterWithPosition().$ctor$4(pos, name, type);
            }
            //--TRIMMABLE-BOUNDARY-END(352189001843)
            
            //--TRIMMABLE-BOUNDARY-START(244814819443)
            /*Expression */ ParseAssignment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814819443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseConditional();
                if (this._token.id === 33/*TokenId.Equal*/)
                {
                    if (!((this._arguments.Settings.AssignmentOperators & (1/*AssignmentOperators.AssignmentEqual*/)) == (1/*AssignmentOperators.AssignmentEqual*/)))
                    {
                        throw new $.$HnZw.DE.AssignmentOperatorDisabledException().$ctor$13("=", this._token.pos);
                    }
                    /*Func<Expression, Expression>*/ let assignLeftDynamic = null;
                    if (!$.$HnZw.DP.Parser.IsWritable(left) && !$.$HnZw.DP.Parser.IsDynamicWritable(left, $.$ref(() => assignLeftDynamic, ($v) => assignLeftDynamic = $v, $.$$.S.Func$$$($.$sle.SLE.Expression, $.$sle.SLE.Expression))))
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.ExpressionMustBeWritable, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    this.NextToken();
                    /*var*/ let right = this.ParseAssignment();
                    /*var*/ let promoted = $.$HnZw.DR$1.ExpressionUtils.PromoteExpression(right, left.Type);
                    if (promoted === null)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.CannotConvertValue, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(right.Type), $.$HnZw.DR.TypeUtils.GetTypeName(left.Type) ], null, null));
                    }
                    left = assignLeftDynamic === null ? $.$sle.SLE.Expression.Assign(left, promoted) : assignLeftDynamic.Invoke(promoted);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(244814819443)
            
            //--TRIMMABLE-BOUNDARY-START(261994688627)
            /*Expression */ ParseConditional()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994688627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let expr = this.ParseConditionalOr();
                if (this._token.id === 17/*TokenId.QuestionQuestion*/)
                {
                    this.NextToken();
                    /*var*/ let exprRight = this.ParseExpressionSegment();
                    if ($.$HnZw.DR.TypeUtils.IsNullableType(expr.Type))
                    {
                        expr = this.GenerateConditional(this.GenerateGetNullableHasValue(expr), this.GenerateGetNullableValue(expr), exprRight, errorPos);
                    }
                    else 
                    {
                        expr = this.GenerateConditional(this.GenerateEqual(expr, $.$HnZw.DP.ParserConstants.NullLiteralExpression), exprRight, expr, errorPos);
                    }
                }
                else if (this._token.id === 22/*TokenId.Question*/)
                {
                    this.NextToken();
                    /*var*/ let expr1 = this.ParseExpressionSegment();
                    this.ValidateToken(19/*TokenId.Colon*/, $.$HnZw.DR$2.ErrorMessages.ColonExpected);
                    this.NextToken();
                    /*var*/ let expr2 = this.ParseExpressionSegment();
                    expr = this.GenerateConditional(expr, expr1, expr2, errorPos);
                }
                return expr;
            }
            //--TRIMMABLE-BOUNDARY-END(261994688627)
            
            //--TRIMMABLE-BOUNDARY-START(270584623219)
            /*Expression */ ParseConditionalOr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584623219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseConditionalAnd();
                while(this._token.id === 32/*TokenId.DoubleBar*/)
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseConditionalAnd();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.LogicalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(37/*ExpressionType.OrElse*/, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(270584623219)
            
            //--TRIMMABLE-BOUNDARY-START(266289655923)
            /*Expression */ ParseConditionalAnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289655923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseLogicalOr();
                while(this._token.id === 27/*TokenId.DoubleAmphersand*/)
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseLogicalOr();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.LogicalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(3/*ExpressionType.AndAlso*/, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(266289655923)
            
            //--TRIMMABLE-BOUNDARY-START(390843707507)
            /*Expression */ ParseLogicalOr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843707507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseLogicalXor();
                while(this._token.id === 31/*TokenId.Bar*/)
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseLogicalXor();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.LogicalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(36/*ExpressionType.Or*/, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(390843707507)
            
            //--TRIMMABLE-BOUNDARY-START(395138674803)
            /*Expression */ ParseLogicalXor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138674803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseLogicalAnd();
                while(this._token.id === 34/*TokenId.Caret*/)
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseLogicalAnd();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.LogicalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(14/*ExpressionType.ExclusiveOr*/, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(395138674803)
            
            //--TRIMMABLE-BOUNDARY-START(386548740211)
            /*Expression */ ParseLogicalAnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548740211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseComparison();
                while(this._token.id === 26/*TokenId.Amphersand*/)
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseComparison();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.LogicalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(2/*ExpressionType.And*/, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(386548740211)
            
            //--TRIMMABLE-BOUNDARY-START(257699721331)
            /*Expression */ ParseComparison()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699721331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseTypeTesting();
                while(this._token.id === 29/*TokenId.DoubleEqual*/ || this._token.id === 25/*TokenId.ExclamationEqual*/ || this._token.id === 21/*TokenId.GreaterThan*/ || this._token.id === 30/*TokenId.GreaterThanEqual*/ || this._token.id === 20/*TokenId.LessThan*/ || this._token.id === 28/*TokenId.LessThanEqual*/)
                {
                    /*var*/ let op = this._token;
                    this.NextToken();
                    /*var*/ let right = this.ParseShift();
                    /*var*/ let isEquality = op.id === 29/*TokenId.DoubleEqual*/ || op.id === 25/*TokenId.ExclamationEqual*/;
                    this.CheckAndPromoteOperands(isEquality ? $.$HnZw.DP.ParseSignatures.EqualitySignatures : $.$HnZw.DP.ParseSignatures.RelationalSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    let $switch3 = op.id;
                    switch($switch3)
                    {
                        case 29/*TokenId.DoubleEqual*/:
                        left = this.GenerateEqual(left, right);
                        break;
                        case 25/*TokenId.ExclamationEqual*/:
                        left = this.GenerateNotEqual(left, right);
                        break;
                        case 21/*TokenId.GreaterThan*/:
                        left = this.GenerateGreaterThan(left, right);
                        break;
                        case 30/*TokenId.GreaterThanEqual*/:
                        left = this.GenerateGreaterThanEqual(left, right);
                        break;
                        case 20/*TokenId.LessThan*/:
                        left = this.GenerateLessThan(left, right);
                        break;
                        case 28/*TokenId.LessThanEqual*/:
                        left = this.GenerateLessThanEqual(left, right);
                        break;
                    }
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(257699721331)
            
            //--TRIMMABLE-BOUNDARY-START(489627955315)
            /*Expression */ ParseTypeTesting()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627955315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseShift();
                while($.$$.S.String.op_Equality(this._token.text, "is"/*ParserConstants.KeywordIs*/) || $.$$.S.String.op_Equality(this._token.text, "as"/*ParserConstants.KeywordAs*/))
                {
                    /*var*/ let typeOperator = this._token.text;
                    /*var*/ let op = this._token;
                    this.NextToken();
                    /*var*/ let knownType;
                    if (!this.TryParseKnownType(this._token.text, $.$ref(() => knownType, ($v) => knownType = $v, $.$$.S.Type)))
                    {
                        throw $.$HnZw.DE.ParseException.Create(op.pos, $.$HnZw.DR$2.ErrorMessages.TypeIdentifierExpected, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    if ($.$$.S.String.op_Equality(typeOperator, "is"/*ParserConstants.KeywordIs*/))
                    {
                        left = $.$sle.SLE.Expression.TypeIs(left, knownType);
                    }
                    else if ($.$$.S.String.op_Equality(typeOperator, "as"/*ParserConstants.KeywordAs*/))
                    {
                        left = $.$sle.SLE.Expression.TypeAs(left, knownType);
                    }
                    else 
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.SyntaxError, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(489627955315)
            
            //--TRIMMABLE-BOUNDARY-START(223339982963)
            /*Expression */ ParseAdditive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339982963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseMultiplicative();
                while(this._token.id === 12/*TokenId.Plus*/ || this._token.id === 14/*TokenId.Minus*/)
                {
                    /*var*/ let op = this._token;
                    this.NextToken();
                    /*var*/ let right = this.ParseMultiplicative();
                    let $switch1 = op.id;
                    switch($switch1)
                    {
                        case 12/*TokenId.Plus*/:
                        if ($.$$.S.Type.op_Equality$1(left.Type, $.$$.S.String.$type) || $.$$.S.Type.op_Equality$1(right.Type, $.$$.S.String.$type))
                        {
                            left = $.$HnZw.DP.Parser.GenerateStringConcat(left, right);
                        }
                        else 
                        {
                            this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.AddSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                            left = this.GenerateBinary(0/*ExpressionType.Add*/, left, right);
                        }
                        break;
                        case 14/*TokenId.Minus*/:
                        this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.SubtractSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                        left = this.GenerateBinary(42/*ExpressionType.Subtract*/, left, right);
                        break;
                    }
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(223339982963)
            
            //--TRIMMABLE-BOUNDARY-START(459563184243)
            /*Expression */ ParseShift()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563184243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseAdditive();
                /*var*/ let shiftType;
                while(this.IsShiftOperator($.$ref(() => shiftType, ($v) => shiftType = $v, $.$sle.SLE.ExpressionType)))
                {
                    this.NextToken();
                    /*var*/ let right = this.ParseAdditive();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.ShiftSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    left = this.GenerateBinary(shiftType, left, right);
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(459563184243)
            
            //--TRIMMABLE-BOUNDARY-START(197570179187)
            /*bool */ IsShiftOperator(/*out ExpressionType*/ shiftType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570179187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._token.id === 21/*TokenId.GreaterThan*/ && this._parseChar === /*>*/ 62)
                {
                    this.NextToken();
                    shiftType.$v = 41/*ExpressionType.RightShift*/;
                    return true;
                }
                else if (this._token.id === 20/*TokenId.LessThan*/ && this._parseChar === /*<*/ 60)
                {
                    this.NextToken();
                    shiftType.$v = 19/*ExpressionType.LeftShift*/;
                    return true;
                }
                shiftType.$v = 48/*ExpressionType.DebugInfo*/;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(197570179187)
            
            //--TRIMMABLE-BOUNDARY-START(425203445875)
            /*Expression */ ParseMultiplicative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203445875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let left = this.ParseUnary();
                while(this._token.id === 11/*TokenId.Asterisk*/ || this._token.id === 18/*TokenId.Slash*/ || this._token.id === 8/*TokenId.Percent*/)
                {
                    /*var*/ let op = this._token;
                    this.NextToken();
                    /*var*/ let right = this.ParseUnary();
                    this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.ArithmeticSignatures, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                    let $switch3 = op.id;
                    switch($switch3)
                    {
                        case 11/*TokenId.Asterisk*/:
                        left = this.GenerateBinary(26/*ExpressionType.Multiply*/, left, right);
                        break;
                        case 18/*TokenId.Slash*/:
                        left = this.GenerateBinary(12/*ExpressionType.Divide*/, left, right);
                        break;
                        case 8/*TokenId.Percent*/:
                        left = this.GenerateBinary(25/*ExpressionType.Modulo*/, left, right);
                        break;
                    }
                }
                return left;
            }
            //--TRIMMABLE-BOUNDARY-END(425203445875)
            
            //--TRIMMABLE-BOUNDARY-START(493922922611)
            /*Expression */ ParseUnary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922922611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._token.id === 14/*TokenId.Minus*/ || this._token.id === 12/*TokenId.Plus*/ || this._token.id === 7/*TokenId.Exclamation*/ || this._token.id === 15/*TokenId.Tilde*/)
                {
                    /*var*/ let op = this._token;
                    this.NextToken();
                    if (this._token.id === 5/*TokenId.IntegerLiteral*/ || this._token.id === 6/*TokenId.RealLiteral*/)
                    {
                        if (op.id === 14/*TokenId.Minus*/)
                        {
                            this._token.text = "-" + this._token.text;
                            this._token.pos = op.pos;
                            return this.ParsePrimary();
                        }
                        if (op.id === 12/*TokenId.Plus*/)
                        {
                            this._token.text = "+" + this._token.text;
                            this._token.pos = op.pos;
                            return this.ParsePrimary();
                        }
                    }
                    /*var*/ let expr = this.ParseUnary();
                    if (op.id === 14/*TokenId.Minus*/)
                    {
                        this.CheckAndPromoteOperand($.$HnZw.DP.ParseSignatures.NegationSignatures, $.$ref(() => expr, ($v) => expr = $v, $.$sle.SLE.Expression));
                        expr = this.GenerateUnary(28/*ExpressionType.Negate*/, expr);
                    }
                    else if (op.id === 12/*TokenId.Plus*/)
                    {
                    }
                    else if (op.id === 7/*TokenId.Exclamation*/)
                    {
                        this.CheckAndPromoteOperand($.$HnZw.DP.ParseSignatures.NotSignatures, $.$ref(() => expr, ($v) => expr = $v, $.$sle.SLE.Expression));
                        expr = this.GenerateUnary(34/*ExpressionType.Not*/, expr);
                    }
                    else if (op.id === 15/*TokenId.Tilde*/)
                    {
                        this.CheckAndPromoteOperand($.$HnZw.DP.ParseSignatures.BitwiseComplementSignatures, $.$ref(() => expr, ($v) => expr = $v, $.$sle.SLE.Expression));
                        expr = this.GenerateUnary(82/*ExpressionType.OnesComplement*/, expr);
                    }
                    return expr;
                }
                return this.ParsePrimary();
            }
            //--TRIMMABLE-BOUNDARY-END(493922922611)
            
            //--TRIMMABLE-BOUNDARY-START(163210440819)
            /*Expression */ GenerateUnary(/*ExpressionType*/ unaryType, /*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210440819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsDynamicExpression(expr))
                {
                    return this.GenerateUnaryDynamic(unaryType, expr);
                }
                /*var*/ let unaryOps = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ExpressionType), [82/*ExpressionType.OnesComplement*/], null, null);
                if (expr.Type.IsEnum && $.$$.S.MemoryExtensions.Contains$1($.$sle.SLE.ExpressionType, $.$$.S.ReadOnlySpan$$($.$sle.SLE.ExpressionType).op_Implicit$1(unaryOps), unaryType, null))
                {
                    return this.GenerateUnaryEnums(unaryType, expr);
                }
                /*string*/ let opName;
                switch(unaryType)
                {
                    case 28/*ExpressionType.Negate*/:
                    opName = "op_UnaryNegation";
                    break;
                    case 34/*ExpressionType.Not*/:
                    opName = "op_LogicalNot";
                    break;
                    case 82/*ExpressionType.OnesComplement*/:
                    opName = "op_OnesComplement";
                    break;
                    default:
                    opName = null;
                    break;
                }
                /*var*/ let applicableMethod = this.FindUnaryOperator(opName, expr);
                /*MethodInfo*/ let operatorMethod = null;
                if (applicableMethod !== null)
                {
                    operatorMethod = $.$as(applicableMethod.MethodBase, $.$$.SR.MethodInfo);
                    expr = applicableMethod.PromotedParameters.SCG$IList$$$get_Item(0);
                }
                return $.$sle.SLE.Expression.MakeUnary(unaryType, expr, null, operatorMethod);
            }
            //--TRIMMABLE-BOUNDARY-END(163210440819)
            
            //--TRIMMABLE-BOUNDARY-START(171800375411)
            /*Expression */ GenerateUnaryEnums(/*ExpressionType*/ unaryType, /*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800375411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let enumType = expr.Type;
                /*var*/ let underlyingType = enumType.GetEnumUnderlyingType();
                expr = $.$sle.SLE.Expression.Convert$1(expr, underlyingType);
                return $.$sle.SLE.Expression.MakeUnary$1(unaryType, expr, enumType);
            }
            //--TRIMMABLE-BOUNDARY-END(171800375411)
            
            //--TRIMMABLE-BOUNDARY-START(167505408115)
            /*Expression */ GenerateUnaryDynamic(/*ExpressionType*/ unaryType, /*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505408115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let binder = $.$mc.MCR.Binder.UnaryOperation(0/*CSharpBinderFlags.None*/, unaryType, $.$HnZw.DP.Parser.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mc.MCR.CSharpArgumentInfo), [$.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null)], [-1], null));
                return $.$sle.SLE.Expression.Dynamic$5(binder, $.$$.S.Object.$type, expr);
            }
            //--TRIMMABLE-BOUNDARY-END(167505408115)
            
            //--TRIMMABLE-BOUNDARY-START(77311094899)
            /*MethodData */ FindUnaryOperator(/*string*/ operatorName, /*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311094899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.op_Equality(operatorName, null))
                {
                    return null;
                }
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let type = expr.Type;
                /*var*/ let args = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [expr], null, null);
                /*var*/ let applicableMethods = this._memberFinder.FindMethods(type, operatorName, true, args);
                if (applicableMethods.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousUnaryOperatorInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ operatorName, $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
                }
                /*MethodData*/ let userDefinedOperator = null;
                if (applicableMethods.SCG$ICollection$$$Count === 1)
                {
                    userDefinedOperator = applicableMethods.SCG$IList$$$get_Item(0);
                }
                return userDefinedOperator;
            }
            //--TRIMMABLE-BOUNDARY-END(77311094899)
            
            //--TRIMMABLE-BOUNDARY-START(446678282355)
            /*Expression */ ParsePrimary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678282355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tokenPos = this._token.pos;
                /*var*/ let expr = this.ParsePrimaryStart();
                while(true)
                {
                    if (this._token.id === 16/*TokenId.Dot*/)
                    {
                        this.NextToken();
                        expr = this.ParseMemberAccess(expr);
                    }
                    else if (this._token.id === 22/*TokenId.Question*/ && (this._parseChar === /*.*/ 46 || this._parseChar === /*[*/ 91))
                    {
                        this.NextToken();
                        if (this._token.id === 16/*TokenId.Dot*/)
                        {
                            this.NextToken();
                            /*var*/ let memberAccess = $.$HnZw.DP.Parser.GenerateNullableTypeConversion(this.ParseMemberAccess(this.GenerateGetNullableValue(expr)));
                            /*var*/ let nullExpr = $.$HnZw.DP.ParserConstants.NullLiteralExpression;
                            this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.EqualitySignatures, $.$ref(() => expr, ($v) => expr = $v, $.$sle.SLE.Expression), $.$ref(() => nullExpr, ($v) => nullExpr = $v, $.$sle.SLE.Expression));
                            expr = this.GenerateConditional(this.GenerateEqual(expr, nullExpr), $.$HnZw.DP.ParserConstants.NullLiteralExpression, memberAccess, this._token.pos);
                        }
                        else if (this._token.id === 23/*TokenId.OpenBracket*/)
                        {
                            /*var*/ let elementAccess = $.$HnZw.DP.Parser.GenerateNullableTypeConversion(this.ParseElementAccess(this.GenerateGetNullableValue(expr)));
                            /*var*/ let nullExpr = $.$HnZw.DP.ParserConstants.NullLiteralExpression;
                            this.CheckAndPromoteOperands($.$HnZw.DP.ParseSignatures.EqualitySignatures, $.$ref(() => expr, ($v) => expr = $v, $.$sle.SLE.Expression), $.$ref(() => nullExpr, ($v) => nullExpr = $v, $.$sle.SLE.Expression));
                            expr = this.GenerateConditional(this.GenerateEqual(expr, nullExpr), $.$HnZw.DP.ParserConstants.NullLiteralExpression, elementAccess, this._token.pos);
                        }
                    }
                    else if (this._token.id === 23/*TokenId.OpenBracket*/)
                    {
                        expr = this.ParseElementAccess(expr);
                    }
                    else if (this._token.id === 9/*TokenId.OpenParen*/)
                    {
                        let lambda;
                        if ($.$is(expr, $.$sle.SLE.LambdaExpression, { set $v(v){ lambda = v; } }))
                        {
                            return this.ParseLambdaInvocation(lambda, tokenPos);
                        }
                        let methodGroup;
                        if ($.$is(expr, $.$HnZw.D.MethodGroupExpression, { set $v(v){ methodGroup = v; } }))
                        {
                            expr = this.ParseMethodGroupInvocation(methodGroup, tokenPos);
                        }
                        else if ($.$$.S.Delegate.$type.IsAssignableFrom(expr.Type))
                        {
                            expr = this.ParseDelegateInvocation(expr, tokenPos);
                        }
                        else 
                        {
                            throw $.$HnZw.DE.ParseException.Create(tokenPos, $.$HnZw.DR$2.ErrorMessages.InvalidMethodCall, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(expr.Type) ], null, null));
                        }
                    }
                    else 
                    {
                        break;
                    }
                }
                return expr;
            }
            //--TRIMMABLE-BOUNDARY-END(446678282355)
            
            //--TRIMMABLE-BOUNDARY-START(111670833267)
            /*Expression */ GenerateGetNullableHasValue(/*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670833267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$HnZw.DR.TypeUtils.IsNullableType(expr.Type))
                {
                    return expr;
                }
                return this.GeneratePropertyOrFieldExpression(expr.Type, expr, this._token.pos, "HasValue");
            }
            //--TRIMMABLE-BOUNDARY-END(111670833267)
            
            //--TRIMMABLE-BOUNDARY-START(115965800563)
            /*Expression */ GenerateGetNullableValue(/*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965800563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$HnZw.DR.TypeUtils.IsNullableType(expr.Type))
                {
                    return expr;
                }
                return this.GeneratePropertyOrFieldExpression(expr.Type, expr, this._token.pos, "Value");
            }
            //--TRIMMABLE-BOUNDARY-END(115965800563)
            
            //--TRIMMABLE-BOUNDARY-START(450973249651)
            /*Expression */ ParsePrimaryStart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973249651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = this._token.id;
                switch($switch1)
                {
                    case 2/*TokenId.Identifier*/:
                    return this.ParseIdentifier();
                    case 3/*TokenId.CharLiteral*/:
                    return this.ParseCharLiteral();
                    case 4/*TokenId.StringLiteral*/:
                    return this.ParseStringLiteral();
                    case 5/*TokenId.IntegerLiteral*/:
                    return this.ParseIntegerLiteral();
                    case 6/*TokenId.RealLiteral*/:
                    return this.ParseRealLiteral();
                    case 9/*TokenId.OpenParen*/:
                    return this.ParseParenExpression();
                    case 1/*TokenId.End*/:
                    return $.$sle.SLE.Expression.Empty();
                    default:
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.ExpressionExpected, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450973249651)
            
            //--TRIMMABLE-BOUNDARY-START(249109786739)
            /*Expression */ ParseCharLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109786739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(3/*TokenId.CharLiteral*/);
                /*var*/ let s = $.$$.S.String.Substring.call(this._token.text, 1, ((this._token.text.length - 2) | 0));
                s = this.EvalEscapeStringLiteral(s);
                if (s.length !== 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidCharacterLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                this.NextToken();
                return $.$HnZw.DP.Parser.CreateLiteral($.$box($.$$.S.String.get_Chars.call(s, 0), $.$$.S.Char));
            }
            //--TRIMMABLE-BOUNDARY-END(249109786739)
            
            //--TRIMMABLE-BOUNDARY-START(463858151539)
            /*Expression */ ParseStringLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463858151539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(4/*TokenId.StringLiteral*/);
                /*var*/ let s = $.$$.S.String.Substring.call(this._token.text, 1, ((this._token.text.length - 2) | 0));
                s = this.EvalEscapeStringLiteral(s);
                this.NextToken();
                return $.$HnZw.DP.Parser.CreateLiteral(s);
            }
            //--TRIMMABLE-BOUNDARY-END(463858151539)
            
            //--TRIMMABLE-BOUNDARY-START(64426193011)
            /*string */ EvalEscapeStringLiteral(/*string*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426193011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IndexOf$3.call(source, /*\\*/ 92) < 0)
                {
                    return source;
                }
                /*var*/ let builder = new $.$$.ST.StringBuilder().$ctor$4(source.length);
                for(/*var*/ let i = 0; i < source.length; i++)
                {
                    /*var*/ let c = $.$$.S.String.get_Chars.call(source, i);
                    if (c === /*\\*/ 92)
                    {
                        if ((((i + 1) | 0)) === source.length)
                        {
                            throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidEscapeSequence, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        }
                        builder.Append$5(this.EvalEscapeChar($.$$.S.String.get_Chars.call(source, ++i)));
                    }
                    else 
                    {
                        builder.Append$5(c);
                    }
                }
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(64426193011)
            
            //--TRIMMABLE-BOUNDARY-START(60131225715)
            /*char */ EvalEscapeChar(/*char*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131225715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(source)
                {
                    case /*'*/ 39:
                    case /*\"*/ 34:
                    case /*\\*/ 92:
                    return source;
                    case /*0*/ 48:
                    return /*\u0000*/ 0;
                    case /*a*/ 97:
                    return /*\u0007*/ 7;
                    case /*b*/ 98:
                    return /*\u0008*/ 8;
                    case /*f*/ 102:
                    return /*\u000C*/ 12;
                    case /*n*/ 110:
                    return /*\n*/ 10;
                    case /*r*/ 114:
                    return /*\r*/ 13;
                    case /*t*/ 116:
                    return /*\t*/ 9;
                    case /*v*/ 118:
                    return /*\u000B*/ 11;
                    default:
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidEscapeSequence, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131225715)
            
            //--TRIMMABLE-BOUNDARY-START(326419198067)
            /*Expression */ ParseIntegerLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419198067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(5/*TokenId.IntegerLiteral*/);
                /*var*/ let text = this._token.text;
                /*var*/ let isUnsigned = false;
                /*var*/ let isLong = false;
                /*var*/ let numberEnd = ((text.length - 1) | 0);
                for(; numberEnd >= 0; numberEnd--)
                {
                    /*var*/ let chr = $.$$.S.String.get_Chars.call(text, numberEnd);
                    if (chr === /*U*/ 85 || chr === /*u*/ 117)
                    {
                        isUnsigned = true;
                    }
                    else if (chr === /*L*/ 76 || chr === /*l*/ 108)
                    {
                        isLong = true;
                    }
                    else 
                    {
                        break;
                    }
                }
                text = $.$$.S.String.Substring.call(text, 0, ((numberEnd + 1) | 0));
                if (this._defaultNumberType === 2/*DefaultNumberType.Long*/)
                {
                    isLong = true;
                }
                if ($.$$.S.String.get_Chars.call(text, 0) !== /*-*/ 45)
                {
                    /*ulong*/ let value;
                    if ($.$$.S.String.StartsWith$3.call(text, "0x") || $.$$.S.String.StartsWith$3.call(text, "0X"))
                    {
                        /*var*/ let hex = $.$$.S.String.Substring$1.call(text, 2);
                        if (!$.$$.S.UInt64.TryParse$7(hex, 515/*ParseLiteralHexNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt64)))
                        {
                            throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidIntegerLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                        }
                    }
                    else if ($.$$.S.String.StartsWith$3.call(text, "0b") || $.$$.S.String.StartsWith$3.call(text, "0B"))
                    {
                        /*var*/ let binary = $.$$.S.String.Substring$1.call(text, 2);
                        if ($.$$.S.String.IsNullOrEmpty(binary))
                        {
                            throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidIntegerLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                        }
                        try
                        {
                            value = $.$$.S.Convert.ToUInt64$14(binary, 2);
                        }
                        catch(ex)
                        {
                            throw $.$HnZw.DP.Parser.WrapWithParseException(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidIntegerLiteral, ex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                        }
                    }
                    else if (!$.$$.S.UInt64.TryParse$7(text, 4/*ParseLiteralUnsignedNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt64)))
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidIntegerLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                    }
                    this.NextToken();
                    if (!isUnsigned && !isLong && value <= BigInt(2147483647/*int.MaxValue*/))
                    {
                        return $.$HnZw.DP.Parser.CreateLiteral($.$box($.$cast(value, $.$$.S.Int32), $.$$.S.Int32));
                    }
                    if (!isLong && value <= BigInt(4294967295/*uint.MaxValue*/))
                    {
                        return $.$HnZw.DP.Parser.CreateLiteral($.$box($.$cast(value, $.$$.S.UInt32), $.$$.S.UInt32));
                    }
                    if (!isUnsigned && value <= 9223372036854775807n)
                    {
                        return $.$HnZw.DP.Parser.CreateLiteral($.$box($.$cast(value, $.$$.S.Int64), $.$$.S.Int64));
                    }
                    return $.$HnZw.DP.Parser.CreateLiteral($.$box(value, $.$$.S.UInt64));
                }
                else 
                {
                    /*var*/ let value;
                    if (!$.$$.S.Int64.TryParse$7(text, 4/*ParseLiteralNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => value, ($v) => value = $v, $.$$.S.Int64)))
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidIntegerLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                    }
                    this.NextToken();
                    if (!isLong && value >= BigInt(-2147483648/*int.MinValue*/) && value <= BigInt(2147483647/*int.MaxValue*/))
                    {
                        return $.$HnZw.DP.Parser.CreateLiteral($.$box($.$cast(value, $.$$.S.Int32), $.$$.S.Int32));
                    }
                    return $.$HnZw.DP.Parser.CreateLiteral($.$box(value, $.$$.S.Int64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(326419198067)
            
            //--TRIMMABLE-BOUNDARY-START(455268216947)
            /*Expression */ ParseRealLiteral()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455268216947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(6/*TokenId.RealLiteral*/);
                /*var*/ let text = this._token.text;
                /*object*/ let value = null;
                /*var*/ let last = $.$$.S.String.get_Chars.call(text, ((text.length - 1) | 0));
                if (last === /*F*/ 70 || last === /*f*/ 102)
                {
                    /*var*/ let f;
                    if ($.$$.S.Single.TryParse$7($.$$.S.String.Substring.call(text, 0, ((text.length - 1) | 0)), 36/*ParseLiteralDecimalNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => f, ($v) => f = $v, $.$$.S.Single)))
                    {
                        value = $.$box(f, $.$$.S.Single);
                    }
                }
                else if (last === /*M*/ 77 || last === /*m*/ 109)
                {
                    /*var*/ let dc;
                    if ($.$$.S.Decimal.TryParse$7($.$$.S.String.Substring.call(text, 0, ((text.length - 1) | 0)), 36/*ParseLiteralDecimalNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => dc, ($v) => dc = $v, $.$$.S.Decimal)))
                    {
                        value = dc;
                    }
                }
                else if (last === /*D*/ 68 || last === /*d*/ 100)
                {
                    /*var*/ let d;
                    if ($.$$.S.Double.TryParse$7($.$$.S.String.Substring.call(text, 0, ((text.length - 1) | 0)), 164/*ParseLiteralDoubleNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => d, ($v) => d = $v, $.$$.S.Double)))
                    {
                        value = $.$box(d, $.$$.S.Double);
                    }
                }
                else 
                {
                    if (this._defaultNumberType === 5/*DefaultNumberType.Decimal*/)
                    {
                        /*var*/ let dc;
                        if ($.$$.S.Decimal.TryParse$7(text, 36/*ParseLiteralDecimalNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => dc, ($v) => dc = $v, $.$$.S.Decimal)))
                        {
                            value = dc;
                        }
                    }
                    else if (this._defaultNumberType === 3/*DefaultNumberType.Single*/)
                    {
                        /*var*/ let f;
                        if ($.$$.S.Single.TryParse$7(text, 36/*ParseLiteralDecimalNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => f, ($v) => f = $v, $.$$.S.Single)))
                        {
                            value = $.$box(f, $.$$.S.Single);
                        }
                    }
                    else 
                    {
                        /*var*/ let d;
                        if ($.$$.S.Double.TryParse$7(text, 164/*ParseLiteralDoubleNumberStyle*/, $.$HnZw.DP.Parser.ParseCulture, $.$ref(() => d, ($v) => d = $v, $.$$.S.Double)))
                        {
                            value = $.$box(d, $.$$.S.Double);
                        }
                    }
                }
                if (value === null)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidRealLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ text ], null, null));
                }
                this.NextToken();
                return $.$HnZw.DP.Parser.CreateLiteral(value);
            }
            //--TRIMMABLE-BOUNDARY-END(455268216947)
            
            //--TRIMMABLE-BOUNDARY-START(55836258419)
            static /*Expression */ CreateLiteral(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836258419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let expr = $.$sle.SLE.Expression.Constant$1(value);
                return expr;
            }
            //--TRIMMABLE-BOUNDARY-END(55836258419)
            
            //--TRIMMABLE-BOUNDARY-START(438088347763)
            /*Expression */ ParseParenExpression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088347763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken(9/*TokenId.OpenParen*/, $.$HnZw.DR$2.ErrorMessages.OpenParenExpected);
                this.NextToken();
                /*var*/ let innerParenthesesExpression = this.ParseExpressionSegment();
                this.ValidateToken(10/*TokenId.CloseParen*/, $.$HnZw.DR$2.ErrorMessages.CloseParenOrOperatorExpected);
                let constExp;
                let constType;
                if ($.$is(innerParenthesesExpression, $.$sle.SLE.ConstantExpression, { set $v(v){ constExp = v; } }) && $.$is(constExp.Value, $.$$.S.Type, { set $v(v){ constType = v; } }))
                {
                    this.NextToken();
                    /*var*/ let nextExpression = this.ParseUnary();
                    return $.$sle.SLE.Expression.Convert$1(nextExpression, constType);
                }
                this.NextToken();
                return innerParenthesesExpression;
            }
            //--TRIMMABLE-BOUNDARY-END(438088347763)
            
            //--TRIMMABLE-BOUNDARY-START(322124230771)
            /*Expression */ ParseIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124230771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(2/*TokenId.Identifier*/);
                if ($.$$.S.String.op_Equality(this._token.text, "new"/*ParserConstants.KeywordNew*/))
                {
                    return this.ParseNew();
                }
                if ($.$$.S.String.op_Equality(this._token.text, "typeof"/*ParserConstants.KeywordTypeof*/))
                {
                    return this.ParseTypeof();
                }
                if ($.$$.S.String.op_Equality(this._token.text, "default"/*ParserConstants.KeywordDefault*/))
                {
                    return this.ParseDefaultOperator();
                }
                /*var*/ let keywordExpression;
                if (this._arguments.TryGetIdentifier(this._token.text, $.$ref(() => keywordExpression, ($v) => keywordExpression = $v, $.$sle.SLE.Expression)))
                {
                    this.NextToken();
                    return keywordExpression;
                }
                /*var*/ let parameterExpression;
                if (this._arguments.TryGetParameters(this._token.text, $.$ref(() => parameterExpression, ($v) => parameterExpression = $v, $.$sle.SLE.ParameterExpression)))
                {
                    this.NextToken();
                    return parameterExpression;
                }
                /*var*/ let knownType;
                if (this.TryParseKnownType(this._token.text, $.$ref(() => knownType, ($v) => knownType = $v, $.$$.S.Type)))
                {
                    return this.ParseTypeKeyword(knownType);
                }
                /*var*/ let token = this._token;
                try
                {
                    /*var*/ let thisKeywordExpression;
                    if (this._arguments.TryGetIdentifier("this"/*LanguageConstants.This*/, $.$ref(() => thisKeywordExpression, ($v) => thisKeywordExpression = $v, $.$sle.SLE.Expression)))
                    {
                        return this.ParseMemberAccess(thisKeywordExpression);
                    }
                    /*var*/ let thisParameterExpression;
                    if (this._arguments.TryGetParameters("this"/*LanguageConstants.This*/, $.$ref(() => thisParameterExpression, ($v) => thisParameterExpression = $v, $.$sle.SLE.ParameterExpression)))
                    {
                        return this.ParseMemberAccess(thisParameterExpression);
                    }
                }
                catch($e)
                {
                }
                throw new $.$HnZw.DE.UnknownIdentifierException().$ctor$13(token.text, token.pos);
            }
            //--TRIMMABLE-BOUNDARY-END(322124230771)
            
            //--TRIMMABLE-BOUNDARY-START(485332988019)
            /*Expression */ ParseTypeof()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332988019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let errorPos = this._token.pos;
                this.NextToken();
                /*var*/ let args = this.ParseArgumentList();
                if (args.length !== 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.TypeofRequiresOneArg, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                let constExp;
                if (!($.$is($.$$.System.Array.$ReadT1.call(args, 0), $.$sle.SLE.ConstantExpression, { set $v(v){ constExp = v; } }) && $.$is(constExp.Value, $.$$.S.Type)))
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.TypeofRequiresAType, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                return constExp;
            }
            //--TRIMMABLE-BOUNDARY-END(485332988019)
            
            //--TRIMMABLE-BOUNDARY-START(279174557811)
            /*Expression */ ParseDefaultOperator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174557811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NextToken();
                this.ValidateToken(9/*TokenId.OpenParen*/, $.$HnZw.DR$2.ErrorMessages.OpenParenExpected);
                this.NextToken();
                this.ValidateToken$1(2/*TokenId.Identifier*/);
                /*var*/ let type = this.ParseKnownType();
                this.ValidateToken(10/*TokenId.CloseParen*/, $.$HnZw.DR$2.ErrorMessages.CloseParenOrCommaExpected);
                this.NextToken();
                return $.$sle.SLE.Expression.Default(type);
            }
            //--TRIMMABLE-BOUNDARY-END(279174557811)
            
            //--TRIMMABLE-BOUNDARY-START(94490964083)
            /*Expression */ GenerateConditional(/*Expression*/ test, /*Expression*/ expr1, /*Expression*/ expr2, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490964083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsDynamicExpression(test))
                {
                    return this.GenerateConditionalDynamic(test, expr1, expr2, errorPos);
                }
                if ($.$$.S.Type.op_Inequality$1(test.Type, $.$$.S.Boolean.$type))
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.FirstExprMustBeBool, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                if ($.$$.S.Type.op_Inequality$1(expr1.Type, expr2.Type))
                {
                    /*var*/ let expr1As2 = expr2 !== $.$HnZw.DP.ParserConstants.NullLiteralExpression ? $.$HnZw.DR$1.ExpressionUtils.PromoteExpression(expr1, expr2.Type) : null;
                    /*var*/ let expr2As1 = expr1 !== $.$HnZw.DP.ParserConstants.NullLiteralExpression ? $.$HnZw.DR$1.ExpressionUtils.PromoteExpression(expr2, expr1.Type) : null;
                    if (expr1As2 !== null && expr2As1 === null)
                    {
                        expr1 = expr1As2;
                    }
                    else if (expr2As1 !== null && expr1As2 === null)
                    {
                        expr2 = expr2As1;
                    }
                    else 
                    {
                        /*var*/ let type1 = expr1 !== $.$HnZw.DP.ParserConstants.NullLiteralExpression ? expr1.Type.Name : "null";
                        /*var*/ let type2 = expr2 !== $.$HnZw.DP.ParserConstants.NullLiteralExpression ? expr2.Type.Name : "null";
                        if (expr1As2 !== null)
                        {
                            throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.BothTypesConvertToOther, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ type1, type2 ], null, null));
                        }
                        throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.NeitherTypeConvertsToOther, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ type1, type2 ], null, null));
                    }
                }
                return $.$sle.SLE.Expression.Condition$1(test, expr1, expr2);
            }
            //--TRIMMABLE-BOUNDARY-END(94490964083)
            
            //--TRIMMABLE-BOUNDARY-START(98785931379)
            /*Expression */ GenerateConditionalDynamic(/*Expression*/ test, /*Expression*/ expr1, /*Expression*/ expr2, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785931379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let casted = $.$sle.SLE.Expression.Convert$1(test, $.$$.S.Boolean.$type);
                return this.GenerateConditional(casted, expr1, expr2, errorPos);
            }
            //--TRIMMABLE-BOUNDARY-END(98785931379)
            
            //--TRIMMABLE-BOUNDARY-START(429498413171)
            /*Expression */ ParseNew()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498413171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NextToken();
                this.ValidateToken(2/*TokenId.Identifier*/, $.$HnZw.DR$2.ErrorMessages.IdentifierExpected);
                /*var*/ let newType = this.ParseKnownType();
                /*var*/ let args = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), null, [0], null);
                if (newType.IsArray)
                {
                    if (newType.GetArrayRank() !== 1)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.UnsupportedMultidimensionalArrays, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ newType ], null, null));
                    }
                    args = this.ParseArrayInitializerList();
                    return $.$sle.SLE.Expression.NewArrayInit$1(newType.GetElementType(), args);
                }
                if (this._token.id === 9/*TokenId.OpenParen*/)
                {
                    args = this.ParseArgumentList();
                }
                else 
                {
                    this.ValidateToken(35/*TokenId.OpenCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.OpenCurlyBracketExpected);
                }
                /*var*/ let applicableConstructors = $.$HnZw.DR$1.MethodResolution.FindBestMethod$1($.$$.N.InterfaceVarianceStubHandler.Create(newType.GetConstructors(), $.$$.SCG.IEnumerable$$($.$$.SR.ConstructorInfo), $.$$.SCG.IEnumerable$$($.$$.SR.MethodBase)), args);
                if (applicableConstructors.SCG$ICollection$$$Count === 0)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.NoApplicableConstructor, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ newType ], null, null));
                }
                if (applicableConstructors.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.AmbiguousConstructorInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ newType ], null, null));
                }
                /*var*/ let $constructor = applicableConstructors.SCG$IList$$$get_Item(0);
                /*var*/ let newExpr = $.$sle.SLE.Expression.New$2($.$cast($constructor.MethodBase, $.$$.SR.ConstructorInfo), $constructor.PromotedParameters);
                if (this._token.id === 35/*TokenId.OpenCurlyBracket*/)
                {
                    return this.ParseWithObjectInitializer(newExpr, newType);
                }
                return newExpr;
            }
            //--TRIMMABLE-BOUNDARY-END(429498413171)
            
            //--TRIMMABLE-BOUNDARY-START(236224884851)
            /*Expression[] */ ParseArrayInitializerList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224884851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseArgumentList$1(35/*TokenId.OpenCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.OpenCurlyBracketExpected, 36/*TokenId.CloseCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.CloseCurlyBracketExpected, true);
            }
            //--TRIMMABLE-BOUNDARY-END(236224884851)
            
            //--TRIMMABLE-BOUNDARY-START(502512857203)
            /*Expression */ ParseWithObjectInitializer(/*NewExpression*/ newExpr, /*Type*/ newType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512857203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken(35/*TokenId.OpenCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.OpenCurlyBracketExpected);
                this.NextToken();
                /*var*/ let initializedInstance = this.ParseMemberAndInitializerList(newExpr, newType);
                this.ValidateToken(36/*TokenId.CloseCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.CloseCurlyBracketExpected);
                this.NextToken();
                return initializedInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(502512857203)
            
            //--TRIMMABLE-BOUNDARY-START(408023576691)
            /*Expression */ ParseMemberAndInitializerList(/*NewExpression*/ newExpr, /*Type*/ newType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023576691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let originalPos = this._token.pos;
                /*var*/ let bindingList = new ($.$$.SCG.List$$($.$sle.SLE.MemberBinding))().$ctor$1();
                /*var*/ let actions = new ($.$$.SCG.List$$($.$sle.SLE.Expression))().$ctor$1();
                /*var*/ let instance = $.$sle.SLE.Expression.Variable$1(newType);
                /*var*/ let allowCollectionInit = $.$$.SC$1.IEnumerable.$type.IsAssignableFrom(newType);
                while(true)
                {
                    if (this._token.id === 36/*TokenId.CloseCurlyBracket*/)
                    {
                        break;
                    }
                    if (this._token.id !== 2/*TokenId.Identifier*/)
                    {
                        this.ParseCollectionInitalizer(newType, originalPos, bindingList, actions, instance, allowCollectionInit);
                    }
                    else 
                    {
                        this.ParsePossibleMemberBinding(newType, bindingList, actions, instance, allowCollectionInit);
                    }
                    if (this._token.id !== 13/*TokenId.Comma*/)
                    {
                        break;
                    }
                    this.NextToken();
                }
                if (bindingList.Count === 0)
                {
                    actions.Insert(0, $.$sle.SLE.Expression.Assign(instance, newExpr));
                    actions.Add(instance);
                    return $.$sle.SLE.Expression.Block$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [instance], [-1], null), actions);
                }
                return $.$sle.SLE.Expression.MemberInit(newExpr, bindingList);
            }
            //--TRIMMABLE-BOUNDARY-END(408023576691)
            
            //--TRIMMABLE-BOUNDARY-START(442383315059)
            /*void */ ParsePossibleMemberBinding(/*Type*/ newType, /*List<MemberBinding>*/ bindingList, /*List<Expression>*/ actions, /*ParameterExpression*/ instance, /*bool*/ allowCollectionInit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383315059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken(2/*TokenId.Identifier*/, $.$HnZw.DR$2.ErrorMessages.IdentifierExpected);
                /*var*/ let propertyOrFieldName = this._token.text;
                /*var*/ let member = this._memberFinder.FindPropertyOrField(newType, propertyOrFieldName, false);
                /*var*/ let pos = this._token.pos;
                if (allowCollectionInit)
                {
                    this.NextToken();
                    if (this._token.id === 33/*TokenId.Equal*/ && $.$$.SR.MemberInfo.op_Inequality(member, null))
                    {
                        if (actions.Count > 0)
                        {
                            throw $.$HnZw.DE.ParseException.Create(pos, $.$HnZw.DR$2.ErrorMessages.InvalidInitializerMemberDeclarator, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        }
                    }
                    else if (this._token.id !== 33/*TokenId.Equal*/ || this._arguments.TryGetIdentifier(propertyOrFieldName, $.$discardRef()) || this._arguments.TryGetParameters(propertyOrFieldName, $.$discardRef()))
                    {
                        this.SetTextPos(pos);
                        this.NextToken();
                        this.ParseCollectionInitalizer(newType, pos, bindingList, actions, instance, allowCollectionInit);
                        return;
                    }
                    this.SetTextPos(pos);
                    this.NextToken();
                }
                if ($.$$.SR.MemberInfo.op_Equality(member, null))
                {
                    throw $.$HnZw.DE.ParseException.Create(pos, $.$HnZw.DR$2.ErrorMessages.UnknownPropertyOrField, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ propertyOrFieldName, $.$HnZw.DR.TypeUtils.GetTypeName(newType) ], null, null));
                }
                this.NextToken();
                this.ValidateToken(33/*TokenId.Equal*/, $.$HnZw.DR$2.ErrorMessages.EqualExpected);
                this.NextToken();
                /*var*/ let value = this.ParseExpressionSegment();
                bindingList.Add($.$sle.SLE.Expression.Bind(member, value));
            }
            //--TRIMMABLE-BOUNDARY-END(442383315059)
            
            //--TRIMMABLE-BOUNDARY-START(253404754035)
            /*void */ ParseCollectionInitalizer(/*Type*/ newType, /*int*/ originalPos, /*List<MemberBinding>*/ bindingList, /*List<Expression>*/ actions, /*ParameterExpression*/ instance, /*bool*/ allowCollectionInit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404754035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!allowCollectionInit)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.CollectionInitializationNotSupported, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ newType, $.$$.SC$1.IEnumerable.$type ], null, null));
                }
                if (bindingList.Count > 0)
                {
                    throw $.$HnZw.DE.ParseException.Create(originalPos, $.$HnZw.DR$2.ErrorMessages.InvalidInitializerMemberDeclarator, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                if (this._token.id === 35/*TokenId.OpenCurlyBracket*/)
                {
                    /*var*/ let pos = this._token.pos;
                    this.NextToken();
                    if (this._token.id === 2/*TokenId.Identifier*/)
                    {
                        /*var*/ let identifierName = this._token.text;
                        this.NextToken();
                        if (this._token.id === 33/*TokenId.Equal*/ && !this._arguments.TryGetIdentifier(identifierName, $.$discardRef()) && !this._arguments.TryGetParameters(identifierName, $.$discardRef()))
                        {
                            throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.InvalidInitializerMemberDeclarator, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        }
                        else 
                        {
                            this.SetTextPos(pos);
                            this.NextToken();
                        }
                    }
                    else 
                    {
                        this.SetTextPos(pos);
                        this.ParseExpressionSegment();
                    }
                    actions.Add(this.ParseMethodInvocation(newType, instance, this._token.pos, "Add", 35/*TokenId.OpenCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.OpenCurlyBracketExpected, 36/*TokenId.CloseCurlyBracket*/, $.$HnZw.DR$2.ErrorMessages.CloseCurlyBracketExpected));
                }
                else 
                {
                    /*var*/ let args = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [this.ParseExpressionSegment()], null, null);
                    /*var*/ let addMethod = this.ParseNormalMethodInvocation(newType, instance, this._token.pos, "Add", args);
                    if (addMethod === null)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.UnableToFindAppropriateAddMethod, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(newType) ], null, null));
                    }
                    actions.Add(addMethod);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404754035)
            
            //--TRIMMABLE-BOUNDARY-START(347894034547)
            /*Expression */ ParseLambdaInvocation(/*LambdaExpression*/ lambda, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894034547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseInvocation(lambda, errorPos, $.$HnZw.DR$2.ErrorMessages.ArgsIncompatibleWithLambda);
            }
            //--TRIMMABLE-BOUNDARY-END(347894034547)
            
            //--TRIMMABLE-BOUNDARY-START(283469525107)
            /*Expression */ ParseDelegateInvocation(/*Expression*/ delegateExp, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469525107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseInvocation(delegateExp, errorPos, $.$HnZw.DR$2.ErrorMessages.ArgsIncompatibleWithDelegate);
            }
            //--TRIMMABLE-BOUNDARY-END(283469525107)
            
            //--TRIMMABLE-BOUNDARY-START(330714165363)
            /*Expression */ ParseInvocation(/*Expression*/ expr, /*int*/ errorPos, /*string*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714165363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let args = this.ParseArgumentList();
                /*var*/ let invokeMethod = $.$HnZw.DR.MemberFinder.FindInvokeMethod(expr.Type);
                if ($.$$.SR.MethodBase.op_Inequality$1(invokeMethod, null))
                {
                    /*var*/ let invokeMethodData = $.$HnZw.DR.MethodData.Gen(invokeMethod);
                    if ($.$HnZw.DR$1.MethodResolution.CheckIfMethodIsApplicableAndPrepareIt(invokeMethodData, args))
                    {
                        return $.$sle.SLE.Expression.Invoke(expr, invokeMethodData.PromotedParameters);
                    }
                }
                throw $.$HnZw.DE.ParseException.Create(errorPos, error, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(330714165363)
            
            //--TRIMMABLE-BOUNDARY-START(412318543987)
            /*Expression */ ParseMethodGroupInvocation(/*MethodGroupExpression*/ methodGroup, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318543987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let args = this.ParseArgumentList();
                /*var*/ let usedInvokeMethod = false;
                /*var*/ let candidates = methodGroup.Overloads;
                /*var*/ let applicableMethods = $.$HnZw.DR$1.MethodResolution.FindBestMethod$1($.$sl.SL.Enumerable.Select$1($.$HnZw.D.MethodGroupExpression.Overload, $.$$.SR.MethodBase, candidates, new ($.$$.S.Func$$$($.$HnZw.D.MethodGroupExpression.Overload, $.$$.SR.MethodBase))().$ctor(this,  (/*_*/ _0) =>
                {
                    return _.Method;
                }, _29e1823d_5449_4711_9d80_5e38931f806b ??= {"r":116457473,"p":[{"n":"_","p":1355891}],"n":"","d":1683571,"h":0,"f":17825794})), args);
                if (applicableMethods.SCG$ICollection$$$Count === 0)
                {
                    usedInvokeMethod = true;
                    applicableMethods = $.$HnZw.DR$1.MethodResolution.FindBestMethod$1($.$sl.SL.Enumerable.Select$1($.$HnZw.D.MethodGroupExpression.Overload, $.$$.SR.MethodBase, candidates, new ($.$$.S.Func$$$($.$HnZw.D.MethodGroupExpression.Overload, $.$$.SR.MethodBase))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return _.InvokeMethod;
                    }, _5b4cca77_25b2_4c60_96fa_ab7e388e7b29 ??= {"r":116457473,"p":[{"n":"_","p":1355891}],"n":"","d":1683571,"h":0,"f":17825794})), args);
                }
                if (applicableMethods.SCG$ICollection$$$Count === 0)
                {
                    if ($.$sl.SL.Enumerable.Any($.$sle.SLE.Expression, args, new ($.$$.S.Func$$$($.$sle.SLE.Expression, $.$$.S.Boolean))().$ctor(this, this.IsDynamicExpression)))
                    {
                        /*var*/ let candidatesWithSameArgumentCount = $.$sl.SL.Enumerable.ToList($.$HnZw.D.MethodGroupExpression.Overload, $.$sl.SL.Enumerable.Where($.$HnZw.D.MethodGroupExpression.Overload, candidates, new ($.$$.S.Func$$$($.$HnZw.D.MethodGroupExpression.Overload, $.$$.S.Boolean))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return _.Method.GetParameters().length === args.length;
                        }, _8d14a3da_b0a3_4a4a_9940_13cb734d7748 ??= {"r":262145,"p":[{"n":"_","p":1355891}],"n":"","d":1683571,"h":0,"f":17825794})));
                        if (candidatesWithSameArgumentCount.Count === 1)
                        {
                            return this.ParseDynamicMethodGroupInvocation(candidatesWithSameArgumentCount.get_Item(0).Delegate, args);
                        }
                    }
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.ArgsIncompatibleWithDelegate, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                if (applicableMethods.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousDelegateInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                /*var*/ let applicableMethod = applicableMethods.SCG$IList$$$get_Item(0);
                /*var*/ let usedDelegate = methodGroup.FindUsedOverload(usedInvokeMethod, applicableMethod);
                return $.$sle.SLE.Expression.Invoke($.$sle.SLE.Expression.Constant$1(usedDelegate), applicableMethod.PromotedParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(412318543987)
            
            //--TRIMMABLE-BOUNDARY-START(339304099955)
            /*Type */ ParseKnownType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304099955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let name = this._token.text;
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let type;
                if (!this.TryParseKnownType(name, $.$ref(() => type, ($v) => type = $v, $.$$.S.Type)))
                {
                    throw new $.$HnZw.DE.UnknownIdentifierException().$ctor$13(name, errorPos);
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(339304099955)
            
            //--TRIMMABLE-BOUNDARY-START(528282660979)
            /*bool */ TryParseKnownType(/*string*/ name, /*out Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282660979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let originalPos = this._token.pos;
                if (this._arguments.TryGetKnownType(name, type) || this._arguments.HasKnownGenericTypeDefinition(name))
                {
                    type.$v = this.ParseKnownGenericType(name, type.$v);
                }
                type.$v = this.ParseTypeModifiers(type.$v);
                if ($.$$.S.Type.op_Equality$1(type.$v, null))
                {
                    this.SetTextPos(originalPos);
                    this.NextToken();
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(528282660979)
            
            //--TRIMMABLE-BOUNDARY-START(335009132659)
            /*Type */ ParseKnownGenericType(/*string*/ name, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009132659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NextToken();
                if (this._token.id === 20/*TokenId.LessThan*/)
                {
                    /*var*/ let typeArguments = this.ParseTypeArgumentList();
                    /*var*/ let rank = typeArguments.Count;
                    if ($.$$.S.Type.op_Equality$1(type, null) && !this._arguments.TryGetKnownType(name + `\`${rank}`, $.$ref(() => type, ($v) => type = $v, $.$$.S.Type)))
                    {
                        return null;
                    }
                    if (rank !== type.GetGenericArguments().length)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$HnZw.DR$2.ErrorMessages.GenericArgumentCountMismatch);
                    }
                    if ($.$sl.SL.Enumerable.All($.$$.S.Type, typeArguments, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return $.$$.S.Type.op_Inequality$1(_, null);
                    }, _f6eb3afb_1d66_4c1c_8854_793a51c3551f ??= {"r":262145,"p":[{"n":"_","p":188022785}],"n":"","d":1683571,"h":0,"f":17825794})))
                    {
                        type = type.MakeGenericType(typeArguments.ToArray());
                    }
                    this.NextToken();
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(335009132659)
            
            //--TRIMMABLE-BOUNDARY-START(481038020723)
            /*Type */ ParseTypeModifiers(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481038020723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(type, null))
                {
                    return null;
                }
                /*var*/ let errorPos = this._token.pos;
                if (this._token.id === 22/*TokenId.Question*/)
                {
                    if (!type.IsValueType || $.$HnZw.DR.TypeUtils.IsNullableType(type))
                    {
                        throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.TypeHasNoNullableForm, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
                    }
                    type = $.$$.S.Nullable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ type ], null, null));
                    this.NextToken();
                    type = this.ParseTypeModifiers(type);
                }
                else if (this._token.id === 23/*TokenId.OpenBracket*/)
                {
                    type = this.ParseArrayRankSpecifier(type);
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(481038020723)
            
            //--TRIMMABLE-BOUNDARY-START(240519852147)
            /*Type */ ParseArrayRankSpecifier(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519852147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(23/*TokenId.OpenBracket*/);
                /*var*/ let ranks = new ($.$sc.SCG.Stack$$($.$$.S.Int32))().$ctor$1();
                while(this._token.id === 23/*TokenId.OpenBracket*/)
                {
                    this.NextToken();
                    /*var*/ let rank = 1;
                    while(this._token.id === 13/*TokenId.Comma*/)
                    {
                        rank++;
                        this.NextToken();
                    }
                    this.ValidateToken(24/*TokenId.CloseBracket*/, $.$HnZw.DR$2.ErrorMessages.CloseBracketOrCommaExpected);
                    ranks.Push(rank);
                    this.NextToken();
                }
                while(ranks.Count > 0)
                {
                    /*var*/ let rank = ranks.Pop();
                    type = rank === 1 ? type.MakeArrayType() : type.MakeArrayType$1(rank);
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(240519852147)
            
            //--TRIMMABLE-BOUNDARY-START(468153118835)
            /*List<Type> */ ParseTypeArgumentList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153118835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken$1(20/*TokenId.LessThan*/);
                this.NextToken();
                /*List<Type>*/ let args;
                if (this._token.id === 2/*TokenId.Identifier*/)
                {
                    args = this.ParseTypeArguments();
                }
                else 
                {
                    /*var*/ let arity = this.ParseUnboundTypeArity();
                    args = new ($.$$.SCG.List$$($.$$.S.Type))().$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [arity], null));
                }
                this.ValidateToken(21/*TokenId.GreaterThan*/, $.$HnZw.DR$2.ErrorMessages.CloseTypeArgumentListExpected);
                return args;
            }
            //--TRIMMABLE-BOUNDARY-END(468153118835)
            
            //--TRIMMABLE-BOUNDARY-START(472448086131)
            /*List<Type> */ ParseTypeArguments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448086131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let genericArguments = new ($.$$.SCG.List$$($.$$.S.Type))().$ctor$1();
                while(true)
                {
                    this.ValidateToken$1(2/*TokenId.Identifier*/);
                    genericArguments.Add(this.ParseKnownType());
                    if (this._token.id !== 13/*TokenId.Comma*/)
                    {
                        break;
                    }
                    this.NextToken();
                }
                return genericArguments;
            }
            //--TRIMMABLE-BOUNDARY-END(472448086131)
            
            //--TRIMMABLE-BOUNDARY-START(498217889907)
            /*int */ ParseUnboundTypeArity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217889907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rank = 1;
                while(this._token.id === 13/*TokenId.Comma*/)
                {
                    rank++;
                    this.NextToken();
                }
                return rank;
            }
            //--TRIMMABLE-BOUNDARY-END(498217889907)
            
            //--TRIMMABLE-BOUNDARY-START(476743053427)
            /*Expression */ ParseTypeKeyword(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743053427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._token.id === 10/*TokenId.CloseParen*/)
                {
                    return $.$sle.SLE.Expression.Constant$1(type);
                }
                this.ValidateToken(16/*TokenId.Dot*/, $.$HnZw.DR$2.ErrorMessages.DotOrOpenParenExpected);
                this.NextToken();
                return this.ParseMemberAccess$1(type, null);
            }
            //--TRIMMABLE-BOUNDARY-END(476743053427)
            
            //--TRIMMABLE-BOUNDARY-START(103080898675)
            /*Expression */ GenerateConversion(/*Expression*/ expr, /*Type*/ type, /*int*/ errorPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080898675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let exprType = expr.Type;
                if ($.$$.S.Type.op_Equality$1(exprType, type))
                {
                    return expr;
                }
                if (type.ContainsGenericParameters$1)
                {
                    /*var*/ let typeDef = type.GetGenericTypeDefinition();
                    /*var*/ let interfaces = $.$sl.SL.Enumerable.ToList($.$$.S.Type, exprType.GetInterfaces());
                    for(/*var*/ let nextType = exprType.BaseType; $.$$.S.Type.op_Inequality$1(nextType, null); nextType = nextType.BaseType)
                    {
                        interfaces.Add(nextType);
                    }
                    var $en3 = interfaces.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var inherited = $en3.Current;
                        {
                            if (inherited.IsGenericType && $.$$.S.Type.op_Equality$1(inherited.GetGenericTypeDefinition(), typeDef))
                            {
                                type = inherited;
                            }
                        }
                    }
                }
                try
                {
                    let ie;
                    if ($.$is(expr, $.$HnZw.DP.InterpreterExpression, { set $v(v){ ie = v; } }))
                    {
                        return ie.EvalAs(type);
                    }
                    return $.$sle.SLE.Expression.ConvertChecked$1(expr, type);
                }
                catch($e)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.CannotConvertValue, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(exprType), $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080898675)
            
            //--TRIMMABLE-BOUNDARY-START(399433642099)
            /*Expression */ ParseMemberAccess(/*Expression*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433642099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseMemberAccess$1(null, instance);
            }
            //--TRIMMABLE-BOUNDARY-END(399433642099)
            
            //--TRIMMABLE-BOUNDARY-START(403728609395)
            /*Expression */ ParseMemberAccess$1(/*Type*/ type, /*Expression*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728609395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (instance !== null)
                {
                    type = instance.Type;
                }
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let id = this.GetIdentifier();
                this.NextToken();
                if (this._token.id === 9/*TokenId.OpenParen*/)
                {
                    return this.ParseMethodInvocation$1(type, instance, errorPos, id);
                }
                return this.GeneratePropertyOrFieldExpression(type, instance, errorPos, id);
            }
            //--TRIMMABLE-BOUNDARY-END(403728609395)
            
            //--TRIMMABLE-BOUNDARY-START(146030571635)
            /*Expression */ GeneratePropertyOrFieldExpression(/*Type*/ type, /*Expression*/ instance, /*int*/ errorPos, /*string*/ propertyOrFieldName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030571635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let member = this._memberFinder.FindPropertyOrField(type, propertyOrFieldName, instance === null);
                if ($.$$.SR.MemberInfo.op_Inequality(member, null))
                {
                    return $.$is(member, $.$$.SR.PropertyInfo) ? $.$sle.SLE.Expression.Property$3(instance, $.$cast(member, $.$$.SR.PropertyInfo)) : $.$sle.SLE.Expression.Field(instance, $.$cast(member, $.$$.SR.FieldInfo));
                }
                if ($.$HnZw.DR.TypeUtils.IsDynamicType(type) || this.IsDynamicExpression(instance))
                {
                    return this.ParseDynamicProperty(instance, propertyOrFieldName);
                }
                throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.UnknownPropertyOrField, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ propertyOrFieldName, $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(146030571635)
            
            //--TRIMMABLE-BOUNDARY-START(420908478579)
            /*Expression */ ParseMethodInvocation$1(/*Type*/ type, /*Expression*/ instance, /*int*/ errorPos, /*string*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908478579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseMethodInvocation(type, instance, errorPos, methodName, 9/*TokenId.OpenParen*/, $.$HnZw.DR$2.ErrorMessages.OpenParenExpected, 10/*TokenId.CloseParen*/, $.$HnZw.DR$2.ErrorMessages.CloseParenOrCommaExpected);
            }
            //--TRIMMABLE-BOUNDARY-END(420908478579)
            
            //--TRIMMABLE-BOUNDARY-START(416613511283)
            /*Expression */ ParseMethodInvocation(/*Type*/ type, /*Expression*/ instance, /*int*/ errorPos, /*string*/ methodName, /*TokenId*/ open, /*string*/ openExpected, /*TokenId*/ close, /*string*/ closeExpected)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613511283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let args = this.ParseArgumentList$1(open, openExpected, close, closeExpected, false);
                /*var*/ let methodInvocationExpression = this.ParseNormalMethodInvocation(type, instance, errorPos, methodName, args);
                if (methodInvocationExpression === null && instance !== null)
                {
                    methodInvocationExpression = this.ParseExtensionMethodInvocation(type, instance, errorPos, methodName, args);
                }
                if (methodInvocationExpression !== null)
                {
                    return methodInvocationExpression;
                }
                if ($.$HnZw.DR.TypeUtils.IsDynamicType(type) || this.IsDynamicExpression(instance) || $.$sl.SL.Enumerable.Any($.$sle.SLE.Expression, args, new ($.$$.S.Func$$$($.$sle.SLE.Expression, $.$$.S.Boolean))().$ctor(this, this.IsDynamicExpression)))
                {
                    return this.ParseDynamicMethodInvocation(type, instance, methodName, args);
                }
                throw new $.$HnZw.DE.NoApplicableMethodException().$ctor$13(methodName, $.$HnZw.DR.TypeUtils.GetTypeName(type), errorPos);
            }
            //--TRIMMABLE-BOUNDARY-END(416613511283)
            
            //--TRIMMABLE-BOUNDARY-START(317829263475)
            /*Expression */ ParseExtensionMethodInvocation(/*Type*/ type, /*Expression*/ instance, /*int*/ errorPos, /*string*/ methodName, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829263475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let extensionMethodsArguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), null, [((args.length + 1) | 0)], null);
                $.$$.System.Array.$WriteT1.call(extensionMethodsArguments, instance, 0);
                args.CopyTo(extensionMethodsArguments, 1);
                /*var*/ let extensionMethods = this._memberFinder.FindExtensionMethods(methodName, extensionMethodsArguments);
                if (extensionMethods.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousMethodInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ methodName, $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
                }
                if (extensionMethods.SCG$ICollection$$$Count === 1)
                {
                    /*var*/ let method = extensionMethods.SCG$IList$$$get_Item(0);
                    return $.$sle.SLE.Expression.Call($.$cast(method.MethodBase, $.$$.SR.MethodInfo), method.PromotedParameters);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(317829263475)
            
            //--TRIMMABLE-BOUNDARY-START(433793380467)
            /*Expression */ ParseNormalMethodInvocation(/*Type*/ type, /*Expression*/ instance, /*int*/ errorPos, /*string*/ methodName, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793380467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let applicableMethods = this._memberFinder.FindMethods(type, methodName, instance === null, args);
                if (applicableMethods.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousMethodInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ methodName, $.$HnZw.DR.TypeUtils.GetTypeName(type) ], null, null));
                }
                if (applicableMethods.SCG$ICollection$$$Count === 1)
                {
                    /*var*/ let method = applicableMethods.SCG$IList$$$get_Item(0);
                    return $.$sle.SLE.Expression.Call$9(instance, $.$cast(method.MethodBase, $.$$.SR.MethodInfo), method.PromotedParameters);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(433793380467)
            
            //--TRIMMABLE-BOUNDARY-START(300649394291)
            /*Expression */ ParseDynamicProperty(/*Expression*/ instance, /*string*/ propertyOrFieldName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649394291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.SLE.Expression.Dynamic$5(new $.$HnZw.DR$1.LateGetMemberCallSiteBinder().$ctor$2(propertyOrFieldName, this._arguments.ReflectionEnabled), $.$$.S.Object.$type, instance);
            }
            //--TRIMMABLE-BOUNDARY-END(300649394291)
            
            //--TRIMMABLE-BOUNDARY-START(296354426995)
            /*Expression */ ParseDynamicMethodInvocation(/*Type*/ type, /*Expression*/ instance, /*string*/ methodName, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354426995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argsDynamic = $.$sl.SL.Enumerable.ToList($.$sle.SLE.Expression, args);
                /*var*/ let isStatic = instance === null;
                argsDynamic.Insert(0, !isStatic ? instance : $.$sle.SLE.Expression.Constant$1(type));
                return $.$sle.SLE.Expression.Dynamic(new $.$HnZw.DR$1.LateInvokeMethodCallSiteBinder().$ctor$2(methodName, isStatic, this._arguments.ReflectionEnabled), $.$$.S.Object.$type, argsDynamic);
            }
            //--TRIMMABLE-BOUNDARY-END(296354426995)
            
            //--TRIMMABLE-BOUNDARY-START(292059459699)
            /*Expression */ ParseDynamicMethodGroupInvocation(/*Delegate*/ delegate, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059459699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argsDynamic = $.$sl.SL.Enumerable.ToList($.$sle.SLE.Expression, args);
                argsDynamic.Insert(0, $.$sle.SLE.Expression.Constant$1(delegate));
                return $.$sle.SLE.Expression.Dynamic(new $.$HnZw.DR$1.LateInvokeDelegateCallSiteBinder().$ctor$2(), $.$$.S.Object.$type, argsDynamic);
            }
            //--TRIMMABLE-BOUNDARY-END(292059459699)
            
            //--TRIMMABLE-BOUNDARY-START(287764492403)
            static /*Expression */ ParseDynamicIndex(/*Expression*/ instance, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764492403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argsDynamic = $.$sl.SL.Enumerable.ToList($.$sle.SLE.Expression, args);
                argsDynamic.Insert(0, instance);
                return $.$sle.SLE.Expression.Dynamic(new $.$HnZw.DR$1.LateGetIndexCallSiteBinder().$ctor$2(), $.$$.S.Object.$type, argsDynamic);
            }
            //--TRIMMABLE-BOUNDARY-END(287764492403)
            
            //--TRIMMABLE-BOUNDARY-START(231929917555)
            /*Expression[] */ ParseArgumentList$1(/*TokenId*/ openToken, /*string*/ missingOpenTokenMsg, /*TokenId*/ closeToken, /*string*/ missingCloseTokenMsg, /*bool*/ allowTrailingComma)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929917555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken(openToken, missingOpenTokenMsg);
                this.NextToken();
                /*var*/ let argList = new ($.$$.SCG.List$$($.$sle.SLE.Expression))().$ctor$1();
                while(this._token.id !== closeToken)
                {
                    argList.Add(this.ParseExpressionSegment());
                    if (this._token.id !== 13/*TokenId.Comma*/)
                    {
                        break;
                    }
                    this.NextToken();
                    if (!allowTrailingComma && this._token.id === closeToken)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._token.pos, missingCloseTokenMsg, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                }
                this.ValidateToken(closeToken, missingCloseTokenMsg);
                this.NextToken();
                return argList.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(231929917555)
            
            //--TRIMMABLE-BOUNDARY-START(227634950259)
            /*Expression[] */ ParseArgumentList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634950259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseArgumentList$1(9/*TokenId.OpenParen*/, $.$HnZw.DR$2.ErrorMessages.OpenParenExpected, 10/*TokenId.CloseParen*/, $.$HnZw.DR$2.ErrorMessages.CloseParenOrCommaExpected, false);
            }
            //--TRIMMABLE-BOUNDARY-END(227634950259)
            
            //--TRIMMABLE-BOUNDARY-START(304944361587)
            /*Expression */ ParseElementAccess(/*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944361587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let args = this.ParseArgumentList$1(23/*TokenId.OpenBracket*/, $.$HnZw.DR$2.ErrorMessages.OpenParenExpected, 24/*TokenId.CloseBracket*/, $.$HnZw.DR$2.ErrorMessages.CloseBracketOrCommaExpected, false);
                if (expr.Type.IsArray)
                {
                    if (expr.Type.GetArrayRank() !== args.length)
                    {
                        throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.IncorrectNumberOfIndexes, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    for(/*var*/ let i = 0; i < args.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(args, $.$HnZw.DR$1.ExpressionUtils.PromoteExpression($.$$.System.Array.$ReadT1.call(args, i), $.$$.S.Int32.$type), i);
                        if ($.$$.System.Array.$ReadT1.call(args, i) === null)
                        {
                            throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.InvalidIndex, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        }
                    }
                    return $.$sle.SLE.Expression.ArrayAccess$1(expr, args);
                }
                if ($.$HnZw.DR.TypeUtils.IsDynamicType(expr.Type) || this.IsDynamicExpression(expr))
                {
                    return $.$HnZw.DP.Parser.ParseDynamicIndex(expr, args);
                }
                /*var*/ let applicableMethods = this._memberFinder.FindIndexer(expr.Type, args);
                if (applicableMethods.SCG$ICollection$$$Count === 0)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.NoApplicableIndexer, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(expr.Type) ], null, null));
                }
                if (applicableMethods.SCG$ICollection$$$Count > 1)
                {
                    throw $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousIndexerInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$HnZw.DR.TypeUtils.GetTypeName(expr.Type) ], null, null));
                }
                /*var*/ let indexer = $.$cast(applicableMethods.SCG$IList$$$get_Item(0), $.$HnZw.DR.IndexerData);
                return $.$sle.SLE.Expression.Property$1(expr, indexer.Indexer, indexer.PromotedParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(304944361587)
            
            //--TRIMMABLE-BOUNDARY-START(188980244595)
            /*bool */ IsDynamicExpression(/*Expression*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980244595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return instance !== null && (instance.NodeType === 50/*ExpressionType.Dynamic*/ || (this._arguments.Settings.LateBindObject && $.$$.S.Type.op_Equality$1(instance.Type, $.$$.S.Object.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(188980244595)
            
            //--TRIMMABLE-BOUNDARY-START(47246323827)
            /*void */ CheckAndPromoteOperand(/*MethodBase[]*/ unarySignatures, /*ref Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246323827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let args = this.PrepareOperandArguments(unarySignatures, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [expr.$v], null, null));
                expr.$v = args.SCG$IList$$$get_Item(0);
            }
            //--TRIMMABLE-BOUNDARY-END(47246323827)
            
            //--TRIMMABLE-BOUNDARY-START(51541291123)
            /*void */ CheckAndPromoteOperands(/*MethodBase[]*/ binarySignatures, /*ref Expression*/ left, /*ref Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541291123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nonNullableLeftType;
                /*var*/ let nonNullableRightType;
                if ($.$HnZw.DR.TypeUtils.TryGetNonNullableType(left.$v.Type, $.$ref(() => nonNullableLeftType, ($v) => nonNullableLeftType = $v, $.$$.S.Type)) && $.$$.S.Type.op_Equality$1(nonNullableLeftType, right.$v.Type))
                {
                    right.$v = $.$HnZw.DP.Parser.GenerateNullableTypeConversion(right.$v);
                }
                else if ($.$HnZw.DR.TypeUtils.TryGetNonNullableType(right.$v.Type, $.$ref(() => nonNullableRightType, ($v) => nonNullableRightType = $v, $.$$.S.Type)) && $.$$.S.Type.op_Equality$1(nonNullableRightType, left.$v.Type))
                {
                    left.$v = $.$HnZw.DP.Parser.GenerateNullableTypeConversion(left.$v);
                }
                /*var*/ let args = this.PrepareOperandArguments(binarySignatures, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [left.$v, right.$v], null, null));
                left.$v = args.SCG$IList$$$get_Item(0);
                right.$v = args.SCG$IList$$$get_Item(1);
            }
            //--TRIMMABLE-BOUNDARY-END(51541291123)
            
            //--TRIMMABLE-BOUNDARY-START(506807824499)
            /*IList<Expression> */ PrepareOperandArguments(/*MethodBase[]*/ signatures, /*Expression[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807824499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let applicableMethods = $.$HnZw.DR$1.MethodResolution.FindBestMethod$1(signatures, args);
                if (applicableMethods.SCG$ICollection$$$Count === 1)
                {
                    return applicableMethods.SCG$IList$$$get_Item(0).PromotedParameters;
                }
                return args;
            }
            //--TRIMMABLE-BOUNDARY-END(506807824499)
            
            //--TRIMMABLE-BOUNDARY-START(201865146483)
            static /*bool */ IsWritable(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865146483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var indexer;
                var member;
                var prop;
                let $switch1 = expression.NodeType;
                switch($switch1)
                {
                    case 55/*ExpressionType.Index*/:
                    indexer = ($.$cast(expression, $.$sle.SLE.IndexExpression)).Indexer;
                    return $.$$.SR.PropertyInfo.op_Equality$1(indexer, null) || indexer.CanWrite;
                    case 23/*ExpressionType.MemberAccess*/:
                    member = ($.$cast(expression, $.$sle.SLE.MemberExpression)).Member;
                    prop = $.$as(member, $.$$.SR.PropertyInfo);
                    if ($.$$.SR.PropertyInfo.op_Inequality$1(prop, null))
                    {
                        return prop.CanWrite;
                    }
                    else 
                    {
                        /*var*/ let field = $.$cast(member, $.$$.SR.FieldInfo);
                        return !(field.IsInitOnly || field.IsLiteral);
                    }
                    case 38/*ExpressionType.Parameter*/:
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(201865146483)
            
            //--TRIMMABLE-BOUNDARY-START(193275211891)
            static /*bool */ IsDynamicWritable(/*Expression*/ expression, /*out Func<Expression, Expression>*/ toWritableExpression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275211891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                toWritableExpression.$v = null;
                if (expression.NodeType !== 50/*ExpressionType.Dynamic*/)
                {
                    return false;
                }
                /*var*/ let dynamicExpression = $.$cast(expression, $.$sle.SLE.DynamicExpression);
                let convertibleBinder;
                if (!($.$is(dynamicExpression.Binder, $.$HnZw.DR$1.IConvertibleToWritableBinder, { set $v(v){ convertibleBinder = v; } })))
                {
                    return false;
                }
                toWritableExpression.$v = new ($.$$.S.Func$$$($.$sle.SLE.Expression, $.$sle.SLE.Expression))().$ctor(this,  (/*value*/ value) =>
                {
                    return $.$sle.SLE.Expression.Dynamic(convertibleBinder.DR$1$IConvertibleToWritableBinder$ToWritableBinder(), $.$$.S.Object.$type, $.$sl.SL.Enumerable.Concat($.$sle.SLE.Expression, dynamicExpression.Arguments, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [value], null, null)));
                }, _62660f65_64d4_49de_90b5_df295dd466de ??= {"r":8781861,"p":[{"n":"value","p":8781861}],"n":"","d":1683571,"h":0,"f":17825794});
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(193275211891)
            
            //--TRIMMABLE-BOUNDARY-START(107375865971)
            /*Expression */ GenerateEqual(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375865971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GenerateBinary(13/*ExpressionType.Equal*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(107375865971)
            
            //--TRIMMABLE-BOUNDARY-START(137440637043)
            /*Expression */ GenerateNotEqual(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440637043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GenerateBinary(35/*ExpressionType.NotEqual*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(137440637043)
            
            //--TRIMMABLE-BOUNDARY-START(120260767859)
            /*Expression */ GenerateGreaterThan(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260767859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(left.Type, $.$$.S.String.$type) && $.$$.S.Type.op_Equality$1(right.Type, $.$$.S.String.$type))
                {
                    return $.$sle.SLE.Expression.GreaterThan$1($.$HnZw.DP.Parser.GenerateStaticMethodCall("Compare", left, right), $.$sle.SLE.Expression.Constant$1($.$box(0, $.$$.S.Int32)));
                }
                return this.GenerateBinary(15/*ExpressionType.GreaterThan*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(120260767859)
            
            //--TRIMMABLE-BOUNDARY-START(124555735155)
            /*Expression */ GenerateGreaterThanEqual(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555735155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(left.Type, $.$$.S.String.$type) && $.$$.S.Type.op_Equality$1(right.Type, $.$$.S.String.$type))
                {
                    return $.$sle.SLE.Expression.GreaterThanOrEqual$1($.$HnZw.DP.Parser.GenerateStaticMethodCall("Compare", left, right), $.$sle.SLE.Expression.Constant$1($.$box(0, $.$$.S.Int32)));
                }
                return this.GenerateBinary(16/*ExpressionType.GreaterThanOrEqual*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(124555735155)
            
            //--TRIMMABLE-BOUNDARY-START(128850702451)
            /*Expression */ GenerateLessThan(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850702451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(left.Type, $.$$.S.String.$type) && $.$$.S.Type.op_Equality$1(right.Type, $.$$.S.String.$type))
                {
                    return $.$sle.SLE.Expression.LessThan$1($.$HnZw.DP.Parser.GenerateStaticMethodCall("Compare", left, right), $.$sle.SLE.Expression.Constant$1($.$box(0, $.$$.S.Int32)));
                }
                return this.GenerateBinary(20/*ExpressionType.LessThan*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(128850702451)
            
            //--TRIMMABLE-BOUNDARY-START(133145669747)
            /*Expression */ GenerateLessThanEqual(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145669747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Equality$1(left.Type, $.$$.S.String.$type) && $.$$.S.Type.op_Equality$1(right.Type, $.$$.S.String.$type))
                {
                    return $.$sle.SLE.Expression.LessThanOrEqual$1($.$HnZw.DP.Parser.GenerateStaticMethodCall("Compare", left, right), $.$sle.SLE.Expression.Constant$1($.$box(0, $.$$.S.Int32)));
                }
                return this.GenerateBinary(21/*ExpressionType.LessThanOrEqual*/, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(133145669747)
            
            //--TRIMMABLE-BOUNDARY-START(81606062195)
            /*Expression */ GenerateBinary(/*ExpressionType*/ binaryType, /*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606062195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsDynamicExpression(left) || this.IsDynamicExpression(right))
                {
                    return this.GenerateBinaryDynamic(binaryType, left, right);
                }
                /*var*/ let bitwiseOps = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ExpressionType), [36/*ExpressionType.Or*/, 2/*ExpressionType.And*/], null, null);
                if (left.Type.IsEnum && $.$$.S.Type.op_Equality$1(right.Type, left.Type) && $.$$.S.MemoryExtensions.Contains$1($.$sle.SLE.ExpressionType, $.$$.S.ReadOnlySpan$$($.$sle.SLE.ExpressionType).op_Implicit$1(bitwiseOps), binaryType, null))
                {
                    return this.GenerateBinaryEnums(binaryType, left, right);
                }
                /*string*/ let opName;
                /*var*/ let liftToNull = true;
                switch(binaryType)
                {
                    case 37/*ExpressionType.OrElse*/:
                    opName = "op_BitwiseOr";
                    break;
                    case 36/*ExpressionType.Or*/:
                    opName = "op_BitwiseOr";
                    break;
                    case 14/*ExpressionType.ExclusiveOr*/:
                    opName = "op_ExclusiveOr";
                    break;
                    case 3/*ExpressionType.AndAlso*/:
                    opName = "op_BitwiseAnd";
                    break;
                    case 2/*ExpressionType.And*/:
                    opName = "op_BitwiseAnd";
                    break;
                    case 0/*ExpressionType.Add*/:
                    opName = "op_Addition";
                    break;
                    case 42/*ExpressionType.Subtract*/:
                    opName = "op_Subtraction";
                    break;
                    case 26/*ExpressionType.Multiply*/:
                    opName = "op_Multiply";
                    break;
                    case 12/*ExpressionType.Divide*/:
                    opName = "op_Division";
                    break;
                    case 25/*ExpressionType.Modulo*/:
                    opName = "op_Modulus";
                    break;
                    case 41/*ExpressionType.RightShift*/:
                    opName = "op_RightShift";
                    break;
                    case 19/*ExpressionType.LeftShift*/:
                    opName = "op_LeftShift";
                    break;
                    case 13/*ExpressionType.Equal*/:
                    opName = "op_Equality";
                    liftToNull = false;
                    break;
                    case 35/*ExpressionType.NotEqual*/:
                    opName = "op_Inequality";
                    liftToNull = false;
                    break;
                    case 15/*ExpressionType.GreaterThan*/:
                    opName = "op_GreaterThan";
                    liftToNull = false;
                    break;
                    case 16/*ExpressionType.GreaterThanOrEqual*/:
                    opName = "op_GreaterThanOrEqual";
                    liftToNull = false;
                    break;
                    case 20/*ExpressionType.LessThan*/:
                    opName = "op_LessThan";
                    liftToNull = false;
                    break;
                    case 21/*ExpressionType.LessThanOrEqual*/:
                    opName = "op_LessThanOrEqual";
                    liftToNull = false;
                    break;
                    default:
                    opName = null;
                    break;
                }
                /*var*/ let applicableMethod = this.FindBinaryOperator(opName, left, right);
                if (applicableMethod === null)
                {
                    applicableMethod = this.FindBinaryOperatorWithImplicitConversion(opName, $.$ref(() => left, ($v) => left = $v, $.$sle.SLE.Expression), $.$ref(() => right, ($v) => right = $v, $.$sle.SLE.Expression));
                }
                /*MethodInfo*/ let operatorMethod = null;
                if (applicableMethod !== null)
                {
                    operatorMethod = $.$as(applicableMethod.MethodBase, $.$$.SR.MethodInfo);
                    left = applicableMethod.PromotedParameters.SCG$IList$$$get_Item(0);
                    right = applicableMethod.PromotedParameters.SCG$IList$$$get_Item(1);
                }
                return $.$sle.SLE.Expression.MakeBinary$1(binaryType, left, right, liftToNull, operatorMethod);
            }
            //--TRIMMABLE-BOUNDARY-END(81606062195)
            
            //--TRIMMABLE-BOUNDARY-START(85901029491)
            /*Expression */ GenerateBinaryDynamic(/*ExpressionType*/ binaryType, /*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901029491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (binaryType === 3/*ExpressionType.AndAlso*/ || binaryType === 37/*ExpressionType.OrElse*/)
                {
                    if (this.IsDynamicExpression(left))
                    {
                        left = $.$sle.SLE.Expression.Convert$1(left, $.$$.S.Boolean.$type);
                    }
                    if (this.IsDynamicExpression(right))
                    {
                        right = $.$sle.SLE.Expression.Convert$1(right, $.$$.S.Boolean.$type);
                    }
                    return $.$sle.SLE.Expression.MakeBinary$2(binaryType, left, right);
                }
                /*var*/ let binder = $.$mc.MCR.Binder.BinaryOperation(0/*CSharpBinderFlags.None*/, binaryType, $.$HnZw.DP.Parser.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mc.MCR.CSharpArgumentInfo), [$.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null), $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null)], [-1], null));
                return $.$sle.SLE.Expression.Dynamic$4(binder, $.$$.S.Object.$type, left, right);
            }
            //--TRIMMABLE-BOUNDARY-END(85901029491)
            
            //--TRIMMABLE-BOUNDARY-START(90195996787)
            /*Expression */ GenerateBinaryEnums(/*ExpressionType*/ binaryType, /*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195996787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let enumType = left.Type;
                /*var*/ let underlyingType = enumType.GetEnumUnderlyingType();
                left = $.$sle.SLE.Expression.Convert$1(left, underlyingType);
                right = $.$sle.SLE.Expression.Convert$1(right, underlyingType);
                /*var*/ let op = $.$sle.SLE.Expression.MakeBinary$2(binaryType, left, right);
                return $.$sle.SLE.Expression.Convert$1(op, enumType);
            }
            //--TRIMMABLE-BOUNDARY-END(90195996787)
            
            //--TRIMMABLE-BOUNDARY-START(68721160307)
            /*MethodData */ FindBinaryOperator(/*string*/ operatorName, /*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721160307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.op_Equality(operatorName, null))
                {
                    return null;
                }
                /*var*/ let errorPos = this._token.pos;
                /*var*/ let leftType = left.Type;
                /*var*/ let rightType = right.Type;
                /*ParseException*/  function CreateAmbiguousOperatorException()
                {
                    {
                        return $.$HnZw.DE.ParseException.Create(errorPos, $.$HnZw.DR$2.ErrorMessages.AmbiguousBinaryOperatorInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ operatorName, $.$HnZw.DR.TypeUtils.GetTypeName(leftType), $.$HnZw.DR.TypeUtils.GetTypeName(rightType) ], null, null));
                    }
                }
                /*var*/ let args = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [left, right], null, null);
                /*MethodData*/ let userDefinedOperator = null;
                /*var*/ let opOnLeftType = this._memberFinder.FindMethods(leftType, operatorName, true, args);
                if (opOnLeftType.SCG$ICollection$$$Count > 1)
                {
                    throw CreateAmbiguousOperatorException.call(this);
                }
                if (opOnLeftType.SCG$ICollection$$$Count === 1)
                {
                    userDefinedOperator = opOnLeftType.SCG$IList$$$get_Item(0);
                }
                if ($.$$.S.Type.op_Inequality$1(leftType, rightType))
                {
                    /*var*/ let opOnRightType = this._memberFinder.FindMethods(rightType, operatorName, true, args);
                    if (opOnRightType.SCG$ICollection$$$Count > 1)
                    {
                        throw CreateAmbiguousOperatorException.call(this);
                    }
                    /*MethodData*/ let rightOperator = null;
                    if (opOnRightType.SCG$ICollection$$$Count === 1)
                    {
                        rightOperator = opOnRightType.SCG$IList$$$get_Item(0);
                    }
                    if (userDefinedOperator !== null && rightOperator !== null && !$.$$.S.Object.ReferenceEquals(userDefinedOperator.MethodBase, rightOperator.MethodBase))
                    {
                        throw CreateAmbiguousOperatorException.call(this);
                    }
                    if (userDefinedOperator === null && rightOperator !== null)
                    {
                        userDefinedOperator = rightOperator;
                    }
                }
                return userDefinedOperator;
            }
            //--TRIMMABLE-BOUNDARY-END(68721160307)
            
            //--TRIMMABLE-BOUNDARY-START(73016127603)
            /*MethodData */ FindBinaryOperatorWithImplicitConversion(/*string*/ operatorName, /*ref Expression*/ left, /*ref Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016127603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.op_Equality(operatorName, null))
                {
                    return null;
                }
                /*var*/ let leftType = left.$v.Type;
                /*var*/ let rightType = right.$v.Type;
                /*var*/ let convertedLeft = $.$HnZw.DP.Parser.TryGenerateImplicitConversion(left.$v, rightType);
                /*var*/ let leftConvertedOperator = convertedLeft !== null ? this.FindBinaryOperator(operatorName, convertedLeft, right.$v) : null;
                /*var*/ let convertedRight = $.$HnZw.DP.Parser.TryGenerateImplicitConversion(right.$v, leftType);
                /*var*/ let rightConvertedOperator = convertedRight !== null ? this.FindBinaryOperator(operatorName, left.$v, convertedRight) : null;
                if (leftConvertedOperator !== null && rightConvertedOperator !== null && !$.$$.S.Object.ReferenceEquals(leftConvertedOperator.MethodBase, rightConvertedOperator.MethodBase))
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.AmbiguousBinaryOperatorInvocation, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ operatorName, $.$HnZw.DR.TypeUtils.GetTypeName(leftType), $.$HnZw.DR.TypeUtils.GetTypeName(rightType) ], null, null));
                }
                if (leftConvertedOperator !== null)
                {
                    left.$v = convertedLeft;
                    return leftConvertedOperator;
                }
                if (rightConvertedOperator !== null)
                {
                    right.$v = convertedRight;
                    return rightConvertedOperator;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(73016127603)
            
            //--TRIMMABLE-BOUNDARY-START(523987693683)
            static /*Expression */ TryGenerateImplicitConversion(/*Expression*/ expression, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523987693683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$HnZw.DP.Parser.HasImplicitConversion(expression.Type, type))
                {
                    return null;
                }
                return $.$sle.SLE.Expression.Convert$1(expression, type);
            }
            //--TRIMMABLE-BOUNDARY-END(523987693683)
            
            //--TRIMMABLE-BOUNDARY-START(180390310003)
            static /*bool */ HasImplicitConversion(/*Type*/ sourceType, /*Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390310003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$HnZw.DP.Parser.HasImplicitConversionOperator(sourceType, sourceType, targetType) || $.$HnZw.DP.Parser.HasImplicitConversionOperator(targetType, sourceType, targetType);
            }
            //--TRIMMABLE-BOUNDARY-END(180390310003)
            
            //--TRIMMABLE-BOUNDARY-START(184685277299)
            static /*bool */ HasImplicitConversionOperator(/*Type*/ declaringType, /*Type*/ sourceType, /*Type*/ targetType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685277299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Any($.$$.SR.MethodInfo, declaringType.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/ | 64/*BindingFlags.FlattenHierarchy*/), new ($.$$.S.Func$$$($.$$.SR.MethodInfo, $.$$.S.Boolean))().$ctor(this,  (/*method*/ method) =>
                {
                    return $.$$.S.String.op_Equality(method.Name, "op_Implicit") && $.$$.S.Type.op_Equality$1(method.ReturnType, targetType) && method.GetParameters().length === 1 && $.$$.S.Type.op_Equality$1($.$$.System.Array.$ReadT1.call(method.GetParameters(), 0).ParameterType, sourceType);
                }, _7c5d505a_6969_4759_ab9e_21dcea1ed9b3 ??= {"r":262145,"p":[{"n":"method","p":117112833}],"n":"","d":1683571,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(184685277299)
            
            //--TRIMMABLE-BOUNDARY-START(154620506227)
            static /*Expression */ GenerateStringConcat(/*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620506227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let leftObj = $.$HnZw.DP.Parser.GenerateStringConcatOperand(left);
                /*var*/ let rightObj = $.$HnZw.DP.Parser.GenerateStringConcatOperand(right);
                return $.$sle.SLE.Expression.Call$10(null, $.$HnZw.DR.ReflectionExtensions.StringConcatMethod, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [leftObj, rightObj], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(154620506227)
            
            //--TRIMMABLE-BOUNDARY-START(519692726387)
            static /*Expression */ ToStringOrNull(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519692726387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nullableExpression = $.$HnZw.DP.Parser.GenerateNullableTypeConversion(expression);
                /*var*/ let expressionTypeNullConstant = $.$sle.SLE.Expression.Constant(null, nullableExpression.Type);
                /*var*/ let stringNullConstant = $.$sle.SLE.Expression.Constant(null, $.$$.S.String.$type);
                /*Expression*/ let condition = $.$sle.SLE.Expression.Equal$1(nullableExpression, expressionTypeNullConstant);
                return $.$sle.SLE.Expression.Condition$1(condition, stringNullConstant, $.$sle.SLE.Expression.Call$14(expression, $.$HnZw.DR.ReflectionExtensions.ObjectToStringMethod));
            }
            //--TRIMMABLE-BOUNDARY-END(519692726387)
            
            //--TRIMMABLE-BOUNDARY-START(158915473523)
            static /*Expression */ GenerateStringConcatOperand(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915473523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Type.op_Inequality$1(expression.Type, $.$$.S.String.$type) ? $.$HnZw.DP.Parser.ToStringOrNull(expression) : expression;
            }
            //--TRIMMABLE-BOUNDARY-END(158915473523)
            
            //--TRIMMABLE-BOUNDARY-START(150325538931)
            static /*Expression */ GenerateStaticMethodCall(/*string*/ methodName, /*Expression*/ left, /*Expression*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325538931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let staticMethod = left.Type.GetMethod$11(methodName, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [left.Type, right.Type], null, null));
                return $.$sle.SLE.Expression.Call$10(null, staticMethod, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [left, right], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(150325538931)
            
            //--TRIMMABLE-BOUNDARY-START(515397759091)
            /*void */ SetTextPos(/*int*/ pos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397759091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._parsePosition = pos;
                this._parseChar = this._parsePosition < this._expressionTextLength ? $.$$.S.String.get_Chars.call(this._expressionText, this._parsePosition) : /*\u0000*/ 0;
            }
            //--TRIMMABLE-BOUNDARY-END(515397759091)
            
            //--TRIMMABLE-BOUNDARY-START(206160113779)
            /*void */ NextChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160113779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parsePosition < this._expressionTextLength)
                {
                    this._parsePosition++;
                }
                this._parseChar = this._parsePosition < this._expressionTextLength ? $.$$.S.String.get_Chars.call(this._expressionText, this._parsePosition) : /*\u0000*/ 0;
            }
            //--TRIMMABLE-BOUNDARY-END(206160113779)
            
            //--TRIMMABLE-BOUNDARY-START(511102791795)
            /*void */ PreviousChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511102791795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetTextPos(((this._parsePosition - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(511102791795)
            
            //--TRIMMABLE-BOUNDARY-START(210455081075)
            /*void */ NextToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455081075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while($.$$.S.Char.IsWhiteSpace$1(this._parseChar))
                {
                    this.NextChar();
                }
                /*TokenId*/ let t;
                /*var*/ let tokenPos = this._parsePosition;
                var isEscapeS;
                var isEndS;
                var isEscapeC;
                var isEndC;
                switch(this._parseChar)
                {
                    case /*!*/ 33:
                    this.NextChar();
                    if (this._parseChar === /*=*/ 61)
                    {
                        this.NextChar();
                        t = 25/*TokenId.ExclamationEqual*/;
                    }
                    else 
                    {
                        t = 7/*TokenId.Exclamation*/;
                    }
                    break;
                    case /*%*/ 37:
                    this.NextChar();
                    t = 8/*TokenId.Percent*/;
                    break;
                    case /*&*/ 38:
                    this.NextChar();
                    if (this._parseChar === /*&*/ 38)
                    {
                        this.NextChar();
                        t = 27/*TokenId.DoubleAmphersand*/;
                    }
                    else 
                    {
                        t = 26/*TokenId.Amphersand*/;
                    }
                    break;
                    case /*(*/ 40:
                    this.NextChar();
                    t = 9/*TokenId.OpenParen*/;
                    break;
                    case /*)*/ 41:
                    this.NextChar();
                    t = 10/*TokenId.CloseParen*/;
                    break;
                    case /***/ 42:
                    this.NextChar();
                    t = 11/*TokenId.Asterisk*/;
                    break;
                    case /*+*/ 43:
                    this.NextChar();
                    t = 12/*TokenId.Plus*/;
                    break;
                    case /*,*/ 44:
                    this.NextChar();
                    t = 13/*TokenId.Comma*/;
                    break;
                    case /*-*/ 45:
                    this.NextChar();
                    t = 14/*TokenId.Minus*/;
                    break;
                    case /*~*/ 126:
                    this.NextChar();
                    t = 15/*TokenId.Tilde*/;
                    break;
                    case /*.*/ 46:
                    this.NextChar();
                    if ($.$$.S.Char.IsDigit$1(this._parseChar))
                    {
                        t = 6/*TokenId.RealLiteral*/;
                        do
                        {
                            this.NextChar();
                        }
                        while($.$$.S.Char.IsDigit$1(this._parseChar));
                        if (this._parseChar === /*E*/ 69 || this._parseChar === /*e*/ 101)
                        {
                            t = 6/*TokenId.RealLiteral*/;
                            this.NextChar();
                            if (this._parseChar === /*+*/ 43 || this._parseChar === /*-*/ 45)
                            {
                                this.NextChar();
                            }
                            this.ValidateDigit();
                            do
                            {
                                this.NextChar();
                            }
                            while($.$$.S.Char.IsDigit$1(this._parseChar));
                        }
                        if (this._parseChar === /*F*/ 70 || this._parseChar === /*f*/ 102 || this._parseChar === /*M*/ 77 || this._parseChar === /*m*/ 109)
                        {
                            this.NextChar();
                        }
                        break;
                    }
                    t = 16/*TokenId.Dot*/;
                    break;
                    case /*/*/ 47:
                    this.NextChar();
                    t = 18/*TokenId.Slash*/;
                    break;
                    case /*:*/ 58:
                    this.NextChar();
                    t = 19/*TokenId.Colon*/;
                    break;
                    case /*<*/ 60:
                    this.NextChar();
                    if (this._parseChar === /*=*/ 61)
                    {
                        this.NextChar();
                        t = 28/*TokenId.LessThanEqual*/;
                    }
                    else 
                    {
                        t = 20/*TokenId.LessThan*/;
                    }
                    break;
                    case /*=*/ 61:
                    this.NextChar();
                    if (this._parseChar === /*=*/ 61)
                    {
                        this.NextChar();
                        t = 29/*TokenId.DoubleEqual*/;
                    }
                    else if (this._parseChar === /*>*/ 62)
                    {
                        this.NextChar();
                        t = 37/*TokenId.LambdaArrow*/;
                    }
                    else 
                    {
                        t = 33/*TokenId.Equal*/;
                    }
                    break;
                    case /*>*/ 62:
                    this.NextChar();
                    if (this._parseChar === /*=*/ 61)
                    {
                        this.NextChar();
                        t = 30/*TokenId.GreaterThanEqual*/;
                    }
                    else 
                    {
                        t = 21/*TokenId.GreaterThan*/;
                    }
                    break;
                    case /*?*/ 63:
                    this.NextChar();
                    if (this._parseChar === /*?*/ 63)
                    {
                        this.NextChar();
                        t = 17/*TokenId.QuestionQuestion*/;
                    }
                    else 
                    {
                        t = 22/*TokenId.Question*/;
                    }
                    break;
                    case /*[*/ 91:
                    this.NextChar();
                    t = 23/*TokenId.OpenBracket*/;
                    break;
                    case /*]*/ 93:
                    this.NextChar();
                    t = 24/*TokenId.CloseBracket*/;
                    break;
                    case /*{*/ 123:
                    this.NextChar();
                    t = 35/*TokenId.OpenCurlyBracket*/;
                    break;
                    case /*}*/ 125:
                    this.NextChar();
                    t = 36/*TokenId.CloseCurlyBracket*/;
                    break;
                    case /*|*/ 124:
                    this.NextChar();
                    if (this._parseChar === /*|*/ 124)
                    {
                        this.NextChar();
                        t = 32/*TokenId.DoubleBar*/;
                    }
                    else 
                    {
                        t = 31/*TokenId.Bar*/;
                    }
                    break;
                    case /*\"*/ 34:
                    this.NextChar();
                    isEscapeS = false;
                    isEndS = this._parseChar === /*\"*/ 34;
                    while(this._parsePosition < this._expressionTextLength && !isEndS)
                    {
                        isEscapeS = this._parseChar === /*\\*/ 92 && !isEscapeS;
                        this.NextChar();
                        isEndS = (this._parseChar === /*\"*/ 34 && !isEscapeS);
                    }
                    if (this._parsePosition === this._expressionTextLength)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._parsePosition, $.$HnZw.DR$2.ErrorMessages.UnterminatedStringLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    this.NextChar();
                    t = 4/*TokenId.StringLiteral*/;
                    break;
                    case /*'*/ 39:
                    this.NextChar();
                    isEscapeC = false;
                    isEndC = false;
                    while(this._parsePosition < this._expressionTextLength && !isEndC)
                    {
                        isEscapeC = this._parseChar === /*\\*/ 92 && !isEscapeC;
                        this.NextChar();
                        isEndC = (this._parseChar === /*'*/ 39 && !isEscapeC);
                    }
                    if (this._parsePosition === this._expressionTextLength)
                    {
                        throw $.$HnZw.DE.ParseException.Create(this._parsePosition, $.$HnZw.DR$2.ErrorMessages.UnterminatedStringLiteral, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }
                    this.NextChar();
                    t = 3/*TokenId.CharLiteral*/;
                    break;
                    case /*^*/ 94:
                    this.NextChar();
                    t = 34/*TokenId.Caret*/;
                    break;
                    default:
                    if ($.$$.S.Char.IsLetter$1(this._parseChar) || this._parseChar === /*@*/ 64 || this._parseChar === /*_*/ 95)
                    {
                        do
                        {
                            this.NextChar();
                        }
                        while($.$$.S.Char.IsLetterOrDigit$1(this._parseChar) || this._parseChar === /*_*/ 95);
                        t = 2/*TokenId.Identifier*/;
                        break;
                    }
                    if ($.$$.S.Char.IsDigit$1(this._parseChar))
                    {
                        if (this._defaultNumberType === 3/*DefaultNumberType.Single*/ || this._defaultNumberType === 4/*DefaultNumberType.Double*/ || this._defaultNumberType === 5/*DefaultNumberType.Decimal*/)
                        {
                            t = 6/*TokenId.RealLiteral*/;
                        }
                        else 
                        {
                            t = 5/*TokenId.IntegerLiteral*/;
                        }
                        /*var*/ let canBeRealLiteral = true;
                        if (this._parseChar === /*0*/ 48)
                        {
                            this.NextChar();
                            if (this._parseChar === /*x*/ 120 || this._parseChar === /*X*/ 88)
                            {
                                canBeRealLiteral = false;
                                do
                                {
                                    this.NextChar();
                                }
                                while($.$$.S.Char.IsDigit$1(this._parseChar) || (this._parseChar >= /*a*/ 97 && this._parseChar <= /*f*/ 102) || (this._parseChar >= /*A*/ 65 && this._parseChar <= /*F*/ 70));
                                this.PreviousChar();
                            }
                            else if (this._parseChar === /*b*/ 98 || this._parseChar === /*B*/ 66)
                            {
                                canBeRealLiteral = false;
                                do
                                {
                                    this.NextChar();
                                }
                                while(this._parseChar === /*0*/ 48 || this._parseChar === /*1*/ 49);
                                this.PreviousChar();
                            }
                            else 
                            {
                                this.PreviousChar();
                            }
                        }
                        do
                        {
                            this.NextChar();
                        }
                        while($.$$.S.Char.IsDigit$1(this._parseChar));
                        if (canBeRealLiteral && this._parseChar === /*.*/ 46)
                        {
                            this.NextChar();
                            if ($.$$.S.Char.IsDigit$1(this._parseChar))
                            {
                                t = 6/*TokenId.RealLiteral*/;
                                do
                                {
                                    this.NextChar();
                                }
                                while($.$$.S.Char.IsDigit$1(this._parseChar));
                            }
                            else 
                            {
                                this.PreviousChar();
                                break;
                            }
                        }
                        if (canBeRealLiteral && (this._parseChar === /*E*/ 69 || this._parseChar === /*e*/ 101))
                        {
                            t = 6/*TokenId.RealLiteral*/;
                            this.NextChar();
                            if (this._parseChar === /*+*/ 43 || this._parseChar === /*-*/ 45)
                            {
                                this.NextChar();
                            }
                            this.ValidateDigit();
                            do
                            {
                                this.NextChar();
                            }
                            while($.$$.S.Char.IsDigit$1(this._parseChar));
                        }
                        if (canBeRealLiteral && (this._parseChar === /*D*/ 68 || this._parseChar === /*d*/ 100 || this._parseChar === /*F*/ 70 || this._parseChar === /*f*/ 102 || this._parseChar === /*M*/ 77 || this._parseChar === /*m*/ 109))
                        {
                            t = 6/*TokenId.RealLiteral*/;
                            this.NextChar();
                        }
                        if (this._parseChar === /*U*/ 85 || this._parseChar === /*u*/ 117)
                        {
                            t = 5/*TokenId.IntegerLiteral*/;
                            this.NextChar();
                            if (this._parseChar === /*L*/ 76 || this._parseChar === /*l*/ 108)
                            {
                                this.NextChar();
                            }
                        }
                        else if (this._parseChar === /*L*/ 76 || this._parseChar === /*l*/ 108)
                        {
                            t = 5/*TokenId.IntegerLiteral*/;
                            this.NextChar();
                            if (this._parseChar === /*U*/ 85 || this._parseChar === /*u*/ 117)
                            {
                                this.NextChar();
                            }
                        }
                        break;
                    }
                    if (this._parsePosition === this._expressionTextLength)
                    {
                        if (this._token.id === 1/*TokenId.End*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$HnZw.DR$2.ErrorMessages.NextTokenAtEnd);
                        }
                        t = 1/*TokenId.End*/;
                        break;
                    }
                    throw $.$HnZw.DE.ParseException.Create(this._parsePosition, $.$HnZw.DR$2.ErrorMessages.InvalidCharacter, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(this._parseChar, $.$$.S.Char) ], null, null));
                }
                this._token.id = t;
                this._token.text = $.$$.S.String.Substring.call(this._expressionText, tokenPos, ((this._parsePosition - tokenPos) | 0));
                this._token.pos = tokenPos;
            }
            //--TRIMMABLE-BOUNDARY-END(210455081075)
            
            //--TRIMMABLE-BOUNDARY-START(176095342707)
            /*string */ GetIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095342707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateToken(2/*TokenId.Identifier*/, $.$HnZw.DR$2.ErrorMessages.IdentifierExpected);
                /*var*/ let id = this._token.text;
                if (id.length > 1 && $.$$.S.String.get_Chars.call(id, 0) === /*@*/ 64)
                {
                    id = $.$$.S.String.Substring$1.call(id, 1);
                }
                return id;
            }
            //--TRIMMABLE-BOUNDARY-END(176095342707)
            
            //--TRIMMABLE-BOUNDARY-START(532577628275)
            /*void */ ValidateDigit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577628275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.Char.IsDigit$1(this._parseChar))
                {
                    throw $.$HnZw.DE.ParseException.Create(this._parsePosition, $.$HnZw.DR$2.ErrorMessages.DigitExpected, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(532577628275)
            
            //--TRIMMABLE-BOUNDARY-START(536872595571)
            /*void */ ValidateToken(/*TokenId*/ t, /*string*/ errorMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872595571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._token.id !== t)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, errorMessage, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(536872595571)
            
            //--TRIMMABLE-BOUNDARY-START(541167562867)
            /*void */ ValidateToken$1(/*TokenId*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167562867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._token.id !== t)
                {
                    throw $.$HnZw.DE.ParseException.Create(this._token.pos, $.$HnZw.DR$2.ErrorMessages.SyntaxError, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(541167562867)
            
            //--TRIMMABLE-BOUNDARY-START(545462530163)
            static /*Exception */ WrapWithParseException(/*int*/ pos, /*string*/ format, /*Exception*/ ex, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462530163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DE.ParseException().$ctor$10($.$$.S.String.Format$10(format, args), pos, ex);
            }
            //--TRIMMABLE-BOUNDARY-END(545462530163)
            
            //--TRIMMABLE-BOUNDARY-START(141735604339)
            static /*Expression */ GenerateNullableTypeConversion(/*Expression*/ expr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735604339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let exprType = expr.Type;
                if (!exprType.IsValueType || $.$HnZw.DR.TypeUtils.IsNullableType(exprType))
                {
                    return expr;
                }
                /*var*/ let conversionType = $.$HnZw.DR.TypeUtils.MakeNullable(exprType);
                return $.$sle.SLE.Expression.Convert$1(expr, conversionType);
            }
            //--TRIMMABLE-BOUNDARY-END(141735604339)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361421939)
                this._token = $.$default($.$HnZw.DP.Token);
                //--TRIMMABLE-BOUNDARY-END(34361421939)
                
            }
            //--TRIMMABLE-BOUNDARY-START(38656389235)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656389235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(274879590515)
                    this.ParseCulture = $.$$.SG.CultureInfo.InvariantCulture;
                    //--TRIMMABLE-BOUNDARY-END(274879590515)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656389235)
            
            static $h = 1683571;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(219045015667),
    {
      "r": 8781861,
      "p": [
        {
          "n": "arguments",
          "p": 1552499
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1683571,
      "h": 219045015667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(219045015667),
//--TRIMMABLE-BOUNDARY-START(214750048371),
    {
      "r": 8781861,
      "n": "Parse",
      "d": 1683571,
      "h": 214750048371,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214750048371),
//--TRIMMABLE-BOUNDARY-START(313534296179),
    {
      "r": 8781861,
      "p": [
        {
          "n": "returnType",
          "p": 188022785
        }
      ],
      "n": "ParseExpressionSegment",
      "o": "@$1",
      "d": 1683571,
      "h": 313534296179,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(313534296179),
//--TRIMMABLE-BOUNDARY-START(309239328883),
    {
      "r": 8781861,
      "n": "ParseExpressionSegment",
      "d": 1683571,
      "h": 309239328883,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(309239328883),
//--TRIMMABLE-BOUNDARY-START(343599067251),
    {
      "r": 8781861,
      "n": "ParseLambdaExpression",
      "d": 1683571,
      "h": 343599067251,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343599067251),
//--TRIMMABLE-BOUNDARY-START(356483969139),
    {
      "r": $.$typeArray($.$HnZw.D.ParameterWithPosition).$h,
      "n": "ParseLambdaParameterList",
      "d": 1683571,
      "h": 356483969139,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(356483969139),
//--TRIMMABLE-BOUNDARY-START(360778936435),
    {
      "r": $.$typeArray($.$HnZw.D.ParameterWithPosition).$h,
      "n": "ParseLambdaParameters",
      "d": 1683571,
      "h": 360778936435,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360778936435),
//--TRIMMABLE-BOUNDARY-START(352189001843),
    {
      "r": 1486963,
      "n": "ParseLambdaParameter",
      "d": 1683571,
      "h": 352189001843,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352189001843),
//--TRIMMABLE-BOUNDARY-START(244814819443),
    {
      "r": 8781861,
      "n": "ParseAssignment",
      "d": 1683571,
      "h": 244814819443,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244814819443),
//--TRIMMABLE-BOUNDARY-START(261994688627),
    {
      "r": 8781861,
      "n": "ParseConditional",
      "d": 1683571,
      "h": 261994688627,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261994688627),
//--TRIMMABLE-BOUNDARY-START(270584623219),
    {
      "r": 8781861,
      "n": "ParseConditionalOr",
      "d": 1683571,
      "h": 270584623219,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270584623219),
//--TRIMMABLE-BOUNDARY-START(266289655923),
    {
      "r": 8781861,
      "n": "ParseConditionalAnd",
      "d": 1683571,
      "h": 266289655923,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266289655923),
//--TRIMMABLE-BOUNDARY-START(390843707507),
    {
      "r": 8781861,
      "n": "ParseLogicalOr",
      "d": 1683571,
      "h": 390843707507,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390843707507),
//--TRIMMABLE-BOUNDARY-START(395138674803),
    {
      "r": 8781861,
      "n": "ParseLogicalXor",
      "d": 1683571,
      "h": 395138674803,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395138674803),
//--TRIMMABLE-BOUNDARY-START(386548740211),
    {
      "r": 8781861,
      "n": "ParseLogicalAnd",
      "d": 1683571,
      "h": 386548740211,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(386548740211),
//--TRIMMABLE-BOUNDARY-START(257699721331),
    {
      "r": 8781861,
      "n": "ParseComparison",
      "d": 1683571,
      "h": 257699721331,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257699721331),
//--TRIMMABLE-BOUNDARY-START(489627955315),
    {
      "r": 8781861,
      "n": "ParseTypeTesting",
      "d": 1683571,
      "h": 489627955315,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(489627955315),
//--TRIMMABLE-BOUNDARY-START(223339982963),
    {
      "r": 8781861,
      "n": "ParseAdditive",
      "d": 1683571,
      "h": 223339982963,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223339982963),
//--TRIMMABLE-BOUNDARY-START(459563184243),
    {
      "r": 8781861,
      "n": "ParseShift",
      "d": 1683571,
      "h": 459563184243,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(459563184243),
//--TRIMMABLE-BOUNDARY-START(197570179187),
    {
      "r": 262145,
      "p": [
        {
          "n": "shiftType",
          "p": 11272229,
          "f": 2
        }
      ],
      "n": "IsShiftOperator",
      "d": 1683571,
      "h": 197570179187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570179187),
//--TRIMMABLE-BOUNDARY-START(425203445875),
    {
      "r": 8781861,
      "n": "ParseMultiplicative",
      "d": 1683571,
      "h": 425203445875,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(425203445875),
//--TRIMMABLE-BOUNDARY-START(493922922611),
    {
      "r": 8781861,
      "n": "ParseUnary",
      "d": 1683571,
      "h": 493922922611,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(493922922611),
//--TRIMMABLE-BOUNDARY-START(163210440819),
    {
      "r": 8781861,
      "p": [
        {
          "n": "unaryType",
          "p": 11272229
        },
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateUnary",
      "d": 1683571,
      "h": 163210440819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163210440819),
//--TRIMMABLE-BOUNDARY-START(171800375411),
    {
      "r": 8781861,
      "p": [
        {
          "n": "unaryType",
          "p": 11272229
        },
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateUnaryEnums",
      "d": 1683571,
      "h": 171800375411,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171800375411),
//--TRIMMABLE-BOUNDARY-START(167505408115),
    {
      "r": 8781861,
      "p": [
        {
          "n": "unaryType",
          "p": 11272229
        },
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateUnaryDynamic",
      "d": 1683571,
      "h": 167505408115,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167505408115),
//--TRIMMABLE-BOUNDARY-START(77311094899),
    {
      "r": 2273395,
      "p": [
        {
          "n": "operatorName",
          "p": 1310721
        },
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "FindUnaryOperator",
      "d": 1683571,
      "h": 77311094899,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77311094899),
//--TRIMMABLE-BOUNDARY-START(446678282355),
    {
      "r": 8781861,
      "n": "ParsePrimary",
      "d": 1683571,
      "h": 446678282355,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(446678282355),
//--TRIMMABLE-BOUNDARY-START(111670833267),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateGetNullableHasValue",
      "d": 1683571,
      "h": 111670833267,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111670833267),
//--TRIMMABLE-BOUNDARY-START(115965800563),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateGetNullableValue",
      "d": 1683571,
      "h": 115965800563,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115965800563),
//--TRIMMABLE-BOUNDARY-START(450973249651),
    {
      "r": 8781861,
      "n": "ParsePrimaryStart",
      "d": 1683571,
      "h": 450973249651,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(450973249651),
//--TRIMMABLE-BOUNDARY-START(249109786739),
    {
      "r": 8781861,
      "n": "ParseCharLiteral",
      "d": 1683571,
      "h": 249109786739,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249109786739),
//--TRIMMABLE-BOUNDARY-START(463858151539),
    {
      "r": 8781861,
      "n": "ParseStringLiteral",
      "d": 1683571,
      "h": 463858151539,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(463858151539),
//--TRIMMABLE-BOUNDARY-START(64426193011),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": 1310721
        }
      ],
      "n": "EvalEscapeStringLiteral",
      "d": 1683571,
      "h": 64426193011,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426193011),
//--TRIMMABLE-BOUNDARY-START(60131225715),
    {
      "r": 458753,
      "p": [
        {
          "n": "source",
          "p": 458753
        }
      ],
      "n": "EvalEscapeChar",
      "d": 1683571,
      "h": 60131225715,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60131225715),
//--TRIMMABLE-BOUNDARY-START(326419198067),
    {
      "r": 8781861,
      "n": "ParseIntegerLiteral",
      "d": 1683571,
      "h": 326419198067,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(326419198067),
//--TRIMMABLE-BOUNDARY-START(455268216947),
    {
      "r": 8781861,
      "n": "ParseRealLiteral",
      "d": 1683571,
      "h": 455268216947,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(455268216947),
//--TRIMMABLE-BOUNDARY-START(55836258419),
    {
      "r": 8781861,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "CreateLiteral",
      "d": 1683571,
      "h": 55836258419,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836258419),
//--TRIMMABLE-BOUNDARY-START(438088347763),
    {
      "r": 8781861,
      "n": "ParseParenExpression",
      "d": 1683571,
      "h": 438088347763,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(438088347763),
//--TRIMMABLE-BOUNDARY-START(322124230771),
    {
      "r": 8781861,
      "n": "ParseIdentifier",
      "d": 1683571,
      "h": 322124230771,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322124230771),
//--TRIMMABLE-BOUNDARY-START(485332988019),
    {
      "r": 8781861,
      "n": "ParseTypeof",
      "d": 1683571,
      "h": 485332988019,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(485332988019),
//--TRIMMABLE-BOUNDARY-START(279174557811),
    {
      "r": 8781861,
      "n": "ParseDefaultOperator",
      "d": 1683571,
      "h": 279174557811,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279174557811),
//--TRIMMABLE-BOUNDARY-START(94490964083),
    {
      "r": 8781861,
      "p": [
        {
          "n": "test",
          "p": 8781861
        },
        {
          "n": "expr1",
          "p": 8781861
        },
        {
          "n": "expr2",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "GenerateConditional",
      "d": 1683571,
      "h": 94490964083,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490964083),
//--TRIMMABLE-BOUNDARY-START(98785931379),
    {
      "r": 8781861,
      "p": [
        {
          "n": "test",
          "p": 8781861
        },
        {
          "n": "expr1",
          "p": 8781861
        },
        {
          "n": "expr2",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "GenerateConditionalDynamic",
      "d": 1683571,
      "h": 98785931379,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785931379),
//--TRIMMABLE-BOUNDARY-START(429498413171),
    {
      "r": 8781861,
      "n": "ParseNew",
      "d": 1683571,
      "h": 429498413171,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(429498413171),
//--TRIMMABLE-BOUNDARY-START(236224884851),
    {
      "r": $.$typeArray($.$sle.SLE.Expression).$h,
      "n": "ParseArrayInitializerList",
      "d": 1683571,
      "h": 236224884851,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236224884851),
//--TRIMMABLE-BOUNDARY-START(502512857203),
    {
      "r": 8781861,
      "p": [
        {
          "n": "newExpr",
          "p": 40370213
        },
        {
          "n": "newType",
          "p": 188022785
        }
      ],
      "n": "ParseWithObjectInitializer",
      "d": 1683571,
      "h": 502512857203,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(502512857203),
//--TRIMMABLE-BOUNDARY-START(408023576691),
    {
      "r": 8781861,
      "p": [
        {
          "n": "newExpr",
          "p": 40370213
        },
        {
          "n": "newType",
          "p": 188022785
        }
      ],
      "n": "ParseMemberAndInitializerList",
      "d": 1683571,
      "h": 408023576691,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(408023576691),
//--TRIMMABLE-BOUNDARY-START(442383315059),
    {
      "r": 65537,
      "p": [
        {
          "n": "newType",
          "p": 188022785
        },
        {
          "n": "bindingList",
          "p": $.$$.SCG.List$$($.$sle.SLE.MemberBinding).$h
        },
        {
          "n": "actions",
          "p": $.$$.SCG.List$$($.$sle.SLE.Expression).$h
        },
        {
          "n": "instance",
          "p": 40566821
        },
        {
          "n": "allowCollectionInit",
          "p": 262145
        }
      ],
      "n": "ParsePossibleMemberBinding",
      "d": 1683571,
      "h": 442383315059,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(442383315059),
//--TRIMMABLE-BOUNDARY-START(253404754035),
    {
      "r": 65537,
      "p": [
        {
          "n": "newType",
          "p": 188022785
        },
        {
          "n": "originalPos",
          "p": 655361
        },
        {
          "n": "bindingList",
          "p": $.$$.SCG.List$$($.$sle.SLE.MemberBinding).$h
        },
        {
          "n": "actions",
          "p": $.$$.SCG.List$$($.$sle.SLE.Expression).$h
        },
        {
          "n": "instance",
          "p": 40566821
        },
        {
          "n": "allowCollectionInit",
          "p": 262145
        }
      ],
      "n": "ParseCollectionInitalizer",
      "d": 1683571,
      "h": 253404754035,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253404754035),
//--TRIMMABLE-BOUNDARY-START(347894034547),
    {
      "r": 8781861,
      "p": [
        {
          "n": "lambda",
          "p": 38797349
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "ParseLambdaInvocation",
      "d": 1683571,
      "h": 347894034547,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347894034547),
//--TRIMMABLE-BOUNDARY-START(283469525107),
    {
      "r": 8781861,
      "p": [
        {
          "n": "delegateExp",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "ParseDelegateInvocation",
      "d": 1683571,
      "h": 283469525107,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283469525107),
//--TRIMMABLE-BOUNDARY-START(330714165363),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "error",
          "p": 1310721
        }
      ],
      "n": "ParseInvocation",
      "d": 1683571,
      "h": 330714165363,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(330714165363),
//--TRIMMABLE-BOUNDARY-START(412318543987),
    {
      "r": 8781861,
      "p": [
        {
          "n": "methodGroup",
          "p": 1290355
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "ParseMethodGroupInvocation",
      "d": 1683571,
      "h": 412318543987,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(412318543987),
//--TRIMMABLE-BOUNDARY-START(339304099955),
    {
      "r": 188022785,
      "n": "ParseKnownType",
      "d": 1683571,
      "h": 339304099955,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339304099955),
//--TRIMMABLE-BOUNDARY-START(528282660979),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785,
          "f": 2
        }
      ],
      "n": "TryParseKnownType",
      "d": 1683571,
      "h": 528282660979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(528282660979),
//--TRIMMABLE-BOUNDARY-START(335009132659),
    {
      "r": 188022785,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "ParseKnownGenericType",
      "d": 1683571,
      "h": 335009132659,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(335009132659),
//--TRIMMABLE-BOUNDARY-START(481038020723),
    {
      "r": 188022785,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "ParseTypeModifiers",
      "d": 1683571,
      "h": 481038020723,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(481038020723),
//--TRIMMABLE-BOUNDARY-START(240519852147),
    {
      "r": 188022785,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "ParseArrayRankSpecifier",
      "d": 1683571,
      "h": 240519852147,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240519852147),
//--TRIMMABLE-BOUNDARY-START(468153118835),
    {
      "r": $.$$.SCG.List$$($.$$.S.Type).$h,
      "n": "ParseTypeArgumentList",
      "d": 1683571,
      "h": 468153118835,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(468153118835),
//--TRIMMABLE-BOUNDARY-START(472448086131),
    {
      "r": $.$$.SCG.List$$($.$$.S.Type).$h,
      "n": "ParseTypeArguments",
      "d": 1683571,
      "h": 472448086131,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(472448086131),
//--TRIMMABLE-BOUNDARY-START(498217889907),
    {
      "r": 655361,
      "n": "ParseUnboundTypeArity",
      "d": 1683571,
      "h": 498217889907,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(498217889907),
//--TRIMMABLE-BOUNDARY-START(476743053427),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "ParseTypeKeyword",
      "d": 1683571,
      "h": 476743053427,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(476743053427),
//--TRIMMABLE-BOUNDARY-START(103080898675),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        },
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "errorPos",
          "p": 655361
        }
      ],
      "n": "GenerateConversion",
      "d": 1683571,
      "h": 103080898675,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080898675),
//--TRIMMABLE-BOUNDARY-START(399433642099),
    {
      "r": 8781861,
      "p": [
        {
          "n": "instance",
          "p": 8781861
        }
      ],
      "n": "ParseMemberAccess",
      "d": 1683571,
      "h": 399433642099,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(399433642099),
//--TRIMMABLE-BOUNDARY-START(403728609395),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        }
      ],
      "n": "ParseMemberAccess",
      "o": "@$1",
      "d": 1683571,
      "h": 403728609395,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(403728609395),
//--TRIMMABLE-BOUNDARY-START(146030571635),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "propertyOrFieldName",
          "p": 1310721
        }
      ],
      "n": "GeneratePropertyOrFieldExpression",
      "d": 1683571,
      "h": 146030571635,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146030571635),
//--TRIMMABLE-BOUNDARY-START(420908478579),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": "ParseMethodInvocation",
      "o": "@$1",
      "d": 1683571,
      "h": 420908478579,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(420908478579),
//--TRIMMABLE-BOUNDARY-START(416613511283),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "open",
          "p": 2011251
        },
        {
          "n": "openExpected",
          "p": 1310721
        },
        {
          "n": "close",
          "p": 2011251
        },
        {
          "n": "closeExpected",
          "p": 1310721
        }
      ],
      "n": "ParseMethodInvocation",
      "d": 1683571,
      "h": 416613511283,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(416613511283),
//--TRIMMABLE-BOUNDARY-START(317829263475),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "ParseExtensionMethodInvocation",
      "d": 1683571,
      "h": 317829263475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(317829263475),
//--TRIMMABLE-BOUNDARY-START(433793380467),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "errorPos",
          "p": 655361
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "ParseNormalMethodInvocation",
      "d": 1683571,
      "h": 433793380467,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(433793380467),
//--TRIMMABLE-BOUNDARY-START(300649394291),
    {
      "r": 8781861,
      "p": [
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "propertyOrFieldName",
          "p": 1310721
        }
      ],
      "n": "ParseDynamicProperty",
      "d": 1683571,
      "h": 300649394291,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300649394291),
//--TRIMMABLE-BOUNDARY-START(296354426995),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 188022785
        },
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "ParseDynamicMethodInvocation",
      "d": 1683571,
      "h": 296354426995,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296354426995),
//--TRIMMABLE-BOUNDARY-START(292059459699),
    {
      "r": 8781861,
      "p": [
        {
          "n": "delegate",
          "p": 66977793
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "ParseDynamicMethodGroupInvocation",
      "d": 1683571,
      "h": 292059459699,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292059459699),
//--TRIMMABLE-BOUNDARY-START(287764492403),
    {
      "r": 8781861,
      "p": [
        {
          "n": "instance",
          "p": 8781861
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "ParseDynamicIndex",
      "d": 1683571,
      "h": 287764492403,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287764492403),
//--TRIMMABLE-BOUNDARY-START(231929917555),
    {
      "r": $.$typeArray($.$sle.SLE.Expression).$h,
      "p": [
        {
          "n": "openToken",
          "p": 2011251
        },
        {
          "n": "missingOpenTokenMsg",
          "p": 1310721
        },
        {
          "n": "closeToken",
          "p": 2011251
        },
        {
          "n": "missingCloseTokenMsg",
          "p": 1310721
        },
        {
          "n": "allowTrailingComma",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "ParseArgumentList",
      "o": "@$1",
      "d": 1683571,
      "h": 231929917555,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231929917555),
//--TRIMMABLE-BOUNDARY-START(227634950259),
    {
      "r": $.$typeArray($.$sle.SLE.Expression).$h,
      "n": "ParseArgumentList",
      "d": 1683571,
      "h": 227634950259,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634950259),
//--TRIMMABLE-BOUNDARY-START(304944361587),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "ParseElementAccess",
      "d": 1683571,
      "h": 304944361587,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304944361587),
//--TRIMMABLE-BOUNDARY-START(188980244595),
    {
      "r": 262145,
      "p": [
        {
          "n": "instance",
          "p": 8781861
        }
      ],
      "n": "IsDynamicExpression",
      "d": 1683571,
      "h": 188980244595,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188980244595),
//--TRIMMABLE-BOUNDARY-START(47246323827),
    {
      "r": 65537,
      "p": [
        {
          "n": "unarySignatures",
          "p": $.$typeArray($.$$.SR.MethodBase).$h
        },
        {
          "n": "expr",
          "p": 8781861,
          "f": 4
        }
      ],
      "n": "CheckAndPromoteOperand",
      "d": 1683571,
      "h": 47246323827,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246323827),
//--TRIMMABLE-BOUNDARY-START(51541291123),
    {
      "r": 65537,
      "p": [
        {
          "n": "binarySignatures",
          "p": $.$typeArray($.$$.SR.MethodBase).$h
        },
        {
          "n": "left",
          "p": 8781861,
          "f": 4
        },
        {
          "n": "right",
          "p": 8781861,
          "f": 4
        }
      ],
      "n": "CheckAndPromoteOperands",
      "d": 1683571,
      "h": 51541291123,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541291123),
//--TRIMMABLE-BOUNDARY-START(506807824499),
    {
      "r": $.$$.SCG.IList$$($.$sle.SLE.Expression).$h,
      "p": [
        {
          "n": "signatures",
          "p": $.$typeArray($.$$.SR.MethodBase).$h
        },
        {
          "n": "args",
          "p": $.$typeArray($.$sle.SLE.Expression).$h
        }
      ],
      "n": "PrepareOperandArguments",
      "d": 1683571,
      "h": 506807824499,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(506807824499),
//--TRIMMABLE-BOUNDARY-START(201865146483),
    {
      "r": 262145,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "IsWritable",
      "d": 1683571,
      "h": 201865146483,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201865146483),
//--TRIMMABLE-BOUNDARY-START(193275211891),
    {
      "r": 262145,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        },
        {
          "n": "toWritableExpression",
          "p": $.$$.S.Func$$$($.$sle.SLE.Expression, $.$sle.SLE.Expression).$h,
          "f": 2
        }
      ],
      "n": "IsDynamicWritable",
      "d": 1683571,
      "h": 193275211891,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(193275211891),
//--TRIMMABLE-BOUNDARY-START(107375865971),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateEqual",
      "d": 1683571,
      "h": 107375865971,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107375865971),
//--TRIMMABLE-BOUNDARY-START(137440637043),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateNotEqual",
      "d": 1683571,
      "h": 137440637043,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440637043),
//--TRIMMABLE-BOUNDARY-START(120260767859),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateGreaterThan",
      "d": 1683571,
      "h": 120260767859,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260767859),
//--TRIMMABLE-BOUNDARY-START(124555735155),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateGreaterThanEqual",
      "d": 1683571,
      "h": 124555735155,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555735155),
//--TRIMMABLE-BOUNDARY-START(128850702451),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateLessThan",
      "d": 1683571,
      "h": 128850702451,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128850702451),
//--TRIMMABLE-BOUNDARY-START(133145669747),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateLessThanEqual",
      "d": 1683571,
      "h": 133145669747,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133145669747),
//--TRIMMABLE-BOUNDARY-START(81606062195),
    {
      "r": 8781861,
      "p": [
        {
          "n": "binaryType",
          "p": 11272229
        },
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateBinary",
      "d": 1683571,
      "h": 81606062195,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606062195),
//--TRIMMABLE-BOUNDARY-START(85901029491),
    {
      "r": 8781861,
      "p": [
        {
          "n": "binaryType",
          "p": 11272229
        },
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateBinaryDynamic",
      "d": 1683571,
      "h": 85901029491,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901029491),
//--TRIMMABLE-BOUNDARY-START(90195996787),
    {
      "r": 8781861,
      "p": [
        {
          "n": "binaryType",
          "p": 11272229
        },
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateBinaryEnums",
      "d": 1683571,
      "h": 90195996787,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195996787),
//--TRIMMABLE-BOUNDARY-START(68721160307),
    {
      "r": 2273395,
      "p": [
        {
          "n": "operatorName",
          "p": 1310721
        },
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "FindBinaryOperator",
      "d": 1683571,
      "h": 68721160307,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68721160307),
//--TRIMMABLE-BOUNDARY-START(73016127603),
    {
      "r": 2273395,
      "p": [
        {
          "n": "operatorName",
          "p": 1310721
        },
        {
          "n": "left",
          "p": 8781861,
          "f": 4
        },
        {
          "n": "right",
          "p": 8781861,
          "f": 4
        }
      ],
      "n": "FindBinaryOperatorWithImplicitConversion",
      "d": 1683571,
      "h": 73016127603,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016127603),
//--TRIMMABLE-BOUNDARY-START(523987693683),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": "TryGenerateImplicitConversion",
      "d": 1683571,
      "h": 523987693683,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(523987693683),
//--TRIMMABLE-BOUNDARY-START(180390310003),
    {
      "r": 262145,
      "p": [
        {
          "n": "sourceType",
          "p": 188022785
        },
        {
          "n": "targetType",
          "p": 188022785
        }
      ],
      "n": "HasImplicitConversion",
      "d": 1683571,
      "h": 180390310003,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180390310003),
//--TRIMMABLE-BOUNDARY-START(184685277299),
    {
      "r": 262145,
      "p": [
        {
          "n": "declaringType",
          "p": 188022785
        },
        {
          "n": "sourceType",
          "p": 188022785
        },
        {
          "n": "targetType",
          "p": 188022785
        }
      ],
      "n": "HasImplicitConversionOperator",
      "d": 1683571,
      "h": 184685277299,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(184685277299),
//--TRIMMABLE-BOUNDARY-START(154620506227),
    {
      "r": 8781861,
      "p": [
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateStringConcat",
      "d": 1683571,
      "h": 154620506227,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154620506227),
//--TRIMMABLE-BOUNDARY-START(519692726387),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "ToStringOrNull",
      "d": 1683571,
      "h": 519692726387,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(519692726387),
//--TRIMMABLE-BOUNDARY-START(158915473523),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "GenerateStringConcatOperand",
      "d": 1683571,
      "h": 158915473523,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158915473523),
//--TRIMMABLE-BOUNDARY-START(150325538931),
    {
      "r": 8781861,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "left",
          "p": 8781861
        },
        {
          "n": "right",
          "p": 8781861
        }
      ],
      "n": "GenerateStaticMethodCall",
      "d": 1683571,
      "h": 150325538931,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(150325538931),
//--TRIMMABLE-BOUNDARY-START(515397759091),
    {
      "r": 65537,
      "p": [
        {
          "n": "pos",
          "p": 655361
        }
      ],
      "n": "SetTextPos",
      "d": 1683571,
      "h": 515397759091,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(515397759091),
//--TRIMMABLE-BOUNDARY-START(206160113779),
    {
      "r": 65537,
      "n": "NextChar",
      "d": 1683571,
      "h": 206160113779,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206160113779),
//--TRIMMABLE-BOUNDARY-START(511102791795),
    {
      "r": 65537,
      "n": "PreviousChar",
      "d": 1683571,
      "h": 511102791795,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(511102791795),
//--TRIMMABLE-BOUNDARY-START(210455081075),
    {
      "r": 65537,
      "n": "NextToken",
      "d": 1683571,
      "h": 210455081075,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210455081075),
//--TRIMMABLE-BOUNDARY-START(176095342707),
    {
      "r": 1310721,
      "n": "GetIdentifier",
      "d": 1683571,
      "h": 176095342707,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176095342707),
//--TRIMMABLE-BOUNDARY-START(532577628275),
    {
      "r": 65537,
      "n": "ValidateDigit",
      "d": 1683571,
      "h": 532577628275,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(532577628275),
//--TRIMMABLE-BOUNDARY-START(536872595571),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 2011251
        },
        {
          "n": "errorMessage",
          "p": 1310721
        }
      ],
      "n": "ValidateToken",
      "d": 1683571,
      "h": 536872595571,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(536872595571),
//--TRIMMABLE-BOUNDARY-START(541167562867),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 2011251
        }
      ],
      "n": "ValidateToken",
      "o": "@$1",
      "d": 1683571,
      "h": 541167562867,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(541167562867),
//--TRIMMABLE-BOUNDARY-START(545462530163),
    {
      "r": 80281601,
      "p": [
        {
          "n": "pos",
          "p": 655361
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "ex",
          "p": 80281601
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "WrapWithParseException",
      "d": 1683571,
      "h": 545462530163,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(545462530163),
//--TRIMMABLE-BOUNDARY-START(141735604339),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expr",
          "p": 8781861
        }
      ],
      "n": "GenerateNullableTypeConversion",
      "d": 1683571,
      "h": 141735604339,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141735604339)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(377958805619),
    {
      "t": 87097345,
      "n": "ParseLiteralNumberStyle",
      "d": 1683571,
      "h": 377958805619,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(377958805619),
//--TRIMMABLE-BOUNDARY-START(382253772915),
    {
      "t": 87097345,
      "n": "ParseLiteralUnsignedNumberStyle",
      "d": 1683571,
      "h": 382253772915,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(382253772915),
//--TRIMMABLE-BOUNDARY-START(373663838323),
    {
      "t": 87097345,
      "n": "ParseLiteralHexNumberStyle",
      "d": 1683571,
      "h": 373663838323,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(373663838323),
//--TRIMMABLE-BOUNDARY-START(365073903731),
    {
      "t": 87097345,
      "n": "ParseLiteralDecimalNumberStyle",
      "d": 1683571,
      "h": 365073903731,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(365073903731),
//--TRIMMABLE-BOUNDARY-START(369368871027),
    {
      "t": 87097345,
      "n": "ParseLiteralDoubleNumberStyle",
      "d": 1683571,
      "h": 369368871027,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(369368871027),
//--TRIMMABLE-BOUNDARY-START(274879590515),
    {
      "t": 84213761,
      "n": "ParseCulture",
      "d": 1683571,
      "h": 274879590515,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(274879590515),
//--TRIMMABLE-BOUNDARY-START(4296650867),
    {
      "t": 1552499,
      "n": "_arguments",
      "d": 1683571,
      "h": 4296650867,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296650867),
//--TRIMMABLE-BOUNDARY-START(30066454643),
    {
      "t": 655361,
      "n": "_parsePosition",
      "d": 1683571,
      "h": 30066454643,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066454643),
//--TRIMMABLE-BOUNDARY-START(12886585459),
    {
      "t": 1310721,
      "n": "_expressionText",
      "d": 1683571,
      "h": 12886585459,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886585459),
//--TRIMMABLE-BOUNDARY-START(17181552755),
    {
      "t": 655361,
      "n": "_expressionTextLength",
      "d": 1683571,
      "h": 17181552755,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181552755),
//--TRIMMABLE-BOUNDARY-START(25771487347),
    {
      "t": 458753,
      "n": "_parseChar",
      "d": 1683571,
      "h": 25771487347,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771487347),
//--TRIMMABLE-BOUNDARY-START(34361421939),
    {
      "t": 1945715,
      "n": "_token",
      "d": 1683571,
      "h": 34361421939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361421939),
//--TRIMMABLE-BOUNDARY-START(21476520051),
    {
      "t": 2207859,
      "n": "_memberFinder",
      "d": 1683571,
      "h": 21476520051,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476520051),
//--TRIMMABLE-BOUNDARY-START(8591618163),
    {
      "t": 176243,
      "n": "_defaultNumberType",
      "d": 1683571,
      "h": 8591618163,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591618163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951356531),
    {
      "p": [
        {
          "n": "arguments",
          "p": 1552499
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1683571,
      "h": 42951356531,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951356531)
  ],
  "h": 1683571
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.Parser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}Parser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1683571)
        
        

        //--TRIMMABLE-BOUNDARY-START(1945715)
        $asm.$str(`$HnZw.DP.Token`, ($self) => class Token extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591880307)
            /*TokenId*/  get id() { return this.$getField(0, 4); }
            /*TokenId*/  set id(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591880307)
            
            //--TRIMMABLE-BOUNDARY-START(17181814899)
            /*string*/  get text() { return this.$getField(4, 4); }
            /*string*/  set text(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17181814899)
            
            //--TRIMMABLE-BOUNDARY-START(12886847603)
            /*int*/  get pos() { return this.$getField(8, 4); }
            /*int*/  set pos(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886847603)
            
            //--TRIMMABLE-BOUNDARY-START(4296913011)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296913011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296913011)
            
            //--TRIMMABLE-BOUNDARY-START(4296913011)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296913011)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.id = this.id;
                copy.text = this.text;
                copy.pos = this.pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591880307)
                this.id = 0;
                //--TRIMMABLE-BOUNDARY-END(8591880307)
                
                //--TRIMMABLE-BOUNDARY-START(17181814899)
                this.text = null;
                //--TRIMMABLE-BOUNDARY-END(17181814899)
                
                //--TRIMMABLE-BOUNDARY-START(12886847603)
                this.pos = 0;
                //--TRIMMABLE-BOUNDARY-END(12886847603)
                
            }
            static $h = 1945715;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591880307),
    {
      "t": 2011251,
      "n": "id",
      "d": 1945715,
      "h": 8591880307,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591880307),
//--TRIMMABLE-BOUNDARY-START(17181814899),
    {
      "t": 1310721,
      "n": "text",
      "d": 1945715,
      "h": 17181814899,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181814899),
//--TRIMMABLE-BOUNDARY-START(12886847603),
    {
      "t": 655361,
      "n": "pos",
      "d": 1945715,
      "h": 12886847603,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886847603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296913011),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1945715,
      "h": 4296913011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296913011)
  ],
  "h": 1945715
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.Token`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}Token`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1945715)
        
        

        //--TRIMMABLE-BOUNDARY-START(3453043)
        $asm.$cls(`$HnZw.DV.DisableReflectionVisitor`, ($self) => class DisableReflectionVisitor extends $.$sle.SLE.ExpressionVisitor
        {
            //--TRIMMABLE-BOUNDARY-START(12888354931)
            /*Expression */ VisitMethodCall(/*MethodCallExpression*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888354931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (node.Object !== null && ($.$$.S.Type.$type.IsAssignableFrom(node.Object.Type) || $.$$.SR.MemberInfo.$type.IsAssignableFrom(node.Object.Type)))
                {
                    throw new $.$HnZw.DE.ReflectionNotAllowedException().$ctor$12();
                }
                return super.VisitMethodCall(node);
            }
            //--TRIMMABLE-BOUNDARY-END(12888354931)
            
            //--TRIMMABLE-BOUNDARY-START(8593387635)
            /*Expression */ VisitMember(/*MemberExpression*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593387635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (($.$$.S.Type.$type.IsAssignableFrom(node.Member.DeclaringType) || $.$$.SR.MemberInfo.$type.IsAssignableFrom(node.Member.DeclaringType)) && $.$$.S.String.op_Inequality(node.Member.Name, "Name"))
                {
                    throw new $.$HnZw.DE.ReflectionNotAllowedException().$ctor$12();
                }
                return super.VisitMember(node);
            }
            //--TRIMMABLE-BOUNDARY-END(8593387635)
            
            //--TRIMMABLE-BOUNDARY-START(4298420339)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298420339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298420339)
            
            //--TRIMMABLE-BOUNDARY-START(4298420339)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298420339)
            
            static $h = 3453043;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 11337765,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888354931),
    {
      "r": 8781861,
      "p": [
        {
          "n": "node",
          "p": 39649317
        }
      ],
      "n": "VisitMethodCall",
      "d": 3453043,
      "h": 12888354931,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888354931),
//--TRIMMABLE-BOUNDARY-START(8593387635),
    {
      "r": 8781861,
      "p": [
        {
          "n": "node",
          "p": 39321637
        }
      ],
      "n": "VisitMember",
      "d": 3453043,
      "h": 8593387635,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593387635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298420339),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3453043,
      "h": 4298420339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298420339)
  ],
  "h": 3453043
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SLE.ExpressionVisitor; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Visitors.DisableReflectionVisitor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Visitors${separator}DisableReflectionVisitor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3453043)
        
        

        //--TRIMMABLE-BOUNDARY-START(1618035)
        $asm.$cls(`$HnZw.DP.InterpreterExpression`, ($self) => class InterpreterExpression extends $.$sle.SLE.Expression
        {
            //--TRIMMABLE-BOUNDARY-START(8591552627)
            /*Interpreter*/ _interpreter = null;
            //--TRIMMABLE-BOUNDARY-END(8591552627)
            
            //--TRIMMABLE-BOUNDARY-START(4296585331)
            /*string*/ _expressionText = null;
            //--TRIMMABLE-BOUNDARY-END(4296585331)
            
            //--TRIMMABLE-BOUNDARY-START(12886519923)
            /*IList<Parameter>*/ _parameters = null;
            //--TRIMMABLE-BOUNDARY-END(12886519923)
            
            //--TRIMMABLE-BOUNDARY-START(17181487219)
            /*Type*/ _type = null;
            //--TRIMMABLE-BOUNDARY-END(17181487219)
            
            //--TRIMMABLE-BOUNDARY-START(21476454515)
            $ctor$3(/*ParserArguments*/ parserArguments, /*string*/ expressionText, /*params ParameterWithPosition[]*/ parameters)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476454515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = parserArguments.Settings.Clone();
                    this._interpreter = new $.$HnZw.D.Interpreter().$ctor$3(settings);
                    this._expressionText = expressionText;
                    this._parameters = parameters;
                    var $en3 = parserArguments.DeclaredParameters.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        var dp = $en3.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let pe;
                            parserArguments.TryGetParameters(dp.Name, $.$ref(() => pe, ($v) => pe = $v, $.$sle.SLE.ParameterExpression));
                            this._interpreter.SetIdentifier(new $.$HnZw.D.Identifier().$ctor$1(dp.Name, pe));
                        }
                    }
                    let $i1 = 0;
                    let $arr1 = parameters;
                    while ($i1 < $arr1.length)
                    {
                        let myParameter = $arr1[$i1++];
                        if (settings.Identifiers.SCG$IDictionary$$$$ContainsKey(myParameter.Name))
                        {
                            throw new $.$HnZw.DE.ParseException().$ctor$11($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.DuplicateLocalParameterDeclaration, myParameter.Name), myParameter.Position);
                        }
                    }
                    this._type = $.$HnZw.DR.ReflectionExtensions.GetFuncType(parameters.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476454515)
            
            //--TRIMMABLE-BOUNDARY-START(51541225587)
            /*IList<Parameter> */ get Parameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361356403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parameters;
            }
            //--TRIMMABLE-BOUNDARY-END(51541225587)
            
            //--TRIMMABLE-BOUNDARY-START(55836192883)
            /*Type */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951290995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type;
            }
            //--TRIMMABLE-BOUNDARY-END(55836192883)
            
            //--TRIMMABLE-BOUNDARY-START(25771421811)
            /*LambdaExpression */ EvalAs(/*Type*/ delegateType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771421811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsCompatibleWithDelegate(delegateType))
                {
                    return null;
                }
                /*var*/ let lambdaExpr = this._interpreter.ParseAsExpression(delegateType, this._expressionText, $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$$.S.String, this._parameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Name;
                }, _b3b50399_9d76_417e_985c_a195018a83ac ??= {"r":1310721,"p":[{"n":"p","p":1421427}],"n":"","d":1618035,"h":0,"f":17825794}))));
                this._type = lambdaExpr.Type;
                return lambdaExpr;
            }
            //--TRIMMABLE-BOUNDARY-END(25771421811)
            
            //--TRIMMABLE-BOUNDARY-START(47246258291)
            /*bool */ IsCompatibleWithDelegate(/*Type*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246258291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!target.IsGenericType || $.$$.S.Type.op_Inequality$1(target.BaseType, $.$$.S.MulticastDelegate.$type))
                {
                    return false;
                }
                /*var*/ let genericTypeDefinition = target.GetGenericTypeDefinition();
                return $.$$.S.Type.op_Equality$1(genericTypeDefinition, $.$HnZw.DR.ReflectionExtensions.GetFuncType(this._parameters.SCG$ICollection$$$Count)) || $.$$.S.Type.op_Equality$1(genericTypeDefinition, $.$HnZw.DR.ReflectionExtensions.GetActionType(this._parameters.SCG$ICollection$$$Count));
            }
            //--TRIMMABLE-BOUNDARY-END(47246258291)
            
            static $h = 1618035;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 8781861,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541225587),
    {
      "p": $.$$.SCG.IList$$($.$HnZw.D.Parameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361356403,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1618035,
      "h": 51541225587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541225587),
//--TRIMMABLE-BOUNDARY-START(55836192883),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951290995,
        "f": 50364417
      },
      "n": "Type",
      "d": 1618035,
      "h": 55836192883,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836192883)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771421811),
    {
      "r": 38797349,
      "p": [
        {
          "n": "delegateType",
          "p": 188022785
        }
      ],
      "n": "EvalAs",
      "d": 1618035,
      "h": 25771421811,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771421811),
//--TRIMMABLE-BOUNDARY-START(47246258291),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 188022785
        }
      ],
      "n": "IsCompatibleWithDelegate",
      "d": 1618035,
      "h": 47246258291,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47246258291)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591552627),
    {
      "t": 1028211,
      "n": "_interpreter",
      "d": 1618035,
      "h": 8591552627,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591552627),
//--TRIMMABLE-BOUNDARY-START(4296585331),
    {
      "t": 1310721,
      "n": "_expressionText",
      "d": 1618035,
      "h": 4296585331,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296585331),
//--TRIMMABLE-BOUNDARY-START(12886519923),
    {
      "t": $.$$.SCG.IList$$($.$HnZw.D.Parameter).$h,
      "n": "_parameters",
      "d": 1618035,
      "h": 12886519923,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886519923),
//--TRIMMABLE-BOUNDARY-START(17181487219),
    {
      "t": 188022785,
      "n": "_type",
      "d": 1618035,
      "h": 17181487219,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181487219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476454515),
    {
      "p": [
        {
          "n": "parserArguments",
          "p": 1552499
        },
        {
          "n": "expressionText",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$HnZw.D.ParameterWithPosition).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1618035,
      "h": 21476454515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476454515)
  ],
  "h": 1618035
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SLE.Expression; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.InterpreterExpression`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}InterpreterExpression`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1618035)
        
        

        //--TRIMMABLE-BOUNDARY-START(1290355)
        $asm.$cls(`$HnZw.D.MethodGroupExpression`, ($self) => class MethodGroupExpression extends $.$sle.SLE.Expression
        {
            //--TRIMMABLE-BOUNDARY-START(1355891)
            static $_Overload;
            static get Overload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1355891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$HnZw.D.MethodGroupExpression;
                return $cls.$_Overload ??= $asm.$ncls(`$HnZw.D.MethodGroupExpression.Overload`, ($self) => class Overload extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21476192371)
                    /*Delegate*/ Delegate = null;
                    //--TRIMMABLE-BOUNDARY-END(21476192371)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591290483)
                    /*MethodBase*/ _method = null;
                    //--TRIMMABLE-BOUNDARY-END(8591290483)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835930739)
                    /*MethodBase */ get Method()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245996147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.SR.MethodBase.op_Equality$1(this._method, null))
                        {
                            this._method = this.Delegate.Method;
                        }
                        return this._method;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835930739)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296323187)
                    /*MethodBase*/ _invokeMethod = null;
                    //--TRIMMABLE-BOUNDARY-END(4296323187)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540963443)
                    /*MethodBase */ get InvokeMethod()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656061555);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.SR.MethodBase.op_Equality$1(this._invokeMethod, null))
                        {
                            this._invokeMethod = $.$HnZw.DR.MemberFinder.FindInvokeMethod($.$$.S.Object.GetType.call(this.Delegate));
                        }
                        return this._invokeMethod;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540963443)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181225075)
                    $ctor$1(/*Delegate*/ delegate)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181225075);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Delegate = delegate;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181225075)
                    
                    static $h = 1355891;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476192371),
    {
      "p": 66977793,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066126963,
        "f": 50331649
      },
      "n": "Delegate",
      "d": 1355891,
      "h": 21476192371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476192371),
//--TRIMMABLE-BOUNDARY-START(55835930739),
    {
      "p": 116457473,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245996147,
        "f": 50331649
      },
      "n": "Method",
      "d": 1355891,
      "h": 55835930739,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835930739),
//--TRIMMABLE-BOUNDARY-START(51540963443),
    {
      "p": 116457473,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656061555,
        "f": 50331649
      },
      "n": "InvokeMethod",
      "d": 1355891,
      "h": 51540963443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540963443)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591290483),
    {
      "t": 116457473,
      "n": "_method",
      "d": 1355891,
      "h": 8591290483,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591290483),
//--TRIMMABLE-BOUNDARY-START(4296323187),
    {
      "t": 116457473,
      "n": "_invokeMethod",
      "d": 1355891,
      "h": 4296323187,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296323187)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181225075),
    {
      "p": [
        {
          "n": "delegate",
          "p": 66977793
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1355891,
      "h": 17181225075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181225075)
  ],
  "d": 1290355,
  "h": 1355891
}; }
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `DynamicExpresso.MethodGroupExpression+Overload`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}MethodGroupExpression${separator}Overload`; }
                }, $cls, ($v) => $cls.$_Overload = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1355891)
            
            //--TRIMMABLE-BOUNDARY-START(4296257651)
            /*List<Overload>*/ _overloads = null;
            //--TRIMMABLE-BOUNDARY-END(4296257651)
            
            //--TRIMMABLE-BOUNDARY-START(34361028723)
            /*IReadOnlyCollection<Overload> */ get Overloads()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771094131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._overloads.AsReadOnly();
            }
            //--TRIMMABLE-BOUNDARY-END(34361028723)
            
            //--TRIMMABLE-BOUNDARY-START(8591224947)
            $ctor$3(/*Delegate*/ overload)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591224947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AddOverload(overload);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591224947)
            
            //--TRIMMABLE-BOUNDARY-START(12886192243)
            /*void */ AddOverload(/*Delegate*/ overload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886192243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RemoveDelegateSignature(overload);
                this._overloads.Add(new $.$HnZw.D.MethodGroupExpression.Overload().$ctor$1(overload));
            }
            //--TRIMMABLE-BOUNDARY-END(12886192243)
            
            //--TRIMMABLE-BOUNDARY-START(38655996019)
            /*void */ RemoveDelegateSignature(/*Delegate*/ overload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655996019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._overloads.RemoveAll(new ($.$$.S.Predicate$$($.$HnZw.D.MethodGroupExpression.Overload))().$ctor(this,  (/*del*/ del) =>
                {
                    return $.$HnZw.D.MethodGroupExpression.HasSameSignature(overload.Method, del.Delegate.Method);
                }, _ab9d8651_e336_4fda_ba99_9040c2c58b9f ??= {"r":262145,"p":[{"n":"del","p":1355891}],"n":"","d":1290355,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(38655996019)
            
            //--TRIMMABLE-BOUNDARY-START(30066061427)
            static /*bool */ HasSameSignature(/*MethodInfo*/ method, /*MethodInfo*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066061427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Type.op_Inequality$1(method.ReturnType, other.ReturnType))
                {
                    return false;
                }
                /*var*/ let param = method.GetParameters();
                /*var*/ let oParam = other.GetParameters();
                if (param.length !== oParam.length)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < param.length; i++)
                {
                    /*var*/ let p = $.$$.System.Array.$ReadT1.call(param, i);
                    /*var*/ let q = $.$$.System.Array.$ReadT1.call(oParam, i);
                    if ($.$$.S.Type.op_Inequality$1(p.ParameterType, q.ParameterType) || p.HasDefaultValue !== q.HasDefaultValue)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30066061427)
            
            //--TRIMMABLE-BOUNDARY-START(17181159539)
            /*Delegate */ FindUsedOverload(/*bool*/ usedInvokeMethod, /*MethodData*/ methodData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181159539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._overloads.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var overload = $en2.Current;
                    {
                        if (usedInvokeMethod)
                        {
                            if ($.$$.SR.MethodBase.op_Equality$1(methodData.MethodBase, overload.InvokeMethod))
                            {
                                return overload.Delegate;
                            }
                        }
                        else 
                        {
                            if ($.$$.SR.MethodBase.op_Equality$1(methodData.MethodBase, overload.Method))
                            {
                                return overload.Delegate;
                            }
                        }
                    }
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12("No overload matches the method");
            }
            //--TRIMMABLE-BOUNDARY-END(17181159539)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296257651)
                this._overloads = new ($.$$.SCG.List$$($.$HnZw.D.MethodGroupExpression.Overload))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296257651)
                
            }
            static $h = 1290355;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 8781861,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361028723),
    {
      "p": $.$$.SCG.IReadOnlyCollection$$($.$HnZw.D.MethodGroupExpression.Overload).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771094131,
        "f": 50331656
      },
      "n": "Overloads",
      "d": 1290355,
      "h": 34361028723,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34361028723)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886192243),
    {
      "r": 65537,
      "p": [
        {
          "n": "overload",
          "p": 66977793
        }
      ],
      "n": "AddOverload",
      "d": 1290355,
      "h": 12886192243,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886192243),
//--TRIMMABLE-BOUNDARY-START(38655996019),
    {
      "r": 65537,
      "p": [
        {
          "n": "overload",
          "p": 66977793
        }
      ],
      "n": "RemoveDelegateSignature",
      "d": 1290355,
      "h": 38655996019,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655996019),
//--TRIMMABLE-BOUNDARY-START(30066061427),
    {
      "r": 262145,
      "p": [
        {
          "n": "method",
          "p": 117112833
        },
        {
          "n": "other",
          "p": 117112833
        }
      ],
      "n": "HasSameSignature",
      "d": 1290355,
      "h": 30066061427,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066061427),
//--TRIMMABLE-BOUNDARY-START(17181159539),
    {
      "r": 66977793,
      "p": [
        {
          "n": "usedInvokeMethod",
          "p": 262145
        },
        {
          "n": "methodData",
          "p": 2273395
        }
      ],
      "n": "FindUsedOverload",
      "d": 1290355,
      "h": 17181159539,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181159539)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296257651),
    {
      "t": $.$$.SCG.List$$($.$HnZw.D.MethodGroupExpression.Overload).$h,
      "n": "_overloads",
      "d": 1290355,
      "h": 4296257651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296257651)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591224947),
    {
      "p": [
        {
          "n": "overload",
          "p": 66977793
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1290355,
      "h": 8591224947,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591224947)
  ],
  "j": [1355891
  ],
  "h": 1290355
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SLE.Expression; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.MethodGroupExpression`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}MethodGroupExpression`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1290355)
        
        

        //--TRIMMABLE-BOUNDARY-START(3190899)
        $asm.$cls(`$HnZw.DR$1.LateSetMemberCallSiteBinder`, ($self) => class LateSetMemberCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(4298158195)
            /*string*/ _propertyOrFieldName = null;
            //--TRIMMABLE-BOUNDARY-END(4298158195)
            
            //--TRIMMABLE-BOUNDARY-START(8593125491)
            /*bool*/ _reflectionEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(8593125491)
            
            //--TRIMMABLE-BOUNDARY-START(12888092787)
            $ctor$2(/*string*/ propertyOrFieldName, /*bool*/ reflectionEnabled)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888092787);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._propertyOrFieldName = propertyOrFieldName;
                    this._reflectionEnabled = reflectionEnabled;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888092787)
            
            //--TRIMMABLE-BOUNDARY-START(17183060083)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183060083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HnZw.DR$1.LateBindingSecurity.ValidateReflectionTarget($.$$.System.Array.$ReadT1.call(args, 0), this._propertyOrFieldName, this._reflectionEnabled, false);
                /*object*/ let __ca2__;
                /*var*/ let binder = $.$mc.MCR.Binder.SetMember(0/*CSharpBinderFlags.None*/, this._propertyOrFieldName, $.$HnZw.DR.TypeUtils.RemoveArrayType(((__ca2__ = $.$$.System.Array.$ReadT1.call(args, 0)) !== null ? $.$$.S.Object.GetType.call(__ca2__) : null)), $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _40379018_07b8_4128_8240_95e33b2d2dbe ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":3190899,"h":0,"f":17825794})));
                return binder.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(17183060083)
            
            static $h = 3190899;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183060083),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 3190899,
      "h": 17183060083,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183060083)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298158195),
    {
      "t": 1310721,
      "n": "_propertyOrFieldName",
      "d": 3190899,
      "h": 4298158195,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298158195),
//--TRIMMABLE-BOUNDARY-START(8593125491),
    {
      "t": 262145,
      "n": "_reflectionEnabled",
      "d": 3190899,
      "h": 8593125491,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593125491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888092787),
    {
      "p": [
        {
          "n": "propertyOrFieldName",
          "p": 1310721
        },
        {
          "n": "reflectionEnabled",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3190899,
      "h": 12888092787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888092787)
  ],
  "h": 3190899
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateSetMemberCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateSetMemberCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3190899)
        
        

        //--TRIMMABLE-BOUNDARY-START(3059827)
        $asm.$cls(`$HnZw.DR$1.LateInvokeMethodCallSiteBinder`, ($self) => class LateInvokeMethodCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(8592994419)
            /*string*/ _methodName = null;
            //--TRIMMABLE-BOUNDARY-END(8592994419)
            
            //--TRIMMABLE-BOUNDARY-START(4298027123)
            /*bool*/ _isStatic = false;
            //--TRIMMABLE-BOUNDARY-END(4298027123)
            
            //--TRIMMABLE-BOUNDARY-START(12887961715)
            /*bool*/ _reflectionEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(12887961715)
            
            //--TRIMMABLE-BOUNDARY-START(17182929011)
            $ctor$2(/*string*/ methodName, /*bool*/ isStatic, /*bool*/ reflectionEnabled)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182929011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._methodName = methodName;
                    this._isStatic = isStatic;
                    this._reflectionEnabled = reflectionEnabled;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182929011)
            
            //--TRIMMABLE-BOUNDARY-START(21477896307)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477896307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isStatic)
                {
                    $.$HnZw.DR$1.LateBindingSecurity.ValidateReflectionTarget($.$$.System.Array.$ReadT1.call(args, 0), this._methodName, this._reflectionEnabled, false);
                }
                /*object*/ let __ca3__;
                /*var*/ let context = this._isStatic ? $.$cast($.$$.System.Array.$ReadT1.call(args, 0), $.$$.S.Type) : ((__ca3__ = $.$$.System.Array.$ReadT1.call(args, 0)) !== null ? $.$$.S.Object.GetType.call(__ca3__) : null);
                /*var*/ let argumentInfo = $.$sl.SL.Enumerable.ToArray($.$mc.MCR.CSharpArgumentInfo, $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _3d723f97_1418_4b17_af52_f889b6f84063 ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":3059827,"h":0,"f":17825794})));
                if (this._isStatic)
                {
                    $.$$.System.Array.$WriteT1.call(argumentInfo, $.$mc.MCR.CSharpArgumentInfo.Create(1/*CSharpArgumentInfoFlags.UseCompileTimeType*/ | 32/*CSharpArgumentInfoFlags.IsStaticType*/, null), 0);
                }
                /*var*/ let binderM = $.$mc.MCR.Binder.InvokeMember(0/*CSharpBinderFlags.None*/, this._methodName, null, $.$HnZw.DR.TypeUtils.RemoveArrayType(context), argumentInfo);
                return binderM.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(21477896307)
            
            static $h = 3059827;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477896307),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 3059827,
      "h": 21477896307,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477896307)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592994419),
    {
      "t": 1310721,
      "n": "_methodName",
      "d": 3059827,
      "h": 8592994419,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592994419),
//--TRIMMABLE-BOUNDARY-START(4298027123),
    {
      "t": 262145,
      "n": "_isStatic",
      "d": 3059827,
      "h": 4298027123,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298027123),
//--TRIMMABLE-BOUNDARY-START(12887961715),
    {
      "t": 262145,
      "n": "_reflectionEnabled",
      "d": 3059827,
      "h": 12887961715,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887961715)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182929011),
    {
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "isStatic",
          "p": 262145
        },
        {
          "n": "reflectionEnabled",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3059827,
      "h": 17182929011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182929011)
  ],
  "h": 3059827
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateInvokeMethodCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateInvokeMethodCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3059827)
        
        

        //--TRIMMABLE-BOUNDARY-START(2994291)
        $asm.$cls(`$HnZw.DR$1.LateInvokeDelegateCallSiteBinder`, ($self) => class LateInvokeDelegateCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(4297961587)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297961587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297961587)
            
            //--TRIMMABLE-BOUNDARY-START(8592928883)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592928883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let argumentInfo = $.$sl.SL.Enumerable.ToArray($.$mc.MCR.CSharpArgumentInfo, $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _600cb916_c407_420b_afaa_7467aaabab50 ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":2994291,"h":0,"f":17825794})));
                $.$$.System.Array.$WriteT1.call(argumentInfo, $.$mc.MCR.CSharpArgumentInfo.Create(1/*CSharpArgumentInfoFlags.UseCompileTimeType*/, null), 0);
                /*var*/ let binderM = $.$mc.MCR.Binder.Invoke(0/*CSharpBinderFlags.None*/, null, argumentInfo);
                return binderM.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(8592928883)
            
            //--TRIMMABLE-BOUNDARY-START(4297961587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297961587)
            
            static $h = 2994291;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592928883),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 2994291,
      "h": 8592928883,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592928883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297961587),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2994291,
      "h": 4297961587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297961587)
  ],
  "h": 2994291
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateInvokeDelegateCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateInvokeDelegateCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2994291)
        
        

        //--TRIMMABLE-BOUNDARY-START(3125363)
        $asm.$cls(`$HnZw.DR$1.LateSetIndexCallSiteBinder`, ($self) => class LateSetIndexCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(8593059955)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593059955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let __ca5__;
                /*var*/ let binder = $.$mc.MCR.Binder.SetIndex(0/*CSharpBinderFlags.None*/, $.$HnZw.DR.TypeUtils.RemoveArrayType(((__ca5__ = $.$$.System.Array.$ReadT1.call(args, 0)) !== null ? $.$$.S.Object.GetType.call(__ca5__) : null)), $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _1b970076_2302_41ca_bf55_1f10d3d4a281 ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":3125363,"h":0,"f":17825794})));
                return binder.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(8593059955)
            
            //--TRIMMABLE-BOUNDARY-START(4298092659)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298092659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298092659)
            
            //--TRIMMABLE-BOUNDARY-START(4298092659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298092659)
            
            static $h = 3125363;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593059955),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 3125363,
      "h": 8593059955,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593059955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298092659),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3125363,
      "h": 4298092659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298092659)
  ],
  "h": 3125363
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateSetIndexCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateSetIndexCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3125363)
        
        

        //--TRIMMABLE-BOUNDARY-START(2928755)
        $asm.$cls(`$HnZw.DR$1.LateGetMemberCallSiteBinder`, ($self) => class LateGetMemberCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(4297896051)
            /*string*/ _propertyOrFieldName = null;
            //--TRIMMABLE-BOUNDARY-END(4297896051)
            
            //--TRIMMABLE-BOUNDARY-START(8592863347)
            /*bool*/ _reflectionEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(8592863347)
            
            //--TRIMMABLE-BOUNDARY-START(12887830643)
            $ctor$2(/*string*/ propertyOrFieldName, /*bool*/ reflectionEnabled)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887830643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._propertyOrFieldName = propertyOrFieldName;
                    this._reflectionEnabled = reflectionEnabled;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887830643)
            
            //--TRIMMABLE-BOUNDARY-START(17182797939)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182797939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$HnZw.DR$1.LateBindingSecurity.ValidateReflectionTarget($.$$.System.Array.$ReadT1.call(args, 0), this._propertyOrFieldName, this._reflectionEnabled, true);
                /*object*/ let __ca1__;
                /*var*/ let binder = $.$mc.MCR.Binder.GetMember(0/*CSharpBinderFlags.None*/, this._propertyOrFieldName, $.$HnZw.DR.TypeUtils.RemoveArrayType(((__ca1__ = $.$$.System.Array.$ReadT1.call(args, 0)) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null)), $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _5779fa67_2447_4b53_8278_3e8d37eb169c ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":2928755,"h":0,"f":17825794})));
                return binder.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(17182797939)
            
            //--TRIMMABLE-BOUNDARY-START(21477765235)
            /*CallSiteBinder */ ToWritableBinder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477765235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DR$1.LateSetMemberCallSiteBinder().$ctor$2(this._propertyOrFieldName, this._reflectionEnabled);
            }
            //--TRIMMABLE-BOUNDARY-END(21477765235)
            
            //--TRIMMABLE-BOUNDARY-START(4297699443)
            //Generated interface implemetation for DynamicExpresso.Resolution.IConvertibleToWritableBinder.ToWritableBinder()
            DR$1$IConvertibleToWritableBinder$ToWritableBinder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297699443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToWritableBinder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297699443)
            
            static $h = 2928755;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182797939),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 2928755,
      "h": 17182797939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182797939),
//--TRIMMABLE-BOUNDARY-START(21477765235),
    {
      "r": 42860581,
      "n": "ToWritableBinder",
      "d": 2928755,
      "h": 21477765235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477765235)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297896051),
    {
      "t": 1310721,
      "n": "_propertyOrFieldName",
      "d": 2928755,
      "h": 4297896051,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297896051),
//--TRIMMABLE-BOUNDARY-START(8592863347),
    {
      "t": 262145,
      "n": "_reflectionEnabled",
      "d": 2928755,
      "h": 8592863347,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592863347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887830643),
    {
      "p": [
        {
          "n": "propertyOrFieldName",
          "p": 1310721
        },
        {
          "n": "reflectionEnabled",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2928755,
      "h": 12887830643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887830643)
  ],
  "i": [2732147
  ],
  "h": 2928755
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$HnZw.DR$1.IConvertibleToWritableBinder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateGetMemberCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateGetMemberCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2928755)
        
        

        //--TRIMMABLE-BOUNDARY-START(2863219)
        $asm.$cls(`$HnZw.DR$1.LateGetIndexCallSiteBinder`, ($self) => class LateGetIndexCallSiteBinder extends $.$sle.SRC.CallSiteBinder
        {
            //--TRIMMABLE-BOUNDARY-START(8592797811)
            /*Expression */ Bind(/*object[]*/ args, /*ReadOnlyCollection<ParameterExpression>*/ parameters, /*LabelTarget*/ returnLabel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592797811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let __ca4__;
                /*var*/ let binder = $.$mc.MCR.Binder.GetIndex(0/*CSharpBinderFlags.None*/, $.$HnZw.DR.TypeUtils.RemoveArrayType(((__ca4__ = $.$$.System.Array.$ReadT1.call(args, 0)) !== null ? $.$$.S.Object.GetType.call(__ca4__) : null)), $.$sl.SL.Enumerable.Select$1($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo, parameters, new ($.$$.S.Func$$$($.$sle.SLE.ParameterExpression, $.$mc.MCR.CSharpArgumentInfo))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mc.MCR.CSharpArgumentInfo.Create(0/*CSharpArgumentInfoFlags.None*/, null);
                }, _3e7954bb_9efc_4322_b134_25dd7b064dd2 ??= {"r":393288,"p":[{"n":"x","p":40566821}],"n":"","d":2863219,"h":0,"f":17825794})));
                return binder.Bind(args, parameters, returnLabel);
            }
            //--TRIMMABLE-BOUNDARY-END(8592797811)
            
            //--TRIMMABLE-BOUNDARY-START(12887765107)
            /*CallSiteBinder */ ToWritableBinder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887765107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DR$1.LateSetIndexCallSiteBinder().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887765107)
            
            //--TRIMMABLE-BOUNDARY-START(4297699443)
            //Generated interface implemetation for DynamicExpresso.Resolution.IConvertibleToWritableBinder.ToWritableBinder()
            DR$1$IConvertibleToWritableBinder$ToWritableBinder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297699443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToWritableBinder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297699443)
            
            //--TRIMMABLE-BOUNDARY-START(4297830515)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297830515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297830515)
            
            //--TRIMMABLE-BOUNDARY-START(4297830515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297830515)
            
            static $h = 2863219;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 42860581,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592797811),
    {
      "r": 8781861,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "parameters",
          "p": $.$$.SCO.ReadOnlyCollection$$($.$sle.SLE.ParameterExpression).$h
        },
        {
          "n": "returnLabel",
          "p": 38731813
        }
      ],
      "n": "Bind",
      "d": 2863219,
      "h": 8592797811,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592797811),
//--TRIMMABLE-BOUNDARY-START(12887765107),
    {
      "r": 42860581,
      "n": "ToWritableBinder",
      "d": 2863219,
      "h": 12887765107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887765107)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297830515),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2863219,
      "h": 4297830515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297830515)
  ],
  "i": [2732147
  ],
  "h": 2863219
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$sle.SRC.CallSiteBinder; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$HnZw.DR$1.IConvertibleToWritableBinder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Resolution.LateGetIndexCallSiteBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Resolution${separator}LateGetIndexCallSiteBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2863219)
        
        

        //--TRIMMABLE-BOUNDARY-START(2470003)
        $asm.$cls(`$HnZw.DR.SimpleMethodSignature`, ($self) => class SimpleMethodSignature extends $.$$.SR.MethodBase
        {
            //--TRIMMABLE-BOUNDARY-START(2535539)
            static $_SimpleParameterInfo;
            static get SimpleParameterInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2535539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$HnZw.DR.SimpleMethodSignature;
                return $cls.$_SimpleParameterInfo ??= $asm.$ncls(`$HnZw.DR.SimpleMethodSignature.SimpleParameterInfo`, ($self) => class SimpleParameterInfo extends $.$$.SR.ParameterInfo
                {
                    //--TRIMMABLE-BOUNDARY-START(4297502835)
                    $ctor$2(/*Type*/ parameterType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297502835);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.ClassImpl = parameterType;
                            this.DefaultValueImpl = null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297502835)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182404723)
                    /*bool */ get HasDefaultValue()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182404723)
                    
                    static $h = 2535539;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 118620161,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182404723),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887437427,
        "f": 50364417
      },
      "n": "HasDefaultValue",
      "d": 2535539,
      "h": 17182404723,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182404723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297502835),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 188022785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2535539,
      "h": 4297502835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297502835)
  ],
  "i": [114425857,157614081
  ],
  "d": 2470003,
  "h": 2535539
}; }
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.SR.ParameterInfo; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SR.ICustomAttributeProvider, $.$$.SRS.IObjectReference ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.SimpleMethodSignature+SimpleParameterInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}SimpleMethodSignature${separator}SimpleParameterInfo`; }
                }, $cls, ($v) => $cls.$_SimpleParameterInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2535539)
            
            //--TRIMMABLE-BOUNDARY-START(21477306483)
            /*MethodAttributes*/ Attributes = 0;
            //--TRIMMABLE-BOUNDARY-END(21477306483)
            
            //--TRIMMABLE-BOUNDARY-START(107376652403)
            /*MemberTypes*/ MemberType = 0;
            //--TRIMMABLE-BOUNDARY-END(107376652403)
            
            //--TRIMMABLE-BOUNDARY-START(4297437299)
            /*ParameterInfo[]*/ _parameterInfos = null;
            //--TRIMMABLE-BOUNDARY-END(4297437299)
            
            //--TRIMMABLE-BOUNDARY-START(17182339187)
            $ctor$5(/*params Type[]*/ parameterTypes)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182339187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._parameterInfos = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.ParameterInfo), null, [parameterTypes.length], null);
                    for(/*var*/ let i = 0; i < parameterTypes.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(this._parameterInfos, new $.$HnZw.DR.SimpleMethodSignature.SimpleParameterInfo().$ctor$2($.$$.System.Array.$ReadT1.call(parameterTypes, i)), i);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182339187)
            
            //--TRIMMABLE-BOUNDARY-START(94491750515)
            /*ParameterInfo[] */ GetParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491750515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parameterInfos;
            }
            //--TRIMMABLE-BOUNDARY-END(94491750515)
            
            //--TRIMMABLE-BOUNDARY-START(111671619699)
            /*RuntimeMethodHandle */ get MethodHandle()
            {
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111671619699)
            
            //--TRIMMABLE-BOUNDARY-START(115966586995)
            /*string */ get Name()
            {
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(115966586995)
            
            //--TRIMMABLE-BOUNDARY-START(25772273779)
            /*Type */ get DeclaringType()
            {
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(25772273779)
            
            //--TRIMMABLE-BOUNDARY-START(120261554291)
            /*Type */ get ReflectedType()
            {
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120261554291)
            
            //--TRIMMABLE-BOUNDARY-START(81606848627)
            /*object[] */ GetCustomAttributes(/*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606848627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(81606848627)
            
            //--TRIMMABLE-BOUNDARY-START(85901815923)
            /*object[] */ GetCustomAttributes$1(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901815923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(85901815923)
            
            //--TRIMMABLE-BOUNDARY-START(90196783219)
            /*MethodImplAttributes */ GetMethodImplementationFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196783219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90196783219)
            
            //--TRIMMABLE-BOUNDARY-START(98786717811)
            /*object */ Invoke$1(/*object*/ obj, /*BindingFlags*/ invokeAttr, /*Binder*/ binder, /*object[]*/ parameters, /*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786717811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98786717811)
            
            //--TRIMMABLE-BOUNDARY-START(103081685107)
            /*bool */ IsDefined(/*Type*/ attributeType, /*bool*/ inherit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081685107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(103081685107)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477306483)
                this.Attributes = 6;
                //--TRIMMABLE-BOUNDARY-END(21477306483)
                
                //--TRIMMABLE-BOUNDARY-START(107376652403)
                this.MemberType = 8;
                //--TRIMMABLE-BOUNDARY-END(107376652403)
                
            }
            static $h = 2470003;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 116457473,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477306483),
    {
      "p": 116391937,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362208371,
        "f": 50364417
      },
      "n": "Attributes",
      "d": 2470003,
      "h": 21477306483,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477306483),
//--TRIMMABLE-BOUNDARY-START(107376652403),
    {
      "p": 115802113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542077555,
        "f": 50364417
      },
      "n": "MemberType",
      "d": 2470003,
      "h": 107376652403,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107376652403),
//--TRIMMABLE-BOUNDARY-START(111671619699),
    {
      "p": 159973377,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132012147,
        "f": 50364417
      },
      "n": "MethodHandle",
      "d": 2470003,
      "h": 111671619699,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111671619699),
//--TRIMMABLE-BOUNDARY-START(115966586995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721946739,
        "f": 50364417
      },
      "n": "Name",
      "d": 2470003,
      "h": 115966586995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115966586995),
//--TRIMMABLE-BOUNDARY-START(25772273779),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952142963,
        "f": 50364417
      },
      "n": "DeclaringType",
      "d": 2470003,
      "h": 25772273779,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772273779),
//--TRIMMABLE-BOUNDARY-START(120261554291),
    {
      "p": 188022785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311881331,
        "f": 50364417
      },
      "n": "ReflectedType",
      "d": 2470003,
      "h": 120261554291,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120261554291)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94491750515),
    {
      "r": $.$typeArray($.$$.SR.ParameterInfo).$h,
      "n": "GetParameters",
      "d": 2470003,
      "h": 94491750515,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491750515),
//--TRIMMABLE-BOUNDARY-START(81606848627),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "d": 2470003,
      "h": 81606848627,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606848627),
//--TRIMMABLE-BOUNDARY-START(85901815923),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "p": [
        {
          "n": "attributeType",
          "p": 188022785
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "GetCustomAttributes",
      "o": "@$1",
      "d": 2470003,
      "h": 85901815923,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901815923),
//--TRIMMABLE-BOUNDARY-START(90196783219),
    {
      "r": 117047297,
      "n": "GetMethodImplementationFlags",
      "d": 2470003,
      "h": 90196783219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196783219),
//--TRIMMABLE-BOUNDARY-START(98786717811),
    {
      "r": 131073,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "invokeAttr",
          "p": 108593153
        },
        {
          "n": "binder",
          "p": 108527617
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "culture",
          "p": 84213761
        }
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 2470003,
      "h": 98786717811,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786717811),
//--TRIMMABLE-BOUNDARY-START(103081685107),
    {
      "r": 262145,
      "p": [
        {
          "n": "attributeType",
          "p": 188022785
        },
        {
          "n": "inherit",
          "p": 262145
        }
      ],
      "n": "IsDefined",
      "d": 2470003,
      "h": 103081685107,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081685107)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297437299),
    {
      "t": $.$typeArray($.$$.SR.ParameterInfo).$h,
      "n": "_parameterInfos",
      "d": 2470003,
      "h": 4297437299,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297437299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182339187),
    {
      "p": [
        {
          "n": "parameterTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2470003,
      "h": 17182339187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182339187)
  ],
  "i": [114425857
  ],
  "j": [2535539
  ],
  "h": 2470003
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SR.MethodBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SR.ICustomAttributeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.SimpleMethodSignature`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}SimpleMethodSignature`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2470003)
        
        

        //--TRIMMABLE-BOUNDARY-START(307315)
        $asm.$str(`$HnZw.D.DetectorOptions`, ($self) => class DetectorOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static IncludeChildren = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(307315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "IncludeChildren": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295274611)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295274611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295274611)
            
            //--TRIMMABLE-BOUNDARY-START(4295274611)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295274611)
            
            static $h = 307315;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885209203),
    {
      "t": 307315,
      "n": "None",
      "d": 307315,
      "h": 12885209203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885209203),
//--TRIMMABLE-BOUNDARY-START(8590241907),
    {
      "t": 307315,
      "n": "IncludeChildren",
      "d": 307315,
      "h": 8590241907,
      "f": 4194337,
      "a": [
        {
          "t": 104005633,
          "c": 30168776705,
          "a": [
            {
              "v": "IncludeChildren is deprecated and will be removed in a future version.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590241907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295274611),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 307315,
      "h": 4295274611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295274611)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 307315
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.DetectorOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}DetectorOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(307315)
        
        

        //--TRIMMABLE-BOUNDARY-START(176243)
        $asm.$str(`$HnZw.D.DefaultNumberType`, ($self) => class DefaultNumberType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static Int = 1;
            static Long = 2;
            static Single = 3;
            static Double = 4;
            static Decimal = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Int": 1n,
                    "Long": 2n,
                    "Single": 3n,
                    "Double": 4n,
                    "Decimal": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295143539)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295143539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295143539)
            
            //--TRIMMABLE-BOUNDARY-START(4295143539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295143539)
            
            static $h = 176243;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885078131),
    {
      "t": 176243,
      "n": "Default",
      "d": 176243,
      "h": 12885078131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885078131),
//--TRIMMABLE-BOUNDARY-START(21475012723),
    {
      "t": 176243,
      "n": "Int",
      "d": 176243,
      "h": 21475012723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475012723),
//--TRIMMABLE-BOUNDARY-START(25769980019),
    {
      "t": 176243,
      "n": "Long",
      "d": 176243,
      "h": 25769980019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769980019),
//--TRIMMABLE-BOUNDARY-START(30064947315),
    {
      "t": 176243,
      "n": "Single",
      "d": 176243,
      "h": 30064947315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064947315),
//--TRIMMABLE-BOUNDARY-START(17180045427),
    {
      "t": 176243,
      "n": "Double",
      "d": 176243,
      "h": 17180045427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180045427),
//--TRIMMABLE-BOUNDARY-START(8590110835),
    {
      "t": 176243,
      "n": "Decimal",
      "d": 176243,
      "h": 8590110835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590110835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295143539),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 176243,
      "h": 4295143539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295143539)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 176243
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.DefaultNumberType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}DefaultNumberType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(176243)
        
        

        //--TRIMMABLE-BOUNDARY-START(110707)
        $asm.$str(`$HnZw.D.AssignmentOperators`, ($self) => class AssignmentOperators extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static AssignmentEqual = 1;
            static All = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(110707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "AssignmentEqual": 1n,
                    "All": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295078003)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295078003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295078003)
            
            //--TRIMMABLE-BOUNDARY-START(4295078003)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295078003)
            
            static $h = 110707;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179979891),
    {
      "t": 110707,
      "n": "None",
      "d": 110707,
      "h": 17179979891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179979891),
//--TRIMMABLE-BOUNDARY-START(12885012595),
    {
      "t": 110707,
      "n": "AssignmentEqual",
      "d": 110707,
      "h": 12885012595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885012595),
//--TRIMMABLE-BOUNDARY-START(8590045299),
    {
      "t": 110707,
      "n": "All",
      "d": 110707,
      "h": 8590045299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590045299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295078003),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 110707,
      "h": 4295078003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295078003)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 110707,
  "a": [
    {
      "t": 80740353,
      "c": 4375707649
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.AssignmentOperators`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}AssignmentOperators`; }
        });
        //--TRIMMABLE-BOUNDARY-END(110707)
        
        

        //--TRIMMABLE-BOUNDARY-START(2011251)
        $asm.$str(`$HnZw.DP.TokenId`, ($self) => class TokenId extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unknown = 0;
            static End = 1;
            static Identifier = 2;
            static CharLiteral = 3;
            static StringLiteral = 4;
            static IntegerLiteral = 5;
            static RealLiteral = 6;
            static Exclamation = 7;
            static Percent = 8;
            static OpenParen = 9;
            static CloseParen = 10;
            static Asterisk = 11;
            static Plus = 12;
            static Comma = 13;
            static Minus = 14;
            static Tilde = 15;
            static Dot = 16;
            static QuestionQuestion = 17;
            static Slash = 18;
            static Colon = 19;
            static LessThan = 20;
            static GreaterThan = 21;
            static Question = 22;
            static OpenBracket = 23;
            static CloseBracket = 24;
            static ExclamationEqual = 25;
            static Amphersand = 26;
            static DoubleAmphersand = 27;
            static LessThanEqual = 28;
            static DoubleEqual = 29;
            static GreaterThanEqual = 30;
            static Bar = 31;
            static DoubleBar = 32;
            static Equal = 33;
            static Caret = 34;
            static OpenCurlyBracket = 35;
            static CloseCurlyBracket = 36;
            static LambdaArrow = 37;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2011251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "End": 1n,
                    "Identifier": 2n,
                    "CharLiteral": 3n,
                    "StringLiteral": 4n,
                    "IntegerLiteral": 5n,
                    "RealLiteral": 6n,
                    "Exclamation": 7n,
                    "Percent": 8n,
                    "OpenParen": 9n,
                    "CloseParen": 10n,
                    "Asterisk": 11n,
                    "Plus": 12n,
                    "Comma": 13n,
                    "Minus": 14n,
                    "Tilde": 15n,
                    "Dot": 16n,
                    "QuestionQuestion": 17n,
                    "Slash": 18n,
                    "Colon": 19n,
                    "LessThan": 20n,
                    "GreaterThan": 21n,
                    "Question": 22n,
                    "OpenBracket": 23n,
                    "CloseBracket": 24n,
                    "ExclamationEqual": 25n,
                    "Amphersand": 26n,
                    "DoubleAmphersand": 27n,
                    "LessThanEqual": 28n,
                    "DoubleEqual": 29n,
                    "GreaterThanEqual": 30n,
                    "Bar": 31n,
                    "DoubleBar": 32n,
                    "Equal": 33n,
                    "Caret": 34n,
                    "OpenCurlyBracket": 35n,
                    "CloseCurlyBracket": 36n,
                    "LambdaArrow": 37n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296978547)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296978547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296978547)
            
            //--TRIMMABLE-BOUNDARY-START(4296978547)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296978547)
            
            static $h = 2011251;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(167505735795),
    {
      "t": 2011251,
      "n": "Unknown",
      "d": 2011251,
      "h": 167505735795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505735795),
//--TRIMMABLE-BOUNDARY-START(68721487987),
    {
      "t": 2011251,
      "n": "End",
      "d": 2011251,
      "h": 68721487987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721487987),
//--TRIMMABLE-BOUNDARY-START(94491291763),
    {
      "t": 2011251,
      "n": "Identifier",
      "d": 2011251,
      "h": 94491291763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94491291763),
//--TRIMMABLE-BOUNDARY-START(25771815027),
    {
      "t": 2011251,
      "n": "CharLiteral",
      "d": 2011251,
      "h": 25771815027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771815027),
//--TRIMMABLE-BOUNDARY-START(158915801203),
    {
      "t": 2011251,
      "n": "StringLiteral",
      "d": 2011251,
      "h": 158915801203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915801203),
//--TRIMMABLE-BOUNDARY-START(98786259059),
    {
      "t": 2011251,
      "n": "IntegerLiteral",
      "d": 2011251,
      "h": 98786259059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98786259059),
//--TRIMMABLE-BOUNDARY-START(150325866611),
    {
      "t": 2011251,
      "n": "RealLiteral",
      "d": 2011251,
      "h": 150325866611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325866611),
//--TRIMMABLE-BOUNDARY-START(77311422579),
    {
      "t": 2011251,
      "n": "Exclamation",
      "d": 2011251,
      "h": 77311422579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77311422579),
//--TRIMMABLE-BOUNDARY-START(133145997427),
    {
      "t": 2011251,
      "n": "Percent",
      "d": 2011251,
      "h": 133145997427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145997427),
//--TRIMMABLE-BOUNDARY-START(128851030131),
    {
      "t": 2011251,
      "n": "OpenParen",
      "d": 2011251,
      "h": 128851030131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128851030131),
//--TRIMMABLE-BOUNDARY-START(38656716915),
    {
      "t": 2011251,
      "n": "CloseParen",
      "d": 2011251,
      "h": 38656716915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656716915),
//--TRIMMABLE-BOUNDARY-START(12886913139),
    {
      "t": 2011251,
      "n": "Asterisk",
      "d": 2011251,
      "h": 12886913139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886913139),
//--TRIMMABLE-BOUNDARY-START(137440964723),
    {
      "t": 2011251,
      "n": "Plus",
      "d": 2011251,
      "h": 137440964723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440964723),
//--TRIMMABLE-BOUNDARY-START(47246651507),
    {
      "t": 2011251,
      "n": "Comma",
      "d": 2011251,
      "h": 47246651507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246651507),
//--TRIMMABLE-BOUNDARY-START(115966128243),
    {
      "t": 2011251,
      "n": "Minus",
      "d": 2011251,
      "h": 115966128243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115966128243),
//--TRIMMABLE-BOUNDARY-START(163210768499),
    {
      "t": 2011251,
      "n": "Tilde",
      "d": 2011251,
      "h": 163210768499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210768499),
//--TRIMMABLE-BOUNDARY-START(51541618803),
    {
      "t": 2011251,
      "n": "Dot",
      "d": 2011251,
      "h": 51541618803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541618803),
//--TRIMMABLE-BOUNDARY-START(146030899315),
    {
      "t": 2011251,
      "n": "QuestionQuestion",
      "d": 2011251,
      "h": 146030899315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030899315),
//--TRIMMABLE-BOUNDARY-START(154620833907),
    {
      "t": 2011251,
      "n": "Slash",
      "d": 2011251,
      "h": 154620833907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620833907),
//--TRIMMABLE-BOUNDARY-START(42951684211),
    {
      "t": 2011251,
      "n": "Colon",
      "d": 2011251,
      "h": 42951684211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951684211),
//--TRIMMABLE-BOUNDARY-START(107376193651),
    {
      "t": 2011251,
      "n": "LessThan",
      "d": 2011251,
      "h": 107376193651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107376193651),
//--TRIMMABLE-BOUNDARY-START(85901357171),
    {
      "t": 2011251,
      "n": "GreaterThan",
      "d": 2011251,
      "h": 85901357171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85901357171),
//--TRIMMABLE-BOUNDARY-START(141735932019),
    {
      "t": 2011251,
      "n": "Question",
      "d": 2011251,
      "h": 141735932019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735932019),
//--TRIMMABLE-BOUNDARY-START(120261095539),
    {
      "t": 2011251,
      "n": "OpenBracket",
      "d": 2011251,
      "h": 120261095539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120261095539),
//--TRIMMABLE-BOUNDARY-START(30066782323),
    {
      "t": 2011251,
      "n": "CloseBracket",
      "d": 2011251,
      "h": 30066782323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066782323),
//--TRIMMABLE-BOUNDARY-START(81606389875),
    {
      "t": 2011251,
      "n": "ExclamationEqual",
      "d": 2011251,
      "h": 81606389875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81606389875),
//--TRIMMABLE-BOUNDARY-START(8591945843),
    {
      "t": 2011251,
      "n": "Amphersand",
      "d": 2011251,
      "h": 8591945843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591945843),
//--TRIMMABLE-BOUNDARY-START(55836586099),
    {
      "t": 2011251,
      "n": "DoubleAmphersand",
      "d": 2011251,
      "h": 55836586099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836586099),
//--TRIMMABLE-BOUNDARY-START(111671160947),
    {
      "t": 2011251,
      "n": "LessThanEqual",
      "d": 2011251,
      "h": 111671160947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111671160947),
//--TRIMMABLE-BOUNDARY-START(64426520691),
    {
      "t": 2011251,
      "n": "DoubleEqual",
      "d": 2011251,
      "h": 64426520691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426520691),
//--TRIMMABLE-BOUNDARY-START(90196324467),
    {
      "t": 2011251,
      "n": "GreaterThanEqual",
      "d": 2011251,
      "h": 90196324467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90196324467),
//--TRIMMABLE-BOUNDARY-START(17181880435),
    {
      "t": 2011251,
      "n": "Bar",
      "d": 2011251,
      "h": 17181880435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181880435),
//--TRIMMABLE-BOUNDARY-START(60131553395),
    {
      "t": 2011251,
      "n": "DoubleBar",
      "d": 2011251,
      "h": 60131553395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131553395),
//--TRIMMABLE-BOUNDARY-START(73016455283),
    {
      "t": 2011251,
      "n": "Equal",
      "d": 2011251,
      "h": 73016455283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016455283),
//--TRIMMABLE-BOUNDARY-START(21476847731),
    {
      "t": 2011251,
      "n": "Caret",
      "d": 2011251,
      "h": 21476847731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476847731),
//--TRIMMABLE-BOUNDARY-START(124556062835),
    {
      "t": 2011251,
      "n": "OpenCurlyBracket",
      "d": 2011251,
      "h": 124556062835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124556062835),
//--TRIMMABLE-BOUNDARY-START(34361749619),
    {
      "t": 2011251,
      "n": "CloseCurlyBracket",
      "d": 2011251,
      "h": 34361749619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361749619),
//--TRIMMABLE-BOUNDARY-START(103081226355),
    {
      "t": 2011251,
      "n": "LambdaArrow",
      "d": 2011251,
      "h": 103081226355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103081226355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296978547),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2011251,
      "h": 4296978547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296978547)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 2011251
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Parsing.TokenId`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Parsing${separator}TokenId`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2011251)
        
        

        //--TRIMMABLE-BOUNDARY-START(1093747)
        $asm.$str(`$HnZw.D.InterpreterOptions`, ($self) => class InterpreterOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static PrimitiveTypes = 1;
            static SystemKeywords = 2;
            static CommonTypes = 4;
            static CaseInsensitive = 8;
            static LateBindObject = 16;
            static LambdaExpressions = 32;
            static Default = 7;
            static DefaultCaseInsensitive = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1093747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "PrimitiveTypes": 1n,
                    "SystemKeywords": 2n,
                    "CommonTypes": 4n,
                    "CaseInsensitive": 8n,
                    "LateBindObject": 16n,
                    "LambdaExpressions": 32n,
                    "Default": 7n,
                    "DefaultCaseInsensitive": 15n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296061043)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296061043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296061043)
            
            //--TRIMMABLE-BOUNDARY-START(4296061043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296061043)
            
            static $h = 1093747;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360832115),
    {
      "t": 1093747,
      "n": "None",
      "d": 1093747,
      "h": 34360832115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360832115),
//--TRIMMABLE-BOUNDARY-START(38655799411),
    {
      "t": 1093747,
      "n": "PrimitiveTypes",
      "d": 1093747,
      "h": 38655799411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655799411),
//--TRIMMABLE-BOUNDARY-START(42950766707),
    {
      "t": 1093747,
      "n": "SystemKeywords",
      "d": 1093747,
      "h": 42950766707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950766707),
//--TRIMMABLE-BOUNDARY-START(12885995635),
    {
      "t": 1093747,
      "n": "CommonTypes",
      "d": 1093747,
      "h": 12885995635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885995635),
//--TRIMMABLE-BOUNDARY-START(8591028339),
    {
      "t": 1093747,
      "n": "CaseInsensitive",
      "d": 1093747,
      "h": 8591028339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591028339),
//--TRIMMABLE-BOUNDARY-START(30065864819),
    {
      "t": 1093747,
      "n": "LateBindObject",
      "d": 1093747,
      "h": 30065864819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065864819),
//--TRIMMABLE-BOUNDARY-START(25770897523),
    {
      "t": 1093747,
      "n": "LambdaExpressions",
      "d": 1093747,
      "h": 25770897523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770897523),
//--TRIMMABLE-BOUNDARY-START(17180962931),
    {
      "t": 1093747,
      "n": "Default",
      "d": 1093747,
      "h": 17180962931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180962931),
//--TRIMMABLE-BOUNDARY-START(21475930227),
    {
      "t": 1093747,
      "n": "DefaultCaseInsensitive",
      "d": 1093747,
      "h": 21475930227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475930227)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296061043),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1093747,
      "h": 4296061043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296061043)
  ],
  "i": [90308609,96862209,90767361,90439681
  ],
  "h": 1093747,
  "a": [
    {
      "t": 80740353,
      "c": 4375707649
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.InterpreterOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}InterpreterOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1093747)
        
        

        //--TRIMMABLE-BOUNDARY-START(2142323)
        $asm.$cls(`$HnZw.DR.IndexerData`, ($self) => class IndexerData extends $.$HnZw.DR.MethodData
        {
            //--TRIMMABLE-BOUNDARY-START(8592076915)
            /*PropertyInfo*/ Indexer = null;
            //--TRIMMABLE-BOUNDARY-END(8592076915)
            
            //--TRIMMABLE-BOUNDARY-START(4297109619)
            $ctor$2(/*PropertyInfo*/ indexer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297109619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Indexer = indexer;
                    /*var*/ let method = indexer.GetGetMethod();
                    if ($.$$.SR.MethodInfo.op_Inequality$2(method, null))
                    {
                        this.Parameters = method.GetParameters();
                    }
                    else 
                    {
                        method = indexer.GetSetMethod();
                        this.Parameters = $.$HnZw.DR.IndexerData.RemoveLast($.$$.SR.ParameterInfo, method.GetParameters());
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297109619)
            
            //--TRIMMABLE-BOUNDARY-START(12887044211)
            static /*T[] */ RemoveLast(T, /*T[]*/ array)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887044211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((array.length - 1) | 0)], null);
                $.$$.S.Array.Copy(array, 0, result, 0, result.length);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(12887044211)
            
            static $h = 2142323;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2273395,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887044211),
    {
      "r": (T) => $.$typeArray(T).$h,
      "p": [
        {
          "n": "array",
          "p": (T) => $.$typeArray(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveLast",
      "d": 2142323,
      "h": 12887044211,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(12887044211)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592076915),
    {
      "t": 119144449,
      "n": "Indexer",
      "d": 2142323,
      "h": 8592076915,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8592076915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297109619),
    {
      "p": [
        {
          "n": "indexer",
          "p": 119144449
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2142323,
      "h": 4297109619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297109619)
  ],
  "h": 2142323
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DR.MethodData; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Reflection.IndexerData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Reflection${separator}IndexerData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2142323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1486963)
        $asm.$cls(`$HnZw.D.ParameterWithPosition`, ($self) => class ParameterWithPosition extends $.$HnZw.D.Parameter
        {
            //--TRIMMABLE-BOUNDARY-START(8591421555)
            $ctor$4(/*int*/ pos, /*string*/ name, /*Type*/ type)
            {
                super.$ctor$3(name, type, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591421555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Position = pos;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591421555)
            
            //--TRIMMABLE-BOUNDARY-START(21476323443)
            /*int*/ Position = 0;
            //--TRIMMABLE-BOUNDARY-END(21476323443)
            
            static $h = 1486963;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1421427,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476323443),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181356147,
        "f": 50331649
      },
      "n": "Position",
      "d": 1486963,
      "h": 21476323443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476323443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591421555),
    {
      "p": [
        {
          "n": "pos",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188022785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1486963,
      "h": 8591421555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591421555)
  ],
  "h": 1486963
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.D.Parameter; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.ParameterWithPosition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}ParameterWithPosition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1486963)
        
        

        //--TRIMMABLE-BOUNDARY-START(831603)
        $asm.$cls(`$HnZw.D.FunctionIdentifier`, ($self) => class FunctionIdentifier extends $.$HnZw.D.Identifier
        {
            //--TRIMMABLE-BOUNDARY-START(4295798899)
            $ctor$2(/*string*/ name, /*Delegate*/ value)
            {
                super.$ctor$1(name, new $.$HnZw.D.MethodGroupExpression().$ctor$3(value));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295798899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295798899)
            
            //--TRIMMABLE-BOUNDARY-START(8590766195)
            /*void */ AddOverload(/*Delegate*/ overload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590766195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ($.$cast(this.Expression, $.$HnZw.D.MethodGroupExpression)).AddOverload(overload);
            }
            //--TRIMMABLE-BOUNDARY-END(8590766195)
            
            static $h = 831603;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 897139,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590766195),
    {
      "r": 65537,
      "p": [
        {
          "n": "overload",
          "p": 66977793
        }
      ],
      "n": "AddOverload",
      "d": 831603,
      "h": 8590766195,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590766195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295798899),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 66977793
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 831603,
      "h": 4295798899,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295798899)
  ],
  "h": 831603
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.D.Identifier; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.FunctionIdentifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}FunctionIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(831603)
        
        

        //--TRIMMABLE-BOUNDARY-START(503923)
        $asm.$cls(`$HnZw.DE.DynamicExpressoException`, ($self) => class DynamicExpressoException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4295471219)
            $ctor$5()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295471219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295471219)
            
            //--TRIMMABLE-BOUNDARY-START(17180373107)
            $ctor$8(/*string*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180373107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180373107)
            
            //--TRIMMABLE-BOUNDARY-START(12885405811)
            $ctor$7(/*string*/ message, /*Exception*/ inner)
            {
                super.$ctor$3(message, inner);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885405811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885405811)
            
            //--TRIMMABLE-BOUNDARY-START(8590438515)
            $ctor$6(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590438515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590438515)
            
            //--TRIMMABLE-BOUNDARY-START(4295471219)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295471219)
            
            static $h = 503923;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80281601,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295471219),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 503923,
      "h": 4295471219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295471219),
//--TRIMMABLE-BOUNDARY-START(17180373107),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 503923,
      "h": 17180373107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180373107),
//--TRIMMABLE-BOUNDARY-START(12885405811),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "inner",
          "p": 80281601
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 503923,
      "h": 12885405811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885405811),
//--TRIMMABLE-BOUNDARY-START(8590438515),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 503923,
      "h": 8590438515,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590438515)
  ],
  "i": [157745153
  ],
  "h": 503923,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.DynamicExpressoException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}DynamicExpressoException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(503923)
        
        

        //--TRIMMABLE-BOUNDARY-START(438387)
        $asm.$cls(`$HnZw.DE.DuplicateParameterException`, ($self) => class DuplicateParameterException extends $.$HnZw.DE.DynamicExpressoException
        {
            //--TRIMMABLE-BOUNDARY-START(12885340275)
            $ctor$10(/*string*/ identifier)
            {
                super.$ctor$8($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.DuplicateParameter, identifier));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885340275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Identifier = identifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885340275)
            
            //--TRIMMABLE-BOUNDARY-START(30065209459)
            /*string*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(30065209459)
            
            //--TRIMMABLE-BOUNDARY-START(8590372979)
            $ctor$9(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$6(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590372979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Identifier = info.GetString("Identifier");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590372979)
            
            //--TRIMMABLE-BOUNDARY-START(25770242163)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770242163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                info.AddValue$10("Identifier", this.Identifier);
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(25770242163)
            
            static $h = 438387;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 503923,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065209459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475274867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655144051,
        "f": 83886082
      },
      "n": "Identifier",
      "d": 438387,
      "h": 30065209459,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065209459)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770242163),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 438387,
      "h": 25770242163,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770242163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885340275),
    {
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 438387,
      "h": 12885340275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885340275),
//--TRIMMABLE-BOUNDARY-START(8590372979),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 438387,
      "h": 8590372979,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590372979)
  ],
  "i": [157745153
  ],
  "h": 438387,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.DynamicExpressoException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.DuplicateParameterException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}DuplicateParameterException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(438387)
        
        

        //--TRIMMABLE-BOUNDARY-START(634995)
        $asm.$cls(`$HnZw.DE.ParseException`, ($self) => class ParseException extends $.$HnZw.DE.DynamicExpressoException
        {
            //--TRIMMABLE-BOUNDARY-START(17180504179)
            $ctor$11(/*string*/ message, /*int*/ position)
            {
                super.$ctor$8($.$$.S.String.Format$8($.$HnZw.DR$2.ErrorMessages.Format, message, $.$box(position, $.$$.S.Int32)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180504179);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Position = position;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180504179)
            
            //--TRIMMABLE-BOUNDARY-START(12885536883)
            $ctor$10(/*string*/ message, /*int*/ position, /*Exception*/ innerException)
            {
                super.$ctor$7($.$$.S.String.Format$8($.$HnZw.DR$2.ErrorMessages.Format, message, $.$box(position, $.$$.S.Int32)), innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885536883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Position = position;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885536883)
            
            //--TRIMMABLE-BOUNDARY-START(38655340659)
            /*int*/ Position = 0;
            //--TRIMMABLE-BOUNDARY-END(38655340659)
            
            //--TRIMMABLE-BOUNDARY-START(21475471475)
            static /*ParseException */ Create(/*int*/ pos, /*string*/ format, /*params object[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475471475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$HnZw.DE.ParseException().$ctor$11($.$$.S.String.Format$10(format, args), pos);
            }
            //--TRIMMABLE-BOUNDARY-END(21475471475)
            
            //--TRIMMABLE-BOUNDARY-START(8590569587)
            $ctor$9(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$6(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590569587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Position = info.GetInt32("Position");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590569587)
            
            //--TRIMMABLE-BOUNDARY-START(34360373363)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360373363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                info.AddValue$7("Position", this.Position);
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(34360373363)
            
            static $h = 634995;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 503923,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655340659),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065406067,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245275251,
        "f": 83886082
      },
      "n": "Position",
      "d": 634995,
      "h": 38655340659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655340659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475471475),
    {
      "r": 634995,
      "p": [
        {
          "n": "pos",
          "p": 655361
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "Create",
      "d": 634995,
      "h": 21475471475,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475471475),
//--TRIMMABLE-BOUNDARY-START(34360373363),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 634995,
      "h": 34360373363,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360373363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180504179),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "position",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 634995,
      "h": 17180504179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180504179),
//--TRIMMABLE-BOUNDARY-START(12885536883),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "position",
          "p": 655361
        },
        {
          "n": "innerException",
          "p": 80281601
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 634995,
      "h": 12885536883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885536883),
//--TRIMMABLE-BOUNDARY-START(8590569587),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 634995,
      "h": 8590569587,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590569587)
  ],
  "i": [157745153
  ],
  "h": 634995,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.DynamicExpressoException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.ParseException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}ParseException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(634995)
        
        

        //--TRIMMABLE-BOUNDARY-START(700531)
        $asm.$cls(`$HnZw.DE.ReflectionNotAllowedException`, ($self) => class ReflectionNotAllowedException extends $.$HnZw.DE.ParseException
        {
            //--TRIMMABLE-BOUNDARY-START(4295667827)
            $ctor$12()
            {
                super.$ctor$11($.$HnZw.DR$2.ErrorMessages.ReflectionNotAllowed, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295667827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295667827)
            
            //--TRIMMABLE-BOUNDARY-START(8590635123)
            $ctor$13(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$9(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590635123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590635123)
            
            //--TRIMMABLE-BOUNDARY-START(12885602419)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885602419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(12885602419)
            
            //--TRIMMABLE-BOUNDARY-START(4295667827)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$12();
            }
            //--TRIMMABLE-BOUNDARY-END(4295667827)
            
            static $h = 700531;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 634995,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885602419),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 700531,
      "h": 12885602419,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885602419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295667827),
    {
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 700531,
      "h": 4295667827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295667827),
//--TRIMMABLE-BOUNDARY-START(8590635123),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 700531,
      "h": 8590635123,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590635123)
  ],
  "i": [157745153
  ],
  "h": 700531,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.ParseException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.ReflectionNotAllowedException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}ReflectionNotAllowedException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(700531)
        
        

        //--TRIMMABLE-BOUNDARY-START(766067)
        $asm.$cls(`$HnZw.DE.UnknownIdentifierException`, ($self) => class UnknownIdentifierException extends $.$HnZw.DE.ParseException
        {
            //--TRIMMABLE-BOUNDARY-START(12885667955)
            $ctor$13(/*string*/ identifier, /*int*/ position)
            {
                super.$ctor$11($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.UnknownIdentifier, identifier), position);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885667955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Identifier = identifier;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885667955)
            
            //--TRIMMABLE-BOUNDARY-START(30065537139)
            /*string*/ Identifier = null;
            //--TRIMMABLE-BOUNDARY-END(30065537139)
            
            //--TRIMMABLE-BOUNDARY-START(8590700659)
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$9(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590700659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Identifier = info.GetString("Identifier");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590700659)
            
            //--TRIMMABLE-BOUNDARY-START(25770569843)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770569843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                info.AddValue$10("Identifier", this.Identifier);
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(25770569843)
            
            static $h = 766067;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 634995,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065537139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475602547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655471731,
        "f": 83886082
      },
      "n": "Identifier",
      "d": 766067,
      "h": 30065537139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065537139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770569843),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 766067,
      "h": 25770569843,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770569843)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885667955),
    {
      "p": [
        {
          "n": "identifier",
          "p": 1310721
        },
        {
          "n": "position",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 766067,
      "h": 12885667955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885667955),
//--TRIMMABLE-BOUNDARY-START(8590700659),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 766067,
      "h": 8590700659,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590700659)
  ],
  "i": [157745153
  ],
  "h": 766067,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.ParseException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.UnknownIdentifierException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}UnknownIdentifierException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(766067)
        
        

        //--TRIMMABLE-BOUNDARY-START(372851)
        $asm.$cls(`$HnZw.DE.AssignmentOperatorDisabledException`, ($self) => class AssignmentOperatorDisabledException extends $.$HnZw.DE.ParseException
        {
            //--TRIMMABLE-BOUNDARY-START(12885274739)
            $ctor$13(/*string*/ operatorString, /*int*/ position)
            {
                super.$ctor$11($.$$.S.String.Format$9($.$HnZw.DR$2.ErrorMessages.AssignmentOperatorNotAllowed, operatorString), position);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885274739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OperatorString = operatorString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885274739)
            
            //--TRIMMABLE-BOUNDARY-START(30065143923)
            /*string*/ OperatorString = null;
            //--TRIMMABLE-BOUNDARY-END(30065143923)
            
            //--TRIMMABLE-BOUNDARY-START(8590307443)
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$9(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590307443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OperatorString = info.GetString("OperatorString");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590307443)
            
            //--TRIMMABLE-BOUNDARY-START(25770176627)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770176627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                info.AddValue$10("OperatorString", this.OperatorString);
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(25770176627)
            
            static $h = 372851;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 634995,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065143923),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475209331,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655078515,
        "f": 83886082
      },
      "n": "OperatorString",
      "d": 372851,
      "h": 30065143923,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065143923)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770176627),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 372851,
      "h": 25770176627,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770176627)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885274739),
    {
      "p": [
        {
          "n": "operatorString",
          "p": 1310721
        },
        {
          "n": "position",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 372851,
      "h": 12885274739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885274739),
//--TRIMMABLE-BOUNDARY-START(8590307443),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 372851,
      "h": 8590307443,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590307443)
  ],
  "i": [157745153
  ],
  "h": 372851,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.ParseException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.AssignmentOperatorDisabledException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}AssignmentOperatorDisabledException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(372851)
        
        

        //--TRIMMABLE-BOUNDARY-START(569459)
        $asm.$cls(`$HnZw.DE.NoApplicableMethodException`, ($self) => class NoApplicableMethodException extends $.$HnZw.DE.ParseException
        {
            //--TRIMMABLE-BOUNDARY-START(17180438643)
            $ctor$13(/*string*/ methodName, /*string*/ methodTypeName, /*int*/ position)
            {
                super.$ctor$11($.$$.S.String.Format$8($.$HnZw.DR$2.ErrorMessages.InvalidMethodCall2, methodName, methodTypeName), position);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180438643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MethodTypeName = methodTypeName;
                    this.MethodName = methodName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180438643)
            
            //--TRIMMABLE-BOUNDARY-START(47245209715)
            /*string*/ MethodTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(47245209715)
            
            //--TRIMMABLE-BOUNDARY-START(42950242419)
            /*string*/ MethodName = null;
            //--TRIMMABLE-BOUNDARY-END(42950242419)
            
            //--TRIMMABLE-BOUNDARY-START(12885471347)
            $ctor$12(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$9(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885471347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MethodTypeName = info.GetString("MethodTypeName");
                    this.MethodName = info.GetString("MethodName");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885471347)
            
            //--TRIMMABLE-BOUNDARY-START(38655275123)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655275123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                info.AddValue$10("MethodName", this.MethodName);
                info.AddValue$10("MethodTypeName", this.MethodTypeName);
                super.GetObjectData(info, context);
            }
            //--TRIMMABLE-BOUNDARY-END(38655275123)
            
            static $h = 569459;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 634995,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245209715),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360307827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425078899,
        "f": 83886082
      },
      "n": "MethodTypeName",
      "d": 569459,
      "h": 47245209715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245209715),
//--TRIMMABLE-BOUNDARY-START(42950242419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770373235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835144307,
        "f": 83886082
      },
      "n": "MethodName",
      "d": 569459,
      "h": 42950242419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950242419)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655275123),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": "GetObjectData",
      "d": 569459,
      "h": 38655275123,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655275123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180438643),
    {
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "methodTypeName",
          "p": 1310721
        },
        {
          "n": "position",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 569459,
      "h": 17180438643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180438643),
//--TRIMMABLE-BOUNDARY-START(12885471347),
    {
      "p": [
        {
          "n": "info",
          "p": 158334977
        },
        {
          "n": "context",
          "p": 158466049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 569459,
      "h": 12885471347,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885471347)
  ],
  "i": [157745153
  ],
  "h": 569459,
  "a": [
    {
      "t": 162594817,
      "c": 4457562113
    }
  ]
}; }
            static $$b;
            static get $b() { return this.$$b ??= $.$HnZw.DE.ParseException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `DynamicExpresso.Exceptions.NoApplicableMethodException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `DynamicExpresso${separator}Exceptions${separator}NoApplicableMethodException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(569459)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp"));
})();
//--TRIMMABLE-BOUNDARY-END(45171)
