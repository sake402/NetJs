
//--TRIMMABLE-BOUNDARY-START(39743)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $zHIt, $kVHt, $Iaui, $uvJL, $ajwi, $GfYa, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $lJUR) {
    "use strict";
    let _;
    let $hveDSe;
    let $yleExi;
    let $HbwrYg;
    let $oNQWWg;
    let $cmxqod;
    let $KnCexa;
    let $lmNqwf;
    let $ZqPuqg;
    let $xrkMkf;
    let $jRqNDf;
    let $aSYEOb;
    let $ZMWMCj;
    let $QszSol;
    let $IHUbIe;
    let $QmXvii;
    let $XoKhwc;
    let $HnwJFa;
    let $LpNnll;
    let $JHGthg;
    let $bqNpQc;
    let $CvOXgf;
    let $Wrypnf;
    let $kPrxvh;
    let $DpJCOa;
    let $KfQomi;
    let $bsNxfa;
    let $OuwHwj;
    let $hlROna;
    let $aeQGac;
    let $bgzWze;
    let $pvnPgh;
    let $IqBKvg;
    let $lmauAe;
    let $efVQZa;
    let $mNbHUb;
    let $cNvtlj;
    let $lcafTg;
    let $LcIqra;
    let $bjnWSj;
    let $nSeuvf;
    let $gVYXNi;
    let $OQTHpc;
    let $meKxZb;
    let $IZUkoj;
    let $zivJQj;
    let $QpBXXi;
    let $TuxvXi;
    let $xOulth;
    let $MYLbDg;
    let $xzNWSc;
    let $ehiRwd;
    let $RpJvil;
    let $JnzIej;
    let $modGri;
    let $TcFLka;
    let $wFqdqj;
    let $BXKTQc;
    let $aUitrj;
    let $csfTWe;
    let $TXVeng;
    let $JpVHYi;
    let $RPswxg;
    let $iEKRoh;
    let $XWAQWj;
    let $Wowpej;
    let $CZGBbg;
    let $ahXwhk;
    let $XTdylh;
    let $YMmKXe;
    let $ZgLvbj;
    let $QKFVoh;
    let $cbLbOd;
    let $uiGYdh;
    let $RPBXdg;
    let $IePqog;
    let $dXcFWa;
    let $jxlARk;
    let $SLnlJi;
    let $kHRrnj;
    let $ghDzhb;
    let $WHpihe;
    let $YSdwnl;
    let $UgUiGa;
    let $kysqna;
    let $nhOvvd;
    let $KMewvg;
    let $audWga;
    let $PzBsOi;
    let $gUvNNi;
    let $uinQJk;
    let $VfZDPh;
    let $iwCpUj;
    let $oNLvWf;
    let $ifGAua;
    let $KwqdQc;
    let $ugozZa;
    let $DUnWui;
    let $NLgthi;
    let $flUbGb;
    let $LIaUdb;
    let $SxFdkb;
    let $ugHgGf;
    let $vEUkob;
    let $vQibmh;
    let $Axjmsa;
    let $gHZbUf;
    let $ufAPsf;
    let $OzFUSa;
    let $wnuCWa;
    let $TJdiKg;
    let $HxpwZh;
    let $TljqYe;
    let $fjIWec;
    let $NGTQZg;
    let $xaOXUj;
    let $iGZhIg;
    let $ShmGug;
    let $CNISXh;
    let $AkvrDj;
    let $YiwXHc;
    let $cTRBQh;
    let $kUUbrc;
    let $jjsPLi;
    let $GBvVUa;
    let $nAmVhg;
    let $GuwOIf;
    let $PLNUNf;
    let $ihbBhd;
    let $KRTHLd;
    let $USjPwb;
    let $chNhCk;
    let $eijKke;
    let $qYSsLb;
    let $AWYYXh;
    let $JKXwhl;
    let $PCgdzh;
    let $wQPmol;
    let $Vnkwyd;
    let $yQkrkj;
    let $eDfchf;
    let $FxGzgk;
    let $Bstkvi;
    let $oMkwlh;
    let $nrkChl;
    let $GFFLCh;
    let $ixSZNj;
    let $cSnDTk;
    let $nnRZfj;
    let $htNdUc;
    let $QMUOqg;
    let $Nofgxc;
    let $iRRFJb;
    let $UdxVAi;
    let $CYAWwg;
    let $wgjroi;
    let $uXOGed;
    let $idiaXd;
    let $RcPtIi;
    let $suTxhf;
    let $DADVbl;
    let $etHEAe;
    let $kgCxwi;
    let $kgMSAe;
    let $meyIYj;
    let $qCfsld;
    let $IgEnbh;
    let $TflwOe;
    let $muJrkk;
    let $oUZHDe;
    let $bHUhYg;
    let $usbkZd;
    let $dbrjhh;
    let $aGBWLh;
    let $PBQIKb;
    let $IZBLca;
    let $hLnuUd;
    let $ymqGKf;
    let $rmqVic;
    let $rTomud;
    let $OlArXd;
    let $hlMHBe;
    let $XgixPc;
    let $FzEGOc;
    let $Lmikpj;
    let $oQVEMd;
    let $ISAEuk;
    let $DdSEgg;
    let $eZXPCc;
    let $vlBhHg;
    let $UcHHMj;
    let $ieOdFk;
    let $LzPpRc;
    let $MIluhi;
    let $lJbEfh;
    let $CHBGWe;
    let $njUtvc;
    let $cBhOMk;
    let $jHEScf;
    let $RfDgIg;
    let $QqQMvj;
    let $xvGlGb;
    let $qlHvwj;
    let $sODlPg;
    let $NuvPxe;
    let $xbYXDd;
    let $UzjWAf;
    let $KkOfFf;
    let $qEUPcj;
    let $nOQOjh;
    let $vRnjpj;
    let $HLBWti;
    let $bmNudc;
    let $GkNjUa;
    let $UrOscc;
    let $kDNQud;
    let $tUqMfk;
    let $ddSyCi;
    let $lwvIad;
    let $zPkJYi;
    let $HbDUqh;
    let $Basjxa;
    let $iZdeUk;
    let $bCwoCi;
    let $iEDqIk;
    let $oegVRa;
    let $khwMvj;
    let $azoLib;
    let $roqQce;
    let $cfBZYj;
    let $bPbOnk;
    let $DXeAEd;
    let $FPznhd;
    let $WYViPf;
    let $AFndPf;
    let $pqBOJk;
    let $wwFuTf;
    let $Frxref;
    let $DSaCrj;
    let $kfHaLk;
    let $dsDXne;
    let $cVLYdg;
    let $JoeTBj;
    let $HgUjyg;
    let $QMQLuh;
    let $eTpBwk;
    let $Oplauc;
    let $ByGQgi;
    let $UKQPjl;
    let $YiEzia;
    let $oERgjf;
    let $lkWRJf;
    let $wxBoLd;
    let $QDqKSg;
    let $YiNoQd;
    let $YTRrZb;
    let $CmLkKi;
    let $ZUiQyf;
    let $GpcLmb;
    let $IbAVRa;
    let $JebrLc;
    let $WQODGc;
    let $QEMiOj;
    let $VjoCla;
    let $SSvRFg;
    let $XefmNh;
    let $lxbYCj;
    let $wfOWMh;
    let $jTKkCh;
    let $Pibuje;
    let $Jlbbrd;
    let $rQbgVe;
    let $uTdWGf;
    let $uThAyi;
    let $IAsgdi;
    let $KLTadk;
    let $VaUNug;
    let $kmYKni;
    let $mBsTnf;
    let $cnZyId;
    let $Ljljte;
    let $ojFWOg;
    let $xmtXih;
    let $nifHYg;
    let $BrrIKh;
    let $qkaeeg;
    let $IhKxej;
    let $URWgMb;
    let $abogyh;
    let $hrapgl;
    let $LvYYXd;
    let $YXldjj;
    let $BJuRwh;
    let $PnNfWc;
    let $AoToHh;
    let $ZeRCnl;
    let $hsAQpi;
    let $kYZUCc;
    let $gwMPgi;
    let $umQeDb;
    let $DiiSYg;
    let $NQcwAk;
    let $hCvgzi;
    let $RiIRIh;
    let $QUQhgf;
    let $bpRove;
    let $mlWfdf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Admin.Client.Blazor", 
    {
  "h": 39743,
  "f": "LivingThing.Core.Admin.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Admin.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Admin.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(564031)
        $asm.$cls(`$WRsM.LCACM.EditModel`, ($self) => class EditModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540171583)
            /*EntryModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(51540171583)
            
            //--TRIMMABLE-BOUNDARY-START(21475400511)
            /*ObservableCollection<string>*/ Fields = null;
            //--TRIMMABLE-BOUNDARY-END(21475400511)
            
            //--TRIMMABLE-BOUNDARY-START(81604942655)
            /*Action*/ UndoDirty = null;
            //--TRIMMABLE-BOUNDARY-END(81604942655)
            
            //--TRIMMABLE-BOUNDARY-START(17180433215)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180433215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180433215)
            
            //--TRIMMABLE-BOUNDARY-START(17180433215)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180433215)
            
            static $h = 564031;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540171583),
    {
      "p": 8856918,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655269695,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720040767,
        "f": 83886081
      },
      "n": "Model",
      "d": 564031,
      "h": 51540171583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540171583),
//--TRIMMABLE-BOUNDARY-START(21475400511),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065335103,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130106175,
        "f": 83886081
      },
      "n": "Fields",
      "d": 564031,
      "h": 21475400511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475400511),
//--TRIMMABLE-BOUNDARY-START(81604942655),
    {
      "p": 43122689,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245204287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309975359,
        "f": 83886081
      },
      "n": "UndoDirty",
      "d": 564031,
      "h": 81604942655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604942655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180433215),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 564031,
      "h": 17180433215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180433215)
  ],
  "h": 564031
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Models.EditModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Models${separator}EditModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(564031)
        
        

        //--TRIMMABLE-BOUNDARY-START(498495)
        $asm.$cls(`$WRsM.LCACM.AppState`, ($self) => class AppState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540106047)
            /*Dictionary<TableRowType, Table>*/ RootTables = null;
            //--TRIMMABLE-BOUNDARY-END(51540106047)
            
            //--TRIMMABLE-BOUNDARY-START(21475334975)
            /*Dictionary<TableRowType, ObservableCollection<EntryModel>>*/ ClipBoard = null;
            //--TRIMMABLE-BOUNDARY-END(21475334975)
            
            //--TRIMMABLE-BOUNDARY-START(81604877119)
            /*ObservableCollection<Table>*/ TableManagers = null;
            //--TRIMMABLE-BOUNDARY-END(81604877119)
            
            //--TRIMMABLE-BOUNDARY-START(17180367679)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180367679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180367679)
            
            //--TRIMMABLE-BOUNDARY-START(17180367679)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180367679)
            
            static $h = 498495;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540106047),
    {
      "p": $.$$.SCG.Dictionary$$$($.$ajwi.LCACM.TableRowType, $.$WRsM.LCACSD.Table).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655204159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719975231,
        "f": 83886081
      },
      "n": "RootTables",
      "d": 498495,
      "h": 51540106047,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540106047),
//--TRIMMABLE-BOUNDARY-START(21475334975),
    {
      "p": $.$$.SCG.Dictionary$$$($.$ajwi.LCACM.TableRowType, $.$so.SCO.ObservableCollection$$($.$Iaui.LCFCM.EntryModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065269567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130040639,
        "f": 83886081
      },
      "n": "ClipBoard",
      "d": 498495,
      "h": 21475334975,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475334975),
//--TRIMMABLE-BOUNDARY-START(81604877119),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$WRsM.LCACSD.Table).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245138751,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309909823,
        "f": 83886081
      },
      "n": "TableManagers",
      "d": 498495,
      "h": 81604877119,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604877119)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180367679),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 498495,
      "h": 17180367679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180367679)
  ],
  "h": 498495
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Models.AppState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Models${separator}AppState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(498495)
        
        

        //--TRIMMABLE-BOUNDARY-START(1874751)
        $asm.$cls(`$WRsM.LCACSD.TableValueBinder<>`, (T) => $asm.$gt(`$WRsM.LCACSD.TableValueBinder<>`, [T], ($self) => class TableValueBinder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361613119)
            /*Action<T>*/ OnSet = null;
            //--TRIMMABLE-BOUNDARY-END(34361613119)
            
            //--TRIMMABLE-BOUNDARY-START(4296842047)
            /*T*/ _value = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(4296842047)
            
            //--TRIMMABLE-BOUNDARY-START(51541482303)
            /*TableViewModel*/ table = null;
            //--TRIMMABLE-BOUNDARY-END(51541482303)
            
            //--TRIMMABLE-BOUNDARY-START(38656580415)
            /*TableRowModel*/ row = null;
            //--TRIMMABLE-BOUNDARY-END(38656580415)
            
            //--TRIMMABLE-BOUNDARY-START(12886776639)
            $ctor$1(/*TableViewModel*/ table, /*TableRowModel*/ row, /*T*/ value, /*Action<T>*/ onSet)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886776639);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.table = table;
                    this.row = row;
                    this._value = value;
                    this.OnSet = onSet;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886776639)
            
            //--TRIMMABLE-BOUNDARY-START(55836449599)
            /*T */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066645823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*T */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246515007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.SCG.EqualityComparer$$(T).Default.Equals$2(this._value, value))
                {
                    this._value = value;
                    this.OnSet.Invoke(value);
                    this.table.MarkDirty(this.row);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836449599)
            
            static $H = 1874751;
            static $h = 1874751;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361613119),
    {
      "p": $.$$.S.Action$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476711231,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "n": "OnSet",
      "d": this.$h,
      "H": 34361613119,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361613119),
//--TRIMMABLE-BOUNDARY-START(55836449599),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066645823,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47246515007,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "Value",
      "d": this.$h,
      "H": 55836449599,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836449599)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296842047),
    {
      "t": T?.$h??1572864,
      "n": "_value",
      "d": this.$h,
      "H": 4296842047,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296842047),
//--TRIMMABLE-BOUNDARY-START(51541482303),
    {
      "t": 2530111,
      "n": "table",
      "d": this.$h,
      "H": 51541482303,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541482303),
//--TRIMMABLE-BOUNDARY-START(38656580415),
    {
      "t": 2071359,
      "n": "row",
      "d": this.$h,
      "H": 38656580415,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656580415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886776639),
    {
      "p": [
        {
          "n": "table",
          "p": 2530111
        },
        {
          "n": "row",
          "p": 2071359
        },
        {
          "n": "value",
          "p": T?.$h??1572864
        },
        {
          "n": "onSet",
          "p": $.$$.S.Action$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12886776639,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886776639)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1874751,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.TableValueBinder<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}TableValueBinder$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1874751)
        
        

        //--TRIMMABLE-BOUNDARY-START(3119935)
        $asm.$cls(`$WRsM.LCACSS$1.SystemStatesCustomAttributesProvider`, ($self) => class SystemStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298087231)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298087231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298087231)
            
            static $h = 3119935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298087231),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3119935,
      "h": 4298087231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298087231)
  ],
  "h": 3119935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3119935)
        
        

        //--TRIMMABLE-BOUNDARY-START(3513151)
        $asm.$cls(`$WRsM.LCAC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298480447)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298480447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WRsM.LCACM.EditModelTypeDescriptorBuilder.Register();
                $.$WRsM.LCACSDV.TableRowModelTypeDescriptorBuilder.Register();
                $.$WRsM.LCACSS$1.SystemStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298480447)
            
            static $h = 3513151;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298480447),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3513151,
      "h": 4298480447,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298480447)
  ],
  "h": 3513151
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3513151)
        
        

        //--TRIMMABLE-BOUNDARY-START(367423)
        $asm.$cls(`$WRsM.LCAC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295334719)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295334719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WRsM.LCACM.EditModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WRsM.LCACM.EditModelCustomAttributesProvider, $.$WRsM.LCACM.EditModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WRsM.LCACSDV.TableRowState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WRsM.LCACSDV.TableRowStateCustomAttributesProvider, $.$WRsM.LCACSDV.TableRowStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WRsM.LCACSDV.TableRowModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WRsM.LCACSDV.TableRowModelCustomAttributesProvider, $.$WRsM.LCACSDV.TableRowModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WRsM.LCACSS$1.SystemStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WRsM.LCACSS$1.SystemStatesCustomAttributesProvider, $.$WRsM.LCACSS$1.SystemStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295334719)
            
            static $h = 367423;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295334719),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 367423,
      "h": 4295334719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295334719)
  ],
  "h": 367423
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(367423)
        
        

        //--TRIMMABLE-BOUNDARY-START(432959)
        $asm.$cls(`$WRsM.LCAC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295400255)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295400255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295400255)
            
            static $h = 432959;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295400255),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 432959,
      "h": 4295400255,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295400255)
  ],
  "h": 432959
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(432959)
        
        

        //--TRIMMABLE-BOUNDARY-START(301887)
        $asm.$cls(`$WRsM.LCAC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295269183)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295269183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$WRsM.LCAC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295269183)
            
            static $h = 301887;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295269183),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 301887,
      "h": 4295269183,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295269183)
  ],
  "h": 301887
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(301887)
        
        

        //--TRIMMABLE-BOUNDARY-START(629567)
        $asm.$cls(`$WRsM.LCACM.EditModelCustomAttributesProvider`, ($self) => class EditModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295596863)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295596863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295596863)
            
            static $h = 629567;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295596863),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 629567,
      "h": 4295596863,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295596863)
  ],
  "h": 629567
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Models.EditModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Models${separator}EditModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(629567)
        
        

        //--TRIMMABLE-BOUNDARY-START(760639)
        $asm.$cls(`$WRsM.LCACM.EditModelTypeDescriptorBuilder`, ($self) => class EditModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590695231)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590695231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WRsM.LCACM.EditModelTypeDescriptor()
                        const $t1 = $.$WRsM.LCACM.EditModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Admin.Client.Models.EditModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ufAPsf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":760639,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WRsM.LCACM.EditModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590695231)
            
            //--TRIMMABLE-BOUNDARY-START(4295727935)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295727935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295727935)
            
            //--TRIMMABLE-BOUNDARY-START(4295727935)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295727935)
            
            static $h = 760639;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590695231),
    {
      "r": 65537,
      "n": "Register",
      "d": 760639,
      "h": 8590695231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590695231)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295727935),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 760639,
      "h": 4295727935,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295727935)
  ],
  "h": 760639
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Models.EditModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Models${separator}EditModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(760639)
        
        

        //--TRIMMABLE-BOUNDARY-START(2136895)
        $asm.$cls(`$WRsM.LCACSDV.TableRowModelCustomAttributesProvider`, ($self) => class TableRowModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297104191)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297104191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297104191)
            
            static $h = 2136895;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297104191),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2136895,
      "h": 4297104191,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297104191)
  ],
  "h": 2136895
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2136895)
        
        

        //--TRIMMABLE-BOUNDARY-START(2399039)
        $asm.$cls(`$WRsM.LCACSDV.TableRowStateCustomAttributesProvider`, ($self) => class TableRowStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297366335)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297366335)
            
            //--TRIMMABLE-BOUNDARY-START(8592333631)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592333631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WRsM.LCACSDV.TableRowStateCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WRsM.LCACSDV.TableRowStateCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $LIaUdb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2399039,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $SxFdkb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2399039,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592333631)
            
            static $h = 2399039;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592333631),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2399039,
      "h": 8592333631,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592333631)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297366335),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2399039,
      "h": 4297366335,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297366335)
  ],
  "h": 2399039
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2399039)
        
        

        //--TRIMMABLE-BOUNDARY-START(170815)
        $asm.$cls(`$WRsM._LCACSSS.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295138111)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295138111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295138111)
            
            //--TRIMMABLE-BOUNDARY-START(8590105407)
            static /*void */ CreatePropertySheet_1(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*T*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg2, /*int*/ __seq3, /*global::System.Int32*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590105407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Editable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "Target", $.$box(__arg1, T));
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq3, "PadContent", $.$box(__arg3, $.$$.S.Int32));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590105407)
            
            static $h = 170815;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295138111),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 170815,
      "h": 4295138111,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295138111),
//--TRIMMABLE-BOUNDARY-START(8590105407),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => T.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 14505642
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 655361
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_1",
      "d": 170815,
      "h": 8590105407,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590105407)
  ],
  "h": 170815
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Admin.Client.Shared.SystemStates.SystemState.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemState${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(170815)
        
        

        //--TRIMMABLE-BOUNDARY-START(3251007)
        $asm.$cls(`$WRsM.LCACSS$1.SystemStatesTypeDescriptorBuilder`, ($self) => class SystemStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593185599)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593185599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WRsM.LCACSS$1.SystemStatesTypeDescriptor()
                        const $t1 = $.$WRsM.LCACSS$1.SystemStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iGZhIg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3251007,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WRsM.LCACSS$1.SystemStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593185599)
            
            //--TRIMMABLE-BOUNDARY-START(4298218303)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298218303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298218303)
            
            //--TRIMMABLE-BOUNDARY-START(4298218303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298218303)
            
            static $h = 3251007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593185599),
    {
      "r": 65537,
      "n": "Register",
      "d": 3251007,
      "h": 8593185599,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593185599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298218303),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3251007,
      "h": 4298218303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298218303)
  ],
  "h": 3251007
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3251007)
        
        

        //--TRIMMABLE-BOUNDARY-START(105279)
        $asm.$cls(`$WRsM._LCACSDT.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295072575)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295072575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295072575)
            
            static $h = 105279;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295072575),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 105279,
      "h": 4295072575,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295072575)
  ],
  "h": 105279
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Admin.Client.Shared.DataTable.TableRow.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}TableRow${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(105279)
        
        

        //--TRIMMABLE-BOUNDARY-START(891711)
        $asm.$cls(`$WRsM.LCAC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590826303)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590826303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$WRsM.LCACP.App, "LivingThing.Core.Admin.Client", "Pages\\App", "App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin", "/Admin/{*PageRoute}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590826303)
            
            //--TRIMMABLE-BOUNDARY-START(4295859007)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295859007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295859007)
            
            //--TRIMMABLE-BOUNDARY-START(4295859007)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295859007)
            
            static $h = 891711;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590826303),
    {
      "r": 65537,
      "n": "Build",
      "d": 891711,
      "h": 8590826303,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590826303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295859007),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 891711,
      "h": 4295859007,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295859007)
  ],
  "h": 891711
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(891711)
        
        

        //--TRIMMABLE-BOUNDARY-START(2267967)
        $asm.$cls(`$WRsM.LCACSDV.TableRowModelTypeDescriptorBuilder`, ($self) => class TableRowModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592202559)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592202559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WRsM.LCACSDV.TableRowModelTypeDescriptor()
                        const $t1 = $.$WRsM.LCACSDV.TableRowModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YiwXHc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2267967,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WRsM.LCACSDV.TableRowModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592202559)
            
            //--TRIMMABLE-BOUNDARY-START(4297235263)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297235263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297235263)
            
            //--TRIMMABLE-BOUNDARY-START(4297235263)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297235263)
            
            static $h = 2267967;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592202559),
    {
      "r": 65537,
      "n": "Register",
      "d": 2267967,
      "h": 8592202559,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592202559)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297235263),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2267967,
      "h": 4297235263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297235263)
  ],
  "h": 2267967
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2267967)
        
        

        //--TRIMMABLE-BOUNDARY-START(3447615)
        $asm.$cls(`$WRsM.LCACS$2.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593382207)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593382207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.ContactModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$WRsM.LCACS.ContactMesssageComposerProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.ContactModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WRsM.LCACS.ContactMesssageComposerProvider, x);
                }, $LcIqra ??= {"r":$.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.ContactModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":3447615,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WRsM.LCACS.ContactMesssageComposerProvider, x);
                }, $bjnWSj ??= {"r":210396,"p":[{"n":"x","p":327718}],"n":"","d":3447615,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.UserModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$WRsM.LCACS.UserMesssageComposerProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.UserModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WRsM.LCACS.UserMesssageComposerProvider, x);
                }, $nSeuvf ??= {"r":$.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.UserModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":3447615,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$UrvY.LCFCM.IMessageComposerProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WRsM.LCACS.UserMesssageComposerProvider, x);
                }, $gVYXNi ??= {"r":210396,"p":[{"n":"x","p":327718}],"n":"","d":3447615,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$WRsM.LCACV.ApplicationViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ajwi.LCACS.IAdminTableColumnEditor, $.$WRsM.LCACS.PluginAttributesColumnEditor, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593382207)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$WRsM.LCACS$2.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298414911)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298414911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298414911)
            
            //--TRIMMABLE-BOUNDARY-START(4298414911)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298414911)
            
            static $h = 3447615;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593382207),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3447615,
      "h": 8593382207,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593382207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298414911),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3447615,
      "h": 4298414911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298414911)
  ],
  "h": 3447615
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Startup.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Startup${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3447615)
        
        

        //--TRIMMABLE-BOUNDARY-START(1153855)
        $asm.$cls(`$WRsM.LCACS.PluginAttributesColumnEditor`, ($self) => class PluginAttributesColumnEditor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1219391)
            static $_KnownPlugin;
            static get KnownPlugin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1219391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$WRsM.LCACS.PluginAttributesColumnEditor;
                return $cls.$_KnownPlugin ??= $asm.$ncls(`$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin`, ($self) => class KnownPlugin extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(81605598015)
                    /*string*/ TableType = null;
                    //--TRIMMABLE-BOUNDARY-END(81605598015)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540826943)
                    /*string*/ PluginType = null;
                    //--TRIMMABLE-BOUNDARY-END(51540826943)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476055871)
                    /*Type*/ AttributeType = null;
                    //--TRIMMABLE-BOUNDARY-END(21476055871)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181088575)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181088575);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181088575)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181088575)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181088575)
                    
                    static $h = 1219391;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605598015),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245859647,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310630719,
        "f": 83886081
      },
      "n": "TableType",
      "d": 1219391,
      "h": 81605598015,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605598015),
//--TRIMMABLE-BOUNDARY-START(51540826943),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655925055,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720696127,
        "f": 83886081
      },
      "n": "PluginType",
      "d": 1219391,
      "h": 51540826943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540826943),
//--TRIMMABLE-BOUNDARY-START(21476055871),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065990463,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130761535,
        "f": 83886081
      },
      "n": "AttributeType",
      "d": 1219391,
      "h": 21476055871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476055871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181088575),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1219391,
      "h": 17181088575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181088575)
  ],
  "d": 1153855,
  "h": 1219391
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Services.PluginAttributesColumnEditor+KnownPlugin`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Services${separator}PluginAttributesColumnEditor${separator}KnownPlugin`; }
                }, $cls, ($v) => $cls.$_KnownPlugin = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1219391)
            
            //--TRIMMABLE-BOUNDARY-START(1284927)
            static $_KnownPlugin$$;
            static KnownPlugin$$(TAttributes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1284927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$WRsM.LCACS.PluginAttributesColumnEditor;
                return ($cls.$_KnownPlugin$$ ??= $asm.$ncls(`$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin<>`, (TAttributes) => $asm.$gt(`$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin<>`, [TAttributes], ($self) => class KnownPlugin$$ extends $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin
                {
                    //--TRIMMABLE-BOUNDARY-START(4296252223)
                    $ctor$2(/*string*/ table, /*string*/ plugin)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296252223);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.TableType = table;
                            this.PluginType = plugin;
                            this.AttributeType = TAttributes.$type;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296252223)
                    
                    static $H = 1284927;
                    static $h = 1284927;
                    static $g = 1;
                    static $f = 0b10000000001010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296252223),
    {
      "p": [
        {
          "n": "table",
          "p": 1310721
        },
        {
          "n": "plugin",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296252223,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296252223)
  ],
  "s": [
    {
      "h": TAttributes?.$h??1572864,
      "n": "TAttributes"
    }
  ],
  "r": 1,
  "d": 1153855,
  "H": 1284927,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Services.PluginAttributesColumnEditor+KnownPlugin<${TAttributes?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Services${separator}PluginAttributesColumnEditor${separator}KnownPlugin$${TAttributes?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_KnownPlugin$$ = $v))(TAttributes);
            }
            //--TRIMMABLE-BOUNDARY-END(1284927)
            
            //--TRIMMABLE-BOUNDARY-START(25770957631)
            /*IEnumerable<KnownPlugin>*/ static KnownPlugins = null;
            //--TRIMMABLE-BOUNDARY-END(25770957631)
            
            //--TRIMMABLE-BOUNDARY-START(30065924927)
            /*IUIService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(30065924927)
            
            //--TRIMMABLE-BOUNDARY-START(12886055743)
            $ctor$1(/*IUIService*/ ui)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886055743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UI = ui;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886055743)
            
            //--TRIMMABLE-BOUNDARY-START(17181023039)
            /*bool */ CanEdit(/*TableRowType*/ table, /*TablePropertyColumn*/ column)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181023039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return column.Name === "Attributes" && $.$sl.SL.Enumerable.Any($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugins, new ($.$$.S.Func$$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.TableType === $.$$.System.Array.$ReadT1.call(table.Aliases, 0);
                }, $xzNWSc ??= {"r":262145,"p":[{"n":"p","p":1219391}],"n":"","d":1153855,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(17181023039)
            
            //--TRIMMABLE-BOUNDARY-START(4296121151)
            /*ValueTask *//*async*/  _Edit(T, /*T*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296121151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Form(T, "Edit Attributes", null, "OK", "Cancel", data), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4296121151)
            
            //--TRIMMABLE-BOUNDARY-START(21475990335)
            /*Task *//*async*/  Edit(/*TableDefinition*/ definitions, /*TableRowType*/ table, /*TablePropertyColumn*/ column, /*IDictionary<string, IObservableDataDescriptor>*/ rowData, /*IObservableDataDescriptor*/ columnData)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475990335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let kps = $.$sl.SL.Enumerable.Where($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugins, new ($.$$.S.Func$$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$$.S.Boolean))().$ctor(this,  (/**/ p) =>
                    {
                        return p.TableType === $.$$.System.Array.$ReadT1.call(table.Aliases, 0);
                    }, $ehiRwd ??= {"r":262145,"p":[{"n":"p","p":1219391}],"n":"","d":1153855,"h":0,"f":17825794}));
                    /*KnownPlugin*/ let kp = null;
                    if ($.$sl.SL.Enumerable.Count$1($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, kps) > 1)
                    {
                        /*LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?*/ let __ca1__;
                        /*var*/ let family = ((__ca1__ = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, rowData, "family")) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                        if (family !== null)
                        {
                            kp = $.$sl.SL.Enumerable.Single($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, kps, new ($.$$.S.Func$$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$$.S.Boolean))().$ctor(this,  (/*k*/ k) =>
                            {
                                return $.$$.S.String.StartsWith$3.call(family, k.PluginType);
                            }, $RpJvil ??= {"r":262145,"p":[{"n":"k","p":1219391}],"n":"","d":1153855,"h":0,"f":17825794}));
                        }
                        else 
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                    }
                    else 
                    {
                        kp = $.$sl.SL.Enumerable.First$1($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, kps);
                    }
                    /*object?*/ let __ca2__;
                    /*string?*/ let __ca3__;
                    /*var*/ let model = ((__ca2__ = columnData.LCFCD$IValueProvider$Value) !== null ? (((__ca3__ = $.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString)) !== null ? ($.$fPer.LCFCS$1.JsonSerializeExtension.DeSerializeAs$2(__ca3__, kp.AttributeType) ?? $.$$.S.Activator.CreateInstance$9(kp.AttributeType)) : $.$$.S.Activator.CreateInstance$9(kp.AttributeType)) ?? $.$$.S.Activator.CreateInstance$9(kp.AttributeType)) : $.$$.S.Activator.CreateInstance$9(kp.AttributeType));
                    ($t2 = this._Edit(T, model), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    columnData.LCFCD$IValueProvider$Value = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, model, true, false, true, false, false, false, false, "Edit", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\PluginAttributesColumnEditor.cs", "Edit", 104);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475990335)
            
            //--TRIMMABLE-BOUNDARY-START(4295808121)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Services.IAdminTableColumnEditor.CanEdit(LivingThing.Core.Admin.Common.Models.TableRowType, LivingThing.Core.Admin.Common.Models.TablePropertyColumn)
            LCACS$IAdminTableColumnEditor$CanEdit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295808121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanEdit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295808121)
            
            //--TRIMMABLE-BOUNDARY-START(8590775417)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Services.IAdminTableColumnEditor.Edit(LivingThing.Core.Admin.Common.Models.TableDefinition, LivingThing.Core.Admin.Common.Models.TableRowType, LivingThing.Core.Admin.Common.Models.TablePropertyColumn, System.Collections.Generic.IDictionary<string, LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor>, LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCACS$IAdminTableColumnEditor$Edit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590775417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Edit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590775417)
            
            //--TRIMMABLE-BOUNDARY-START(8591088447)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591088447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770957631)
                    this.KnownPlugins = (() =>
                    {
                        //new $.$$.SCG.List$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin)()
                        const $t3 = $.$$.SCG.List$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin);
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        return $i3;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(25770957631)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591088447)
            
            static $h = 1153855;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181023039),
    {
      "r": 262145,
      "p": [
        {
          "n": "table",
          "p": 644217
        },
        {
          "n": "column",
          "p": 578681
        }
      ],
      "n": "CanEdit",
      "d": 1153855,
      "h": 17181023039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181023039),
//--TRIMMABLE-BOUNDARY-START(4296121151),
    {
      "r": 181338113,
      "p": [
        {
          "n": "data",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "_Edit",
      "d": 1153855,
      "h": 4296121151,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(4296121151),
//--TRIMMABLE-BOUNDARY-START(21475990335),
    {
      "r": 178454529,
      "p": [
        {
          "n": "definitions",
          "p": 513145
        },
        {
          "n": "table",
          "p": 644217
        },
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "rowData",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h
        },
        {
          "n": "columnData",
          "p": 40536406
        }
      ],
      "n": "Edit",
      "d": 1153855,
      "h": 21475990335,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475990335)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770957631),
    {
      "t": $.$$.SCG.IEnumerable$$($.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin).$h,
      "n": "KnownPlugins",
      "d": 1153855,
      "h": 25770957631,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770957631),
//--TRIMMABLE-BOUNDARY-START(30065924927),
    {
      "t": 5594536,
      "n": "UI",
      "d": 1153855,
      "h": 30065924927,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065924927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886055743),
    {
      "p": [
        {
          "n": "ui",
          "p": 5594536
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1153855,
      "h": 12886055743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886055743)
  ],
  "h": 1153855
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ajwi.LCACS.IAdminTableColumnEditor ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin, $.$WRsM.LCACS.PluginAttributesColumnEditor.KnownPlugin$$(TAttributes) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Services.PluginAttributesColumnEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Services${separator}PluginAttributesColumnEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1153855)
        
        

        //--TRIMMABLE-BOUNDARY-START(826175)
        $asm.$cls(`$WRsM.LCAC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180695359)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACP.App.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACP.App().$ctor$4();
                    }, $TcFLka ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACS$1.Contacts.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACS$1.Contacts().$ctor$3();
                    }, $wFqdqj ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.DataTableGroupApplicationPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.DataTableGroupApplicationPage().$ctor$3();
                    }, $BXKTQc ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.DataTableManager.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.DataTableManager().$ctor$4();
                    }, $aUitrj ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.Table.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.Table().$ctor$4();
                    }, $csfTWe ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.TableApplicationPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.TableApplicationPage().$ctor$3();
                    }, $TXVeng ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.TableColumn.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.TableColumn().$ctor$4();
                    }, $JpVHYi ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSD.TableRow.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSD.TableRow().$ctor$4();
                    }, $RPswxg ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSN.Newsletter.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSN.Newsletter().$ctor$3();
                    }, $iEKRoh ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSP.GlobalSettingsPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSP.GlobalSettingsPage().$ctor$3();
                    }, $XWAQWj ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSS.ServiceTaskCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSS.ServiceTaskCard().$ctor$4();
                    }, $Wowpej ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSS.ServiceTasksManager.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSS.ServiceTasksManager().$ctor$4();
                    }, $CZGBbg ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSS$1.SystemState.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSS$1.SystemState().$ctor$4();
                    }, $ahXwhk ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WRsM.LCACSS$1.SystemStates.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WRsM.LCACSS$1.SystemStates().$ctor$4();
                    }, $XTdylh ??= {"r":2752627,"n":"","d":826175,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180695359)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295793471)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295793471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295793471)
            
            //--TRIMMABLE-BOUNDARY-START(4295793471)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295793471)
            
            static $h = 826175;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180695359),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885728063,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 826175,
      "h": 17180695359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180695359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295793471),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 826175,
      "h": 4295793471,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295793471)
  ],
  "h": 826175
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(826175)
        
        

        //--TRIMMABLE-BOUNDARY-START(3578687)
        $asm.$cls(`$WRsM.LCACV.AdminDashboardTableProvider`, ($self) => class AdminDashboardTableProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593513279)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593513279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8593513279)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(4298545983)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298545983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298545983)
            
            //--TRIMMABLE-BOUNDARY-START(4298545983)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298545983)
            
            static $h = 3578687;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593513279),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "defaultValue",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 3578687,
      "h": 8593513279,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(8593513279)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298545983),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3578687,
      "h": 4298545983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298545983)
  ],
  "h": 3578687
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.ViewModels.AdminDashboardTableProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}ViewModels${separator}AdminDashboardTableProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3578687)
        
        

        //--TRIMMABLE-BOUNDARY-START(3709759)
        $asm.$cls(`$WRsM.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298677055)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298677055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298677055)
            
            //--TRIMMABLE-BOUNDARY-START(4298677055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298677055)
            
            static $h = 3709759;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298677055),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3709759,
      "h": 4298677055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298677055)
  ],
  "h": 3709759
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3709759)
        
        

        //--TRIMMABLE-BOUNDARY-START(3775295)
        $asm.$cls(`$WRsM.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298742591)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298742591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298742591)
            
            //--TRIMMABLE-BOUNDARY-START(4298742591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298742591)
            
            static $h = 3775295;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298742591),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3775295,
      "h": 4298742591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298742591)
  ],
  "h": 3775295,
  "a": [
    {
      "t": 3709759,
      "c": 4298677055
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3775295)
        
        

        //--TRIMMABLE-BOUNDARY-START(2333503)
        $asm.$str(`$WRsM.LCACSDV.TableRowState`, ($self) => class TableRowState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Added = 1;
            static Removed = 2;
            static Updated = 4;
            static Deleted = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2333503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Added": 1n,
                    "Removed": 2n,
                    "Updated": 4n,
                    "Deleted": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297300799)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297300799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297300799)
            
            //--TRIMMABLE-BOUNDARY-START(4297300799)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297300799)
            
            static $h = 2333503;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182202687),
    {
      "t": 2333503,
      "n": "None",
      "d": 2333503,
      "h": 17182202687,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182202687),
//--TRIMMABLE-BOUNDARY-START(8592268095),
    {
      "t": 2333503,
      "n": "Added",
      "d": 2333503,
      "h": 8592268095,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592268095),
//--TRIMMABLE-BOUNDARY-START(21477169983),
    {
      "t": 2333503,
      "n": "Removed",
      "d": 2333503,
      "h": 21477169983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477169983),
//--TRIMMABLE-BOUNDARY-START(25772137279),
    {
      "t": 2333503,
      "n": "Updated",
      "d": 2333503,
      "h": 25772137279,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772137279),
//--TRIMMABLE-BOUNDARY-START(12887235391),
    {
      "t": 2333503,
      "n": "Deleted",
      "d": 2333503,
      "h": 12887235391,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887235391)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297300799),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2333503,
      "h": 4297300799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297300799)
  ],
  "h": 2333503,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2333503)
        
        

        //--TRIMMABLE-BOUNDARY-START(236351)
        $asm.$cls(`$WRsM.LCAC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590170943)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590170943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590170943)
            
            //--TRIMMABLE-BOUNDARY-START(4295203647)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295203647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295203647)
            
            //--TRIMMABLE-BOUNDARY-START(4295203647)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295203647)
            
            static $h = 236351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590170943),
    {
      "r": 65537,
      "n": "Execute",
      "d": 236351,
      "h": 8590170943,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590170943)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295203647),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 236351,
      "h": 4295203647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295203647)
  ],
  "h": 236351
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(236351)
        
        

        //--TRIMMABLE-BOUNDARY-START(1481535)
        $asm.$cls(`$WRsM.LCACSD.DataTableGroupApplicationPage`, ($self) => class DataTableGroupApplicationPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(47246121791)
            /*IGrouping<string, TableViewModel>*/ Tables = null;
            //--TRIMMABLE-BOUNDARY-END(47246121791)
            
            //--TRIMMABLE-BOUNDARY-START(34361219903)
            /*string */ get OptimizedComponentName()
            {
                return "datatablegroupapplicationpage";
            }
            //--TRIMMABLE-BOUNDARY-END(34361219903)
            
            //--TRIMMABLE-BOUNDARY-START(51541089087)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541089087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Tables":
                    this.Tables = $.$cast(parameter.Value, $.$sl.SL.IGrouping$$$($.$$.S.String, $.$WRsM.LCACSDV.TableViewModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51541089087)
            
            //--TRIMMABLE-BOUNDARY-START(12886383423)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886383423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "h1");
                __builder.AddAttribute$5(1, "class", "mgt-0");
                __builder.AddContent$4(2, this.Tables.SL$IGrouping$$$$Key);
                __builder.CloseElement();
                __builder.AddMarkupContent(3, "\r\n");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "container");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "row responsive");
                let $en2 = this.Tables.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let table = $en2.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(8, "div");
                        __builder.AddAttribute$5(9, "class", "col-3 miwx-3");
                        __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 10);
                        __builder.AddAttribute$3(11, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(12, "h3");
                            __builder2.AddAttribute$5(13, "class", "text-center mgt-0");
                            __builder2.AddContent$4(14, table.TableRowType.Name);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(15, "\r\n                    ");
                            __builder2.OpenElement(16, "h4");
                            __builder2.AddContent$4(17, "Clipboard (");
                            __builder2.AddContent$3(18, $.$box($.$sl.SL.Enumerable.Count$1($.$WRsM.LCACSDV.TableRowModel, table.Clipboard), $.$$.S.Int32));
                            __builder2.AddContent$4(19, ")");
                            __builder2.CloseElement();
                        }), $yleExi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1481535,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12886383423)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591416127)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591416127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591416127)
            
            //--TRIMMABLE-BOUNDARY-START(8591416127)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591416127)
            
            static $h = 1481535;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246121791),
    {
      "p": $.$sl.SL.IGrouping$$$($.$$.S.String, $.$WRsM.LCACSDV.TableViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066252607,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951154495,
        "f": 83886081
      },
      "n": "Tables",
      "d": 1481535,
      "h": 47246121791,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246121791),
//--TRIMMABLE-BOUNDARY-START(34361219903),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476318015,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1481535,
      "h": 34361219903,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361219903)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541089087),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1481535,
      "h": 51541089087,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541089087),
//--TRIMMABLE-BOUNDARY-START(12886383423),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1481535,
      "h": 12886383423,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886383423)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591416127),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1481535,
      "h": 8591416127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591416127)
  ],
  "h": 1481535
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.DataTableGroupApplicationPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}DataTableGroupApplicationPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1481535)
        
        

        //--TRIMMABLE-BOUNDARY-START(2595647)
        $asm.$cls(`$WRsM.LCACSN.Newsletter`, ($self) => class Newsletter extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42952268607)
            /*IEnumerable<IMessageComposerProvider>*/ Providers = null;
            //--TRIMMABLE-BOUNDARY-END(42952268607)
            
            //--TRIMMABLE-BOUNDARY-START(51542203199)
            /*IMessageComposerProvider?*/ selectedProvider = null;
            //--TRIMMABLE-BOUNDARY-END(51542203199)
            
            //--TRIMMABLE-BOUNDARY-START(47247235903)
            /*void */ Select(/*IMessageComposerProvider?*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247235903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selectedProvider = provider;
            }
            //--TRIMMABLE-BOUNDARY-END(47247235903)
            
            //--TRIMMABLE-BOUNDARY-START(38657301311)
            /*string */ get OptimizedComponentName()
            {
                return "newsletter";
            }
            //--TRIMMABLE-BOUNDARY-END(38657301311)
            
            //--TRIMMABLE-BOUNDARY-START(34362334015)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362334015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Providers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.IMessageComposerProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34362334015)
            
            //--TRIMMABLE-BOUNDARY-START(12887497535)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887497535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.selectedProvider === null)
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "mgt-10 grid gap-1 colm-15");
                    let $en1 = this.Providers.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let provider = $en1.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(2, "div");
                            __builder.AddAttribute$5(3, "class", "bg-card bd corner clickable");
                            __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                            {
                                return this.Select(provider);
                            }, $QszSol ??= {"r":65537,"n":"","d":2595647,"h":0,"f":17825794})));
                            __builder.OpenElement(5, "div");
                            __builder.AddMultipleAttributes(6, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "hx-1 bdb flex"))));
                            if (provider.LCFC$IDisplayable$Icon.IsImage)
                            {
                                __builder.OpenElement(7, "img");
                                __builder.AddAttribute$5(8, "src", $.$strNN((this.ResolvePath(provider.LCFC$IDisplayable$Icon.Icon, true, false, false))) + "?height=200");
                                __builder.AddAttribute$5(9, "class", "mgx-a mgy mahf");
                                __builder.CloseElement();
                            }
                            else 
                            {
                                __builder.OpenElement(10, "i");
                                __builder.AddMultipleAttributes(11, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), `${$.$strNN(provider.LCFC$IDisplayable$Icon.ToString())} fsz-70 mg-a`))));
                                __builder.CloseElement();
                            }
                            __builder.CloseElement();
                            __builder.AddMarkupContent(12, "\r\n                ");
                            __builder.OpenElement(13, "div");
                            __builder.AddAttribute$5(14, "class", "pd");
                            __builder.OpenElement(15, "h3");
                            __builder.AddAttribute$5(16, "class", "mg-0");
                            __builder.AddContent$4(17, provider.LCFC$IDisplayable$Title);
                            __builder.CloseElement();
                            __builder.AddMarkupContent(18, "\r\n                    ");
                            __builder.OpenElement(19, "small");
                            __builder.AddAttribute$5(20, "class", "nowrap-2");
                            __builder.AddContent$4(21, provider.LCFC$IDescribable$Description);
                            __builder.CloseElement();
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(22, "button");
                    __builder.AddAttribute$5(23, "class", "pos-abs r-0 t-0 mdi mdi-close bg-transparent fsz-20");
                    __builder.AddAttribute$5(24, "title", "Back to Providers");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 25, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.selectedProvider = null;
                    }, $IHUbIe ??= {"r":65537,"n":"","d":2595647,"h":0,"f":17825794})));
                    __builder.CloseElement();
                    __builder.AddMarkupContent(26, "\r\n    ");
                    __builder.OpenElement(27, "LivingThing.Core.Frameworks.Client.Utility.NewsletterComposer");
                    __builder.AddAttribute$5(28, "Provider", "selectedProvider");
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887497535)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592530239)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592530239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592530239)
            
            //--TRIMMABLE-BOUNDARY-START(8592530239)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592530239)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42952268607)
                this.Providers = null;
                //--TRIMMABLE-BOUNDARY-END(42952268607)
                
            }
            static $h = 2595647;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952268607),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.IMessageComposerProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067366719,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132137791,
        "f": 83886081
      },
      "n": "Providers",
      "d": 2595647,
      "h": 42952268607,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952268607),
//--TRIMMABLE-BOUNDARY-START(38657301311),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477432127,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2595647,
      "h": 38657301311,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657301311)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47247235903),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 210396
        }
      ],
      "n": "Select",
      "d": 2595647,
      "h": 47247235903,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47247235903),
//--TRIMMABLE-BOUNDARY-START(34362334015),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2595647,
      "h": 34362334015,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362334015),
//--TRIMMABLE-BOUNDARY-START(12887497535),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2595647,
      "h": 12887497535,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887497535)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51542203199),
    {
      "t": 210396,
      "n": "selectedProvider",
      "d": 2595647,
      "h": 51542203199,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51542203199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592530239),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2595647,
      "h": 8592530239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592530239)
  ],
  "h": 2595647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.NewsLetter.Newsletter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}NewsLetter${separator}Newsletter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2595647)
        
        

        //--TRIMMABLE-BOUNDARY-START(1678143)
        $asm.$cls(`$WRsM.LCACSD.TableApplicationPage`, ($self) => class TableApplicationPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77311089471)
            /*TableViewModel*/ Table = null;
            //--TRIMMABLE-BOUNDARY-END(77311089471)
            
            //--TRIMMABLE-BOUNDARY-START(51541285695)
            /*EventCallback<TableViewModel>*/ OnShowing;
            //--TRIMMABLE-BOUNDARY-END(51541285695)
            
            //--TRIMMABLE-BOUNDARY-START(4296645439)
            /*Task<bool> */ _OnShowing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296645439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnShowing.InvokeAsync$1(this.Table);
                return $.$$.STT.Task.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(4296645439)
            
            //--TRIMMABLE-BOUNDARY-START(55836252991)
            /*string */ get OptimizedComponentName()
            {
                return "tableapplicationpage";
            }
            //--TRIMMABLE-BOUNDARY-END(55836252991)
            
            //--TRIMMABLE-BOUNDARY-START(81606056767)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606056767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Table":
                    this.Table = $.$cast(parameter.Value, $.$WRsM.LCACSDV.TableViewModel);
                    return true;
                    case "OnShowing":
                    this.OnShowing = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81606056767)
            
            //--TRIMMABLE-BOUNDARY-START(21476514623)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476514623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "OnShowing", "_OnShowing");
                __builder.AddComponentParameter(2, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$strNN(this.Table.DataTable.TableDefinition.Name) + "/") + $.$strNN(this.Table.TableRowType.Name)));
                __builder.AddComponentParameter(3, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2($.$strNN($.$strNN(this.Table.DataTable.TableDefinition.Name) + "/") + $.$strNN($.$$.S.String.Replace$3.call(this.Table.TableRowType.ToString(), ".", "-")))));
                __builder.AddAttribute$3(4, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(5, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(this.Table.TableRowType.Name));
                    }, $QmXvii ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1678143,"h":0,"f":17825794});
                }), $XoKhwc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1678143,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 7);
                        __builder2.AddComponentParameter(8, "Class", "mdi mdi-database");
                        __builder2.CloseComponent();
                    }, $HnwJFa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1678143,"h":0,"f":17825794});
                }), $LpNnll ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1678143,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$WRsM.LCACSD.Table, 10);
                        __builder2.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableViewModel, this.Table));
                        __builder2.AddComponentParameter(12, "Class", "fill");
                        __builder2.CloseComponent();
                    }, $JHGthg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1678143,"h":0,"f":17825794});
                }), $bqNpQc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1678143,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21476514623)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181547327)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181547327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181547327)
            
            //--TRIMMABLE-BOUNDARY-START(17181547327)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181547327)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51541285695)
                this.OnShowing = $.$default($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel));
                //--TRIMMABLE-BOUNDARY-END(51541285695)
                
            }
            static $h = 1678143;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311089471),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246318399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016122175,
        "f": 83886081
      },
      "n": "Table",
      "d": 1678143,
      "h": 77311089471,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311089471),
//--TRIMMABLE-BOUNDARY-START(51541285695),
    {
      "p": $.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066449215,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426187583,
        "f": 83886081
      },
      "n": "OnShowing",
      "d": 1678143,
      "h": 51541285695,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541285695),
//--TRIMMABLE-BOUNDARY-START(55836252991),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656383807,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1678143,
      "h": 55836252991,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836252991)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296645439),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "n": "_OnShowing",
      "d": 1678143,
      "h": 4296645439,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(4296645439),
//--TRIMMABLE-BOUNDARY-START(81606056767),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1678143,
      "h": 81606056767,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606056767),
//--TRIMMABLE-BOUNDARY-START(21476514623),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1678143,
      "h": 21476514623,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476514623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181547327),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1678143,
      "h": 17181547327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181547327)
  ],
  "h": 1678143
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.TableApplicationPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}TableApplicationPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1678143)
        
        

        //--TRIMMABLE-BOUNDARY-START(1415999)
        $asm.$cls(`$WRsM.LCACS$1.Contacts`, ($self) => class Contacts extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42951088959)
            /*string */ get OptimizedComponentName()
            {
                return "contacts";
            }
            //--TRIMMABLE-BOUNDARY-END(42951088959)
            
            //--TRIMMABLE-BOUNDARY-START(64425925439)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425925439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "DashBoardTableProvider":
                    this.DashBoardTableProvider = $.$cast(parameter.Value, $.$WRsM.LCACV.AdminDashboardTableProvider);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(64425925439)
            
            //--TRIMMABLE-BOUNDARY-START(12886317887)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886317887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$Iaui.LCFCM.ContactModel), 0);
                __builder.AddComponentParameter(1, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.DashBoardTableProvider));
                __builder.AddComponentParameter(2, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                __builder.AddComponentParameter(3, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                __builder.AddAttribute$3(4, "Commands", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$Iaui.LCFCM.ContactModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Iaui.LCFCM.ContactModel))))().$ctor(this, ( (/*command*/ command) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if (command.Location === 1/*DataListToolBarCommandLocation.Right*/)
                        {
                            __builder2.OpenElement(5, "span");
                            __builder2.AddAttribute$5(6, "title", "Upload Contact");
                            __builder2.AddAttribute$5(7, "class", "mgy-a");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCF.FileUpload, 8);
                            __builder2.AddComponentParameter(9, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN($.$hDPm.LCFCCD$1.DataListFilter.ButtonClass)} mdi mdi-upload pdx-2`));
                            __builder2.AddComponentParameter(10, "OnFileSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), $.$$.STT.Task))().$ctor(this, this.ContactCSVUploaded))));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(11, "\r\n            ");
                            __builder2.OpenElement(12, "span");
                            __builder2.AddAttribute$5(13, "title", "Upload SMS Status");
                            __builder2.AddAttribute$5(14, "class", "mgy-a");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCF.FileUpload, 15);
                            __builder2.AddComponentParameter(16, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN($.$hDPm.LCFCCD$1.DataListFilter.ButtonClass)} mdi mdi-upload-network pdx-2`));
                            __builder2.AddComponentParameter(17, "OnFileSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), $.$$.STT.Task))().$ctor(this, this.SMSStatusCSVUploaded))));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                    }, $kfHaLk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1415999,"h":0,"f":17825794});
                }), $dsDXne ??= {"r":6881395,"p":[{"n":"command","p":$.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$Iaui.LCFCM.ContactModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Iaui.LCFCM.ContactModel)).$h}],"n":"","d":1415999,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(18, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.table = $.$cast(__value, $.$hDPm.LCFCCD.DashboardTable$$($.$Iaui.LCFCM.ContactModel));
                }, $cVLYdg ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1415999,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886317887)
            
            //--TRIMMABLE-BOUNDARY-START(60130958143)
            /*DashboardTable<ContactModel>?*/ table = null;
            //--TRIMMABLE-BOUNDARY-END(60130958143)
            
            //--TRIMMABLE-BOUNDARY-START(21476252479)
            /*AdminDashboardTableProvider*/ DashBoardTableProvider = null;
            //--TRIMMABLE-BOUNDARY-END(21476252479)
            
            //--TRIMMABLE-BOUNDARY-START(17181285183)
            /*Task *//*async*/  ContactCSVUploaded(/*IEnumerable<PickedFileInfo>*/ files)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181285183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.table.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $en3 = files.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let file = $en3.SCG$IEnumerator$$$Current;
                                {
                                    let mem = null;
                                    try
                                    {
                                        mem = new $.$$.SI.MemoryStream().$ctor$3();
                                        let stream = null;
                                        try
                                        {
                                            let $t4, $r4;
                                            let $t5, $r5;
                                            let $t6, $r6;
                                            stream = ($t4 = file.ReadAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                            ($t5 = stream.LCFCC$IFileStreamProvider$Stream.CopyToAsync$3(mem), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                            mem.Position = 0n;
                                            /*StreamReader*/ let reader = new $.$$.SI.StreamReader().$ctor$9(mem);
                                            /*var*/ let csv = ($t6 = $.$fPer.LCFCD.CSVExtension.ParseCSVAsync(reader, true, true), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                            /*int*/ let rows = $.$sl.SL.Enumerable.Count$1($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), csv.Data);
                                            /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                                            /*int*/ let cols = ((__ca1__ = csv.Header) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca1__) : 0);
                                            /*List<ContactModel>*/ let contacts = new ($.$$.SCG.List$$($.$Iaui.LCFCM.ContactModel))().$ctor$3(rows);
                                            /*Dictionary<int, Action<ContactModel, string>>*/ let writers = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String)))().$ctor$1();
                                            /*void*/  function SetFirstName(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                contact.FirstName = $.$$.S.String.Trim$1.call($.$$.S.String.Trim.call(value), /*,*/ 44);
                                            }
                                            /*void*/  function SetLastName(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                contact.LastName = $.$$.S.String.Trim$1.call($.$$.S.String.Trim.call(value), /*,*/ 44);
                                            }
                                            /*void*/  function SetGender(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                contact.Gender = value.length > 0 ? ($.$$.S.Char.ToUpper$1($.$$.S.String.get_Chars.call(value, 0)) === /*M*/ 77 ? 1/*Gender.Male*/ : $.$$.S.Char.ToUpper$1($.$$.S.String.get_Chars.call(value, 0)) === /*F*/ 70 ? 2/*Gender.Female*/ : 0/*Gender.None*/) : 0/*Gender.None*/;
                                            }
                                            /*void*/  function SetPhoneNumber(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                if (value.length >= 10)
                                                {
                                                    contact.PhoneNumber = "234" + $.$strNN($.$$.S.String.TrimStart$1.call(value, /*0*/ 48));
                                                }
                                            }
                                            /*void*/  function SetDateOfBirth(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                /*var*/ let d;
                                                /*var*/ let dd;
                                                if ($.$$.S.DateOnly.TryParseExact$5(value, "d/M/yyyy", null, 0/*System.Globalization.DateTimeStyles.None*/, $.$ref(() => d, ($v) => d = $v, $.$$.S.DateOnly)))
                                                {
                                                    contact.DateOfBirth = d;
                                                }
                                                else if ($.$$.S.DateOnly.TryParseExact$5(value, "M/d/yyyy", null, 0/*System.Globalization.DateTimeStyles.None*/, $.$ref(() => dd, ($v) => dd = $v, $.$$.S.DateOnly)))
                                                {
                                                    contact.DateOfBirth = dd;
                                                }
                                            }
                                            /*void*/  function SetOccupation(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                contact.Occupation = value;
                                            }
                                            /*void*/  function SetPollingUnit(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                            }
                                            /*string?*/ let rac = null;
                                            /*string?*/ let lga = null;
                                            /*void*/  function SetRAC(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                rac = value;
                                            }
                                            /*void*/  function SetLGA(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                lga = value;
                                            }
                                            /*void*/  function SetState(/*ContactModel*/ contact, /*string*/ value)
                                            {
                                                /*string?*/ let __ca2__;
                                                /*string?*/ let __ca3__;
                                                /*var*/ let rquot = (((__ca2__ = rac) !== null ? $.$$.S.String.Contains$1.call(__ca2__, /* */ 32) : false)) || (((__ca3__ = rac) !== null ? $.$$.S.String.Contains$1.call(__ca3__, /*/*/ 47) : false)) ? "\"" : "";
                                                /*string?*/ let __ca4__;
                                                /*string?*/ let __ca5__;
                                                /*var*/ let lgaquot = (((__ca4__ = lga) !== null ? $.$$.S.String.Contains$1.call(__ca4__, /* */ 32) : false)) || (((__ca5__ = lga) !== null ? $.$$.S.String.Contains$1.call(__ca5__, /*/*/ 47) : false)) ? "\"" : "";
                                                contact.Metadata ??= new $.$Iaui.LCFCM.ContactMetadataModel().$ctor$1();
                                                contact.Metadata.Location = `Africa/Nigeria/${$.$strNN(value)}/${$.$strNN(lgaquot)}${$.$strNN(lga)}${$.$strNN(lgaquot)}/${$.$strNN(rquot)}${$.$strNN(rac)}${$.$strNN(rquot)}`;
                                                rac = null;
                                                lga = null;
                                            }
                                            /*Dictionary<string, Action<ContactModel, string>>*/ let swriters = (() =>
                                            {
                                                //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))()
                                                const $t9 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String));
                                                const $i9 = new $t9();
                                                $i9.$ctor$1();
                                                $i9.set_Item("FirstName", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetFirstName.bind(this), $JoeTBj ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetFirstName","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("First Name", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetFirstName.bind(this), $HgUjyg ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetFirstName","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("LastName", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetLastName.bind(this), $QMQLuh ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetLastName","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Last Name", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetLastName.bind(this), $eTpBwk ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetLastName","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Gender", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetGender.bind(this), $Oplauc ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetGender","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("PhoneNumber", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetPhoneNumber.bind(this), $ByGQgi ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetPhoneNumber","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Phone Number", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetPhoneNumber.bind(this), $UKQPjl ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetPhoneNumber","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("DateOfBirth", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetDateOfBirth.bind(this), $YiEzia ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetDateOfBirth","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Date Of Birth", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetDateOfBirth.bind(this), $oERgjf ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetDateOfBirth","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Occupation", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetOccupation.bind(this), $lkWRJf ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetOccupation","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("Polling Unit", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetPollingUnit.bind(this), $wxBoLd ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetPollingUnit","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("RAC", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetRAC.bind(this), $QDqKSg ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetRAC","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("LGA", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetLGA.bind(this), $YiNoQd ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetLGA","d":1415999,"h":0,"f":16777218}));
                                                $i9.set_Item("State", new ($.$$.S.Action$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this, SetState.bind(this), $YTRrZb ??= {"r":65537,"p":[{"n":"contact","p":2762070},{"n":"value","p":1310721}],"n":"SetState","d":1415999,"h":0,"f":16777218}));
                                                return $i9;
                                            })();
                                            for(/*int*/ let col = 0; col < cols; col++)
                                            {
                                                /*var*/ let name = $.$sl.SL.Enumerable.ElementAt$1($.$$.S.String, csv.Header, col);
                                                writers.set_Item(col, swriters.get_Item(name));
                                            }
                                            for(/*int*/ let row = 0; row < rows; row++)
                                            {
                                                if (row % 1000 === 0)
                                                {
                                                    $.$scsl.S.Console.WriteLine$17(`Parsing ${$.$strNN(row)} of ${$.$strNN(rows)} (${$.$strNN(($.trunc(((row * 100) | 0) / rows)))}%)`);
                                                }
                                                /*var*/ let contact = new $.$Iaui.LCFCM.ContactModel().$ctor$2();
                                                contacts.Add(contact);
                                                for(/*int*/ let col = 0; col < cols; col++)
                                                {
                                                    /*var*/ let value = csv.get_Item$1(row, col);
                                                    writers.get_Item(col).Invoke(contact, value ?? "");
                                                }
                                            }
                                            /*var*/ let distinctContacts = $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ContactModel, $.$sl.SL.Enumerable.DistinctBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.String, contacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.String))().$ctor(this,  (/*e*/ e) =>
                                            {
                                                return e.PhoneNumber;
                                            }, $CmLkKi ??= {"r":1310721,"p":[{"n":"e","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794})));
                                            /*var*/ let maxFName = $.$sl.SL.Enumerable.MaxBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32, distinctContacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                const $t10 = () => c.FirstName;
                                                return $.$ifnn($t10, ($t) => $t.length) ?? 0;
                                            }, $ZUiQyf ??= {"r":655361,"p":[{"n":"c","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794}));
                                            /*var*/ let maxLName = $.$sl.SL.Enumerable.MaxBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32, distinctContacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                const $t11 = () => c.LastName;
                                                return $.$ifnn($t11, ($t) => $t.length) ?? 0;
                                            }, $GpcLmb ??= {"r":655361,"p":[{"n":"c","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794}));
                                            /*var*/ let maxOcc = $.$sl.SL.Enumerable.MaxBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32, distinctContacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                const $t12 = () => c.Occupation;
                                                return $.$ifnn($t12, ($t) => $t.length) ?? 0;
                                            }, $IbAVRa ??= {"r":655361,"p":[{"n":"c","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794}));
                                            /*var*/ let maxPhone = $.$sl.SL.Enumerable.MaxBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32, distinctContacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                const $t13 = () => c.PhoneNumber;
                                                return $.$ifnn($t13, ($t) => $t.length) ?? 0;
                                            }, $JebrLc ??= {"r":655361,"p":[{"n":"c","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794}));
                                            /*var*/ let maxEmail = $.$sl.SL.Enumerable.MaxBy$1($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32, distinctContacts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ContactModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                const $t14 = () => c.Email;
                                                return $.$ifnn($t14, ($t) => $t.length) ?? 0;
                                            }, $WQODGc ??= {"r":655361,"p":[{"n":"c","p":2762070}],"n":"","d":1415999,"h":0,"f":17825794}));
                                            /*int*/ let batch = 5000;
                                            /*int*/ let cnt = distinctContacts.Count;
                                            for(/*int*/ let i = 0; i < cnt; i += batch)
                                            {
                                                let $t15, $r15;
                                                ($t15 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.ContactModel), $.$Iaui.LCFCM.ContactModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.ContactModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.ContactModel)))().$ctor(this,  (/*server*/ server) =>
                                                {
                                                    return server.LCFCD$ICreateDataService$LivingThing$Core$Frameworks$Common$Models$ContactModel$Create($.$fPer.LCFCD.DataFilter.Default, $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.ContactModel, $.$sl.SL.Enumerable.Take($.$Iaui.LCFCM.ContactModel, $.$sl.SL.Enumerable.Skip($.$Iaui.LCFCM.ContactModel, distinctContacts, i), batch)));
                                                }, $QEMiOj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.ContactModel)).$h,"p":[{"n":"server","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.ContactModel).$h}],"n":"","d":1415999,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                                            }
                                        }
                                        finally
                                        {
                                            stream?.S$IDisposable$Dispose();
                                        }
                                    }
                                    finally
                                    {
                                        mem?.S$IDisposable$Dispose();
                                    }
                                }
                            }
                        });
                    }, $VjoCla ??= {"r":181338113,"n":"","d":1415999,"h":0,"f":17829890}), true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181285183)
            
            //--TRIMMABLE-BOUNDARY-START(55835990847)
            /*Task *//*async*/  SMSStatusCSVUploaded(/*IEnumerable<PickedFileInfo>*/ files)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835990847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t16 = this.table.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $en17 = files.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let file = $en17.SCG$IEnumerator$$$Current;
                                {
                                    let mem = null;
                                    try
                                    {
                                        mem = new $.$$.SI.MemoryStream().$ctor$3();
                                        let stream = null;
                                        try
                                        {
                                            let $t18, $r18;
                                            let $t19, $r19;
                                            let $t20, $r20;
                                            stream = ($t18 = file.ReadAsync(), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                                            ($t19 = stream.LCFCC$IFileStreamProvider$Stream.CopyToAsync$3(mem), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                                            mem.Position = 0n;
                                            /*StreamReader*/ let reader = new $.$$.SI.StreamReader().$ctor$9(mem);
                                            /*var*/ let csv = ($t20 = $.$fPer.LCFCD.CSVExtension.ParseCSVAsync(reader, true, true), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                                            /*int*/ let rows = $.$sl.SL.Enumerable.Count$1($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), csv.Data);
                                            /*int*/ let cols = $.$sl.SL.Enumerable.Count$1($.$$.S.String, csv.Header);
                                            /*int*/ let date_i = $.$$.S.Array.IndexOf$5($.$$.S.String, $.$sl.SL.Enumerable.ToArray($.$$.S.String, csv.Header), "Sent At");
                                            /*int*/ let contact_i = $.$$.S.Array.IndexOf$5($.$$.S.String, $.$sl.SL.Enumerable.ToArray($.$$.S.String, csv.Header), "Receiver");
                                            /*int*/ let status_i = $.$$.S.Array.IndexOf$5($.$$.S.String, $.$sl.SL.Enumerable.ToArray($.$$.S.String, csv.Header), "Status");
                                            /*int*/ let batch = 5000;
                                            /*int*/ let cnt = csv.Data.Count;
                                            /*var*/ let vals = $.$sl.SL.Enumerable.ToList($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$sl.SL.Enumerable.DistinctBy$1($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), csv.Data, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                                            {
                                                return d.Value.Count >= cols;
                                            }, $SSvRFg ??= {"r":262145,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)).$h}],"n":"","d":1415999,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$$.S.String))().$ctor(this,  (/*d*/ d) =>
                                            {
                                                return d.Value.get_Item(contact_i);
                                            }, $XefmNh ??= {"r":1310721,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)).$h}],"n":"","d":1415999,"h":0,"f":17825794})));
                                            for(/*int*/ let i = 0; i < cnt; i += batch)
                                            {
                                                let $t21, $r21;
                                                ($t21 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$vWqU.LCFCCR.ICoreRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                                                {
                                                    return server.LCFCCR$ICoreRemoteService$UpdateContactSMSStatus($.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$$.S.String, $.$Iaui.LCFCM.ContactSMSMetadataModel, $.$sl.SL.Enumerable.Take($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$sl.SL.Enumerable.Skip($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), vals, i), batch), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$$.S.String))().$ctor(this,  (/*d*/ d) =>
                                                    {
                                                        return d.Value.get_Item(contact_i);
                                                    }, $lxbYCj ??= {"r":1310721,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)).$h}],"n":"","d":1415999,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$Iaui.LCFCM.ContactSMSMetadataModel))().$ctor(this,  (/*d*/ d) =>
                                                    {
                                                        return (() =>
                                                        {
                                                            //new $.$Iaui.LCFCM.ContactSMSMetadataModel()
                                                            const $t22 = $.$Iaui.LCFCM.ContactSMSMetadataModel;
                                                            const $i22 = new $t22();
                                                            $i22.$ctor$1();
                                                            $i22.Date = $.$$.S.DateTime.Parse$4(d.Value.get_Item(date_i));
                                                            $i22.Status = d.Value.get_Item(status_i) === "Message Sent" ? 0/*ContactSMSStatus.Sent*/ : $.$$.S.Enum.Parse$7($.$Iaui.LCFCM.ContactSMSStatus, d.Value.get_Item(status_i));
                                                            return $i22;
                                                        })();
                                                    }, $wfOWMh ??= {"r":3024214,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)).$h}],"n":"","d":1415999,"h":0,"f":17825794})));
                                                }, $jTKkCh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":7429544}],"n":"","d":1415999,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                                            }
                                        }
                                        finally
                                        {
                                            stream?.S$IDisposable$Dispose();
                                        }
                                    }
                                    finally
                                    {
                                        mem?.S$IDisposable$Dispose();
                                    }
                                }
                            }
                        });
                    }, $Pibuje ??= {"r":181338113,"n":"","d":1415999,"h":0,"f":17829890}), true), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835990847)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591350591)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591350591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591350591)
            
            //--TRIMMABLE-BOUNDARY-START(8591350591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591350591)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21476252479)
                this.DashBoardTableProvider = null;
                //--TRIMMABLE-BOUNDARY-END(21476252479)
                
            }
            static $h = 1415999;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951088959),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656121663,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1415999,
      "h": 42951088959,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951088959),
//--TRIMMABLE-BOUNDARY-START(21476252479),
    {
      "p": 3578687,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066187071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541023551,
        "f": 83886081
      },
      "n": "DashBoardTableProvider",
      "d": 1415999,
      "h": 21476252479,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476252479)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425925439),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1415999,
      "h": 64425925439,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425925439),
//--TRIMMABLE-BOUNDARY-START(12886317887),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1415999,
      "h": 12886317887,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886317887),
//--TRIMMABLE-BOUNDARY-START(17181285183),
    {
      "r": 178454529,
      "p": [
        {
          "n": "files",
          "p": $.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo).$h
        }
      ],
      "n": "ContactCSVUploaded",
      "d": 1415999,
      "h": 17181285183,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17181285183),
//--TRIMMABLE-BOUNDARY-START(55835990847),
    {
      "r": 178454529,
      "p": [
        {
          "n": "files",
          "p": $.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo).$h
        }
      ],
      "n": "SMSStatusCSVUploaded",
      "d": 1415999,
      "h": 55835990847,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(55835990847)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130958143),
    {
      "t": $.$hDPm.LCFCCD.DashboardTable$$($.$Iaui.LCFCM.ContactModel).$h,
      "n": "table",
      "d": 1415999,
      "h": 60130958143,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130958143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591350591),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1415999,
      "h": 8591350591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591350591)
  ],
  "h": 1415999
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.Contacts`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}Contacts`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1415999)
        
        

        //--TRIMMABLE-BOUNDARY-START(2661183)
        $asm.$cls(`$WRsM.LCACSP.GlobalSettingsPage`, ($self) => class GlobalSettingsPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25772464959)
            /*ValueTask<T?> *//*async*/  GetCurrentSettings(T)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772464959);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let r = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$vWqU.LCFCCR.ICoreRemoteService, $.$$.S.String, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCCR$ICoreRemoteService$GetGlobalSettings(T.$type.FullName);
                    }, $YMmKXe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.String)).$h,"p":[{"n":"server","p":7429544}],"n":"","d":2661183,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3(T, r, false, "GetCurrentSettings", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\GlobalSettingsPage.razor.cs", "GetCurrentSettings", 27) ?? $.$$.S.Activator.CreateInstance$10(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25772464959)
            
            //--TRIMMABLE-BOUNDARY-START(34362399551)
            /*ValueTask *//*async*/  SaveSettings(T, /*T*/ t)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362399551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$vWqU.LCFCCR.ICoreRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ICoreRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCCR$ICoreRemoteService$SaveGlobalSettings(T.$type.FullName, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, t, true, false, true, false, false, false, false, "SaveSettings", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\GlobalSettingsPage.razor.cs", "SaveSettings", 32).Json);
                    }, $ZgLvbj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":7429544}],"n":"","d":2661183,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362399551)
            
            //--TRIMMABLE-BOUNDARY-START(38657366847)
            /*Task *//*async*/  Setting(/*Type*/ type)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657366847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let name = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(type.Name, "Settings", ""), "Component", ""), "Plugin", ""), "Global", "");
                    if ($.$$.S.String.IsNullOrEmpty(name))
                    {
                        name = type.Name;
                    }
                    ($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return $.$fPer.LCFCT.TypesExtensions.CallGenericMethod$1($.$mac.MAC.RenderFragment, this, "Form", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [type], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    }, $QKFVoh ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":2661183,"h":0,"f":17825794}), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, name, false), null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t4 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.ViewFeatures = 5632/*ViewFeatures.Default*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/;
                        $i4.ContentAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t5 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i5 = new $t5();
                            $i5.$ctor$1();
                            $i5.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-card pd");
                            return $i5;
                        })();
                        return $i4;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657366847)
            
            //--TRIMMABLE-BOUNDARY-START(30067432255)
            /*string */ get OptimizedComponentName()
            {
                return "globalsettingspage";
            }
            //--TRIMMABLE-BOUNDARY-END(30067432255)
            
            //--TRIMMABLE-BOUNDARY-START(8592595775)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592595775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "GlobalSettings");
                __builder.AddComponentParameter(2, "Class", "pd");
                __builder.AddComponentParameter(3, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("GlobalSettings"))));
                __builder.AddAttribute$3(4, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(5, "\r\n        GLOBAL SETTINGS\r\n    ");
                    }, $cbLbOd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794});
                }), $uiGYdh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":2661183,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(7, "<i class=\"mdi mdi-cogs\"></i>");
                    }, $RPBXdg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794});
                }), $IePqog ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":2661183,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(9, "div");
                        __builder2.AddAttribute$5(10, "class", "grid gap-2 colm-2");
                        let $en6 = $.$Iaui.LCFCMS.PluginGlobalSettings.Types.SCG$IEnumerable$$$GetEnumerator();
                        while ($en6.SC$1$IEnumerator$MoveNext())
                        {
                            let _type = $en6.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let type = _type;
                                /*var*/ let name = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(type.Name, "Settings", ""), "Component", ""), "Plugin", ""), "Global", "");
                                if ($.$$.S.String.IsNullOrEmpty(name))
                                {
                                    name = type.Name;
                                }
                                __builder2.OpenElement(11, "div");
                                __builder2.AddAttribute$5(12, "class", "pd bg-card bd corner stack");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Setting(type);
                                }, $dXcFWa ??= {"r":178454529,"n":"","d":2661183,"h":0,"f":17825794})));
                                __builder2.AddMarkupContent(14, "<i class=\"mgx-a fsz-60 mdi mdi-cog\"></i>\r\n                    ");
                                __builder2.OpenElement(15, "b");
                                __builder2.AddAttribute$5(16, "class", "mgx-a");
                                __builder2.AddContent$4(17, name);
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                    }, $jxlARk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794});
                }), $SLnlJi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":2661183,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8592595775)
            
            //--TRIMMABLE-BOUNDARY-START(12887563071)
            /*RenderFragment */ Form(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887563071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$(T), 18);
                    __builder2.AddComponentParameter(19, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$(T), $.$$.S.Func$$($.$$.STT.Task$$(T)), $.$$.STT.ValueTask$$(T), $.$$.S.Func$$($.$$.STT.ValueTask$$(T)), $.$fPer.LCFCR.ReactiveObservable$$(T)), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$(T), $.$$.S.Func$$($.$$.STT.Task$$(T)), $.$$.STT.ValueTask$$(T), $.$$.S.Func$$($.$$.STT.ValueTask$$(T)), $.$fPer.LCFCR.ReactiveObservable$$(T)).op_Implicit$4(new ($.$$.S.Func$$($.$$.STT.ValueTask$$(T)))().$ctor(this, (...args) => this.GetCurrentSettings(T,  ...args)))));
                    __builder2.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$(T)))().$ctor(this, ( (/*settings*/ settings) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), 21);
                            __builder3.AddComponentParameter(22, "Model", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(T, $.$hDPm.LCFCI.ContainerContext$$(T).op_Implicit(settings)), T));
                            __builder3.AddComponentParameter(23, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(T), $.$hDPm.LCFCC$1.ComponentExtension.Create$3(T, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$(T, $.$$.STT.ValueTask))().$ctor(this, (...args) => this.SaveSettings(T,  ...args)))));
                            __builder3.AddComponentParameter(24, "Class", "hf");
                            __builder3.AddComponentParameter(25, "MenuButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 128/*ButtonFeatures.XSmall*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddComponentParameter(26, "tabs-tabshead-class", "bdr bg-card hf");
                            __builder3.AddComponentParameter(27, "sidebar-bar-class", "bg-card bdt");
                            __builder3.AddComponentParameter(28, "sidebar-content-class", "pdr pdt pdb");
                            __builder3.AddAttribute$3(29, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 30);
                                __builder4.AddComponentParameter(31, "type", "submit");
                                __builder4.AddComponentParameter(32, "Class", "mg miwx-1");
                                __builder4.AddComponentParameter(33, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder4.AddAttribute$3(34, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(35, "Save");
                                }), $kHRrnj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }), $ghDzhb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $WHpihe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794});
                    }), $YSdwnl ??= {"r":6881395,"p":[{"n":"settings","p":(T) => $.$hDPm.LCFCI.ContainerContext$$(T).$h}],"n":"","d":2661183,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $UgUiGa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2661183,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12887563071)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4297628479)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297628479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297628479)
            
            //--TRIMMABLE-BOUNDARY-START(4297628479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297628479)
            
            static $h = 2661183;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067432255),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477497663,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2661183,
      "h": 30067432255,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30067432255)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772464959),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "g": [
        "T"
      ],
      "n": "GetCurrentSettings",
      "d": 2661183,
      "h": 25772464959,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(25772464959),
//--TRIMMABLE-BOUNDARY-START(34362399551),
    {
      "r": 181338113,
      "p": [
        {
          "n": "t",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SaveSettings",
      "d": 2661183,
      "h": 34362399551,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(34362399551),
//--TRIMMABLE-BOUNDARY-START(38657366847),
    {
      "r": 178454529,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "Setting",
      "d": 2661183,
      "h": 38657366847,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38657366847),
//--TRIMMABLE-BOUNDARY-START(8592595775),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2661183,
      "h": 8592595775,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592595775),
//--TRIMMABLE-BOUNDARY-START(12887563071),
    {
      "r": 6881395,
      "g": [
        "T"
      ],
      "n": "Form",
      "d": 2661183,
      "h": 12887563071,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(12887563071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297628479),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2661183,
      "h": 4297628479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297628479)
  ],
  "h": 2661183
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.PluginGlobalSettings.GlobalSettingsPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}PluginGlobalSettings${separator}GlobalSettingsPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2661183)
        
        

        //--TRIMMABLE-BOUNDARY-START(2857791)
        $asm.$cls(`$WRsM.LCACSSV.ServicesViewModel`, ($self) => class ServicesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887759679)
            $ctor$3(/*ApplicationViewModel*/ app)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887759679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.App = app;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887759679)
            
            //--TRIMMABLE-BOUNDARY-START(17182726975)
            /*ApplicationViewModel*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(17182726975)
            
            //--TRIMMABLE-BOUNDARY-START(55837432639)
            /*IEnumerable<ServiceViewModel>*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(55837432639)
            
            //--TRIMMABLE-BOUNDARY-START(42952530751)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952530751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        /*var*/ let services = (($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$ajwi.LCACS.IAdminRemoteService, $.$ajwi.LCACM.ServiceTaskModel, this.App.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ajwi.LCACS.IAdminRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$ajwi.LCACM.ServiceTaskModel)))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCACS$IAdminRemoteService$GetServiceTasks();
                        }, $CvOXgf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$ajwi.LCACM.ServiceTaskModel)).$h,"p":[{"n":"s","p":775289}],"n":"","d":2857791,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))).AsEnumerable();
                        this.Services = $.$sl.SL.Enumerable.ToArray($.$WRsM.LCACSSV.ServiceViewModel, $.$sl.SL.Enumerable.Select$1($.$ajwi.LCACM.ServiceTaskModel, $.$WRsM.LCACSSV.ServiceViewModel, services, new ($.$$.S.Func$$$($.$ajwi.LCACM.ServiceTaskModel, $.$WRsM.LCACSSV.ServiceViewModel))().$ctor(this,  (/*s*/ s) =>
                        {
                            return new $.$WRsM.LCACSSV.ServiceViewModel().$ctor$3(this.App.Server, s);
                        }, $Wrypnf ??= {"r":2923327,"p":[{"n":"s","p":382073}],"n":"","d":2857791,"h":0,"f":17825794})));
                    });
                }, $kPrxvh ??= {"r":181338113,"n":"","d":2857791,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42952530751)
            
            //--TRIMMABLE-BOUNDARY-START(38657563455)
            /*ServiceViewModel */ GetService(/*string*/ serviceId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657563455);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.SingleOrDefault$1($.$WRsM.LCACSSV.ServiceViewModel, this.Services, new ($.$$.S.Func$$$($.$WRsM.LCACSSV.ServiceViewModel, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                    {
                        return s.Model.ServiceId === serviceId;
                    }, $DpJCOa ??= {"r":262145,"p":[{"n":"s","p":2923327}],"n":"","d":2857791,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657563455)
            
            //--TRIMMABLE-BOUNDARY-START(68722334527)
            /*Task */ WriteServiceConsole(/*string*/ serviceId, /*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722334527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let service = this.GetService(serviceId);
                if (service !== null)
                {
                    service.Console.LCFCC$IConsole$Message(text);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(68722334527)
            
            //--TRIMMABLE-BOUNDARY-START(51542465343)
            /*Task */ ServiceExited(/*string*/ serviceId, /*int*/ exitCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542465343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let service = this.GetService(serviceId);
                if (service !== null)
                {
                    service.Model.IsRunning = false;
                    service.ExitCode = exitCode;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(51542465343)
            
            //--TRIMMABLE-BOUNDARY-START(47247498047)
            /*Task */ ServiceException(/*string*/ serviceId, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247498047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let service = this.GetService(serviceId);
                if (service !== null)
                {
                    service.Model.IsRunning = false;
                    service.Error = message;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47247498047)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55837432639)
                this.Services = new ($.$$.SCG.List$$($.$WRsM.LCACSSV.ServiceViewModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(55837432639)
                
            }
            static $h = 2857791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182726975),
    {
      "p": 3644223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772661567,
        "f": 50331650
      },
      "n": "App",
      "d": 2857791,
      "h": 17182726975,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17182726975),
//--TRIMMABLE-BOUNDARY-START(55837432639),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSSV.ServiceViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362596159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427367231,
        "f": 83886081
      },
      "n": "Services",
      "d": 2857791,
      "h": 55837432639,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837432639)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952530751),
    {
      "r": 181338113,
      "n": "Load",
      "d": 2857791,
      "h": 42952530751,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952530751),
//--TRIMMABLE-BOUNDARY-START(38657563455),
    {
      "r": 2923327,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        }
      ],
      "n": "GetService",
      "d": 2857791,
      "h": 38657563455,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38657563455),
//--TRIMMABLE-BOUNDARY-START(68722334527),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteServiceConsole",
      "d": 2857791,
      "h": 68722334527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722334527),
//--TRIMMABLE-BOUNDARY-START(51542465343),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "exitCode",
          "p": 655361
        }
      ],
      "n": "ServiceExited",
      "d": 2857791,
      "h": 51542465343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542465343),
//--TRIMMABLE-BOUNDARY-START(47247498047),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ServiceException",
      "d": 2857791,
      "h": 47247498047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47247498047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887759679),
    {
      "p": [
        {
          "n": "app",
          "p": 3644223
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2857791,
      "h": 12887759679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887759679)
  ],
  "h": 2857791
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.Services.ViewModel.ServicesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}Services${separator}ViewModel${separator}ServicesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2857791)
        
        

        //--TRIMMABLE-BOUNDARY-START(3316543)
        $asm.$cls(`$WRsM.LCACSSV$1.SystemStatesViewModel`, ($self) => class SystemStatesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(12888218431)
            $ctor$3(/*ApplicationViewModel*/ app)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888218431);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.App = app;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888218431)
            
            //--TRIMMABLE-BOUNDARY-START(64427825983)
            /*IEnumerable<SystemStateViewModel>*/ Statuses = null;
            //--TRIMMABLE-BOUNDARY-END(64427825983)
            
            //--TRIMMABLE-BOUNDARY-START(21478153023)
            /*ApplicationViewModel*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(21478153023)
            
            //--TRIMMABLE-BOUNDARY-START(42952989503)
            /*SystemStateViewModel */ GetStateViewModel(/*string*/ uuid)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952989503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let svm = $.$sl.SL.Enumerable.SingleOrDefault$1($.$WRsM.LCACSSV$1.SystemStateViewModel, this.Statuses, new ($.$$.S.Func$$$($.$WRsM.LCACSSV$1.SystemStateViewModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.UUID === uuid;
                }, $KfQomi ??= {"r":262145,"p":[{"n":"s","p":3382079}],"n":"","d":3316543,"h":0,"f":17825794}));
                if (svm === null)
                {
                    svm = new $.$WRsM.LCACSSV$1.SystemStateViewModel().$ctor$3(uuid, new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore))().$ctor$1());
                    this.Statuses = $.$sl.SL.Enumerable.ToList($.$WRsM.LCACSSV$1.SystemStateViewModel, $.$sl.SL.Enumerable.Concat($.$WRsM.LCACSSV$1.SystemStateViewModel, this.Statuses, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSSV$1.SystemStateViewModel), [svm], null, null)));
                }
                return svm;
            }
            //--TRIMMABLE-BOUNDARY-END(42952989503)
            
            //--TRIMMABLE-BOUNDARY-START(17183185727)
            /*Task */ AddStatusStore(/*string*/ uuid, /*string*/ name, /*StatusStore*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183185727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let svm = this.GetStateViewModel(uuid);
                return svm.AddStatusStore(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17183185727)
            
            //--TRIMMABLE-BOUNDARY-START(51542924095)
            /*Task */ RemoveStatusStore(/*string*/ uuid, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542924095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let svm = this.GetStateViewModel(uuid);
                return svm.RemoveStatusStore(name);
            }
            //--TRIMMABLE-BOUNDARY-END(51542924095)
            
            //--TRIMMABLE-BOUNDARY-START(47247956799)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247956799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        /*var*/ let statuses = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$ajwi.LCACS.IAdminRemoteService, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)), this.App.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ajwi.LCACS.IAdminRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)))))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCACS$IAdminRemoteService$GetAppStatuses();
                        }, $bsNxfa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)))).$h,"p":[{"n":"s","p":775289}],"n":"","d":3316543,"h":0,"f":17825794}), null, (() =>
                        {
                            //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                            const $t2 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                            const $i2 = new $t2();
                            $i2.$ctor$1();
                            $i2.CloneResponse = false;
                            return $i2;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        this.Statuses = $.$sl.SL.Enumerable.ToList($.$WRsM.LCACSSV$1.SystemStateViewModel, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)), $.$WRsM.LCACSSV$1.SystemStateViewModel, statuses, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)), $.$WRsM.LCACSSV$1.SystemStateViewModel))().$ctor(this,  (/*s*/ s) =>
                        {
                            return new $.$WRsM.LCACSSV$1.SystemStateViewModel().$ctor$3(s.Key, s.Value);
                        }, $OuwHwj ??= {"r":3382079,"p":[{"n":"s","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)).$h}],"n":"","d":3316543,"h":0,"f":17825794})));
                    });
                }, $hlROna ??= {"r":181338113,"n":"","d":3316543,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(47247956799)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64427825983)
                this.Statuses = new ($.$$.SCG.List$$($.$WRsM.LCACSSV$1.SystemStateViewModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64427825983)
                
            }
            static $h = 3316543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64427825983),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSSV$1.SystemStateViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658022207,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132858687,
        "f": 83886081
      },
      "n": "Statuses",
      "d": 3316543,
      "h": 64427825983,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427825983),
//--TRIMMABLE-BOUNDARY-START(21478153023),
    {
      "p": 3644223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068087615,
        "f": 50331650
      },
      "n": "App",
      "d": 3316543,
      "h": 21478153023,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21478153023)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952989503),
    {
      "r": 3382079,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        }
      ],
      "n": "GetStateViewModel",
      "d": 3316543,
      "h": 42952989503,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42952989503),
//--TRIMMABLE-BOUNDARY-START(17183185727),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1037433
        }
      ],
      "n": "AddStatusStore",
      "d": 3316543,
      "h": 17183185727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183185727),
//--TRIMMABLE-BOUNDARY-START(51542924095),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "RemoveStatusStore",
      "d": 3316543,
      "h": 51542924095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542924095),
//--TRIMMABLE-BOUNDARY-START(47247956799),
    {
      "r": 181338113,
      "n": "Load",
      "d": 3316543,
      "h": 47247956799,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247956799)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888218431),
    {
      "p": [
        {
          "n": "app",
          "p": 3644223
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3316543,
      "h": 12888218431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888218431)
  ],
  "h": 3316543
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.ViewModels.SystemStatesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}ViewModels${separator}SystemStatesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3316543)
        
        

        //--TRIMMABLE-BOUNDARY-START(2464575)
        $asm.$cls(`$WRsM.LCACSDV.TableRowViewModel`, ($self) => class TableRowViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(17182333759)
            $ctor$3(/*TableViewModel*/ table, /*TableRowModel*/ data, /*int*/ depth)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182333759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Table = $.$firstOf(table, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("table") });
                    this.Data = $.$firstOf(data, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("data") });
                    this.Depth = depth;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182333759)
            
            //--TRIMMABLE-BOUNDARY-START(30067235647)
            /*int*/ Depth = 0;
            //--TRIMMABLE-BOUNDARY-END(30067235647)
            
            //--TRIMMABLE-BOUNDARY-START(90196777791)
            /*TableViewModel*/ Table = null;
            //--TRIMMABLE-BOUNDARY-END(90196777791)
            
            //--TRIMMABLE-BOUNDARY-START(25772268351)
            /*TableRowModel*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(25772268351)
            
            //--TRIMMABLE-BOUNDARY-START(77311875903)
            /*IObservableDataDescriptor */ GetValue(/*Common.Models.TablePropertyColumn*/ column)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311875903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.Data, column.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(77311875903)
            
            //--TRIMMABLE-BOUNDARY-START(34362202943)
            /*IDictionary<string, IObservableDataDescriptor> */ get DetailedRows()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132006719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToDictionary$5($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.Table.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String))().$ctor(this,  (/**/ kv) =>
                {
                    return kv.Name;
                }, $OQTHpc ??= {"r":1310721,"p":[{"n":"kv","p":578681}],"n":"","d":2464575,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.Data, kv.Name);
                }, $meKxZb ??= {"r":40536406,"p":[{"n":"kv","p":578681}],"n":"","d":2464575,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34362202943)
            
            //--TRIMMABLE-BOUNDARY-START(21477301055)
            /*IDictionary<Common.Models.TablePropertyColumn, TableRowColumnViewModel>*/ columns = null;
            //--TRIMMABLE-BOUNDARY-END(21477301055)
            
            //--TRIMMABLE-BOUNDARY-START(73016908607)
            /*TableRowColumnViewModel */ GetColumn(/*Common.Models.TablePropertyColumn*/ col)
            {
                /*var*/ let vm;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016908607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.columns.SCG$IDictionary$$$$TryGetValue(col, $.$ref(() => vm, ($v) => vm = $v, $.$WRsM.LCACSDV.TableRowColumnViewModel)))
                {
                    return vm;
                }
                vm = new $.$WRsM.LCACSDV.TableRowColumnViewModel().$ctor$3(this.Table, this, col, ((this.Depth + 1) | 0));
                this.columns.SCG$IDictionary$$$$set_Item(col, vm);
                return vm;
            }
            //--TRIMMABLE-BOUNDARY-END(73016908607)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477301055)
                this.columns = new ($.$$.SCG.Dictionary$$$($.$ajwi.LCACM.TablePropertyColumn, $.$WRsM.LCACSDV.TableRowColumnViewModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21477301055)
                
            }
            static $h = 2464575;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067235647),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542072127,
        "f": 50331649
      },
      "n": "Depth",
      "d": 2464575,
      "h": 30067235647,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067235647),
//--TRIMMABLE-BOUNDARY-START(90196777791),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721941311,
        "f": 50331649
      },
      "n": "Table",
      "d": 2464575,
      "h": 90196777791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196777791),
//--TRIMMABLE-BOUNDARY-START(25772268351),
    {
      "p": 2071359,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952137535,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901810495,
        "f": 83886081
      },
      "n": "Data",
      "d": 2464575,
      "h": 25772268351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772268351),
//--TRIMMABLE-BOUNDARY-START(34362202943),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132006719,
        "f": 50331649
      },
      "n": "DetailedRows",
      "d": 2464575,
      "h": 34362202943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362202943)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311875903),
    {
      "r": 40536406,
      "p": [
        {
          "n": "column",
          "p": 578681
        }
      ],
      "n": "GetValue",
      "d": 2464575,
      "h": 77311875903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311875903),
//--TRIMMABLE-BOUNDARY-START(73016908607),
    {
      "r": 2005823,
      "p": [
        {
          "n": "col",
          "p": 578681
        }
      ],
      "n": "GetColumn",
      "d": 2464575,
      "h": 73016908607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016908607)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477301055),
    {
      "t": $.$$.SCG.IDictionary$$$($.$ajwi.LCACM.TablePropertyColumn, $.$WRsM.LCACSDV.TableRowColumnViewModel).$h,
      "n": "columns",
      "d": 2464575,
      "h": 21477301055,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477301055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182333759),
    {
      "p": [
        {
          "n": "table",
          "p": 2530111
        },
        {
          "n": "data",
          "p": 2071359
        },
        {
          "n": "depth",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2464575,
      "h": 17182333759,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182333759)
  ],
  "h": 2464575
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2464575)
        
        

        //--TRIMMABLE-BOUNDARY-START(2923327)
        $asm.$cls(`$WRsM.LCACSSV.ServiceViewModel`, ($self) => class ServiceViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(21477759807)
            $ctor$3(/*IServerRemoteService*/ server, /*ServiceTaskModel*/ model)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477759807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Model = model;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477759807)
            
            //--TRIMMABLE-BOUNDARY-START(25772727103)
            /*IConsole*/ Console = null;
            //--TRIMMABLE-BOUNDARY-END(25772727103)
            
            //--TRIMMABLE-BOUNDARY-START(81607301951)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(81607301951)
            
            //--TRIMMABLE-BOUNDARY-START(34362661695)
            /*int?*/ ExitCode = null;
            //--TRIMMABLE-BOUNDARY-END(34362661695)
            
            //--TRIMMABLE-BOUNDARY-START(30067694399)
            /*string?*/ Error = null;
            //--TRIMMABLE-BOUNDARY-END(30067694399)
            
            //--TRIMMABLE-BOUNDARY-START(73017367359)
            /*ServiceTaskModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(73017367359)
            
            //--TRIMMABLE-BOUNDARY-START(77312334655)
            /*ValueTask *//*async*/  Run(/*ServiceParameterModel[]*/ $arguments)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77312334655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        this.Model.IsRunning = true;
                        this.ExitCode = null;
                        this.Error = null;
                        this.Console?.LCFCC$IConsole$Clear();
                        ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$ajwi.LCACS.IAdminRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ajwi.LCACS.IAdminRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCACS$IAdminRemoteService$StartServiceTask(this.Model.ServiceId, $arguments);
                        }, $JnzIej ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":775289}],"n":"","d":2923327,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch(e)
                    {
                        this.Model.IsRunning = false;
                        this.Error = e.Message;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77312334655)
            
            //--TRIMMABLE-BOUNDARY-START(111672073023)
            /*ValueTask *//*async*/  Stop()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672073023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model.IsRunning = false;
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$ajwi.LCACS.IAdminRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$ajwi.LCACS.IAdminRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCACS$IAdminRemoteService$StopServiceTask(this.Model.ServiceId);
                    }, $modGri ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":775289}],"n":"","d":2923327,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111672073023)
            
            static $h = 2923327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772727103),
    {
      "p": 2842024,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952596287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197236543,
        "f": 83886081
      },
      "n": "Console",
      "d": 2923327,
      "h": 25772727103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772727103),
//--TRIMMABLE-BOUNDARY-START(34362661695),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132465471,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107377105727,
        "f": 83886081
      },
      "n": "ExitCode",
      "d": 2923327,
      "h": 34362661695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362661695),
//--TRIMMABLE-BOUNDARY-START(30067694399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542530879,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787171135,
        "f": 83886081
      },
      "n": "Error",
      "d": 2923327,
      "h": 30067694399,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067694399),
//--TRIMMABLE-BOUNDARY-START(73017367359),
    {
      "p": 382073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722400063,
        "f": 50331649
      },
      "n": "Model",
      "d": 2923327,
      "h": 73017367359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017367359)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77312334655),
    {
      "r": 181338113,
      "p": [
        {
          "n": "arguments",
          "p": $.$typeArray($.$ajwi.LCACM.ServiceParameterModel).$h
        }
      ],
      "n": "Run",
      "d": 2923327,
      "h": 77312334655,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77312334655),
//--TRIMMABLE-BOUNDARY-START(111672073023),
    {
      "r": 181338113,
      "n": "Stop",
      "d": 2923327,
      "h": 111672073023,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(111672073023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81607301951),
    {
      "t": 1309651,
      "n": "Server",
      "d": 2923327,
      "h": 81607301951,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81607301951)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477759807),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "model",
          "p": 382073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2923327,
      "h": 21477759807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477759807)
  ],
  "h": 2923327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.Services.ViewModel.ServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}Services${separator}ViewModel${separator}ServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2923327)
        
        

        //--TRIMMABLE-BOUNDARY-START(2005823)
        $asm.$cls(`$WRsM.LCACSDV.TableRowColumnViewModel`, ($self) => class TableRowColumnViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(244815141695)
            /*TableViewModel*/ Table = null;
            //--TRIMMABLE-BOUNDARY-END(244815141695)
            
            //--TRIMMABLE-BOUNDARY-START(206160436031)
            /*TableRowViewModel*/ Row = null;
            //--TRIMMABLE-BOUNDARY-END(206160436031)
            
            //--TRIMMABLE-BOUNDARY-START(73016449855)
            /*Common.Models.TablePropertyColumn*/ Column = null;
            //--TRIMMABLE-BOUNDARY-END(73016449855)
            
            //--TRIMMABLE-BOUNDARY-START(30066776895)
            $ctor$3(/*TableViewModel*/ table, /*TableRowViewModel*/ row, /*Common.Models.TablePropertyColumn*/ column, /*int*/ depth)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066776895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Table = $.$firstOf(table, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("table") });
                    this.Row = $.$firstOf(row, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("row") });
                    this.Column = $.$firstOf(column, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("column") });
                    this.Depth = depth;
                    this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066776895)
            
            //--TRIMMABLE-BOUNDARY-START(257700043583)
            /*IObservableDataDescriptor */ get Value()
            {
                return this.Row.GetValue(this.Column);
            }
            //--TRIMMABLE-BOUNDARY-END(257700043583)
            
            //--TRIMMABLE-BOUNDARY-START(81606384447)
            /*int*/ Depth = 0;
            //--TRIMMABLE-BOUNDARY-END(81606384447)
            
            //--TRIMMABLE-BOUNDARY-START(64426515263)
            /*bool*/ collapsed = true;
            //--TRIMMABLE-BOUNDARY-END(64426515263)
            
            //--TRIMMABLE-BOUNDARY-START(68721482559)
            /*bool */ get Collapsed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966122815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.collapsed;
            }
            /*bool */ set Collapsed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635272511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.collapsed && !value && $.$$.System.Array.$ReadT1.call(this.Column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 21/*DataType.Class*/ && this.ClassData === null)
                {
                    this.LoadClass();
                }
                this.collapsed = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68721482559)
            
            //--TRIMMABLE-BOUNDARY-START(249110108991)
            /*TableRowType? */ get TableType()
            {
                return (this.Table.DataTable.get_Item$1(this.Column.ColumnType.ElementType)?.TableRowType ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(249110108991)
            
            //--TRIMMABLE-BOUNDARY-START(210455403327)
            /*TableViewModel? */ get RowViewModel()
            {
                return this.Table.DataTable.get_Item$1(this.Column.ColumnType.ElementType);
            }
            //--TRIMMABLE-BOUNDARY-END(210455403327)
            
            //--TRIMMABLE-BOUNDARY-START(240520174399)
            /*TableViewModel?*/ table = null;
            //--TRIMMABLE-BOUNDARY-END(240520174399)
            
            //--TRIMMABLE-BOUNDARY-START(77311417151)
            /*TableViewModel? */ get DataTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145991999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TableType !== null && (this.table === null || this.table.ParentColumn.Row.Data !== this.Row.Data))
                {
                    this.table = new $.$WRsM.LCACSDV.TableViewModel().$ctor$3(this.Table.DataTable.App, this.Table.DataTable, this.TableType, ((this.Depth + 1) | 0), this);
                }
                return this.table;
            }
            //--TRIMMABLE-BOUNDARY-END(77311417151)
            
            //--TRIMMABLE-BOUNDARY-START(60131547967)
            /*TableViewModel? */ get ClassTable()
            {
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$WRsM.LCACSDV.TableViewModel, this.Table.DataTable.Tables, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$$.S.String.Equals$5.call($.$$.System.Array.$ReadT1.call(t.TableRowType.Aliases, 0), $.$$.System.Array.$ReadT1.call(this.Column.ColumnType.Aliases, 0));
                }, $DUnWui ??= {"r":262145,"p":[{"n":"t","p":2530111}],"n":"","d":2005823,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(60131547967)
            
            //--TRIMMABLE-BOUNDARY-START(51541613375)
            /*TableRowViewModel?*/ classRow = null;
            //--TRIMMABLE-BOUNDARY-END(51541613375)
            
            //--TRIMMABLE-BOUNDARY-START(55836580671)
            /*TableRowViewModel? */ get ClassRow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786253631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ClassTable !== null && this.ClassData !== null)
                {
                    if (this.classRow === null || this.classRow.Data !== this.ClassData)
                    {
                        this.classRow = new $.$WRsM.LCACSDV.TableRowViewModel().$ctor$3(this.ClassTable, this.ClassData, ((this.Depth + 1) | 0));
                    }
                }
                return this.classRow;
            }
            //--TRIMMABLE-BOUNDARY-END(55836580671)
            
            //--TRIMMABLE-BOUNDARY-START(253405076287)
            /*void */ ToggleCollapsed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405076287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Collapsed = !this.Collapsed;
            }
            //--TRIMMABLE-BOUNDARY-END(253405076287)
            
            //--TRIMMABLE-BOUNDARY-START(34361744191)
            /*void */ ClassCopy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361744191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ClassData !== null)
                {
                    /*var*/ let clipBoard = this.Table.DataTable.ClipBoards.get_Item(this.TableType);
                    if (!clipBoard.Contains(this.ClassData))
                    {
                        clipBoard.Add(this.ClassData);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361744191)
            
            //--TRIMMABLE-BOUNDARY-START(47246646079)
            /*void */ ClassPaste()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246646079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let clipBoard = this.Table.DataTable.ClipBoards.get_Item(this.TableType);
                /*var*/ let lastClipBoardItem = $.$sl.SL.Enumerable.LastOrDefault$3($.$WRsM.LCACSDV.TableRowModel, clipBoard);
                if (lastClipBoardItem !== null)
                {
                    /*var*/ let id = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, lastClipBoardItem, "Id");
                    /*var*/ let currentId = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.Row.Data, $.$strNN(this.Column.Name) + "Id");
                    currentId.LCFCD$IValueProvider$Value = id.LCFCD$IValueProvider$Value;
                    this.Table.Update(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableRowModel), [ this.Row.Data ], null, null));
                    this.ClassData = lastClipBoardItem;
                    this.classRow = null;
                    this.NullClass = false;
                    this.RaisePropertyChanged$1("ClassPaste");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246646079)
            
            //--TRIMMABLE-BOUNDARY-START(42951678783)
            /*void */ ClassDetach()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951678783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let currentId = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.Row.Data, $.$strNN(this.Column.Name) + "Id");
                currentId.LCFCD$IValueProvider$Value = null;
                this.Table.Update(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableRowModel), [ this.Row.Data ], null, null));
                this.ClassData = null;
                this.classRow = null;
                this.NullClass = true;
                this.RaisePropertyChanged$1("ClassDetach");
            }
            //--TRIMMABLE-BOUNDARY-END(42951678783)
            
            //--TRIMMABLE-BOUNDARY-START(38656711487)
            /*TableRowModel?*/ ClassData = null;
            //--TRIMMABLE-BOUNDARY-END(38656711487)
            
            //--TRIMMABLE-BOUNDARY-START(201865468735)
            /*bool*/ NullClass = false;
            //--TRIMMABLE-BOUNDARY-END(201865468735)
            
            //--TRIMMABLE-BOUNDARY-START(197570501439)
            /*void *//*async*/  LoadClass()
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197570501439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let id = ($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.Row.Data, $.$strNN(this.Column.Name) + "Id")?.LCFCD$IValueProvider$Value ?? null);
                    if (id !== null)
                    {
                        this.NullClass = false;
                        let adminService = null;
                        try
                        {
                            let $t1, $r1;
                            adminService = this.Table.DataTable.App.Server.LCFCR$IServerRemoteService$GetRemoteService($.$ajwi.LCACS.IAdminRemoteService, null);
                            this.Loading = $.$vWqU.LCFCC.LoadState.Loading;
                            /*var*/ let response = ($t1 = adminService.LCFCS$3$IServiceProxy$$$Service.LCACS$IAdminRemoteService$ReadSingle(this.Table.DataTable.ProviderName, (() =>
                            {
                                //new $.$Iaui.LCFCM.ReadRequestModel()
                                const $t2 = $.$Iaui.LCFCM.ReadRequestModel;
                                const $i2 = new $t2();
                                $i2.$ctor$2();
                                $i2.ModelType = 1/*ModelType.Row*/;
                                $i2.Target = new $.$fPer.LCFCD.DataId().$ctor$3(id, $.$$.System.Array.$ReadT1.call(this.Column.ColumnType.Aliases, 0));
                                return $i2;
                            })()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            if (this.ClassData === null)
                            {
                                this.ClassData = new $.$WRsM.LCACSDV.TableRowModel().$ctor$10();
                            }
                            this.ClassData.Clear();
                            /*var*/ let dic = $.$sl.SL.Enumerable.ToDictionary$5($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.RowViewModel.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.Name;
                            }, $NLgthi ??= {"r":1310721,"p":[{"n":"c","p":578681}],"n":"","d":2005823,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*column*/ column) =>
                            {
                                return $.$fPer.LCFCD.DataDescriptorFactory.FromObject($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$$.S.Object, response.Data, column.Name), column.ValueType, null, column.Name, null, false);
                            }, $flUbGb ??= {"r":40536406,"p":[{"n":"column","p":578681}],"n":"","d":2005823,"h":0,"f":17825794}));
                            let $en3 = dic.GetEnumerator();
                            while ($en3.MoveNext())
                            {
                                let d = $en3.Current;
                                {
                                    this.ClassData.Add(d.Key, d.Value);
                                }
                            }
                            let $en4 = this.RowViewModel.PrimitiveColumns.SCG$IEnumerable$$$GetEnumerator();
                            while ($en4.SC$1$IEnumerator$MoveNext())
                            {
                                let column = $en4.SCG$IEnumerator$$$Current;
                                {
                                    if (!this.ClassData.ContainsKey(column.Name))
                                    {
                                        $.$fPer.LCFCP$1.PropertyExtension.SetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.ClassData, column.Name, $.$fPer.LCFCD.DataDescriptorFactory.FromObject(null, column.ValueType, null, column.Name, null, false));
                                    }
                                }
                            }
                            this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                            this.RaisePropertyChanged$1("LoadClass");
                        }
                        finally
                        {
                            adminService?.S$IDisposable$Dispose();
                        }
                    }
                    else 
                    {
                        this.NullClass = true;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197570501439)
            
            static $h = 2005823;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(244815141695),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095664959,
        "f": 50331649
      },
      "n": "Table",
      "d": 2005823,
      "h": 244815141695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244815141695),
//--TRIMMABLE-BOUNDARY-START(206160436031),
    {
      "p": 2464575,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915795775,
        "f": 50331649
      },
      "n": "Row",
      "d": 2005823,
      "h": 206160436031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206160436031),
//--TRIMMABLE-BOUNDARY-START(73016449855),
    {
      "p": 578681,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556057407,
        "f": 50331649
      },
      "n": "Column",
      "d": 2005823,
      "h": 73016449855,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016449855),
//--TRIMMABLE-BOUNDARY-START(257700043583),
    {
      "p": 40536406,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275534143,
        "f": 50331649
      },
      "n": "Value",
      "d": 2005823,
      "h": 257700043583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257700043583),
//--TRIMMABLE-BOUNDARY-START(81606384447),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735926591,
        "f": 50331649
      },
      "n": "Depth",
      "d": 2005823,
      "h": 81606384447,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606384447),
//--TRIMMABLE-BOUNDARY-START(68721482559),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966122815,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227635272511,
        "f": 83886081
      },
      "n": "Collapsed",
      "d": 2005823,
      "h": 68721482559,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721482559),
//--TRIMMABLE-BOUNDARY-START(249110108991),
    {
      "p": 644217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685599551,
        "f": 50331650
      },
      "n": "TableType",
      "d": 2005823,
      "h": 249110108991,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(249110108991),
//--TRIMMABLE-BOUNDARY-START(210455403327),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505730367,
        "f": 50331650
      },
      "n": "RowViewModel",
      "d": 2005823,
      "h": 210455403327,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210455403327),
//--TRIMMABLE-BOUNDARY-START(77311417151),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145991999,
        "f": 50331649
      },
      "n": "DataTable",
      "d": 2005823,
      "h": 77311417151,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311417151),
//--TRIMMABLE-BOUNDARY-START(60131547967),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376188223,
        "f": 50331650
      },
      "n": "ClassTable",
      "d": 2005823,
      "h": 60131547967,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60131547967),
//--TRIMMABLE-BOUNDARY-START(55836580671),
    {
      "p": 2464575,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786253631,
        "f": 50331649
      },
      "n": "ClassRow",
      "d": 2005823,
      "h": 55836580671,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836580671),
//--TRIMMABLE-BOUNDARY-START(38656711487),
    {
      "p": 2071359,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196319039,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219045337919,
        "f": 83886082
      },
      "n": "ClassData",
      "d": 2005823,
      "h": 38656711487,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38656711487),
//--TRIMMABLE-BOUNDARY-START(201865468735),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325861183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236225207103,
        "f": 83886082
      },
      "n": "NullClass",
      "d": 2005823,
      "h": 201865468735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865468735)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(253405076287),
    {
      "r": 65537,
      "n": "ToggleCollapsed",
      "d": 2005823,
      "h": 253405076287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253405076287),
//--TRIMMABLE-BOUNDARY-START(34361744191),
    {
      "r": 65537,
      "n": "ClassCopy",
      "d": 2005823,
      "h": 34361744191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361744191),
//--TRIMMABLE-BOUNDARY-START(47246646079),
    {
      "r": 65537,
      "n": "ClassPaste",
      "d": 2005823,
      "h": 47246646079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246646079),
//--TRIMMABLE-BOUNDARY-START(42951678783),
    {
      "r": 65537,
      "n": "ClassDetach",
      "d": 2005823,
      "h": 42951678783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951678783),
//--TRIMMABLE-BOUNDARY-START(197570501439),
    {
      "r": 65537,
      "n": "LoadClass",
      "d": 2005823,
      "h": 197570501439,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(197570501439)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426515263),
    {
      "t": 262145,
      "n": "collapsed",
      "d": 2005823,
      "h": 64426515263,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426515263),
//--TRIMMABLE-BOUNDARY-START(240520174399),
    {
      "t": 2530111,
      "n": "table",
      "d": 2005823,
      "h": 240520174399,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(240520174399),
//--TRIMMABLE-BOUNDARY-START(51541613375),
    {
      "t": 2464575,
      "n": "classRow",
      "d": 2005823,
      "h": 51541613375,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541613375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066776895),
    {
      "p": [
        {
          "n": "table",
          "p": 2530111
        },
        {
          "n": "row",
          "p": 2464575
        },
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "depth",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2005823,
      "h": 30066776895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066776895)
  ],
  "h": 2005823
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowColumnViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowColumnViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2005823)
        
        

        //--TRIMMABLE-BOUNDARY-START(1940287)
        $asm.$cls(`$WRsM.LCACSDV.DataTablesViewModel`, ($self) => class DataTablesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(25771744063)
            $ctor$3(/*ApplicationViewModel*/ app, /*string*/ providerName, /*TableDefinition*/ tableDefinition)
            {
                super.$ctor$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$vWqU.LCFCC.IViewModel), [ app ], null, null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771744063);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.App = $.$firstOf(app, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("app") });
                    this.ProviderName = $.$firstOf(providerName, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("providerName") });
                    this.TableDefinition = $.$firstOf(tableDefinition, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("tableDefinition") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771744063)
            
            //--TRIMMABLE-BOUNDARY-START(38656645951)
            /*int*/ Depth = 0;
            //--TRIMMABLE-BOUNDARY-END(38656645951)
            
            //--TRIMMABLE-BOUNDARY-START(115966057279)
            /*string*/ ProviderName = null;
            //--TRIMMABLE-BOUNDARY-END(115966057279)
            
            //--TRIMMABLE-BOUNDARY-START(128850959167)
            /*TableDefinition*/ TableDefinition = null;
            //--TRIMMABLE-BOUNDARY-END(128850959167)
            
            //--TRIMMABLE-BOUNDARY-START(141735861055)
            /*TableViewModel?*/ get_Item$1(/*string*/ typeName)
            {
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$WRsM.LCACSDV.TableViewModel, this.Tables, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$$.System.Array.$ReadT1.call(t.TableRowType.Aliases, 0) === typeName;
                }, $ugHgGf ??= {"r":262145,"p":[{"n":"t","p":2530111}],"n":"","d":1940287,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(141735861055)
            
            //--TRIMMABLE-BOUNDARY-START(30066711359)
            /*ApplicationViewModel*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(30066711359)
            
            //--TRIMMABLE-BOUNDARY-START(146030828351)
            /*ValueTask *//*async*/  Update(/*TableViewModel?*/ specifiiedTable)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030828351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let model = (() =>
                    {
                        //new $.$Iaui.LCFCM.CRUDRequestModel()
                        const $t1 = $.$Iaui.LCFCM.CRUDRequestModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Creates = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.CreateRequestModel), [], [-1], null);
                        $i1.Updates = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.UpdateRequestModel), [], [-1], null);
                        $i1.Deletes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DeleteRequestModel), [], [-1], null);
                        $i1.Removes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.RemovePropertyRequestModel), [], [-1], null);
                        $i1.ModelType = 1/*ModelType.Row*/;
                        return $i1;
                    })();
                    if (specifiiedTable === null)
                    {
                        $.$fPer.LCFC.ForEachExtension.ForEach$1($.$WRsM.LCACSDV.TableViewModel, this.Tables, new ($.$$.S.Action$$($.$WRsM.LCACSDV.TableViewModel))().$ctor(this,  (/*table*/ table) =>
                        {
                            table.GetUpdates(model);
                        }, $vEUkob ??= {"r":65537,"p":[{"n":"table","p":2530111}],"n":"","d":1940287,"h":0,"f":17825794}));
                    }
                    else 
                    {
                        specifiiedTable.GetUpdates(model);
                    }
                    let service = null;
                    try
                    {
                        service = this.App.Server.LCFCR$IServerRemoteService$GetRemoteService($.$ajwi.LCACS.IAdminRemoteService, null);
                        if (specifiiedTable !== null)
                        {
                            let $t2, $r2;
                            ($t2 = specifiiedTable.Load$2($.$fPer.LCFCD.WireTransportManyModel, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel)))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel), $.$fPer.LCFCD.WireTransportManyModel, async ($asnycContext) => 
                                {
                                    let $t3, $r3;
                                    return ($t3 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAdminRemoteService$CRUD(this.ProviderName, model), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                });
                            }, $vQibmh ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel).$h,"n":"","d":1940287,"h":0,"f":17829890}), false, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                        else 
                        {
                            let $t4, $r4;
                            ($t4 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAdminRemoteService$CRUD(this.ProviderName, model), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                        if (specifiiedTable === null)
                        {
                            let $i5 = 0;
                            let $arr5 = this.Tables;
                            while ($i5 < $arr5.length)
                            {
                                let $t6, $r6;
                                let _table = $arr5[$i5++];
                                ($t6 = _table.NotifyUpdated(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            }
                        }
                        else 
                        {
                            let $t7, $r7;
                            ($t7 = specifiiedTable.NotifyUpdated(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        }
                    }
                    finally
                    {
                        service?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146030828351)
            
            //--TRIMMABLE-BOUNDARY-START(133145926463)
            /*TableViewModel[]?*/ tables = null;
            //--TRIMMABLE-BOUNDARY-END(133145926463)
            
            //--TRIMMABLE-BOUNDARY-START(137440893759)
            /*TableViewModel[] */ get Tables()
            {
                return this.tables ??= $.$sl.SL.Enumerable.ToArray($.$WRsM.LCACSDV.TableViewModel, $.$sl.SL.Enumerable.Select$1($.$ajwi.LCACM.TableRowType, $.$WRsM.LCACSDV.TableViewModel, this.TableDefinition.Tables, new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$WRsM.LCACSDV.TableViewModel))().$ctor(this,  (/*t*/ t) =>
                {
                    /*var*/ let vm = new $.$WRsM.LCACSDV.TableViewModel().$ctor$3(this.App, this, t, 0, null);
                    this.ClipBoards.set_Item(t, new ($.$$.SCG.List$$($.$WRsM.LCACSDV.TableRowModel))().$ctor$1());
                    return vm;
                }, $Axjmsa ??= {"r":2530111,"p":[{"n":"t","p":644217}],"n":"","d":1940287,"h":0,"f":17825794}))) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableViewModel), null, [0], null);
            }
            //--TRIMMABLE-BOUNDARY-END(137440893759)
            
            //--TRIMMABLE-BOUNDARY-START(111671089983)
            /*IEnumerable<IGrouping<string, TableViewModel>> */ get Groupings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016384319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.GroupBy$7($.$WRsM.LCACSDV.TableViewModel, $.$$.S.String, this.Tables, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.S.String))().$ctor(this,  (/**/ t) =>
                {
                    /*var*/ let name = t.TableRowType.AssemblyGroup;
                    if (name === null)
                    {
                        return "";
                    }
                    /*var*/ let names = $.$$.S.String.Split$5.call(name, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*.*/ 46], [-1], null));
                    /*var*/ let namespace = $.$$.S.String.Join$10(".", $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Take($.$$.S.String, names, ((names.length - 1) | 0))));
                    return namespace;
                }, $gHZbUf ??= {"r":1310721,"p":[{"n":"t","p":2530111}],"n":"","d":1940287,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(111671089983)
            
            //--TRIMMABLE-BOUNDARY-START(34361678655)
            /*Dictionary<TableRowType, List<TableRowModel>>*/ ClipBoards = null;
            //--TRIMMABLE-BOUNDARY-END(34361678655)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361678655)
                this.ClipBoards = new ($.$$.SCG.Dictionary$$$($.$ajwi.LCACM.TableRowType, $.$$.SCG.List$$($.$WRsM.LCACSDV.TableRowModel)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(34361678655)
                
            }
            static $h = 1940287;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656645951),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426449727,
        "f": 50331649
      },
      "n": "Depth",
      "d": 1940287,
      "h": 38656645951,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656645951),
//--TRIMMABLE-BOUNDARY-START(115966057279),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196253503,
        "f": 50331649
      },
      "n": "ProviderName",
      "d": 1940287,
      "h": 115966057279,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966057279),
//--TRIMMABLE-BOUNDARY-START(128850959167),
    {
      "p": 513145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786188095,
        "f": 50331649
      },
      "n": "TableDefinition",
      "d": 1940287,
      "h": 128850959167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850959167),
//--TRIMMABLE-BOUNDARY-START(141735861055),
    {
      "p": 2530111,
      "i": [
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606318911,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1940287,
      "h": 141735861055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735861055),
//--TRIMMABLE-BOUNDARY-START(30066711359),
    {
      "p": 3644223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246580543,
        "f": 50331649
      },
      "n": "App",
      "d": 1940287,
      "h": 30066711359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066711359),
//--TRIMMABLE-BOUNDARY-START(137440893759),
    {
      "p": $.$typeArray($.$WRsM.LCACSDV.TableViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376122687,
        "f": 50331649
      },
      "n": "Tables",
      "d": 1940287,
      "h": 137440893759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440893759),
//--TRIMMABLE-BOUNDARY-START(111671089983),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$WRsM.LCACSDV.TableViewModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016384319,
        "f": 50331649
      },
      "n": "Groupings",
      "d": 1940287,
      "h": 111671089983,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671089983),
//--TRIMMABLE-BOUNDARY-START(34361678655),
    {
      "p": $.$$.SCG.Dictionary$$$($.$ajwi.LCACM.TableRowType, $.$$.SCG.List$$($.$WRsM.LCACSDV.TableRowModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836515135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555991871,
        "f": 83886081
      },
      "n": "ClipBoards",
      "d": 1940287,
      "h": 34361678655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361678655)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146030828351),
    {
      "r": 181338113,
      "p": [
        {
          "n": "specifiiedTable",
          "p": 2530111,
          "f": 65
        }
      ],
      "n": "Update",
      "d": 1940287,
      "h": 146030828351,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(146030828351)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133145926463),
    {
      "t": $.$typeArray($.$WRsM.LCACSDV.TableViewModel).$h,
      "n": "tables",
      "d": 1940287,
      "h": 133145926463,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145926463)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771744063),
    {
      "p": [
        {
          "n": "app",
          "p": 3644223
        },
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "tableDefinition",
          "p": 513145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1940287,
      "h": 25771744063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771744063)
  ],
  "h": 1940287
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.DataTablesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}DataTablesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1940287)
        
        

        //--TRIMMABLE-BOUNDARY-START(3382079)
        $asm.$cls(`$WRsM.LCACSSV$1.SystemStateViewModel`, ($self) => class SystemStateViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(12888283967)
            $ctor$3(/*string*/ uuid, /*Dictionary<string, StatusStore>*/ states)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888283967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UUID = uuid;
                    this.States = states;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888283967)
            
            //--TRIMMABLE-BOUNDARY-START(77312793407)
            /*string*/ UUID = null;
            //--TRIMMABLE-BOUNDARY-END(77312793407)
            
            //--TRIMMABLE-BOUNDARY-START(64427891519)
            /*Dictionary<string, StatusStore>*/ States = null;
            //--TRIMMABLE-BOUNDARY-END(64427891519)
            
            //--TRIMMABLE-BOUNDARY-START(21478218559)
            /*bool */ CanEdit(/*object*/ target, /*string?*/ propertyName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478218559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478218559)
            
            //--TRIMMABLE-BOUNDARY-START(68722858815)
            /*Dictionary<string, object> */ get Statuses()
            {
                return $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String, $.$$.S.Object, this.States, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String))().$ctor(this,  (/**/ kv) =>
                {
                    return kv.Key;
                }, $IZUkoj ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.Object))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value;
                }, $zivJQj ??= {"r":131073,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(68722858815)
            
            //--TRIMMABLE-BOUNDARY-START(17183251263)
            /*Task */ AddStatusStore(/*string*/ name, /*StatusStore*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183251263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.States.set_Item(name, value);
                this.States = $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String, $.$ajwi.LCAM.StatusStore, this.States, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Key;
                }, $QpBXXi ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$ajwi.LCAM.StatusStore))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value;
                }, $TuxvXi ??= {"r":1037433,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17183251263)
            
            //--TRIMMABLE-BOUNDARY-START(51542989631)
            /*Task */ RemoveStatusStore(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542989631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.States.Remove$1(name);
                this.States = $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String, $.$ajwi.LCAM.StatusStore, this.States, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Key;
                }, $xOulth ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore), $.$ajwi.LCAM.StatusStore))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value;
                }, $MYLbDg ??= {"r":1037433,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h}],"n":"","d":3382079,"h":0,"f":17825794}));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(51542989631)
            
            //--TRIMMABLE-BOUNDARY-START(73017826111)
            /*ValueTask */ Update(/*object*/ target, /*string*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017826111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(73017826111)
            
            //--TRIMMABLE-BOUNDARY-START(4317664938)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Editable.IEditController.CanEdit(object?, string?)
            LCFCCE$IEditController$CanEdit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317664938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanEdit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317664938)
            
            //--TRIMMABLE-BOUNDARY-START(8612632234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Editable.IEditController.Update(object, string)
            LCFCCE$IEditController$Update()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8612632234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Update(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8612632234)
            
            static $h = 3382079;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77312793407),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248022335,
        "f": 50331649
      },
      "n": "UUID",
      "d": 3382079,
      "h": 77312793407,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312793407),
//--TRIMMABLE-BOUNDARY-START(64427891519),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068153151,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132924223,
        "f": 83886081
      },
      "n": "States",
      "d": 3382079,
      "h": 64427891519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427891519),
//--TRIMMABLE-BOUNDARY-START(68722858815),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658087743,
        "f": 50331649
      },
      "n": "Statuses",
      "d": 3382079,
      "h": 68722858815,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722858815)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478218559),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "propertyName",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CanEdit",
      "d": 3382079,
      "h": 21478218559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478218559),
//--TRIMMABLE-BOUNDARY-START(17183251263),
    {
      "r": 178454529,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1037433
        }
      ],
      "n": "AddStatusStore",
      "d": 3382079,
      "h": 17183251263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183251263),
//--TRIMMABLE-BOUNDARY-START(51542989631),
    {
      "r": 178454529,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "RemoveStatusStore",
      "d": 3382079,
      "h": 51542989631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542989631),
//--TRIMMABLE-BOUNDARY-START(73017826111),
    {
      "r": 181338113,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "property",
          "p": 1310721
        }
      ],
      "n": "Update",
      "d": 3382079,
      "h": 73017826111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73017826111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888283967),
    {
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "states",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3382079,
      "h": 12888283967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888283967)
  ],
  "h": 3382079
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCCE.IEditController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.ViewModels.SystemStateViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}ViewModels${separator}SystemStateViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3382079)
        
        

        //--TRIMMABLE-BOUNDARY-START(3644223)
        $asm.$cls(`$WRsM.LCACV.ApplicationViewModel`, ($self) => class ApplicationViewModel extends $.$vWqU.LCFCC.HubConnectedViewModel$$($.$ajwi.LCACH.IAdminHubClient)
        {
            //--TRIMMABLE-BOUNDARY-START(21478480703)
            $ctor$4(/*IAuthenticationService*/ authManager, /*IServerRemoteService*/ server, /*IHubConnector<IAdminHubClient>*/ hubConnector)
            {
                super.$ctor$3(authManager, server, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478480703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = new $.$WRsM.LCACSSV.ServicesViewModel().$ctor$3(this);
                    this.States = new $.$WRsM.LCACSSV$1.SystemStatesViewModel().$ctor$3(this);
                    _ = this.Load();
                    this.disposeHubSubscription = hubConnector.LCFCH$IHubConnector$$$Subscribe(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478480703)
            
            //--TRIMMABLE-BOUNDARY-START(38658349887)
            /*IDisposable?*/ disposeHubSubscription = null;
            //--TRIMMABLE-BOUNDARY-END(38658349887)
            
            //--TRIMMABLE-BOUNDARY-START(77313055551)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77313055551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let remote = null;
                        try
                        {
                            let $t1, $r1;
                            remote = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$ajwi.LCACS.IAdminRemoteService, null);
                            /*var*/ let response = ($t1 = remote.LCFCS$3$IServiceProxy$$$Service.LCACS$IAdminRemoteService$Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            if (response.Success)
                            {
                                this.Model = response.Data;
                                this.DataTables = $.$sl.SL.Enumerable.ToArray($.$WRsM.LCACSDV.DataTablesViewModel, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCACM.TableDefinition), $.$WRsM.LCACSDV.DataTablesViewModel, this.Model.TableDefinitions, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCACM.TableDefinition), $.$WRsM.LCACSDV.DataTablesViewModel))().$ctor(this,  (/**/ t) =>
                                {
                                    return new $.$WRsM.LCACSDV.DataTablesViewModel().$ctor$3(this, t.Key, t.Value);
                                }, $xaOXUj ??= {"r":1940287,"p":[{"n":"t","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$ajwi.LCACM.TableDefinition).$h}],"n":"","d":3644223,"h":0,"f":17825794})));
                                this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                            }
                            else 
                            {
                                throw new $.$$.S.Exception().$ctor$4(response.Message);
                            }
                        }
                        finally
                        {
                            remote?.S$IDisposable$Dispose();
                        }
                    }
                    catch(e)
                    {
                        this.LoadErrorMessage = e.Message;
                        this.Loading = $.$vWqU.LCFCC.LoadState.LoadError;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77313055551)
            
            //--TRIMMABLE-BOUNDARY-START(124557695807)
            /*Task *//*async*/  UpdateDataTables()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124557695807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Loading = $.$vWqU.LCFCC.LoadState.Loading;
                    let $i2 = 0;
                    let $arr2 = this.DataTables;
                    while ($i2 < $arr2.length)
                    {
                        let $t3, $r3;
                        let table = $arr2[$i2++];
                        ($t3 = table.Update(null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124557695807)
            
            //--TRIMMABLE-BOUNDARY-START(128852663103)
            /*Task */ WriteServiceConsole(/*string*/ serviceId, /*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852663103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services.WriteServiceConsole(serviceId, text);
            }
            //--TRIMMABLE-BOUNDARY-END(128852663103)
            
            //--TRIMMABLE-BOUNDARY-START(94492924735)
            /*Task */ ServiceExited(/*string*/ serviceId, /*int*/ exitCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492924735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services.ServiceExited(serviceId, exitCode);
            }
            //--TRIMMABLE-BOUNDARY-END(94492924735)
            
            //--TRIMMABLE-BOUNDARY-START(90197957439)
            /*Task */ ServiceException(/*string*/ serviceId, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197957439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services.ServiceException(serviceId, message);
            }
            //--TRIMMABLE-BOUNDARY-END(90197957439)
            
            //--TRIMMABLE-BOUNDARY-START(30068415295)
            /*DataTablesViewModel[]*/ DataTables = null;
            //--TRIMMABLE-BOUNDARY-END(30068415295)
            
            //--TRIMMABLE-BOUNDARY-START(98787892031)
            /*ServicesViewModel*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(98787892031)
            
            //--TRIMMABLE-BOUNDARY-START(120262728511)
            /*SystemStatesViewModel*/ States = null;
            //--TRIMMABLE-BOUNDARY-END(120262728511)
            
            //--TRIMMABLE-BOUNDARY-START(81608022847)
            /*AdminModel?*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(81608022847)
            
            //--TRIMMABLE-BOUNDARY-START(34363382591)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363382591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposeHubSubscription?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(34363382591)
            
            //--TRIMMABLE-BOUNDARY-START(25773447999)
            /*Task */ AddStatusStore(/*string*/ uuid, /*string*/ name, /*StatusStore*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773447999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.States.AddStatusStore(uuid, name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25773447999)
            
            //--TRIMMABLE-BOUNDARY-START(85902990143)
            /*Task */ RemoveStatusStore(/*string*/ uuid, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902990143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.States.RemoveStatusStore(uuid, name);
            }
            //--TRIMMABLE-BOUNDARY-END(85902990143)
            
            //--TRIMMABLE-BOUNDARY-START(21474956409)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Hubs.IAdminHubClient.WriteServiceConsole(string, string)
            LCACH$IAdminHubClient$WriteServiceConsole()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474956409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WriteServiceConsole(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474956409)
            
            //--TRIMMABLE-BOUNDARY-START(12885021817)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Hubs.IAdminHubClient.ServiceException(string, string)
            LCACH$IAdminHubClient$ServiceException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885021817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceException(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885021817)
            
            //--TRIMMABLE-BOUNDARY-START(17179989113)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Hubs.IAdminHubClient.ServiceExited(string, int)
            LCACH$IAdminHubClient$ServiceExited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179989113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceExited(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17179989113)
            
            //--TRIMMABLE-BOUNDARY-START(4295087225)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Hubs.IAdminHubClient.AddStatusStore(string, string, LivingThing.Core.Admin.Models.StatusStore)
            LCACH$IAdminHubClient$AddStatusStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddStatusStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295087225)
            
            //--TRIMMABLE-BOUNDARY-START(8590054521)
            //Generated interface implemetation for LivingThing.Core.Admin.Common.Hubs.IAdminHubClient.RemoveStatusStore(string, string)
            LCACH$IAdminHubClient$RemoveStatusStore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590054521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveStatusStore(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590054521)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30068415295)
                this.DataTables = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.DataTablesViewModel), null, [0], null);
                //--TRIMMABLE-BOUNDARY-END(30068415295)
                
            }
            static $h = 3644223;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.HubConnectedViewModel$$($.$ajwi.LCACH.IAdminHubClient); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30068415295),
    {
      "p": $.$typeArray($.$WRsM.LCACSDV.DataTablesViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248284479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107377826623,
        "f": 83886082
      },
      "n": "DataTables",
      "d": 3644223,
      "h": 30068415295,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068415295),
//--TRIMMABLE-BOUNDARY-START(98787892031),
    {
      "p": 2857791,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428153663,
        "f": 50331649
      },
      "n": "Services",
      "d": 3644223,
      "h": 98787892031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98787892031),
//--TRIMMABLE-BOUNDARY-START(120262728511),
    {
      "p": 3316543,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018088255,
        "f": 50331649
      },
      "n": "States",
      "d": 3644223,
      "h": 120262728511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262728511),
//--TRIMMABLE-BOUNDARY-START(81608022847),
    {
      "p": 906361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838219071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115967761215,
        "f": 83886081
      },
      "n": "Model",
      "d": 3644223,
      "h": 81608022847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81608022847)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77313055551),
    {
      "r": 181338113,
      "n": "Load",
      "d": 3644223,
      "h": 77313055551,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(77313055551),
//--TRIMMABLE-BOUNDARY-START(124557695807),
    {
      "r": 178454529,
      "n": "UpdateDataTables",
      "d": 3644223,
      "h": 124557695807,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(124557695807),
//--TRIMMABLE-BOUNDARY-START(128852663103),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteServiceConsole",
      "d": 3644223,
      "h": 128852663103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128852663103),
//--TRIMMABLE-BOUNDARY-START(94492924735),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "exitCode",
          "p": 655361
        }
      ],
      "n": "ServiceExited",
      "d": 3644223,
      "h": 94492924735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492924735),
//--TRIMMABLE-BOUNDARY-START(90197957439),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ServiceException",
      "d": 3644223,
      "h": 90197957439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90197957439),
//--TRIMMABLE-BOUNDARY-START(34363382591),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3644223,
      "h": 34363382591,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34363382591),
//--TRIMMABLE-BOUNDARY-START(25773447999),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1037433
        }
      ],
      "n": "AddStatusStore",
      "d": 3644223,
      "h": 25773447999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773447999),
//--TRIMMABLE-BOUNDARY-START(85902990143),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "RemoveStatusStore",
      "d": 3644223,
      "h": 85902990143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902990143)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38658349887),
    {
      "t": 91095041,
      "n": "disposeHubSubscription",
      "d": 3644223,
      "h": 38658349887,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38658349887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478480703),
    {
      "p": [
        {
          "n": "authManager",
          "p": 1655170
        },
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$ajwi.LCACH.IAdminHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3644223,
      "h": 21478480703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478480703)
  ],
  "h": 3644223
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$ajwi.LCACH.IAdminHubClient, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.ViewModels.ApplicationViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}ViewModels${separator}ApplicationViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3644223)
        
        

        //--TRIMMABLE-BOUNDARY-START(1088319)
        $asm.$cls(`$WRsM.LCACS.ContactMesssageComposerProvider`, ($self) => class ContactMesssageComposerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540695871)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(51540695871)
            
            //--TRIMMABLE-BOUNDARY-START(8591022911)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591022911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591022911)
            
            //--TRIMMABLE-BOUNDARY-START(55835663167)
            /*string? */ get Title()
            {
                return "Contacts";
            }
            //--TRIMMABLE-BOUNDARY-END(55835663167)
            
            //--TRIMMABLE-BOUNDARY-START(12885990207)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12885990207)
            
            //--TRIMMABLE-BOUNDARY-START(47245728575)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-contacts"/*MaterialDesignIconNames.Contacts*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47245728575)
            
            //--TRIMMABLE-BOUNDARY-START(42950761279)
            /*Pager<ContactModel> */ GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950761279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$Iaui.LCFCM.ContactModel, this.server, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42950761279)
            
            //--TRIMMABLE-BOUNDARY-START(4295243228)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider<LivingThing.Core.Frameworks.Common.Models.ContactModel>.GetContacts()
            LCFCM$IMessageComposerProvider$$$GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295243228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetContacts(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295243228)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1088319;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835663167),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655793983,
        "f": 50331649
      },
      "n": "Title",
      "d": 1088319,
      "h": 55835663167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835663167),
//--TRIMMABLE-BOUNDARY-START(12885990207),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475924799,
        "f": 50331649
      },
      "n": "Description",
      "d": 1088319,
      "h": 12885990207,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885990207),
//--TRIMMABLE-BOUNDARY-START(47245728575),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065859391,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1088319,
      "h": 47245728575,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245728575)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950761279),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$Iaui.LCFCM.ContactModel).$h,
      "n": "GetContacts",
      "d": 1088319,
      "h": 42950761279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950761279)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540695871),
    {
      "t": 1309651,
      "n": "server",
      "d": 1088319,
      "h": 51540695871,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540695871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591022911),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1088319,
      "h": 8591022911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591022911)
  ],
  "h": 1088319
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.ContactModel), $.$UrvY.LCFCM.IMessageComposerProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Services.ContactMesssageComposerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Services${separator}ContactMesssageComposerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1088319)
        
        

        //--TRIMMABLE-BOUNDARY-START(695103)
        $asm.$cls(`$WRsM.LCACM.EditModelTypeDescriptor`, ($self) => class EditModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACM.EditModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295662399)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295662399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WRsM.LCACM.EditModelTypeDescriptor.GenerateProperties($.$WRsM.LCACM.EditModel, this, factory);
                    }, $OzFUSa ??= {"r":65537,"n":"","d":695103,"h":0,"f":17825794}), 0, "EditModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\Models_EditModel_LivingThing.Core.Admin.Client.Models.EditModelTypeDescriptorBuilder.g.cs", "EditModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295662399)
            
            //--TRIMMABLE-BOUNDARY-START(12885596991)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885596991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Model"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACM.EditModel.$type, $.$discardRef(), "Model", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Model")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.EntryModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Model";
                        $i1.DelaredOn = "LivingThing.Core.Admin.Client.Models.EditModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.EntryModel, ($.$cast(target, $.$WRsM.LCACM.EditModel)).Model);
                        }, $wnuCWa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695103,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Model = value.AsReference($.$Iaui.LCFCM.EntryModel);
                        }, $TJdiKg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695103,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Fields"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACM.EditModel.$type, $.$discardRef(), "Fields", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Fields")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$so.SCO.ObservableCollection$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Fields";
                        $i3.DelaredOn = "LivingThing.Core.Admin.Client.Models.EditModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$so.SCO.ObservableCollection$$($.$$.S.String), ($.$cast(target, $.$WRsM.LCACM.EditModel)).Fields);
                        }, $HxpwZh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695103,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Fields = value.AsReference($.$so.SCO.ObservableCollection$$($.$$.S.String));
                        }, $TljqYe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695103,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UndoDirty"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACM.EditModel.$type, $.$discardRef(), "UndoDirty", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UndoDirty")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Action, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "UndoDirty";
                        $i5.DelaredOn = "LivingThing.Core.Admin.Client.Models.EditModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Action, ($.$cast(target, $.$WRsM.LCACM.EditModel)).UndoDirty);
                        }, $fjIWec ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695103,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACM.EditModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.UndoDirty = value.AsReference($.$$.S.Action);
                        }, $NGTQZg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695103,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885596991)
            
            //--TRIMMABLE-BOUNDARY-START(17180564287)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Models.EditModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180564287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Model = _target.Model;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Model"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.EntryModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Model, ($v) => _Model = $v, $.$Iaui.LCFCM.EntryModel)))
                    {
                        _target.Model = _Model;
                    }
                }
                {
                    /*var*/ let _Fields = _target.Fields;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Fields"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$so.SCO.ObservableCollection$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Fields, ($v) => _Fields = $v, $.$so.SCO.ObservableCollection$$($.$$.S.String))))
                    {
                        _target.Fields = _Fields;
                    }
                }
                {
                    /*var*/ let _UndoDirty = _target.UndoDirty;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UndoDirty"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Action));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _UndoDirty, ($v) => _UndoDirty = $v, $.$$.S.Action)))
                    {
                        _target.UndoDirty = _UndoDirty;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180564287)
            
            //--TRIMMABLE-BOUNDARY-START(8590629695)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Models.EditModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590629695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WRsM.LCACM.EditModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WRsM.LCACM.EditModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACM.EditModel)))
                {
                    /*var*/ let result = $.$WRsM.LCACM.EditModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACM.EditModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WRsM.LCACM.EditModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACM.EditModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590629695)
            
            static $h = 695103;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACM.EditModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885596991),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 695103,
      "h": 12885596991,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885596991),
//--TRIMMABLE-BOUNDARY-START(17180564287),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 564031,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 695103,
      "h": 17180564287,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180564287),
//--TRIMMABLE-BOUNDARY-START(8590629695),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 564031,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 695103,
      "h": 8590629695,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590629695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295662399),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 695103,
      "h": 4295662399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295662399)
  ],
  "h": 695103
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WRsM.LCACM.EditModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Models.EditModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Models${separator}EditModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(695103)
        
        

        //--TRIMMABLE-BOUNDARY-START(1547071)
        $asm.$cls(`$WRsM.LCACSD.DataTableManager`, ($self) => class DataTableManager extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.DataTablesViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(55836121919)
            /*DataTablesViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(55836121919)
            
            //--TRIMMABLE-BOUNDARY-START(34361285439)
            /*Task<bool> */ NavigatingTo(/*TableViewModel*/ table)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361285439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(34361285439)
            
            //--TRIMMABLE-BOUNDARY-START(38656252735)
            /*string */ get OptimizedComponentName()
            {
                return "datatablemanager";
            }
            //--TRIMMABLE-BOUNDARY-END(38656252735)
            
            //--TRIMMABLE-BOUNDARY-START(51541154623)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541154623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSDV.DataTablesViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51541154623)
            
            //--TRIMMABLE-BOUNDARY-START(12886448959)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886448959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let groupings = this.ViewModel.Groupings;
                let $en2 = groupings.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let tables = $en2.SCG$IEnumerator$$$Current;
                    {
                        if (tables.SL$IGrouping$$$$Key === "")
                        {
                            let $en3 = $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableViewModel, tables, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                            {
                                return !t.TableRowType.IsAbstract;
                            }, $aeQGac ??= {"r":262145,"p":[{"n":"t","p":2530111}],"n":"","d":1547071,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let table = $en3.SCG$IEnumerator$$$Current;
                                {
                                    __builder.OpenComponent$1($.$WRsM.LCACSD.TableApplicationPage, 0);
                                    __builder.AddComponentParameter(1, "Table", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableViewModel, table));
                                    __builder.AddComponentParameter(2, "OnShowing", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$WRsM.LCACSDV.TableViewModel, this, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.STT.Task))().$ctor(this, this.NavigatingTo))));
                                    __builder.SetKey(table);
                                    __builder.CloseComponent();
                                }
                            }
                        }
                        else 
                        {
                            __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 3);
                            __builder.AddComponentParameter(4, "Class", "pd");
                            __builder.AddComponentParameter(5, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Database/" + $.$strNN(tables.SL$IGrouping$$$$Key)));
                            __builder.AddComponentParameter(6, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Database/" + $.$strNN(tables.SL$IGrouping$$$$Key))));
                            __builder.AddAttribute$3(7, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                                {
                                    __builder2.AddContent$4(8, tables.SL$IGrouping$$$$Key);
                                }, $bgzWze ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1547071,"h":0,"f":17825794});
                            }), $pvnPgh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1547071,"h":0,"f":17825794}));
                            __builder.AddAttribute$3(9, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                                {
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 10);
                                    __builder2.AddComponentParameter(11, "Class", "mdi mdi-database");
                                    __builder2.CloseComponent();
                                }, $IqBKvg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1547071,"h":0,"f":17825794});
                            }), $lmauAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1547071,"h":0,"f":17825794}));
                            __builder.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                                {
                                    __builder2.OpenComponent$1($.$WRsM.LCACSD.DataTableGroupApplicationPage, 13);
                                    __builder2.AddComponentParameter(14, "Tables", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sl.SL.IGrouping$$$($.$$.S.String, $.$WRsM.LCACSDV.TableViewModel), tables));
                                    __builder2.CloseComponent();
                                }, $efVQZa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1547071,"h":0,"f":17825794});
                            }), $mNbHUb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1547071,"h":0,"f":17825794}));
                            __builder.AddAttribute$3(15, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                            {
                                let $en4 = $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableViewModel, tables, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                                {
                                    return !t.TableRowType.IsAbstract;
                                }, $cNvtlj ??= {"r":262145,"p":[{"n":"t","p":2530111}],"n":"","d":1547071,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                                while ($en4.SC$1$IEnumerator$MoveNext())
                                {
                                    let table = $en4.SCG$IEnumerator$$$Current;
                                    {
                                        __builder2.OpenComponent$1($.$WRsM.LCACSD.TableApplicationPage, 16);
                                        __builder2.AddComponentParameter(17, "Table", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableViewModel, table));
                                        __builder2.AddComponentParameter(18, "OnShowing", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$WRsM.LCACSDV.TableViewModel, this, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableViewModel, $.$$.STT.Task))().$ctor(this, this.NavigatingTo))));
                                        __builder2.SetKey(table);
                                        __builder2.CloseComponent();
                                    }
                                }
                            }), $lcafTg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1547071,"h":0,"f":17825794}));
                            __builder.CloseComponent();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886448959)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591481663)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591481663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591481663)
            
            //--TRIMMABLE-BOUNDARY-START(8591481663)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591481663)
            
            static $h = 1547071;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.DataTablesViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836121919),
    {
      "p": 1940287,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066318143,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246187327,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 1547071,
      "h": 55836121919,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836121919),
//--TRIMMABLE-BOUNDARY-START(38656252735),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476383551,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1547071,
      "h": 38656252735,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656252735)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361285439),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "table",
          "p": 2530111
        }
      ],
      "n": "NavigatingTo",
      "d": 1547071,
      "h": 34361285439,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34361285439),
//--TRIMMABLE-BOUNDARY-START(51541154623),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1547071,
      "h": 51541154623,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541154623),
//--TRIMMABLE-BOUNDARY-START(12886448959),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1547071,
      "h": 12886448959,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886448959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591481663),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1547071,
      "h": 8591481663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591481663)
  ],
  "h": 1547071
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.DataTableManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}DataTableManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1547071)
        
        

        //--TRIMMABLE-BOUNDARY-START(3054399)
        $asm.$cls(`$WRsM.LCACSS$1.SystemStates`, ($self) => class SystemStates extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV$1.SystemStatesViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(55837629247)
            /*SystemStatesViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(55837629247)
            
            //--TRIMMABLE-BOUNDARY-START(34362792767)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362792767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.Load();
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(34362792767)
            
            //--TRIMMABLE-BOUNDARY-START(38657760063)
            /*string */ get OptimizedComponentName()
            {
                return "systemstates";
            }
            //--TRIMMABLE-BOUNDARY-END(38657760063)
            
            //--TRIMMABLE-BOUNDARY-START(51542661951)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542661951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSSV$1.SystemStatesViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51542661951)
            
            //--TRIMMABLE-BOUNDARY-START(12887956287)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887956287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    let $en2 = this.ViewModel.Statuses.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let status = $en2.SCG$IEnumerator$$$Current;
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 2);
                            __builder2.AddComponentParameter(3, "Class", "bg-card pd shadow mgb");
                            __builder2.AddComponentParameter(4, "header-class", "bdb");
                            __builder2.AddAttribute$3(5, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(6, "h4");
                                    __builder3.AddAttribute$5(7, "class", "clickable mgy-3");
                                    __builder3.AddContent$4(8, status.UUID);
                                    __builder3.AddMarkupContent(9, "\r\n                    (");
                                    __builder3.AddContent$3(10, $.$box(status.States.Count, $.$$.S.Int32));
                                    __builder3.AddMarkupContent(11, ")\r\n                    ");
                                    __builder3.OpenElement(12, "i");
                                    __builder3.AddAttribute$5(13, "class", `mdi ${$.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(context) ? "mdi-chevron-up" : "mdi-chevron-down"))} f-right`);
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }, $HbwrYg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3054399,"h":0,"f":17825794});
                            }), $oNQWWg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":3054399,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(14, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$WRsM.LCACSS$1.SystemState, 15);
                                    __builder3.AddComponentParameter(16, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSSV$1.SystemStateViewModel, status));
                                    __builder3.CloseComponent();
                                }, $cmxqod ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3054399,"h":0,"f":17825794});
                            }), $KnCexa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":3054399,"h":0,"f":17825794}));
                            __builder2.SetKey(status);
                            __builder2.CloseComponent();
                        }
                    }
                }), $lmNqwf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3054399,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12887956287)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592988991)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592988991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592988991)
            
            //--TRIMMABLE-BOUNDARY-START(8592988991)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592988991)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55837629247)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(55837629247)
                
            }
            static $h = 3054399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV$1.SystemStatesViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837629247),
    {
      "p": 3316543,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067825471,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247694655,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3054399,
      "h": 55837629247,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837629247),
//--TRIMMABLE-BOUNDARY-START(38657760063),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477890879,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3054399,
      "h": 38657760063,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657760063)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362792767),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 3054399,
      "h": 34362792767,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34362792767),
//--TRIMMABLE-BOUNDARY-START(51542661951),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3054399,
      "h": 51542661951,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51542661951),
//--TRIMMABLE-BOUNDARY-START(12887956287),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3054399,
      "h": 12887956287,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887956287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592988991),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3054399,
      "h": 8592988991,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592988991)
  ],
  "h": 3054399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3054399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1809215)
        $asm.$cls(`$WRsM.LCACSD.TableRow`, ($self) => class TableRow extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableRowViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(55836384063)
            /*TableRowViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(55836384063)
            
            //--TRIMMABLE-BOUNDARY-START(17181678399)
            /*bool */ Filter(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181678399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let key = $.$$.S.String.ToString.call(data.LCFCD$1$IPropertyDescriptor$Name);
                return $.$sl.SL.Enumerable.Any($.$ajwi.LCACM.TablePropertyColumn, this.ViewModel.Table.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/**/ col) =>
                {
                    return $.$$.S.String.Equals$5.call(col.Name, key);
                }, $ZqPuqg ??= {"r":262145,"p":[{"n":"col","p":578681}],"n":"","d":1809215,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(17181678399)
            
            //--TRIMMABLE-BOUNDARY-START(38656514879)
            /*string */ get OptimizedComponentName()
            {
                return "tablerow";
            }
            //--TRIMMABLE-BOUNDARY-END(38656514879)
            
            //--TRIMMABLE-BOUNDARY-START(51541416767)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541416767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSDV.TableRowViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51541416767)
            
            //--TRIMMABLE-BOUNDARY-START(12886711103)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886711103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor)), 0);
                __builder.AddComponentParameter(1, "Target", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor), this.ViewModel.DetailedRows.SCG$IDictionary$$$$Values));
                __builder.AddComponentParameter(2, "Filter", "Filter");
                __builder.AddComponentParameter(3, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD$1.IObservableDataDescriptor))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let col = $.$sl.SL.Enumerable.Single($.$ajwi.LCACM.TablePropertyColumn, this.ViewModel.Table.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*col*/ col) =>
                        {
                            return $.$$.S.String.Equals$5.call(col.Name, context.Model.LCFCD$1$IObservableDataDescriptor$Name);
                        }, $xrkMkf ??= {"r":262145,"p":[{"n":"col","p":578681}],"n":"","d":1809215,"h":0,"f":17825794}));
                        $.$WRsM._LCACSDT.TypeInference.CreateCascadingValue_0($.$WRsM.LCACSD.TableRow, __builder2, 6, 7, this, 8, true, 9, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACSD.TableColumn, 10);
                            __builder3.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableRowColumnViewModel, this.ViewModel.GetColumn(col)));
                            __builder3.CloseComponent();
                        }, $jRqNDf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1809215,"h":0,"f":17825794}));
                    }, $aSYEOb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1809215,"h":0,"f":17825794});
                }), $ZMWMCj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$fPer.LCFCD$1.IObservableDataDescriptor)).$h}],"n":"","d":1809215,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886711103)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591743807)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591743807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591743807)
            
            //--TRIMMABLE-BOUNDARY-START(8591743807)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591743807)
            
            static $h = 1809215;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableRowViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836384063),
    {
      "p": 2464575,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361547583,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246449471,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 1809215,
      "h": 55836384063,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836384063),
//--TRIMMABLE-BOUNDARY-START(38656514879),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771612991,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1809215,
      "h": 38656514879,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656514879)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181678399),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "data",
          "p": 40733014
        }
      ],
      "n": "Filter",
      "d": 1809215,
      "h": 17181678399,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181678399),
//--TRIMMABLE-BOUNDARY-START(51541416767),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1809215,
      "h": 51541416767,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541416767),
//--TRIMMABLE-BOUNDARY-START(12886711103),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1809215,
      "h": 12886711103,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886711103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591743807),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1809215,
      "h": 8591743807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591743807)
  ],
  "h": 1809215
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.TableRow`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}TableRow`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1809215)
        
        

        //--TRIMMABLE-BOUNDARY-START(1743679)
        $asm.$cls(`$WRsM.LCACSD.TableColumn`, ($self) => class TableColumn extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableRowColumnViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(30066514751)
            /*IEnumerable<IAdminTableColumnEditor>*/ Editors = null;
            //--TRIMMABLE-BOUNDARY-END(30066514751)
            
            //--TRIMMABLE-BOUNDARY-START(98785991487)
            /*TableRowColumnViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(98785991487)
            
            //--TRIMMABLE-BOUNDARY-START(25771547455)
            /*IAdminTableColumnEditor? */ get Editor()
            {
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$ajwi.LCACS.IAdminTableColumnEditor, this.Editors, new ($.$$.S.Func$$$($.$ajwi.LCACS.IAdminTableColumnEditor, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.LCACS$IAdminTableColumnEditor$CanEdit(this.ViewModel.Table.TableRowType, this.ViewModel.Column);
                }, $DdSEgg ??= {"r":262145,"p":[{"n":"e","p":840825}],"n":"","d":1743679,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25771547455)
            
            //--TRIMMABLE-BOUNDARY-START(21476580159)
            /*Task *//*async*/  Edit()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476580159);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Editor.LCACS$IAdminTableColumnEditor$Edit(this.ViewModel.Table.DataTable.TableDefinition, this.ViewModel.Table.TableRowType, this.ViewModel.Column, this.ViewModel.Row.Data, this.ViewModel.Value), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.ViewModel.Table.Update(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableRowModel), [ this.ViewModel.Row.Data ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476580159)
            
            //--TRIMMABLE-BOUNDARY-START(73016187711)
            /*string */ get OptimizedComponentName()
            {
                return "tablecolumn";
            }
            //--TRIMMABLE-BOUNDARY-END(73016187711)
            
            //--TRIMMABLE-BOUNDARY-START(94491024191)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491024191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSDV.TableRowColumnViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(94491024191)
            
            //--TRIMMABLE-BOUNDARY-START(68721220415)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721220415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Editors = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$ajwi.LCACS.IAdminTableColumnEditor), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68721220415)
            
            //--TRIMMABLE-BOUNDARY-START(17181612863)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181612863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 1, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ToggleCollapsed)));
                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 2, "onclick", true);
                __builder.AddAttribute$5(3, "class", $.$strNN($.$strNN($.$strNN("mihx-03" + " pd-2") + " stack") + " ") + $.$strNN((!this.ViewModel.Collapsed ? "bg-primary-02 pdx" : "")));
                __builder.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 4);
                __builder.AddComponentParameter(5, "Class", "mgy-a");
                __builder.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 7);
                        __builder2.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 67108864/*MenuFeatures.PropagateClick*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                __builder3.AddContent$4(10, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.String.ToString.call(this.ViewModel.Column.Name)));
                            }, $eZXPCc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                        }), $vlBhHg ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(11, "\r\n        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 12);
                        __builder2.AddComponentParameter(13, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        __builder2.AddComponentParameter(14, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 67108864/*MenuFeatures.PropagateClick*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.CloseComponent();
                        if (this.Editor !== null)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 15);
                            __builder2.AddAttribute$3(16, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 17);
                                    __builder3.AddComponentParameter(18, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(19, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(20, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Edit))));
                                    __builder3.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 22);
                                        __builder4.AddComponentParameter(23, "Class", "mdi mdi-pencil");
                                        __builder4.CloseComponent();
                                    }), $UcHHMj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $ieOdFk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $LzPpRc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        if ($.$$.System.Array.$ReadT1.call(this.ViewModel.Column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 134217728/*DataType.Array*/)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 24);
                            __builder2.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 26);
                                    __builder3.AddComponentParameter(27, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(28, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(29, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ToggleCollapsed))));
                                    __builder3.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 31);
                                        __builder4.AddComponentParameter(32, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Collapsed ? "mdi mdi-plus" : "mdi mdi-minus"));
                                        __builder4.CloseComponent();
                                    }), $MIluhi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $lJbEfh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $CHBGWe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        else if ($.$$.System.Array.$ReadT1.call(this.ViewModel.Column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 21/*DataType.Class*/)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 33);
                            __builder2.AddAttribute$3(34, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 35);
                                    __builder3.AddComponentParameter(36, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(37, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(38, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ClassCopy))));
                                    __builder3.AddAttribute$3(39, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 40);
                                        __builder4.AddComponentParameter(41, "Class", "mdi mdi-content-copy");
                                        __builder4.CloseComponent();
                                    }), $njUtvc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $cBhOMk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $jHEScf ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(42, "\r\n            ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 43);
                            __builder2.AddAttribute$3(44, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 45);
                                    __builder3.AddComponentParameter(46, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(47, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(48, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ClassPaste))));
                                    __builder3.AddAttribute$3(49, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 50);
                                        __builder4.AddComponentParameter(51, "Class", "mdi mdi-content-paste");
                                        __builder4.CloseComponent();
                                    }), $RfDgIg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $QqQMvj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $xvGlGb ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(52, "\r\n            ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 53);
                            __builder2.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 55);
                                    __builder3.AddComponentParameter(56, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(57, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(58, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ClassDetach))));
                                    __builder3.AddAttribute$3(59, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 60);
                                        __builder4.AddComponentParameter(61, "Class", "mdi mdi-delete");
                                        __builder4.CloseComponent();
                                    }), $qlHvwj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $sODlPg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $NuvPxe ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(62, "\r\n            ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 63);
                            __builder2.AddAttribute$3(64, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 65);
                                    __builder3.AddComponentParameter(66, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                                    __builder3.AddComponentParameter(67, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(68, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.ToggleCollapsed))));
                                    __builder3.AddAttribute$3(69, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCC$4.ClassIcon, 70);
                                        __builder4.AddComponentParameter(71, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Collapsed ? "mdi mdi-plus" : "mdi mdi-minus"));
                                        __builder4.CloseComponent();
                                    }), $xbYXDd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $UzjWAf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $KkOfFf ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        else 
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 72);
                            __builder2.AddComponentParameter(73, "Class", "text-right");
                            __builder2.AddAttribute$3(74, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$3(75, (this.ViewModel.Value?.LCFCD$IValueProvider$Value ?? null));
                                }, $qEUPcj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                            }), $nOQOjh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }, $vRnjpj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794});
                }), $HLBWti ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1743679,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                if ($.$$.System.Array.$ReadT1.call(this.ViewModel.Column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 134217728/*DataType.Array*/)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCC$7.Collapsible, 76);
                    __builder.AddComponentParameter(77, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.ViewModel.Collapsed), $.$$.S.Boolean));
                    __builder.AddComponentParameter(78, "Class", "bdl bdw-3 bd-primary");
                    __builder.AddAttribute$3(79, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        if (!this.ViewModel.Collapsed)
                        {
                            if (this.ViewModel.DataTable !== null)
                            {
                                __builder2.OpenComponent$1($.$WRsM.LCACSD.Table, 80);
                                __builder2.AddComponentParameter(81, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableViewModel, this.ViewModel.DataTable));
                                __builder2.AddComponentParameter(82, "Class", "wp-100");
                                __builder2.CloseComponent();
                            }
                            else 
                            {
                                /*System.Collections.IEnumerable?*/ let __ca1__;
                                /*var*/ let value = ((__ca1__ = ($.$cast((this.ViewModel.Value?.LCFCD$IValueProvider$Value ?? null), $.$$.SC$1.IEnumerable))) !== null ? $.$sl.SL.Enumerable.Cast($.$$.S.Object, __ca1__) : null);
                                if (value !== null)
                                {
                                    __builder2.OpenElement(83, "ul");
                                    __builder2.AddAttribute$5(84, "class", "reset");
                                    let $en4 = value.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en4.SC$1$IEnumerator$MoveNext())
                                    {
                                        let v = $en4.SCG$IEnumerator$$$Current;
                                        {
                                            __builder2.OpenElement(85, "li");
                                            __builder2.AddAttribute$5(86, "class", "pd-2 bdb");
                                            __builder2.AddContent$1(87, $.$hDPm.LCFCCV$1.VisualPresent$$($.$$.S.Object).PresentValue(v, null, 3, null, null, null));
                                            __builder2.CloseElement();
                                        }
                                    }
                                    __builder2.CloseElement();
                                }
                            }
                        }
                    }), $bmNudc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else if ($.$$.System.Array.$ReadT1.call(this.ViewModel.Column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 21/*DataType.Class*/)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCC$7.Collapsible, 88);
                    __builder.AddComponentParameter(89, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.ViewModel.Collapsed), $.$$.S.Boolean));
                    __builder.AddComponentParameter(90, "Class", "bdl bdw-3 pdl bd-primary");
                    __builder.AddAttribute$3(91, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 92);
                        __builder2.AddComponentParameter(93, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this.ViewModel));
                        __builder2.AddAttribute$3(94, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            if (this.ViewModel.ClassRow !== null)
                            {
                                __builder3.OpenComponent$1($.$WRsM.LCACSD.TableRow, 95);
                                __builder3.AddComponentParameter(96, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableRowViewModel, this.ViewModel.ClassRow));
                                __builder3.CloseComponent();
                            }
                            else if (this.ViewModel.NullClass)
                            {
                                __builder3.AddContent$4(97, "None");
                            }
                        }), $GkNjUa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }), $UrOscc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1743679,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181612863)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886645567)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886645567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886645567)
            
            //--TRIMMABLE-BOUNDARY-START(12886645567)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12886645567)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30066514751)
                this.Editors = null;
                //--TRIMMABLE-BOUNDARY-END(30066514751)
                
            }
            static $h = 1743679;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableRowColumnViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066514751),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACS.IAdminTableColumnEditor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246383935,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606122303,
        "f": 83886081
      },
      "n": "Editors",
      "d": 1743679,
      "h": 30066514751,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066514751),
//--TRIMMABLE-BOUNDARY-START(98785991487),
    {
      "p": 2005823,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426253119,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196056895,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 1743679,
      "h": 98785991487,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785991487),
//--TRIMMABLE-BOUNDARY-START(25771547455),
    {
      "p": 840825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656449343,
        "f": 50331650
      },
      "n": "Editor",
      "d": 1743679,
      "h": 25771547455,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25771547455),
//--TRIMMABLE-BOUNDARY-START(73016187711),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836318527,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1743679,
      "h": 73016187711,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016187711)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476580159),
    {
      "r": 178454529,
      "n": "Edit",
      "d": 1743679,
      "h": 21476580159,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476580159),
//--TRIMMABLE-BOUNDARY-START(94491024191),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1743679,
      "h": 94491024191,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491024191),
//--TRIMMABLE-BOUNDARY-START(68721220415),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1743679,
      "h": 68721220415,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721220415),
//--TRIMMABLE-BOUNDARY-START(17181612863),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1743679,
      "h": 17181612863,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181612863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886645567),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1743679,
      "h": 12886645567,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886645567)
  ],
  "h": 1743679
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.TableColumn`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}TableColumn`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1743679)
        
        

        //--TRIMMABLE-BOUNDARY-START(2792255)
        $asm.$cls(`$WRsM.LCACSS.ServiceTasksManager`, ($self) => class ServiceTasksManager extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV.ServicesViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(85902138175)
            /*ServicesViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(85902138175)
            
            //--TRIMMABLE-BOUNDARY-START(60132334399)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(60132334399)
            
            //--TRIMMABLE-BOUNDARY-START(51542399807)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542399807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.Load();
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(51542399807)
            
            //--TRIMMABLE-BOUNDARY-START(55837367103)
            /*string */ get OptimizedComponentName()
            {
                return "servicetasksmanager";
            }
            //--TRIMMABLE-BOUNDARY-END(55837367103)
            
            //--TRIMMABLE-BOUNDARY-START(81607170879)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607170879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSSV.ServicesViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81607170879)
            
            //--TRIMMABLE-BOUNDARY-START(47247432511)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247432511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47247432511)
            
            //--TRIMMABLE-BOUNDARY-START(17182661439)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182661439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "container");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "row responsive");
                let $en2 = this.ViewModel.Services.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let service = $en2.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(4, "div");
                        __builder.AddAttribute$5(5, "class", "col-a mawx-25 miwx-25");
                        __builder.OpenComponent$1($.$WRsM.LCACSS.ServiceTaskCard, 6);
                        __builder.AddComponentParameter(7, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSSV.ServiceViewModel, service));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17182661439)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887694143)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887694143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887694143)
            
            //--TRIMMABLE-BOUNDARY-START(12887694143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12887694143)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60132334399)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(60132334399)
                
            }
            static $h = 2792255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV.ServicesViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85902138175),
    {
      "p": 2857791,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952465215,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312203583,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 2792255,
      "h": 85902138175,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85902138175),
//--TRIMMABLE-BOUNDARY-START(60132334399),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362530623,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722268991,
        "f": 83886081
      },
      "n": "Server",
      "d": 2792255,
      "h": 60132334399,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60132334399),
//--TRIMMABLE-BOUNDARY-START(55837367103),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772596031,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2792255,
      "h": 55837367103,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55837367103)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51542399807),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 2792255,
      "h": 51542399807,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51542399807),
//--TRIMMABLE-BOUNDARY-START(81607170879),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2792255,
      "h": 81607170879,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81607170879),
//--TRIMMABLE-BOUNDARY-START(47247432511),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2792255,
      "h": 47247432511,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247432511),
//--TRIMMABLE-BOUNDARY-START(17182661439),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2792255,
      "h": 17182661439,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182661439)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887694143),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2792255,
      "h": 12887694143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887694143)
  ],
  "h": 2792255
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.Services.ServiceTasksManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}Services${separator}ServiceTasksManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2792255)
        
        

        //--TRIMMABLE-BOUNDARY-START(2726719)
        $asm.$cls(`$WRsM.LCACSS.ServiceTaskCard`, ($self) => class ServiceTaskCard extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV.ServiceViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(111671876415)
            /*ServiceViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(111671876415)
            
            //--TRIMMABLE-BOUNDARY-START(17182595903)
            /*Application*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(17182595903)
            
            //--TRIMMABLE-BOUNDARY-START(30067497791)
            /*IConsole */ get Console()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247366975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.Console;
            }
            /*IConsole */ set Console(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197039935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.Console = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30067497791)
            
            //--TRIMMABLE-BOUNDARY-START(25772530495)
            /*ValueTask */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772530495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.Error = null;
                this.ViewModel.ExitCode = null;
                return (this.Console?.LCFCC$IConsole$Clear() ?? null) ?? $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25772530495)
            
            //--TRIMMABLE-BOUNDARY-START(73017170751)
            /*ValueTask *//*async*/  Run()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017170751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let desc = $.$sl.SL.Enumerable.ToArray($.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.Select$1($.$ajwi.LCACM.ServiceParameterModel, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.ViewModel.Model.Parameters, new ($.$$.S.Func$$$($.$ajwi.LCACM.ServiceParameterModel, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*p*/ p) =>
                    {
                        /*var*/ let d = $.$fPer.LCFCD.DataDescriptorFactory.FromObject(p.Property.LCFCD$1$IPropertyDescriptor$DefaultValue ?? p.ValueType.LCFCD$1$ITypeDescriptor$GetDefaultValue(true), p.ValueType, null, p.Name, null, false);
                        return d;
                    }, $kysqna ??= {"r":40536406,"p":[{"n":"p","p":316537}],"n":"","d":2726719,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73017170751)
            
            //--TRIMMABLE-BOUNDARY-START(103081941823)
            /*ValueTask */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081941823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.Stop();
            }
            //--TRIMMABLE-BOUNDARY-END(103081941823)
            
            //--TRIMMABLE-BOUNDARY-START(68722203455)
            /*string */ get OptimizedComponentName()
            {
                return "servicetaskcard";
            }
            //--TRIMMABLE-BOUNDARY-END(68722203455)
            
            //--TRIMMABLE-BOUNDARY-START(107376909119)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376909119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSSV.ServiceViewModel);
                    return true;
                    case "Application":
                    this.Application = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(107376909119)
            
            //--TRIMMABLE-BOUNDARY-START(21477563199)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477563199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "card shadow corner-2 bd pd");
                __builder.OpenElement(2, "h3");
                __builder.AddAttribute$5(3, "class", "mgy-4");
                __builder.AddContent$4(4, this.ViewModel.Model.Name);
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "p");
                __builder.AddAttribute$5(7, "class", "op-7");
                __builder.AddContent$4(8, this.ViewModel.Model.Description);
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n    ");
                __builder.OpenElement(10, "small");
                __builder.AddAttribute$5(11, "class", "cl-error d-block");
                __builder.AddContent$4(12, this.ViewModel.Error);
                __builder.CloseElement();
                if (this.ViewModel.ExitCode !== null)
                {
                    __builder.OpenElement(13, "small");
                    __builder.AddAttribute$5(14, "class", `d-block ${$.$strNN((this.ViewModel.ExitCode === 0 ? "cl-success" : "cl-fatal"))}`);
                    __builder.AddContent$4(15, "Exit with code ");
                    __builder.AddContent$3(16, $.$box(this.ViewModel.ExitCode, $.$$.S.Int32));
                    __builder.CloseElement();
                }
                if (this.ViewModel.Model.IsRunning)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCC$10.Console, 17);
                    __builder.AddComponentReferenceCapture(18, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.Console = $.$cast(__value, $.$hDPm.LCFCCC$10.Console);
                    }, $nhOvvd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":2726719,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 19);
                __builder.AddComponentParameter(20, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 8192/*MenuFeatures.Right*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                __builder.AddComponentParameter(21, "Class", "pdx-0 pdb-0");
                __builder.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 23);
                        __builder2.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 25);
                                __builder3.AddComponentParameter(26, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Warning));
                                __builder3.AddComponentParameter(27, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Clear))));
                                __builder3.AddComponentParameter(28, "title", "Clear logs and status");
                                __builder3.AddAttribute$3(29, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(30, "<i class=\"mdi mdi-delete\"></i>");
                                }), $KMewvg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $audWga ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794});
                        }), $PzBsOi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2726719,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(31, "\r\n    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 32);
                        __builder2.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ __) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 34);
                                __builder3.AddComponentParameter(35, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Message));
                                __builder3.AddComponentParameter(36, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Stop))));
                                __builder3.AddComponentParameter(37, "title", "Abort");
                                __builder3.AddAttribute$3(38, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(39, "<i class=\"mdi mdi-stop\"></i>");
                                }), $gUvNNi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $uinQJk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794});
                        }), $VfZDPh ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2726719,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(40, "\r\n    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 41);
                        __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 43);
                                __builder3.AddComponentParameter(44, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(45, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Run))));
                                __builder3.AddComponentParameter(46, "title", "Run");
                                __builder3.AddAttribute$3(47, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder4) =>
                                {
                                    __builder4.OpenElement(48, "i");
                                    __builder4.AddAttribute$5(49, "class", `mdi ${$.$strNN((!this.ViewModel.Model.IsRunning ? "mdi-run" : "mdi-spin mdi-loading"))}`);
                                    __builder4.CloseElement();
                                }), $iwCpUj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $oNLvWf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794});
                        }), $ifGAua ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2726719,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $KwqdQc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2726719,"h":0,"f":17825794});
                }), $ugozZa ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":2726719,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21477563199)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887628607)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887628607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887628607)
            
            //--TRIMMABLE-BOUNDARY-START(12887628607)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12887628607)
            
            static $h = 2726719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV.ServiceViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111671876415),
    {
      "p": 2923327,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427236159,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786974527,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 2726719,
      "h": 111671876415,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111671876415),
//--TRIMMABLE-BOUNDARY-START(17182595903),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657432383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607105343,
        "f": 83886081
      },
      "n": "Application",
      "d": 2726719,
      "h": 17182595903,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182595903),
//--TRIMMABLE-BOUNDARY-START(30067497791),
    {
      "p": 2842024,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247366975,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197039935,
        "f": 83886082
      },
      "n": "Console",
      "d": 2726719,
      "h": 30067497791,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30067497791),
//--TRIMMABLE-BOUNDARY-START(68722203455),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837301567,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2726719,
      "h": 68722203455,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68722203455)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772530495),
    {
      "r": 181338113,
      "n": "Clear",
      "d": 2726719,
      "h": 25772530495,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772530495),
//--TRIMMABLE-BOUNDARY-START(73017170751),
    {
      "r": 181338113,
      "n": "Run",
      "d": 2726719,
      "h": 73017170751,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73017170751),
//--TRIMMABLE-BOUNDARY-START(103081941823),
    {
      "r": 181338113,
      "n": "Stop",
      "d": 2726719,
      "h": 103081941823,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103081941823),
//--TRIMMABLE-BOUNDARY-START(107376909119),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2726719,
      "h": 107376909119,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376909119),
//--TRIMMABLE-BOUNDARY-START(21477563199),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2726719,
      "h": 21477563199,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21477563199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887628607),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2726719,
      "h": 12887628607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887628607)
  ],
  "h": 2726719
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.Services.ServiceTaskCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}Services${separator}ServiceTaskCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2726719)
        
        

        //--TRIMMABLE-BOUNDARY-START(2988863)
        $asm.$cls(`$WRsM.LCACSS$1.SystemState`, ($self) => class SystemState extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV$1.SystemStateViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51542596415)
            /*SystemStateViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51542596415)
            
            //--TRIMMABLE-BOUNDARY-START(34362727231)
            /*string */ get OptimizedComponentName()
            {
                return "systemstate";
            }
            //--TRIMMABLE-BOUNDARY-END(34362727231)
            
            //--TRIMMABLE-BOUNDARY-START(47247629119)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247629119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSSV$1.SystemStateViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47247629119)
            
            //--TRIMMABLE-BOUNDARY-START(12887890751)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887890751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WRsM._LCACSSS.TypeInference.CreateCascadingValue_0($.$WRsM.LCACSSV$1.SystemStateViewModel, __builder, 0, 1, this.ViewModel, 2, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    $.$WRsM._LCACSSS.TypeInference.CreatePropertySheet_1($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), __builder2, 3, 4, true, 5, this.ViewModel.Statuses, 6, 35184372092928n | 65536n | 8388608n | 2251799813685248n, 7, 2);
                }, $hveDSe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2988863,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12887890751)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592923455)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592923455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592923455)
            
            //--TRIMMABLE-BOUNDARY-START(8592923455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592923455)
            
            static $h = 2988863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSSV$1.SystemStateViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542596415),
    {
      "p": 3382079,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067759935,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952661823,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 2988863,
      "h": 51542596415,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542596415),
//--TRIMMABLE-BOUNDARY-START(34362727231),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477825343,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2988863,
      "h": 34362727231,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362727231)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47247629119),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2988863,
      "h": 47247629119,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247629119),
//--TRIMMABLE-BOUNDARY-START(12887890751),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2988863,
      "h": 12887890751,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887890751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592923455),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2988863,
      "h": 8592923455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592923455)
  ],
  "h": 2988863
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.SystemState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2988863)
        
        

        //--TRIMMABLE-BOUNDARY-START(957247)
        $asm.$cls(`$WRsM.LCACP.App`, ($self) => class App extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACV.ApplicationViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(111670106943)
            /*ApplicationViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(111670106943)
            
            //--TRIMMABLE-BOUNDARY-START(81605335871)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(81605335871)
            
            //--TRIMMABLE-BOUNDARY-START(21475793727)
            /*IEnumerable<IAdministrativeComponentProvider>*/ AdministrativeComponentProviders = null;
            //--TRIMMABLE-BOUNDARY-END(21475793727)
            
            //--TRIMMABLE-BOUNDARY-START(30065728319)
            /*AdminDashboardTableProvider*/ dashBoardTableProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065728319)
            
            //--TRIMMABLE-BOUNDARY-START(73015401279)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015401279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(73015401279)
            
            //--TRIMMABLE-BOUNDARY-START(77310368575)
            /*string */ get OptimizedComponentName()
            {
                return "app";
            }
            //--TRIMMABLE-BOUNDARY-END(77310368575)
            
            //--TRIMMABLE-BOUNDARY-START(68720433983)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720433983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ViewModel = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WRsM.LCACV.ApplicationViewModel, serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
                this.AdministrativeComponentProviders = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$hDPm.LCFCI.IAdministrativeComponentProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720433983)
            
            //--TRIMMABLE-BOUNDARY-START(25770761023)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770761023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, "Admin");
                }), $GuwOIf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 4);
                __builder.AddComponentParameter(5, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.ViewModel));
                __builder.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/ | 128/*ApplicationFeatures.ToolBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(7, "Name", "Admin");
                __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(9, "\r\n        Admin\r\n    ");
                    }, $PLNUNf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                }), $ihbBhd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(11, "<i Class=\"mdi mdi-account\"></i>");
                    }, $KRTHLd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                }), $USjPwb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "LoadingView", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (this.ViewModel.LoadErrorMessage !== null)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCA$1.Alert, 13);
                        __builder2.AddComponentParameter(14, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Fatal));
                        __builder2.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(16, this.ViewModel.LoadErrorMessage);
                        }), $chNhCk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }), $eijKke ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.AddAttribute$3(17, "ToolBarControls", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(18, "menuitem");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$WRsM.LCACSDV.TableViewModel), 19);
                        __builder2.AddComponentParameter(20, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                        __builder2.AddComponentParameter(21, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(22, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableViewModel), $.$mac.MAC.EventCallback.Factory.Create$9($.$WRsM.LCACSDV.TableViewModel, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this.ViewModel, this.ViewModel.UpdateDataTables))));
                        __builder2.AddAttribute$3(23, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(24, "<i class=\"mdi mdi-upload\"></i>");
                        }), $qYSsLb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }, $AWYYXh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                }), $JKXwhl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.AddAttribute$3(25, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 26);
                    __builder2.AddComponentParameter(27, "Name", "");
                    __builder2.AddComponentParameter(28, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("")));
                    __builder2.AddAttribute$3(29, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(30, "DASHBOARD");
                        }, $PCgdzh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $wQPmol ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(31, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(32, "<i class=\"mdi mdi-database\"></i>");
                        }, $Vnkwyd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $yQkrkj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                        }, $eDfchf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $FxGzgk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    let $i1 = 0;
                    let $arr1 = this.ViewModel.DataTables;
                    while ($i1 < $arr1.length)
                    {
                        let _dataTable = $arr1[$i1++];
                        /*var*/ let dataTable = _dataTable;
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 34);
                        __builder2.AddComponentParameter(35, "Class", "pd");
                        __builder2.AddComponentParameter(36, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, dataTable.TableDefinition.Name));
                        __builder2.AddComponentParameter(37, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`${$.$strNN(dataTable.TableDefinition.Name)}/${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}`)));
                        __builder2.AddAttribute$3(38, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(39, dataTable.TableDefinition.Name);
                            }, $Bstkvi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                        }), $oMkwlh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(40, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(41, "<i class=\"mdi mdi-database\"></i>");
                            }, $nrkChl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                        }), $GFFLCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                            }, $ixSZNj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                        }), $cSnDTk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(43, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACSD.DataTableManager, 44);
                            __builder3.AddComponentParameter(45, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.DataTablesViewModel, dataTable));
                            __builder3.CloseComponent();
                        }), $nnRZfj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 46);
                    __builder2.AddComponentParameter(47, "Class", "pd pos-rel");
                    __builder2.AddComponentParameter(48, "Name", "Newsletter");
                    __builder2.AddComponentParameter(49, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Newsletter"))));
                    __builder2.AddAttribute$3(50, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$4(51, "NEWSLETTER");
                        }, $htNdUc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $QMUOqg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(52, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(53, "<i class=\"mdi mdi-newspaper\"></i>");
                        }, $Nofgxc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $iRRFJb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACSN.Newsletter, 55);
                            __builder3.CloseComponent();
                        }, $UdxVAi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $CYAWwg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(56, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 57);
                    __builder2.AddComponentParameter(58, "Class", "pd pos-rel");
                    __builder2.AddComponentParameter(59, "Name", "Contacts");
                    __builder2.AddComponentParameter(60, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Contacts"))));
                    __builder2.AddAttribute$3(61, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$4(62, "CONTACTS");
                        }, $wgjroi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $uXOGed ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(63, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(64, "<i class=\"mdi mdi-contacts\"></i>");
                        }, $idiaXd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $RcPtIi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(65, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACS$1.Contacts, 66);
                            __builder3.AddComponentParameter(67, "DashBoardTableProvider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACV.AdminDashboardTableProvider, this.dashBoardTableProvider));
                            __builder3.CloseComponent();
                        }, $suTxhf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $DADVbl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(68, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 69);
                    __builder2.AddComponentParameter(70, "Class", "pd");
                    __builder2.AddComponentParameter(71, "Name", "Services");
                    __builder2.AddComponentParameter(72, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Services"))));
                    __builder2.AddAttribute$3(73, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(74, "SERVICES");
                        }, $etHEAe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $kgCxwi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(75, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(76, "<i class=\"mdi mdi-engine\"></i>");
                        }, $kgMSAe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $meyIYj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(77, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACSS.ServiceTasksManager, 78);
                            __builder3.AddComponentParameter(79, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSSV.ServicesViewModel, this.ViewModel.Services));
                            __builder3.CloseComponent();
                        }, $qCfsld ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $IgEnbh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(80, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 81);
                    __builder2.AddComponentParameter(82, "Class", "pd");
                    __builder2.AddComponentParameter(83, "Name", "Statuses");
                    __builder2.AddComponentParameter(84, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Statuses"))));
                    __builder2.AddAttribute$3(85, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(86, "STATUSES");
                        }, $TflwOe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $muJrkk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(87, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(88, "<i class=\"mdi mdi-chart-bar\"></i>");
                        }, $oUZHDe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $bHUhYg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(89, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$WRsM.LCACSS$1.SystemStates, 90);
                            __builder3.AddComponentParameter(91, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSSV$1.SystemStatesViewModel, this.ViewModel.States));
                            __builder3.CloseComponent();
                        }, $usbkZd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                    }), $dbrjhh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(92, "\r\n        ");
                    __builder2.OpenComponent$1($.$WRsM.LCACSP.GlobalSettingsPage, 93);
                    __builder2.CloseComponent();
                    let $en2 = this.AdministrativeComponentProviders.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let _adminProvider = $en2.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let adminProvider = _adminProvider;
                            __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 94);
                            __builder2.AddComponentParameter(95, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, adminProvider.LCFCI$IAdministrativeComponentProvider$Title));
                            __builder2.AddComponentParameter(96, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`${$.$strNN(adminProvider.LCFCI$IAdministrativeComponentProvider$Title)}/${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}`)));
                            __builder2.AddAttribute$3(97, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                                {
                                    __builder3.AddContent$4(98, $.$$.S.String.ToUpper.call(adminProvider.LCFCI$IAdministrativeComponentProvider$Title));
                                }, $aGBWLh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                            }), $PBQIKb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(99, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(100, "i");
                                    __builder3.AddAttribute$5(101, "class", adminProvider.LCFCI$IAdministrativeComponentProvider$Icon);
                                    __builder3.CloseElement();
                                }, $IZBLca ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                            }), $hLnuUd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(102, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$1(103, adminProvider.LCFCI$IAdministrativeComponentProvider$Content);
                                }, $ymqGKf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                            }), $rmqVic ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(104, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                if (adminProvider.LCFCI$IAdministrativeComponentProvider$Pages !== null)
                                {
                                    let $en3 = adminProvider.LCFCI$IAdministrativeComponentProvider$Pages.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en3.SC$1$IEnumerator$MoveNext())
                                    {
                                        let ppage = $en3.SCG$IEnumerator$$$Current;
                                        {
                                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 105);
                                            __builder3.AddComponentParameter(106, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, ppage.LCFCI$IAdministrativePage$Title));
                                            __builder3.AddComponentParameter(107, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(ppage.LCFCI$IAdministrativePage$Title)));
                                            __builder3.AddAttribute$3(108, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    __builder4.AddContent$4(109, ppage.LCFCI$IAdministrativePage$Title);
                                                }, $rTomud ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                                            }), $OlArXd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                                            __builder3.AddAttribute$3(110, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    __builder4.OpenElement(111, "i");
                                                    __builder4.AddAttribute$5(112, "class", ppage.LCFCI$IAdministrativePage$Icon);
                                                    __builder4.CloseElement();
                                                }, $hlMHBe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                                            }), $XgixPc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                                            __builder3.AddAttribute$3(113, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    __builder4.AddContent$1(114, ppage.LCFCI$IAdministrativePage$Content);
                                                }, $FzEGOc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":957247,"h":0,"f":17825794});
                                            }), $Lmikpj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":957247,"h":0,"f":17825794}));
                                            __builder3.CloseComponent();
                                        }
                                    }
                                }
                            }), $oQVEMd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                            __builder2.SetKey(adminProvider);
                            __builder2.CloseComponent();
                        }
                    }
                }), $ISAEuk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":957247,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770761023)
            
            //--TRIMMABLE-BOUNDARY-START(1022783)
            static $___PrivateComponentRenderModeAttribute;
            static get __PrivateComponentRenderModeAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1022783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$WRsM.LCACP.App;
                return $cls.$___PrivateComponentRenderModeAttribute ??= $asm.$ncls(`$WRsM.LCACP.App.__PrivateComponentRenderModeAttribute`, ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.MAC.RenderModeAttribute
                {
                    //--TRIMMABLE-BOUNDARY-START(30065793855)
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get ModeImpl()
                    {
                        return $.$macw.MACW.RenderMode.InteractiveServer;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065793855)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770826559)
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get Mode()
                    {
                        return $.$WRsM.LCACP.App.__PrivateComponentRenderModeAttribute.ModeImpl;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770826559)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295990079)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295990079);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295990079)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295990079)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295990079)
                    
                    static $h = 1022783;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mac.MAC.RenderModeAttribute; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065793855),
    {
      "p": 2883699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475859263,
        "f": 50331682
      },
      "n": "ModeImpl",
      "d": 1022783,
      "h": 30065793855,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(30065793855),
//--TRIMMABLE-BOUNDARY-START(25770826559),
    {
      "p": 2883699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885924671,
        "f": 50364417
      },
      "n": "Mode",
      "d": 1022783,
      "h": 25770826559,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770826559)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295990079),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1022783,
      "h": 4295990079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295990079)
  ],
  "d": 957247,
  "h": 1022783
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Pages.App+__PrivateComponentRenderModeAttribute`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Pages${separator}App${separator}__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___PrivateComponentRenderModeAttribute = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1022783)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180826431)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180826431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180826431)
            
            //--TRIMMABLE-BOUNDARY-START(17180826431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17180826431)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111670106943)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(111670106943)
                
                //--TRIMMABLE-BOUNDARY-START(81605335871)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(81605335871)
                
                //--TRIMMABLE-BOUNDARY-START(21475793727)
                this.AdministrativeComponentProviders = null;
                //--TRIMMABLE-BOUNDARY-END(21475793727)
                
                //--TRIMMABLE-BOUNDARY-START(30065728319)
                this.dashBoardTableProvider = new $.$WRsM.LCACV.AdminDashboardTableProvider().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(30065728319)
                
            }
            static $h = 957247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACV.ApplicationViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670106943),
    {
      "p": 3644223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425466687,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375139647,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 957247,
      "h": 111670106943,
      "f": 2129921,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670106943),
//--TRIMMABLE-BOUNDARY-START(81605335871),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835532095,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785205055,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 957247,
      "h": 81605335871,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605335871),
//--TRIMMABLE-BOUNDARY-START(21475793727),
    {
      "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCI.IAdministrativeComponentProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655662911,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195270463,
        "f": 83886081
      },
      "n": "AdministrativeComponentProviders",
      "d": 957247,
      "h": 21475793727,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475793727),
//--TRIMMABLE-BOUNDARY-START(77310368575),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245597503,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 957247,
      "h": 77310368575,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310368575)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015401279),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 957247,
      "h": 73015401279,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73015401279),
//--TRIMMABLE-BOUNDARY-START(68720433983),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 957247,
      "h": 68720433983,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720433983),
//--TRIMMABLE-BOUNDARY-START(25770761023),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 957247,
      "h": 25770761023,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770761023)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065728319),
    {
      "t": 3578687,
      "n": "dashBoardTableProvider",
      "d": 957247,
      "h": 30065728319,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065728319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180826431),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 957247,
      "h": 17180826431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180826431)
  ],
  "h": 957247,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": $.$hDPm.LCFCL.NoLayout$$($.$macw.MACW.InteractiveServerRenderMode).$h,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/{*PageRoute}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1022783,
      "c": 4295990079
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$WRsM.LCACP.App.__PrivateComponentRenderModeAttribute ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Pages.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Pages${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(957247)
        
        

        //--TRIMMABLE-BOUNDARY-START(3185471)
        $asm.$cls(`$WRsM.LCACSS$1.SystemStatesTypeDescriptor`, ($self) => class SystemStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACSS$1.SystemStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298152767)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298152767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WRsM.LCACSS$1.SystemStatesTypeDescriptor.GenerateProperties($.$WRsM.LCACSS$1.SystemStates, this, factory);
                    }, $ShmGug ??= {"r":65537,"n":"","d":3185471,"h":0,"f":17825794}), 0, "SystemStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\Shared_SystemStates_SystemStates_LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStatesTypeDescriptorBuilder.g.cs", "SystemStatesTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298152767)
            
            //--TRIMMABLE-BOUNDARY-START(12888087359)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888087359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ViewModel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACSS$1.SystemStates.$type, $.$discardRef(), "ViewModel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ViewModel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$WRsM.LCACSSV$1.SystemStatesViewModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ViewModel";
                        $i1.DelaredOn = "LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStates";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSS$1.SystemStatesTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$WRsM.LCACSSV$1.SystemStatesViewModel, ($.$cast(target, $.$WRsM.LCACSS$1.SystemStates)).ViewModel);
                        }, $CNISXh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3185471,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSS$1.SystemStatesTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ViewModel = value.AsReference($.$WRsM.LCACSSV$1.SystemStatesViewModel);
                        }, $AkvrDj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3185471,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888087359)
            
            //--TRIMMABLE-BOUNDARY-START(17183054655)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183054655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ViewModel = _target.ViewModel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ViewModel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$WRsM.LCACSSV$1.SystemStatesViewModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ViewModel, ($v) => _ViewModel = $v, $.$WRsM.LCACSSV$1.SystemStatesViewModel)))
                    {
                        _target.ViewModel = _ViewModel;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183054655)
            
            //--TRIMMABLE-BOUNDARY-START(8593120063)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593120063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WRsM.LCACSS$1.SystemStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WRsM.LCACSS$1.SystemStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSS$1.SystemStates)))
                {
                    /*var*/ let result = $.$WRsM.LCACSS$1.SystemStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSS$1.SystemStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WRsM.LCACSS$1.SystemStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSS$1.SystemStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593120063)
            
            static $h = 3185471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACSS$1.SystemStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888087359),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3185471,
      "h": 12888087359,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888087359),
//--TRIMMABLE-BOUNDARY-START(17183054655),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3054399,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3185471,
      "h": 17183054655,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183054655),
//--TRIMMABLE-BOUNDARY-START(8593120063),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3054399,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3185471,
      "h": 8593120063,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593120063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298152767),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3185471,
      "h": 4298152767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298152767)
  ],
  "h": 3185471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WRsM.LCACSS$1.SystemStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.SystemStates.SystemStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}SystemStates${separator}SystemStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3185471)
        
        

        //--TRIMMABLE-BOUNDARY-START(2071359)
        $asm.$cls(`$WRsM.LCACSDV.TableRowModel`, ($self) => class TableRowModel extends $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor)
        {
            //--TRIMMABLE-BOUNDARY-START(12886973247)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886973247);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886973247)
            
            //--TRIMMABLE-BOUNDARY-START(17181940543)
            $ctor$11(/*TableRowType*/ type, /*object?*/ id, /*IDictionary<string, IObservableDataDescriptor>*/ columnValues)
            {
                super.$ctor$3(columnValues);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181940543);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.TableType = type;
                    this.id = id;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181940543)
            
            //--TRIMMABLE-BOUNDARY-START(73016515391)
            /*TableRowState*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(73016515391)
            
            //--TRIMMABLE-BOUNDARY-START(81606449983)
            /*TableRowType*/ TableType = null;
            //--TRIMMABLE-BOUNDARY-END(81606449983)
            
            //--TRIMMABLE-BOUNDARY-START(55836646207)
            /*object?*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(55836646207)
            
            //--TRIMMABLE-BOUNDARY-START(60131613503)
            /*object? */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066842431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _id = this.id ?? ($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this, "Id")?.LCFCD$IValueProvider$Value ?? null);
                let did;
                if ($.$is(_id, $.$fPer.LCFCD.DataId, { set $v($v){ did = $v; } }) && did.Id !== null)
                {
                    return did.Id;
                }
                return _id;
            }
            //--TRIMMABLE-BOUNDARY-END(60131613503)
            
            //--TRIMMABLE-BOUNDARY-START(51541678911)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541678911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.id !== null)
                {
                    return $.$dspc(this.id, $.$$.S.Object, ($t) => $t.GetHashCode);
                }
                return $.$$.S.Object.GetHashCode.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(51541678911)
            
            //--TRIMMABLE-BOUNDARY-START(85901417279)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901417279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.id !== null)
                {
                    return $.$dspc(this.id, $.$$.S.Object, ($t) => $t.ToString);
                }
                return $.$$.S.Object.ToString.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(85901417279)
            
            //--TRIMMABLE-BOUNDARY-START(21476907839)
            /*bool */ Equals$2(/*TableRowModel?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476907839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                return ((__ca1__ = this.Id) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.Equals$1, (other?.Id ?? null)) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(21476907839)
            
            //--TRIMMABLE-BOUNDARY-START(77311482687)
            /*IEnumerator<IObservableDataDescriptor> */ SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311482687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(77311482687)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.Equals(LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel?)
            S$IEquatable$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12886973247)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(12886973247)
            
            static $h = 2071359;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016515391),
    {
      "p": 2333503,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656777023,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721548095,
        "f": 83886081
      },
      "n": "State",
      "d": 2071359,
      "h": 73016515391,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016515391),
//--TRIMMABLE-BOUNDARY-START(81606449983),
    {
      "p": 644217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246711615,
        "f": 50331649
      },
      "n": "TableType",
      "d": 2071359,
      "h": 81606449983,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606449983),
//--TRIMMABLE-BOUNDARY-START(60131613503),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066842431,
        "f": 50331649
      },
      "n": "Id",
      "d": 2071359,
      "h": 60131613503,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131613503)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541678911),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2071359,
      "h": 51541678911,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541678911),
//--TRIMMABLE-BOUNDARY-START(85901417279),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2071359,
      "h": 85901417279,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901417279),
//--TRIMMABLE-BOUNDARY-START(21476907839),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2071359
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2071359,
      "h": 21476907839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476907839)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836646207),
    {
      "t": 131073,
      "n": "id",
      "d": 2071359,
      "h": 55836646207,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55836646207)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886973247),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2071359,
      "h": 12886973247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886973247),
//--TRIMMABLE-BOUNDARY-START(17181940543),
    {
      "p": [
        {
          "n": "type",
          "p": 644217
        },
        {
          "n": "id",
          "p": 131073
        },
        {
          "n": "columnValues",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 2071359,
      "h": 17181940543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181940543)
  ],
  "h": 2071359
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor)), $.$$.SC$1.IDictionary, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor)), $.$$.SRS.ISerializable, $.$$.SRS.IDeserializationCallback, $.$$.S.IEquatable$$($.$WRsM.LCACSDV.TableRowModel), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2071359)
        
        

        //--TRIMMABLE-BOUNDARY-START(2530111)
        $asm.$cls(`$WRsM.LCACSDV.TableViewModel`, ($self) => class TableViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(42952203071)
            $ctor$3(/*ApplicationViewModel*/ app, /*DataTablesViewModel*/ dataTable, /*TableRowType*/ tableModel, /*int*/ depth, /*TableRowColumnViewModel?*/ parentColumn)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952203071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.App = $.$firstOf(app, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("app") });
                    this.DataTable = $.$firstOf(dataTable, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("dataTable") });
                    this.TableRowType = $.$firstOf(tableModel, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("tableModel") });
                    this.ParentColumn = parentColumn;
                    if (parentColumn !== null)
                    {
                        parentColumn.Row.Table.Children.Add(this);
                    }
                    this.Depth = depth;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952203071)
            
            //--TRIMMABLE-BOUNDARY-START(115966647103)
            /*int*/ Depth = 0;
            //--TRIMMABLE-BOUNDARY-END(115966647103)
            
            //--TRIMMABLE-BOUNDARY-START(369369717567)
            /*TableRowColumnViewModel?*/ ParentColumn = null;
            //--TRIMMABLE-BOUNDARY-END(369369717567)
            
            //--TRIMMABLE-BOUNDARY-START(55837104959)
            /*ApplicationViewModel*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(55837104959)
            
            //--TRIMMABLE-BOUNDARY-START(60132072255)
            /*System.Collections.Generic.List<TableViewModel>*/ Children = null;
            //--TRIMMABLE-BOUNDARY-END(60132072255)
            
            //--TRIMMABLE-BOUNDARY-START(47247170367)
            /*IEnumerable<TableRowModel> */ get AddedRows()
            {
                return $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableRowModel, this.ViewData, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.S.Boolean))().$ctor(this,  (/**/ v) =>
                {
                    return ((v.State & (1/*TableRowState.Added*/)) == (1/*TableRowState.Added*/));
                }, $Jlbbrd ??= {"r":262145,"p":[{"n":"v","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47247170367)
            
            //--TRIMMABLE-BOUNDARY-START(395139521343)
            /*IEnumerable<TableRowModel> */ get RemovedRows()
            {
                return $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableRowModel, this.ViewData, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                {
                    return ((v.State & (2/*TableRowState.Removed*/)) == (2/*TableRowState.Removed*/));
                }, $rQbgVe ??= {"r":262145,"p":[{"n":"v","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(395139521343)
            
            //--TRIMMABLE-BOUNDARY-START(107376712511)
            /*IEnumerable<TableRowModel> */ get DeletedRows()
            {
                return $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableRowModel, this.ViewData, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                {
                    return ((v.State & (8/*TableRowState.Deleted*/)) == (8/*TableRowState.Deleted*/));
                }, $uTdWGf ??= {"r":262145,"p":[{"n":"v","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(107376712511)
            
            //--TRIMMABLE-BOUNDARY-START(476743899967)
            /*IEnumerable<TableRowModel> */ get UpdatedRows()
            {
                return $.$sl.SL.Enumerable.Where($.$WRsM.LCACSDV.TableRowModel, this.ViewData, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                {
                    return ((v.State & (4/*TableRowState.Updated*/)) == (4/*TableRowState.Updated*/));
                }, $uThAyi ??= {"r":262145,"p":[{"n":"v","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(476743899967)
            
            //--TRIMMABLE-BOUNDARY-START(365074750271)
            /*int*/ page = 0;
            //--TRIMMABLE-BOUNDARY-END(365074750271)
            
            //--TRIMMABLE-BOUNDARY-START(77311941439)
            /*int*/ count = 0;
            //--TRIMMABLE-BOUNDARY-END(77311941439)
            
            //--TRIMMABLE-BOUNDARY-START(438089194303)
            /*Sorting*/ Sort;
            //--TRIMMABLE-BOUNDARY-END(438089194303)
            
            //--TRIMMABLE-BOUNDARY-START(450974096191)
            /*void */ ToggleSort(/*Common.Models.TablePropertyColumn*/ column)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450974096191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Sort.Field !== column.Name)
                {
                    this.Sort = (() =>
                    {
                        //new $.$fPer.LCFCD.Sorting()
                        const $t1 = $.$fPer.LCFCD.Sorting;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Field = column.Name;
                        $i1.Order = 1/*SortingOrder.Ascending*/;
                        return $i1;
                    })();
                }
                else 
                {
                    this.Sort = (() =>
                    {
                        //new $.$fPer.LCFCD.Sorting()
                        const $t2 = $.$fPer.LCFCD.Sorting;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Field = column.Name;
                        $i2.Order = this.Sort.Order === 0/*SortingOrder.Default*/ ? 1/*SortingOrder.Ascending*/ : this.Sort.Order === 1/*SortingOrder.Ascending*/ ? 2/*SortingOrder.Descending*/ : 0/*SortingOrder.Default*/;
                        return $i2;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450974096191)
            
            //--TRIMMABLE-BOUNDARY-START(382254619455)
            /*Task<WireTransportManyModel<TableRowModel>> *//*async*/  ReadMany(/*DataFilter?*/ filter, /*TableRowModel?*/ _)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)), $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel), async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(382254619455);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = this.Load$2($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel), new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel))))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)), $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel), async ($asnycContext) => 
                        {
                            /*int*/ let totalCount = 0;
                            let adminService = null;
                            try
                            {
                                adminService = this.App.Server.LCFCR$IServerRemoteService$GetRemoteService($.$ajwi.LCACS.IAdminRemoteService, null);
                                /*System.Collections.Generic.List<TableRowModel>*/ let rows = new ($.$$.SCG.List$$($.$WRsM.LCACSDV.TableRowModel))().$ctor$1();
                                if (this.DataSource !== null)
                                {
                                    let $t4, $r4;
                                    rows = $.$sl.SL.Enumerable.ToList($.$WRsM.LCACSDV.TableRowModel, (($t4 = this.DataSource.Invoke(0, 50), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)))));
                                }
                                else 
                                {
                                    let $t5, $r5;
                                    /*var*/ let response = ($t5 = adminService.LCFCS$3$IServiceProxy$$$Service.LCACS$IAdminRemoteService$ReadTable(this.DataTable.ProviderName, (() =>
                                    {
                                        //new $.$Iaui.LCFCM.ReadManyRequestModel()
                                        const $t6 = $.$Iaui.LCFCM.ReadManyRequestModel;
                                        const $i6 = new $t6();
                                        $i6.$ctor$3();
                                        $i6.Target = new $.$fPer.LCFCD.DataId().$ctor$3(this.ParentColumn !== null ? ($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.ParentColumn.Row.Data, "Id")?.LCFCD$IValueProvider$Value ?? null) : null, this.ParentColumn !== null ? $.$$.System.Array.$ReadT1.call(this.ParentColumn.Row.Table.TableRowType.Aliases, 0) : $.$$.System.Array.$ReadT1.call(this.TableRowType.Aliases, 0));
                                        $i6.ModelType = 1/*ModelType.Row*/;
                                        $i6.Property = (this.ParentColumn?.Column.Name ?? null);
                                        $i6.Filter = (filter?.Sorting.Order ?? null) === 0/*SortingOrder.Default*/ ? $.$with(filter, ($clone) =>
                                        {
                                            $clone.Sorting = new $.$fPer.LCFCD.Sorting().$ctor$3("DateCreated", 2/*SortingOrder.Descending*/);
                                        }) : filter;
                                        $i6.Sorting = $.$clone(this.Sort);
                                        return $i6;
                                    })()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                    if (response.Success)
                                    {
                                        rows = $.$sl.SL.Enumerable.ToList($.$WRsM.LCACSDV.TableRowModel, $.$sl.SL.Enumerable.Select$1($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), $.$WRsM.LCACSDV.TableRowModel, response.Data, new ($.$$.S.Func$$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), $.$WRsM.LCACSDV.TableRowModel))().$ctor(this,  (/*data*/ data) =>
                                        {
                                            /*var*/ let id = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$$.S.Object, data, "Id");
                                            return new $.$WRsM.LCACSDV.TableRowModel().$ctor$11(this.TableRowType, id, $.$sl.SL.Enumerable.ToDictionary$5($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String))().$ctor(this,  (/*column*/ column) =>
                                            {
                                                return column.Name;
                                            }, $IAsgdi ??= {"r":1310721,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/**/ column) =>
                                            {
                                                return $.$fPer.LCFCD.DataDescriptorFactory.FromObject($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$$.S.Object, data, column.Name), column.ValueType, column, column.Name, null, false);
                                            }, $KLTadk ??= {"r":40536406,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794})));
                                        }, $VaUNug ??= {"r":2071359,"p":[{"n":"data","p":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":2530111,"h":0,"f":17825794})));
                                        totalCount = response.TotalCount;
                                    }
                                }
                                if (this.ParentColumn !== null)
                                {
                                    /*var*/ let navigationIds = $.$as(($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.ParentColumn.Row.Data, $.$strNN(this.ParentColumn.Column.Name) + "Id")?.LCFCD$IValueProvider$Value ?? null), $.$$.SCG.List$$($.$$.S.Object));
                                    if (navigationIds === null)
                                    {
                                        navigationIds = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                                        $.$fPer.LCFCP$1.PropertyExtension.SetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.ParentColumn.Row.Data, $.$strNN(this.ParentColumn.Column.Name) + "Id", $.$fPer.LCFCD.DataDescriptorFactory.FromData($.$$.SCG.List$$($.$$.S.Object), navigationIds, null, null, $.$strNN(this.ParentColumn.Column.Name) + "Id", null, false));
                                    }
                                }
                                let $en7 = rows.GetEnumerator();
                                while ($en7.MoveNext())
                                {
                                    let row = $en7.Current;
                                    {
                                        let $en8 = this.PrimitiveColumns.SCG$IEnumerable$$$GetEnumerator();
                                        while ($en8.SC$1$IEnumerator$MoveNext())
                                        {
                                            let column = $en8.SCG$IEnumerator$$$Current;
                                            {
                                                if (!row.ContainsKey(column.Name))
                                                {
                                                    $.$fPer.LCFCP$1.PropertyExtension.SetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, row, column.Name, $.$fPer.LCFCD.DataDescriptorFactory.FromObject(null, column.ValueType, null, column.Name, null, false));
                                                }
                                            }
                                        }
                                    }
                                }
                                this.page = filter.DataPage;
                                this.count = filter.DataCount;
                                return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                                {
                                    //new $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)()
                                    const $t9 = $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel);
                                    const $i9 = new $t9();
                                    $i9.$ctor$2();
                                    $i9.Success = true;
                                    $i9.Data = rows;
                                    $i9.TotalCount = totalCount;
                                    return $i9;
                                })());
                            }
                            finally
                            {
                                adminService?.S$IDisposable$Dispose();
                            }
                        });
                    }, $kmYKni ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)).$h,"n":"","d":2530111,"h":0,"f":17829890}), true, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(382254619455)
            
            //--TRIMMABLE-BOUNDARY-START(386549586751)
            /*void */ Reload$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549586751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en10 = this.ViewData.SCG$IEnumerable$$$GetEnumerator();
                while ($en10.SC$1$IEnumerator$MoveNext())
                {
                    let v = $en10.SCG$IEnumerator$$$Current;
                    {
                        v.State = 0/*TableRowState.None*/;
                    }
                }
                this.detailedRows.SCG$ICollection$$$Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(386549586751)
            
            //--TRIMMABLE-BOUNDARY-START(347894881087)
            /*bool */ get IsRootTable()
            {
                return this.ParentColumn === null;
            }
            //--TRIMMABLE-BOUNDARY-END(347894881087)
            
            //--TRIMMABLE-BOUNDARY-START(68722006847)
            /*IEnumerable<Common.Models.TablePropertyColumn> */ get Columns()
            {
                return $.$ajwi.LCACM.TableDefinition.Sort(this.DataTable.TableDefinition.GetPropertiesDeep(this.TableRowType));
            }
            //--TRIMMABLE-BOUNDARY-END(68722006847)
            
            //--TRIMMABLE-BOUNDARY-START(377959652159)
            /*IEnumerable<Common.Models.TablePropertyColumn> */ get PrimitiveColumns()
            {
                return $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*column*/ column) =>
                {
                    return $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 134217728/*DataType.Array*/ && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 21/*DataType.Class*/;
                }, $mBsTnf ??= {"r":262145,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(377959652159)
            
            //--TRIMMABLE-BOUNDARY-START(133146516287)
            /*IEnumerable<Common.Models.TablePropertyColumn> */ get FormColumns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930764095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca1__;
                    return !(((__ca1__ = e.Schema) !== null ? ((__ca1__.Exclude & (1/*SchemaType.Form*/)) == (1/*SchemaType.Form*/)) : false));
                }, $cnZyId ??= {"r":262145,"p":[{"n":"e","p":578681}],"n":"","d":2530111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*column*/ column) =>
                {
                    return column.Name !== "DateCreated" && ((column.Accessibility & (4/*PropertyAccessibility.Write*/)) == (4/*PropertyAccessibility.Write*/)) && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 134217728/*DataType.Array*/ && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 21/*DataType.Class*/;
                }, $Ljljte ??= {"r":262145,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(133146516287)
            
            //--TRIMMABLE-BOUNDARY-START(433794227007)
            /*IEnumerable<Common.Models.TablePropertyColumn> */ get SimpleColumns()
            {
                return $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*column*/ column) =>
                {
                    return $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 134217728/*DataType.Array*/ && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 21/*DataType.Class*/ && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 28/*DataType.Guid*/ && $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) !== 29/*DataType.Stream*/;
                }, $ojFWOg ??= {"r":262145,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(433794227007)
            
            //--TRIMMABLE-BOUNDARY-START(343599913791)
            /*bool */ get IsEntity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110633279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Any($.$ajwi.LCACM.TableRowType, this.DataTable.TableDefinition.BaseClassesOf(this.TableRowType), new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.S.Boolean))().$ctor(this,  (/*tb*/ tb) =>
                {
                    return $.$$.S.String.Equals$5.call(tb.Name, "Entity");
                }, $xmtXih ??= {"r":262145,"p":[{"n":"tb","p":644217}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(343599913791)
            
            //--TRIMMABLE-BOUNDARY-START(51542137663)
            /*void */ AddParentNavigationId(/*IEnumerable<TableRowModel>*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542137663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let desc = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, this.ParentColumn.Row.Data, $.$strNN(this.ParentColumn.Column.Name) + "Id");
                /*var*/ let parentNavigationIds = $.$cast(desc.LCFCD$IValueProvider$Value, $.$$.SCG.List$$($.$$.S.Object));
                /*var*/ let idColumns = $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.IsPrimaryKey;
                }, $nifHYg ??= {"r":262145,"p":[{"n":"c","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
                let $en11 = models.SCG$IEnumerable$$$GetEnumerator();
                while ($en11.SC$1$IEnumerator$MoveNext())
                {
                    let model = $en11.SCG$IEnumerator$$$Current;
                    {
                        if ($.$sl.SL.Enumerable.Count$1($.$ajwi.LCACM.TablePropertyColumn, idColumns) === 1)
                        {
                            /*var*/ let id = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, model, $.$sl.SL.Enumerable.Single$1($.$ajwi.LCACM.TablePropertyColumn, idColumns).Name).LCFCD$IValueProvider$Value;
                            if (!parentNavigationIds.Contains(id))
                            {
                                parentNavigationIds.Add(id);
                            }
                        }
                        else 
                        {
                            /*var*/ let id = $.$sl.SL.Enumerable.ToList($.$$.S.Object, $.$sl.SL.Enumerable.Select$1($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Object, idColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Object))().$ctor(this,  (/*c*/ c) =>
                            {
                                return $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, model, c.Name).LCFCD$IValueProvider$Value;
                            }, $BrrIKh ??= {"r":131073,"p":[{"n":"c","p":578681}],"n":"","d":2530111,"h":0,"f":17825794})));
                            if (!parentNavigationIds.Contains(id))
                            {
                                parentNavigationIds.Add(id);
                            }
                        }
                    }
                }
                if (!((this.ParentColumn.Row.Data.State & (1/*TableRowState.Added*/)) == (1/*TableRowState.Added*/)) && !((this.ParentColumn.Row.Data.State & (4/*TableRowState.Updated*/)) == (4/*TableRowState.Updated*/)))
                {
                    this.ParentColumn.Row.Data.State |= 4/*TableRowState.Updated*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542137663)
            
            //--TRIMMABLE-BOUNDARY-START(81606908735)
            /*Task<WireTransportManyModel<TableRowModel>> */ Create(/*DataFilter*/ filter, /*params TableRowModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606908735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i12 = 0;
                let $arr12 = models;
                while ($i12 < $arr12.length)
                {
                    let model = $arr12[$i12++];
                    /*var*/ let others = $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*column*/ column) =>
                    {
                        return !model.ContainsKey(column.Name);
                    }, $qkaeeg ??= {"r":262145,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
                    let $en13 = others.SCG$IEnumerable$$$GetEnumerator();
                    while ($en13.SC$1$IEnumerator$MoveNext())
                    {
                        let column = $en13.SCG$IEnumerator$$$Current;
                        {
                            model.set_Item(column.Name, $.$fPer.LCFCD.DataDescriptorFactory.FromObject(column.ResolveDefaultValue, column.ValueType, null, column.Name, null, false));
                        }
                    }
                }
                let $i14 = 0;
                let $arr14 = models;
                while ($i14 < $arr14.length)
                {
                    let m = $arr14[$i14++];
                    m.State |= 1/*TableRowState.Added*/;
                }
                if (this.ParentColumn !== null)
                {
                    this.AddParentNavigationId(models);
                }
                return $.$$.STT.Task.FromResult($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel), (() =>
                {
                    //new $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)()
                    const $t15 = $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel);
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Success = true;
                    $i15.Data = models;
                    return $i15;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(81606908735)
            
            //--TRIMMABLE-BOUNDARY-START(352189848383)
            /*void */ MarkDirty(/*TableRowModel*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189848383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!((data.State & (4/*TableRowState.Updated*/)) == (4/*TableRowState.Updated*/)) && !((data.State & (1/*TableRowState.Added*/)) == (1/*TableRowState.Added*/)))
                {
                    data.State |= 4/*TableRowState.Updated*/;
                    _ = (this.DataTableUI?.GetContext(data)?.StateChanged(false) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352189848383)
            
            //--TRIMMABLE-BOUNDARY-START(468153965375)
            /*Task<WireTransportManyModel<TableRowModel>> */ Update(/*DataFilter*/ filter, /*params TableRowModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153965375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i16 = 0;
                let $arr16 = models;
                while ($i16 < $arr16.length)
                {
                    let model = $arr16[$i16++];
                    if (!((model.State & (4/*TableRowState.Updated*/)) == (4/*TableRowState.Updated*/)) && !((model.State & (1/*TableRowState.Added*/)) == (1/*TableRowState.Added*/)))
                    {
                        model.State |= 4/*TableRowState.Updated*/;
                    }
                }
                return $.$$.STT.Task.FromResult($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel), (() =>
                {
                    //new $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)()
                    const $t17 = $.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel);
                    const $i17 = new $t17();
                    $i17.$ctor$2();
                    return $i17;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(468153965375)
            
            //--TRIMMABLE-BOUNDARY-START(390844554047)
            /*Task */ Remove(/*TableRowModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844554047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Delete(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableRowModel), [model], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(390844554047)
            
            //--TRIMMABLE-BOUNDARY-START(111671679807)
            /*TaskCompletionSource?*/ deleting = null;
            //--TRIMMABLE-BOUNDARY-END(111671679807)
            
            //--TRIMMABLE-BOUNDARY-START(103081745215)
            /*Task<WireTransportManyModel<bool>> *//*async*/  Delete(/*DataFilter*/ filter, /*params TableRowModel[]*/ models)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), async ($asnycContext) => 
                {
                    let $t20, $r20;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081745215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.IsRootTable || ((this.ParentColumn?.Column?.IsOneToManyRelationship ?? null) ?? false))
                    {
                        let $i18 = 0;
                        let $arr18 = models;
                        while ($i18 < $arr18.length)
                        {
                            let model = $arr18[$i18++];
                            model.State |= 8/*TableRowState.Deleted*/;
                        }
                    }
                    else 
                    {
                        let $i19 = 0;
                        let $arr19 = models;
                        while ($i19 < $arr19.length)
                        {
                            let model = $arr19[$i19++];
                            model.State |= 2/*TableRowState.Removed*/;
                        }
                    }
                    this.deleting ??= new $.$$.STT.TaskCompletionSource().$ctor$1();
                    ($t20 = this.deleting.Task, ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)()
                        const $t21 = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean);
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Success = true;
                        return $i21;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103081745215)
            
            //--TRIMMABLE-BOUNDARY-START(373664684863)
            /*void */ PasteFromClipBoard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664684863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let subClasses = $.$sl.SL.Enumerable.Concat($.$ajwi.LCACM.TableRowType, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ajwi.LCACM.TableRowType), [this.TableRowType], null, null), this.DataTable.TableDefinition.SubClassesOf(this.TableRowType));
                let $en22 = subClasses.SCG$IEnumerable$$$GetEnumerator();
                while ($en22.SC$1$IEnumerator$MoveNext())
                {
                    let table = $en22.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let items = this.DataTable.ClipBoards.get_Item(table);
                        if (items !== null)
                        {
                            if (this.DataTableUI !== null)
                            {
                                items.ForEach(new ($.$$.S.Action$$($.$WRsM.LCACSDV.TableRowModel))().$ctor(this,  (/**/ item) =>
                                {
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>?*/ let __ca2__;
                                    if (!(((__ca2__ = this.DataTableUI.Data) !== null ? $.$sl.SL.Enumerable.Contains$1($.$WRsM.LCACSDV.TableRowModel, __ca2__, item) : false)))
                                    {
                                        this.DataTableUI.Append$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$WRsM.LCACSDV.TableRowModel), [ item ], null, null));
                                    }
                                }, $IhKxej ??= {"r":65537,"p":[{"n":"item","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
                            }
                            if (this.ParentColumn !== null)
                            {
                                this.AddParentNavigationId(items);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373664684863)
            
            //--TRIMMABLE-BOUNDARY-START(73016974143)
            /*void */ CopySelectionsToClipBoard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016974143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.selections !== null)
                {
                    /*var*/ let clipBoard = this.DataTable.ClipBoards.get_Item(this.TableRowType);
                    $.$fPer.LCFC.ForEachExtension.ForEach$1($.$WRsM.LCACSDV.TableRowModel, this.selections, new ($.$$.S.Action$$($.$WRsM.LCACSDV.TableRowModel))().$ctor(this,  (/*v*/ v) =>
                    {
                        if (!clipBoard.Contains(v))
                        {
                            clipBoard.Add(v);
                        }
                    }, $URWgMb ??= {"r":65537,"p":[{"n":"v","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016974143)
            
            //--TRIMMABLE-BOUNDARY-START(64427039551)
            /*IEnumerable<TableRowModel> */ get Clipboard()
            {
                return this.DataTable.ClipBoards.get_Item(this.TableRowType);
            }
            //--TRIMMABLE-BOUNDARY-END(64427039551)
            
            //--TRIMMABLE-BOUNDARY-START(446679128895)
            /*void */ ToggleClipBoard(/*TableRowModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679128895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let clipBoard = this.DataTable.ClipBoards.get_Item(this.TableRowType);
                if (!clipBoard.Contains(model))
                {
                    clipBoard.Add(model);
                }
                else 
                {
                    clipBoard.Remove(model);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(446679128895)
            
            //--TRIMMABLE-BOUNDARY-START(459564030783)
            /*void */ UndoDelete(/*TableRowModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459564030783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                model.State &= ~(8/*TableRowState.Deleted*/ | 2/*TableRowState.Removed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(459564030783)
            
            //--TRIMMABLE-BOUNDARY-START(463858998079)
            /*void */ UndoDeleteAll()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463858998079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en23 = this.ViewData.SCG$IEnumerable$$$GetEnumerator();
                while ($en23.SC$1$IEnumerator$MoveNext())
                {
                    let model = $en23.SCG$IEnumerator$$$Current;
                    {
                        model.State &= ~(8/*TableRowState.Deleted*/ | 2/*TableRowState.Removed*/);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(463858998079)
            
            //--TRIMMABLE-BOUNDARY-START(399434488639)
            /*Dictionary<string, IObservableDataDescriptor> */ Sanitize(/*TableRowModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434488639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), model, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    /*var*/ let column = $.$sl.SL.Enumerable.SingleOrDefault$1($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*column*/ column) =>
                    {
                        return $.$$.S.String.Equals$2.call(column.Name, m.Key, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $abogyh ??= {"r":262145,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
                    const $t24 = column;
                    if ($.$ifnn($t24, ($t) => $.$$.System.Array.$ReadT1.call($t.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0)) === 16/*DataType.DateTime*/ && m.Value === null)
                    {
                        return false;
                    }
                    return true;
                }, $hrapgl ??= {"r":262145,"p":[{"n":"m","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Key;
                }, $LvYYXd ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value;
                }, $YXldjj ??= {"r":40536406,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(399434488639)
            
            //--TRIMMABLE-BOUNDARY-START(339304946495)
            /*void */ GetUpdates(/*CRUDRequestModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304946495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                model.Creates = $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.CreateRequestModel, $.$sl.SL.Enumerable.Concat($.$Iaui.LCFCM.CreateRequestModel, model.Creates, $.$sl.SL.Enumerable.Select$1($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.CreateRequestModel, this.AddedRows, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.CreateRequestModel))().$ctor(this,  (/*r*/ r) =>
                {
                    return (() =>
                    {
                        //new $.$Iaui.LCFCM.CreateRequestModel()
                        const $t25 = $.$Iaui.LCFCM.CreateRequestModel;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Target = new $.$fPer.LCFCD.DataId().$ctor$3(null, $.$$.System.Array.$ReadT1.call(this.TableRowType.Aliases, 0));
                        $i25.ModelType = 1/*ModelType.Row*/;
                        $i25.Properties = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String, $.$$.S.Object, this.Sanitize(r), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                        {
                            return kv.Key;
                        }, $BJuRwh ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.Object))().$ctor(this,  (/*kv*/ kv) =>
                        {
                            return kv.Value.LCFCD$IValueProvider$Value;
                        }, $PnNfWc ??= {"r":131073,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794})), true, false, true, false, false, false, false, "GetUpdates", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\TableViewModel.cs", "GetUpdates", 525));
                        $i25.AddTo = this.ParentColumn !== null && $.$is(this.ParentColumn.Row.Data.Id, $.$$.S.Guid) ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.AddToModel), [(() =>
                        {
                            //new $.$Iaui.LCFCM.AddToModel()
                            const $t26 = $.$Iaui.LCFCM.AddToModel;
                            const $i26 = new $t26();
                            $i26.$ctor$1();
                            $i26.Id = new $.$fPer.LCFCD.DataId().$ctor$3(this.ParentColumn.Row.Data.Id, $.$$.System.Array.$ReadT1.call(this.ParentColumn.Row.Table.TableRowType.Aliases, 0));
                            $i26.Property = this.ParentColumn.Column.Name;
                            return $i26;
                        })()], [-1], null) : null;
                        return $i25;
                    })();
                }, $AoToHh ??= {"r":4203862,"p":[{"n":"r","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}))));
                model.Updates = $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.UpdateRequestModel, $.$sl.SL.Enumerable.Concat($.$Iaui.LCFCM.UpdateRequestModel, model.Updates, $.$sl.SL.Enumerable.Select$1($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.UpdateRequestModel, this.UpdatedRows, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.UpdateRequestModel))().$ctor(this,  (/*r*/ r) =>
                {
                    return (() =>
                    {
                        //new $.$Iaui.LCFCM.UpdateRequestModel()
                        const $t27 = $.$Iaui.LCFCM.UpdateRequestModel;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Target = new $.$fPer.LCFCD.DataId().$ctor$3(r.Id, $.$$.System.Array.$ReadT1.call(this.TableRowType.Aliases, 0));
                        $i27.ModelType = 1/*ModelType.Row*/;
                        $i27.Properties = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String, $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), this.Sanitize(r), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.Boolean))().$ctor(this,  (/*kv*/ kv) =>
                        {
                            return kv.Value.LCFCD$1$IDirtyData$IsDirty;
                        }, $ZeRCnl ??= {"r":262145,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                        {
                            return kv.Key;
                        }, $hsAQpi ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.S.Object))().$ctor(this,  (/*kv*/ kv) =>
                        {
                            return kv.Value.LCFCD$IValueProvider$Value;
                        }, $kYZUCc ??= {"r":131073,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h}],"n":"","d":2530111,"h":0,"f":17825794})), true, false, true, false, false, false, false, "GetUpdates", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\TableViewModel.cs", "GetUpdates", 539));
                        return $i27;
                    })();
                }, $gwMPgi ??= {"r":23536982,"p":[{"n":"r","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}))));
                model.Deletes = $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.DeleteRequestModel, $.$sl.SL.Enumerable.Concat($.$Iaui.LCFCM.DeleteRequestModel, model.Deletes, $.$sl.SL.Enumerable.Select$1($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.DeleteRequestModel, this.DeletedRows, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.DeleteRequestModel))().$ctor(this,  (/*r*/ r) =>
                {
                    return (() =>
                    {
                        //new $.$Iaui.LCFCM.DeleteRequestModel()
                        const $t28 = $.$Iaui.LCFCM.DeleteRequestModel;
                        const $i28 = new $t28();
                        $i28.$ctor$2();
                        $i28.Target = new $.$fPer.LCFCD.DataId().$ctor$3(r.Id, $.$$.System.Array.$ReadT1.call(this.TableRowType.Aliases, 0));
                        $i28.ModelType = 1/*ModelType.Row*/;
                        return $i28;
                    })();
                }, $umQeDb ??= {"r":7742806,"p":[{"n":"r","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794}))));
                if (this.ParentColumn !== null && $.$sl.SL.Enumerable.Any$1($.$WRsM.LCACSDV.TableRowModel, this.RemovedRows))
                {
                    model.Removes = $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.RemovePropertyRequestModel, $.$sl.SL.Enumerable.Concat($.$Iaui.LCFCM.RemovePropertyRequestModel, model.Removes, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.RemovePropertyRequestModel), [(() =>
                    {
                        //new $.$Iaui.LCFCM.RemovePropertyRequestModel()
                        const $t29 = $.$Iaui.LCFCM.RemovePropertyRequestModel;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Target = new $.$fPer.LCFCD.DataId().$ctor$3(this.ParentColumn.Row.Data.Id, $.$$.System.Array.$ReadT1.call(this.ParentColumn.Row.Table.TableRowType.Aliases, 0));
                        $i29.Property = this.ParentColumn.Column.Name;
                        $i29.ModelType = 1/*ModelType.Row*/;
                        $i29.Members = $.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.RemoveMemeberRequestModel, $.$sl.SL.Enumerable.Select$1($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.RemoveMemeberRequestModel, this.RemovedRows, new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$Iaui.LCFCM.RemoveMemeberRequestModel))().$ctor(this,  (/*rr*/ rr) =>
                        {
                            return (() =>
                            {
                                //new $.$Iaui.LCFCM.RemoveMemeberRequestModel()
                                const $t30 = $.$Iaui.LCFCM.RemoveMemeberRequestModel;
                                const $i30 = new $t30();
                                $i30.$ctor$1();
                                $i30.Target = new $.$fPer.LCFCD.DataId().$ctor$3(rr.Id, $.$$.System.Array.$ReadT1.call(this.TableRowType.Aliases, 0));
                                return $i30;
                            })();
                        }, $DiiSYg ??= {"r":14361942,"p":[{"n":"rr","p":2071359}],"n":"","d":2530111,"h":0,"f":17825794})));
                        return $i29;
                    })()], [-1], null)));
                }
                let $en31 = this.Children.GetEnumerator();
                while ($en31.MoveNext())
                {
                    let child = $en31.Current;
                    {
                        child.GetUpdates(model);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339304946495)
            
            //--TRIMMABLE-BOUNDARY-START(356484815679)
            /*ValueTask *//*async*/  NotifyUpdated()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(356484815679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en32 = this.UpdatedRows.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let row = $en32.SCG$IEnumerator$$$Current;
                        {
                            let $en33 = row.GetEnumerator();
                            while ($en33.MoveNext())
                            {
                                let cell = $en33.Current;
                                {
                                    cell.Value.LCFCD$1$IDirtyData$NotDirty();
                                }
                            }
                            /*var*/ let rowUI = (this.DataTableUI?.GetContext(row) ?? null);
                            if (rowUI !== null)
                            {
                                let $t34, $r34;
                                ($t34 = rowUI.StateChanged(false), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                            }
                        }
                    }
                    let $en35 = this.ViewData.SCG$IEnumerable$$$GetEnumerator();
                    while ($en35.SC$1$IEnumerator$MoveNext())
                    {
                        let m = $en35.SCG$IEnumerator$$$Current;
                        {
                            m.State &= ~(1/*TableRowState.Added*/ | 4/*TableRowState.Updated*/ | 8/*TableRowState.Deleted*/ | 2/*TableRowState.Removed*/);
                        }
                    }
                    let $en36 = this.Children.GetEnumerator();
                    while ($en36.MoveNext())
                    {
                        let child = $en36.Current;
                        {
                            let $t37, $r37;
                            ($t37 = child.NotifyUpdated(), ($.$$.N.AsyncResolver.IsCompleted($t37, { set $v($v) { $r37 = $v; } }) ? $r37 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t37)));
                        }
                    }
                    if (this.deleting !== null)
                    {
                        this.deleting.SetResult();
                    }
                    else if (this.DataTableUI !== null)
                    {
                        let $t38, $r38;
                        ($t38 = this.DataTableUI.Refresh(), ($.$$.N.AsyncResolver.IsCompleted($t38, { set $v($v) { $r38 = $v; } }) ? $r38 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t38)));
                    }
                    this.deleting = null;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(356484815679)
            
            //--TRIMMABLE-BOUNDARY-START(472448932671)
            /*ValueTask */ UpdateDatabase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448932671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DataTable.Update(this);
            }
            //--TRIMMABLE-BOUNDARY-END(472448932671)
            
            //--TRIMMABLE-BOUNDARY-START(403729455935)
            /*IEnumerable<TableRowModel>?*/ selections = null;
            //--TRIMMABLE-BOUNDARY-END(403729455935)
            
            //--TRIMMABLE-BOUNDARY-START(360779782975)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<TableRowModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360779782975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selections = $.$sl.SL.Enumerable.ToList($.$WRsM.LCACSDV.TableRowModel, $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$WRsM.LCACSDV.TableRowModel), $.$WRsM.LCACSDV.TableRowModel, selection.SelectedItems, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$WRsM.LCACSDV.TableRowModel), $.$WRsM.LCACSDV.TableRowModel))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.LCFCCD$1$IDataListItemContext$$$Data;
                }, $NQcwAk ??= {"r":2071359,"p":[{"n":"s","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$WRsM.LCACSDV.TableRowModel).$h}],"n":"","d":2530111,"h":0,"f":17825794})));
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false);
            }
            //--TRIMMABLE-BOUNDARY-END(360779782975)
            
            //--TRIMMABLE-BOUNDARY-START(137441483583)
            /*IFormController */ get FormController()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(137441483583)
            
            //--TRIMMABLE-BOUNDARY-START(128851548991)
            /*void */ Field(/*IObservableDataDescriptor*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851548991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let column = $.$sl.SL.Enumerable.SingleOrDefault$1($.$ajwi.LCACM.TablePropertyColumn, this.FormColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Name === field.LCFCD$1$IObservableDataDescriptor$Name;
                }, $hCvgzi ??= {"r":262145,"p":[{"n":"c","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
                if (column === null || !((column.Accessibility & (4/*PropertyAccessibility.Write*/)) == (4/*PropertyAccessibility.Write*/)))
                {
                    field.LCFCD$1$IObservableDataDescriptor$Comment(1/*SchemaType.Form*/, true);
                }
                else 
                {
                    if (field.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$InputType === 21n)
                    {
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851548991)
            
            //--TRIMMABLE-BOUNDARY-START(85901876031)
            /*TableRowModel */ CreateInstance(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901876031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let columnValues = $.$sl.SL.Enumerable.ToDictionary$5($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor, this.FormColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Name;
                }, $RiIRIh ??= {"r":1310721,"p":[{"n":"c","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$fPer.LCFCD$1.IObservableDataDescriptor))().$ctor(this,  (/*column*/ column) =>
                {
                    return $.$fPer.LCFCD.DataDescriptorFactory.FromObject(column.ResolveDefaultValue, column.ValueType, column, column.Name, null, false);
                }, $QUQhgf ??= {"r":40536406,"p":[{"n":"column","p":578681}],"n":"","d":2530111,"h":0,"f":17825794}));
                /*string?*/ let id = null;
                if ($.$sl.SL.Enumerable.Any($.$ajwi.LCACM.TablePropertyColumn, this.Columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.ToLower.call(c.Name) === "id";
                }, $bpRove ??= {"r":262145,"p":[{"n":"c","p":578681}],"n":"","d":2530111,"h":0,"f":17825794})))
                {
                    id = $.$fPer.LCFCS$6.StringExtension.GetRandomString(8, true, true, true);
                    /*var*/ let d = $.$fPer.LCFCD.DataDescriptorFactory.FromData($.$$.S.String, id, null, null, null, null, true);
                    $.$fPer.LCFCP$1.PropertyExtension.SetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, columnValues, "Id", d);
                }
                return new $.$WRsM.LCACSDV.TableRowModel().$ctor$11(this.TableRowType, id, columnValues);
            }
            //--TRIMMABLE-BOUNDARY-END(85901876031)
            
            //--TRIMMABLE-BOUNDARY-START(120261614399)
            /*IDictionary<TableRowModel, TableRowViewModel>*/ detailedRows = null;
            //--TRIMMABLE-BOUNDARY-END(120261614399)
            
            //--TRIMMABLE-BOUNDARY-START(335009979199)
            /*TableRowViewModel */ GetRowDetail(/*TableRowModel*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009979199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TableRowViewModel?*/ let vm;
                if (this.detailedRows.SCG$IDictionary$$$$TryGetValue(data, $.$ref(() => vm, ($v) => vm = $v, $.$WRsM.LCACSDV.TableRowViewModel)))
                {
                    return vm;
                }
                vm = new $.$WRsM.LCACSDV.TableRowViewModel().$ctor$3(this, data, ((this.Depth + 1) | 0));
                this.detailedRows.SCG$IDictionary$$$$set_Item(data, vm);
                return vm;
            }
            //--TRIMMABLE-BOUNDARY-END(335009979199)
            
            //--TRIMMABLE-BOUNDARY-START(124556581695)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556581695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ParentColumn !== null)
                {
                    this.ParentColumn.Row.Table.Children.Remove(this);
                }
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(124556581695)
            
            //--TRIMMABLE-BOUNDARY-START(455269063487)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269063487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TableRowType.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(455269063487)
            
            //--TRIMMABLE-BOUNDARY-START(330715011903)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330715011903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(330715011903)
            
            //--TRIMMABLE-BOUNDARY-START(98786777919)
            /*DashboardTable<TableRowModel>?*/ DataTableUI = null;
            //--TRIMMABLE-BOUNDARY-END(98786777919)
            
            //--TRIMMABLE-BOUNDARY-START(481038867263)
            /*IEnumerable<TableRowModel> */ get ViewData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420044607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>?*/ let __ca3__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel, LivingThing.Core.Frameworks.Client.Components.DataTable.DataTableColumn<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>>>?*/ let __ca4__;
                return ((__ca3__ = this.DataTableUI) !== null ? (((__ca4__ = __ca3__.DataManager.ViewDataModels) !== null ? ($.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)), $.$WRsM.LCACSDV.TableRowModel, __ca4__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)), $.$WRsM.LCACSDV.TableRowModel))().$ctor(this,  (/*v*/ v) =>
                {
                    return v.Data;
                }, $mlWfdf ??= {"r":2071359,"p":[{"n":"v","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)).$h}],"n":"","d":2530111,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$WRsM.LCACSDV.TableRowModel)) : $.$sl.SL.Enumerable.Empty($.$WRsM.LCACSDV.TableRowModel)) ?? $.$sl.SL.Enumerable.Empty($.$WRsM.LCACSDV.TableRowModel)) : $.$sl.SL.Enumerable.Empty($.$WRsM.LCACSDV.TableRowModel));
            }
            //--TRIMMABLE-BOUNDARY-END(481038867263)
            
            //--TRIMMABLE-BOUNDARY-START(94491810623)
            /*DataTablesViewModel*/ DataTable = null;
            //--TRIMMABLE-BOUNDARY-END(94491810623)
            
            //--TRIMMABLE-BOUNDARY-START(442384161599)
            /*TableRowType*/ TableRowType = null;
            //--TRIMMABLE-BOUNDARY-END(442384161599)
            
            //--TRIMMABLE-BOUNDARY-START(90196843327)
            /*Func<int, int, Task<IEnumerable<TableRowModel>>>?*/ DataSource = null;
            //--TRIMMABLE-BOUNDARY-END(90196843327)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4314335574)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IInstanceActivator<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.CreateInstance(string?)
            LCFCD$IInstanceActivator$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$CreateInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4314335574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateInstance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4314335574)
            
            //--TRIMMABLE-BOUNDARY-START(4311517526)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.ICreateDataService<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.Create(LivingThing.Core.Frameworks.Common.Data.DataFilter, params LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel[])
            LCFCD$ICreateDataService$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311517526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311517526)
            
            //--TRIMMABLE-BOUNDARY-START(4317153622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadManyDataService<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.ReadMany(LivingThing.Core.Frameworks.Common.Data.DataFilter?, LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel?)
            LCFCD$IReadManyDataService$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$ReadMany()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317153622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadMany(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317153622)
            
            //--TRIMMABLE-BOUNDARY-START(4319250774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IUpdateDataService<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.Update(LivingThing.Core.Frameworks.Common.Data.DataFilter, params LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel[])
            LCFCD$IUpdateDataService$LivingThing$Core$Admin$Client$Shared$DataTable$ViewModels$TableRowModel$Update()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319250774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Update(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319250774)
            
            //--TRIMMABLE-BOUNDARY-START(4313024854)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDeleteDataService<LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel>.Delete(LivingThing.Core.Frameworks.Common.Data.DataFilter, params LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel[])
            LCFCD$IDeleteDataService$$$Delete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313024854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Delete(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313024854)
            
            //--TRIMMABLE-BOUNDARY-START(4318975658)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFieldEditController.Field(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCFCCF$2$IFormFieldEditController$Field()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4318975658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Field(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4318975658)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60132072255)
                this.Children = new ($.$$.SCG.List$$($.$WRsM.LCACSDV.TableViewModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(60132072255)
                
                //--TRIMMABLE-BOUNDARY-START(438089194303)
                this.Sort = $.$default($.$fPer.LCFCD.Sorting);
                //--TRIMMABLE-BOUNDARY-END(438089194303)
                
                //--TRIMMABLE-BOUNDARY-START(111671679807)
                this.deleting = new $.$$.STT.TaskCompletionSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(111671679807)
                
                //--TRIMMABLE-BOUNDARY-START(120261614399)
                this.detailedRows = new ($.$$.SCG.Dictionary$$$($.$WRsM.LCACSDV.TableRowModel, $.$WRsM.LCACSDV.TableRowViewModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(120261614399)
                
            }
            static $h = 2530111;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115966647103),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223340829503,
        "f": 50331649
      },
      "n": "Depth",
      "d": 2530111,
      "h": 115966647103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966647103),
//--TRIMMABLE-BOUNDARY-START(369369717567),
    {
      "p": 2005823,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266290502463,
        "f": 50331649
      },
      "n": "ParentColumn",
      "d": 2530111,
      "h": 369369717567,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369369717567),
//--TRIMMABLE-BOUNDARY-START(55837104959),
    {
      "p": 3644223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621352767,
        "f": 50331650
      },
      "n": "App",
      "d": 2530111,
      "h": 55837104959,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55837104959),
//--TRIMMABLE-BOUNDARY-START(60132072255),
    {
      "p": $.$$.SCG.List$$($.$WRsM.LCACSDV.TableViewModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211287359,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412319390527,
        "f": 83886081
      },
      "n": "Children",
      "d": 2530111,
      "h": 60132072255,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132072255),
//--TRIMMABLE-BOUNDARY-START(47247170367),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031418175,
        "f": 50331649
      },
      "n": "AddedRows",
      "d": 2530111,
      "h": 47247170367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247170367),
//--TRIMMABLE-BOUNDARY-START(395139521343),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283470371647,
        "f": 50331649
      },
      "n": "RemovedRows",
      "d": 2530111,
      "h": 395139521343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(395139521343),
//--TRIMMABLE-BOUNDARY-START(107376712511),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750894911,
        "f": 50331649
      },
      "n": "DeletedRows",
      "d": 2530111,
      "h": 107376712511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376712511),
//--TRIMMABLE-BOUNDARY-START(476743899967),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317830110015,
        "f": 50331649
      },
      "n": "UpdatedRows",
      "d": 2530111,
      "h": 476743899967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(476743899967),
//--TRIMMABLE-BOUNDARY-START(438089194303),
    {
      "p": 36997462,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300650240831,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429499259711,
        "f": 83886081
      },
      "n": "Sort",
      "d": 2530111,
      "h": 438089194303,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(438089194303),
//--TRIMMABLE-BOUNDARY-START(347894881087),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257700567871,
        "f": 50331650
      },
      "n": "IsRootTable",
      "d": 2530111,
      "h": 347894881087,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(347894881087),
//--TRIMMABLE-BOUNDARY-START(68722006847),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180391156543,
        "f": 50331649
      },
      "n": "Columns",
      "d": 2530111,
      "h": 68722006847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722006847),
//--TRIMMABLE-BOUNDARY-START(377959652159),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274880437055,
        "f": 50331649
      },
      "n": "PrimitiveColumns",
      "d": 2530111,
      "h": 377959652159,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377959652159),
//--TRIMMABLE-BOUNDARY-START(133146516287),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231930764095,
        "f": 50331649
      },
      "n": "FormColumns",
      "d": 2530111,
      "h": 133146516287,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146516287),
//--TRIMMABLE-BOUNDARY-START(433794227007),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292060306239,
        "f": 50331649
      },
      "n": "SimpleColumns",
      "d": 2530111,
      "h": 433794227007,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(433794227007),
//--TRIMMABLE-BOUNDARY-START(343599913791),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249110633279,
        "f": 50331649
      },
      "n": "IsEntity",
      "d": 2530111,
      "h": 343599913791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343599913791),
//--TRIMMABLE-BOUNDARY-START(64427039551),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171801221951,
        "f": 50331649
      },
      "n": "Clipboard",
      "d": 2530111,
      "h": 64427039551,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427039551),
//--TRIMMABLE-BOUNDARY-START(137441483583),
    {
      "p": 23942826,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240520698687,
        "f": 50331649
      },
      "n": "FormController",
      "d": 2530111,
      "h": 137441483583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441483583),
//--TRIMMABLE-BOUNDARY-START(98786777919),
    {
      "p": $.$hDPm.LCFCCD.DashboardTable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160960319,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420909325119,
        "f": 83886088
      },
      "n": "DataTableUI",
      "d": 2530111,
      "h": 98786777919,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786777919),
//--TRIMMABLE-BOUNDARY-START(481038867263),
    {
      "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326420044607,
        "f": 50331649
      },
      "n": "ViewData",
      "d": 2530111,
      "h": 481038867263,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(481038867263),
//--TRIMMABLE-BOUNDARY-START(94491810623),
    {
      "p": 1940287,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197571025727,
        "f": 50331649
      },
      "n": "DataTable",
      "d": 2530111,
      "h": 94491810623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491810623),
//--TRIMMABLE-BOUNDARY-START(442384161599),
    {
      "p": 644217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309240175423,
        "f": 50331649
      },
      "n": "TableRowType",
      "d": 2530111,
      "h": 442384161599,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(442384161599),
//--TRIMMABLE-BOUNDARY-START(90196843327),
    {
      "p": $.$$.S.Func$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel))).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188981091135,
        "f": 50331650
      },
      "n": "DataSource",
      "d": 2530111,
      "h": 90196843327,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90196843327)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(450974096191),
    {
      "r": 65537,
      "p": [
        {
          "n": "column",
          "p": 578681
        }
      ],
      "n": "ToggleSort",
      "d": 2530111,
      "h": 450974096191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(450974096191),
//--TRIMMABLE-BOUNDARY-START(382254619455),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "_",
          "p": 2071359,
          "f": 65
        }
      ],
      "n": "ReadMany",
      "d": 2530111,
      "h": 382254619455,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(382254619455),
//--TRIMMABLE-BOUNDARY-START(386549586751),
    {
      "r": 65537,
      "n": "Reload",
      "o": "@$1",
      "d": 2530111,
      "h": 386549586751,
      "f": 553648129
    },
//--TRIMMABLE-BOUNDARY-END(386549586751),
//--TRIMMABLE-BOUNDARY-START(51542137663),
    {
      "r": 65537,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h
        }
      ],
      "n": "AddParentNavigationId",
      "d": 2530111,
      "h": 51542137663,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51542137663),
//--TRIMMABLE-BOUNDARY-START(81606908735),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray($.$WRsM.LCACSDV.TableRowModel).$h,
          "f": 16
        }
      ],
      "n": "Create",
      "d": 2530111,
      "h": 81606908735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606908735),
//--TRIMMABLE-BOUNDARY-START(352189848383),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 2071359
        }
      ],
      "n": "MarkDirty",
      "d": 2530111,
      "h": 352189848383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(352189848383),
//--TRIMMABLE-BOUNDARY-START(468153965375),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$WRsM.LCACSDV.TableRowModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray($.$WRsM.LCACSDV.TableRowModel).$h,
          "f": 16
        }
      ],
      "n": "Update",
      "d": 2530111,
      "h": 468153965375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(468153965375),
//--TRIMMABLE-BOUNDARY-START(390844554047),
    {
      "r": 178454529,
      "p": [
        {
          "n": "model",
          "p": 2071359
        }
      ],
      "n": "Remove",
      "d": 2530111,
      "h": 390844554047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(390844554047),
//--TRIMMABLE-BOUNDARY-START(103081745215),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray($.$WRsM.LCACSDV.TableRowModel).$h,
          "f": 16
        }
      ],
      "n": "Delete",
      "d": 2530111,
      "h": 103081745215,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103081745215),
//--TRIMMABLE-BOUNDARY-START(373664684863),
    {
      "r": 65537,
      "n": "PasteFromClipBoard",
      "d": 2530111,
      "h": 373664684863,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(373664684863),
//--TRIMMABLE-BOUNDARY-START(73016974143),
    {
      "r": 65537,
      "n": "CopySelectionsToClipBoard",
      "d": 2530111,
      "h": 73016974143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016974143),
//--TRIMMABLE-BOUNDARY-START(446679128895),
    {
      "r": 65537,
      "p": [
        {
          "n": "model",
          "p": 2071359
        }
      ],
      "n": "ToggleClipBoard",
      "d": 2530111,
      "h": 446679128895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(446679128895),
//--TRIMMABLE-BOUNDARY-START(459564030783),
    {
      "r": 65537,
      "p": [
        {
          "n": "model",
          "p": 2071359
        }
      ],
      "n": "UndoDelete",
      "d": 2530111,
      "h": 459564030783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(459564030783),
//--TRIMMABLE-BOUNDARY-START(463858998079),
    {
      "r": 65537,
      "n": "UndoDeleteAll",
      "d": 2530111,
      "h": 463858998079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(463858998079),
//--TRIMMABLE-BOUNDARY-START(399434488639),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h,
      "p": [
        {
          "n": "model",
          "p": 2071359
        }
      ],
      "n": "Sanitize",
      "d": 2530111,
      "h": 399434488639,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(399434488639),
//--TRIMMABLE-BOUNDARY-START(339304946495),
    {
      "r": 65537,
      "p": [
        {
          "n": "model",
          "p": 4466006
        }
      ],
      "n": "GetUpdates",
      "d": 2530111,
      "h": 339304946495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(339304946495),
//--TRIMMABLE-BOUNDARY-START(356484815679),
    {
      "r": 181338113,
      "n": "NotifyUpdated",
      "d": 2530111,
      "h": 356484815679,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(356484815679),
//--TRIMMABLE-BOUNDARY-START(472448932671),
    {
      "r": 181338113,
      "n": "UpdateDatabase",
      "d": 2530111,
      "h": 472448932671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(472448932671),
//--TRIMMABLE-BOUNDARY-START(360779782975),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$WRsM.LCACSDV.TableRowModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 2530111,
      "h": 360779782975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(360779782975),
//--TRIMMABLE-BOUNDARY-START(128851548991),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": 40536406
        }
      ],
      "n": "Field",
      "d": 2530111,
      "h": 128851548991,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851548991),
//--TRIMMABLE-BOUNDARY-START(85901876031),
    {
      "r": 2071359,
      "p": [
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CreateInstance",
      "d": 2530111,
      "h": 85901876031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901876031),
//--TRIMMABLE-BOUNDARY-START(335009979199),
    {
      "r": 2464575,
      "p": [
        {
          "n": "data",
          "p": 2071359
        }
      ],
      "n": "GetRowDetail",
      "d": 2530111,
      "h": 335009979199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(335009979199),
//--TRIMMABLE-BOUNDARY-START(124556581695),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2530111,
      "h": 124556581695,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124556581695),
//--TRIMMABLE-BOUNDARY-START(455269063487),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2530111,
      "h": 455269063487,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(455269063487),
//--TRIMMABLE-BOUNDARY-START(330715011903),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "defaultValue",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 2530111,
      "h": 330715011903,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(330715011903)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(365074750271),
    {
      "t": 655361,
      "n": "page",
      "d": 2530111,
      "h": 365074750271,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(365074750271),
//--TRIMMABLE-BOUNDARY-START(77311941439),
    {
      "t": 655361,
      "n": "count",
      "d": 2530111,
      "h": 77311941439,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77311941439),
//--TRIMMABLE-BOUNDARY-START(111671679807),
    {
      "t": 179568641,
      "n": "deleting",
      "d": 2530111,
      "h": 111671679807,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111671679807),
//--TRIMMABLE-BOUNDARY-START(403729455935),
    {
      "t": $.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h,
      "n": "selections",
      "d": 2530111,
      "h": 403729455935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(403729455935),
//--TRIMMABLE-BOUNDARY-START(120261614399),
    {
      "t": $.$$.SCG.IDictionary$$$($.$WRsM.LCACSDV.TableRowModel, $.$WRsM.LCACSDV.TableRowViewModel).$h,
      "n": "detailedRows",
      "d": 2530111,
      "h": 120261614399,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261614399)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952203071),
    {
      "p": [
        {
          "n": "app",
          "p": 3644223
        },
        {
          "n": "dataTable",
          "p": 1940287
        },
        {
          "n": "tableModel",
          "p": 644217
        },
        {
          "n": "depth",
          "p": 655361
        },
        {
          "n": "parentColumn",
          "p": 2005823,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2530111,
      "h": 42952203071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952203071)
  ],
  "h": 2530111
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$WRsM.LCACSDV.TableRowModel), $.$hDPm.LCFCCD$1.IDataListFormController$$($.$WRsM.LCACSDV.TableRowModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$WRsM.LCACSDV.TableRowModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$hDPm.LCFCCF$2.IFormModelController$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD.IInstanceActivator$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD.ICreateDataService$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD.IReadManyDataService$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD.IUpdateDataService$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD.IDeleteDataService$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFC.IRemoteService, $.$hDPm.LCFCCF$2.IFormFieldEditController, $.$hDPm.LCFCCF$2.IFormController, $.$hDPm.LCFCCI$1.IInputController, $.$vWqU.LCFCC.IViewController, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2530111)
        
        

        //--TRIMMABLE-BOUNDARY-START(2202431)
        $asm.$cls(`$WRsM.LCACSDV.TableRowModelTypeDescriptor`, ($self) => class TableRowModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACSDV.TableRowModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297169727)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297169727);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WRsM.LCACSDV.TableRowModelTypeDescriptor.GenerateProperties($.$WRsM.LCACSDV.TableRowModel, this, factory);
                    }, $cTRBQh ??= {"r":65537,"n":"","d":2202431,"h":0,"f":17825794}), 0, "TableRowModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Admin.Client.Blazor\\Shared_DataTable_ViewModels_TableRowModel_LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModelTypeDescriptorBuilder.g.cs", "TableRowModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297169727)
            
            //--TRIMMABLE-BOUNDARY-START(12887104319)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887104319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACSDV.TableRowModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$WRsM.LCACSDV.TableRowState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "State";
                        $i1.DelaredOn = "LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSDV.TableRowModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$WRsM.LCACSDV.TableRowState, ($.$cast(target, $.$WRsM.LCACSDV.TableRowModel)).State);
                        }, $kUUbrc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2202431,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSDV.TableRowModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$WRsM.LCACSDV.TableRowState);
                        }, $jjsPLi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2202431,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TableType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACSDV.TableRowModel.$type, $.$discardRef(), "TableType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TableType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ajwi.LCACM.TableRowType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TableType";
                        $i3.DelaredOn = "LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSDV.TableRowModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ajwi.LCACM.TableRowType, ($.$cast(target, $.$WRsM.LCACSDV.TableRowModel)).TableType);
                        }, $GBvVUa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2202431,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WRsM.LCACSDV.TableRowModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Object, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Id";
                        $i5.DelaredOn = "LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WRsM.LCACSDV.TableRowModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Object, ($.$cast(target, $.$WRsM.LCACSDV.TableRowModel)).Id);
                        }, $nAmVhg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2202431,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887104319)
            
            //--TRIMMABLE-BOUNDARY-START(17182071615)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182071615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$WRsM.LCACSDV.TableRowState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$WRsM.LCACSDV.TableRowState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _TableType = _target.TableType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TableType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ajwi.LCACM.TableRowType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _TableType, ($v) => _TableType = $v, $.$ajwi.LCACM.TableRowType)))
                    {
                    }
                }
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Object));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Object, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.Object)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182071615)
            
            //--TRIMMABLE-BOUNDARY-START(8592137023)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592137023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WRsM.LCACSDV.TableRowModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WRsM.LCACSDV.TableRowModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSDV.TableRowModel)))
                {
                    /*var*/ let result = $.$WRsM.LCACSDV.TableRowModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSDV.TableRowModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WRsM.LCACSDV.TableRowModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WRsM.LCACSDV.TableRowModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592137023)
            
            static $h = 2202431;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WRsM.LCACSDV.TableRowModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887104319),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2202431,
      "h": 12887104319,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887104319),
//--TRIMMABLE-BOUNDARY-START(17182071615),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2071359,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2202431,
      "h": 17182071615,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182071615),
//--TRIMMABLE-BOUNDARY-START(8592137023),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2071359,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2202431,
      "h": 8592137023,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592137023)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297169727),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2202431,
      "h": 4297169727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297169727)
  ],
  "h": 2202431
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WRsM.LCACSDV.TableRowModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.ViewModels.TableRowModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}ViewModels${separator}TableRowModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2202431)
        
        

        //--TRIMMABLE-BOUNDARY-START(1612607)
        $asm.$cls(`$WRsM.LCACSD.Table`, ($self) => class Table extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51541220159)
            /*SchemaAttributeBase*/ static nameFilter = null;
            //--TRIMMABLE-BOUNDARY-END(51541220159)
            
            //--TRIMMABLE-BOUNDARY-START(85900958527)
            /*TableViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(85900958527)
            
            //--TRIMMABLE-BOUNDARY-START(55836187455)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836187455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.TableRowType.AutoRefreshInterval !== 0)
                {
                    _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            while(!this.IsDisposed)
                            {
                                let $t1, $r1;
                                ($t1 = $.$$.STT.Task.Delay$1(this.ViewModel.TableRowType.AutoRefreshInterval), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                                if (this.ViewModel.DataTableUI !== null)
                                {
                                    let $t2, $r2;
                                    ($t2 = this.InvokeAsync(new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.ViewModel.DataTableUI.Refresh();
                                    }, $kDNQud ??= {"r":65537,"n":"","d":1612607,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                }
                            }
                        });
                    }, $tUqMfk ??= {"r":178454529,"n":"","d":1612607,"h":0,"f":17829890}));
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(55836187455)
            
            //--TRIMMABLE-BOUNDARY-START(25771416383)
            /*IDictionary<string, object?>? */ CellFormat(/*IObservableDataDescriptor?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771416383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((data?.LCFCD$1$IDirtyData$IsDirty ?? null) ?? false) ? (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("class", data.LCFCD$1$IDirtyData$IsDirty ? "bg-dark-05" : null);
                    return $i3;
                })() : null;
            }
            //--TRIMMABLE-BOUNDARY-END(25771416383)
            
            //--TRIMMABLE-BOUNDARY-START(64426122047)
            /*IEnumerable<KeyValuePair<string, object>> */ RowAttributes(/*TableRowModel*/ row)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)))().$ctor$1(function*()
                {
                    if (((row.State & (2/*TableRowState.Removed*/)) == (2/*TableRowState.Removed*/)) || ((row.State & (8/*TableRowState.Deleted*/)) == (8/*TableRowState.Deleted*/)))
                    {
                        yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("class", "bg-error-01");
                    }
                    if (((row.State & (1/*TableRowState.Added*/)) == (1/*TableRowState.Added*/)))
                    {
                        yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("class", "bg-success-01");
                    }
                    if (((row.State & (4/*TableRowState.Updated*/)) == (4/*TableRowState.Updated*/)))
                    {
                        yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("class", "bg-warning-01");
                    }
                    /*var*/ let clipboard = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$ajwi.LCACM.TableRowType, $.$$.SCG.List$$($.$WRsM.LCACSDV.TableRowModel), this.ViewModel.DataTable.ClipBoards, this.ViewModel.TableRowType);
                    if (clipboard !== null && clipboard.Contains(row))
                    {
                        yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))().$ctor$3("class", "bg-message-01");
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(64426122047)
            
            //--TRIMMABLE-BOUNDARY-START(60131154751)
            /*string */ get OptimizedComponentName()
            {
                return "table";
            }
            //--TRIMMABLE-BOUNDARY-END(60131154751)
            
            //--TRIMMABLE-BOUNDARY-START(81605991231)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605991231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WRsM.LCACSDV.TableViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81605991231)
            
            //--TRIMMABLE-BOUNDARY-START(21476449087)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476449087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$WRsM.LCACSDV.TableRowModel), 3);
                    __builder2.AddComponentParameter(4, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder2.AddComponentParameter(5, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.ViewModel));
                    __builder2.AddComponentParameter(6, "ItemName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.TableRowType.Name));
                    __builder2.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (27073296294678532n & ~4096n) | 140737488355328n | 64n | 32n | 128n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(8, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, (7616/*DashboardTableFeatures.Default*/ | 8192/*DashboardTableFeatures.FillPage*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/) & ~128/*DashboardTableFeatures.DetailsToDrawer*/ & ~2048/*DashboardTableFeatures.TableFromSchema*/ & ~4096/*DashboardTableFeatures.TitleBar*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                    __builder2.AddComponentParameter(9, "DataListFilterFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFilterFeatures, 0/*DataListFilterFeatures.Default*/ | 1/*DataListFilterFeatures.Query*/), $.$hDPm.LCFCCD$1.DataListFilterFeatures));
                    __builder2.AddComponentParameter(10, "RowAttributes", new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))))().$ctor(this, (this.RowAttributes)));
                    __builder2.AddComponentParameter(11, "ItemsPerPage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeArray($.$$.S.Int32), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [24, 50, 100, 200, 500, 1000], null, null)));
                    __builder2.AddComponentParameter(12, "side-class", "bg-card pd mg shadow");
                    __builder2.AddComponentParameter(13, "content-class", "bg-card pd mg shadow");
                    __builder2.AddComponentParameter(14, "menu-class", "mg pd bg-card mgt");
                    __builder2.AddComponentParameter(15, "search-class", "bd bg-primary-01 corner");
                    __builder2.AddAttribute$3(16, "Commands", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel))))().$ctor(this, ( (/*item*/ item) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (item.Context === null && item.Location === 1/*DataListToolBarCommandLocation.Right*/)
                            {
                                __builder3.OpenElement(17, "button");
                                __builder3.AddAttribute$5(18, "title", "Copy selections to clipboard");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 19, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.CopySelectionsToClipBoard)));
                                __builder3.AddAttribute$5(20, "class", $.$strNN($.$strNN(($.$hDPm.LCFCCD$1.DataListFilter.ButtonClass)) + " mdi") + " mdi-content-copy");
                                __builder3.AddAttribute$5(21, "type", "button");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(22, "\r\n                ");
                                __builder3.OpenElement(23, "button");
                                __builder3.AddAttribute$5(24, "title", "Paste from clipboard");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 25, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.PasteFromClipBoard)));
                                __builder3.AddAttribute$5(26, "class", $.$strNN($.$strNN(($.$hDPm.LCFCCD$1.DataListFilter.ButtonClass)) + " mdi") + " mdi-content-paste");
                                __builder3.AddAttribute$5(27, "type", "button");
                                __builder3.CloseElement();
                                __builder3.OpenElement(28, "button");
                                __builder3.AddAttribute$5(29, "title", "Update Database");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 30, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this.ViewModel, this.ViewModel.UpdateDatabase)));
                                __builder3.AddAttribute$5(31, "class", $.$strNN($.$strNN(($.$hDPm.LCFCCD$1.DataListFilter.ButtonClass)) + " mdi") + " mdi-upload");
                                __builder3.AddAttribute$5(32, "type", "button");
                                __builder3.CloseElement();
                            }
                            else if (item.Context === null && item.Location === 0/*DataListToolBarCommandLocation.Left*/)
                            {
                                if (item.Filter !== null)
                                {
                                    __builder3.AddContent$1(33, item.Filter.Text(new ($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCA$1.SchemaAttributeBase, $.$fPer.LCFCD$1.IPropertyDescriptor), $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption)))().$ctor$3($.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCA$1.SchemaAttributeBase, $.$fPer.LCFCD$1.IPropertyDescriptor).op_Implicit($.$WRsM.LCACSD.Table.nameFilter), null)));
                                }
                                if ($.$sl.SL.Enumerable.Any$1($.$WRsM.LCACSDV.TableRowModel, this.ViewModel.DeletedRows))
                                {
                                    __builder3.OpenElement(34, "div");
                                    __builder3.AddAttribute$5(35, "class", "mgx-a mgy-a");
                                    __builder3.OpenElement(36, "div");
                                    __builder3.AddAttribute$5(37, "class", "mgy-a fsz-11 pdx pdy-1 bg-error corner-5");
                                    __builder3.AddContent$3(38, $.$box($.$sl.SL.Enumerable.Count$1($.$WRsM.LCACSDV.TableRowModel, this.ViewModel.DeletedRows), $.$$.S.Int32));
                                    __builder3.AddMarkupContent(39, " deleting\r\n                            ");
                                    __builder3.OpenElement(40, "button");
                                    __builder3.AddAttribute$5(41, "class", "mdi mdi-close bg-transparent pd-0");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 42, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this.ViewModel, this.ViewModel.UndoDeleteAll)));
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                            }
                            else if (item.Context !== null)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$WRsM.LCACSDV.TableRowModel), 43);
                                __builder3.AddComponentParameter(44, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(45, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableRowModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$WRsM.LCACSDV.TableRowModel, this, new ($.$$.S.Action$$($.$WRsM.LCACSDV.TableRowModel))().$ctor(this.ViewModel, this.ViewModel.UndoDelete))));
                                __builder3.AddComponentParameter(46, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableRowModel, item.Context.Data));
                                __builder3.AddComponentParameter(47, "title", "Undo Delete");
                                __builder3.AddComponentParameter(48, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN($.$hDPm.LCFCCD$1.DataListItemToolBar.ButtonClass)} mdi mdi-dete-off`));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(49, "\r\n                ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$WRsM.LCACSDV.TableRowModel), 50);
                                __builder3.AddComponentParameter(51, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(52, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$WRsM.LCACSDV.TableRowModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$WRsM.LCACSDV.TableRowModel, this, new ($.$$.S.Action$$($.$WRsM.LCACSDV.TableRowModel))().$ctor(this.ViewModel, this.ViewModel.ToggleClipBoard))));
                                __builder3.AddComponentParameter(53, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableRowModel, item.Context.Data));
                                __builder3.AddComponentParameter(54, "title", "Copy Item");
                                __builder3.AddComponentParameter(55, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN($.$hDPm.LCFCCD$1.DataListItemToolBar.ButtonClass)} mdi mdi-content-copy`));
                                __builder3.CloseComponent();
                            }
                        }, $ddSyCi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                    }), $lwvIad ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListToolCommand$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)).$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(56, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, context.Data, "Id")?.LCFCD$IValueProvider$Value ?? null) !== null)
                            {
                                __builder3.OpenComponent$1($.$WRsM.LCACSD.TableRow, 57);
                                __builder3.AddComponentParameter(58, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$WRsM.LCACSDV.TableRowViewModel, this.ViewModel.GetRowDetail(context.Data)));
                                __builder3.CloseComponent();
                            }
                        }, $zPkJYi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                    }), $HbDUqh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)).$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(59, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            let $en5 = $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TablePropertyColumn, this.ViewModel.PrimitiveColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                            {
                                /*LivingThing.Core.Frameworks.Common.Attributes.SchemaAttribute?*/ let __ca1__;
                                return !(((__ca1__ = e.Schema) !== null ? ((__ca1__.Exclude & (4/*SchemaType.DataTable*/)) == (4/*SchemaType.DataTable*/)) : false));
                            }, $Basjxa ??= {"r":262145,"p":[{"n":"e","p":578681}],"n":"","d":1612607,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                            while ($en5.SC$1$IEnumerator$MoveNext())
                            {
                                let column = $en5.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _column = column;
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel), 60);
                                    __builder3.AddComponentParameter(61, "CellAttributes", new ($.$$.S.Func$$$($.$WRsM.LCACSDV.TableRowModel, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object))))().$ctor(this, ( (/*data*/ data) =>
                                    {
                                        return this.CellFormat($.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, data, _column.Name));
                                    }), $iZdeUk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,"p":[{"n":"data","p":2071359}],"n":"","d":1612607,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(62, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel)))().$ctor(this, ( (/**/ columns) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenElement(63, "span");
                                            __builder4.AddAttribute$5(64, "class", "nowrap mawx-1");
                                            __builder4.AddAttribute$5(65, "title", $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(column.Name));
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 66, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                return this.ViewModel.ToggleSort(column);
                                            }, $bCwoCi ??= {"r":65537,"n":"","d":1612607,"h":0,"f":17825794})));
                                            __builder4.AddContent$4(67, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(column.Name));
                                            if (this.ViewModel.Sort.Field === column.Name)
                                            {
                                                if (this.ViewModel.Sort.Order === 1/*SortingOrder.Ascending*/)
                                                {
                                                    __builder4.AddMarkupContent(68, "<i class=\"f-right mdi mdi-chevron-up\"></i>");
                                                }
                                                else if (this.ViewModel.Sort.Order === 2/*SortingOrder.Descending*/)
                                                {
                                                    __builder4.AddMarkupContent(69, "<i class=\"f-right mdi mdi-chevron-down\"></i>");
                                                }
                                            }
                                            __builder4.CloseElement();
                                        }, $iEDqIk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                                    }), $oegVRa ??= {"r":6881395,"p":[{"n":"columns","p":$.$$.SCG.IEnumerable$$($.$WRsM.LCACSDV.TableRowModel).$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(70, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel))))().$ctor(this, ( (/*data*/ data) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            if (!((column.Accessibility & (4/*PropertyAccessibility.Write*/)) == (4/*PropertyAccessibility.Write*/)) || ((column.Schema?.InputType ?? null) === 3n))
                                            {
                                                __builder4.AddContent$1(71, $.$WRsM.LCACSD.Table.SmartFormat(column, $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, data.Model, column.Name)));
                                            }
                                            else 
                                            {
                                                __builder4.AddContent$1(72, this.Editable(column, data.Model));
                                            }
                                        }, $khwMvj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                                    }), $azoLib ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)).$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                            }
                        }, $roqQce ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                    }), $cfBZYj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$WRsM.LCACSDV.TableRowModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$WRsM.LCACSDV.TableRowModel)).$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(73, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.ViewModel.DataTableUI = $.$cast(__value, $.$hDPm.LCFCCD.DashboardTable$$($.$WRsM.LCACSDV.TableRowModel));
                    }, $bPbOnk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1612607,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $DXeAEd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21476449087)
            
            //--TRIMMABLE-BOUNDARY-START(77311023935)
            static /*RenderFragment? */ SmartFormat(/*Common.Models.TablePropertyColumn*/ column, /*IObservableDataDescriptor?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311023935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?*/ let __ca2__;
                /*object?*/ let __ca3__;
                let dt;
                /*var*/ let val = $.$is((value?.LCFCD$IValueProvider$Value ?? null), $.$$.S.DateTime, { set $v($v){ dt = $v; } }) ? $.$fPer.LCFCDC.DateTimeExtension.FromUTCToZone(dt, null).ToString() : (((__ca2__ = value) !== null ? (((__ca3__ = __ca2__.LCFCD$IValueProvider$Value) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "") ?? "") : ""));
                /*Dictionary<Stringy, object?>*/ let att = (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                    const $t6 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "mawx-15 d-i-block nowrap");
                    $i6.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("title"), val);
                    return $i6;
                })();
                return $.$hDPm.LCFCCV$1.VisualPresent$$($.$$.S.Object).PresentValue((value?.LCFCD$IValueProvider$Value ?? null), null, (column.Schema?.ViewType ?? null) ?? 3/*ViewType.Mini*/, att, null, null);
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(74, "span");
                    __builder2.AddAttribute$5(75, "class", "mawx-15 d-i-block nowrap");
                    __builder2.AddAttribute$5(76, "title", val);
                    __builder2.AddContent$4(77, val);
                    __builder2.CloseElement();
                }, $FPznhd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(77311023935)
            
            //--TRIMMABLE-BOUNDARY-START(4296579903)
            /*RenderFragment? */ _Editable(T, /*Common.Models.TablePropertyColumn*/ column, /*TableRowModel*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296579903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IObservableDataDescriptor?*/ let val = $.$fPer.LCFCP$1.PropertyExtension.GetValue$1($.$fPer.LCFCD$1.IObservableDataDescriptor, data, column.Name);
                if (val === null)
                {
                    return null;
                }
                /*var*/ let ed = new ($.$WRsM.LCACSD.TableValueBinder$$(T))().$ctor$1(this.ViewModel, data, $.$cast(val.LCFCD$IValueProvider$Value, T), new ($.$$.S.Action$$(T))().$ctor(this,  (/*v*/ v) =>
                {
                    return val.LCFCD$IValueProvider$Value = $.$box(v, T);
                }, $WYViPf ??= {"r":65537,"p":[{"n":"v","p":(T) => T.$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(T), 78);
                    __builder2.AddComponentParameter(79, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, column.InputType), $.$fPer.LCFC.InputType));
                    __builder2.AddComponentParameter(80, "Class", "miwx-1");
                    __builder2.AddComponentParameter(81, "ExcludeSchema", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCA$1.SchemaType), 0/*SchemaType.None*/), $.$fPer.LCFCA$1.SchemaType));
                    __builder2.AddComponentParameter(82, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(83, "Value", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(T, ed.Value), T));
                    __builder2.AddComponentParameter(84, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(T), $.$mac.MAC.EventCallback.Factory.Create$6(T, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1(T, this, new ($.$$.S.Action$$(T))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return ed.Value = __value;
                    }, $AFndPf ??= {"r":65537,"p":[{"n":"__value","p":(T) => T.$h}],"n":"","d":1612607,"h":0,"f":17825794}), ed.Value))));
                    __builder2.AddComponentParameter(85, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$(T)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(ed), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $pqBOJk ??= {"r":38797349,"n":"","d":1612607,"h":0,"f":17825794})).Invoke())));
                    __builder2.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$(T))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(87, $.$WRsM.LCACSD.Table.SmartFormat(column, val));
                        }, $wwFuTf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
                    }), $Frxref ??= {"r":6881395,"p":[{"n":"context","p":(T) => T.$h}],"n":"","d":1612607,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $DSaCrj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1612607,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(4296579903)
            
            //--TRIMMABLE-BOUNDARY-START(30066383679)
            /*RenderFragment? */ Editable(/*Common.Models.TablePropertyColumn*/ column, /*TableRowModel*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066383679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCT.TypesExtensions.CallGenericMethod$1($.$mac.MAC.RenderFragment, this, "_Editable", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [column.ValueType.LCFCD$1$ITypeDescriptor$SystemType], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ column, data ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066383679)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181481791)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181481791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181481791)
            
            //--TRIMMABLE-BOUNDARY-START(17181481791)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17181481791)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85900958527)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(85900958527)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886514495)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886514495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51541220159)
                    this.nameFilter = (() =>
                    {
                        //new $.$fPer.LCFCA$1.SchemaAttribute()
                        const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                        const $i7 = new $t7();
                        $i7.$ctor$4();
                        $i7.Key = "Name";
                        $i7.Title = "Name";
                        return $i7;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(51541220159)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886514495)
            
            static $h = 1612607;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WRsM.LCACSDV.TableViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900958527),
    {
      "p": 2530111,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246252863,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016056639,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 1612607,
      "h": 85900958527,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900958527),
//--TRIMMABLE-BOUNDARY-START(60131154751),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656318271,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1612607,
      "h": 60131154751,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60131154751)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836187455),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1612607,
      "h": 55836187455,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55836187455),
//--TRIMMABLE-BOUNDARY-START(25771416383),
    {
      "r": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "p": [
        {
          "n": "data",
          "p": 40536406
        }
      ],
      "n": "CellFormat",
      "d": 1612607,
      "h": 25771416383,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25771416383),
//--TRIMMABLE-BOUNDARY-START(64426122047),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "p": [
        {
          "n": "row",
          "p": 2071359
        }
      ],
      "n": "RowAttributes",
      "d": 1612607,
      "h": 64426122047,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426122047),
//--TRIMMABLE-BOUNDARY-START(81605991231),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1612607,
      "h": 81605991231,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605991231),
//--TRIMMABLE-BOUNDARY-START(21476449087),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1612607,
      "h": 21476449087,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476449087),
//--TRIMMABLE-BOUNDARY-START(77311023935),
    {
      "r": 6881395,
      "p": [
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "value",
          "p": 40536406
        }
      ],
      "n": "SmartFormat",
      "d": 1612607,
      "h": 77311023935,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77311023935),
//--TRIMMABLE-BOUNDARY-START(4296579903),
    {
      "r": 6881395,
      "p": [
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "data",
          "p": 2071359
        }
      ],
      "g": [
        "T"
      ],
      "n": "_Editable",
      "d": 1612607,
      "h": 4296579903,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(4296579903),
//--TRIMMABLE-BOUNDARY-START(30066383679),
    {
      "r": 6881395,
      "p": [
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "data",
          "p": 2071359
        }
      ],
      "n": "Editable",
      "d": 1612607,
      "h": 30066383679,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30066383679)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541220159),
    {
      "t": 2328918,
      "n": "nameFilter",
      "d": 1612607,
      "h": 51541220159,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541220159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181481791),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1612607,
      "h": 17181481791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181481791)
  ],
  "h": 1612607
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Shared.DataTable.Table`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Shared${separator}DataTable${separator}Table`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1612607)
        
        

        //--TRIMMABLE-BOUNDARY-START(1350463)
        $asm.$cls(`$WRsM.LCACS.UserMesssageComposerProvider`, ($self) => class UserMesssageComposerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540958015)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(51540958015)
            
            //--TRIMMABLE-BOUNDARY-START(8591285055)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591285055);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591285055)
            
            //--TRIMMABLE-BOUNDARY-START(55835925311)
            /*string? */ get Title()
            {
                return "Users";
            }
            //--TRIMMABLE-BOUNDARY-END(55835925311)
            
            //--TRIMMABLE-BOUNDARY-START(12886252351)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(12886252351)
            
            //--TRIMMABLE-BOUNDARY-START(47245990719)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account"/*MaterialDesignIconNames.Account*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47245990719)
            
            //--TRIMMABLE-BOUNDARY-START(42951023423)
            /*Pager<UserModel> */ GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951023423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$Iaui.LCFCM.UserModel, this.server, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951023423)
            
            //--TRIMMABLE-BOUNDARY-START(4295243228)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider<LivingThing.Core.Frameworks.Common.Models.UserModel>.GetContacts()
            LCFCM$IMessageComposerProvider$$$GetContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295243228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetContacts(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295243228)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 1350463;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835925311),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656056127,
        "f": 50331649
      },
      "n": "Title",
      "d": 1350463,
      "h": 55835925311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835925311),
//--TRIMMABLE-BOUNDARY-START(12886252351),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476186943,
        "f": 50331649
      },
      "n": "Description",
      "d": 1350463,
      "h": 12886252351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886252351),
//--TRIMMABLE-BOUNDARY-START(47245990719),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066121535,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1350463,
      "h": 47245990719,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245990719)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951023423),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$Iaui.LCFCM.UserModel).$h,
      "n": "GetContacts",
      "d": 1350463,
      "h": 42951023423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951023423)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540958015),
    {
      "t": 1309651,
      "n": "server",
      "d": 1350463,
      "h": 51540958015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540958015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591285055),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1350463,
      "h": 8591285055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591285055)
  ],
  "h": 1350463
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessageComposerProvider$$($.$Iaui.LCFCM.UserModel), $.$UrvY.LCFCM.IMessageComposerProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Client.Services.UserMesssageComposerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Client${separator}Services${separator}UserMesssageComposerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1350463)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Admin.Common", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(39743)
