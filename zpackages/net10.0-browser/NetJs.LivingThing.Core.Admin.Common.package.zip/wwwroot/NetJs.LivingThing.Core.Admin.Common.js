
//--TRIMMABLE-BOUNDARY-START(54393)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $kVHt, $Iaui, $uvJL) {
    "use strict";
    let _;
    let $xMwodk;
    let $fPBnQa;
    let $rvjhki;
    let $wmYwwf;
    let $PbDsHa;
    let $OFzjBk;
    let $Lflcge;
    let $IllOuf;
    let $fPoOVb;
    let $MaTPEd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Admin.Common", 
    {
  "h": 54393,
  "f": "LivingThing.Core.Admin.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Admin.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Admin.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(840825)
        $asm.$cls(`$ajwi.LCACS.IAdminTableColumnEditor`, ($self) => class IAdminTableColumnEditor
        {
            static $h = 840825;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295808121),
    {
      "r": 262145,
      "p": [
        {
          "n": "table",
          "p": 644217
        },
        {
          "n": "column",
          "p": 578681
        }
      ],
      "n": "CanEdit",
      "o": "LCACS$IAdminTableColumnEditor$CanEdit",
      "d": 840825,
      "h": 4295808121,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295808121),
//--TRIMMABLE-BOUNDARY-START(8590775417),
    {
      "r": 178454529,
      "p": [
        {
          "n": "definitions",
          "p": 513145
        },
        {
          "n": "table",
          "p": 644217
        },
        {
          "n": "column",
          "p": 578681
        },
        {
          "n": "rowData",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IObservableDataDescriptor).$h
        },
        {
          "n": "columnData",
          "p": 40536406
        }
      ],
      "n": "Edit",
      "o": "LCACS$IAdminTableColumnEditor$Edit",
      "d": 840825,
      "h": 8590775417,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590775417)
  ],
  "h": 840825
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Services.IAdminTableColumnEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Services${separator}IAdminTableColumnEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(840825)
        
        

        //--TRIMMABLE-BOUNDARY-START(251001)
        $asm.$cls(`$ajwi.LCACM.IAdminDataTableProvider`, ($self) => class IAdminDataTableProvider
        {
            static $h = 251001;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590185593),
    {
      "r": 513145,
      "n": "GetTableDefinition",
      "o": "LCACM$IAdminDataTableProvider$GetTableDefinition",
      "d": 251001,
      "h": 8590185593,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590185593),
//--TRIMMABLE-BOUNDARY-START(4295218297),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel).$h,
      "p": [
        {
          "n": "models",
          "p": 4466006
        }
      ],
      "n": "CRUD",
      "o": "LCACM$IAdminDataTableProvider$CRUD",
      "d": 251001,
      "h": 4295218297,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295218297),
//--TRIMMABLE-BOUNDARY-START(12885152889),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))).$h,
      "p": [
        {
          "n": "model",
          "p": 14099798
        }
      ],
      "n": "ReadSingle",
      "o": "LCACM$IAdminDataTableProvider$ReadSingle",
      "d": 251001,
      "h": 12885152889,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885152889),
//--TRIMMABLE-BOUNDARY-START(17180120185),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))).$h,
      "p": [
        {
          "n": "model",
          "p": 13575510
        }
      ],
      "n": "ReadTable",
      "o": "LCACM$IAdminDataTableProvider$ReadTable",
      "d": 251001,
      "h": 17180120185,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180120185)
  ],
  "h": 251001
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.IAdminDataTableProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}IAdminDataTableProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(251001)
        
        

        //--TRIMMABLE-BOUNDARY-START(775289)
        $asm.$cls(`$ajwi.LCACS.IAdminRemoteService`, ($self) => class IAdminRemoteService
        {
            static $h = 775289;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180644473),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$ajwi.LCAM.AdminModel)).$h,
      "n": "Load",
      "o": "LCACS$IAdminRemoteService$Load",
      "d": 775289,
      "h": 17180644473,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180644473),
//--TRIMMABLE-BOUNDARY-START(4295742585),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel).$h,
      "p": [
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "models",
          "p": 4466006
        }
      ],
      "n": "CRUD",
      "o": "LCACS$IAdminRemoteService$CRUD",
      "d": 775289,
      "h": 4295742585,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295742585),
//--TRIMMABLE-BOUNDARY-START(21475611769),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))).$h,
      "p": [
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "model",
          "p": 14099798
        }
      ],
      "n": "ReadSingle",
      "o": "LCACS$IAdminRemoteService$ReadSingle",
      "d": 775289,
      "h": 21475611769,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475611769),
//--TRIMMABLE-BOUNDARY-START(25770579065),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))).$h,
      "p": [
        {
          "n": "providerName",
          "p": 1310721
        },
        {
          "n": "model",
          "p": 13575510
        }
      ],
      "n": "ReadTable",
      "o": "LCACS$IAdminRemoteService$ReadTable",
      "d": 775289,
      "h": 25770579065,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770579065),
//--TRIMMABLE-BOUNDARY-START(12885677177),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$ajwi.LCACM.ServiceTaskModel)).$h,
      "n": "GetServiceTasks",
      "o": "LCACS$IAdminRemoteService$GetServiceTasks",
      "d": 775289,
      "h": 12885677177,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885677177),
//--TRIMMABLE-BOUNDARY-START(30065546361),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$ajwi.LCACM.ServiceParameterModel).$h
        }
      ],
      "n": "StartServiceTask",
      "o": "LCACS$IAdminRemoteService$StartServiceTask",
      "d": 775289,
      "h": 30065546361,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065546361),
//--TRIMMABLE-BOUNDARY-START(34360513657),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        }
      ],
      "n": "StopServiceTask",
      "o": "LCACS$IAdminRemoteService$StopServiceTask",
      "d": 775289,
      "h": 34360513657,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360513657),
//--TRIMMABLE-BOUNDARY-START(8590709881),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCAM.StatusStore)))).$h,
      "n": "GetAppStatuses",
      "o": "LCACS$IAdminRemoteService$GetAppStatuses",
      "d": 775289,
      "h": 8590709881,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590709881)
  ],
  "h": 775289,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Services.IAdminRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Services${separator}IAdminRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(775289)
        
        

        //--TRIMMABLE-BOUNDARY-START(185465)
        $asm.$cls(`$ajwi.LCACH.IAdminHubServer`, ($self) => class IAdminHubServer
        {
            static $h = 185465;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295152761),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "SendToService",
      "o": "LCACH$IAdminHubServer$SendToService",
      "d": 185465,
      "h": 4295152761,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295152761)
  ],
  "h": 185465
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Hubs.IAdminHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Hubs${separator}IAdminHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(185465)
        
        

        //--TRIMMABLE-BOUNDARY-START(119929)
        $asm.$cls(`$ajwi.LCACH.IAdminHubClient`, ($self) => class IAdminHubClient
        {
            static $h = 119929;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474956409),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteServiceConsole",
      "o": "LCACH$IAdminHubClient$WriteServiceConsole",
      "d": 119929,
      "h": 21474956409,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474956409),
//--TRIMMABLE-BOUNDARY-START(12885021817),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ServiceException",
      "o": "LCACH$IAdminHubClient$ServiceException",
      "d": 119929,
      "h": 12885021817,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885021817),
//--TRIMMABLE-BOUNDARY-START(17179989113),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceId",
          "p": 1310721
        },
        {
          "n": "exitCode",
          "p": 655361
        }
      ],
      "n": "ServiceExited",
      "o": "LCACH$IAdminHubClient$ServiceExited",
      "d": 119929,
      "h": 17179989113,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17179989113),
//--TRIMMABLE-BOUNDARY-START(4295087225),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1037433
        }
      ],
      "n": "AddStatusStore",
      "o": "LCACH$IAdminHubClient$AddStatusStore",
      "d": 119929,
      "h": 4295087225,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295087225),
//--TRIMMABLE-BOUNDARY-START(8590054521),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uuid",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "RemoveStatusStore",
      "o": "LCACH$IAdminHubClient$RemoveStatusStore",
      "d": 119929,
      "h": 8590054521,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590054521)
  ],
  "h": 119929
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Hubs.IAdminHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Hubs${separator}IAdminHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(119929)
        
        

        //--TRIMMABLE-BOUNDARY-START(971897)
        $asm.$cls(`$ajwi.LCAM.PluginBaseModel`, ($self) => class PluginBaseModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835546745)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55835546745)
            
            //--TRIMMABLE-BOUNDARY-START(21475808377)
            /*string*/ FullName = null;
            //--TRIMMABLE-BOUNDARY-END(21475808377)
            
            //--TRIMMABLE-BOUNDARY-START(51540579449)
            /*int*/ Instances = 0;
            //--TRIMMABLE-BOUNDARY-END(51540579449)
            
            //--TRIMMABLE-BOUNDARY-START(17180841081)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180841081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180841081)
            
            //--TRIMMABLE-BOUNDARY-START(17180841081)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180841081)
            
            static $h = 971897;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835546745),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245612153,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605350521,
        "f": 83886081
      },
      "n": "Name",
      "d": 971897,
      "h": 55835546745,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835546745),
//--TRIMMABLE-BOUNDARY-START(21475808377),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065742969,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425481337,
        "f": 83886081
      },
      "n": "FullName",
      "d": 971897,
      "h": 21475808377,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475808377),
//--TRIMMABLE-BOUNDARY-START(51540579449),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655677561,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015415929,
        "f": 83886081
      },
      "n": "Instances",
      "d": 971897,
      "h": 51540579449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540579449)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180841081),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 971897,
      "h": 17180841081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180841081)
  ],
  "h": 971897
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Models.PluginBaseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Models${separator}PluginBaseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(971897)
        
        

        //--TRIMMABLE-BOUNDARY-START(382073)
        $asm.$cls(`$ajwi.LCACM.ServiceTaskModel`, ($self) => class ServiceTaskModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90194695289)
            /*string*/ ServiceId = null;
            //--TRIMMABLE-BOUNDARY-END(90194695289)
            
            //--TRIMMABLE-BOUNDARY-START(81604760697)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(81604760697)
            
            //--TRIMMABLE-BOUNDARY-START(30065153145)
            /*string*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30065153145)
            
            //--TRIMMABLE-BOUNDARY-START(77309793401)
            /*bool*/ IsRunning = false;
            //--TRIMMABLE-BOUNDARY-END(77309793401)
            
            //--TRIMMABLE-BOUNDARY-START(85899727993)
            /*IEnumerable<ServiceParameterModel>*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(85899727993)
            
            //--TRIMMABLE-BOUNDARY-START(25770185849)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770185849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770185849)
            
            //--TRIMMABLE-BOUNDARY-START(25770185849)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770185849)
            
            static $h = 382073;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194695289),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014826105,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144368249,
        "f": 83886081
      },
      "n": "ServiceId",
      "d": 382073,
      "h": 90194695289,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194695289),
//--TRIMMABLE-BOUNDARY-START(81604760697),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834956921,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964499065,
        "f": 83886081
      },
      "n": "Name",
      "d": 382073,
      "h": 81604760697,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604760697),
//--TRIMMABLE-BOUNDARY-START(30065153145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655087737,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784629881,
        "f": 83886081
      },
      "n": "Description",
      "d": 382073,
      "h": 30065153145,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065153145),
//--TRIMMABLE-BOUNDARY-START(77309793401),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245022329,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374564473,
        "f": 83886081
      },
      "n": "IsRunning",
      "d": 382073,
      "h": 77309793401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309793401),
//--TRIMMABLE-BOUNDARY-START(85899727993),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.ServiceParameterModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424891513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554433657,
        "f": 83886081
      },
      "n": "Parameters",
      "d": 382073,
      "h": 85899727993,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899727993)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770185849),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 382073,
      "h": 25770185849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770185849)
  ],
  "h": 382073
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.ServiceTaskModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}ServiceTaskModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382073)
        
        

        //--TRIMMABLE-BOUNDARY-START(1037433)
        $asm.$cls(`$ajwi.LCAM.StatusStore`, ($self) => class StatusStore extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770841209)
            /*DateTime*/ DateCreated;
            //--TRIMMABLE-BOUNDARY-END(25770841209)
            
            //--TRIMMABLE-BOUNDARY-START(111670187129)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(111670187129)
            
            //--TRIMMABLE-BOUNDARY-START(30065808505)
            /*bool*/ Editable = false;
            //--TRIMMABLE-BOUNDARY-END(30065808505)
            
            //--TRIMMABLE-BOUNDARY-START(68720514169)
            /*bool*/ Persist = false;
            //--TRIMMABLE-BOUNDARY-END(68720514169)
            
            //--TRIMMABLE-BOUNDARY-START(107375219833)
            /*bool */ ShouldSerializePersist()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375219833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375219833)
            
            //--TRIMMABLE-BOUNDARY-START(21475873913)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475873913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475873913)
            
            //--TRIMMABLE-BOUNDARY-START(21475873913)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475873913)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770841209)
                this.DateCreated = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(25770841209)
                
            }
            static $h = 1037433;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770841209),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655743097,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310448761,
        "f": 83886081
      },
      "n": "DateCreated",
      "d": 1037433,
      "h": 25770841209,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770841209),
//--TRIMMABLE-BOUNDARY-START(111670187129),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425546873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080252537,
        "f": 83886081
      },
      "n": "Value",
      "d": 1037433,
      "h": 111670187129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670187129),
//--TRIMMABLE-BOUNDARY-START(30065808505),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245677689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900383353,
        "f": 83886081
      },
      "n": "Editable",
      "d": 1037433,
      "h": 30065808505,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065808505),
//--TRIMMABLE-BOUNDARY-START(68720514169),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835612281,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490317945,
        "f": 83886081
      },
      "n": "Persist",
      "d": 1037433,
      "h": 68720514169,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720514169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375219833),
    {
      "r": 262145,
      "n": "ShouldSerializePersist",
      "d": 1037433,
      "h": 107375219833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375219833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475873913),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1037433,
      "h": 21475873913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475873913)
  ],
  "h": 1037433
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Models.StatusStore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Models${separator}StatusStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1037433)
        
        

        //--TRIMMABLE-BOUNDARY-START(513145)
        $asm.$cls(`$ajwi.LCACM.TableDefinition`, ($self) => class TableDefinition extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42950186105)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(42950186105)
            
            //--TRIMMABLE-BOUNDARY-START(73014957177)
            /*IEnumerable<TableRowType>*/ Tables = null;
            //--TRIMMABLE-BOUNDARY-END(73014957177)
            
            //--TRIMMABLE-BOUNDARY-START(64425022585)
            static /*IEnumerable<Common.Models.TablePropertyColumn> */ Sort(/*IEnumerable<TablePropertyColumn>*/ columns)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425022585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.OrderBy$1($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Int32, columns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Int32))().$ctor(this,  (/*column*/ column) =>
                {
                    if ($.$$.S.String.Equals$2.call(column.Name, "ID", 3/*StringComparison.InvariantCultureIgnoreCase*/))
                    {
                        return -2147483648/*int.MinValue*/;
                    }
                    if ($.$$.S.String.EndsWith$3.call(column.Name, "ID"))
                    {
                        return ((-2147483648/*int.MinValue*/ + 1) | 0);
                    }
                    if ($.$$.S.String.Contains$3.call(column.Name, "Date"))
                    {
                        return ((-2147483648/*int.MinValue*/ + 3) | 0);
                    }
                    if ($.$$.S.String.StartsWith$3.call(column.Name, "Is"))
                    {
                        return ((-2147483648/*int.MinValue*/ + 4) | 0);
                    }
                    if ($.$$.S.String.EndsWith$2.call($.$$.S.String.ToLower.call(column.Name), "ID", 3/*StringComparison.InvariantCultureIgnoreCase*/) || $.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 21/*DataType.Class*/)
                    {
                        return ((-2147483648/*int.MinValue*/ + 5) | 0);
                    }
                    if ($.$$.System.Array.$ReadT1.call(column.ValueType.LCFCD$1$ITypeDescriptor$DataTypes, 0) === 134217728/*DataType.Array*/)
                    {
                        return ((-2147483648/*int.MinValue*/ + 6) | 0);
                    }
                    if (column.Name === "Flags")
                    {
                        return ((-2147483648/*int.MinValue*/ + 7) | 0);
                    }
                    if ($.$is(column.ValueType, $.$fPer.LCFCD$1.VoidTypeDescriptor))
                    {
                        return ((-2147483648/*int.MinValue*/ + 2) | 0);
                    }
                    return 0;
                }, $wmYwwf ??= {"r":655361,"p":[{"n":"column","p":578681}],"n":"","d":513145,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(64425022585)
            
            //--TRIMMABLE-BOUNDARY-START(38655218809)
            /*IEnumerable<TablePropertyColumn> */ GetPropertiesDeep(/*TableRowType*/ tableModel)
            {
                return new ($.$$.N.YieldToIterator$$($.$ajwi.LCACM.TablePropertyColumn))().$ctor$1(function*()
                {
                    /*var*/ let baseTableModel = $.$sl.SL.Enumerable.FirstOrDefault$3($.$ajwi.LCACM.TableRowType, $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TableRowType, $.$sl.SL.Enumerable.Except$1($.$ajwi.LCACM.TableRowType, this.Tables, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ajwi.LCACM.TableRowType), [tableModel], null, null)), new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.S.Boolean))().$ctor(this,  (/*tbm*/ tbm) =>
                    {
                        return $.$$.System.Array.$ReadT1.call(tbm.Aliases, 0) !== null && $.$$.S.String.Equals$5.call($.$$.System.Array.$ReadT1.call(tbm.Aliases, 0), tableModel.BaseType);
                    }, $PbDsHa ??= {"r":262145,"p":[{"n":"tbm","p":644217}],"n":"","d":513145,"h":0,"f":17825794})));
                    if (baseTableModel !== null)
                    {
                        /*var*/ let ps = this.GetPropertiesDeep(baseTableModel);
                        let $en1 = ps.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let p = $en1.SCG$IEnumerator$$$Current;
                            {
                                if (!$.$sl.SL.Enumerable.Any($.$ajwi.LCACM.TablePropertyColumn, tableModel.PropertyColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                                {
                                    return a.Name === p.Name;
                                }, $OFzjBk ??= {"r":262145,"p":[{"n":"a","p":578681}],"n":"","d":513145,"h":0,"f":17825794})))
                                {
                                    yield p;
                                }
                            }
                        }
                    }
                    let $en2 = tableModel.PropertyColumns.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en2.SCG$IEnumerator$$$Current;
                        {
                            yield p;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(38655218809)
            
            //--TRIMMABLE-BOUNDARY-START(68719989881)
            /*IEnumerable<TableRowType> */ SubClassesOf(/*TableRowType*/ table)
            {
                return new ($.$$.N.YieldToIterator$$($.$ajwi.LCACM.TableRowType))().$ctor$1(function*()
                {
                    /*var*/ let results = $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TableRowType, this.Tables, new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.S.Boolean))().$ctor(this,  (/*tbm*/ tbm) =>
                    {
                        /*string?*/ let __ca1__;
                        return ((__ca1__ = tbm.BaseType) !== null ? $.$$.S.String.Equals$5.call(__ca1__, $.$$.System.Array.$ReadT1.call(table.Aliases, 0)) : false);
                    }, $Lflcge ??= {"r":262145,"p":[{"n":"tbm","p":644217}],"n":"","d":513145,"h":0,"f":17825794}));
                    let $en3 = results.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en3.SCG$IEnumerator$$$Current;
                        {
                            yield p;
                        }
                    }
                    let $en4 = $.$sl.SL.Enumerable.SelectMany$2($.$ajwi.LCACM.TableRowType, $.$ajwi.LCACM.TableRowType, results, new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType)))().$ctor(this,  (/*r*/ r) =>
                    {
                        return this.SubClassesOf(r);
                    }, $IllOuf ??= {"r":$.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType).$h,"p":[{"n":"r","p":644217}],"n":"","d":513145,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en4.SCG$IEnumerator$$$Current;
                        {
                            yield p;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(68719989881)
            
            //--TRIMMABLE-BOUNDARY-START(17180382329)
            /*IEnumerable<TableRowType> */ BaseClassesOf(/*TableRowType*/ table)
            {
                return new ($.$$.N.YieldToIterator$$($.$ajwi.LCACM.TableRowType))().$ctor$1(function*()
                {
                    /*var*/ let results = $.$sl.SL.Enumerable.Where($.$ajwi.LCACM.TableRowType, this.Tables, new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.S.Boolean))().$ctor(this,  (/*tbm*/ tbm) =>
                    {
                        return $.$$.S.String.Equals$5.call($.$$.System.Array.$ReadT1.call(tbm.Aliases, 0), table.BaseType);
                    }, $fPoOVb ??= {"r":262145,"p":[{"n":"tbm","p":644217}],"n":"","d":513145,"h":0,"f":17825794}));
                    let $en5 = results.SCG$IEnumerable$$$GetEnumerator();
                    while ($en5.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en5.SCG$IEnumerator$$$Current;
                        {
                            yield p;
                        }
                    }
                    let $en6 = $.$sl.SL.Enumerable.SelectMany$2($.$ajwi.LCACM.TableRowType, $.$ajwi.LCACM.TableRowType, results, new ($.$$.S.Func$$$($.$ajwi.LCACM.TableRowType, $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType)))().$ctor(this,  (/*r*/ r) =>
                    {
                        return this.BaseClassesOf(r);
                    }, $MaTPEd ??= {"r":$.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType).$h,"p":[{"n":"r","p":644217}],"n":"","d":513145,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en6.SCG$IEnumerator$$$Current;
                        {
                            yield p;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180382329)
            
            //--TRIMMABLE-BOUNDARY-START(12885415033)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885415033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885415033)
            
            //--TRIMMABLE-BOUNDARY-START(12885415033)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885415033)
            
            static $h = 513145;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950186105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770316921,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540120697,
        "f": 83886081
      },
      "n": "Name",
      "d": 513145,
      "h": 42950186105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950186105),
//--TRIMMABLE-BOUNDARY-START(73014957177),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360251513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130055289,
        "f": 83886081
      },
      "n": "Tables",
      "d": 513145,
      "h": 73014957177,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014957177)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425022585),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "p": [
        {
          "n": "columns",
          "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h
        }
      ],
      "n": "Sort",
      "d": 513145,
      "h": 64425022585,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425022585),
//--TRIMMABLE-BOUNDARY-START(38655218809),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "p": [
        {
          "n": "tableModel",
          "p": 644217
        }
      ],
      "n": "GetPropertiesDeep",
      "d": 513145,
      "h": 38655218809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655218809),
//--TRIMMABLE-BOUNDARY-START(68719989881),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType).$h,
      "p": [
        {
          "n": "table",
          "p": 644217
        }
      ],
      "n": "SubClassesOf",
      "d": 513145,
      "h": 68719989881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719989881),
//--TRIMMABLE-BOUNDARY-START(17180382329),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TableRowType).$h,
      "p": [
        {
          "n": "table",
          "p": 644217
        }
      ],
      "n": "BaseClassesOf",
      "d": 513145,
      "h": 17180382329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180382329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885415033),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 513145,
      "h": 12885415033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885415033)
  ],
  "h": 513145
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.TableDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}TableDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513145)
        
        

        //--TRIMMABLE-BOUNDARY-START(447609)
        $asm.$cls(`$ajwi.LCACM.TableColumnType`, ($self) => class TableColumnType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540055161)
            /*DataType[]*/ DataTypes = null;
            //--TRIMMABLE-BOUNDARY-END(51540055161)
            
            //--TRIMMABLE-BOUNDARY-START(42950120569)
            /*string[]*/ Aliases = null;
            //--TRIMMABLE-BOUNDARY-END(42950120569)
            
            //--TRIMMABLE-BOUNDARY-START(214748812409)
            /*Type?*/ systemType = null;
            //--TRIMMABLE-BOUNDARY-END(214748812409)
            
            //--TRIMMABLE-BOUNDARY-START(219043779705)
            /*Type */ get SystemType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849466489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.systemType ?? $.$fPer.LCFCD$1.SystemTypeDescriptor.GetRuntimeType($.$$.System.Array.$ReadT1.call(this.DataTypes, 0));
            }
            /*Type */ set SystemType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453845113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.systemType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(219043779705)
            
            //--TRIMMABLE-BOUNDARY-START(146029335673)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(146029335673)
            
            //--TRIMMABLE-BOUNDARY-START(141734368377)
            /*string*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(141734368377)
            
            //--TRIMMABLE-BOUNDARY-START(137439401081)
            /*DataActivator*/ InstanceActivator;
            //--TRIMMABLE-BOUNDARY-END(137439401081)
            
            //--TRIMMABLE-BOUNDARY-START(133144433785)
            /*object? */ GetDefaultValue(/*bool?*/ notNull)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144433785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCD$1.SystemTypeDescriptor.GetDefaultValue$1(this.SystemType, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144433785)
            
            //--TRIMMABLE-BOUNDARY-START(150324302969)
            /*IReadOnlyDictionary<string, IPropertyDescriptor>*/ Properties = null;
            //--TRIMMABLE-BOUNDARY-END(150324302969)
            
            //--TRIMMABLE-BOUNDARY-START(60129989753)
            /*string*/ ElementType = null;
            //--TRIMMABLE-BOUNDARY-END(60129989753)
            
            //--TRIMMABLE-BOUNDARY-START(47245087865)
            /*ITypeDescriptor */ ApplyTo(/*SchemaContext*/ schema, /*ServiceFactory*/ factory, /*params OneOf<object, Func<object>, IValueProvider>[]*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245087865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245087865)
            
            //--TRIMMABLE-BOUNDARY-START(55835022457)
            /*IObservableDataDescriptor */ DefineValue(/*string*/ name, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835022457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835022457)
            
            //--TRIMMABLE-BOUNDARY-START(38655153273)
            /*bool */ AcceptVisitor(TVisitor, /*ref TVisitor*/ visitor, /*ref object?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655153273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(38655153273)
            
            //--TRIMMABLE-BOUNDARY-START(68760930646)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Name.get
            get LCFCD$1$ITypeDescriptor$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103120669014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(68760930646)
            
            //--TRIMMABLE-BOUNDARY-START(60170996054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Label.get
            get LCFCD$1$ITypeDescriptor$Label()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98825701718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Label;
            }
            //--TRIMMABLE-BOUNDARY-END(60170996054)
            
            //--TRIMMABLE-BOUNDARY-START(42991126870)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.DataTypes.get
            get LCFCD$1$ITypeDescriptor$DataTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21516290390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DataTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(42991126870)
            
            //--TRIMMABLE-BOUNDARY-START(34401192278)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Aliases.get
            get LCFCD$1$ITypeDescriptor$Aliases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8631388502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Aliases;
            }
            //--TRIMMABLE-BOUNDARY-END(34401192278)
            
            //--TRIMMABLE-BOUNDARY-START(85940799830)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.SystemType.get
            get LCFCD$1$ITypeDescriptor$SystemType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111710603606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SystemType;
            }
            //--TRIMMABLE-BOUNDARY-END(85940799830)
            
            //--TRIMMABLE-BOUNDARY-START(90235767126)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.GetDefaultValue(bool?)
            LCFCD$1$ITypeDescriptor$GetDefaultValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90235767126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(90235767126)
            
            //--TRIMMABLE-BOUNDARY-START(51581061462)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.InstanceActivator.get
            get LCFCD$1$ITypeDescriptor$InstanceActivator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94530734422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InstanceActivator;
            }
            //--TRIMMABLE-BOUNDARY-END(51581061462)
            
            //--TRIMMABLE-BOUNDARY-START(77350865238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Properties.get
            get LCFCD$1$ITypeDescriptor$Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107415636310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Properties;
            }
            //--TRIMMABLE-BOUNDARY-END(77350865238)
            
            //--TRIMMABLE-BOUNDARY-START(25811257686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.DefineValue(string, object?)
            LCFCD$1$ITypeDescriptor$DefineValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25811257686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DefineValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25811257686)
            
            //--TRIMMABLE-BOUNDARY-START(12926355798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.ApplyTo(LivingThing.Core.Frameworks.Common.Attributes.SchemaContext, LivingThing.Core.Frameworks.Common.Services.ServiceFactory?, params LivingThing.Core.Frameworks.Common.OneOf.OneOf<object?, System.Func<object?>?, LivingThing.Core.Frameworks.Common.Data.IValueProvider?>[])
            LCFCD$1$ITypeDescriptor$ApplyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12926355798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12926355798)
            
            //--TRIMMABLE-BOUNDARY-START(4336421206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.AcceptVisitor<TVisitor>(ref TVisitor, ref object?)
            LCFCD$1$ITypeDescriptor$AcceptVisitor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4336421206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AcceptVisitor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4336421206)
            
            //--TRIMMABLE-BOUNDARY-START(34360185977)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360185977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360185977)
            
            //--TRIMMABLE-BOUNDARY-START(34360185977)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360185977)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137439401081)
                this.InstanceActivator = $.$default($.$fPer.LCFCD.DataActivator);
                //--TRIMMABLE-BOUNDARY-END(137439401081)
                
            }
            static $h = 447609;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540055161),
    {
      "p": $.$typeArray($.$fPer.LCFCD.DataType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309858937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504172153,
        "f": 83886081
      },
      "n": "DataTypes",
      "d": 447609,
      "h": 51540055161,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540055161),
//--TRIMMABLE-BOUNDARY-START(42950120569),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719924345,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914237561,
        "f": 83886081
      },
      "n": "Aliases",
      "d": 447609,
      "h": 42950120569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950120569),
//--TRIMMABLE-BOUNDARY-START(219043779705),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849466489,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453845113,
        "f": 83886081
      },
      "n": "SystemType",
      "d": 447609,
      "h": 219043779705,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043779705),
//--TRIMMABLE-BOUNDARY-START(146029335673),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669597305,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863910521,
        "f": 83886081
      },
      "n": "Name",
      "d": 447609,
      "h": 146029335673,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029335673),
//--TRIMMABLE-BOUNDARY-START(141734368377),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079662713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273975929,
        "f": 83886081
      },
      "n": "Label",
      "d": 447609,
      "h": 141734368377,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734368377),
//--TRIMMABLE-BOUNDARY-START(137439401081),
    {
      "p": 8423766,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489728121,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684041337,
        "f": 83886081
      },
      "n": "InstanceActivator",
      "d": 447609,
      "h": 137439401081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439401081),
//--TRIMMABLE-BOUNDARY-START(150324302969),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259531897,
        "f": 50331649
      },
      "n": "Properties",
      "d": 447609,
      "h": 150324302969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324302969),
//--TRIMMABLE-BOUNDARY-START(60129989753),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899793529,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094106745,
        "f": 83886081
      },
      "n": "ElementType",
      "d": 447609,
      "h": 60129989753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129989753)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133144433785),
    {
      "r": 131073,
      "p": [
        {
          "n": "notNull",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetDefaultValue",
      "d": 447609,
      "h": 133144433785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144433785),
//--TRIMMABLE-BOUNDARY-START(47245087865),
    {
      "r": 41453910,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "target",
          "p": $.$typeArray($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider)).$h,
          "f": 16
        }
      ],
      "n": "ApplyTo",
      "d": 447609,
      "h": 47245087865,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245087865),
//--TRIMMABLE-BOUNDARY-START(55835022457),
    {
      "r": 40536406,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "DefineValue",
      "d": 447609,
      "h": 55835022457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835022457),
//--TRIMMABLE-BOUNDARY-START(38655153273),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 131073,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "d": 447609,
      "h": 38655153273,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(38655153273)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(214748812409),
    {
      "t": 188547073,
      "n": "systemType",
      "d": 447609,
      "h": 214748812409,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(214748812409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360185977),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 447609,
      "h": 34360185977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360185977)
  ],
  "h": 447609
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.TableColumnType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}TableColumnType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(447609)
        
        

        //--TRIMMABLE-BOUNDARY-START(644217)
        $asm.$cls(`$ajwi.LCACM.TableRowType`, ($self) => class TableRowType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81605022841)
            /*DataType[]*/ DataTypes = null;
            //--TRIMMABLE-BOUNDARY-END(81605022841)
            
            //--TRIMMABLE-BOUNDARY-START(60130186361)
            /*string[]*/ Aliases = null;
            //--TRIMMABLE-BOUNDARY-END(60130186361)
            
            //--TRIMMABLE-BOUNDARY-START(309238289529)
            /*Type */ get SystemType()
            {
                return $.$fPer.LCFCD$1.SystemTypeDescriptor.GetRuntimeType($.$$.System.Array.$ReadT1.call(this.DataTypes, 0));
            }
            //--TRIMMABLE-BOUNDARY-END(309238289529)
            
            //--TRIMMABLE-BOUNDARY-START(210454041721)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(210454041721)
            
            //--TRIMMABLE-BOUNDARY-START(206159074425)
            /*string*/ Label = null;
            //--TRIMMABLE-BOUNDARY-END(206159074425)
            
            //--TRIMMABLE-BOUNDARY-START(73015088249)
            /*int*/ AutoRefreshInterval = 0;
            //--TRIMMABLE-BOUNDARY-END(73015088249)
            
            //--TRIMMABLE-BOUNDARY-START(193274172537)
            /*object? */ GetDefaultValue(/*bool?*/ notNull)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274172537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCD$1.SystemTypeDescriptor.GetDefaultValue$1(this.SystemType, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274172537)
            
            //--TRIMMABLE-BOUNDARY-START(197569139833)
            /*DataActivator*/ InstanceActivator;
            //--TRIMMABLE-BOUNDARY-END(197569139833)
            
            //--TRIMMABLE-BOUNDARY-START(219043976313)
            /*IEnumerable<TablePropertyColumn>*/ PropertyColumns = null;
            //--TRIMMABLE-BOUNDARY-END(219043976313)
            
            //--TRIMMABLE-BOUNDARY-START(4295611513)
            /*IReadOnlyDictionary<string, IPropertyDescriptor>?*/ _properties = null;
            //--TRIMMABLE-BOUNDARY-END(4295611513)
            
            //--TRIMMABLE-BOUNDARY-START(214749009017)
            /*IReadOnlyDictionary<string, IPropertyDescriptor> */ get Properties()
            {
                return this._properties ??= $.$sl.SL.Enumerable.ToDictionary$5($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String, $.$fPer.LCFCD$1.IPropertyDescriptor, this.PropertyColumns, new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Name;
                }, $xMwodk ??= {"r":1310721,"p":[{"n":"p","p":578681}],"n":"","d":644217,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$ajwi.LCACM.TablePropertyColumn, $.$fPer.LCFCD$1.IPropertyDescriptor))().$ctor(this,  (/*p*/ p) =>
                {
                    return p;
                }, $fPBnQa ??= {"r":40733014,"p":[{"n":"p","p":578681}],"n":"","d":644217,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(214749009017)
            
            //--TRIMMABLE-BOUNDARY-START(68720120953)
            /*string*/ AssemblyGroup = null;
            //--TRIMMABLE-BOUNDARY-END(68720120953)
            
            //--TRIMMABLE-BOUNDARY-START(77310055545)
            /*string?*/ BaseType = null;
            //--TRIMMABLE-BOUNDARY-END(77310055545)
            
            //--TRIMMABLE-BOUNDARY-START(201864107129)
            /*bool*/ IsAbstract = false;
            //--TRIMMABLE-BOUNDARY-END(201864107129)
            
            //--TRIMMABLE-BOUNDARY-START(64425153657)
            /*ITypeDescriptor */ ApplyTo(/*SchemaContext*/ schema, /*ServiceFactory*/ factory, /*params OneOf<object, Func<object>, IValueProvider>[]*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425153657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425153657)
            
            //--TRIMMABLE-BOUNDARY-START(85899990137)
            /*IObservableDataDescriptor */ DefineValue(/*string*/ name, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899990137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85899990137)
            
            //--TRIMMABLE-BOUNDARY-START(313533256825)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533256825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                const $t1 = this.Aliases;
                if ($.$$.S.Int32.op_GreaterThan($.$ifnn($t1, ($t) => $t.length), 0))
                {
                    return `${$.$strNN($.$$.System.Array.$ReadT1.call(this.Aliases, 0))}-${$.$strNN(this.Name)}`;
                }
                return `${$.$strNN(this.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(313533256825)
            
            //--TRIMMABLE-BOUNDARY-START(55835219065)
            /*bool */ AcceptVisitor(TVisitor, /*ref TVisitor*/ visitor, /*ref object?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835219065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(55835219065)
            
            //--TRIMMABLE-BOUNDARY-START(68760930646)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Name.get
            get LCFCD$1$ITypeDescriptor$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103120669014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(68760930646)
            
            //--TRIMMABLE-BOUNDARY-START(60170996054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Label.get
            get LCFCD$1$ITypeDescriptor$Label()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98825701718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Label;
            }
            //--TRIMMABLE-BOUNDARY-END(60170996054)
            
            //--TRIMMABLE-BOUNDARY-START(42991126870)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.DataTypes.get
            get LCFCD$1$ITypeDescriptor$DataTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21516290390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DataTypes;
            }
            //--TRIMMABLE-BOUNDARY-END(42991126870)
            
            //--TRIMMABLE-BOUNDARY-START(34401192278)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Aliases.get
            get LCFCD$1$ITypeDescriptor$Aliases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8631388502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Aliases;
            }
            //--TRIMMABLE-BOUNDARY-END(34401192278)
            
            //--TRIMMABLE-BOUNDARY-START(85940799830)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.SystemType.get
            get LCFCD$1$ITypeDescriptor$SystemType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111710603606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SystemType;
            }
            //--TRIMMABLE-BOUNDARY-END(85940799830)
            
            //--TRIMMABLE-BOUNDARY-START(90235767126)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.GetDefaultValue(bool?)
            LCFCD$1$ITypeDescriptor$GetDefaultValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90235767126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(90235767126)
            
            //--TRIMMABLE-BOUNDARY-START(51581061462)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.InstanceActivator.get
            get LCFCD$1$ITypeDescriptor$InstanceActivator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94530734422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InstanceActivator;
            }
            //--TRIMMABLE-BOUNDARY-END(51581061462)
            
            //--TRIMMABLE-BOUNDARY-START(77350865238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.Properties.get
            get LCFCD$1$ITypeDescriptor$Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107415636310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Properties;
            }
            //--TRIMMABLE-BOUNDARY-END(77350865238)
            
            //--TRIMMABLE-BOUNDARY-START(25811257686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.DefineValue(string, object?)
            LCFCD$1$ITypeDescriptor$DefineValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25811257686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DefineValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25811257686)
            
            //--TRIMMABLE-BOUNDARY-START(12926355798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.ApplyTo(LivingThing.Core.Frameworks.Common.Attributes.SchemaContext, LivingThing.Core.Frameworks.Common.Services.ServiceFactory?, params LivingThing.Core.Frameworks.Common.OneOf.OneOf<object?, System.Func<object?>?, LivingThing.Core.Frameworks.Common.Data.IValueProvider?>[])
            LCFCD$1$ITypeDescriptor$ApplyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12926355798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ApplyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12926355798)
            
            //--TRIMMABLE-BOUNDARY-START(4336421206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.ITypeDescriptor.AcceptVisitor<TVisitor>(ref TVisitor, ref object?)
            LCFCD$1$ITypeDescriptor$AcceptVisitor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4336421206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AcceptVisitor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4336421206)
            
            //--TRIMMABLE-BOUNDARY-START(51540251769)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540251769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540251769)
            
            //--TRIMMABLE-BOUNDARY-START(51540251769)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51540251769)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(197569139833)
                this.InstanceActivator = $.$default($.$fPer.LCFCD.DataActivator);
                //--TRIMMABLE-BOUNDARY-END(197569139833)
                
            }
            static $h = 644217;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605022841),
    {
      "p": $.$typeArray($.$fPer.LCFCD.DataType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849663097,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993649273,
        "f": 83886081
      },
      "n": "DataTypes",
      "d": 644217,
      "h": 81605022841,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605022841),
//--TRIMMABLE-BOUNDARY-START(60130186361),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489924729,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633910905,
        "f": 83886081
      },
      "n": "Aliases",
      "d": 644217,
      "h": 60130186361,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130186361),
//--TRIMMABLE-BOUNDARY-START(309238289529),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979205241,
        "f": 50331649
      },
      "n": "SystemType",
      "d": 644217,
      "h": 309238289529,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238289529),
//--TRIMMABLE-BOUNDARY-START(210454041721),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209401465,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353387641,
        "f": 83886081
      },
      "n": "Name",
      "d": 644217,
      "h": 210454041721,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454041721),
//--TRIMMABLE-BOUNDARY-START(206159074425),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619466873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763453049,
        "f": 83886081
      },
      "n": "Label",
      "d": 644217,
      "h": 206159074425,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159074425),
//--TRIMMABLE-BOUNDARY-START(73015088249),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669793913,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813780089,
        "f": 83886081
      },
      "n": "AutoRefreshInterval",
      "d": 644217,
      "h": 73015088249,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015088249),
//--TRIMMABLE-BOUNDARY-START(197569139833),
    {
      "p": 8423766,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439597689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583583865,
        "f": 83886081
      },
      "n": "InstanceActivator",
      "d": 644217,
      "h": 197569139833,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569139833),
//--TRIMMABLE-BOUNDARY-START(219043976313),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389270649,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943322233,
        "f": 83886081
      },
      "n": "PropertyColumns",
      "d": 644217,
      "h": 219043976313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043976313),
//--TRIMMABLE-BOUNDARY-START(214749009017),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799336057,
        "f": 50331649
      },
      "n": "Properties",
      "d": 644217,
      "h": 214749009017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749009017),
//--TRIMMABLE-BOUNDARY-START(68720120953),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079859321,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223845497,
        "f": 83886081
      },
      "n": "AssemblyGroup",
      "d": 644217,
      "h": 68720120953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720120953),
//--TRIMMABLE-BOUNDARY-START(77310055545),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259728505,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403714681,
        "f": 83886081
      },
      "n": "BaseType",
      "d": 644217,
      "h": 77310055545,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310055545),
//--TRIMMABLE-BOUNDARY-START(201864107129),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029532281,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173518457,
        "f": 83886081
      },
      "n": "IsAbstract",
      "d": 644217,
      "h": 201864107129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864107129)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(193274172537),
    {
      "r": 131073,
      "p": [
        {
          "n": "notNull",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetDefaultValue",
      "d": 644217,
      "h": 193274172537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274172537),
//--TRIMMABLE-BOUNDARY-START(64425153657),
    {
      "r": 41453910,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "target",
          "p": $.$typeArray($.$fPer.LCFCO.OneOf$$$$($.$$.S.Object, $.$$.S.Func$$($.$$.S.Object), $.$fPer.LCFCD.IValueProvider)).$h,
          "f": 16
        }
      ],
      "n": "ApplyTo",
      "d": 644217,
      "h": 64425153657,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425153657),
//--TRIMMABLE-BOUNDARY-START(85899990137),
    {
      "r": 40536406,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "DefineValue",
      "d": 644217,
      "h": 85899990137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899990137),
//--TRIMMABLE-BOUNDARY-START(313533256825),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 644217,
      "h": 313533256825,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(313533256825),
//--TRIMMABLE-BOUNDARY-START(55835219065),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 131073,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "d": 644217,
      "h": 55835219065,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(55835219065)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295611513),
    {
      "t": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "n": "_properties",
      "d": 644217,
      "h": 4295611513,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295611513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51540251769),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 644217,
      "h": 51540251769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540251769)
  ],
  "h": 644217
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.TableRowType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}TableRowType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(644217)
        
        

        //--TRIMMABLE-BOUNDARY-START(578681)
        $asm.$cls(`$ajwi.LCACM.TablePropertyColumn`, ($self) => class TablePropertyColumn extends $.$fPer.LCFCD$1.PropertyDescriptorBase
        {
            //--TRIMMABLE-BOUNDARY-START(94489859193)
            /*bool*/ IsPrimaryKey = false;
            //--TRIMMABLE-BOUNDARY-END(94489859193)
            
            //--TRIMMABLE-BOUNDARY-START(90194891897)
            /*bool*/ IsOneToManyRelationship = false;
            //--TRIMMABLE-BOUNDARY-END(90194891897)
            
            //--TRIMMABLE-BOUNDARY-START(34360317049)
            /*TableColumnType?*/ ColumnType = null;
            //--TRIMMABLE-BOUNDARY-END(34360317049)
            
            //--TRIMMABLE-BOUNDARY-START(184684172409)
            /*ITypeDescriptor */ get ValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899924601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ColumnType ?? super.ValueType;
            }
            //--TRIMMABLE-BOUNDARY-END(184684172409)
            
            //--TRIMMABLE-BOUNDARY-START(124554630265)
            /*Pager<ISelectOption<object>>?*/ LCFCD$1$IPropertyDescriptor$$$Options = null;
            //--TRIMMABLE-BOUNDARY-END(124554630265)
            
            //--TRIMMABLE-BOUNDARY-START(128849597561)
            /*ITypeDescriptor<object>*/ LCFCD$1$IPropertyDescriptor$$$ValueType = null;
            //--TRIMMABLE-BOUNDARY-END(128849597561)
            
            //--TRIMMABLE-BOUNDARY-START(137439532153)
            /*SchemaAttribute?*/ Schema = null;
            //--TRIMMABLE-BOUNDARY-END(137439532153)
            
            //--TRIMMABLE-BOUNDARY-START(176094237817)
            /*void */ SetValue$1(/*object*/ source, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094237817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(176094237817)
            
            //--TRIMMABLE-BOUNDARY-START(180389205113)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389205113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(180389205113)
            
            //--TRIMMABLE-BOUNDARY-START(115964695673)
            /*IObservableDataDescriptor<object>? */ LCFCD$1$IPropertyDescriptor$$$GetObservable(/*OneOf<object, Func<object>, IValueProvider>*/ source, /*IObservableDataDescriptor?*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964695673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964695673)
            
            //--TRIMMABLE-BOUNDARY-START(120259662969)
            /*object? */ LCFCD$1$IPropertyDescriptor$$$GetRawValue(/*OneOf<object, Func<object>, IValueProvider>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259662969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120259662969)
            
            //--TRIMMABLE-BOUNDARY-START(133144564857)
            /*object? */ get ResolveDefaultValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720055417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = this.DefaultValue;
                let d;
                if ($.$is(value, $.$$.S.Delegate, { set $v($v){ d = $v; } }) && d.Method.GetParameters().length === 0)
                {
                    value = d.DynamicInvoke($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(133144564857)
            
            //--TRIMMABLE-BOUNDARY-START(34400536918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor<object>.SetValue(object, object?)
            LCFCD$1$IPropertyDescriptor$$$SetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34400536918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetValue$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34400536918)
            
            //--TRIMMABLE-BOUNDARY-START(30065349753)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065349753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065349753)
            
            //--TRIMMABLE-BOUNDARY-START(30065349753)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30065349753)
            
            static $h = 578681;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.PropertyDescriptorBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489859193),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130120825,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209335929,
        "f": 83886081
      },
      "n": "IsPrimaryKey",
      "d": 578681,
      "h": 94489859193,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489859193),
//--TRIMMABLE-BOUNDARY-START(90194891897),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540186233,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619401337,
        "f": 83886081
      },
      "n": "IsOneToManyRelationship",
      "d": 578681,
      "h": 90194891897,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194891897),
//--TRIMMABLE-BOUNDARY-START(34360317049),
    {
      "p": 447609,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950251641,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029466745,
        "f": 83886081
      },
      "n": "ColumnType",
      "d": 578681,
      "h": 34360317049,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360317049),
//--TRIMMABLE-BOUNDARY-START(184684172409),
    {
      "p": 41453910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899924601,
        "f": 50364417
      },
      "n": "ValueType",
      "d": 578681,
      "h": 184684172409,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684172409),
//--TRIMMABLE-BOUNDARY-START(124554630265),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079793785,
        "f": 50331650
      },
      "n": "{$.$fPer.LCFCD$1.IPropertyDescriptor$$($.$$.S.Object).$h}.Options",
      "o": "LCFCD$1$IPropertyDescriptor$$$Options",
      "d": 578681,
      "h": 124554630265,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124554630265),
//--TRIMMABLE-BOUNDARY-START(128849597561),
    {
      "p": $.$fPer.LCFCD$1.ITypeDescriptor$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669728377,
        "f": 50331650
      },
      "n": "{$.$fPer.LCFCD$1.IPropertyDescriptor$$($.$$.S.Object).$h}.ValueType",
      "o": "LCFCD$1$IPropertyDescriptor$$$ValueType",
      "d": 578681,
      "h": 128849597561,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128849597561),
//--TRIMMABLE-BOUNDARY-START(137439532153),
    {
      "p": 2197846,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309990009,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799270521,
        "f": 83886081
      },
      "n": "Schema",
      "d": 578681,
      "h": 137439532153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439532153),
//--TRIMMABLE-BOUNDARY-START(133144564857),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720055417,
        "f": 50331649
      },
      "n": "ResolveDefaultValue",
      "d": 578681,
      "h": 133144564857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144564857)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094237817),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "o": "@$1",
      "d": 578681,
      "h": 176094237817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094237817),
//--TRIMMABLE-BOUNDARY-START(180389205113),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 578681,
      "h": 180389205113,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389205113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065349753),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 578681,
      "h": 30065349753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065349753)
  ],
  "h": 578681
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptor$$($.$$.S.Object), $.$fPer.LCFCD$1.IPropertyDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.TablePropertyColumn`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}TablePropertyColumn`; }
        });
        //--TRIMMABLE-BOUNDARY-END(578681)
        
        

        //--TRIMMABLE-BOUNDARY-START(709753)
        $asm.$cls(`$ajwi.LCACM.TableRowType<>`, (T) => $asm.$gt(`$ajwi.LCACM.TableRowType<>`, [T], ($self) => class TableRowType$$ extends $.$ajwi.LCACM.TableRowType
        {
            //--TRIMMABLE-BOUNDARY-START(4295677049)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295677049);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PropertyColumns = $.$fPer.LCFCD.DataDescriptorFactory.OfPropertiesType($.$ajwi.LCACM.TablePropertyColumn, T.$type, new ($.$$.S.Func$$$$$($.$fPer.LCFCD$1.ITypeDescriptor, $.$$.SR.PropertyInfo, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn)))().$ctor(this,  (/*t*/ t, /*p*/ p, /*a*/ a) =>
                    {
                        return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ajwi.LCACM.TablePropertyColumn), [(() =>
                        {
                            //new $.$ajwi.LCACM.TablePropertyColumn()
                            const $t1 = $.$ajwi.LCACM.TablePropertyColumn;
                            const $i1 = new $t1();
                            $i1.$ctor$2();
                            $i1.Name = p.Name;
                            $i1.DeclaredOnType = $.$fPer.LCFCD$1.SystemTypeDescriptor.Get$2(T, null);
                            $i1.ValueType = $.$fPer.LCFCD$1.SystemTypeDescriptor.Get$1(p.PropertyType, null);
                            $i1.Accessibility = (p.CanWrite ? 4/*PropertyAccessibility.Write*/ : 0/*PropertyAccessibility.None*/) | (p.CanRead ? 2/*PropertyAccessibility.Read*/ : 0/*PropertyAccessibility.None*/);
                            $i1.DefaultValue = $.$fPer.LCFCT.TypesExtensions.GetDefaultValue(p.PropertyType, false);
                            $i1.Schema = $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$8($.$fPer.LCFCA$1.SchemaAttribute, p);
                            return $i1;
                        })()], [-1], null);
                    }, $rvjhki ??= {"r":$.$$.SCG.IEnumerable$$($.$ajwi.LCACM.TablePropertyColumn).$h,"p":[{"n":"t","p":41453910},{"n":"p","p":119603201},{"n":"a","p":$.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null).Properties$1;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295677049)
            
            //--TRIMMABLE-BOUNDARY-START(4295677049)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295677049)
            
            static $H = 709753;
            static $h = 709753;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ajwi.LCACM.TableRowType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295677049),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295677049,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295677049)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 709753,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.TableRowType<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}TableRowType$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(709753)
        
        

        //--TRIMMABLE-BOUNDARY-START(316537)
        $asm.$cls(`$ajwi.LCACM.ServiceParameterModel`, ($self) => class ServiceParameterModel extends $.$fPer.LCFCD$1.DataDescriptorBase$$($.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(4295283833)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295283833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295283833)
            
            //--TRIMMABLE-BOUNDARY-START(4295283833)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295283833)
            
            static $h = 316537;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.DataDescriptorBase$$($.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295283833),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 316537,
      "h": 4295283833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295283833)
  ],
  "h": 316537
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object), $.$fPer.LCFCD$1.IObservableDataDescriptor, $.$fPer.LCFCD$1.IDirtyData, $.$fPer.LCFC.IGenericTypeDispatcher$$($.$fPer.LCFCD$1.IObservableDataDescriptor), $.$fPer.LCFCR.IReactiveObservable$$($.$$.S.Object), $.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCD.IValueProvider, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Common.Models.ServiceParameterModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Common${separator}Models${separator}ServiceParameterModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(316537)
        
        

        //--TRIMMABLE-BOUNDARY-START(1102969)
        $asm.$cls(`$ajwi.LCAS.AdminSettings`, ($self) => class AdminSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296070265)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296070265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296070265)
            
            //--TRIMMABLE-BOUNDARY-START(4296070265)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296070265)
            
            static $h = 1102969;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296070265),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1102969,
      "h": 4296070265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296070265)
  ],
  "h": 1102969
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Settings.AdminSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Settings${separator}AdminSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1102969)
        
        

        //--TRIMMABLE-BOUNDARY-START(1168505)
        $asm.$cls(`$ajwi.LCAS$1.AdminStates`, ($self) => class AdminStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296135801)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296135801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296135801)
            
            //--TRIMMABLE-BOUNDARY-START(4296135801)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296135801)
            
            static $h = 1168505;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296135801),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1168505,
      "h": 4296135801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296135801)
  ],
  "h": 1168505
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.States.AdminStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}States${separator}AdminStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1168505)
        
        

        //--TRIMMABLE-BOUNDARY-START(906361)
        $asm.$cls(`$ajwi.LCAM.AdminModel`, ($self) => class AdminModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$ajwi.LCAS.AdminSettings, $.$ajwi.LCAS$1.AdminStates)
        {
            //--TRIMMABLE-BOUNDARY-START(60130448505)
            /*Dictionary<string, TableDefinition>*/ TableDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(60130448505)
            
            //--TRIMMABLE-BOUNDARY-START(38655612025)
            /*PluginBaseModel[]*/ Plugins = null;
            //--TRIMMABLE-BOUNDARY-END(38655612025)
            
            //--TRIMMABLE-BOUNDARY-START(17180775545)
            /*StatusStore[]*/ ApplicationStates = null;
            //--TRIMMABLE-BOUNDARY-END(17180775545)
            
            //--TRIMMABLE-BOUNDARY-START(12885808249)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885808249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885808249)
            
            //--TRIMMABLE-BOUNDARY-START(12885808249)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(12885808249)
            
            static $h = 906361;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$ajwi.LCAS.AdminSettings, $.$ajwi.LCAS$1.AdminStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130448505),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ajwi.LCACM.TableDefinition).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360644729,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835481209,
        "f": 83886081
      },
      "n": "TableDefinitions",
      "d": 906361,
      "h": 60130448505,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130448505),
//--TRIMMABLE-BOUNDARY-START(38655612025),
    {
      "p": $.$typeArray($.$ajwi.LCAM.PluginBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770710137,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245546617,
        "f": 83886081
      },
      "n": "Plugins",
      "d": 906361,
      "h": 38655612025,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655612025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180775545),
    {
      "t": $.$typeArray($.$ajwi.LCAM.StatusStore).$h,
      "n": "ApplicationStates",
      "d": 906361,
      "h": 17180775545,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180775545)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885808249),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 906361,
      "h": 12885808249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885808249)
  ],
  "h": 906361
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Admin.Models.AdminModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Admin${separator}Models${separator}AdminModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(906361)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(54393)
