
//--TRIMMABLE-BOUNDARY-START(31555)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $hqRR, $sitj, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm) {
    "use strict";
    let _;
    let $EPXSPf;
    let $mABcwb;
    let $QKgppj;
    let $ZAqKxj;
    let $sHlyQb;
    let $lmBWwk;
    let $xJXsZa;
    let $luOXQf;
    let $eHgdda;
    let $YiRTzi;
    let $yJXbHe;
    let $AClVkc;
    let $iuMKHd;
    let $xuPrwa;
    let $cdqmjj;
    let $nbouSj;
    let $uPvwra;
    let $lNydph;
    let $IbBdsg;
    let $FLWcwh;
    let $MdLVMj;
    let $PNxvJk;
    let $eGVkhi;
    let $tVkXGg;
    let $dGLtLk;
    let $adkNye;
    let $oLxkKb;
    let $ZSyzGc;
    let $yseQLf;
    let $gxNEJe;
    let $SXaNyc;
    let $Xapong;
    let $WarUrc;
    let $ZeSsQh;
    let $TaCskf;
    let $qILSsg;
    let $wvifjg;
    let $ScaKch;
    let $aTLDIi;
    let $zvksgj;
    let $VKVTLk;
    let $TJkEQd;
    let $JSqBcd;
    let $FlJvMj;
    let $Hofwga;
    let $enTkpe;
    let $tHMFAi;
    let $SXPJEe;
    let $uBuRCb;
    let $zIfYXf;
    let $wvwtnl;
    let $XTtIVh;
    let $AJDedd;
    let $xKqKXc;
    let $mjPKXh;
    let $aGqLqd;
    let $zKivgf;
    let $YPdqnh;
    let $UGbAmi;
    let $BrCCEd;
    let $YqAKHf;
    let $HuSeAf;
    let $YSChde;
    let $YDPZYk;
    let $mEkkVj;
    let $ASERge;
    let $PqITMa;
    let $tpmxDh;
    let $rplxxf;
    let $nEqDQg;
    let $ZryGib;
    let $LuANef;
    let $PtXxpk;
    let $tncJBi;
    let $zGSGDa;
    let $XzbTJb;
    let $wXIvwc;
    let $OkFNal;
    let $VXgbed;
    let $bKuuea;
    let $RCQVlj;
    let $BjtyNa;
    let $LjPgXd;
    let $uqMsZh;
    let $JAEJab;
    let $YEIPli;
    let $pyFmGe;
    let $dtzhxb;
    let $OeQldf;
    let $BeZguh;
    let $ZRSwZc;
    let $BTbCbg;
    let $ezJbyj;
    let $hWxCPc;
    let $wbCvNb;
    let $OGcXAf;
    let $WFwEdb;
    let $EoWgai;
    let $UMNdmi;
    let $qwaXOg;
    let $hkYVWe;
    let $NaJTBi;
    let $cXAmee;
    let $lvsIJi;
    let $bFBZCk;
    let $HCsHEd;
    let $yUbOBi;
    let $KsqBwi;
    let $xhkUWc;
    let $voPoSb;
    let $Hepuih;
    let $qLOeQe;
    let $UdKkUc;
    let $PAmtBh;
    let $Riozbf;
    let $KoBqhb;
    let $qaGYuc;
    let $VNIuki;
    let $IKKWQf;
    let $qIyNci;
    let $PJKXkk;
    let $dEuImh;
    let $cBiArd;
    let $UzDhGi;
    let $jKgfBa;
    let $zOGNqg;
    let $yonnRa;
    let $vfXsoe;
    let $BNcjOi;
    let $WePwFg;
    let $MrduXb;
    let $MVomvh;
    let $Cpebxi;
    let $LTSpSg;
    let $KzhDof;
    let $fFtzdh;
    let $igaMCb;
    let $uJTLkd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Authentication.Client.Blazor", 
    {
  "h": 31555,
  "f": "LivingThing.Core.Authentication.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Authentication.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Authentication.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1276739)
        $asm.$cls(`$uVBI.LCACS$1.IWizardFormSteps`, ($self) => class IWizardFormSteps
        {
            static $h = 1276739;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296244035),
    {
      "r": 65537,
      "p": [
        {
          "n": "step",
          "p": 1211203
        }
      ],
      "n": "AddWizardStep",
      "o": "LCACS$1$IWizardFormSteps$AddWizardStep",
      "d": 1276739,
      "h": 4296244035,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296244035)
  ],
  "h": 1276739
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.IWizardFormSteps`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}IWizardFormSteps`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1276739)
        
        

        //--TRIMMABLE-BOUNDARY-START(1211203)
        $asm.$cls(`$uVBI.LCACS$1.IWizardFormStep`, ($self) => class IWizardFormStep
        {
            static $h = 1211203;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886113091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591145795,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCACS$1$IWizardFormStep$Name",
      "d": 1211203,
      "h": 12886113091,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886113091)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181080387),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "Validate",
      "o": "LCACS$1$IWizardFormStep$Validate",
      "d": 1211203,
      "h": 17181080387,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181080387)
  ],
  "h": 1211203
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.IWizardFormStep`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}IWizardFormStep`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1211203)
        
        

        //--TRIMMABLE-BOUNDARY-START(1014595)
        $asm.$cls(`$uVBI.LCACS.IOAuth2AuthenticationService`, ($self) => class IOAuth2AuthenticationService
        {
            static $h = 1014595;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180883779),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590949187,
        "f": 50331905
      },
      "n": "IsConfigured",
      "o": "LCACS$IOAuth2AuthenticationService$IsConfigured",
      "d": 1014595,
      "h": 17180883779,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180883779)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885916483),
    {
      "r": 6881395,
      "p": [
        {
          "n": "onLoggedIn",
          "p": $.$$.S.Func$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$$.STT.ValueTask).$h
        },
        {
          "n": "metadata",
          "p": 541058
        }
      ],
      "n": "GetView",
      "o": "LCACS$IOAuth2AuthenticationService$GetView",
      "d": 1014595,
      "h": 12885916483,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885916483)
  ],
  "h": 1014595
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Services.IOAuth2AuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Services${separator}IOAuth2AuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1014595)
        
        

        //--TRIMMABLE-BOUNDARY-START(1932099)
        $asm.$cls(`$uVBI.LCACV.RegisterViewModel`, ($self) => class RegisterViewModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296899395)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296899395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296899395)
            
            //--TRIMMABLE-BOUNDARY-START(4296899395)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296899395)
            
            static $h = 1932099;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296899395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1932099,
      "h": 4296899395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296899395)
  ],
  "h": 1932099
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ViewModels.RegisterViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ViewModels${separator}RegisterViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1932099)
        
        

        //--TRIMMABLE-BOUNDARY-START(1735491)
        $asm.$cls(`$uVBI.LCACS$2.AppState`, ($self) => class AppState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296702787)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296702787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296702787)
            
            //--TRIMMABLE-BOUNDARY-START(4296702787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296702787)
            
            static $h = 1735491;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296702787),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1735491,
      "h": 4296702787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296702787)
  ],
  "h": 1735491
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.States.AppState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}States${separator}AppState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1735491)
        
        

        //--TRIMMABLE-BOUNDARY-START(1997635)
        $asm.$cls(`$uVBI.LCACV.ResetViewModel`, ($self) => class ResetViewModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296964931)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296964931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296964931)
            
            //--TRIMMABLE-BOUNDARY-START(4296964931)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296964931)
            
            static $h = 1997635;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296964931),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1997635,
      "h": 4296964931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296964931)
  ],
  "h": 1997635
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ViewModels.ResetViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ViewModels${separator}ResetViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1997635)
        
        

        //--TRIMMABLE-BOUNDARY-START(293699)
        $asm.$cls(`$uVBI.LCAC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295260995)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295260995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$uVBI.LCAC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295260995)
            
            static $h = 293699;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295260995),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 293699,
      "h": 4295260995,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295260995)
  ],
  "h": 293699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(293699)
        
        

        //--TRIMMABLE-BOUNDARY-START(359235)
        $asm.$cls(`$uVBI.LCAC.AuthenticationExtensions`, ($self) => class AuthenticationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295326531)
            static /*ValueTask<DecodedAuthenticationTicket> */ Login(TViewConfiguration, /*this IViewStackPresenter<TViewConfiguration>*/ presenter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295326531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult(TViewConfiguration, $.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$uVBI.LCACS$1.Root, presenter, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Login", false), null, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(4295326531)
            
            static $h = 359235;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295326531),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "presenter",
          "p": (TViewConfiguration) => $.$vWqU.LCFCC.IViewStackPresenter$$(TViewConfiguration).$h
        }
      ],
      "g": [
        "TViewConfiguration"
      ],
      "n": "Login",
      "d": 359235,
      "h": 4295326531,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295326531)
  ],
  "h": 359235
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.AuthenticationExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}AuthenticationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(359235)
        
        

        //--TRIMMABLE-BOUNDARY-START(490307)
        $asm.$cls(`$uVBI.LCAC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590424899)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590424899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$uVBI.LCACP.App, "LivingThing.Core.Authentication.Client", "Pages\\App", "App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Authentication", "/Authentication/{View}", "/Authentication/{View}/{Action}", "/Account/Login" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$uVBI.LCACP.RegisterEmail, "LivingThing.Core.Authentication.Client", "Pages\\RegisterEmail", "Register Email", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Authentication/Template/RegisterEmail" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$uVBI.LCACP.ResetPassword, "LivingThing.Core.Authentication.Client", "Pages\\ResetPassword", "Reset Password", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Authentication/Template/ResetPassword" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590424899)
            
            //--TRIMMABLE-BOUNDARY-START(4295457603)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295457603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295457603)
            
            //--TRIMMABLE-BOUNDARY-START(4295457603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295457603)
            
            static $h = 490307;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590424899),
    {
      "r": 65537,
      "n": "Build",
      "d": 490307,
      "h": 8590424899,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590424899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295457603),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 490307,
      "h": 4295457603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295457603)
  ],
  "h": 490307
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(490307)
        
        

        //--TRIMMABLE-BOUNDARY-START(97091)
        $asm.$cls(`$uVBI._LCACSR.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295064387)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295064387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295064387)
            
            static $h = 97091;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295064387),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 97091,
      "h": 4295064387,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295064387)
  ],
  "h": 97091
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Authentication.Client.Shared.Register.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}Register${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(97091)
        
        

        //--TRIMMABLE-BOUNDARY-START(162627)
        $asm.$cls(`$uVBI._LCACSR$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295129923)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295129923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295129923)
            
            //--TRIMMABLE-BOUNDARY-START(8590097219)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590097219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq2, "Theme", $.$clone(__arg2));
                __builder.AddComponentParameter(__seq3, "Class", __arg3);
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590097219)
            
            static $h = 162627;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295129923),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 162627,
      "h": 4295129923,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295129923),
//--TRIMMABLE-BOUNDARY-START(8590097219),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 27612842
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 65309014
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 162627,
      "h": 8590097219,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590097219)
  ],
  "h": 162627
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Authentication.Client.Shared.ResetPassword.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}ResetPassword${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(162627)
        
        

        //--TRIMMABLE-BOUNDARY-START(424771)
        $asm.$cls(`$uVBI.LCAC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180293955)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACP.App.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACP.App().$ctor$3();
                    }, $EPXSPf ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.ChangePassword.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.ChangePassword().$ctor$3();
                    }, $mABcwb ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.Login.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.Login().$ctor$3();
                    }, $QKgppj ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.Profile.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.Profile().$ctor$4();
                    }, $ZAqKxj ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.Register.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.Register().$ctor$3();
                    }, $sHlyQb ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.ResetPassword.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.ResetPassword().$ctor$3();
                    }, $lmBWwk ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$uVBI.LCACS$1.Root.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$uVBI.LCACS$1.Root().$ctor$3();
                    }, $xJXsZa ??= {"r":2752627,"n":"","d":424771,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180293955)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295392067)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295392067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295392067)
            
            //--TRIMMABLE-BOUNDARY-START(4295392067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295392067)
            
            static $h = 424771;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180293955),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885326659,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 424771,
      "h": 17180293955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180293955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295392067),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 424771,
      "h": 4295392067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295392067)
  ],
  "h": 424771
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(424771)
        
        

        //--TRIMMABLE-BOUNDARY-START(817987)
        $asm.$cls(`$uVBI.LCAC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590752579)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590752579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uVBI.LCAC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IClientAuthenticationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uVBI.LCACS.ClientAuthenticationService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IClientAuthenticationService))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.ClientAuthenticationService, x);
                }, $YqAKHf ??= {"r":63592106,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794}));
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$GfYa.LCFCA.IReadOnlyAuthenticationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$GfYa.LCFCA.IAuthenticationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uVBI.LCACS.TokenBasedAuthenticationService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$GfYa.LCFCA.IAuthenticationService))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.TokenBasedAuthenticationService, x);
                    }, $HuSeAf ??= {"r":1655170,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$GfYa.LCFCA.IReadOnlyAuthenticationService))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.TokenBasedAuthenticationService, x);
                    }, $YSChde ??= {"r":1786242,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794}));
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$maa.MAA.IAuthorizationPolicyProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$maa.MAA.IAuthorizationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$maca.MACA.AuthenticationStateProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uVBI.LCAS.TokenAuthenticationProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$maca.MACA.AuthenticationStateProvider))().$ctor(this,  (/*sp*/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }, $YDPZYk ??= {"r":327801,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$maa.MAA.IAuthorizationService))().$ctor(this,  (/*sp*/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }, $mEkkVj ??= {"r":1835120,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$maa.MAA.IAuthorizationPolicyProvider))().$ctor(this,  (/*sp*/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }, $ASERge ??= {"r":1638512,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794}));
                }
                else 
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$GfYa.LCFCA.IReadOnlyAuthenticationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$GfYa.LCFCA.IAuthenticationService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$GfYa.LCFCA.IAuthenticationService))().$ctor(this,  (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService, x);
                    }, $PqITMa ??= {"r":1655170,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$GfYa.LCFCA.IReadOnlyAuthenticationService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService, x);
                    }, $tpmxDh ??= {"r":1786242,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794}));
                }
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$uVBI.LCACV.ResetViewModel, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$uVBI.LCACV.LoginViewModel, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$uVBI.LCACV.RegisterViewModel, services)));
                $.$uVBI.LCAC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590752579)
            
            //--TRIMMABLE-BOUNDARY-START(12885719875)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885719875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_ClientAuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACS.ClientAuthenticationService().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$GfYa.LCFCA.IAuthenticationService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACS.ClientAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_ClientAuthenticationService, $rplxxf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ClientAuthenticationService","d":817987,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientAuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.ClientAuthenticationService, x);
                    }), $nEqDQg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.IClientAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IClientAuthenticationService, $ZryGib ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientAuthenticationService","d":817987,"h":0,"f":16777250})));
                /*static object*/  function Get_TokenBasedAuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACS.TokenBasedAuthenticationService().$ctor$2(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$scm.S.IServiceProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$scm.S.IServiceProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCC$1.IConfigurationParser, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFC.IApplicationContextProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$$.SCG.IEnumerable$$($.$GfYa.LCFCA.IAuthenticationTicketStore), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$GfYa.LCFCA.IAuthenticationTicketStore), provider));
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACS.TokenBasedAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_TokenBasedAuthenticationService, $LuANef ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_TokenBasedAuthenticationService","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IAuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.TokenBasedAuthenticationService, x);
                    }), $PtXxpk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$GfYa.LCFCA.IAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IAuthenticationService, $tncJBi ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IAuthenticationService","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IReadOnlyAuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.TokenBasedAuthenticationService, x);
                    }), $zGSGDa ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$GfYa.LCFCA.IReadOnlyAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IReadOnlyAuthenticationService, $XzbTJb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IReadOnlyAuthenticationService","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_TokenAuthenticationProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCAS.TokenAuthenticationProvider().$ctor$2(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$GfYa.LCFCA.IAuthenticationService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, provider));
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCAS.TokenAuthenticationProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_TokenAuthenticationProvider, $wXIvwc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_TokenAuthenticationProvider","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_AuthenticationStateProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }), $OkFNal ??= {"r":131073,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$maca.MACA.AuthenticationStateProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_AuthenticationStateProvider, $VXgbed ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_AuthenticationStateProvider","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IAuthorizationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*sp*/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }), $bKuuea ??= {"r":131073,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$maa.MAA.IAuthorizationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IAuthorizationService, $RCQVlj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IAuthorizationService","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IAuthorizationPolicyProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*sp*/ sp) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCAS.TokenAuthenticationProvider, sp);
                    }), $BjtyNa ??= {"r":131073,"p":[{"n":"sp","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$maa.MAA.IAuthorizationPolicyProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IAuthorizationPolicyProvider, $LjPgXd ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IAuthorizationPolicyProvider","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_BlazorServerAuthenticationStateProviderService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService().$ctor$2(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$scm.S.IServiceProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$scm.S.IServiceProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCC$1.IConfigurationParser, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFC.IApplicationContextProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$GfYa.LCFCA.IAuthenticationTicketStore, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationTicketStore, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$maca.MACA.AuthenticationStateProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$maca.MACA.AuthenticationStateProvider, provider));
                }
                if (!(options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/))
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_BlazorServerAuthenticationStateProviderService, $uqMsZh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_BlazorServerAuthenticationStateProviderService","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IAuthenticationService_1(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService, x);
                    }), $JAEJab ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (!(options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/))
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$GfYa.LCFCA.IAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IAuthenticationService_1, $YEIPli ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IAuthenticationService_1","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IReadOnlyAuthenticationService_1(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.BlazorServerAuthenticationStateProviderService, x);
                    }), $pyFmGe ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":817987,"h":0,"f":17825794})).Invoke(provider);
                }
                if (!(options.Runtime === 2/*RuntimeType.MobileApp*/ || $.$fPer.LCFC.RuntimeTypeExtension.IsWasm(options.Runtime) || options.Runtime === 6/*RuntimeType.DesktopApp*/))
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$GfYa.LCFCA.IReadOnlyAuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_IReadOnlyAuthenticationService_1, $dtzhxb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IReadOnlyAuthenticationService_1","d":817987,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_RegisterViewModel(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACV.RegisterViewModel().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACV.RegisterViewModel.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(2/*ServiceLifetime.Transient*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_RegisterViewModel, $OeQldf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_RegisterViewModel","d":817987,"h":0,"f":16777250})));
                /*static object*/  function Get_LoginViewModel(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACV.LoginViewModel().$ctor$3(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACV.LoginViewModel.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(2/*ServiceLifetime.Transient*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_LoginViewModel, $BeZguh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_LoginViewModel","d":817987,"h":0,"f":16777250})));
                /*static object*/  function Get_ResetViewModel(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$uVBI.LCACV.ResetViewModel().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACV.ResetViewModel.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(2/*ServiceLifetime.Transient*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$uVBI.LCAC.ServiceRegistrar, Get_ResetViewModel, $ZRSwZc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ResetViewModel","d":817987,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885719875)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uVBI.LCAC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295785283)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295785283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295785283)
            
            //--TRIMMABLE-BOUNDARY-START(4295785283)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295785283)
            
            static $h = 817987;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590752579),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 817987,
      "h": 8590752579,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590752579),
//--TRIMMABLE-BOUNDARY-START(12885719875),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 817987,
      "h": 12885719875,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885719875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295785283),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 817987,
      "h": 4295785283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295785283)
  ],
  "h": 817987
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(817987)
        
        

        //--TRIMMABLE-BOUNDARY-START(949059)
        $asm.$cls(`$uVBI.LCACS.ClientAuthenticationService`, ($self) => class ClientAuthenticationService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180818243)
            /*IAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(17180818243)
            
            //--TRIMMABLE-BOUNDARY-START(4295916355)
            $ctor$1(/*IAuthenticationService*/ authenticationService)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295916355);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AuthenticationService = authenticationService;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295916355)
            
            //--TRIMMABLE-BOUNDARY-START(21475785539)
            /*RenderFragment */ LoginView(/*AuthenticationParameter?*/ parameter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475785539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*_builder*/ _builder) =>
                    {
                        _builder.OpenComponent(1, $.$uVBI.LCACS$1.Root.$type);
                        if ((parameter?.Client ?? null) !== null)
                        {
                            _builder.AddAttribute$4(2, "Client", parameter.Client);
                        }
                        _builder.AddAttribute$4(3, "Flags", $.$box((parameter?.Flags ?? null) ?? 7/*LoginActionFlags.Default*/, $.$hDPm.LCFCI.LoginActionFlags));
                        _builder.AddAttribute$4(4, "Theme", (parameter?.Theme ?? null) ?? $.$fPer.LCFC.Theme.Primary);
                        _builder.AddAttribute$4(5, "FormTheme", (parameter?.FormTheme ?? null) ?? $.$fPer.LCFC.Theme.Primary);
                        _builder.AddAttribute$3(6, "ServiceIcon", (parameter?.ServiceIcon ?? null));
                        _builder.AddAttribute$4(7, "Uri", (parameter?.Uri ?? null));
                        _builder.AddAttribute$4(8, "SetAttributes", (parameter?.Attributes ?? null));
                        _builder.AddAttribute$4(9, "FieldFeatures", $.$box((parameter?.FieldFeatures ?? null) ?? 4/*InputFieldFeatures.Default*/, $.$hDPm.LCFCCI$2.InputFieldFeatures));
                        _builder.AddAttribute$4(10, "EditorFeatures", $.$box((parameter?.EditorFeatures ?? null) ?? 4131/*InputEditorFeatures.Default*/, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                        _builder.AddAttribute$2(11, "Navigable", (parameter?.Navigable ?? null) ?? false);
                        _builder.AddAttribute$5(12, "BasePath", (parameter?.BasePath ?? null));
                        _builder.AddAttribute$3(13, "LoginChildContent", (parameter?.LoginFormSuffix ?? null));
                        _builder.AddAttribute$3(14, "RegisterChildContent", (parameter?.RegisterFormSuffix ?? null));
                        _builder.AddAttribute$3(15, "ValidateLogin", (parameter?.ValidateLogin ?? null));
                        _builder.AddAttribute$3(16, "ValidateRegisteration", (parameter?.ValidateRegisteration ?? null));
                        _builder.CloseComponent();
                    }, $AClVkc ??= {"r":65537,"p":[{"n":"_builder","p":7536755}],"n":"","d":949059,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475785539)
            
            //--TRIMMABLE-BOUNDARY-START(8590883651)
            /*RenderFragment */ Authenticate(/*AuthenticationParameter?*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590883651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoginView(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(8590883651)
            
            //--TRIMMABLE-BOUNDARY-START(12885850947)
            /*ValueTask<DecodedAuthenticationTicket> *//*async*/  AuthenticateAsync(TViewConfiguration, /*IViewStackPresenter<TViewConfiguration>*/ presenter, /*IAuthenticationClient?*/ client, /*string?*/ message, /*bool*/ allowLogin, /*bool*/ allowRegister, /*bool*/ allowReset, /*bool*/ allowDemoLogin, /*bool*/ allowAnonymousLogin)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$GfYa.LCFCA.DecodedAuthenticationTicket, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885850947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ticket = ($t1 = this.AuthenticationService.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (ticket.IsValid())
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, ticket);
                    }
                    /*int*/ let tabs = 0;
                    if (allowLogin)
                    {
                        tabs++;
                    }
                    if (allowRegister)
                    {
                        tabs++;
                    }
                    if (allowReset)
                    {
                        tabs++;
                    }
                    /*string?*/ let __ca1__;
                    ticket = ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.ViewForResult(TViewConfiguration, $.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$uVBI.LCACS$1.Root, presenter, message !== null ? $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Login", false) : null, ((__ca1__ = message) !== null ? $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, __ca1__, false) : null), new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/**/ builder, /*seq*/ seq) =>
                    {
                        builder.AddAttribute$2(seq++, "Navigable", false);
                        builder.AddAttribute$4(seq++, "Client", client);
                        builder.AddAttribute$4(seq++, "Flags", $.$box((allowLogin ? 1/*LoginActionFlags.Login*/ : 0/*LoginActionFlags.None*/) | (allowRegister ? 2/*LoginActionFlags.Register*/ : 0/*LoginActionFlags.None*/) | (allowReset ? 4/*LoginActionFlags.Reset*/ : 0/*LoginActionFlags.None*/) | (allowDemoLogin ? 8/*LoginActionFlags.AllowDemoLogin*/ : 0/*LoginActionFlags.None*/) | (allowAnonymousLogin ? 16/*LoginActionFlags.AllowAnonymousLogin*/ : 0/*LoginActionFlags.None*/), $.$hDPm.LCFCI.LoginActionFlags));
                    }, $iuMKHd ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"seq","p":655361}],"n":"","d":949059,"h":0,"f":17825794}), null, (() =>
                    {
                        //new TViewConfiguration()
                        const $t3 = TViewConfiguration.$isProxy === true ? TViewConfiguration.$prototype : TViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.ViewFeatures = (63207/*ViewFeatures.PromptDefault*/ & ~1/*ViewFeatures.OKToolBar*/ & ~2/*ViewFeatures.CancelToolBar*/ & ~32/*ViewFeatures.Header*/) | 256/*ViewFeatures.CloseOnClickOut*/;
                        $i3.BodyAttributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                            const $t4 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                            const $i4 = new $t4();
                            $i4.$ctor$1();
                            $i4.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), `bg-card${$.$strNN((tabs <= 1 ? " pd" : ""))}`);
                            return $i4;
                        })();
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ticket);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885850947)
            
            //--TRIMMABLE-BOUNDARY-START(25770752835)
            /*RenderFragment */ ProfileView(/*IAuthenticationClient?*/ client, /*RenderFragment?*/ content)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770752835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*_builder*/ _builder) =>
                    {
                        _builder.OpenComponent(1, $.$uVBI.LCACS$1.Profile.$type);
                        _builder.AddAttribute$3(2, "ChildContent", content);
                        if (client !== null)
                        {
                            _builder.AddAttribute$4(3, "Client", client);
                        }
                        _builder.CloseComponent();
                    }, $xuPrwa ??= {"r":65537,"p":[{"n":"_builder","p":7536755}],"n":"","d":949059,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770752835)
            
            //--TRIMMABLE-BOUNDARY-START(4358559402)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.Authenticate(LivingThing.Core.Frameworks.Client.Interface.AuthenticationParameter?)
            LCFCI$IClientAuthenticationService$Authenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358559402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Authenticate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358559402)
            
            //--TRIMMABLE-BOUNDARY-START(12948493994)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.ProfileView(LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?, Microsoft.AspNetCore.Components.RenderFragment?)
            LCFCI$IClientAuthenticationService$ProfileView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948493994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProfileView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948493994)
            
            //--TRIMMABLE-BOUNDARY-START(8653526698)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IClientAuthenticationService.AuthenticateAsync<TViewConfiguration>(LivingThing.Core.Frameworks.Common.Client.IViewStackPresenter<TViewConfiguration>, LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient?, string?, bool, bool, bool, bool, bool)
            LCFCI$IClientAuthenticationService$AuthenticateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653526698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653526698)
            
            static $h = 949059;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475785539),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parameter",
          "p": 62215850
        }
      ],
      "n": "LoginView",
      "d": 949059,
      "h": 21475785539,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475785539),
//--TRIMMABLE-BOUNDARY-START(8590883651),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parameter",
          "p": 62215850,
          "f": 65
        }
      ],
      "n": "Authenticate",
      "d": 949059,
      "h": 8590883651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590883651),
//--TRIMMABLE-BOUNDARY-START(12885850947),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "presenter",
          "p": (TViewConfiguration) => $.$vWqU.LCFCC.IViewStackPresenter$$(TViewConfiguration).$h
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        },
        {
          "n": "message",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "allowLogin",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowRegister",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowReset",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "allowDemoLogin",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "allowAnonymousLogin",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "TViewConfiguration"
      ],
      "n": "AuthenticateAsync",
      "d": 949059,
      "h": 12885850947,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(12885850947),
//--TRIMMABLE-BOUNDARY-START(25770752835),
    {
      "r": 6881395,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        },
        {
          "n": "content",
          "p": 6881395,
          "f": 65
        }
      ],
      "n": "ProfileView",
      "d": 949059,
      "h": 25770752835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770752835)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180818243),
    {
      "t": 1655170,
      "n": "AuthenticationService",
      "d": 949059,
      "h": 17180818243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180818243)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295916355),
    {
      "p": [
        {
          "n": "authenticationService",
          "p": 1655170
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 949059,
      "h": 4295916355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295916355)
  ],
  "h": 949059
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IClientAuthenticationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Services.ClientAuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Services${separator}ClientAuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(949059)
        
        

        //--TRIMMABLE-BOUNDARY-START(2128707)
        $asm.$cls(`$uVBI.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297096003)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297096003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297096003)
            
            //--TRIMMABLE-BOUNDARY-START(4297096003)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297096003)
            
            static $h = 2128707;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297096003),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2128707,
      "h": 4297096003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297096003)
  ],
  "h": 2128707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2128707)
        
        

        //--TRIMMABLE-BOUNDARY-START(2194243)
        $asm.$cls(`$uVBI.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297161539)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297161539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297161539)
            
            //--TRIMMABLE-BOUNDARY-START(4297161539)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297161539)
            
            static $h = 2194243;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297161539),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2194243,
      "h": 4297161539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297161539)
  ],
  "h": 2194243,
  "a": [
    {
      "t": 2128707,
      "c": 4297096003
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2194243)
        
        

        //--TRIMMABLE-BOUNDARY-START(2063171)
        $asm.$cls(`$uVBI.LCAS.TokenAuthenticationProvider`, ($self) => class TokenAuthenticationProvider extends $.$maca.MACA.AuthenticationStateProvider
        {
            //--TRIMMABLE-BOUNDARY-START(17181932355)
            /*IAuthenticationService*/ AuthService = null;
            //--TRIMMABLE-BOUNDARY-END(17181932355)
            
            //--TRIMMABLE-BOUNDARY-START(4297030467)
            $ctor$2(/*IAuthenticationService*/ authService)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297030467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AuthService = authService;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297030467)
            
            //--TRIMMABLE-BOUNDARY-START(8591997763)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*IEnumerable<IAuthorizationRequirement>*/ requirements)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591997763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ((user.Identity?.SSP$1$IIdentity$IsAuthenticated ?? null) ?? false) ? $.$maa.MAA.AuthorizationResult.Success() : $.$maa.MAA.AuthorizationResult.Failed());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591997763)
            
            //--TRIMMABLE-BOUNDARY-START(12886965059)
            /*Task<AuthorizationResult> *//*async*/  AuthorizeAsync$1(/*ClaimsPrincipal*/ user, /*object?*/ resource, /*string*/ policyName)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationResult), $.$maa.MAA.AuthorizationResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886965059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ((user.Identity?.SSP$1$IIdentity$IsAuthenticated ?? null) ?? false) ? $.$maa.MAA.AuthorizationResult.Success() : $.$maa.MAA.AuthorizationResult.Failed());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886965059)
            
            //--TRIMMABLE-BOUNDARY-START(21476899651)
            /*Task<AuthenticationState> *//*async*/  GetAuthenticationStateAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maca.MACA.AuthenticationState), $.$maca.MACA.AuthenticationState, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476899651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let state = new $.$maca.MACA.AuthenticationState().$ctor$1(($t1 = this.AuthService.LCFCA$IReadOnlyAuthenticationService$GetClaimsPrincipal(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                    return $.$$.N.AsyncResolver.Result($asnycContext, state);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476899651)
            
            //--TRIMMABLE-BOUNDARY-START(25771866947)
            /*Task<AuthorizationPolicy> *//*async*/  GetDefaultPolicyAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy), $.$maa.MAA.AuthorizationPolicy, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771866947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$maa.MAA.AuthorizationPolicy().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maa.MAA.IAuthorizationRequirement), [this], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771866947)
            
            //--TRIMMABLE-BOUNDARY-START(30066834243)
            /*Task<AuthorizationPolicy> *//*async*/  GetFallbackPolicyAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy), $.$maa.MAA.AuthorizationPolicy, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066834243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$maa.MAA.AuthorizationPolicy().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maa.MAA.IAuthorizationRequirement), [this], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30066834243)
            
            //--TRIMMABLE-BOUNDARY-START(34361801539)
            /*Task<AuthorizationPolicy> *//*async*/  GetPolicyAsync(/*string*/ policyName)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy), $.$maa.MAA.AuthorizationPolicy, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361801539);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$maa.MAA.AuthorizationPolicy().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$maa.MAA.IAuthorizationRequirement), [this], [-1], null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361801539)
            
            //--TRIMMABLE-BOUNDARY-START(12886540400)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetPolicyAsync(string)
            MAA$IAuthorizationPolicyProvider$GetPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886540400)
            
            //--TRIMMABLE-BOUNDARY-START(4296605808)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
            MAA$IAuthorizationPolicyProvider$GetDefaultPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDefaultPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296605808)
            
            //--TRIMMABLE-BOUNDARY-START(8591573104)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationPolicyProvider.GetFallbackPolicyAsync()
            MAA$IAuthorizationPolicyProvider$GetFallbackPolicyAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFallbackPolicyAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591573104)
            
            //--TRIMMABLE-BOUNDARY-START(4296802416)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, System.Collections.Generic.IEnumerable<Microsoft.AspNetCore.Authorization.IAuthorizationRequirement>)
            MAA$IAuthorizationService$AuthorizeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296802416)
            
            //--TRIMMABLE-BOUNDARY-START(8591769712)
            //Generated interface implemetation for Microsoft.AspNetCore.Authorization.IAuthorizationService.AuthorizeAsync(System.Security.Claims.ClaimsPrincipal, object?, string)
            MAA$IAuthorizationService$AuthorizeAsync$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthorizeAsync$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591769712)
            
            static $h = 2063171;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$maca.MACA.AuthenticationStateProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591997763),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "requirements",
          "p": $.$$.SCG.IEnumerable$$($.$maa.MAA.IAuthorizationRequirement).$h
        }
      ],
      "n": "AuthorizeAsync",
      "d": 2063171,
      "h": 8591997763,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8591997763),
//--TRIMMABLE-BOUNDARY-START(12886965059),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationResult).$h,
      "p": [
        {
          "n": "user",
          "p": 393285
        },
        {
          "n": "resource",
          "p": 131073
        },
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "AuthorizeAsync",
      "o": "@$1",
      "d": 2063171,
      "h": 12886965059,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12886965059),
//--TRIMMABLE-BOUNDARY-START(21476899651),
    {
      "r": $.$$.STT.Task$$($.$maca.MACA.AuthenticationState).$h,
      "n": "GetAuthenticationStateAsync",
      "d": 2063171,
      "h": 21476899651,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(21476899651),
//--TRIMMABLE-BOUNDARY-START(25771866947),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetDefaultPolicyAsync",
      "d": 2063171,
      "h": 25771866947,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25771866947),
//--TRIMMABLE-BOUNDARY-START(30066834243),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "n": "GetFallbackPolicyAsync",
      "d": 2063171,
      "h": 30066834243,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30066834243),
//--TRIMMABLE-BOUNDARY-START(34361801539),
    {
      "r": $.$$.STT.Task$$($.$maa.MAA.AuthorizationPolicy).$h,
      "p": [
        {
          "n": "policyName",
          "p": 1310721
        }
      ],
      "n": "GetPolicyAsync",
      "d": 2063171,
      "h": 34361801539,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34361801539)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181932355),
    {
      "t": 1655170,
      "n": "AuthService",
      "d": 2063171,
      "h": 17181932355,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181932355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297030467),
    {
      "p": [
        {
          "n": "authService",
          "p": 1655170
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2063171,
      "h": 4297030467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297030467)
  ],
  "h": 2063171
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$maa.MAA.IAuthorizationPolicyProvider, $.$maa.MAA.IAuthorizationService, $.$maa.MAA.IAuthorizationRequirement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Services.TokenAuthenticationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Services${separator}TokenAuthenticationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2063171)
        
        

        //--TRIMMABLE-BOUNDARY-START(883523)
        $asm.$cls(`$uVBI.LCACS.BlazorServerAuthenticationStateProviderService`, ($self) => class BlazorServerAuthenticationStateProviderService extends $.$DZqk.LCACS.AuthenticationServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(21475720003)
            $ctor$2(/*IServiceProvider*/ provider, /*IServerRemoteService*/ server, /*IConfigurationParser*/ config, /*IApplicationContextProvider*/ context, /*IJavaScriptRunner*/ javaScript, /*IAuthenticationTicketStore*/ ticketStore, /*AuthenticationStateProvider*/ authenticationProvider)
            {
                super.$ctor$1(server, config, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475720003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._provider = provider;
                    this._javaScript = javaScript;
                    this._ticketStore = ticketStore;
                    this._authenticationProvider = authenticationProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475720003)
            
            //--TRIMMABLE-BOUNDARY-START(12885785411)
            /*IServiceProvider*/ _provider = null;
            //--TRIMMABLE-BOUNDARY-END(12885785411)
            
            //--TRIMMABLE-BOUNDARY-START(17180752707)
            /*IAuthenticationTicketStore*/ _ticketStore = null;
            //--TRIMMABLE-BOUNDARY-END(17180752707)
            
            //--TRIMMABLE-BOUNDARY-START(8590818115)
            /*IJavaScriptRunner*/ _javaScript = null;
            //--TRIMMABLE-BOUNDARY-END(8590818115)
            
            //--TRIMMABLE-BOUNDARY-START(4295850819)
            /*AuthenticationStateProvider*/ _authenticationProvider = null;
            //--TRIMMABLE-BOUNDARY-END(4295850819)
            
            //--TRIMMABLE-BOUNDARY-START(30065654595)
            /*ValueTask<(DecodedAuthenticationTicket Ticket,
#if CLIENT_VALIDATE_JWT
            //SecurityToken? Token, 
#endif
            ClaimsPrincipal? Principal)> *//*async*/  GetSecurityProperties()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)), $.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065654595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        /*var*/ let authState = ($t1 = this._authenticationProvider.GetAuthenticationStateAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if ((authState.User.Identity?.SSP$1$IIdentity$IsAuthenticated ?? null) ?? false)
                        {
                            /*var*/ let decoded = $.$GfYa.LCFCA.DecodedAuthenticationTicket.FromPrincipal(authState.User);
                            return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3(decoded, authState.User));
                        }
                    }
                    catch($e)
                    {
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3($.$GfYa.LCFCA.DecodedAuthenticationTicket.Default, null));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065654595)
            
            //--TRIMMABLE-BOUNDARY-START(38655589187)
            /*ValueTask *//*async*/  SetTicket(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655589187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (ticket.Cookies !== null)
                    {
                        let $t2, $r2;
                        ($t2 = this._javaScript.LCFCI$IJavaScriptRunner$Queue$1("setCookies", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ ticket.Cookies ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    else if (ticket.Token.Provider !== null && ticket.Token.ProviderKey !== null)
                    {
                        let $t3, $r3;
                        /*var*/ let login = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$DZqk.LCACS.IAuthenticationRemoteService, $.$DZqk.LCACM.LogInResponseModel, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$DZqk.LCACS.IAuthenticationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$DZqk.LCACM.LogInResponseModel)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCACS$IAuthenticationRemoteService$Login((() =>
                            {
                                //new $.$DZqk.LCACM.LogInRequestModel()
                                const $t4 = $.$DZqk.LCACM.LogInRequestModel;
                                const $i4 = new $t4();
                                $i4.$ctor$2();
                                $i4.Token = ticket.Token;
                                $i4.RememberMe = true;
                                return $i4;
                            })());
                        }, $yJXbHe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$DZqk.LCACM.LogInResponseModel)).$h,"p":[{"n":"server","p":7259133}],"n":"","d":883523,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        if (login.Ticket.Cookies !== null)
                        {
                            let $t5, $r5;
                            ($t5 = this._javaScript.LCFCI$IJavaScriptRunner$Queue$1("setCookies", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ login.Ticket.Cookies ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    }
                    ($t6 = this._ticketStore.LCFCA$IAuthenticationTicketStore$SetTicket(ticket), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655589187)
            
            //--TRIMMABLE-BOUNDARY-START(25770687299)
            /*ValueTask<DecodedAuthenticationTicket> */ AuthenticateAsync(/*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770687299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let uow = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, this._provider);
                /*ClientAuthenticationService*/ let service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.ClientAuthenticationService, this._provider);
                return service.AuthenticateAsync($.$hDPm.LCFCI.ViewConfiguration, uow.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, true, true, true, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(25770687299)
            
            //--TRIMMABLE-BOUNDARY-START(34360621891)
            /*ValueTask *//*async*/  LogOut(/*IAuthenticationClient?*/ caller)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360621891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = this._javaScript.LCFCI$IJavaScriptRunner$Queue$1("removeCookie", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "Ticket" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    ($t8 = this._ticketStore.LCFCA$IAuthenticationTicketStore$RemoveTicket(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    ($t9 = super.LogOut(caller), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360621891)
            
            static $h = 883523;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$DZqk.LCACS.AuthenticationServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065654595),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)).$h,
      "n": "GetSecurityProperties",
      "d": 883523,
      "h": 30065654595,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(30065654595),
//--TRIMMABLE-BOUNDARY-START(38655589187),
    {
      "r": 181338113,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "SetTicket",
      "d": 883523,
      "h": 38655589187,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(38655589187),
//--TRIMMABLE-BOUNDARY-START(25770687299),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AuthenticateAsync",
      "d": 883523,
      "h": 25770687299,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770687299),
//--TRIMMABLE-BOUNDARY-START(34360621891),
    {
      "r": 181338113,
      "p": [
        {
          "n": "caller",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogOut",
      "d": 883523,
      "h": 34360621891,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(34360621891)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885785411),
    {
      "t": 327718,
      "n": "_provider",
      "d": 883523,
      "h": 12885785411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885785411),
//--TRIMMABLE-BOUNDARY-START(17180752707),
    {
      "t": 1720706,
      "n": "_ticketStore",
      "d": 883523,
      "h": 17180752707,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180752707),
//--TRIMMABLE-BOUNDARY-START(8590818115),
    {
      "t": 64509610,
      "n": "_javaScript",
      "d": 883523,
      "h": 8590818115,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590818115),
//--TRIMMABLE-BOUNDARY-START(4295850819),
    {
      "t": 327801,
      "n": "_authenticationProvider",
      "d": 883523,
      "h": 4295850819,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295850819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475720003),
    {
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "context",
          "p": 46041430
        },
        {
          "n": "javaScript",
          "p": 64509610
        },
        {
          "n": "ticketStore",
          "p": 1720706
        },
        {
          "n": "authenticationProvider",
          "p": 327801
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 883523,
      "h": 21475720003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475720003)
  ],
  "h": 883523
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationService, $.$GfYa.LCFCA.IReadOnlyAuthenticationService, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Services.BlazorServerAuthenticationStateProviderService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Services${separator}BlazorServerAuthenticationStateProviderService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(883523)
        
        

        //--TRIMMABLE-BOUNDARY-START(1080131)
        $asm.$cls(`$uVBI.LCACS.TokenBasedAuthenticationService`, ($self) => class TokenBasedAuthenticationService extends $.$DZqk.LCACS.AuthenticationServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(25770883907)
            /*string*/ static HeaderAuthorizationKey = null;
            //--TRIMMABLE-BOUNDARY-END(25770883907)
            
            //--TRIMMABLE-BOUNDARY-START(12885982019)
            $ctor$2(/*IServiceProvider*/ provider, /*IServerRemoteService*/ server, /*IConfigurationParser*/ config, /*IApplicationContextProvider*/ context, /*IEnumerable<IAuthenticationTicketStore>*/ storages)
            {
                super.$ctor$1(server, config, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885982019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._provider = provider;
                    this.ticketStorages = storages;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885982019)
            
            //--TRIMMABLE-BOUNDARY-START(4296047427)
            /*IServiceProvider*/ _provider = null;
            //--TRIMMABLE-BOUNDARY-END(4296047427)
            
            //--TRIMMABLE-BOUNDARY-START(55835654979)
            /*IEnumerable<IAuthenticationTicketStore>*/ ticketStorages = null;
            //--TRIMMABLE-BOUNDARY-END(55835654979)
            
            //--TRIMMABLE-BOUNDARY-START(34360818499)
            static /*void */ PopulateTicketFromClaims(/*ref DecodedAuthenticationTicket*/ ticket, /*IEnumerable<Claim>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360818499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ticket.$v.Id = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.Type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/);
                }, $uBuRCb ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null) ?? ticket.$v.Id;
                ticket.$v.UserName = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.Type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"/*ClaimTypes.Name*/);
                }, $zIfYXf ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null) ?? ticket.$v.UserName;
                ticket.$v.Email = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.Type, "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"/*ClaimTypes.Email*/);
                }, $wvwtnl ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null) ?? ticket.$v.Email;
                if (ticket.$v.Created === null)
                {
                    /*var*/ let lexp;
                    /*var*/ let _iat = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return $.$$.S.String.Equals$5.call(c.Type, "iat");
                    }, $XTtIVh ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null);
                    if (_iat !== null && $.$$.S.Int64.TryParse$6(_iat, $.$ref(() => lexp, ($v) => lexp = $v, $.$$.S.Int64)))
                    {
                        ticket.$v.Created = $.$fPer.LCFCDC.DateTimeExtension.DateTimeFromEpoch$1(lexp);
                    }
                }
                if (ticket.$v.Created === null)
                {
                    /*var*/ let crt = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return $.$$.S.String.Equals$5.call(c.Type, "Created");
                    }, $AJDedd ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null);
                    if (crt !== null)
                    {
                        /*var*/ let dt;
                        if ($.$$.S.DateTime.TryParse$3(crt, $.$ref(() => dt, ($v) => dt = $v, $.$$.S.DateTime)))
                        {
                            ticket.$v.Created = dt;
                        }
                    }
                }
                if (ticket.$v.Expires === null)
                {
                    /*var*/ let lexp;
                    /*var*/ let _exp = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return $.$$.S.String.Equals$5.call(c.Type, "exp");
                    }, $xKqKXc ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null);
                    if (_exp !== null && $.$$.S.Int64.TryParse$6(_exp, $.$ref(() => lexp, ($v) => lexp = $v, $.$$.S.Int64)))
                    {
                        ticket.$v.Expires = $.$fPer.LCFCDC.DateTimeExtension.DateTimeFromEpoch$1(lexp);
                    }
                }
                if (ticket.$v.Expires === null)
                {
                    /*var*/ let exp = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return $.$$.S.String.Equals$5.call(c.Type, "Expiration");
                    }, $mjPKXh ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}))?.Value ?? null);
                    if (exp !== null)
                    {
                        /*var*/ let dt;
                        if ($.$$.S.DateTime.TryParse$3(exp, $.$ref(() => dt, ($v) => dt = $v, $.$$.S.DateTime)))
                        {
                            ticket.$v.Expires = dt;
                        }
                    }
                }
                ticket.$v.Roles = $.$sl.SL.Enumerable.Select$1($.$ssc.SSC.Claim, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$ssc.SSC.Claim, claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.Type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/) || $.$$.S.String.Equals$2.call(c.Type, "Role", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $aGqLqd ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Value;
                }, $zKivgf ??= {"r":1310721,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794}));
                ticket.$v.Claims = claims;
            }
            //--TRIMMABLE-BOUNDARY-END(34360818499)
            
            //--TRIMMABLE-BOUNDARY-START(38655785795)
            static /*JwtSecurityToken */ PopulateTicketFromJWToken(/*string*/ token, /*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655785795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tokenHandler = new $.$sitj.SITJ.JwtSecurityTokenHandler().$ctor$3();
                $.$mil.MIL.IdentityModelEventSource.ShowPII = true;
                /*var*/ let jwtToken = tokenHandler.ReadJwtToken(token);
                ticket.Roles = $.$sl.SL.Enumerable.ToList($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$ssc.SSC.Claim, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$ssc.SSC.Claim, jwtToken.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.String.Equals$5.call(c.Type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/) || $.$$.S.String.Equals$2.call(c.Type, "Role", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                }, $YPdqnh ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Value;
                }, $UGbAmi ??= {"r":1310721,"p":[{"n":"c","p":131141}],"n":"","d":1080131,"h":0,"f":17825794})));
                ticket.Claims = $.$sl.SL.Enumerable.ToList($.$ssc.SSC.Claim, jwtToken.Claims) ?? new ($.$$.SCG.List$$($.$ssc.SSC.Claim))().$ctor$1();
                return jwtToken;
            }
            //--TRIMMABLE-BOUNDARY-END(38655785795)
            
            //--TRIMMABLE-BOUNDARY-START(51540687683)
            /*DecodedAuthenticationTicket?*/ ticket = null;
            //--TRIMMABLE-BOUNDARY-END(51540687683)
            
            //--TRIMMABLE-BOUNDARY-START(42950753091)
            /*(DecodedAuthenticationTicket Ticket,
#if CLIENT_VALIDATE_JWT
            //SecurityToken? Token,
#endif
            ClaimsPrincipal? Principal)?*/ properties = null;
            //--TRIMMABLE-BOUNDARY-END(42950753091)
            
            //--TRIMMABLE-BOUNDARY-START(47245720387)
            /*ValueTask *//*async*/  SetTicket(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245720387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ticket = ticket;
                    this.properties = null;
                    let $en5 = this.ticketStorages.SCG$IEnumerable$$$GetEnumerator();
                    while ($en5.SC$1$IEnumerator$MoveNext())
                    {
                        let ticketStorage = $en5.SCG$IEnumerator$$$Current;
                        {
                            let $t6, $r6;
                            ($t6 = ticketStorage.LCFCA$IAuthenticationTicketStore$SetTicket(ticket), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                    }
                    this.RaiseAuthenticationChanged(ticket);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245720387)
            
            //--TRIMMABLE-BOUNDARY-START(21475916611)
            /*ValueTask<(DecodedAuthenticationTicket Ticket,
#if CLIENT_VALIDATE_JWT
            //SecurityToken? Token,
#endif
            ClaimsPrincipal? Principal)> *//*async*/  GetSecurityProperties()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)), $.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475916611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$GfYa.LCFCA.DecodedAuthenticationTicket.op_Equality(this.ticket, null) || !this.ticket.IsValid())
                    {
                        let $en7 = this.ticketStorages.SCG$IEnumerable$$$GetEnumerator();
                        while ($en7.SC$1$IEnumerator$MoveNext())
                        {
                            let ticketStorage = $en7.SCG$IEnumerator$$$Current;
                            {
                                let $t8, $r8;
                                this.ticket = ($t8 = ticketStorage.LCFCA$IAuthenticationTicketStore$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                if (this.ticket.Token.JWToken !== null)
                                {
                                    break;
                                }
                            }
                        }
                    }
                    if ((this.ticket?.Token.JWToken ?? null) !== null)
                    {
                        try
                        {
                            let $t9, $r9;
                            /*AuthenticatedTokenResponse*/ let token = new $.$DZqk.LCACS.AuthenticatedTokenResponse();
                            /*var*/ let prop = ($t9 = $.$fPer.LCFC.LockExtensions.LockAsync$1($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal), this, new ($.$$.S.Func$$($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))))().$ctor(this, /*async*/  () =>
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)), $.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal), async ($asnycContext) => 
                                {
                                    if (this.properties !== null)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.S.Nullable$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)).Value$get.call(this.properties));
                                    }
                                    /*var*/ let tokenHandler = new $.$sitj.SITJ.JwtSecurityTokenHandler().$ctor$3();
                                    /*var*/ let jwtToken = $.$uVBI.LCACS.TokenBasedAuthenticationService.PopulateTicketFromJWToken(this.ticket.Token.JWToken, this.ticket);
                                    /*var*/ let prop = new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3(this.ticket, new $.$ssc.SSC.ClaimsPrincipal().$ctor$5(new $.$ssc.SSC.ClaimsIdentity().$ctor$3((jwtToken?.Claims ?? null) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ssc.SSC.Claim), null, [0], null), this.IsValid(new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3(this.ticket, null)) ? "token" : null)));
                                    this.properties = $.$clone(prop);
                                    return $.$$.N.AsyncResolver.Result($asnycContext, prop);
                                });
                            }, $BrCCEd ??= {"r":$.$$.STT.Task$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)).$h,"n":"","d":1080131,"h":0,"f":17829890}), null, true), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                            if ($.$GfYa.LCFCA.DecodedAuthenticationTicket.op_Inequality(token.RefreshedToken, null))
                            {
                                let $t10, $r10;
                                ($t10 = this.SetTicket(this.ticket), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, prop);
                        }
                        catch(e)
                        {
                            $.$scsl.S.Console.WriteLine$17(`Validating token exception ${$.$strNN(e.Message)}`);
                            return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3(this.ticket, this.GetPrincipal(this.ticket)));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal))().$ctor$3($.$GfYa.LCFCA.DecodedAuthenticationTicket.Default, null));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475916611)
            
            //--TRIMMABLE-BOUNDARY-START(17180949315)
            /*ValueTask<DecodedAuthenticationTicket> */ AuthenticateAsync(/*IAuthenticationClient?*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180949315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let uow = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, this._provider);
                /*ClientAuthenticationService*/ let service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACS.ClientAuthenticationService, this._provider);
                return service.AuthenticateAsync($.$hDPm.LCFCI.ViewConfiguration, uow.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, null, null, true, true, true, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17180949315)
            
            //--TRIMMABLE-BOUNDARY-START(30065851203)
            /*ValueTask *//*async*/  LogOut(/*IAuthenticationClient?*/ caller)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065851203);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en11 = this.ticketStorages.SCG$IEnumerable$$$GetEnumerator();
                    while ($en11.SC$1$IEnumerator$MoveNext())
                    {
                        let ticketStorage = $en11.SCG$IEnumerator$$$Current;
                        {
                            let $t12, $r12;
                            ($t12 = ticketStorage.LCFCA$IAuthenticationTicketStore$RemoveTicket(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        }
                    }
                    ($t13 = super.LogOut(caller), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065851203)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950753091)
                this.properties = null;
                //--TRIMMABLE-BOUNDARY-END(42950753091)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8591014723)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591014723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770883907)
                    this.HeaderAuthorizationKey = "Authorization";
                    //--TRIMMABLE-BOUNDARY-END(25770883907)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591014723)
            
            static $h = 1080131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$DZqk.LCACS.AuthenticationServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360818499),
    {
      "r": 65537,
      "p": [
        {
          "n": "ticket",
          "p": 1130882,
          "f": 4
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        }
      ],
      "n": "PopulateTicketFromClaims",
      "d": 1080131,
      "h": 34360818499,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360818499),
//--TRIMMABLE-BOUNDARY-START(38655785795),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "PopulateTicketFromJWToken",
      "d": 1080131,
      "h": 38655785795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655785795),
//--TRIMMABLE-BOUNDARY-START(47245720387),
    {
      "r": 181338113,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "SetTicket",
      "d": 1080131,
      "h": 47245720387,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(47245720387),
//--TRIMMABLE-BOUNDARY-START(21475916611),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)).$h,
      "n": "GetSecurityProperties",
      "d": 1080131,
      "h": 21475916611,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(21475916611),
//--TRIMMABLE-BOUNDARY-START(17180949315),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AuthenticateAsync",
      "d": 1080131,
      "h": 17180949315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180949315),
//--TRIMMABLE-BOUNDARY-START(30065851203),
    {
      "r": 181338113,
      "p": [
        {
          "n": "caller",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogOut",
      "d": 1080131,
      "h": 30065851203,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(30065851203)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770883907),
    {
      "t": 1310721,
      "n": "HeaderAuthorizationKey",
      "d": 1080131,
      "h": 25770883907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770883907),
//--TRIMMABLE-BOUNDARY-START(4296047427),
    {
      "t": 327718,
      "n": "_provider",
      "d": 1080131,
      "h": 4296047427,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296047427),
//--TRIMMABLE-BOUNDARY-START(55835654979),
    {
      "t": $.$$.SCG.IEnumerable$$($.$GfYa.LCFCA.IAuthenticationTicketStore).$h,
      "n": "ticketStorages",
      "d": 1080131,
      "h": 55835654979,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835654979),
//--TRIMMABLE-BOUNDARY-START(51540687683),
    {
      "t": 1130882,
      "n": "ticket",
      "d": 1080131,
      "h": 51540687683,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540687683),
//--TRIMMABLE-BOUNDARY-START(42950753091),
    {
      "t": $.$typeNullable($.$$.S.ValueTuple$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$ssc.SSC.ClaimsPrincipal)).$h,
      "n": "properties",
      "d": 1080131,
      "h": 42950753091,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950753091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885982019),
    {
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "context",
          "p": 46041430
        },
        {
          "n": "storages",
          "p": $.$$.SCG.IEnumerable$$($.$GfYa.LCFCA.IAuthenticationTicketStore).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1080131,
      "h": 12885982019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885982019)
  ],
  "h": 1080131
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationService, $.$GfYa.LCFCA.IReadOnlyAuthenticationService, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Services.TokenBasedAuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Services${separator}TokenBasedAuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1080131)
        
        

        //--TRIMMABLE-BOUNDARY-START(228163)
        $asm.$cls(`$uVBI.LCAC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590162755)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590162755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590162755)
            
            //--TRIMMABLE-BOUNDARY-START(4295195459)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295195459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295195459)
            
            //--TRIMMABLE-BOUNDARY-START(4295195459)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295195459)
            
            static $h = 228163;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590162755),
    {
      "r": 65537,
      "n": "Execute",
      "d": 228163,
      "h": 8590162755,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590162755)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295195459),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 228163,
      "h": 4295195459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295195459)
  ],
  "h": 228163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(228163)
        
        

        //--TRIMMABLE-BOUNDARY-START(1145667)
        $asm.$cls(`$uVBI.LCACS$1.ChangePassword`, ($self) => class ChangePassword extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(107375328067)
            /*string */ get OptimizedComponentName()
            {
                return "changepassword";
            }
            //--TRIMMABLE-BOUNDARY-END(107375328067)
            
            //--TRIMMABLE-BOUNDARY-START(163209902915)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209902915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$uVBI.LCACS$1.Root);
                    return true;
                    case "Client":
                    this.Client = $.$cast(parameter.Value, $.$GfYa.LCFCA.IAuthenticationClient);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(163209902915)
            
            //--TRIMMABLE-BOUNDARY-START(94490426179)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490426179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthorizationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(94490426179)
            
            //--TRIMMABLE-BOUNDARY-START(25770949443)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770949443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model = new $.$DZqk.LCACM.ChangePasswordRequestModel().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770949443)
            
            //--TRIMMABLE-BOUNDARY-START(30065916739)
            /*IClientAuthenticationService*/ AuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(30065916739)
            
            //--TRIMMABLE-BOUNDARY-START(111670295363)
            /*Root*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(111670295363)
            
            //--TRIMMABLE-BOUNDARY-START(38655851331)
            /*IAuthenticationClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(38655851331)
            
            //--TRIMMABLE-BOUNDARY-START(115965262659)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(115965262659)
            
            //--TRIMMABLE-BOUNDARY-START(98785393475)
            /*ChangePasswordRequestModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(98785393475)
            
            //--TRIMMABLE-BOUNDARY-START(103080360771)
            /*ValueTask */ OK(/*ChangePasswordRequestModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080360771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Root.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t2, $r2;
                        ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$3($.$DZqk.LCACS.IAuthenticationRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceMethod$$($.$DZqk.LCACS.IAuthenticationRemoteService))().$ctor(this,  (/**/ server) =>
                        {
                            return server.LCACS$IAuthenticationRemoteService$ChangePassword(model);
                        }, $luOXQf ??= {"r":178454529,"p":[{"n":"server","p":7259133}],"n":"","d":1145667,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.Root.SetAlert($.$fPer.LCFC.Theme.Success, "Password Changed. Please Login");
                    });
                }, $eHgdda ??= {"r":181338113,"n":"","d":1145667,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(103080360771)
            
            //--TRIMMABLE-BOUNDARY-START(34360884035)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360884035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$DZqk.LCACM.ChangePasswordRequestModel), 0);
                __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$DZqk.LCACM.ChangePasswordRequestModel, this.Model));
                __builder.AddComponentParameter(2, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$DZqk.LCACM.ChangePasswordRequestModel), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$DZqk.LCACM.ChangePasswordRequestModel, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$DZqk.LCACM.ChangePasswordRequestModel, $.$$.STT.ValueTask))().$ctor(this, this.OK))));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34360884035)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25770949443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770949443)
            
            static $h = 1145667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375328067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015589699,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1145667,
      "h": 107375328067,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107375328067),
//--TRIMMABLE-BOUNDARY-START(30065916739),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245785923,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555197251,
        "f": 83886081
      },
      "n": "AuthorizationManager",
      "d": 1145667,
      "h": 30065916739,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065916739),
//--TRIMMABLE-BOUNDARY-START(111670295363),
    {
      "p": 1604419,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605524291,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325001027,
        "f": 83886081
      },
      "n": "Root",
      "d": 1145667,
      "h": 111670295363,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670295363),
//--TRIMMABLE-BOUNDARY-START(38655851331),
    {
      "p": 1589634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835720515,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145131843,
        "f": 83886081
      },
      "n": "Client",
      "d": 1145667,
      "h": 38655851331,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655851331),
//--TRIMMABLE-BOUNDARY-START(115965262659),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195458883,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914935619,
        "f": 83886081
      },
      "n": "Server",
      "d": 1145667,
      "h": 115965262659,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965262659),
//--TRIMMABLE-BOUNDARY-START(98785393475),
    {
      "p": 1426429,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425655107,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735066435,
        "f": 83886082
      },
      "n": "Model",
      "d": 1145667,
      "h": 98785393475,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98785393475)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163209902915),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1145667,
      "h": 163209902915,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209902915),
//--TRIMMABLE-BOUNDARY-START(94490426179),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1145667,
      "h": 94490426179,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490426179),
//--TRIMMABLE-BOUNDARY-START(103080360771),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 1426429
        }
      ],
      "n": "OK",
      "d": 1145667,
      "h": 103080360771,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080360771),
//--TRIMMABLE-BOUNDARY-START(34360884035),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1145667,
      "h": 34360884035,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360884035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770949443),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1145667,
      "h": 25770949443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770949443)
  ],
  "h": 1145667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.ChangePassword`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}ChangePassword`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1145667)
        
        

        //--TRIMMABLE-BOUNDARY-START(1669955)
        $asm.$cls(`$uVBI.LCACS$1.WizardFormStep<>`, (T) => $asm.$gt(`$uVBI.LCACS$1.WizardFormStep<>`, [T], ($self) => class WizardFormStep$$ extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25771473731)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771473731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model ??= new T().$gctor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771473731)
            
            //--TRIMMABLE-BOUNDARY-START(154620492611)
            /*IWizardFormSteps*/ Steps = null;
            //--TRIMMABLE-BOUNDARY-END(154620492611)
            
            //--TRIMMABLE-BOUNDARY-START(94490950467)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(94490950467)
            
            //--TRIMMABLE-BOUNDARY-START(107375852355)
            /*Root*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(107375852355)
            
            //--TRIMMABLE-BOUNDARY-START(90195983171)
            /*T*/ Model = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(90195983171)
            
            //--TRIMMABLE-BOUNDARY-START(34361408323)
            /*FormBuilder<T>*/ Form = null;
            //--TRIMMABLE-BOUNDARY-END(34361408323)
            
            //--TRIMMABLE-BOUNDARY-START(163210427203)
            /*ValueTask<bool> */ Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210427203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Form.Validate($.$fPer.LCFCA$1.SchemaContext.op_Implicit$1(1/*SchemaType.Form*/));
            }
            //--TRIMMABLE-BOUNDARY-END(163210427203)
            
            //--TRIMMABLE-BOUNDARY-START(98785917763)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785917763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Steps.LCACS$1$IWizardFormSteps$AddWizardStep(this);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(98785917763)
            
            //--TRIMMABLE-BOUNDARY-START(103080885059)
            /*string */ get OptimizedComponentName()
            {
                return "wizardformstep";
            }
            //--TRIMMABLE-BOUNDARY-END(103080885059)
            
            //--TRIMMABLE-BOUNDARY-START(158915459907)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915459907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Steps":
                    this.Steps = $.$cast(parameter.Value, $.$uVBI.LCACS$1.IWizardFormSteps);
                    return true;
                    case "Name":
                    this.Name = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$uVBI.LCACS$1.Root);
                    return true;
                    case "Model":
                    this.Model = $.$cast(parameter.Value, T);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(158915459907)
            
            //--TRIMMABLE-BOUNDARY-START(30066441027)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066441027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), 0);
                __builder.AddComponentParameter(1, "Model", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(T, this.Model), T));
                __builder.AddComponentParameter(2, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, this.Root.FormTheme));
                __builder.AddComponentParameter(3, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                __builder.AddComponentParameter(4, "FieldFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$2.InputFieldFeatures, this.Root.FieldFeatures), $.$hDPm.LCFCCI$2.InputFieldFeatures));
                __builder.AddComponentParameter(5, "EditorFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, this.Root.EditorFeatures), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentReferenceCapture(6, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.Form = $.$cast(__value, $.$hDPm.LCFCCF$2.FormBuilder$$(T));
                }, $YiRTzi ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30066441027)
            
            //--TRIMMABLE-BOUNDARY-START(8591145795)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Shared.IWizardFormStep.Name.get
            get LCACS$1$IWizardFormStep$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886113091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8591145795)
            
            //--TRIMMABLE-BOUNDARY-START(17181080387)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Shared.IWizardFormStep.Validate()
            LCACS$1$IWizardFormStep$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181080387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181080387)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25771473731)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25771473731)
            
            static $H = 1669955;
            static $h = 1669955;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(154620492611),
    {
      "p": 1276739,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85901015875,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 150325525315,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 83886081
      },
      "n": "Steps",
      "d": this.$h,
      "H": 154620492611,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620492611),
//--TRIMMABLE-BOUNDARY-START(94490950467),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131212099,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133145656131,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "Name",
      "d": this.$h,
      "H": 94490950467,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490950467),
//--TRIMMABLE-BOUNDARY-START(107375852355),
    {
      "p": 1604419,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77311081283,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 141735590723,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 83886081
      },
      "n": "Root",
      "d": this.$h,
      "H": 107375852355,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375852355),
//--TRIMMABLE-BOUNDARY-START(90195983171),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541277507,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124555721539,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "Model",
      "d": this.$h,
      "H": 90195983171,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195983171),
//--TRIMMABLE-BOUNDARY-START(34361408323),
    {
      "p": $.$hDPm.LCFCCF$2.FormBuilder$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42951342915,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 115965786947,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "Form",
      "d": this.$h,
      "H": 34361408323,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361408323),
//--TRIMMABLE-BOUNDARY-START(103080885059),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721146691,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 103080885059,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080885059)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163210427203),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "Validate",
      "d": this.$h,
      "H": 163210427203,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210427203),
//--TRIMMABLE-BOUNDARY-START(98785917763),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 98785917763,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(98785917763),
//--TRIMMABLE-BOUNDARY-START(158915459907),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 158915459907,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158915459907),
//--TRIMMABLE-BOUNDARY-START(30066441027),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 30066441027,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30066441027)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771473731),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 25771473731,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771473731)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 4
    }
  ],
  "r": 1,
  "H": 1669955,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$uVBI.LCACS$1.IWizardFormStep, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.WizardFormStep<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}WizardFormStep$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1669955)
        
        

        //--TRIMMABLE-BOUNDARY-START(555843)
        $asm.$cls(`$uVBI.LCACP.App`, ($self) => class App extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42950228803)
            /*IAuthenticationService*/ AutenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(42950228803)
            
            //--TRIMMABLE-BOUNDARY-START(150324411203)
            /*IEnumerable<ILoginViewProvider>*/ LoginProviders = null;
            //--TRIMMABLE-BOUNDARY-END(150324411203)
            
            //--TRIMMABLE-BOUNDARY-START(158914345795)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(158914345795)
            
            //--TRIMMABLE-BOUNDARY-START(253403626307)
            /*string?*/ View = null;
            //--TRIMMABLE-BOUNDARY-END(253403626307)
            
            //--TRIMMABLE-BOUNDARY-START(38655261507)
            /*string?*/ Action = null;
            //--TRIMMABLE-BOUNDARY-END(38655261507)
            
            //--TRIMMABLE-BOUNDARY-START(184684149571)
            /*string?*/ ReturnUrl = null;
            //--TRIMMABLE-BOUNDARY-END(184684149571)
            
            //--TRIMMABLE-BOUNDARY-START(55835130691)
            /*string?*/ ForceDefault = null;
            //--TRIMMABLE-BOUNDARY-END(55835130691)
            
            //--TRIMMABLE-BOUNDARY-START(51540163395)
            /*AuthenticationClientDescriptor */ get Descriptor()
            {
                return (() =>
                {
                    //new $.$GfYa.LCFCA.AuthenticationClientDescriptor()
                    const $t1 = $.$GfYa.LCFCA.AuthenticationClientDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.ApplicationBaseUrl = "Authentication"/*AuthenticationExtension.RootWebPath*/;
                    $i1.ApplicationName = "SIT";
                    $i1.ApplicationScheme = "https://";
                    $i1.RegisterationEmailTemplateUrl = $.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/) + "/Template/RegisterEmail";
                    $i1.ResetPasswordEmailTemplateUrl = $.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/) + "/Template/ResetPassword";
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(51540163395)
            
            //--TRIMMABLE-BOUNDARY-START(141734476611)
            /*Type?*/ loginComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(141734476611)
            
            //--TRIMMABLE-BOUNDARY-START(146029443907)
            /*RenderFragment?*/ loginComponentView = null;
            //--TRIMMABLE-BOUNDARY-END(146029443907)
            
            //--TRIMMABLE-BOUNDARY-START(154619378499)
            /*ValueTask *//*async*/  Logout()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619378499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.AutenticationService.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154619378499)
            
            //--TRIMMABLE-BOUNDARY-START(167504280387)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504280387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ReturnUrl !== null)
                {
                    let $en3 = this.LoginProviders.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let provider = $en3.SCG$IEnumerator$$$Current;
                        {
                            /*OneOf<Type?, RenderFragment?>*/ let c = provider.LCFCI$ILoginViewProvider$TryGetLoginComponent(this.ReturnUrl);
                            if (c.IsT0 && c.AsT0 !== null)
                            {
                                this.loginComponentType = c.AsT0;
                                break;
                            }
                            else if (c.IsT1 && c.AsT1 !== null)
                            {
                                this.loginComponentView = c.AsT1;
                                break;
                            }
                        }
                    }
                }
                this.UnitOfWork.LCFCI$IClientUnitOfWork$Assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Authentication.Client.Blazor.css", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(167504280387)
            
            //--TRIMMABLE-BOUNDARY-START(163209313091)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209313091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(163209313091)
            
            //--TRIMMABLE-BOUNDARY-START(171799247683)
            /*ValueTask<bool> */ OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799247683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ReturnUrl !== null)
                {
                    this.Navigation.NavigateTo$2(this.ReturnUrl, true);
                }
                else 
                {
                    this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                }
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(171799247683)
            
            //--TRIMMABLE-BOUNDARY-START(176094214979)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094214979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(176094214979)
            
            //--TRIMMABLE-BOUNDARY-START(180389182275)
            /*string */ get OptimizedComponentName()
            {
                return "app";
            }
            //--TRIMMABLE-BOUNDARY-END(180389182275)
            
            //--TRIMMABLE-BOUNDARY-START(249108659011)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108659011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "View":
                    this.View = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Action":
                    this.Action = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "ReturnUrl":
                    this.ReturnUrl = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "ForceDefault":
                    this.ForceDefault = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(249108659011)
            
            //--TRIMMABLE-BOUNDARY-START(137439509315)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439509315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AutenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.LoginProviders = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$hDPm.LCFCI.ILoginViewProvider), serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(137439509315)
            
            //--TRIMMABLE-BOUNDARY-START(47245196099)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245196099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, "Login");
                }), $MdLVMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (this.loginComponentType !== null)
                {
                    __builder.OpenComponent$1($.$mac.MAC.DynamicComponent, 3);
                    __builder.AddComponentParameter(4, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, this.loginComponentType));
                    __builder.CloseComponent();
                }
                else if (this.loginComponentView !== null)
                {
                    __builder.AddContent$1(5, this.loginComponentView);
                }
                else if (this.ForceDefault === null && this.UnitOfWork.LCFCI$IClientUnitOfWork$Deployment.LCFCS$3$IApplicationDeploymentProvider$LoginComponent.IsT1 && this.UnitOfWork.LCFCI$IClientUnitOfWork$Deployment.LCFCS$3$IApplicationDeploymentProvider$LoginComponent.AsT1 !== null)
                {
                    __builder.OpenComponent$1($.$mac.MAC.DynamicComponent, 6);
                    __builder.AddComponentParameter(7, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, this.UnitOfWork.LCFCI$IClientUnitOfWork$Deployment.LCFCS$3$IApplicationDeploymentProvider$LoginComponent.AsT1));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(8, "div");
                    __builder.AddAttribute$5(9, "class", "clip pd hv-10 flex bg-cover");
                    __builder.AddAttribute$5(10, "style", $.$strNN("background-image:url(" + $.$strNN((this.ResolvePath("img/bg.jpg", true, true, false)))) + ")");
                    __builder.OpenElement(11, "div");
                    __builder.AddAttribute$5(12, "class", "mg-a");
                    __builder.OpenElement(13, "h2");
                    __builder.AddAttribute$5(14, "class", "cl-white text-center");
                    __builder.OpenComponent$1($.$maca.MACA.AuthorizeView, 15);
                    __builder.AddAttribute$3(16, "Authorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                        {
                            __builder2.OpenElement(17, "text");
                            __builder2.AddContent$4(18, "Welcome ");
                            __builder2.AddContent$4(19, (context.User.Identity?.SSP$1$IIdentity$Name ?? null));
                            __builder2.CloseElement();
                        }, $PNxvJk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794});
                    }), $eGVkhi ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":555843,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(20, "NotAuthorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(21, "\r\n                        Welcome Back!!!\r\n                    ");
                        }, $tVkXGg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794});
                    }), $dGLtLk ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":555843,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(22, "\r\n            ");
                    __builder.OpenElement(23, "div");
                    __builder.AddAttribute$5(24, "class", "bg-card pd mg-a");
                    __builder.AddAttribute$5(25, "style", "max-width:480px;min-width:320px");
                    __builder.OpenComponent$1($.$maca.MACA.AuthorizeView, 26);
                    __builder.AddAttribute$3(27, "Authorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(28, "<h3 class=\"text-center\">\r\n                            You are already logged in!!!\r\n                        </h3>\r\n                        What would you like to do instead?\r\n                        ");
                            __builder2.OpenElement(29, "a");
                            __builder2.AddAttribute$5(30, "class", "d-block mgt bg-dark pd-2");
                            __builder2.AddAttribute$5(31, "href", "javascript: void(0);");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 32, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Logout)));
                            __builder2.AddMarkupContent(33, "<i class=\"mdi mdi-logout mgr-2\"></i>\r\n                            ");
                            __builder2.AddMarkupContent(34, "<span>Log Out</span>");
                            __builder2.CloseElement();
                        }, $adkNye ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794});
                    }), $oLxkKb ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":555843,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(35, "NotAuthorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$uVBI.LCACS$1.Root, 36);
                            __builder2.AddComponentParameter(37, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this));
                            __builder2.AddComponentParameter(38, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this));
                            __builder2.AddComponentParameter(39, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder2.AddComponentParameter(40, "FormTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfPrimary(0.1)));
                            __builder2.AddComponentParameter(41, "Navigable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, false), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(42, "EditorFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                            __builder2.CloseComponent();
                        }, $ZSyzGc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794});
                    }), $yseQLf ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":555843,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(43, "\r\n            ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCQ.Quotable, 44);
                    __builder.AddAttribute$3(45, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCQ.Quote)))().$ctor(this, ( (/*quote*/ quote) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(46, "h2");
                            __builder2.AddAttribute$5(47, "class", "cl-white mgx text-center");
                            __builder2.AddContent$4(48, quote.Model.Text);
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(49, "\r\n                ");
                            __builder2.OpenElement(50, "h4");
                            __builder2.AddAttribute$5(51, "class", "text-right cl-white mgt-0");
                            __builder2.OpenElement(52, "i");
                            __builder2.AddContent$4(53, quote.Model.Author);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }, $gxNEJe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":555843,"h":0,"f":17825794});
                    }), $SXaNyc ??= {"r":6881395,"p":[{"n":"quote","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCQ.Quote).$h}],"n":"","d":555843,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245196099)
            
            //--TRIMMABLE-BOUNDARY-START(621379)
            static $___PrivateComponentRenderModeAttribute;
            static get __PrivateComponentRenderModeAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(621379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$uVBI.LCACP.App;
                return $cls.$___PrivateComponentRenderModeAttribute ??= $asm.$ncls(`$uVBI.LCACP.App.__PrivateComponentRenderModeAttribute`, ($self) => class __PrivateComponentRenderModeAttribute extends $.$mac.MAC.RenderModeAttribute
                {
                    //--TRIMMABLE-BOUNDARY-START(30065392451)
                    static /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get ModeImpl()
                    {
                        return $.$macw.MACW.RenderMode.InteractiveServer;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065392451)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770425155)
                    /*global::Microsoft.AspNetCore.Components.IComponentRenderMode */ get Mode()
                    {
                        return $.$uVBI.LCACP.App.__PrivateComponentRenderModeAttribute.ModeImpl;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770425155)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295588675)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295588675);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295588675)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295588675)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295588675)
                    
                    static $h = 621379;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mac.MAC.RenderModeAttribute; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065392451),
    {
      "p": 2883699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475457859,
        "f": 50331682
      },
      "n": "ModeImpl",
      "d": 621379,
      "h": 30065392451,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(30065392451),
//--TRIMMABLE-BOUNDARY-START(25770425155),
    {
      "p": 2883699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885523267,
        "f": 50364417
      },
      "n": "Mode",
      "d": 621379,
      "h": 25770425155,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770425155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295588675),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 621379,
      "h": 4295588675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295588675)
  ],
  "d": 555843,
  "h": 621379
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Pages.App+__PrivateComponentRenderModeAttribute`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Pages${separator}App${separator}__PrivateComponentRenderModeAttribute`; }
                }, $cls, ($v) => $cls.$___PrivateComponentRenderModeAttribute = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(621379)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34360294211)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360294211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360294211)
            
            //--TRIMMABLE-BOUNDARY-START(34360294211)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34360294211)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950228803)
                this.AutenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(42950228803)
                
                //--TRIMMABLE-BOUNDARY-START(150324411203)
                this.LoginProviders = null;
                //--TRIMMABLE-BOUNDARY-END(150324411203)
                
                //--TRIMMABLE-BOUNDARY-START(158914345795)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(158914345795)
                
            }
            static $h = 555843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950228803),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014999875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864018755,
        "f": 83886081
      },
      "n": "AutenticationService",
      "d": 555843,
      "h": 42950228803,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950228803),
//--TRIMMABLE-BOUNDARY-START(150324411203),
    {
      "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCI.ILoginViewProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784803651,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043887939,
        "f": 83886081
      },
      "n": "LoginProviders",
      "d": 555843,
      "h": 150324411203,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324411203),
//--TRIMMABLE-BOUNDARY-START(158914345795),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374738243,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633822531,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 555843,
      "h": 158914345795,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914345795),
//--TRIMMABLE-BOUNDARY-START(253403626307),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144542019,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813691715,
        "f": 83886081
      },
      "n": "View",
      "d": 555843,
      "h": 253403626307,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403626307),
//--TRIMMABLE-BOUNDARY-START(38655261507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425065283,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274084163,
        "f": 83886081
      },
      "n": "Action",
      "d": 555843,
      "h": 38655261507,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655261507),
//--TRIMMABLE-BOUNDARY-START(184684149571),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554607427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223757123,
        "f": 83886081
      },
      "n": "ReturnUrl",
      "d": 555843,
      "h": 184684149571,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684149571),
//--TRIMMABLE-BOUNDARY-START(55835130691),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194869059,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453953347,
        "f": 83886081
      },
      "n": "ForceDefault",
      "d": 555843,
      "h": 55835130691,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835130691),
//--TRIMMABLE-BOUNDARY-START(51540163395),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604934467,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 555843,
      "h": 51540163395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540163395),
//--TRIMMABLE-BOUNDARY-START(180389182275),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964672835,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 555843,
      "h": 180389182275,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389182275)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(154619378499),
    {
      "r": 181338113,
      "n": "Logout",
      "d": 555843,
      "h": 154619378499,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(154619378499),
//--TRIMMABLE-BOUNDARY-START(167504280387),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 555843,
      "h": 167504280387,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(167504280387),
//--TRIMMABLE-BOUNDARY-START(163209313091),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 555843,
      "h": 163209313091,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(163209313091),
//--TRIMMABLE-BOUNDARY-START(171799247683),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": 555843,
      "h": 171799247683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799247683),
//--TRIMMABLE-BOUNDARY-START(176094214979),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": 555843,
      "h": 176094214979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094214979),
//--TRIMMABLE-BOUNDARY-START(249108659011),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 555843,
      "h": 249108659011,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108659011),
//--TRIMMABLE-BOUNDARY-START(137439509315),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 555843,
      "h": 137439509315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439509315),
//--TRIMMABLE-BOUNDARY-START(47245196099),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 555843,
      "h": 47245196099,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245196099)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(141734476611),
    {
      "t": 188547073,
      "n": "loginComponentType",
      "d": 555843,
      "h": 141734476611,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141734476611),
//--TRIMMABLE-BOUNDARY-START(146029443907),
    {
      "t": 6881395,
      "n": "loginComponentView",
      "d": 555843,
      "h": 146029443907,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146029443907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360294211),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 555843,
      "h": 34360294211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360294211)
  ],
  "h": 555843,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": $.$hDPm.LCFCL.NoLayout$$($.$macw.MACW.InteractiveServerRenderMode).$h,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Authentication",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Authentication/{View}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Authentication/{View}/{Action}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Account/Login",
          "t": 1310721
        }
      ]
    },
    {
      "t": 621379,
      "c": 4295588675
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$GfYa.LCFCA.IAuthenticationClient, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$uVBI.LCACP.App.__PrivateComponentRenderModeAttribute ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Pages.App`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Pages${separator}App`; }
        });
        //--TRIMMABLE-BOUNDARY-END(555843)
        
        

        //--TRIMMABLE-BOUNDARY-START(1473347)
        $asm.$cls(`$uVBI.LCACS$1.Register`, ($self) => class Register extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(163210230595)
            /*string */ get OptimizedComponentName()
            {
                return "register";
            }
            //--TRIMMABLE-BOUNDARY-END(163210230595)
            
            //--TRIMMABLE-BOUNDARY-START(266289445699)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289445699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Index":
                    this.Index = $.$cast(parameter.Value, $.$uVBI.LCACP.App);
                    return true;
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$uVBI.LCACS$1.Root);
                    return true;
                    case "Client":
                    this.Client = $.$cast(parameter.Value, $.$GfYa.LCFCA.IAuthenticationClient);
                    return true;
                    case "Path":
                    this.Path = $.$cast(parameter.Value, $.$vWqU.LCFCC.IUINavigationPathSegment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(266289445699)
            
            //--TRIMMABLE-BOUNDARY-START(154620296003)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620296003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthorizationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.NavigationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(154620296003)
            
            //--TRIMMABLE-BOUNDARY-START(150325328707)
            /*Pages.App*/ Index = null;
            //--TRIMMABLE-BOUNDARY-END(150325328707)
            
            //--TRIMMABLE-BOUNDARY-START(176095132483)
            /*Root*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(176095132483)
            
            //--TRIMMABLE-BOUNDARY-START(60131015491)
            /*IAuthenticationClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(60131015491)
            
            //--TRIMMABLE-BOUNDARY-START(51541080899)
            /*IAuthenticationService*/ AuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(51541080899)
            
            //--TRIMMABLE-BOUNDARY-START(180390099779)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(180390099779)
            
            //--TRIMMABLE-BOUNDARY-START(158915263299)
            /*NavigationManager*/ NavigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(158915263299)
            
            //--TRIMMABLE-BOUNDARY-START(167505197891)
            /*IUINavigationPathSegment*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(167505197891)
            
            //--TRIMMABLE-BOUNDARY-START(47246113603)
            /*void */ AddWizardStep(/*IWizardFormStep*/ step)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246113603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let vem;
                if ($.$is(step, $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.VerifyEmailRequestModel), { set $v($v){ vem = $v; } }))
                {
                    this.VerifyEmailView = vem;
                }
                let rg;
                if ($.$is(step, $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.RegisterRequestModel), { set $v($v){ rg = $v; } }))
                {
                    this.RegisterView = rg;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246113603)
            
            //--TRIMMABLE-BOUNDARY-START(270584412995)
            /*WizardFormStep<VerifyEmailRequestModel>*/ VerifyEmailView = null;
            //--TRIMMABLE-BOUNDARY-END(270584412995)
            
            //--TRIMMABLE-BOUNDARY-START(171800165187)
            /*WizardFormStep<RegisterRequestModel>*/ RegisterView = null;
            //--TRIMMABLE-BOUNDARY-END(171800165187)
            
            //--TRIMMABLE-BOUNDARY-START(261994478403)
            /*Task *//*async*/  Step(/*ViewChangingEventArgs*/ stepping)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994478403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (stepping.ToName === "Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/ && this.Path !== null)
                    {
                        if ((this.Root.Metadata?.TokenPurpose ?? null) === 1/*AuthenticationTokenPurpose.Register*/ && this.Root.Metadata.TokenValue !== null)
                        {
                            this.Root.SetAlert($.$fPer.LCFC.Theme.Primary, "Choose a Username and Password");
                        }
                    }
                    /*IWizardFormStep[]*/ let steps = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uVBI.LCACS$1.IWizardFormStep), [this.VerifyEmailView, this.RegisterView], [-1], null);
                    if ($.$$.S.String.IsNullOrEmpty(stepping.FromName) && (stepping.ToName === "Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/ || stepping.ToName === "EmailSent") && ((this.Root.Metadata.TokenPurpose ?? 0/*AuthenticationTokenPurpose.None*/) === 0/*AuthenticationTokenPurpose.None*/))
                    {
                        let $t3, $r3;
                        if (this.Root.ValidateRegisteration !== null)
                        {
                            let $t2, $r2;
                            ($t2 = this.Root.ValidateRegisteration.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                        if (this.VerifyEmailView !== null && ($t3 = this.VerifyEmailView.Validate(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))))
                        {
                            let service = null;
                            try
                            {
                                service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$DZqk.LCACS.IAuthenticationRemoteService, null);
                                /*var*/ let model = this.VerifyEmailView.Model;
                                /*string?*/ let __ca1__;
                                model.Email = ((__ca1__ = model.Email) !== null ? $.$$.S.String.Trim.call(__ca1__) : null);
                                /*var*/ let descriptor = (this.Root.Client?.LCFCA$IAuthenticationClient$Descriptor ?? null);
                                model.Metadata = this.Root.BuildMetadata(model.Metadata);
                                if ((descriptor?.ApplicationBaseUrl ?? null) !== null)
                                {
                                    model.EmailClickLinkUrl = $.$fPer.LCFC.PathUtility.ToUrl(descriptor.ApplicationScheme, descriptor.ApplicationBaseUrl, $.$strNN(descriptor.AuthenticationPageRoute) + $.$strNN(`/${$.$strNN("Register"/*AuthenticationExtension.RegisterPath*/)}/${$.$strNN("Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/)}`));
                                }
                                else 
                                {
                                    model.EmailClickLinkUrl = `${$.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/)}/${$.$strNN("Register"/*AuthenticationExtension.RegisterPath*/)}/${$.$strNN("Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/)}`;
                                }
                                model.EmailTemplateUrl = (descriptor?.RegisterationEmailTemplateUrl ?? null) ?? `/${$.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/)}/Template/RegisterEmail`;
                                model.TokenLength = 6;
                                try
                                {
                                    let $t4, $r4;
                                    /*var*/ let result = ($t4 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAuthenticationRemoteService$SendRegisterationEmailVerificationToken(model), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (result.Success)
                                    {
                                        this.Root.SetAlert($.$fPer.LCFC.Theme.Info, `We sent an email to ${$.$strNN(this.VerifyEmailView.Model.Email)}. Provide the token code in the mail and choose a username and password.`);
                                    }
                                    else 
                                    {
                                        throw new $.$$.S.Exception().$ctor$4(result.Message);
                                    }
                                }
                                catch(e)
                                {
                                    this.Root.SetAlert($.$fPer.LCFC.Theme.Error, e.Message);
                                    throw e;
                                }
                                finally
                                {
                                    {
                                    }
                                }
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        }
                        else if (this.VerifyEmailView !== null)
                        {
                            throw new $.$$.S.Exception().$ctor$4("Invalid Entries");
                        }
                    }
                    else if (stepping.FromName === "Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/)
                    {
                        let $t5, $r5;
                        if (this.RegisterView !== null && ($t5 = this.RegisterView.Validate(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))))
                        {
                            let service = null;
                            try
                            {
                                service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$DZqk.LCACS.IAuthenticationRemoteService, null);
                                try
                                {
                                    let $t6, $r6;
                                    /*var*/ let descriptor = (this.Root.Client?.LCFCA$IAuthenticationClient$Descriptor ?? null);
                                    /*var*/ let model = this.RegisterView.Model;
                                    model.Metadata = model.Metadata.MergeWith(this.Root.Metadata);
                                    /*string?*/ let __ca2__;
                                    model.Metadata.TokenEmail = ((__ca2__ = this.VerifyEmailView.Model.Email) !== null ? $.$$.S.String.Trim.call(__ca2__) : null);
                                    model.UserName = $.$$.S.String.Trim.call(model.UserName);
                                    /*string?*/ let __ca3__;
                                    model.Email = ((__ca3__ = model.Email) !== null ? $.$$.S.String.Trim.call(__ca3__) : null);
                                    /*var*/ let result = ($t6 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAuthenticationRemoteService$Register(model), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    if (result.Success)
                                    {
                                        let $t7, $r7;
                                        let $t8, $r8;
                                        ($t7 = this.AuthorizationManager.LCFCA$IAuthenticationService$SetTicket(result.Data.Login.Ticket), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                        this.Root.SetAlert($.$fPer.LCFC.Theme.Success, "Registration Successful");
                                        ($t8 = this.Root.Registered(result.Data.Login.Ticket), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                    }
                                    else 
                                    {
                                        throw new $.$$.S.Exception().$ctor$4(result.Message);
                                    }
                                }
                                catch(e)
                                {
                                    this.Root.SetAlert($.$fPer.LCFC.Theme.Error, e.Message);
                                    throw e;
                                }
                                finally
                                {
                                    {
                                    }
                                }
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        }
                        else if (this.RegisterView !== null)
                        {
                            throw new $.$$.S.Exception().$ctor$4("Invalid Entries");
                        }
                    }
                    else if (stepping.From > stepping.To)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    else if (stepping.From > 0)
                    {
                        let $t9, $r9;
                        if (!($t9 = (($.$$.System.Array.$ReadT1.call(steps, stepping.From)?.LCACS$1$IWizardFormStep$Validate() ?? null) ?? $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true)), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))))
                        {
                            throw new $.$$.S.Exception().$ctor$4("Invalid Entries");
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(261994478403)
            
            //--TRIMMABLE-BOUNDARY-START(55836048195)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836048195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uVBI._LCACSR.TypeInference.CreateCascadingValue_0($.$uVBI.LCACS$1.Register, __builder, 0, 1, this, 2, true, 3, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 4);
                    __builder2.AddComponentParameter(5, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$10($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.Task))().$ctor(this, this.Step))));
                    __builder2.AddComponentParameter(6, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder2.AddComponentParameter(7, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Register"/*AuthenticationExtension.RegisterPath*/)));
                    __builder2.AddComponentParameter(8, "Navigable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, (this.Root?.Navigable ?? null) ?? false), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(9, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, (this.Root?.FormTheme ?? null) ?? this.Theme));
                    __builder2.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 11);
                        __builder3.AddComponentParameter(12, "Name", "");
                        __builder3.AddComponentParameter(13, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                        __builder3.AddComponentParameter(14, "NextButtonText", "Verify Email");
                        __builder3.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(16, "<p></p>\r\n            ");
                                __builder4.OpenComponent$1($.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.VerifyEmailRequestModel), 17);
                                __builder4.AddComponentParameter(18, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this.Root));
                                __builder4.CloseComponent();
                            }, $cdqmjj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1473347,"h":0,"f":17825794});
                        }), $nbouSj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1473347,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(19, "\r\n        ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 20);
                        __builder3.AddComponentParameter(21, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/));
                        __builder3.AddComponentParameter(22, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Credentials"/*AuthenticationExtension.RegisterCendentialsPath*/)));
                        __builder3.AddComponentParameter(23, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~2/*WizardFeatures.Previous*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                        __builder3.AddComponentParameter(24, "NextButtonText", "Continue");
                        __builder3.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.RegisterRequestModel), 26);
                                __builder4.AddComponentParameter(27, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this.Root));
                                __builder4.CloseComponent();
                            }, $uPvwra ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1473347,"h":0,"f":17825794});
                        }), $lNydph ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1473347,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(28, "\r\n        ");
                        __builder3.AddContent$1(29, (this.Root?.RegisterChildContent?.Invoke(0) ?? null));
                    }), $IbBdsg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1473347,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $FLWcwh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1473347,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55836048195)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296244035)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Shared.IWizardFormSteps.AddWizardStep(LivingThing.Core.Authentication.Client.Shared.IWizardFormStep)
            LCACS$1$IWizardFormSteps$AddWizardStep()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296244035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddWizardStep(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296244035)
            
            //--TRIMMABLE-BOUNDARY-START(42951146307)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951146307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951146307)
            
            //--TRIMMABLE-BOUNDARY-START(42951146307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42951146307)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51541080899)
                this.AuthorizationManager = null;
                //--TRIMMABLE-BOUNDARY-END(51541080899)
                
                //--TRIMMABLE-BOUNDARY-START(180390099779)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(180390099779)
                
                //--TRIMMABLE-BOUNDARY-START(158915263299)
                this.NavigationManager = null;
                //--TRIMMABLE-BOUNDARY-END(158915263299)
                
            }
            static $h = 1473347;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163210230595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080688451,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1473347,
      "h": 163210230595,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163210230595),
//--TRIMMABLE-BOUNDARY-START(150325328707),
    {
      "p": 555843,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900819267,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159903555,
        "f": 83886081
      },
      "n": "Index",
      "d": 1473347,
      "h": 150325328707,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325328707),
//--TRIMMABLE-BOUNDARY-START(176095132483),
    {
      "p": 1604419,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850492227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519641923,
        "f": 83886081
      },
      "n": "Root",
      "d": 1473347,
      "h": 176095132483,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095132483),
//--TRIMMABLE-BOUNDARY-START(60131015491),
    {
      "p": 1589634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310884675,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569968963,
        "f": 83886081
      },
      "n": "Client",
      "d": 1473347,
      "h": 60131015491,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131015491),
//--TRIMMABLE-BOUNDARY-START(51541080899),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720950083,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980034371,
        "f": 83886081
      },
      "n": "AuthorizationManager",
      "d": 1473347,
      "h": 51541080899,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541080899),
//--TRIMMABLE-BOUNDARY-START(180390099779),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440426819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109576515,
        "f": 83886081
      },
      "n": "Server",
      "d": 1473347,
      "h": 180390099779,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180390099779),
//--TRIMMABLE-BOUNDARY-START(158915263299),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490753859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749838147,
        "f": 83886081
      },
      "n": "NavigationManager",
      "d": 1473347,
      "h": 158915263299,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915263299),
//--TRIMMABLE-BOUNDARY-START(167505197891),
    {
      "p": 5070248,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670623043,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339772739,
        "f": 83886082
      },
      "n": "Path",
      "d": 1473347,
      "h": 167505197891,
      "f": 2097154,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505197891),
//--TRIMMABLE-BOUNDARY-START(270584412995),
    {
      "p": $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.VerifyEmailRequestModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030361411,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699511107,
        "f": 83886088
      },
      "n": "VerifyEmailView",
      "d": 1473347,
      "h": 270584412995,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(270584412995),
//--TRIMMABLE-BOUNDARY-START(171800165187),
    {
      "p": $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.RegisterRequestModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260557635,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929707331,
        "f": 83886088
      },
      "n": "RegisterView",
      "d": 1473347,
      "h": 171800165187,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171800165187)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(266289445699),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1473347,
      "h": 266289445699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266289445699),
//--TRIMMABLE-BOUNDARY-START(154620296003),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1473347,
      "h": 154620296003,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620296003),
//--TRIMMABLE-BOUNDARY-START(47246113603),
    {
      "r": 65537,
      "p": [
        {
          "n": "step",
          "p": 1211203
        }
      ],
      "n": "AddWizardStep",
      "d": 1473347,
      "h": 47246113603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246113603),
//--TRIMMABLE-BOUNDARY-START(261994478403),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stepping",
          "p": 38098602
        }
      ],
      "n": "Step",
      "d": 1473347,
      "h": 261994478403,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(261994478403),
//--TRIMMABLE-BOUNDARY-START(55836048195),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1473347,
      "h": 55836048195,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55836048195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951146307),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1473347,
      "h": 42951146307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951146307)
  ],
  "h": 1473347
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$uVBI.LCACS$1.IWizardFormSteps ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.Register`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}Register`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1473347)
        
        

        //--TRIMMABLE-BOUNDARY-START(1538883)
        $asm.$cls(`$uVBI.LCACS$1.ResetPassword`, ($self) => class ResetPassword extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(171800230723)
            /*string */ get OptimizedComponentName()
            {
                return "resetpassword";
            }
            //--TRIMMABLE-BOUNDARY-END(171800230723)
            
            //--TRIMMABLE-BOUNDARY-START(283469380419)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469380419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Index":
                    this.Index = $.$cast(parameter.Value, $.$uVBI.LCACP.App);
                    return true;
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$uVBI.LCACS$1.Root);
                    return true;
                    case "Client":
                    this.Client = $.$cast(parameter.Value, $.$GfYa.LCFCA.IAuthenticationClient);
                    return true;
                    case "Path":
                    this.Path = $.$cast(parameter.Value, $.$vWqU.LCFCC.IUINavigationPathSegment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(283469380419)
            
            //--TRIMMABLE-BOUNDARY-START(154620361539)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620361539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthorizationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.NavigationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(154620361539)
            
            //--TRIMMABLE-BOUNDARY-START(150325394243)
            /*Pages.App?*/ Index = null;
            //--TRIMMABLE-BOUNDARY-END(150325394243)
            
            //--TRIMMABLE-BOUNDARY-START(188980099907)
            /*Root?*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(188980099907)
            
            //--TRIMMABLE-BOUNDARY-START(60131081027)
            /*IAuthenticationClient?*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(60131081027)
            
            //--TRIMMABLE-BOUNDARY-START(51541146435)
            /*IClientAuthenticationService*/ AuthorizationManager = null;
            //--TRIMMABLE-BOUNDARY-END(51541146435)
            
            //--TRIMMABLE-BOUNDARY-START(193275067203)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(193275067203)
            
            //--TRIMMABLE-BOUNDARY-START(163210296131)
            /*NavigationManager*/ NavigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(163210296131)
            
            //--TRIMMABLE-BOUNDARY-START(176095198019)
            /*IUINavigationPathSegment?*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(176095198019)
            
            //--TRIMMABLE-BOUNDARY-START(158915328835)
            /*ValueTask *//*async*/  Login()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915328835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = ((this.Root?.Tabs?.SetCurrentView$1(0) ?? null) ?? (this.Root?.LoginView?.SetCurrentView$1(0) ?? null) ?? $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158915328835)
            
            //--TRIMMABLE-BOUNDARY-START(167505263427)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505263427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.Root?.Metadata?.TokenPurpose ?? null) === 2/*AuthenticationTokenPurpose.ResetPassword*/ && this.Root.Metadata.TokenValue !== null)
                {
                    this.Root.SetAlert($.$fPer.LCFC.Theme.Info, "Provide new password");
                }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(167505263427)
            
            //--TRIMMABLE-BOUNDARY-START(184685132611)
            /*WizardFormStep<ResetTokenRequestModel>?*/ ResetTokenView = null;
            //--TRIMMABLE-BOUNDARY-END(184685132611)
            
            //--TRIMMABLE-BOUNDARY-START(180390165315)
            /*WizardFormStep<ResetRequestModel>?*/ ResetRequestView = null;
            //--TRIMMABLE-BOUNDARY-END(180390165315)
            
            //--TRIMMABLE-BOUNDARY-START(47246179139)
            /*void */ AddWizardStep(/*IWizardFormStep*/ step)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246179139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let vem;
                if ($.$is(step, $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetTokenRequestModel), { set $v($v){ vem = $v; } }))
                {
                    this.ResetTokenView = vem;
                }
                let rg;
                if ($.$is(step, $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetRequestModel), { set $v($v){ rg = $v; } }))
                {
                    this.ResetRequestView = rg;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246179139)
            
            //--TRIMMABLE-BOUNDARY-START(279174413123)
            /*string?*/ token = null;
            //--TRIMMABLE-BOUNDARY-END(279174413123)
            
            //--TRIMMABLE-BOUNDARY-START(274879445827)
            /*Task *//*async*/  Step(/*ViewChangingEventArgs*/ stepping)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274879445827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrEmpty(stepping.FromName) && stepping.To !== 0)
                    {
                        let $t3, $r3;
                        if (stepping.ToName === "NewPassword"/*AuthenticationExtension.ChooseNewPasswordPath*/ && (this.Root?.Metadata?.TokenValue ?? null) !== null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        else if (this.ResetTokenView !== null && ($t3 = this.ResetTokenView.Validate(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))))
                        {
                            {
                                /*var*/ let descriptor = (this.Root?.Client?.LCFCA$IAuthenticationClient$Descriptor ?? null);
                                /*var*/ let model = this.ResetTokenView.Model;
                                model.Metadata = (this.Root?.BuildMetadata(model.Metadata) ?? null);
                                if ((descriptor?.ApplicationBaseUrl ?? null) !== null)
                                {
                                    model.EmailClickLinkUrl = $.$fPer.LCFC.PathUtility.ToUrl(descriptor.ApplicationScheme, descriptor.ApplicationBaseUrl, $.$strNN(descriptor.AuthenticationPageRoute) + $.$strNN(`/${$.$strNN("Reset"/*AuthenticationExtension.ResetPasswordPath*/)}/${$.$strNN("NewPassword"/*AuthenticationExtension.ChooseNewPasswordPath*/)}`));
                                }
                                else 
                                {
                                    model.EmailClickLinkUrl = `${$.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/)}/${$.$strNN("Reset"/*AuthenticationExtension.ResetPasswordPath*/)}/${$.$strNN("NewPassword"/*AuthenticationExtension.ChooseNewPasswordPath*/)}`;
                                }
                                model.EmailTemplateUrl = (descriptor?.ResetPasswordEmailTemplateUrl ?? null) ?? `${$.$strNN("Authentication"/*AuthenticationExtension.RootWebPath*/)}/Template/ResetPassword`;
                                model.TokenLength = 6;
                                let service = null;
                                try
                                {
                                    service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$DZqk.LCACS.IAuthenticationRemoteService, null);
                                    try
                                    {
                                        let $t4, $r4;
                                        /*var*/ let result = ($t4 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAuthenticationRemoteService$SendResetPasswordToken(model), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        if (result.Success)
                                        {
                                            this.Root?.SetAlert($.$fPer.LCFC.Theme.Info, `We sent an email to ${$.$strNN(this.ResetTokenView.Model.UserNameOrEmail)}. Click the link there to continue or provide the token code in the mail`);
                                        }
                                        else 
                                        {
                                            throw new $.$$.S.Exception().$ctor$4(result.Message);
                                        }
                                    }
                                    catch(e)
                                    {
                                        this.Root?.SetAlert($.$fPer.LCFC.Theme.Error, e.Message);
                                        throw e;
                                    }
                                }
                                finally
                                {
                                    service?.S$IDisposable$Dispose();
                                }
                            }
                        }
                        else 
                        {
                            throw new $.$$.S.Exception().$ctor$4("Invalid Entries");
                        }
                    }
                    else if (stepping.FromName === "EmailSent")
                    {
                        if (this.token === null || this.token.length !== 6)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter the token sent to your email");
                        }
                        this.Root?.SetAlert($.$fPer.LCFC.Theme.Success, "Choose a New Password");
                    }
                    else if (stepping.FromName === "NewPassword"/*AuthenticationExtension.ChooseNewPasswordPath*/)
                    {
                        let $t5, $r5;
                        if (this.ResetRequestView !== null && ($t5 = this.ResetRequestView.Validate(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))))
                        {
                            /*var*/ let model = this.ResetRequestView.Model;
                            model.Metadata = $.$with(((this.Root?.Metadata?.MergeWith(model.Metadata) ?? null) ?? new $.$GfYa.LCFCA.AuthenticationMetadata().$ctor$1()), ($clone) =>
                            {
                                $clone.TokenEmail = (this.ResetTokenView?.Model.UserNameOrEmail ?? null);
                                $clone.TokenValue = this.token;
                            });
                            let service = null;
                            try
                            {
                                service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$DZqk.LCACS.IAuthenticationRemoteService, null);
                                try
                                {
                                    let $t6, $r6;
                                    /*var*/ let result = ($t6 = service.LCFCS$3$IServiceProxy$$$Service.LCACS$IAuthenticationRemoteService$ResetPassword(model), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    if (result.Success)
                                    {
                                        if (this.Root !== null)
                                        {
                                            let $t7, $r7;
                                            ($t7 = this.Root.PasswordReset(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                        }
                                        this.Root?.SetAlert($.$fPer.LCFC.Theme.Success, "Password Reset Successful!");
                                        if (!$.$$.S.String.IsNullOrEmpty((this.Root?.Metadata?.ReturnUrl ?? null)))
                                        {
                                            this.NavigationManager.NavigateTo$1(this.Root.Metadata.ReturnUrl, false, false);
                                        }
                                        else 
                                        {
                                            this.NavigationManager.NavigateTo$2(this.NavigationManager.Uri, true);
                                        }
                                    }
                                    else 
                                    {
                                        throw new $.$$.S.Exception().$ctor$4(result.Message);
                                    }
                                }
                                catch(e)
                                {
                                    this.Root?.SetAlert($.$fPer.LCFC.Theme.Error, e.Message);
                                    throw e;
                                }
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        }
                        else 
                        {
                            throw new $.$$.S.Exception().$ctor$4("Invalid Entries");
                        }
                    }
                    else 
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(274879445827)
            
            //--TRIMMABLE-BOUNDARY-START(55836113731)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836113731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uVBI._LCACSR$1.TypeInference.CreateCascadingValue_0($.$uVBI.LCACS$1.ResetPassword, __builder, 0, 1, this, 2, true, 3, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 4);
                    __builder2.AddComponentParameter(5, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Reset"/*AuthenticationExtension.ResetPasswordPath*/));
                    __builder2.AddComponentParameter(6, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, (this.Root?.FormTheme ?? null) ?? this.Theme));
                    __builder2.AddComponentParameter(7, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Reset"/*AuthenticationExtension.ResetPasswordPath*/)));
                    __builder2.AddComponentParameter(8, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$10($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Func$$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs, $.$$.STT.Task))().$ctor(this, this.Step))));
                    __builder2.AddComponentParameter(9, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder2.AddComponentParameter(10, "Navigable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, (this.Root?.Navigable ?? null) ?? false), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(11, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder2.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 13);
                        __builder3.AddComponentParameter(14, "Name", "");
                        __builder3.AddComponentParameter(15, "NextButtonText", "Continue");
                        __builder3.AddComponentParameter(16, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                        __builder3.AddAttribute$3(17, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetTokenRequestModel), 18);
                                __builder4.AddComponentParameter(19, "Name", "");
                                __builder4.AddComponentParameter(20, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this.Root));
                                __builder4.CloseComponent();
                            }, $BTbCbg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1538883,"h":0,"f":17825794});
                        }), $ezJbyj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1538883,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(21, "\r\n        ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 22);
                        __builder3.AddComponentParameter(23, "Name", "EmailSent");
                        __builder3.AddComponentParameter(24, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~2/*WizardFeatures.Previous*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                        __builder3.AddComponentParameter(25, "NextButtonText", "Continue");
                        __builder3.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                $.$uVBI._LCACSR$1.TypeInference.CreateInputEditor_1($.$$.S.String, __builder4, 27, 28, 79n, 29, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/, 30, $.$fPer.LCFC.Theme.Primary, 31, "fsz-20", 32, this.token, 33, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                                {
                                    return this.token = __value;
                                }, $hWxCPc ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1538883,"h":0,"f":17825794}), this.token)), 34, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "token"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $wbCvNb ??= {"r":38797349,"n":"","d":1538883,"h":0,"f":17825794})).Invoke()));
                            }, $OGcXAf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1538883,"h":0,"f":17825794});
                        }), $WFwEdb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1538883,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(35, "\r\n        ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 36);
                        __builder3.AddComponentParameter(37, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "NewPassword"/*AuthenticationExtension.ChooseNewPasswordPath*/));
                        __builder3.AddComponentParameter(38, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~2/*WizardFeatures.Previous*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                        __builder3.AddComponentParameter(39, "NextButtonText", "Change Password");
                        __builder3.AddAttribute$3(40, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetRequestModel), 41);
                                __builder4.AddComponentParameter(42, "Name", "NewPassword");
                                __builder4.AddComponentParameter(43, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this.Root));
                                __builder4.CloseComponent();
                            }, $EoWgai ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1538883,"h":0,"f":17825794});
                        }), $UMNdmi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1538883,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(44, "\r\n        ");
                        __builder3.OpenElement(45, "div");
                        __builder3.AddAttribute$5(46, "class", "text-right mgt");
                        __builder3.OpenElement(47, "a");
                        __builder3.AddAttribute$5(48, "href", "javascript: void(0);");
                        __builder3.AddAttribute$5(49, "class", "cl-text");
                        __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 50, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, $.$hDPm.LCFCC$1.ComponentExtension.NoStateChanged$2((new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Login)))));
                        __builder3.AddContent$4(51, "Login?");
                        __builder3.CloseElement();
                        __builder3.CloseElement();
                    }), $qwaXOg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1538883,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $hkYVWe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1538883,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55836113731)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296244035)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Shared.IWizardFormSteps.AddWizardStep(LivingThing.Core.Authentication.Client.Shared.IWizardFormStep)
            LCACS$1$IWizardFormSteps$AddWizardStep()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296244035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddWizardStep(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296244035)
            
            //--TRIMMABLE-BOUNDARY-START(42951211843)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951211843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951211843)
            
            //--TRIMMABLE-BOUNDARY-START(42951211843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42951211843)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51541146435)
                this.AuthorizationManager = null;
                //--TRIMMABLE-BOUNDARY-END(51541146435)
                
                //--TRIMMABLE-BOUNDARY-START(193275067203)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(193275067203)
                
                //--TRIMMABLE-BOUNDARY-START(163210296131)
                this.NavigationManager = null;
                //--TRIMMABLE-BOUNDARY-END(163210296131)
                
            }
            static $h = 1538883;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171800230723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080753987,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1538883,
      "h": 171800230723,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171800230723),
//--TRIMMABLE-BOUNDARY-START(150325394243),
    {
      "p": 555843,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900884803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044870979,
        "f": 83886081
      },
      "n": "Index",
      "d": 1538883,
      "h": 150325394243,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325394243),
//--TRIMMABLE-BOUNDARY-START(188980099907),
    {
      "p": 1604419,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440492355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994543939,
        "f": 83886081
      },
      "n": "Root",
      "d": 1538883,
      "h": 188980099907,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980099907),
//--TRIMMABLE-BOUNDARY-START(60131081027),
    {
      "p": 1589634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310950211,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454936387,
        "f": 83886081
      },
      "n": "Client",
      "d": 1538883,
      "h": 60131081027,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131081027),
//--TRIMMABLE-BOUNDARY-START(51541146435),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721015619,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201865001795,
        "f": 83886081
      },
      "n": "AuthorizationManager",
      "d": 1538883,
      "h": 51541146435,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541146435),
//--TRIMMABLE-BOUNDARY-START(193275067203),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030426947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584478531,
        "f": 83886081
      },
      "n": "Server",
      "d": 1538883,
      "h": 193275067203,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193275067203),
//--TRIMMABLE-BOUNDARY-START(163210296131),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490819395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634805571,
        "f": 83886081
      },
      "n": "NavigationManager",
      "d": 1538883,
      "h": 163210296131,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210296131),
//--TRIMMABLE-BOUNDARY-START(176095198019),
    {
      "p": 5070248,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670688579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224740163,
        "f": 83886081
      },
      "n": "Path",
      "d": 1538883,
      "h": 176095198019,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095198019),
//--TRIMMABLE-BOUNDARY-START(184685132611),
    {
      "p": $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetTokenRequestModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850557763,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404609347,
        "f": 83886088
      },
      "n": "ResetTokenView",
      "d": 1538883,
      "h": 184685132611,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(184685132611),
//--TRIMMABLE-BOUNDARY-START(180390165315),
    {
      "p": $.$uVBI.LCACS$1.WizardFormStep$$($.$DZqk.LCACM.ResetRequestModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260623171,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814674755,
        "f": 83886088
      },
      "n": "ResetRequestView",
      "d": 1538883,
      "h": 180390165315,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180390165315)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(283469380419),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1538883,
      "h": 283469380419,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283469380419),
//--TRIMMABLE-BOUNDARY-START(154620361539),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1538883,
      "h": 154620361539,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620361539),
//--TRIMMABLE-BOUNDARY-START(158915328835),
    {
      "r": 181338113,
      "n": "Login",
      "d": 1538883,
      "h": 158915328835,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158915328835),
//--TRIMMABLE-BOUNDARY-START(167505263427),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1538883,
      "h": 167505263427,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(167505263427),
//--TRIMMABLE-BOUNDARY-START(47246179139),
    {
      "r": 65537,
      "p": [
        {
          "n": "step",
          "p": 1211203
        }
      ],
      "n": "AddWizardStep",
      "d": 1538883,
      "h": 47246179139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246179139),
//--TRIMMABLE-BOUNDARY-START(274879445827),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stepping",
          "p": 38098602
        }
      ],
      "n": "Step",
      "d": 1538883,
      "h": 274879445827,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(274879445827),
//--TRIMMABLE-BOUNDARY-START(55836113731),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1538883,
      "h": 55836113731,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55836113731)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(279174413123),
    {
      "t": 1310721,
      "n": "token",
      "d": 1538883,
      "h": 279174413123,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(279174413123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951211843),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1538883,
      "h": 42951211843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951211843)
  ],
  "h": 1538883
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$uVBI.LCACS$1.IWizardFormSteps ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.ResetPassword`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}ResetPassword`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1538883)
        
        

        //--TRIMMABLE-BOUNDARY-START(1407811)
        $asm.$cls(`$uVBI.LCACS$1.Profile`, ($self) => class Profile extends $.$hDPm.LCFCC$1.BaseContainer
        {
            //--TRIMMABLE-BOUNDARY-START(98785655619)
            /*string */ get OptimizedComponentName()
            {
                return "profile";
            }
            //--TRIMMABLE-BOUNDARY-END(98785655619)
            
            //--TRIMMABLE-BOUNDARY-START(141735328579)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735328579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Client":
                    this.Client = $.$cast(parameter.Value, $.$GfYa.LCFCA.IAuthenticationClient);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(141735328579)
            
            //--TRIMMABLE-BOUNDARY-START(81605786435)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605786435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(81605786435)
            
            //--TRIMMABLE-BOUNDARY-START(25771211587)
            /*IAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(25771211587)
            
            //--TRIMMABLE-BOUNDARY-START(94490688323)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(94490688323)
            
            //--TRIMMABLE-BOUNDARY-START(103080622915)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(103080622915)
            
            //--TRIMMABLE-BOUNDARY-START(34361146179)
            /*IAuthenticationClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(34361146179)
            
            //--TRIMMABLE-BOUNDARY-START(90195721027)
            /*void *//*async*/  LogOut()
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195721027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = this.AuthenticationService.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    {
                        this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195721027)
            
            //--TRIMMABLE-BOUNDARY-START(85900753731)
            /*ValueTask */ LogIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900753731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CancellationTokenSource*/ let loginCancel = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                return $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.Prompt, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                    {
                        builder.OpenComponent$1($.$uVBI.LCACS$1.Root, 1);
                        builder.AddAttribute$4(2, "Theme", $.$fPer.LCFC.Theme.Primary);
                        builder.AddAttribute$4(3, "FormTheme", $.$fPer.LCFC.Theme.Primary);
                        if (this.Client !== null)
                        {
                            builder.AddAttribute$4(4, "Client", this.Client);
                        }
                        builder.AddAttribute$2(5, "Navigable", false);
                        builder.AddAttribute$7($.$GfYa.LCFCA.DecodedAuthenticationTicket, 6, "OnLogggedin", $.$mac.MAC.EventCallback.Factory.Create$8($.$GfYa.LCFCA.DecodedAuthenticationTicket, this, new ($.$$.S.Action$$($.$GfYa.LCFCA.DecodedAuthenticationTicket))().$ctor(this,  (/*ticket*/ ticket) =>
                        {
                            loginCancel.Cancel();
                        }, $ZeSsQh ??= {"r":65537,"p":[{"n":"ticket","p":1130882}],"n":"","d":1407811,"h":0,"f":17825794})));
                        builder.CloseComponent();
                    }, $TaCskf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794});
                }, $qILSsg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1407811,"h":0,"f":17825794}), null, null, loginCancel.Token, (() =>
                {
                    //new $.$hDPm.LCFCI.ViewConfiguration()
                    const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.ViewFeatures = 4/*ViewFeatures.Prompt*/ | 256/*ViewFeatures.CloseOnClickOut*/;
                    $i3.BodyAttributes = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-card");
                        return $i4;
                    })();
                    return $i3;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(85900753731)
            
            //--TRIMMABLE-BOUNDARY-START(30066178883)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066178883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "text-center");
                __builder.OpenComponent$1($.$maca.MACA.AuthorizeView, 2);
                __builder.AddAttribute$3(3, "Authorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "text-center wx-1 hx-1 mg-a round bd flex clip");
                        /*ResourceModel*/ let resource = null;
                        /*var*/ let idClaim = $.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, context.User.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.Type === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/;
                        }, $wvifjg ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1407811,"h":0,"f":17825794}));
                        /*var*/ let imageClaim = $.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, context.User.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.Type === "image";
                        }, $ScaKch ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1407811,"h":0,"f":17825794}));
                        if ((imageClaim?.Value ?? null) !== null)
                        {
                            /*var*/ let imageProperties = $.$$.S.String.Split$5.call(imageClaim.Value, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/***/ 42], [-1], null));
                            resource = (() =>
                            {
                                //new $.$Iaui.LCFCM.ResourceModel()
                                const $t5 = $.$Iaui.LCFCM.ResourceModel;
                                const $i5 = new $t5();
                                $i5.$ctor$3();
                                $i5.Identifier = $.$fPer.LCFCD.DataId.op_Implicit$1($.$$.System.Array.$ReadT1.call(imageProperties, 0));
                                $i5.Name = $.$$.System.Array.$ReadT1.call(imageProperties, 1);
                                return $i5;
                            })();
                        }
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 6);
                        __builder2.AddComponentParameter(7, "TargetId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, $.$fPer.LCFCD.DataId.op_Implicit$1((idClaim?.Value ?? null))));
                        __builder2.AddComponentParameter(8, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, resource));
                        __builder2.AddComponentParameter(9, "AltIconClass", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, resource === null ? `mdi mdi-account-circle` : null));
                        __builder2.AddComponentParameter(10, "Class", "fsz-80 op-7 mawp-10 mg-a");
                        __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~128/*MediaFeatures.UsePlaceHolder*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                        __builder2.AddComponentParameter(12, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(13, "\r\n                ");
                        __builder2.OpenElement(14, "h3");
                        __builder2.AddAttribute$5(15, "class", "mgy");
                        __builder2.OpenComponent$1($.$macw.MACR$2.NavLink, 16);
                        __builder2.AddComponentParameter(17, "href", "User");
                        __builder2.AddAttribute$3(18, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(19, "\r\n                        Hello ");
                            __builder3.AddContent$4(20, context.User.Identity.SSP$1$IIdentity$Name);
                        }), $aTLDIi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(21, "\r\n                ");
                        __builder2.AddContent$1(22, this.ChildContent);
                        __builder2.AddMarkupContent(23, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCR$4.Rounded, 24);
                        __builder2.AddComponentParameter(25, "Radius", "5");
                        __builder2.AddAttribute$3(26, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCP.Padding, 27);
                            __builder3.AddComponentParameter(28, "X", "10");
                            __builder3.AddComponentParameter(29, "Y", "3");
                            __builder3.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCS$5.Shadow, 31);
                                __builder4.AddComponentParameter(32, "Drop", "true");
                                __builder4.AddComponentParameter(33, "Spread", "1");
                                __builder4.AddAttribute$3(34, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 35);
                                    __builder5.AddComponentParameter(36, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder5.AddComponentParameter(37, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder5.AddComponentParameter(38, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.LogOut))));
                                    __builder5.AddAttribute$3(39, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                    {
                                        __builder6.AddMarkupContent(40, "\r\n                                LOGOUT\r\n                            ");
                                    }), $zvksgj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $VKVTLk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }), $TJkEQd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $JSqBcd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $FlJvMj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794});
                }), $Hofwga ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":1407811,"h":0,"f":17825794}));
                __builder.AddAttribute$3(41, "NotAuthorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(42, "<h3 class=\"mgb-0\">Hello Guest!</h3>\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 43);
                        __builder2.AddComponentParameter(44, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(45, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(46, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.LogIn))));
                        __builder2.AddComponentParameter(47, "Class", "miwx-1");
                        __builder2.AddAttribute$3(48, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(49, "\r\n                    LOGIN\r\n                ");
                        }), $enTkpe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $tHMFAi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1407811,"h":0,"f":17825794});
                }), $SXPJEe ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":1407811,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(30066178883)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476244291)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476244291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476244291)
            
            //--TRIMMABLE-BOUNDARY-START(21476244291)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21476244291)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771211587)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(25771211587)
                
                //--TRIMMABLE-BOUNDARY-START(94490688323)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(94490688323)
                
                //--TRIMMABLE-BOUNDARY-START(103080622915)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(103080622915)
                
            }
            static $h = 1407811;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseContainer; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98785655619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720884547,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1407811,
      "h": 98785655619,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785655619),
//--TRIMMABLE-BOUNDARY-START(25771211587),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951080771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670557507,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 1407811,
      "h": 25771211587,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771211587),
//--TRIMMABLE-BOUNDARY-START(94490688323),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130949955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850426691,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1407811,
      "h": 94490688323,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490688323),
//--TRIMMABLE-BOUNDARY-START(103080622915),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310819139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440361283,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 1407811,
      "h": 103080622915,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080622915),
//--TRIMMABLE-BOUNDARY-START(34361146179),
    {
      "p": 1589634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541015363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260492099,
        "f": 83886081
      },
      "n": "Client",
      "d": 1407811,
      "h": 34361146179,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        },
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361146179)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141735328579),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1407811,
      "h": 141735328579,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141735328579),
//--TRIMMABLE-BOUNDARY-START(81605786435),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1407811,
      "h": 81605786435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605786435),
//--TRIMMABLE-BOUNDARY-START(90195721027),
    {
      "r": 65537,
      "n": "LogOut",
      "d": 1407811,
      "h": 90195721027,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90195721027),
//--TRIMMABLE-BOUNDARY-START(85900753731),
    {
      "r": 181338113,
      "n": "LogIn",
      "d": 1407811,
      "h": 85900753731,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900753731),
//--TRIMMABLE-BOUNDARY-START(30066178883),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1407811,
      "h": 30066178883,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30066178883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476244291),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1407811,
      "h": 21476244291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476244291)
  ],
  "h": 1407811
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.Profile`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}Profile`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1407811)
        
        

        //--TRIMMABLE-BOUNDARY-START(1866563)
        $asm.$cls(`$uVBI.LCACV.LoginViewModel`, ($self) => class LoginViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591801155)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591801155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591801155)
            
            //--TRIMMABLE-BOUNDARY-START(25771670339)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(25771670339)
            
            //--TRIMMABLE-BOUNDARY-START(21476703043)
            /*Task<DecodedAuthenticationTicket> *//*async*/  LoginAsync(/*LogInRequestModel*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$GfYa.LCFCA.DecodedAuthenticationTicket, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476703043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Loading = $.$vWqU.LCFCC.LoadState.Loading;
                    let server = null;
                    try
                    {
                        server = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$DZqk.LCACS.IAuthenticationRemoteService, null);
                        try
                        {
                            let $t1, $r1;
                            /*var*/ let loggedIn = ($t1 = server.LCFCS$3$IServiceProxy$$$Service.LCACS$IAuthenticationRemoteService$Login(model), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            /*DecodedAuthenticationTicket?*/ let ticket = null;
                            if (loggedIn.Success)
                            {
                                if (loggedIn.Data.Result === 4/*SignInStatus.ChoosePassword*/)
                                {
                                    throw new $.$uVBI.LCACV.ChoosePasswordException().$ctor$5();
                                }
                                ticket = loggedIn.Data.Ticket;
                            }
                            else 
                            {
                                throw new $.$$.S.Exception().$ctor$4(loggedIn.Message ?? "Login Error");
                            }
                            this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ticket);
                        }
                        catch(e)
                        {
                            this.LoadErrorMessage = e.Message;
                            this.Loading = $.$vWqU.LCFCC.LoadState.LoadError;
                            throw e;
                        }
                    }
                    finally
                    {
                        server?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476703043)
            
            static $h = 1866563;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771670339),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181735747,
        "f": 50331649
      },
      "n": "Server",
      "d": 1866563,
      "h": 25771670339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771670339)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476703043),
    {
      "r": $.$$.STT.Task$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "model",
          "p": 3130365
        }
      ],
      "n": "LoginAsync",
      "d": 1866563,
      "h": 21476703043,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(21476703043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591801155),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1866563,
      "h": 8591801155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591801155)
  ],
  "h": 1866563
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ViewModels.LoginViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ViewModels${separator}LoginViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1866563)
        
        

        //--TRIMMABLE-BOUNDARY-START(686915)
        $asm.$cls(`$uVBI.LCACP.RegisterEmail`, ($self) => class RegisterEmail extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(17180556099)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180556099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 2);
                __builder.AddComponentParameter(3, "Class", "mg-a mawx-5");
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~16/*CardFeatures.Pad*/ | 8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", $.$strNN($.$strNN((this.BgColor === null ? "bg-primary" : "")) + " pd") + " flex");
                    __builder2.AddAttribute$5(8, "style", this.BgColor !== null || this.FgColor !== null ? $.$strNN($.$strNN("background-color:" + $.$strNN(this.BgColor)) + ";color:") + $.$strNN(this.FgColor) : "");
                    if (this.Icon.IsImage)
                    {
                        __builder2.OpenElement(9, "img");
                        __builder2.AddAttribute$5(10, "src", this.ResolvePath(this.Icon.Icon, true, false, false));
                        __builder2.AddAttribute$5(11, "class", "mawx-04 mahx-04 mgy-a");
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.OpenElement(12, "i");
                        __builder2.AddAttribute$5(13, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN((this.Icon).ToString()) + " d-block") + " fsz-30") + " hx-04") + " wx-04") + " corner-2") + " flex") + " mgy-a") + " mgc-a");
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(14, "h2");
                    __builder2.AddAttribute$5(15, "class", "mgy-a mgl");
                    __builder2.AddContent$4(16, this.AppName);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(17, "\r\n        ");
                    __builder2.OpenElement(18, "div");
                    __builder2.AddAttribute$5(19, "class", "pd");
                    __builder2.OpenElement(20, "h1");
                    __builder2.AddAttribute$5(21, "class", "op-8");
                    __builder2.AddContent$4(22, "Hello ");
                    __builder2.AddContent$4(23, this.Name);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n            ");
                    __builder2.OpenElement(25, "p");
                    __builder2.AddContent$4(26, "We received your request to create a user account on ");
                    __builder2.OpenElement(27, "b");
                    __builder2.AddContent$4(28, this.AppName);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.Token !== null)
                    {
                        __builder2.AddMarkupContent(29, "<p>Your registration token is</p>\r\n                ");
                        __builder2.OpenElement(30, "h1");
                        __builder2.AddAttribute$5(31, "class", this.BgColor === null ? "cl-primary" : "");
                        __builder2.AddAttribute$5(32, "style", this.BgColor !== null ? "color:" + $.$strNN(this.BgColor) : "");
                        __builder2.AddContent$4(33, this.Token);
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.AddMarkupContent(34, "<p>\r\n                    If you did not make the request, please ignore this email,\r\n                    otherwise click the button beow to continue your registration.\r\n                </p>\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 35);
                        __builder2.AddComponentParameter(36, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(37, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(38, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Link));
                        __builder2.AddComponentParameter(39, "Class", "pd-4 d-block text-center");
                        __builder2.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(41, "\r\n                    Register\r\n                ");
                        }), $Xapong ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":686915,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.CloseElement();
                }), $WarUrc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":686915,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180556099)
            
            //--TRIMMABLE-BOUNDARY-START(8590621507)
            /*string? */ get AppName()
            {
                return this.GetQuery("appName", false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590621507)
            
            //--TRIMMABLE-BOUNDARY-START(94489967427)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015130947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return _ = ((__ca1__ = this.GetQuery("email", false)) !== null ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$10.call($.$$.System.Array.$ReadT1.call($.$$.S.String.Split$10.call(__ca1__, "@", 0), 0), ".", 0), 0) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(94489967427)
            
            //--TRIMMABLE-BOUNDARY-START(90195000131)
            /*string? */ get Link()
            {
                return this.GetQuery("link", false);
            }
            //--TRIMMABLE-BOUNDARY-END(90195000131)
            
            //--TRIMMABLE-BOUNDARY-START(98784934723)
            /*string? */ get Token()
            {
                return this.GetQuery("token", false);
            }
            //--TRIMMABLE-BOUNDARY-END(98784934723)
            
            //--TRIMMABLE-BOUNDARY-START(12885588803)
            /*string? */ get BgColor()
            {
                return this.GetQuery("bgcolor", false);
            }
            //--TRIMMABLE-BOUNDARY-END(12885588803)
            
            //--TRIMMABLE-BOUNDARY-START(21475523395)
            /*string? */ get FgColor()
            {
                return this.GetQuery("fgcolor", false);
            }
            //--TRIMMABLE-BOUNDARY-END(21475523395)
            
            //--TRIMMABLE-BOUNDARY-START(85900032835)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.GetQuery("icon", false));
            }
            //--TRIMMABLE-BOUNDARY-END(85900032835)
            
            //--TRIMMABLE-BOUNDARY-START(4295654211)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295654211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295654211)
            
            //--TRIMMABLE-BOUNDARY-START(4295654211)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295654211)
            
            static $h = 686915;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590621507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065457987,
        "f": 50331650
      },
      "n": "AppName",
      "d": 686915,
      "h": 8590621507,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590621507),
//--TRIMMABLE-BOUNDARY-START(94489967427),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015130947,
        "f": 50331650
      },
      "n": "Name",
      "d": 686915,
      "h": 94489967427,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94489967427),
//--TRIMMABLE-BOUNDARY-START(90195000131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425196355,
        "f": 50331650
      },
      "n": "Link",
      "d": 686915,
      "h": 90195000131,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90195000131),
//--TRIMMABLE-BOUNDARY-START(98784934723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605065539,
        "f": 50331650
      },
      "n": "Token",
      "d": 686915,
      "h": 98784934723,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784934723),
//--TRIMMABLE-BOUNDARY-START(12885588803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655392579,
        "f": 50331650
      },
      "n": "BgColor",
      "d": 686915,
      "h": 12885588803,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885588803),
//--TRIMMABLE-BOUNDARY-START(21475523395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245327171,
        "f": 50331650
      },
      "n": "FgColor",
      "d": 686915,
      "h": 21475523395,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475523395),
//--TRIMMABLE-BOUNDARY-START(85900032835),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835261763,
        "f": 50331650
      },
      "n": "Icon",
      "d": 686915,
      "h": 85900032835,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85900032835)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180556099),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 686915,
      "h": 17180556099,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180556099)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295654211),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 686915,
      "h": 4295654211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295654211)
  ],
  "h": 686915,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Authentication/Template/RegisterEmail",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Pages.RegisterEmail`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Pages${separator}RegisterEmail`; }
        });
        //--TRIMMABLE-BOUNDARY-END(686915)
        
        

        //--TRIMMABLE-BOUNDARY-START(752451)
        $asm.$cls(`$uVBI.LCACP.ResetPassword`, ($self) => class ResetPassword extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(17180621635)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180621635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 2);
                __builder.AddComponentParameter(3, "Class", "mg-a mawx-5");
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~16/*CardFeatures.Pad*/ | 8/*CardFeatures.Border*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", $.$strNN($.$strNN((this.BgColor === null ? "bg-primary" : "")) + " pd") + " flex");
                    __builder2.AddAttribute$5(8, "style", $.$strNN($.$strNN("background-color:" + $.$strNN(this.BgColor)) + ";color:") + $.$strNN(this.FgColor));
                    if (this.Icon.IsImage)
                    {
                        __builder2.OpenElement(9, "img");
                        __builder2.AddAttribute$5(10, "src", this.ResolvePath(this.Icon.Icon, true, false, false));
                        __builder2.AddAttribute$5(11, "class", "mawx-04 mahx-04 mg-a");
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.OpenElement(12, "i");
                        __builder2.AddAttribute$5(13, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN((this.Icon).ToString()) + " d-block") + " fsz-30") + " hx-04") + " wx-04") + " corner-2") + " flex") + " mgc-a");
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(14, "h2");
                    __builder2.AddAttribute$5(15, "class", "mgy-a mgl");
                    __builder2.AddContent$4(16, this.AppName);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(17, "\r\n        ");
                    __builder2.OpenElement(18, "div");
                    __builder2.AddAttribute$5(19, "class", "pd");
                    __builder2.OpenElement(20, "h1");
                    __builder2.AddAttribute$5(21, "class", "op-8");
                    __builder2.AddContent$4(22, "Hello ");
                    __builder2.AddContent$4(23, this.Name);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n            ");
                    __builder2.OpenElement(25, "p");
                    __builder2.AddContent$4(26, "We received your request to change your password on ");
                    __builder2.OpenElement(27, "b");
                    __builder2.AddContent$4(28, this.AppName);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.Token !== null)
                    {
                        __builder2.AddMarkupContent(29, "<p>Your password reset token is</p>\r\n                ");
                        __builder2.OpenElement(30, "h1");
                        __builder2.AddAttribute$5(31, "class", this.BgColor === null ? "cl-primary" : "");
                        __builder2.AddAttribute$5(32, "style", this.BgColor !== null ? "color:" + $.$strNN(this.BgColor) : "");
                        __builder2.AddContent$4(33, this.Token);
                        __builder2.CloseElement();
                    }
                    else 
                    {
                        __builder2.AddMarkupContent(34, "<p>If you did not make the request, please ignore this email, otherwise click the button below to continue.</p>\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 35);
                        __builder2.AddComponentParameter(36, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(37, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(38, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Link));
                        __builder2.AddComponentParameter(39, "Class", "pd-4 d-block text-center");
                        __builder2.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(41, "\r\n                    Change Password\r\n                ");
                        }), $PAmtBh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":752451,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.CloseElement();
                }), $Riozbf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":752451,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180621635)
            
            //--TRIMMABLE-BOUNDARY-START(8590687043)
            /*string? */ get AppName()
            {
                return this.GetQuery("appName", false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590687043)
            
            //--TRIMMABLE-BOUNDARY-START(94490032963)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015196483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*string?*/ let __ca2__;
                /*string[]*/ let __ca3__;
                return _ = ((__ca1__ = this.GetQuery("email", false)) !== null ? ((__ca2__ = $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, $.$$.S.String.Split$10.call(__ca1__, "@", 0))) !== null ? ((__ca3__ = $.$$.S.String.Split$10.call(__ca2__, ".", 0)) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, __ca3__) : null) : null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(94490032963)
            
            //--TRIMMABLE-BOUNDARY-START(90195065667)
            /*string? */ get Link()
            {
                return this.GetQuery("link", false);
            }
            //--TRIMMABLE-BOUNDARY-END(90195065667)
            
            //--TRIMMABLE-BOUNDARY-START(98785000259)
            /*string? */ get Token()
            {
                return this.GetQuery("token", false);
            }
            //--TRIMMABLE-BOUNDARY-END(98785000259)
            
            //--TRIMMABLE-BOUNDARY-START(12885654339)
            /*string? */ get BgColor()
            {
                return this.GetQuery("bgcolor", false);
            }
            //--TRIMMABLE-BOUNDARY-END(12885654339)
            
            //--TRIMMABLE-BOUNDARY-START(21475588931)
            /*string? */ get FgColor()
            {
                return this.GetQuery("fgcolor", false);
            }
            //--TRIMMABLE-BOUNDARY-END(21475588931)
            
            //--TRIMMABLE-BOUNDARY-START(85900098371)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.GetQuery("icon", false));
            }
            //--TRIMMABLE-BOUNDARY-END(85900098371)
            
            //--TRIMMABLE-BOUNDARY-START(4295719747)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295719747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295719747)
            
            //--TRIMMABLE-BOUNDARY-START(4295719747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295719747)
            
            static $h = 752451;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590687043),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065523523,
        "f": 50331650
      },
      "n": "AppName",
      "d": 752451,
      "h": 8590687043,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590687043),
//--TRIMMABLE-BOUNDARY-START(94490032963),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015196483,
        "f": 50331650
      },
      "n": "Name",
      "d": 752451,
      "h": 94490032963,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94490032963),
//--TRIMMABLE-BOUNDARY-START(90195065667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425261891,
        "f": 50331650
      },
      "n": "Link",
      "d": 752451,
      "h": 90195065667,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90195065667),
//--TRIMMABLE-BOUNDARY-START(98785000259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605131075,
        "f": 50331650
      },
      "n": "Token",
      "d": 752451,
      "h": 98785000259,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98785000259),
//--TRIMMABLE-BOUNDARY-START(12885654339),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655458115,
        "f": 50331650
      },
      "n": "BgColor",
      "d": 752451,
      "h": 12885654339,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885654339),
//--TRIMMABLE-BOUNDARY-START(21475588931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245392707,
        "f": 50331650
      },
      "n": "FgColor",
      "d": 752451,
      "h": 21475588931,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475588931),
//--TRIMMABLE-BOUNDARY-START(85900098371),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835327299,
        "f": 50331650
      },
      "n": "Icon",
      "d": 752451,
      "h": 85900098371,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85900098371)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180621635),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 752451,
      "h": 17180621635,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180621635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295719747),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 752451,
      "h": 4295719747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295719747)
  ],
  "h": 752451,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Authentication/Template/ResetPassword",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Pages.ResetPassword`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Pages${separator}ResetPassword`; }
        });
        //--TRIMMABLE-BOUNDARY-END(752451)
        
        

        //--TRIMMABLE-BOUNDARY-START(1342275)
        $asm.$cls(`$uVBI.LCACS$1.Login`, ($self) => class Login extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(231929576259)
            /*string */ get OptimizedComponentName()
            {
                return "login";
            }
            //--TRIMMABLE-BOUNDARY-END(231929576259)
            
            //--TRIMMABLE-BOUNDARY-START(326418856771)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418856771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Root":
                    this.Root = $.$cast(parameter.Value, $.$uVBI.LCACS$1.Root);
                    return true;
                    case "AllowDemoLogin":
                    this.AllowDemoLogin = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "AllowAnonymousLogin":
                    this.AllowAnonymousLogin = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(326418856771)
            
            //--TRIMMABLE-BOUNDARY-START(193274870595)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274870595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ViewModel = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uVBI.LCACV.LoginViewModel, serviceProvider);
                this.AuthenticationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.Configuration = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, serviceProvider);
                this.Context = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, serviceProvider);
                this.OAuths = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$uVBI.LCACS.IOAuth2AuthenticationService), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(193274870595)
            
            //--TRIMMABLE-BOUNDARY-START(47245982531)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245982531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Model = new $.$DZqk.LCACM.LogInRequestModel().$ctor$2();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245982531)
            
            //--TRIMMABLE-BOUNDARY-START(236224543555)
            /*Root?*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(236224543555)
            
            //--TRIMMABLE-BOUNDARY-START(55835917123)
            /*bool*/ AllowDemoLogin = false;
            //--TRIMMABLE-BOUNDARY-END(55835917123)
            
            //--TRIMMABLE-BOUNDARY-START(51540949827)
            /*bool*/ AllowAnonymousLogin = false;
            //--TRIMMABLE-BOUNDARY-END(51540949827)
            
            //--TRIMMABLE-BOUNDARY-START(335008791363)
            /*LoginViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(335008791363)
            
            //--TRIMMABLE-BOUNDARY-START(60130884419)
            /*IAuthenticationService*/ AuthenticationManager = null;
            //--TRIMMABLE-BOUNDARY-END(60130884419)
            
            //--TRIMMABLE-BOUNDARY-START(77310753603)
            /*IConfigurationParser*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(77310753603)
            
            //--TRIMMABLE-BOUNDARY-START(81605720899)
            /*IApplicationContextProvider*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(81605720899)
            
            //--TRIMMABLE-BOUNDARY-START(214749707075)
            /*IEnumerable<IOAuth2AuthenticationService>*/ OAuths = null;
            //--TRIMMABLE-BOUNDARY-END(214749707075)
            
            //--TRIMMABLE-BOUNDARY-START(210454739779)
            /*LogInRequestModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(210454739779)
            
            //--TRIMMABLE-BOUNDARY-START(188979903299)
            /*IHostView?*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(188979903299)
            
            //--TRIMMABLE-BOUNDARY-START(206159772483)
            /*void *//*async*/  LoginDemo()
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159772483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let model = (() =>
                    {
                        //new $.$DZqk.LCACM.LogInRequestModel()
                        const $t2 = $.$DZqk.LCACM.LogInRequestModel;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.UserName = this.Configuration.LCFCC$1$IConfigurationParser$GetValue($.$$.S.String, $.$strNN($.$strNN($.$DZqk.LCACS$1.AuthenticationGlobalSettings.$type.FullName) + "/") + $.$strNN("DemoUserName"), null);
                        $i2.Password = this.Configuration.LCFCC$1$IConfigurationParser$GetValue($.$$.S.String, $.$strNN($.$strNN($.$DZqk.LCACS$1.AuthenticationGlobalSettings.$type.FullName) + "/") + $.$strNN("DemoPassword"), null);
                        return $i2;
                    })();
                    ($t3 = this.OKLogin(model), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206159772483)
            
            //--TRIMMABLE-BOUNDARY-START(197569837891)
            /*void *//*async*/  LoginAnonymous()
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569837891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let model = (() =>
                    {
                        //new $.$DZqk.LCACM.LogInRequestModel()
                        const $t4 = $.$DZqk.LCACM.LogInRequestModel;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.UserName = this.Configuration.LCFCC$1$IConfigurationParser$GetValue($.$$.S.String, $.$strNN($.$strNN($.$DZqk.LCACS$1.AuthenticationGlobalSettings.$type.FullName) + "/") + $.$strNN("AnonymousUserName"), null);
                        $i4.Password = this.Configuration.LCFCC$1$IConfigurationParser$GetValue($.$$.S.String, $.$strNN($.$strNN($.$DZqk.LCACS$1.AuthenticationGlobalSettings.$type.FullName) + "/") + $.$strNN("AnonymousPassword"), null);
                        return $i4;
                    })();
                    ($t5 = this.OKLogin(model), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197569837891)
            
            //--TRIMMABLE-BOUNDARY-START(90195655491)
            /*ValueTask *//*async*/  Forgot()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195655491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = ((this.Root?.Tabs?.SetCurrentView$1(2) ?? null) ?? (this.Root?.LoginView?.SetCurrentView$1(1) ?? null) ?? $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195655491)
            
            //--TRIMMABLE-BOUNDARY-START(227634608963)
            /*ValueTask *//*async*/  OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227634608963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = this.AuthenticationManager.LCFCA$IAuthenticationService$SetTicket(ticket), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    if (this.Host !== null)
                    {
                        let $t8, $r8;
                        ($t8 = this.Host.LCFCC$IHostView$Complete(true, ticket), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                    if (this.Root !== null)
                    {
                        let $t9, $r9;
                        ($t9 = this.Root.LoggedIn(ticket), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        this.Root.SetAlert($.$fPer.LCFC.Theme.Success, "Log In Successful");
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(227634608963)
            
            //--TRIMMABLE-BOUNDARY-START(85900688195)
            /*ValueTask *//*async*/  ExecuteLogIn(/*LogInRequestModel*/ model)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900688195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t11, $r11;
                        let $t12, $r12;
                        if ((this.Root?.ValidateLogin ?? null) !== null)
                        {
                            let $t10, $r10;
                            ($t10 = this.Root.ValidateLogin.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        }
                        model.Metadata = (this.Root?.Metadata?.MergeWith(model.Metadata) ?? null) ?? model.Metadata;
                        /*var*/ let loggedIn = ($t11 = this.ViewModel.LoginAsync(model), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        ($t12 = this.OnLoggedIn(loggedIn), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$uVBI.LCACV.ChoosePasswordException)
                        {
                            this.Root?.SetAlert($.$fPer.LCFC.Theme.Error, "Please set a new password on your account!");
                            throw $e;
                        }
                        else if ($e instanceof $.$$.S.Exception)
                        {
                            let e = $e;
                            this.Root?.SetAlert($.$fPer.LCFC.Theme.Error, e.Message);
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900688195)
            
            //--TRIMMABLE-BOUNDARY-START(330713824067)
            /*string?*/ userName = null;
            //--TRIMMABLE-BOUNDARY-END(330713824067)
            
            //--TRIMMABLE-BOUNDARY-START(73015786307)
            /*bool*/ choosePassword = false;
            //--TRIMMABLE-BOUNDARY-END(73015786307)
            
            //--TRIMMABLE-BOUNDARY-START(68720819011)
            /*Task *//*async*/  ChooseNewPassword(/*ChooseNewPasswordRequestModel*/ newPass)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720819011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (newPass.NewPassword !== newPass.ConfirmNewPassword)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Password mismatch");
                    }
                    newPass.UserName = this.userName;
                    ($t13 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$DZqk.LCACS.IAuthenticationRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$DZqk.LCACS.IAuthenticationRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCACS$IAuthenticationRemoteService$ChoosePassword(newPass);
                    }, $NaJTBi ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":7259133}],"n":"","d":1342275,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    this.Root?.SetAlert($.$fPer.LCFC.Theme.Success, "Password changed! Please login");
                    this.Model = new $.$DZqk.LCACM.LogInRequestModel().$ctor$2();
                    this.choosePassword = false;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720819011)
            
            //--TRIMMABLE-BOUNDARY-START(219044674371)
            /*ValueTask */ OKLogin(/*LogInRequestModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044674371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                model.Metadata = (this.Root?.BuildMetadata(model.Metadata) ?? null) ?? model.Metadata;
                /*ValueTask*/ /*async*/  function BeginLogin(/*LogInRequestModel*/ model)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        try
                        {
                            let $t14, $r14;
                            this.choosePassword = false;
                            ($t14 = this.ExecuteLogIn(model), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        }
                        catch($e)
                        {
                            this.userName = model.UserName;
                            this.choosePassword = true;
                            this.StateHasChanged();
                        }
                    });
                }
                return (this.Root?.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this,  () =>
                {
                    return BeginLogin.call(this, model);
                }, $cXAmee ??= {"r":181338113,"n":"","d":1342275,"h":0,"f":17825794})) ?? null) ?? BeginLogin.call(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(219044674371)
            
            //--TRIMMABLE-BOUNDARY-START(223339641667)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t17, $r17;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(223339641667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        if (this.AllowAnonymousLogin)
                        {
                            _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "No Account, No Problem", false), new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                            {
                                return this.LoginAnonyousView();
                            }, $lvsIJi ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1342275,"h":0,"f":17825794}), null, (() =>
                            {
                                //new $.$hDPm.LCFCI.ViewConfiguration()
                                const $t15 = $.$hDPm.LCFCI.ViewConfiguration;
                                const $i15 = new $t15();
                                $i15.$ctor$2();
                                $i15.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                                $i15.BodyAttributes = (() =>
                                {
                                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)()
                                    const $t16 = $.$$.SCG.Dictionary$$$($.$fPer.LCFC.Stringy, $.$$.S.Object);
                                    const $i16 = new $t16();
                                    $i16.$ctor$1();
                                    $i16.set_Item($.$fPer.LCFC.Stringy.op_Implicit$3("class"), "pd-5 corner");
                                    return $i16;
                                })();
                                return $i15;
                            })());
                        }
                    }
                    ($t17 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(223339641667)
            
            //--TRIMMABLE-BOUNDARY-START(64425851715)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425851715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Any($.$uVBI.LCACS.IOAuth2AuthenticationService, this.OAuths, new ($.$$.S.Func$$$($.$uVBI.LCACS.IOAuth2AuthenticationService, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.LCACS$IOAuth2AuthenticationService$IsConfigured;
                }, $bFBZCk ??= {"r":262145,"p":[{"n":"o","p":1014595}],"n":"","d":1342275,"h":0,"f":17825794})))
                {
                    let $en18 = $.$sl.SL.Enumerable.Where($.$uVBI.LCACS.IOAuth2AuthenticationService, this.OAuths, new ($.$$.S.Func$$$($.$uVBI.LCACS.IOAuth2AuthenticationService, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                    {
                        return o.LCACS$IOAuth2AuthenticationService$IsConfigured;
                    }, $HCsHEd ??= {"r":262145,"p":[{"n":"o","p":1014595}],"n":"","d":1342275,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let oauth = $en18.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(0, "div");
                            __builder.AddAttribute$5(1, "class", "mgy-10");
                            __builder.AddContent$1(2, oauth.LCACS$IOAuth2AuthenticationService$GetView(new ($.$$.S.Func$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$$.STT.ValueTask))().$ctor(this, this.OnLoggedIn), (this.Root?.Metadata ?? null)));
                            __builder.CloseElement();
                        }
                    }
                    __builder.AddMarkupContent(3, "<div class=\"flex mgy-10\"><div class=\"fill mgy-a bdt\"></div>\r\n        <h3 class=\"text-center mgy-0 mgx\">OR</h3>\r\n        <div class=\"fill mgy-a bdt\"></div></div>");
                }
                if (this.choosePassword)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$DZqk.LCACM.ChooseNewPasswordRequestModel), 4);
                    __builder.AddComponentParameter(5, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$DZqk.LCACM.ChooseNewPasswordRequestModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$DZqk.LCACM.ChooseNewPasswordRequestModel, this, new ($.$$.S.Func$$$($.$DZqk.LCACM.ChooseNewPasswordRequestModel, $.$$.STT.Task))().$ctor(this, this.ChooseNewPassword))));
                    __builder.AddAttribute$3(6, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 7);
                        __builder2.AddComponentParameter(8, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(9, "Class", "mgt-5 d-block wp-100");
                        __builder2.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 8192/*ButtonFeatures.LoadingOnClick*/ | 16384/*ButtonFeatures.DisableOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(11, "type", "submit");
                        __builder2.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(13, "\r\n                Set Password\r\n            ");
                        }), $yUbOBi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }), $KsqBwi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$DZqk.LCACM.LogInRequestModel), 14);
                    __builder.AddComponentParameter(15, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$DZqk.LCACM.LogInRequestModel, this.Model));
                    __builder.AddComponentParameter(16, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, (this.Root?.FormTheme ?? null) ?? this.Theme));
                    __builder.AddComponentParameter(17, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$DZqk.LCACM.LogInRequestModel), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$DZqk.LCACM.LogInRequestModel, $.$mac.MAC.EventCallback.Factory, this, $.$hDPm.LCFCC$1.BaseComponent.NoStateChanged$5($.$DZqk.LCACM.LogInRequestModel, new ($.$$.S.Func$$$($.$DZqk.LCACM.LogInRequestModel, $.$$.STT.ValueTask))().$ctor(this, this.OKLogin)))));
                    __builder.AddComponentParameter(18, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder.AddComponentParameter(19, "FieldFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$2.InputFieldFeatures, (this.Root?.FieldFeatures ?? null) ?? 4/*InputFieldFeatures.Default*/), $.$hDPm.LCFCCI$2.InputFieldFeatures));
                    __builder.AddComponentParameter(20, "EditorFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, (this.Root?.EditorFeatures ?? null) ?? 4131/*InputEditorFeatures.Default*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                    __builder.AddComponentParameter(21, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder.AddAttribute$3(22, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(23, (this.Root?.LoginChildContent ?? null));
                    }), $xhkUWc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(24, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(25, "div");
                        __builder2.AddAttribute$5(26, "class", "text-right mgt");
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 27, "onclick", true);
                        __builder2.OpenElement(28, "a");
                        __builder2.AddAttribute$5(29, "href", "javascript: void(0);");
                        __builder2.AddAttribute$5(30, "class", "cl-text");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 31, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, $.$hDPm.LCFCC$1.ComponentExtension.NoStateChanged$2((new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Forgot)))));
                        __builder2.AddContent$4(32, "Forgotten Password?");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(33, "\r\n            ");
                        __builder2.OpenElement(34, "div");
                        __builder2.AddAttribute$5(35, "class", "row mgt-5 ");
                        if (this.AllowDemoLogin)
                        {
                            __builder2.OpenElement(36, "div");
                            __builder2.AddAttribute$5(37, "class", "col-4 mgr");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 38);
                            __builder2.AddComponentParameter(39, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Message));
                            __builder2.AddComponentParameter(40, "Class", "d-block wf");
                            __builder2.AddComponentParameter(41, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 8192/*ButtonFeatures.LoadingOnClick*/ | 16384/*ButtonFeatures.DisableOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(42, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, $.$hDPm.LCFCC$1.BaseComponent.NoStateChanged(new $.$$.S.Action().$ctor(this, this.LoginDemo)))));
                            __builder2.AddAttribute$3(43, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(44, "\r\n                            Demo\r\n                        ");
                            }), $voPoSb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(45, "div");
                        __builder2.AddAttribute$5(46, "class", "col-6");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 47);
                        __builder2.AddComponentParameter(48, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(49, "Class", "d-block wf");
                        __builder2.AddComponentParameter(50, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 8192/*ButtonFeatures.LoadingOnClick*/ | 16384/*ButtonFeatures.DisableOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(51, "type", "submit");
                        __builder2.AddAttribute$3(52, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(53, "\r\n                        Login\r\n                    ");
                        }), $Hepuih ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }), $qLOeQe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425851715)
            
            //--TRIMMABLE-BOUNDARY-START(201864805187)
            /*RenderFragment */ LoginAnonyousView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864805187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(54, "\r\n        ");
                    __builder2.AddMarkupContent(55, "<p>\r\n            Login anonymously and gain instant access.\r\n            <i class=\"mdi mdi-info\" title=\"Note however that anonymous account has limitations. If you have issues using some of the services, consider creating an account.\"></i></p>\r\n        ");
                    __builder2.OpenElement(56, "div");
                    __builder2.AddAttribute$5(57, "class", "flex");
                    __builder2.OpenElement(58, "button");
                    __builder2.AddAttribute$5(59, "class", "mgx-a bg-error corner-5 sd pdy-2 pdx-4 fsz-14");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 60, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.LoginAnonymous)));
                    __builder2.AddContent$4(61, "Anonymous Login");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(62, "\r\n    ");
                }, $UdKkUc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1342275,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(201864805187)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12888661416)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IPushResultComponent<LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket>.Host.set
            set LCFCC$IPushResultComponent$$$Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12888661416)
            
            //--TRIMMABLE-BOUNDARY-START(47245982531)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(47245982531)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(335008791363)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(335008791363)
                
                //--TRIMMABLE-BOUNDARY-START(60130884419)
                this.AuthenticationManager = null;
                //--TRIMMABLE-BOUNDARY-END(60130884419)
                
                //--TRIMMABLE-BOUNDARY-START(77310753603)
                this.Configuration = null;
                //--TRIMMABLE-BOUNDARY-END(77310753603)
                
                //--TRIMMABLE-BOUNDARY-START(81605720899)
                this.Context = null;
                //--TRIMMABLE-BOUNDARY-END(81605720899)
                
                //--TRIMMABLE-BOUNDARY-START(214749707075)
                this.OAuths = null;
                //--TRIMMABLE-BOUNDARY-END(214749707075)
                
            }
            static $h = 1342275;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(231929576259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505066819,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1342275,
      "h": 231929576259,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231929576259),
//--TRIMMABLE-BOUNDARY-START(236224543555),
    {
      "p": 1604419,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095001411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533954883,
        "f": 83886081
      },
      "n": "Root",
      "d": 1342275,
      "h": 236224543555,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236224543555),
//--TRIMMABLE-BOUNDARY-START(55835917123),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375524675,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404412739,
        "f": 83886081
      },
      "n": "AllowDemoLogin",
      "d": 1342275,
      "h": 55835917123,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835917123),
//--TRIMMABLE-BOUNDARY-START(51540949827),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785590083,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814478147,
        "f": 83886081
      },
      "n": "AllowAnonymousLogin",
      "d": 1342275,
      "h": 51540949827,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540949827),
//--TRIMMABLE-BOUNDARY-START(335008791363),
    {
      "p": 1866563,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684936003,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123889475,
        "f": 83886081
      },
      "n": "ViewModel",
      "d": 1342275,
      "h": 335008791363,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335008791363),
//--TRIMMABLE-BOUNDARY-START(60130884419),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965459267,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994347331,
        "f": 83886081
      },
      "n": "AuthenticationManager",
      "d": 1342275,
      "h": 60130884419,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130884419),
//--TRIMMABLE-BOUNDARY-START(77310753603),
    {
      "p": 4950358,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555393859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584281923,
        "f": 83886081
      },
      "n": "Configuration",
      "d": 1342275,
      "h": 77310753603,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310753603),
//--TRIMMABLE-BOUNDARY-START(81605720899),
    {
      "p": 46041430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145328451,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279174216515,
        "f": 83886081
      },
      "n": "Context",
      "d": 1342275,
      "h": 81605720899,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605720899),
//--TRIMMABLE-BOUNDARY-START(214749707075),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uVBI.LCACS.IOAuth2AuthenticationService).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915132227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304944020291,
        "f": 83886081
      },
      "n": "OAuths",
      "d": 1342275,
      "h": 214749707075,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749707075),
//--TRIMMABLE-BOUNDARY-START(210454739779),
    {
      "p": 3130365,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325197635,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354085699,
        "f": 83886082
      },
      "n": "Model",
      "d": 1342275,
      "h": 210454739779,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210454739779),
//--TRIMMABLE-BOUNDARY-START(188979903299),
    {
      "p": 3300776,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735263043,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764151107,
        "f": 83886081
      },
      "n": "Host",
      "d": 1342275,
      "h": 188979903299,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979903299)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(326418856771),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1342275,
      "h": 326418856771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(326418856771),
//--TRIMMABLE-BOUNDARY-START(193274870595),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1342275,
      "h": 193274870595,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274870595),
//--TRIMMABLE-BOUNDARY-START(206159772483),
    {
      "r": 65537,
      "n": "LoginDemo",
      "d": 1342275,
      "h": 206159772483,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(206159772483),
//--TRIMMABLE-BOUNDARY-START(197569837891),
    {
      "r": 65537,
      "n": "LoginAnonymous",
      "d": 1342275,
      "h": 197569837891,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(197569837891),
//--TRIMMABLE-BOUNDARY-START(90195655491),
    {
      "r": 181338113,
      "n": "Forgot",
      "d": 1342275,
      "h": 90195655491,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90195655491),
//--TRIMMABLE-BOUNDARY-START(227634608963),
    {
      "r": 181338113,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": 1342275,
      "h": 227634608963,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(227634608963),
//--TRIMMABLE-BOUNDARY-START(85900688195),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 3130365
        }
      ],
      "n": "ExecuteLogIn",
      "d": 1342275,
      "h": 85900688195,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85900688195),
//--TRIMMABLE-BOUNDARY-START(68720819011),
    {
      "r": 178454529,
      "p": [
        {
          "n": "newPass",
          "p": 1950717
        }
      ],
      "n": "ChooseNewPassword",
      "d": 1342275,
      "h": 68720819011,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720819011),
//--TRIMMABLE-BOUNDARY-START(219044674371),
    {
      "r": 181338113,
      "p": [
        {
          "n": "model",
          "p": 3130365
        }
      ],
      "n": "OKLogin",
      "d": 1342275,
      "h": 219044674371,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044674371),
//--TRIMMABLE-BOUNDARY-START(223339641667),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 1342275,
      "h": 223339641667,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(223339641667),
//--TRIMMABLE-BOUNDARY-START(64425851715),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1342275,
      "h": 64425851715,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425851715),
//--TRIMMABLE-BOUNDARY-START(201864805187),
    {
      "r": 6881395,
      "n": "LoginAnonyousView",
      "d": 1342275,
      "h": 201864805187,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(201864805187)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(330713824067),
    {
      "t": 1310721,
      "n": "userName",
      "d": 1342275,
      "h": 330713824067,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(330713824067),
//--TRIMMABLE-BOUNDARY-START(73015786307),
    {
      "t": 262145,
      "n": "choosePassword",
      "d": 1342275,
      "h": 73015786307,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015786307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245982531),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1342275,
      "h": 47245982531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245982531)
  ],
  "h": 1342275
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.IPushResultComponent$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$vWqU.LCFCC.IResultComponent$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.Login`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}Login`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1342275)
        
        

        //--TRIMMABLE-BOUNDARY-START(1604419)
        $asm.$cls(`$uVBI.LCACS$1.Root`, ($self) => class Root extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(536872516419)
            /*string */ get OptimizedComponentName()
            {
                return "root";
            }
            //--TRIMMABLE-BOUNDARY-END(536872516419)
            
            //--TRIMMABLE-BOUNDARY-START(820340357955)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820340357955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "LoginChildContent":
                    this.LoginChildContent = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "RegisterChildContent":
                    this.RegisterChildContent = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$$.S.Int32));
                    return true;
                    case "ValidateLogin":
                    this.ValidateLogin = $.$cast(parameter.Value, $.$$.S.Func$$($.$$.STT.Task));
                    return true;
                    case "ValidateRegisteration":
                    this.ValidateRegisteration = $.$cast(parameter.Value, $.$$.S.Func$$($.$$.STT.Task));
                    return true;
                    case "Navigable":
                    this.Navigable = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "Index":
                    this.Index = $.$cast(parameter.Value, $.$uVBI.LCACP.App);
                    return true;
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "FormTheme":
                    this.FormTheme = $.$cast(parameter.Value, $.$fPer.LCFC.Theme);
                    return true;
                    case "Client":
                    this.Client = $.$cast(parameter.Value, $.$GfYa.LCFCA.IAuthenticationClient);
                    return true;
                    case "Flags":
                    this.Flags = $.$cast(parameter.Value, $.$hDPm.LCFCI.LoginActionFlags);
                    return true;
                    case "ServiceIcon":
                    this.ServiceIcon = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "Uri":
                    this.Uri = $.$cast(parameter.Value, $.$spu.S.Uri);
                    return true;
                    case "FieldFeatures":
                    this.FieldFeatures = $.$cast(parameter.Value, $.$hDPm.LCFCCI$2.InputFieldFeatures);
                    return true;
                    case "EditorFeatures":
                    this.EditorFeatures = $.$cast(parameter.Value, $.$hDPm.LCFCCI$1.InputEditorFeatures);
                    return true;
                    case "OnLogggedin":
                    this.OnLogggedin = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    return true;
                    case "OnRegistered":
                    this.OnRegistered = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    return true;
                    case "OnPasswordReset":
                    this.OnPasswordReset = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(820340357955)
            
            //--TRIMMABLE-BOUNDARY-START(450973170499)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973170499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.NavigationManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.AuthenticationService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(450973170499)
            
            //--TRIMMABLE-BOUNDARY-START(124555656003)
            /*string?*/ alertMessage = null;
            //--TRIMMABLE-BOUNDARY-END(124555656003)
            
            //--TRIMMABLE-BOUNDARY-START(128850623299)
            /*string? */ get AlertMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570100035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.alertMessage;
            }
            /*string? */ set AlertMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575527222083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.alertMessage !== value)
                {
                    this.alertMessage = value;
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Authentication.Client.Blazor\\Root.razor.cs", "AlertMessage", 38);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850623299)
            
            //--TRIMMABLE-BOUNDARY-START(133145590595)
            /*Theme*/ alertTheme;
            //--TRIMMABLE-BOUNDARY-END(133145590595)
            
            //--TRIMMABLE-BOUNDARY-START(137440557891)
            /*Theme */ get AlertTheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160034627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.alertTheme;
            }
            /*Theme */ set AlertTheme(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584117156675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFC.Theme.op_Inequality(this.alertTheme, value))
                {
                    this.alertTheme = $.$clone(value);
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Authentication.Client.Blazor\\Root.razor.cs", "AlertTheme", 52);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440557891)
            
            //--TRIMMABLE-BOUNDARY-START(485332908867)
            /*MultiView?*/ LoginView = null;
            //--TRIMMABLE-BOUNDARY-END(485332908867)
            
            //--TRIMMABLE-BOUNDARY-START(481037941571)
            /*RenderFragment?*/ LoginChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(481037941571)
            
            //--TRIMMABLE-BOUNDARY-START(549757418307)
            /*RenderFragment<int>?*/ RegisterChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(549757418307)
            
            //--TRIMMABLE-BOUNDARY-START(828930292547)
            /*Func<Task>?*/ ValidateLogin = null;
            //--TRIMMABLE-BOUNDARY-END(828930292547)
            
            //--TRIMMABLE-BOUNDARY-START(833225259843)
            /*Func<Task>?*/ ValidateRegisteration = null;
            //--TRIMMABLE-BOUNDARY-END(833225259843)
            
            //--TRIMMABLE-BOUNDARY-START(498217810755)
            /*bool*/ Navigable = false;
            //--TRIMMABLE-BOUNDARY-END(498217810755)
            
            //--TRIMMABLE-BOUNDARY-START(446678203203)
            /*Pages.App?*/ Index = null;
            //--TRIMMABLE-BOUNDARY-END(446678203203)
            
            //--TRIMMABLE-BOUNDARY-START(150325459779)
            /*string*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(150325459779)
            
            //--TRIMMABLE-BOUNDARY-START(188980165443)
            /*Theme*/ FormTheme;
            //--TRIMMABLE-BOUNDARY-END(188980165443)
            
            //--TRIMMABLE-BOUNDARY-START(163210361667)
            /*IAuthenticationClient?*/ client = null;
            //--TRIMMABLE-BOUNDARY-END(163210361667)
            
            //--TRIMMABLE-BOUNDARY-START(167505328963)
            /*IAuthenticationClient? */ get Client()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519772995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.client;
            }
            /*IAuthenticationClient? */ set Client(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618476895043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.client === null)
                {
                    this.client = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505328963)
            
            //--TRIMMABLE-BOUNDARY-START(184685198147)
            /*LoginActionFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(184685198147)
            
            //--TRIMMABLE-BOUNDARY-START(566937287491)
            /*RenderFragment?*/ ServiceIcon = null;
            //--TRIMMABLE-BOUNDARY-END(566937287491)
            
            //--TRIMMABLE-BOUNDARY-START(824635325251)
            /*Uri?*/ Uri = null;
            //--TRIMMABLE-BOUNDARY-END(824635325251)
            
            //--TRIMMABLE-BOUNDARY-START(180390230851)
            /*InputFieldFeatures*/ FieldFeatures = 0;
            //--TRIMMABLE-BOUNDARY-END(180390230851)
            
            //--TRIMMABLE-BOUNDARY-START(176095263555)
            /*InputEditorFeatures*/ EditorFeatures = 0;
            //--TRIMMABLE-BOUNDARY-END(176095263555)
            
            //--TRIMMABLE-BOUNDARY-START(519692647235)
            /*EventCallback<DecodedAuthenticationTicket>*/ OnLogggedin;
            //--TRIMMABLE-BOUNDARY-END(519692647235)
            
            //--TRIMMABLE-BOUNDARY-START(532577549123)
            /*EventCallback<DecodedAuthenticationTicket>*/ OnRegistered;
            //--TRIMMABLE-BOUNDARY-END(532577549123)
            
            //--TRIMMABLE-BOUNDARY-START(528282581827)
            /*EventCallback*/ OnPasswordReset;
            //--TRIMMABLE-BOUNDARY-END(528282581827)
            
            //--TRIMMABLE-BOUNDARY-START(502512778051)
            /*NavigationManager*/ NavigationManager = null;
            //--TRIMMABLE-BOUNDARY-END(502512778051)
            
            //--TRIMMABLE-BOUNDARY-START(146030492483)
            /*IAuthenticationService*/ AuthenticationService = null;
            //--TRIMMABLE-BOUNDARY-END(146030492483)
            
            //--TRIMMABLE-BOUNDARY-START(141735525187)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(141735525187)
            
            //--TRIMMABLE-BOUNDARY-START(489627876163)
            /*AuthenticationMetadata?*/ Metadata = null;
            //--TRIMMABLE-BOUNDARY-END(489627876163)
            
            //--TRIMMABLE-BOUNDARY-START(493922843459)
            /*void */ MetaFromQueryString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922843459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let queryParameter = $.$fPer.LCFCS$6.StringExtension.QueryStringAs($.$GfYa.LCFCA.AuthenticationMetadata, new $.$spu.S.Uri().$ctor$5(this.NavigationManager.Uri).Query);
                this.Metadata = queryParameter;
            }
            //--TRIMMABLE-BOUNDARY-END(493922843459)
            
            //--TRIMMABLE-BOUNDARY-START(472448006979)
            /*void */ LocationChanged(/*object?*/ sender, /*LocationChangedEventArgs*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448006979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.MetaFromQueryString();
            }
            //--TRIMMABLE-BOUNDARY-END(472448006979)
            
            //--TRIMMABLE-BOUNDARY-START(154620427075)
            /*AuthenticationMetadata */ BuildMetadata(/*AuthenticationMetadata?*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620427075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = (this.Client?.LCFCA$IAuthenticationClient$Descriptor ?? null);
                metadata = (this.Metadata?.MergeWith(metadata) ?? null) ?? new $.$GfYa.LCFCA.AuthenticationMetadata().$ctor$1();
                metadata.ClientDescriptor = descriptor;
                metadata.ReturnUrl ??= this.NavigationManager.Uri;
                return metadata;
            }
            //--TRIMMABLE-BOUNDARY-END(154620427075)
            
            //--TRIMMABLE-BOUNDARY-START(515397679939)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397679939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Authentication.Client.Blazor.min.css", true, false, false), this.ResolvePath("LivingThing.Core.Authentication.Client.Blazor.js", true, false, false) ], null, null));
                this.MetaFromQueryString();
                this.NavigationManager.add_LocationChanged(new ($.$$.S.EventHandler$$($.$mac.MACR$3.LocationChangedEventArgs))().$ctor(this, this.LocationChanged));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(515397679939)
            
            //--TRIMMABLE-BOUNDARY-START(171800296259)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800296259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NavigationManager.remove_LocationChanged(new ($.$$.S.EventHandler$$($.$mac.MACR$3.LocationChangedEventArgs))().$ctor(this, this.LocationChanged));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(171800296259)
            
            //--TRIMMABLE-BOUNDARY-START(816045390659)
            /*Tabs?*/ Tabs = null;
            //--TRIMMABLE-BOUNDARY-END(816045390659)
            
            //--TRIMMABLE-BOUNDARY-START(468153039683)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(468153039683)
            
            //--TRIMMABLE-BOUNDARY-START(463858072387)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463858072387)
            
            //--TRIMMABLE-BOUNDARY-START(545462451011)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(545462451011)
            
            //--TRIMMABLE-BOUNDARY-START(545462451011)
            //--TRIMMABLE-BOUNDARY-START(120260688707)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260688707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(120260688707)
            
            //--TRIMMABLE-BOUNDARY-START(562642320195)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562642320195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(562642320195)
            
            //--TRIMMABLE-BOUNDARY-END(545462451011)
            
            //--TRIMMABLE-BOUNDARY-START(811750423363)
            /*void */ SetAlert(/*Theme*/ theme, /*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811750423363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFC.Theme.op_Inequality(theme, this.AlertTheme) || message !== this.AlertMessage)
                {
                    this.AlertTheme = $.$clone(theme);
                    this.AlertMessage = message;
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Authentication.Client.Blazor\\Root.razor.cs", "SetAlert", 140);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(811750423363)
            
            //--TRIMMABLE-BOUNDARY-START(511102712643)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(511102712643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        if (this.Client !== null)
                        {
                            let $t2, $r2;
                            /*var*/ let ticket = ($t2 = this.AuthenticationService.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if (ticket.IsValid())
                            {
                                let $t3, $r3;
                                ($t3 = this.Client.LCFCA$IAuthenticationClient$OnLoggedIn(ticket), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            }
                        }
                    }
                    ($t4 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(511102712643)
            
            //--TRIMMABLE-BOUNDARY-START(523987614531)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523987614531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnParametersSet();
            }
            //--TRIMMABLE-BOUNDARY-END(523987614531)
            
            //--TRIMMABLE-BOUNDARY-START(506807745347)
            /*Task *//*async*/  NotifyLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(506807745347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let handled = false;
                    if (this.Client !== null)
                    {
                        let $t5, $r5;
                        ticket.IsFresh = true;
                        handled = ($t5 = this.Client.LCFCA$IAuthenticationClient$OnLoggedIn(ticket), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    if (!handled)
                    {
                        this.NavigationManager.NavigateTo$2((this.Metadata?.ReturnUrl ?? null) ?? this.NavigationManager.Uri, true);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(506807745347)
            
            //--TRIMMABLE-BOUNDARY-START(476742974275)
            /*Task *//*async*/  LoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(476742974275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Host?.LCFCC$IHostView$Complete(true, ticket);
                    ($t6 = this.OnLogggedin.InvokeAsync$1(ticket), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = this.NotifyLoggedIn(ticket), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(476742974275)
            
            //--TRIMMABLE-BOUNDARY-START(554052385603)
            /*Task *//*async*/  Registered(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(554052385603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Host?.LCFCC$IHostView$Complete(true, ticket);
                    ($t8 = this.OnRegistered.InvokeAsync$1(ticket), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    ($t9 = this.NotifyLoggedIn(ticket), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(554052385603)
            
            //--TRIMMABLE-BOUNDARY-START(541167483715)
            /*Task */ PasswordReset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167483715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnPasswordReset.InvokeAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(541167483715)
            
            //--TRIMMABLE-BOUNDARY-START(442383235907)
            /*IHostView?*/ Host = null;
            //--TRIMMABLE-BOUNDARY-END(442383235907)
            
            //--TRIMMABLE-BOUNDARY-START(455268137795)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455268137795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(455268137795)
            
            //--TRIMMABLE-BOUNDARY-START(459563105091)
            /*ValueTask */ Load$1(/*Func<ValueTask>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563105091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, action, true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                }, $KoBqhb ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1604419,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(459563105091)
            
            //--TRIMMABLE-BOUNDARY-START(158915394371)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915394371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build$1(this.OwnAttributes(null))));
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 2);
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (((this.Flags & (1/*LoginActionFlags.Login*/)) == (1/*LoginActionFlags.Login*/)) && ((this.Flags & (2/*LoginActionFlags.Register*/)) == (2/*LoginActionFlags.Register*/)))
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 6);
                        __builder2.AddComponentParameter(7, "TabLocation", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarSide, 3/*SideBarSide.Top*/), $.$hDPm.LCFCCS$7.SideBarSide));
                        __builder2.AddComponentParameter(8, "Navigable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.Navigable), $.$$.S.Boolean));
                        __builder2.AddComponentParameter(9, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.Navigable ? this.BasePath : null)));
                        __builder2.AddComponentParameter(10, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                        __builder2.AddComponentParameter(11, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 2097152/*MenuFeatures.Pad*/ | 8/*MenuFeatures.Selectable*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.AddComponentParameter(12, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 2/*TabsFeatures.TabsBorder*/ | 4/*TabsFeatures.TabsSelectedBorder*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                        __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            if (((this.Flags & (1/*LoginActionFlags.Login*/)) == (1/*LoginActionFlags.Login*/)))
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 14);
                                __builder3.AddComponentParameter(15, "Class", "pdx pdb pdt");
                                __builder3.AddComponentParameter(16, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Login"/*AuthenticationExtension.LoginPath*/));
                                __builder3.AddComponentParameter(17, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.Navigable ? `${$.$strNN("Login"/*AuthenticationExtension.LoginPath*/)}|${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}` : null)));
                                __builder3.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(19, "<h3 class=\"mg-0\">Login</h3>");
                                    }, $qaGYuc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $VNIuki ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        if (this.ServiceIcon !== null)
                                        {
                                            __builder4.OpenElement(21, "div");
                                            __builder4.AddAttribute$5(22, "class", "pd-5 flex flex-center-x");
                                            __builder4.AddContent$1(23, this.ServiceIcon);
                                            __builder4.CloseElement();
                                        }
                                        __builder4.OpenComponent$1($.$uVBI.LCACS$1.Login, 24);
                                        __builder4.AddComponentParameter(25, "AllowDemoLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((this.Flags & (8/*LoginActionFlags.AllowDemoLogin*/)) == (8/*LoginActionFlags.AllowDemoLogin*/))), $.$$.S.Boolean));
                                        __builder4.AddComponentParameter(26, "AllowAnonymousLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((this.Flags & (16/*LoginActionFlags.AllowAnonymousLogin*/)) == (16/*LoginActionFlags.AllowAnonymousLogin*/))), $.$$.S.Boolean));
                                        __builder4.AddComponentParameter(27, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                        __builder4.AddComponentParameter(28, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                                        __builder4.AddComponentParameter(29, "Client", "Client");
                                        __builder4.AddComponentParameter(30, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("login")));
                                        __builder4.CloseComponent();
                                    }, $IKKWQf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $qIyNci ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            if (((this.Flags & (2/*LoginActionFlags.Register*/)) == (2/*LoginActionFlags.Register*/)))
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 31);
                                __builder3.AddComponentParameter(32, "Class", "pdx pdb pdt");
                                __builder3.AddComponentParameter(33, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Register"/*AuthenticationExtension.RegisterPath*/));
                                __builder3.AddComponentParameter(34, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.Navigable ? $.$strNN($.$strNN("Register"/*AuthenticationExtension.RegisterPath*/) + "/") + $.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/) : null)));
                                __builder3.AddAttribute$3(35, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(36, "<h3 class=\"mg-0\">Register</h3>");
                                    }, $PJKXkk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $dEuImh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(37, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        if (this.ServiceIcon !== null)
                                        {
                                            __builder4.OpenElement(38, "div");
                                            __builder4.AddAttribute$5(39, "class", "pd-5 flex flex-center-x");
                                            __builder4.AddContent$1(40, this.ServiceIcon);
                                            __builder4.CloseElement();
                                        }
                                        __builder4.OpenComponent$1($.$uVBI.LCACS$1.Register, 41);
                                        __builder4.AddComponentParameter(42, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                        __builder4.AddComponentParameter(43, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this.Index));
                                        __builder4.AddComponentParameter(44, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                                        __builder4.AddComponentParameter(45, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.Client));
                                        __builder4.AddComponentParameter(46, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("register")));
                                        __builder4.CloseComponent();
                                    }, $cBiArd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $UzDhGi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            if (((this.Flags & (4/*LoginActionFlags.Reset*/)) == (4/*LoginActionFlags.Reset*/)))
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 47);
                                __builder3.AddComponentParameter(48, "Class", "pdx pdb pdt");
                                __builder3.AddComponentParameter(49, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Reset"/*AuthenticationExtension.ResetPasswordPath*/));
                                __builder3.AddComponentParameter(50, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.Navigable ? $.$strNN("Reset"/*AuthenticationExtension.ResetPasswordPath*/) + "/*" : null)));
                                __builder3.AddAttribute$3(51, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(52, "<h3 class=\"mg-0\">Reset</h3>");
                                    }, $jKgfBa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $zOGNqg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(53, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        if (this.ServiceIcon !== null)
                                        {
                                            __builder4.OpenElement(54, "div");
                                            __builder4.AddAttribute$5(55, "class", "pd-5 flex flex-center-x");
                                            __builder4.AddContent$1(56, this.ServiceIcon);
                                            __builder4.CloseElement();
                                        }
                                        __builder4.OpenComponent$1($.$uVBI.LCACS$1.ResetPassword, 57);
                                        __builder4.AddComponentParameter(58, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                        __builder4.AddComponentParameter(59, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this.Index));
                                        __builder4.AddComponentParameter(60, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                                        __builder4.AddComponentParameter(61, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.Client));
                                        __builder4.AddComponentParameter(62, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("reset")));
                                        __builder4.CloseComponent();
                                    }, $yonnRa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                                }), $vfXsoe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }), $BNcjOi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794}));
                        __builder2.AddComponentReferenceCapture(63, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.Tabs = $.$cast(__value, $.$hDPm.LCFCCT$1.Tabs);
                        }, $WePwFg ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1604419,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    else if (((this.Flags & (1/*LoginActionFlags.Login*/)) == (1/*LoginActionFlags.Login*/)))
                    {
                        if (this.ServiceIcon !== null)
                        {
                            __builder2.OpenElement(64, "div");
                            __builder2.AddAttribute$5(65, "class", "pd-5 flex flex-center-x");
                            __builder2.AddContent$1(66, this.ServiceIcon);
                            __builder2.CloseElement();
                        }
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$6.MultiView, 67);
                        __builder2.AddAttribute$3(68, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 69);
                            __builder3.AddComponentParameter(70, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "Login"/*AuthenticationExtension.LoginPath*/));
                            __builder3.AddAttribute$3(71, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$uVBI.LCACS$1.Login, 72);
                                    __builder4.AddComponentParameter(73, "AllowDemoLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((this.Flags & (8/*LoginActionFlags.AllowDemoLogin*/)) == (8/*LoginActionFlags.AllowDemoLogin*/))), $.$$.S.Boolean));
                                    __builder4.AddComponentParameter(74, "AllowAnonymousLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((this.Flags & (16/*LoginActionFlags.AllowAnonymousLogin*/)) == (16/*LoginActionFlags.AllowAnonymousLogin*/))), $.$$.S.Boolean));
                                    __builder4.AddComponentParameter(75, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                    __builder4.AddComponentParameter(76, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                                    __builder4.AddComponentParameter(77, "Client", "Client");
                                    __builder4.AddComponentParameter(78, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("login")));
                                    __builder4.CloseComponent();
                                }, $MrduXb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                            }), $MVomvh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(79, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 80);
                            __builder3.AddComponentParameter(81, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN("Reset"/*AuthenticationExtension.ResetPasswordPath*/) + "/*"));
                            __builder3.AddAttribute$3(82, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$uVBI.LCACS$1.ResetPassword, 83);
                                    __builder4.AddComponentParameter(84, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                                    __builder4.AddComponentParameter(85, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this.Index));
                                    __builder4.AddComponentParameter(86, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                                    __builder4.AddComponentParameter(87, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.Client));
                                    __builder4.AddComponentParameter(88, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("reset")));
                                    __builder4.CloseComponent();
                                }, $Cpebxi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794});
                            }), $LTSpSg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1604419,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $KzhDof ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794}));
                        __builder2.AddComponentReferenceCapture(89, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            this.LoginView = $.$cast(__value, $.$hDPm.LCFCCM$6.MultiView);
                        }, $fFtzdh ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1604419,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    else if (((this.Flags & (2/*LoginActionFlags.Register*/)) == (2/*LoginActionFlags.Register*/)))
                    {
                        if (this.ServiceIcon !== null)
                        {
                            __builder2.OpenElement(90, "div");
                            __builder2.AddAttribute$5(91, "class", "pd-5 flex flex-center-x");
                            __builder2.AddContent$1(92, this.ServiceIcon);
                            __builder2.CloseElement();
                        }
                        __builder2.OpenComponent$1($.$uVBI.LCACS$1.Register, 93);
                        __builder2.AddComponentParameter(94, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                        __builder2.AddComponentParameter(95, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this.Index));
                        __builder2.AddComponentParameter(96, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                        __builder2.AddComponentParameter(97, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.Client));
                        __builder2.AddComponentParameter(98, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("register")));
                        __builder2.CloseComponent();
                    }
                    else if (((this.Flags & (4/*LoginActionFlags.Reset*/)) == (4/*LoginActionFlags.Reset*/)))
                    {
                        if (this.ServiceIcon !== null)
                        {
                            __builder2.OpenElement(99, "div");
                            __builder2.AddAttribute$5(100, "class", "pd-5 flex flex-center-x");
                            __builder2.AddContent$1(101, this.ServiceIcon);
                            __builder2.CloseElement();
                        }
                        __builder2.OpenComponent$1($.$uVBI.LCACS$1.ResetPassword, 102);
                        __builder2.AddComponentParameter(103, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                        __builder2.AddComponentParameter(104, "Index", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACP.App, this.Index));
                        __builder2.AddComponentParameter(105, "Root", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$uVBI.LCACS$1.Root, this));
                        __builder2.AddComponentParameter(106, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.Client));
                        __builder2.AddComponentParameter(107, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AttributesFor("reset")));
                        __builder2.CloseComponent();
                    }
                    if (this.AlertMessage !== null)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCA$1.Alert, 108);
                        __builder2.AddComponentParameter(109, "Class", "mgt pd-2 clip mgx-a");
                        __builder2.AddComponentParameter(110, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.AlertTheme)));
                        __builder2.AddAttribute$3(111, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(112, this.AlertMessage);
                        }), $igaMCb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }), $uJTLkd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1604419,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(158915394371)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12888661416)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IPushResultComponent<LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket>.Host.set
            set LCFCC$IPushResultComponent$$$Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12888661416)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(111670754115)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670754115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111670754115)
            
            //--TRIMMABLE-BOUNDARY-START(111670754115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(111670754115)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133145590595)
                this.alertTheme = $.$default($.$fPer.LCFC.Theme);
                //--TRIMMABLE-BOUNDARY-END(133145590595)
                
                //--TRIMMABLE-BOUNDARY-START(150325459779)
                this.BasePath = "Authentication";
                //--TRIMMABLE-BOUNDARY-END(150325459779)
                
                //--TRIMMABLE-BOUNDARY-START(188980165443)
                this.FormTheme = $.$default($.$fPer.LCFC.Theme);
                //--TRIMMABLE-BOUNDARY-END(188980165443)
                
                //--TRIMMABLE-BOUNDARY-START(184685198147)
                this.Flags = 7;
                //--TRIMMABLE-BOUNDARY-END(184685198147)
                
                //--TRIMMABLE-BOUNDARY-START(180390230851)
                this.FieldFeatures = 4;
                //--TRIMMABLE-BOUNDARY-END(180390230851)
                
                //--TRIMMABLE-BOUNDARY-START(176095263555)
                this.EditorFeatures = 4131;
                //--TRIMMABLE-BOUNDARY-END(176095263555)
                
                //--TRIMMABLE-BOUNDARY-START(519692647235)
                this.OnLogggedin = $.$default($.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                //--TRIMMABLE-BOUNDARY-END(519692647235)
                
                //--TRIMMABLE-BOUNDARY-START(532577549123)
                this.OnRegistered = $.$default($.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                //--TRIMMABLE-BOUNDARY-END(532577549123)
                
                //--TRIMMABLE-BOUNDARY-START(528282581827)
                this.OnPasswordReset = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(528282581827)
                
                //--TRIMMABLE-BOUNDARY-START(502512778051)
                this.NavigationManager = null;
                //--TRIMMABLE-BOUNDARY-END(502512778051)
                
                //--TRIMMABLE-BOUNDARY-START(146030492483)
                this.AuthenticationService = null;
                //--TRIMMABLE-BOUNDARY-END(146030492483)
                
                //--TRIMMABLE-BOUNDARY-START(141735525187)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(141735525187)
                
                //--TRIMMABLE-BOUNDARY-START(468153039683)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(468153039683)
                
            }
            static $h = 1604419;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(536872516419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386548661059,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1604419,
      "h": 536872516419,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(536872516419),
//--TRIMMABLE-BOUNDARY-START(128850623299),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570100035,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 575527222083,
        "f": 83886088
      },
      "n": "AlertMessage",
      "d": 1604419,
      "h": 128850623299,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(128850623299),
//--TRIMMABLE-BOUNDARY-START(137440557891),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160034627,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 584117156675,
        "f": 83886088
      },
      "n": "AlertTheme",
      "d": 1604419,
      "h": 137440557891,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(137440557891),
//--TRIMMABLE-BOUNDARY-START(485332908867),
    {
      "p": 37443242,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326419118915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 704376240963,
        "f": 83886082
      },
      "n": "LoginView",
      "d": 1604419,
      "h": 485332908867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485332908867),
//--TRIMMABLE-BOUNDARY-START(481037941571),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317829184323,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 695786306371,
        "f": 83886081
      },
      "n": "LoginChildContent",
      "d": 1604419,
      "h": 481037941571,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(481037941571),
//--TRIMMABLE-BOUNDARY-START(549757418307),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395138595651,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 764505783107,
        "f": 83886081
      },
      "n": "RegisterChildContent",
      "d": 1604419,
      "h": 549757418307,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(549757418307),
//--TRIMMABLE-BOUNDARY-START(828930292547),
    {
      "p": $.$$.S.Func$$($.$$.STT.Task).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429498334019,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 798865521475,
        "f": 83886081
      },
      "n": "ValidateLogin",
      "d": 1604419,
      "h": 828930292547,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(828930292547),
//--TRIMMABLE-BOUNDARY-START(833225259843),
    {
      "p": $.$$.S.Func$$($.$$.STT.Task).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 438088268611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 807455456067,
        "f": 83886081
      },
      "n": "ValidateRegisteration",
      "d": 1604419,
      "h": 833225259843,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(833225259843),
//--TRIMMABLE-BOUNDARY-START(498217810755),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343598988099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 721556110147,
        "f": 83886081
      },
      "n": "Navigable",
      "d": 1604419,
      "h": 498217810755,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(498217810755),
//--TRIMMABLE-BOUNDARY-START(446678203203),
    {
      "p": 555843,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292059380547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 670016502595,
        "f": 83886081
      },
      "n": "Index",
      "d": 1604419,
      "h": 446678203203,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(446678203203),
//--TRIMMABLE-BOUNDARY-START(150325459779),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929838403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 609886960451,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 1604419,
      "h": 150325459779,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325459779),
//--TRIMMABLE-BOUNDARY-START(188980165443),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879511363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 652836633411,
        "f": 83886081
      },
      "n": "FormTheme",
      "d": 1604419,
      "h": 188980165443,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980165443),
//--TRIMMABLE-BOUNDARY-START(167505328963),
    {
      "p": 1589634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519772995,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 618476895043,
        "f": 83886081
      },
      "n": "Client",
      "d": 1604419,
      "h": 167505328963,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505328963),
//--TRIMMABLE-BOUNDARY-START(184685198147),
    {
      "p": 66344618,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266289576771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 644246698819,
        "f": 83886081
      },
      "n": "Flags",
      "d": 1604419,
      "h": 184685198147,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685198147),
//--TRIMMABLE-BOUNDARY-START(566937287491),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403728530243,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 773095717699,
        "f": 83886081
      },
      "n": "ServiceIcon",
      "d": 1604419,
      "h": 566937287491,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(566937287491),
//--TRIMMABLE-BOUNDARY-START(824635325251),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420908399427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 790275586883,
        "f": 83886081
      },
      "n": "Uri",
      "d": 1604419,
      "h": 824635325251,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(824635325251),
//--TRIMMABLE-BOUNDARY-START(180390230851),
    {
      "p": 30955178,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699642179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 635656764227,
        "f": 83886081
      },
      "n": "FieldFeatures",
      "d": 1604419,
      "h": 180390230851,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180390230851),
//--TRIMMABLE-BOUNDARY-START(176095263555),
    {
      "p": 27612842,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109707587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 627066829635,
        "f": 83886081
      },
      "n": "EditorFeatures",
      "d": 1604419,
      "h": 176095263555,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176095263555),
//--TRIMMABLE-BOUNDARY-START(519692647235),
    {
      "p": $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360778857283,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 738735979331,
        "f": 83886081
      },
      "n": "OnLogggedin",
      "d": 1604419,
      "h": 519692647235,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(519692647235),
//--TRIMMABLE-BOUNDARY-START(532577549123),
    {
      "p": $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377958726467,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 755915848515,
        "f": 83886081
      },
      "n": "OnRegistered",
      "d": 1604419,
      "h": 532577549123,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(532577549123),
//--TRIMMABLE-BOUNDARY-START(528282581827),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369368791875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 747325913923,
        "f": 83886081
      },
      "n": "OnPasswordReset",
      "d": 1604419,
      "h": 528282581827,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(528282581827),
//--TRIMMABLE-BOUNDARY-START(502512778051),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352188922691,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 730146044739,
        "f": 83886081
      },
      "n": "NavigationManager",
      "d": 1604419,
      "h": 502512778051,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(502512778051),
//--TRIMMABLE-BOUNDARY-START(146030492483),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339903811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 601297025859,
        "f": 83886081
      },
      "n": "AuthenticationService",
      "d": 1604419,
      "h": 146030492483,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030492483),
//--TRIMMABLE-BOUNDARY-START(141735525187),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749969219,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 592707091267,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 1604419,
      "h": 141735525187,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735525187),
//--TRIMMABLE-BOUNDARY-START(489627876163),
    {
      "p": 541058,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335009053507,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 712966175555,
        "f": 83886082
      },
      "n": "Metadata",
      "d": 1604419,
      "h": 489627876163,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(489627876163),
//--TRIMMABLE-BOUNDARY-START(816045390659),
    {
      "p": 55793322,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412318464835,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 781685652291,
        "f": 83886081
      },
      "n": "Tabs",
      "d": 1604419,
      "h": 816045390659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(816045390659),
//--TRIMMABLE-BOUNDARY-START(468153039683),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309239249731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 687196371779,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1604419,
      "h": 468153039683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(468153039683),
//--TRIMMABLE-BOUNDARY-START(463858072387),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300649315139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 678606437187,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1604419,
      "h": 463858072387,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(463858072387),
//--TRIMMABLE-BOUNDARY-START(442383235907),
    {
      "p": 3300776,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283469445955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 661426568003,
        "f": 83886081
      },
      "n": "Host",
      "d": 1604419,
      "h": 442383235907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(442383235907)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(820340357955),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1604419,
      "h": 820340357955,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(820340357955),
//--TRIMMABLE-BOUNDARY-START(450973170499),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1604419,
      "h": 450973170499,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(450973170499),
//--TRIMMABLE-BOUNDARY-START(493922843459),
    {
      "r": 65537,
      "n": "MetaFromQueryString",
      "d": 1604419,
      "h": 493922843459,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(493922843459),
//--TRIMMABLE-BOUNDARY-START(472448006979),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "arg",
          "p": 10551411
        }
      ],
      "n": "LocationChanged",
      "d": 1604419,
      "h": 472448006979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(472448006979),
//--TRIMMABLE-BOUNDARY-START(154620427075),
    {
      "r": 541058,
      "p": [
        {
          "n": "metadata",
          "p": 541058
        }
      ],
      "n": "BuildMetadata",
      "d": 1604419,
      "h": 154620427075,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(154620427075),
//--TRIMMABLE-BOUNDARY-START(515397679939),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1604419,
      "h": 515397679939,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(515397679939),
//--TRIMMABLE-BOUNDARY-START(171800296259),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1604419,
      "h": 171800296259,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800296259),
//--TRIMMABLE-BOUNDARY-START(811750423363),
    {
      "r": 65537,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "SetAlert",
      "d": 1604419,
      "h": 811750423363,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(811750423363),
//--TRIMMABLE-BOUNDARY-START(511102712643),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 1604419,
      "h": 511102712643,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(511102712643),
//--TRIMMABLE-BOUNDARY-START(523987614531),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1604419,
      "h": 523987614531,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(523987614531),
//--TRIMMABLE-BOUNDARY-START(506807745347),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "NotifyLoggedIn",
      "d": 1604419,
      "h": 506807745347,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(506807745347),
//--TRIMMABLE-BOUNDARY-START(476742974275),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "LoggedIn",
      "d": 1604419,
      "h": 476742974275,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(476742974275),
//--TRIMMABLE-BOUNDARY-START(554052385603),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "Registered",
      "d": 1604419,
      "h": 554052385603,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(554052385603),
//--TRIMMABLE-BOUNDARY-START(541167483715),
    {
      "r": 178454529,
      "n": "PasswordReset",
      "d": 1604419,
      "h": 541167483715,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(541167483715),
//--TRIMMABLE-BOUNDARY-START(455268137795),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1604419,
      "h": 455268137795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(455268137795),
//--TRIMMABLE-BOUNDARY-START(459563105091),
    {
      "r": 181338113,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Func$$($.$$.STT.ValueTask).$h
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 1604419,
      "h": 459563105091,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(459563105091),
//--TRIMMABLE-BOUNDARY-START(158915394371),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1604419,
      "h": 158915394371,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(158915394371)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555656003),
    {
      "t": 1310721,
      "n": "alertMessage",
      "d": 1604419,
      "h": 124555656003,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555656003),
//--TRIMMABLE-BOUNDARY-START(133145590595),
    {
      "t": 65309014,
      "n": "alertTheme",
      "d": 1604419,
      "h": 133145590595,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145590595),
//--TRIMMABLE-BOUNDARY-START(163210361667),
    {
      "t": 1589634,
      "n": "client",
      "d": 1604419,
      "h": 163210361667,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163210361667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(111670754115),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1604419,
      "h": 111670754115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670754115)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(545462451011),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1604419,
        "h": 120260688707,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1604419,
        "h": 562642320195,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1604419,
      "h": 545462451011,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(545462451011)
  ],
  "h": 1604419
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.IPushResultComponent$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$vWqU.LCFCC.IResultComponent$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$vWqU.LCFCC.IResultComponent, $.$vWqU.LCFCC.IHostedView, $.$vWqU.LCFCC.IViewBase, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.Shared.Root`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}Shared${separator}Root`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1604419)
        
        

        //--TRIMMABLE-BOUNDARY-START(1801027)
        $asm.$cls(`$uVBI.LCACV.ChoosePasswordException`, ($self) => class ChoosePasswordException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4296768323)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296768323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296768323)
            
            //--TRIMMABLE-BOUNDARY-START(4296768323)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296768323)
            
            static $h = 1801027;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296768323),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1801027,
      "h": 4296768323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296768323)
  ],
  "h": 1801027
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.ViewModels.ChoosePasswordException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}ViewModels${separator}ChoosePasswordException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1801027)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(31555)
