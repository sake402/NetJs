//// <reference path="../../../../Libraries/LivingThing.Frameworks/LivingThing.Core.Frameworks.Client.Blazor.Library/Components/Heading/Heading.razor.ts" />

declare var Define: (name: string, f: any) => void;
