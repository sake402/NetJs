
//--TRIMMABLE-BOUNDARY-START(54360)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $hqRR, $sitj, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $uVBI) {
    "use strict";
    let _;
    let $ojoaUb;
    let $qjWchf;
    let $TeeIvj;
    let $LifIRg;
    let $hqwvTj;
    let $QmlBni;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Authentication.Client.OAuth.Blazor", 
    {
  "h": 54360,
  "f": "LivingThing.Core.Authentication.Client.OAuth.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Authentication.Client.OAuth.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Authentication.Client.OAuth.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(644184)
        $asm.$cls(`$yJPN.LCACOS.OAuth2ClientLoginBase`, ($self) => class OAuth2ClientLoginBase extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(176094303320)
            /*string */ get OptimizedComponentName()
            {
                return "";
            }
            //--TRIMMABLE-BOUNDARY-END(176094303320)
            
            //--TRIMMABLE-BOUNDARY-START(266288616536)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288616536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Metadata":
                    this.Metadata = $.$cast(parameter.Value, $.$GfYa.LCFCA.AuthenticationMetadata);
                    return true;
                    case "OnLoggedIn":
                    this.OnLoggedIn = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(266288616536)
            
            //--TRIMMABLE-BOUNDARY-START(150324499544)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324499544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ClientConfigurations = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration), serviceProvider);
                this.MessagePipe = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
                this.Providers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$DZqk.LCACO.IOAuth2ServerProvider), serviceProvider);
                this.Auth = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GfYa.LCFCA.IAuthenticationService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Browser = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IBrowserWindow, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(150324499544)
            
            //--TRIMMABLE-BOUNDARY-START(158914434136)
            /*AuthenticationMetadata*/ Metadata = null;
            //--TRIMMABLE-BOUNDARY-END(158914434136)
            
            //--TRIMMABLE-BOUNDARY-START(171799336024)
            /*EventCallback<DecodedAuthenticationTicket>*/ OnLoggedIn;
            //--TRIMMABLE-BOUNDARY-END(171799336024)
            
            //--TRIMMABLE-BOUNDARY-START(51540251736)
            /*IOptionsSnapshot<OAuth2ClientConfiguration>*/ ClientConfigurations = null;
            //--TRIMMABLE-BOUNDARY-END(51540251736)
            
            //--TRIMMABLE-BOUNDARY-START(154619466840)
            /*IMessagePipeFactory*/ MessagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(154619466840)
            
            //--TRIMMABLE-BOUNDARY-START(180389270616)
            /*IEnumerable<IOAuth2ServerProvider>*/ Providers = null;
            //--TRIMMABLE-BOUNDARY-END(180389270616)
            
            //--TRIMMABLE-BOUNDARY-START(42950317144)
            /*IAuthenticationService*/ Auth = null;
            //--TRIMMABLE-BOUNDARY-END(42950317144)
            
            //--TRIMMABLE-BOUNDARY-START(163209401432)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(163209401432)
            
            //--TRIMMABLE-BOUNDARY-START(47245284440)
            /*IBrowserWindow*/ Browser = null;
            //--TRIMMABLE-BOUNDARY-END(47245284440)
            
            //--TRIMMABLE-BOUNDARY-START(167504368728)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504368728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$Assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Authentication.Client.OAuth.Blazor.js", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(167504368728)
            
            //--TRIMMABLE-BOUNDARY-START(261993649240)
            /*ValueTask *//*async*/  StartLogin()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261993649240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let loginId = $.$$.S.Guid.NewGuid().ToString();
                    /*var*/ let provider = $.$sl.SL.Enumerable.SingleOrDefault$1($.$DZqk.LCACO.IOAuth2ServerProvider, this.Providers, new ($.$$.S.Func$$$($.$DZqk.LCACO.IOAuth2ServerProvider, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                    {
                        return p.LCACO$IOAuth2ServerProvider$ProviderName === this.ServiceName;
                    }, $QmlBni ??= {"r":262145,"p":[{"n":"p","p":6538237}],"n":"","d":644184,"h":0,"f":17825794}));
                    if (provider !== null)
                    {
                        let serverPipe = null;
                        try
                        {
                            let $t2, $r2;
                            let $t4, $r4;
                            let $t5, $r5;
                            let $t6, $r6;
                            serverPipe = ($t2 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.MessagePipe, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(loginId), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            /*var*/ let appUrl = this.Navigation.Uri;
                            /*var*/ let callbackUrl = $.$fPer.LCFC.PathUtility.ToUrl("https", this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost, `OAuth2/Redirect/${$.$strNN(this.ServiceName)}`);
                            /*var*/ let returnUrl = $.$fPer.LCFC.PathUtility.ToUrl("https", this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost, `closeWindow?open=${$.$strNN(appUrl)}`);
                            /*var*/ let state = $.$swh.SW.HttpUtility.UrlEncode$3($.$fPer.LCFCS$6.StringExtension.AsQueryString((() =>
                            {
                                //new $.$DZqk.LCACO.OAuth2State()
                                const $t3 = $.$DZqk.LCACO.OAuth2State;
                                const $i3 = new $t3();
                                $i3.$ctor$1();
                                $i3.PipeId = $.$fPer.LCFCR$3.RoutePath.op_Implicit($.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCR$3.RoutePath, serverPipe.LCFCM$IMessagePipe$PipesId));
                                $i3.ClientId = serverPipe.LCFCM$IMessagePipe$Client.ClientId;
                                $i3.RedirectUrl = returnUrl;
                                $i3.OAuthCallbackUrl = callbackUrl;
                                $i3.ProviderName = this.ServiceName;
                                $i3.Metadata = this.Metadata;
                                return $i3;
                            })(), false));
                            ($t4 = $.$DZqk.LCACO.OAuth2Controller.Authorize(this.Browser, provider, this.ClientConfigurations.MEO$IOptionsSnapshot$LivingThing$Core$Authentication$Common$OAuth2$OAuth2ClientConfiguration$Get(this.ServiceName), $.$swh.SW.HttpUtility.UrlEncode$3(this.Scope), state, callbackUrl), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            /*var*/ let ticket = ($t5 = $.$UrvY.LCFCM.MessagePipeExtension.Await($.$GfYa.LCFCA.DecodedAuthenticationTicket, serverPipe, $.$$.ST$1.CancellationToken.None), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            ($t6 = this.OnLoggedIn.InvokeAsync$1(ticket), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        }
                        finally
                        {
                            serverPipe?.S$IDisposable$Dispose();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(261993649240)
            
            //--TRIMMABLE-BOUNDARY-START(38655349848)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655349848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655349848)
            
            //--TRIMMABLE-BOUNDARY-START(38655349848)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(38655349848)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(171799336024)
                this.OnLoggedIn = $.$default($.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                //--TRIMMABLE-BOUNDARY-END(171799336024)
                
                //--TRIMMABLE-BOUNDARY-START(51540251736)
                this.ClientConfigurations = null;
                //--TRIMMABLE-BOUNDARY-END(51540251736)
                
                //--TRIMMABLE-BOUNDARY-START(154619466840)
                this.MessagePipe = null;
                //--TRIMMABLE-BOUNDARY-END(154619466840)
                
                //--TRIMMABLE-BOUNDARY-START(180389270616)
                this.Providers = null;
                //--TRIMMABLE-BOUNDARY-END(180389270616)
                
                //--TRIMMABLE-BOUNDARY-START(42950317144)
                this.Auth = null;
                //--TRIMMABLE-BOUNDARY-END(42950317144)
                
                //--TRIMMABLE-BOUNDARY-START(163209401432)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(163209401432)
                
                //--TRIMMABLE-BOUNDARY-START(47245284440)
                this.Browser = null;
                //--TRIMMABLE-BOUNDARY-END(47245284440)
                
            }
            static $h = 644184;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176094303320),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259728472,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 644184,
      "h": 176094303320,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094303320),
//--TRIMMABLE-BOUNDARY-START(188979205208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029532248,
        "f": 50331908
      },
      "n": "ServiceName",
      "d": 644184,
      "h": 188979205208,
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(188979205208),
//--TRIMMABLE-BOUNDARY-START(184684237912),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439597656,
        "f": 50331908
      },
      "n": "Scope",
      "d": 644184,
      "h": 184684237912,
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(184684237912),
//--TRIMMABLE-BOUNDARY-START(158914434136),
    {
      "p": 541058,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489924696,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928878168,
        "f": 83886081
      },
      "n": "Metadata",
      "d": 644184,
      "h": 158914434136,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914434136),
//--TRIMMABLE-BOUNDARY-START(171799336024),
    {
      "p": $.$mac.MAC.EventCallback$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669793880,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108747352,
        "f": 83886081
      },
      "n": "OnLoggedIn",
      "d": 644184,
      "h": 171799336024,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799336024),
//--TRIMMABLE-BOUNDARY-START(51540251736),
    {
      "p": $.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310055512,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749008984,
        "f": 83886081
      },
      "n": "ClientConfigurations",
      "d": 644184,
      "h": 51540251736,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540251736),
//--TRIMMABLE-BOUNDARY-START(154619466840),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899990104,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338943576,
        "f": 83886081
      },
      "n": "MessagePipe",
      "d": 644184,
      "h": 154619466840,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619466840),
//--TRIMMABLE-BOUNDARY-START(180389270616),
    {
      "p": $.$$.SCG.IEnumerable$$($.$DZqk.LCACO.IOAuth2ServerProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849663064,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698681944,
        "f": 83886081
      },
      "n": "Providers",
      "d": 644184,
      "h": 180389270616,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389270616),
//--TRIMMABLE-BOUNDARY-START(42950317144),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130186328,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569139800,
        "f": 83886081
      },
      "n": "Auth",
      "d": 644184,
      "h": 42950317144,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950317144),
//--TRIMMABLE-BOUNDARY-START(163209401432),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079859288,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518812760,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 644184,
      "h": 163209401432,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209401432),
//--TRIMMABLE-BOUNDARY-START(47245284440),
    {
      "p": 46172502,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720120920,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159074392,
        "f": 83886081
      },
      "n": "Browser",
      "d": 644184,
      "h": 47245284440,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245284440)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(266288616536),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 644184,
      "h": 266288616536,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266288616536),
//--TRIMMABLE-BOUNDARY-START(150324499544),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 644184,
      "h": 150324499544,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324499544),
//--TRIMMABLE-BOUNDARY-START(167504368728),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 644184,
      "h": 167504368728,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(167504368728),
//--TRIMMABLE-BOUNDARY-START(261993649240),
    {
      "r": 181338113,
      "n": "StartLogin",
      "d": 644184,
      "h": 261993649240,
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(261993649240)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655349848),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 644184,
      "h": 38655349848,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655349848)
  ],
  "h": 644184
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.Shared.OAuth2ClientLoginBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}Shared${separator}OAuth2ClientLoginBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(644184)
        
        

        //--TRIMMABLE-BOUNDARY-START(382040)
        $asm.$cls(`$yJPN.LCACO.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590316632)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590316632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$yJPN.LCACO.OAuth2ServerLogin, "LivingThing.Core.Authentication.Client.OAuth", "OAuth2ServerLogin", "OAuth2Server Login", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/OAuth2/Server/Login/{Source?}/{Target?}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590316632)
            
            //--TRIMMABLE-BOUNDARY-START(4295349336)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295349336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295349336)
            
            //--TRIMMABLE-BOUNDARY-START(4295349336)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295349336)
            
            static $h = 382040;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590316632),
    {
      "r": 65537,
      "n": "Build",
      "d": 382040,
      "h": 8590316632,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590316632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295349336),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 382040,
      "h": 4295349336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295349336)
  ],
  "h": 382040
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382040)
        
        

        //--TRIMMABLE-BOUNDARY-START(185432)
        $asm.$cls(`$yJPN.LCACO._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295152728)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295152728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$yJPN.LCACO.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295152728)
            
            static $h = 185432;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295152728),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 185432,
      "h": 4295152728,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295152728)
  ],
  "h": 185432
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(185432)
        
        

        //--TRIMMABLE-BOUNDARY-START(513112)
        $asm.$cls(`$yJPN.LCACO.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590447704)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590447704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yJPN.LCACO.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$uVBI.LCACS.IOAuth2AuthenticationService, $.$yJPN.LCACO.GoogleOAuth2AuthenticationService, services);
                $.$yJPN.LCACO._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590447704)
            
            //--TRIMMABLE-BOUNDARY-START(12885415000)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885415000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_GoogleOAuth2AuthenticationService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$yJPN.LCACO.GoogleOAuth2AuthenticationService().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration), provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uVBI.LCACS.IOAuth2AuthenticationService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$yJPN.LCACO.ServiceRegistrar, Get_GoogleOAuth2AuthenticationService, $TeeIvj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_GoogleOAuth2AuthenticationService","d":513112,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12885415000)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yJPN.LCACO.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295480408)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295480408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295480408)
            
            //--TRIMMABLE-BOUNDARY-START(4295480408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295480408)
            
            static $h = 513112;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590447704),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 513112,
      "h": 8590447704,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590447704),
//--TRIMMABLE-BOUNDARY-START(12885415000),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 513112,
      "h": 12885415000,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885415000)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295480408),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 513112,
      "h": 4295480408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295480408)
  ],
  "h": 513112
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513112)
        
        

        //--TRIMMABLE-BOUNDARY-START(250968)
        $asm.$cls(`$yJPN.LCACO.GoogleOAuth2AuthenticationService`, ($self) => class GoogleOAuth2AuthenticationService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590185560)
            $ctor$1(/*IOptionsSnapshot<OAuth2ClientConfiguration>*/ clientConfigurations)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590185560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ClientConfigurations = clientConfigurations;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590185560)
            
            //--TRIMMABLE-BOUNDARY-START(12885152856)
            /*IOptionsSnapshot<OAuth2ClientConfiguration>*/ ClientConfigurations = null;
            //--TRIMMABLE-BOUNDARY-END(12885152856)
            
            //--TRIMMABLE-BOUNDARY-START(38654956632)
            /*bool */ get IsConfigured()
            {
                return (this.ClientConfigurations.MEO$IOptionsSnapshot$LivingThing$Core$Authentication$Common$OAuth2$OAuth2ClientConfiguration$Get("Google")?.IsValid ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(38654956632)
            
            //--TRIMMABLE-BOUNDARY-START(34359989336)
            /*RenderFragment */ GetView(/*Func<DecodedAuthenticationTicket, ValueTask>*/ onLoggedIn, /*AuthenticationMetadata?*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359989336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$yJPN.LCACOS.GoogleLogin, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Metadata", metadata);
                    $i1.set_Item("OnLoggedIn", $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$mac.MAC.EventCallback.Factory, this, onLoggedIn));
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34359989336)
            
            //--TRIMMABLE-BOUNDARY-START(8590949187)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Services.IOAuth2AuthenticationService.IsConfigured.get
            get LCACS$IOAuth2AuthenticationService$IsConfigured()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180883779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsConfigured;
            }
            //--TRIMMABLE-BOUNDARY-END(8590949187)
            
            //--TRIMMABLE-BOUNDARY-START(12885916483)
            //Generated interface implemetation for LivingThing.Core.Authentication.Client.Services.IOAuth2AuthenticationService.GetView(System.Func<LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket, System.Threading.Tasks.ValueTask>, LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata?)
            LCACS$IOAuth2AuthenticationService$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885916483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885916483)
            
            static $h = 250968;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885152856),
    {
      "p": $.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475087448,
        "f": 50331650
      },
      "n": "ClientConfigurations",
      "d": 250968,
      "h": 12885152856,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885152856),
//--TRIMMABLE-BOUNDARY-START(38654956632),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065022040,
        "f": 50331649
      },
      "n": "IsConfigured",
      "d": 250968,
      "h": 38654956632,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654956632)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359989336),
    {
      "r": 6881395,
      "p": [
        {
          "n": "onLoggedIn",
          "p": $.$$.S.Func$$$($.$GfYa.LCFCA.DecodedAuthenticationTicket, $.$$.STT.ValueTask).$h
        },
        {
          "n": "metadata",
          "p": 541058
        }
      ],
      "n": "GetView",
      "d": 250968,
      "h": 34359989336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359989336)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590185560),
    {
      "p": [
        {
          "n": "clientConfigurations",
          "p": $.$meo.MEO.IOptionsSnapshot$$($.$DZqk.LCACO.OAuth2ClientConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 250968,
      "h": 8590185560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590185560)
  ],
  "h": 250968
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uVBI.LCACS.IOAuth2AuthenticationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.GoogleOAuth2AuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}GoogleOAuth2AuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(250968)
        
        

        //--TRIMMABLE-BOUNDARY-START(316504)
        $asm.$cls(`$yJPN.LCACO.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180185688)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yJPN.LCACO.OAuth2ServerLogin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yJPN.LCACO.OAuth2ServerLogin().$ctor$3();
                    }, $ojoaUb ??= {"r":2752627,"n":"","d":316504,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$yJPN.LCACOS.GoogleLogin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$yJPN.LCACOS.GoogleLogin().$ctor$4();
                    }, $qjWchf ??= {"r":2752627,"n":"","d":316504,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180185688)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295283800)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295283800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295283800)
            
            //--TRIMMABLE-BOUNDARY-START(4295283800)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295283800)
            
            static $h = 316504;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180185688),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885218392,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 316504,
      "h": 17180185688,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180185688)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295283800),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 316504,
      "h": 4295283800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295283800)
  ],
  "h": 316504
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(316504)
        
        

        //--TRIMMABLE-BOUNDARY-START(775256)
        $asm.$cls(`$yJPN.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295742552)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295742552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295742552)
            
            //--TRIMMABLE-BOUNDARY-START(4295742552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295742552)
            
            static $h = 775256;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295742552),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 775256,
      "h": 4295742552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295742552)
  ],
  "h": 775256,
  "a": [
    {
      "t": 709720,
      "c": 4295677016
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(775256)
        
        

        //--TRIMMABLE-BOUNDARY-START(709720)
        $asm.$cls(`$yJPN.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295677016)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295677016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295677016)
            
            //--TRIMMABLE-BOUNDARY-START(4295677016)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295677016)
            
            static $h = 709720;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295677016),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 709720,
      "h": 4295677016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295677016)
  ],
  "h": 709720
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(709720)
        
        

        //--TRIMMABLE-BOUNDARY-START(119896)
        $asm.$cls(`$yJPN.LCACO._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590054488)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590054488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590054488)
            
            //--TRIMMABLE-BOUNDARY-START(4295087192)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295087192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295087192)
            
            //--TRIMMABLE-BOUNDARY-START(4295087192)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295087192)
            
            static $h = 119896;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590054488),
    {
      "r": 65537,
      "n": "Execute",
      "d": 119896,
      "h": 8590054488,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590054488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295087192),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 119896,
      "h": 4295087192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295087192)
  ],
  "h": 119896
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(119896)
        
        

        //--TRIMMABLE-BOUNDARY-START(447576)
        $asm.$cls(`$yJPN.LCACO.OAuth2ServerLogin`, ($self) => class OAuth2ServerLogin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(163209204824)
            /*string */ get OptimizedComponentName()
            {
                return "oauth2serverlogin";
            }
            //--TRIMMABLE-BOUNDARY-END(163209204824)
            
            //--TRIMMABLE-BOUNDARY-START(261993452632)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993452632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Source":
                    this.Source = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Target":
                    this.Target = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "ClientId":
                    this.ClientId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "ResponseType":
                    this.ResponseType = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Scope":
                    this.Scope = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "RedirectUri":
                    this.RedirectUri = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "State":
                    this.State = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(261993452632)
            
            //--TRIMMABLE-BOUNDARY-START(146029335640)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029335640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(146029335640)
            
            //--TRIMMABLE-BOUNDARY-START(249108550744)
            /*string?*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(249108550744)
            
            //--TRIMMABLE-BOUNDARY-START(257698485336)
            /*string?*/ Target = null;
            //--TRIMMABLE-BOUNDARY-END(257698485336)
            
            //--TRIMMABLE-BOUNDARY-START(51540055128)
            /*string?*/ ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(51540055128)
            
            //--TRIMMABLE-BOUNDARY-START(171799139416)
            /*string?*/ ResponseType = null;
            //--TRIMMABLE-BOUNDARY-END(171799139416)
            
            //--TRIMMABLE-BOUNDARY-START(176094106712)
            /*string?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(176094106712)
            
            //--TRIMMABLE-BOUNDARY-START(167504172120)
            /*string?*/ RedirectUri = null;
            //--TRIMMABLE-BOUNDARY-END(167504172120)
            
            //--TRIMMABLE-BOUNDARY-START(253403518040)
            /*string?*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(253403518040)
            
            //--TRIMMABLE-BOUNDARY-START(150324302936)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(150324302936)
            
            //--TRIMMABLE-BOUNDARY-START(55835022424)
            /*AuthenticationClientDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(55835022424)
            
            //--TRIMMABLE-BOUNDARY-START(154619270232)
            /*ValueTask<bool> *//*async*/  OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619270232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (ticket.Token.JWToken === null)
                    {
                        let $t2, $r2;
                        /*var*/ let mticket = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$DZqk.LCACS.IAuthenticationRemoteService, $.$GfYa.LCFCA.DecodedAuthenticationTicket, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$DZqk.LCACS.IAuthenticationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCACS$IAuthenticationRemoteService$RefreshLoginToken(new $.$GfYa.LCFCA.AuthToken());
                        }, $hqwvTj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)).$h,"p":[{"n":"server","p":7259133}],"n":"","d":447576,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        ticket.Token = mticket.Token;
                    }
                    this.Navigation.NavigateTo$2($.$strNN($.$strNN($.$strNN($.$strNN(this.RedirectUri) + "?state=") + $.$strNN(this.State)) + "&code=") + $.$strNN(ticket.Token.JWToken), true);
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154619270232)
            
            //--TRIMMABLE-BOUNDARY-START(158914237528)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914237528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(158914237528)
            
            //--TRIMMABLE-BOUNDARY-START(47245087832)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245087832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf pd stack");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mg-a");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "pd bg-card");
                __builder.OpenElement(6, "p");
                __builder.AddContent$4(7, this.Target);
                __builder.AddContent$4(8, ": Link your SIT account with ");
                __builder.AddContent$4(9, this.Source);
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n            ");
                __builder.AddContent$1(11, this.UnitOfWork.LCFCI$IClientUnitOfWork$ClientAuthentication.LCFCI$IClientAuthenticationService$Authenticate((() =>
                {
                    //new $.$hDPm.LCFCI.AuthenticationParameter()
                    const $t3 = $.$hDPm.LCFCI.AuthenticationParameter;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Client = this;
                    return $i3;
                })()));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(47245087832)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //--TRIMMABLE-BOUNDARY-START(42950120536)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950120536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950120536)
            
            //--TRIMMABLE-BOUNDARY-START(42950120536)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42950120536)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(150324302936)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(150324302936)
                
            }
            static $h = 447576;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209204824),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194760792,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 447576,
      "h": 163209204824,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209204824),
//--TRIMMABLE-BOUNDARY-START(249108550744),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554499160,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633714264,
        "f": 83886081
      },
      "n": "Source",
      "d": 447576,
      "h": 249108550744,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249108550744),
//--TRIMMABLE-BOUNDARY-START(257698485336),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734368344,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813583448,
        "f": 83886081
      },
      "n": "Target",
      "d": 447576,
      "h": 257698485336,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257698485336),
//--TRIMMABLE-BOUNDARY-START(51540055128),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424957016,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684041304,
        "f": 83886081
      },
      "n": "ClientId",
      "d": 447576,
      "h": 51540055128,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "client_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540055128),
//--TRIMMABLE-BOUNDARY-START(171799139416),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374629976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453845080,
        "f": 83886081
      },
      "n": "ResponseType",
      "d": 447576,
      "h": 171799139416,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "response_type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799139416),
//--TRIMMABLE-BOUNDARY-START(176094106712),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964564568,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043779672,
        "f": 83886081
      },
      "n": "Scope",
      "d": 447576,
      "h": 176094106712,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "scope",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094106712),
//--TRIMMABLE-BOUNDARY-START(167504172120),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784695384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863910488,
        "f": 83886081
      },
      "n": "RedirectUri",
      "d": 447576,
      "h": 167504172120,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "redirect_uri",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504172120),
//--TRIMMABLE-BOUNDARY-START(253403518040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144433752,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223648856,
        "f": 83886081
      },
      "n": "State",
      "d": 447576,
      "h": 253403518040,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "state",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403518040),
//--TRIMMABLE-BOUNDARY-START(150324302936),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604826200,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273975896,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 447576,
      "h": 150324302936,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324302936),
//--TRIMMABLE-BOUNDARY-START(55835022424),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014891608,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 447576,
      "h": 55835022424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835022424)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(261993452632),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 447576,
      "h": 261993452632,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261993452632),
//--TRIMMABLE-BOUNDARY-START(146029335640),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 447576,
      "h": 146029335640,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029335640),
//--TRIMMABLE-BOUNDARY-START(154619270232),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": 447576,
      "h": 154619270232,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(154619270232),
//--TRIMMABLE-BOUNDARY-START(158914237528),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": 447576,
      "h": 158914237528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914237528),
//--TRIMMABLE-BOUNDARY-START(47245087832),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 447576,
      "h": 47245087832,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245087832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950120536),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 447576,
      "h": 42950120536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950120536)
  ],
  "h": 447576,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/OAuth2/Server/Login/{Source?}/{Target?}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$GfYa.LCFCA.IAuthenticationClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.OAuth2ServerLogin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}OAuth2ServerLogin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(447576)
        
        

        //--TRIMMABLE-BOUNDARY-START(578648)
        $asm.$cls(`$yJPN.LCACOS.GoogleLogin`, ($self) => class GoogleLogin extends $.$yJPN.LCACOS.OAuth2ClientLoginBase
        {
            //--TRIMMABLE-BOUNDARY-START(47245218904)
            /*string */ get ServiceName()
            {
                return "Google";
            }
            //--TRIMMABLE-BOUNDARY-END(47245218904)
            
            //--TRIMMABLE-BOUNDARY-START(42950251608)
            /*string */ get Scope()
            {
                return $.$strNN($.$strNN($.$DZqk.LCACOG.GoogleOAuth2ServerProvider.UserEmailInfoScope) + " ") + $.$strNN($.$DZqk.LCACOG.GoogleOAuth2ServerProvider.UserProfileInfoScope);
            }
            //--TRIMMABLE-BOUNDARY-END(42950251608)
            
            //--TRIMMABLE-BOUNDARY-START(38655284312)
            /*string */ get OptimizedComponentName()
            {
                return "googlelogin";
            }
            //--TRIMMABLE-BOUNDARY-END(38655284312)
            
            //--TRIMMABLE-BOUNDARY-START(8590513240)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590513240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 0);
                __builder.AddComponentParameter(1, "Class", "flex d-block mgx-a");
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, (131634/*ButtonFeatures.Default*/ & ~16/*ButtonFeatures.Shadow*/) | 8/*ButtonFeatures.Outline*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(3, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.StartLogin))));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(5, "<div class=\"mgy-a\">\r\n        Continue with Google\r\n    </div>\r\n    ");
                    __builder2.OpenElement(6, "img");
                    __builder2.AddAttribute$5(7, "src", this.ResolvePath("img/google.png", true, false, false));
                    __builder2.AddAttribute$5(8, "class", "mgy-a wx-03 mgl");
                    __builder2.CloseElement();
                }), $LifIRg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":578648,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590513240)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295545944)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295545944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295545944)
            
            //--TRIMMABLE-BOUNDARY-START(4295545944)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295545944)
            
            static $h = 578648;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yJPN.LCACOS.OAuth2ClientLoginBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245218904),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360317016,
        "f": 50364420
      },
      "n": "ServiceName",
      "d": 578648,
      "h": 47245218904,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(47245218904),
//--TRIMMABLE-BOUNDARY-START(42950251608),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770382424,
        "f": 50364420
      },
      "n": "Scope",
      "d": 578648,
      "h": 42950251608,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42950251608),
//--TRIMMABLE-BOUNDARY-START(38655284312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180447832,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 578648,
      "h": 38655284312,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655284312)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590513240),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 578648,
      "h": 8590513240,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590513240)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295545944),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 578648,
      "h": 4295545944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295545944)
  ],
  "h": 578648
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Authentication.Client.OAuth.Shared.GoogleLogin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Authentication${separator}Client${separator}OAuth${separator}Shared${separator}GoogleLogin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(578648)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(54360)
