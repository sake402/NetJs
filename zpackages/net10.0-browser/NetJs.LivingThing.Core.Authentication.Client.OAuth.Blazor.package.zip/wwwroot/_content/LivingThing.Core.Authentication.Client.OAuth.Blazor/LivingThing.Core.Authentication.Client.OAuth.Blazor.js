"use strict";
//// <reference path="../../../../Libraries/LivingThing.Frameworks/LivingThing.Core.Frameworks.Client.Blazor.Library/Components/Heading/Heading.razor.ts" />
Define("OAuth2", {
    _window: {},
    openWindow: function (options, component) {
        options.windowName = options.windowName || 'ConnectWithOAuth'; // should not include space for IE
        options.windowOptions = options.windowOptions || 'location=0,status=0,width=800,height=400';
        var that = this;
        console.log(options.path);
        this._window = window;
        this._window = window.open(options.path, options.windowName, options.windowOptions);
        that._oauthInterval = window.setInterval(function () {
            if (that._window?.closed) {
                window.clearInterval(that._oauthInterval);
                component.invokeMethodAsync("WindowClosed");
            }
        }, 1000);
    },
    closeWindow: function () {
        this._window.close();
    }
});
//# sourceMappingURL=LivingThing.Core.Authentication.Client.OAuth.Blazor.js.map