
//--TRIMMABLE-BOUNDARY-START(45757)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $sZVd, $wtdm, $lJUR, $dgLE) {
    "use strict";
    let _;
    let $nyHpNk;
    let $zpoOGd;
    let $TZrlYh;
    let $hlAQLh;
    let $rEcRGj;
    let $oAewLk;
    let $LvSHQd;
    let $IJNZbk;
    let $gDUKoj;
    let $oOhnpb;
    let $KLxUxb;
    let $AMghvc;
    let $SbZcOd;
    let $NMPxzj;
    let $NFPXVe;
    let $cyZSkl;
    let $BCUyfg;
    let $iuiade;
    let $ZSzXQf;
    let $wyravh;
    let $kclnnf;
    let $tTihQc;
    let $jCiSTk;
    let $Whibng;
    let $pgQUta;
    let $xwHzPe;
    let $mIJRle;
    let $IWRdZd;
    let $tJnvfg;
    let $FFvHQg;
    let $heTZRk;
    let $cohwTa;
    let $VmWfig;
    let $pcEFEj;
    let $YhITSh;
    let $nSSigb;
    let $XBTdme;
    let $LvYrQg;
    let $goobjd;
    let $tKjbEj;
    let $WHNSYj;
    let $ldwVhf;
    let $vvVQub;
    let $wOMdnh;
    let $QHTAXc;
    let $eMjybk;
    let $VdCopk;
    let $qnhphc;
    let $qMtBrj;
    let $tXDAUf;
    let $CLfqMh;
    let $ugcvrb;
    let $MPnGUi;
    let $JdWRib;
    let $nPheIg;
    let $SUqdih;
    let $bGCAdf;
    let $xLKbHi;
    let $kMulRb;
    let $ffzeJh;
    let $gGgvOa;
    let $HYNUWd;
    let $QQKuQc;
    let $YCEGJj;
    let $WlsXob;
    let $HlEWgf;
    let $novUSh;
    let $QkBKFa;
    let $UwTfUe;
    let $IVCLkg;
    let $ykkdfa;
    let $vHZfRe;
    let $cbIxkl;
    let $JueVUb;
    let $RqESFc;
    let $feoEvd;
    let $Qysbsa;
    let $GMNEJc;
    let $fbymrj;
    let $DznZWb;
    let $nFOqml;
    let $mKuSHh;
    let $Vqxwei;
    let $iIdPSd;
    let $MvCXsk;
    let $uqTuxc;
    let $izMBHi;
    let $Taksrg;
    let $AJmvOc;
    let $AjAOZj;
    let $ycaMsg;
    let $HfaKAc;
    let $fyCTkl;
    let $FIjuWf;
    let $hngaCe;
    let $jItdfi;
    let $hcGvhd;
    let $TpSBjf;
    let $Xptdyb;
    let $wLvTqc;
    let $RRcbXd;
    let $enlrsf;
    let $SWItIh;
    let $XjWUFe;
    let $RhtCDe;
    let $mJTXcf;
    let $jUYbof;
    let $uPSZzj;
    let $qQnEfj;
    let $TemKTc;
    let $dahFah;
    let $cNMsrb;
    let $bZrArk;
    let $NVIzQh;
    let $gldezi;
    let $zbItzi;
    let $ARoPcj;
    let $aIsGSe;
    let $CsXsYb;
    let $weHhkb;
    let $RGhTzg;
    let $GHMmQh;
    let $tgavRj;
    let $hfvxLg;
    let $FBbdCg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Bills.Client.Blazor", 
    {
  "h": 45757,
  "f": "LivingThing.Core.Bills.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Bills.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Bills.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(242365)
        $asm.$cls(`$cnlM.LCBC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295209661)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295209661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$cnlM.LCBC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295209661)
            
            static $h = 242365;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295209661),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 242365,
      "h": 4295209661,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295209661)
  ],
  "h": 242365
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(242365)
        
        

        //--TRIMMABLE-BOUNDARY-START(1225405)
        $asm.$cls(`$cnlM.LCBCS$1.WalletStat`, ($self) => class WalletStat extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81605604029)
            /*DateTime*/ Start;
            //--TRIMMABLE-BOUNDARY-END(81605604029)
            
            //--TRIMMABLE-BOUNDARY-START(51540832957)
            /*Money*/ Income;
            //--TRIMMABLE-BOUNDARY-END(51540832957)
            
            //--TRIMMABLE-BOUNDARY-START(21476061885)
            /*Money*/ Expense;
            //--TRIMMABLE-BOUNDARY-END(21476061885)
            
            //--TRIMMABLE-BOUNDARY-START(17181094589)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181094589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181094589)
            
            //--TRIMMABLE-BOUNDARY-START(17181094589)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181094589)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605604029)
                this.Start = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(81605604029)
                
                //--TRIMMABLE-BOUNDARY-START(51540832957)
                this.Income = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(51540832957)
                
                //--TRIMMABLE-BOUNDARY-START(21476061885)
                this.Expense = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(21476061885)
                
            }
            static $h = 1225405;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605604029),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245865661,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310636733,
        "f": 83886081
      },
      "n": "Start",
      "d": 1225405,
      "h": 81605604029,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605604029),
//--TRIMMABLE-BOUNDARY-START(51540832957),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655931069,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720702141,
        "f": 83886081
      },
      "n": "Income",
      "d": 1225405,
      "h": 51540832957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540832957),
//--TRIMMABLE-BOUNDARY-START(21476061885),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065996477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130767549,
        "f": 83886081
      },
      "n": "Expense",
      "d": 1225405,
      "h": 21476061885,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476061885)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181094589),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1225405,
      "h": 17181094589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181094589)
  ],
  "h": 1225405
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.WalletStat`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}WalletStat`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1225405)
        
        

        //--TRIMMABLE-BOUNDARY-START(111293)
        $asm.$cls(`$cnlM._LCBCSB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295078589)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295078589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Target", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "value-class", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295078589)
            
            static $h = 111293;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295078589),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 111293,
      "h": 4295078589,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295078589)
  ],
  "h": 111293
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Bills.Client.Shared.BillPayView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillPayView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(111293)
        
        

        //--TRIMMABLE-BOUNDARY-START(438973)
        $asm.$cls(`$cnlM.LCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590373565)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590373565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cnlM.LCBCS.BillService, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$cnlM.LCBCS.BillApplication, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$Iaui.LCFCM.PaymentModel, services, null);
                $.$cnlM.LCBC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590373565)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cnlM.LCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295406269)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295406269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295406269)
            
            //--TRIMMABLE-BOUNDARY-START(4295406269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295406269)
            
            static $h = 438973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590373565),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 438973,
      "h": 8590373565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590373565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295406269),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 438973,
      "h": 4295406269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295406269)
  ],
  "h": 438973
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(438973)
        
        

        //--TRIMMABLE-BOUNDARY-START(307901)
        $asm.$cls(`$cnlM.LCBC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180177085)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCP.BillApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCP.BillApp().$ctor$3();
                    }, $nyHpNk ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillChooseService.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillChooseService().$ctor$3();
                    }, $zpoOGd ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillChooseServiceTier.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillChooseServiceTier().$ctor$5();
                    }, $TZrlYh ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillHistory.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillHistory().$ctor$3();
                    }, $hlAQLh ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillHome.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillHome().$ctor$3();
                    }, $rEcRGj ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillPay.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillPay().$ctor$4();
                    }, $oAewLk ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillPayView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillPayView().$ctor$5();
                    }, $LvSHQd ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillStatistics.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillStatistics().$ctor$3();
                    }, $IJNZbk ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillTransactionDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillTransactionDetails().$ctor$4();
                    }, $gDUKoj ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$cnlM.LCBCS$1.BillTransactionListItem.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$cnlM.LCBCS$1.BillTransactionListItem().$ctor$5();
                    }, $oOhnpb ??= {"r":2752627,"n":"","d":307901,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180177085)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295275197)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295275197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295275197)
            
            //--TRIMMABLE-BOUNDARY-START(4295275197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295275197)
            
            static $h = 307901;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180177085),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885209789,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 307901,
      "h": 17180177085,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180177085)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295275197),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 307901,
      "h": 4295275197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295275197)
  ],
  "h": 307901
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(307901)
        
        

        //--TRIMMABLE-BOUNDARY-START(1290941)
        $asm.$cls(`$cnlM.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296258237)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296258237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296258237)
            
            //--TRIMMABLE-BOUNDARY-START(4296258237)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296258237)
            
            static $h = 1290941;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296258237),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1290941,
      "h": 4296258237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296258237)
  ],
  "h": 1290941
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1290941)
        
        

        //--TRIMMABLE-BOUNDARY-START(1356477)
        $asm.$cls(`$cnlM.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296323773)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296323773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296323773)
            
            //--TRIMMABLE-BOUNDARY-START(4296323773)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296323773)
            
            static $h = 1356477;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296323773),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1356477,
      "h": 4296323773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296323773)
  ],
  "h": 1356477,
  "a": [
    {
      "t": 1290941,
      "c": 4296258237
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1356477)
        
        

        //--TRIMMABLE-BOUNDARY-START(176829)
        $asm.$cls(`$cnlM.LCBC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590111421)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590111421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590111421)
            
            //--TRIMMABLE-BOUNDARY-START(4295144125)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295144125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295144125)
            
            //--TRIMMABLE-BOUNDARY-START(4295144125)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295144125)
            
            static $h = 176829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590111421),
    {
      "r": 65537,
      "n": "Execute",
      "d": 176829,
      "h": 8590111421,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590111421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295144125),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 176829,
      "h": 4295144125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295144125)
  ],
  "h": 176829
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(176829)
        
        

        //--TRIMMABLE-BOUNDARY-START(373437)
        $asm.$cls(`$cnlM.LCBCP.BillApp`, ($self) => class BillApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129915581)
            /*string */ get OptimizedComponentName()
            {
                return "billapp";
            }
            //--TRIMMABLE-BOUNDARY-END(60129915581)
            
            //--TRIMMABLE-BOUNDARY-START(55834948285)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834948285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.BillService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillService, serviceProvider);
                this.BillApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55834948285)
            
            //--TRIMMABLE-BOUNDARY-START(21475209917)
            /*BillService*/ BillService = null;
            //--TRIMMABLE-BOUNDARY-END(21475209917)
            
            //--TRIMMABLE-BOUNDARY-START(17180242621)
            /*BillApplication*/ BillApplication = null;
            //--TRIMMABLE-BOUNDARY-END(17180242621)
            
            //--TRIMMABLE-BOUNDARY-START(25770177213)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770177213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.BillService));
                __builder.AddComponentParameter(2, "Name", "Bill");
                __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(4, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(5, "CommunityLayout");
                        __builder2.AddAttribute$5(6, "PageContext", "wrap.Context");
                        __builder2.AddContent$1(7, wrap.View);
                        __builder2.CloseElement();
                    }, $LvYrQg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                }), $goobjd ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":373437,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(9, "CommunitySplashScreen");
                        __builder2.AddAttribute$5(10, "ViewModel", "splash.ViewModel");
                        __builder2.AddAttribute$5(11, "Message", splash.Message);
                        __builder2.CloseElement();
                    }, $tKjbEj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                }), $WHNSYj ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":373437,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "NotAuthorizedView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.IApplicationPageComponent))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(13, "CommunityAuthentication");
                        __builder2.AddAttribute$5(14, "Application", "BillApplication");
                        __builder2.CloseElement();
                    }, $ldwVhf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                }), $vvVQub ??= {"r":6881395,"p":[{"n":"context","p":4599881}],"n":"","d":373437,"h":0,"f":17825794}));
                __builder.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 16);
                    __builder2.AddComponentParameter(17, "Name", "");
                    __builder2.AddComponentParameter(18, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(19, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(20, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(21, "_ConfigureContext", "e=>e.Page.Workspace.Set(CommunityLayoutFeatures.Default&~CommunityLayoutFeatures.Pad)");
                    __builder2.AddAttribute$3(22, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(23, "Home");
                        }, $wOMdnh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $QHTAXc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillHome, 25);
                            __builder3.CloseComponent();
                        }, $eMjybk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $VdCopk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(26, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 27);
                    __builder2.AddComponentParameter(28, "Name", "Histories");
                    __builder2.AddComponentParameter(29, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(30, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(31, "Histories");
                        }, $qnhphc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $qMtBrj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(32, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillHistory, 33);
                            __builder3.CloseComponent();
                        }, $tXDAUf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $CLfqMh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(34, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 35);
                    __builder2.AddComponentParameter(36, "Name", "Statistics");
                    __builder2.AddComponentParameter(37, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(38, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(39, "Statistics");
                        }, $ugcvrb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $MPnGUi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(40, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillStatistics, 41);
                            __builder3.CloseComponent();
                        }, $JdWRib ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $nPheIg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(42, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 43);
                    __builder2.AddComponentParameter(44, "Name", "PayServices");
                    __builder2.AddComponentParameter(45, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | $.$lJUR.LCFCS.ApplicationUtility.GetPageAccessibility(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(46, "_ConfigureContext", "e=>e.Page.Workspace.Set(CommunityLayoutFeatures.Default&~CommunityLayoutFeatures.Pad)");
                    __builder2.AddAttribute$3(47, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(48, "Payments");
                        }, $SUqdih ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $bGCAdf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(49, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillChooseService, 50);
                            __builder3.CloseComponent();
                        }, $xLKbHi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $kMulRb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(51, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$xPgy.LCBCM.BillPaymentContext), 52);
                    __builder2.AddComponentParameter(53, "Name", "Pay");
                    __builder2.AddComponentParameter(54, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(55, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$4(56, "Make Payment");
                        }, $ffzeJh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $gGgvOa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(57, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(58, "<i class=\"mdi mdi-engine\"></i>");
                        }, $HYNUWd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $QQKuQc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(59, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillPay, 60);
                            __builder3.CloseComponent();
                        }, $YCEGJj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $WlsXob ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$xPgy.LCBCM.BillPaymentContext)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(61, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$Iaui.LCFCM.PaymentModel), 62);
                    __builder2.AddComponentParameter(63, "Name", "Transaction");
                    __builder2.AddComponentParameter(64, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(65, "_ConfigureContext", "e=>e.Page.Workspace.Set(CommunityLayoutFeatures.Default&~CommunityLayoutFeatures.Pad)");
                    __builder2.AddAttribute$3(66, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(67, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$Iaui.LCFCM.PaymentModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return $.$box(e.Amount, $.$$.S.Double);
                            }, $HlEWgf ??= {"r":131073,"p":[{"n":"e","p":12592470}],"n":"","d":373437,"h":0,"f":17825794}), true));
                        }, $novUSh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $QkBKFa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(68, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(69, "<i class=\"mdi mdi-wallet\"></i>");
                        }, $UwTfUe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $IVCLkg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(70, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillTransactionDetails, 71);
                            __builder3.CloseComponent();
                        }, $ykkdfa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":373437,"h":0,"f":17825794});
                    }), $vHZfRe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":373437,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $cbIxkl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":373437,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770177213)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885275325)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885275325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885275325)
            
            //--TRIMMABLE-BOUNDARY-START(12885275325)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885275325)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475209917)
                this.BillService = null;
                //--TRIMMABLE-BOUNDARY-END(21475209917)
                
                //--TRIMMABLE-BOUNDARY-START(17180242621)
                this.BillApplication = null;
                //--TRIMMABLE-BOUNDARY-END(17180242621)
                
            }
            static $h = 373437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129915581),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539980989,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 373437,
      "h": 60129915581,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60129915581),
//--TRIMMABLE-BOUNDARY-START(21475209917),
    {
      "p": 570045,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950046397,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309784765,
        "f": 83886081
      },
      "n": "BillService",
      "d": 373437,
      "h": 21475209917,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475209917),
//--TRIMMABLE-BOUNDARY-START(17180242621),
    {
      "p": 504509,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360111805,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719850173,
        "f": 83886081
      },
      "n": "BillApplication",
      "d": 373437,
      "h": 17180242621,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180242621)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834948285),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 373437,
      "h": 55834948285,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834948285),
//--TRIMMABLE-BOUNDARY-START(25770177213),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 373437,
      "h": 25770177213,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770177213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885275325),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 373437,
      "h": 12885275325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885275325)
  ],
  "h": 373437
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Pages.BillApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Pages${separator}BillApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(373437)
        
        

        //--TRIMMABLE-BOUNDARY-START(1028797)
        $asm.$cls(`$cnlM.LCBCS$1.BillStatistics`, ($self) => class BillStatistics extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25770832573)
            /*string */ get OptimizedComponentName()
            {
                return "billstatistics";
            }
            //--TRIMMABLE-BOUNDARY-END(25770832573)
            
            //--TRIMMABLE-BOUNDARY-START(30065799869)
            /*DateRange*/ range = 18;
            //--TRIMMABLE-BOUNDARY-END(30065799869)
            
            //--TRIMMABLE-BOUNDARY-START(34360767165)
            /*void */ SetRange(/*DateRange*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360767165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.range = range;
            }
            //--TRIMMABLE-BOUNDARY-END(34360767165)
            
            //--TRIMMABLE-BOUNDARY-START(21475865277)
            /*IEnumerable<WalletStat> */ GetStat(/*IEnumerable<PaymentModel>*/ transactions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475865277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.DataClassifier.ClassifyByInterval($.$Iaui.LCFCM.PaymentModel, $.$cnlM.LCBCS$1.WalletStat, transactions, $.$$.S.DateTime.MinValue, $.$$.S.DateTime.MaxValue, 8/*PeriodicInterval.Monthly*/, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime))))().$ctor(this,  (/*t*/ t) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)))().$ctor$3($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(t.DateCreated), null);
                }, $uqTuxc ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.DateTime, $.$$.S.Nullable$$($.$$.S.DateTime)).$h,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}), new ($.$$.S.Func$$$$$($.$$.S.DateTime, $.$$.S.DateTime, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), $.$cnlM.LCBCS$1.WalletStat))().$ctor(this,  (/*s*/ s, /*e*/ e, /*ts*/ ts) =>
                {
                    return (() =>
                    {
                        //new $.$cnlM.LCBCS$1.WalletStat()
                        const $t1 = $.$cnlM.LCBCS$1.WalletStat;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Start = s;
                        $i1.Income = (() =>
                        {
                            //new $.$fPer.LCFCDM.Money()
                            const $t2 = $.$fPer.LCFCDM.Money;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Value = $.$sl.SL.Enumerable.Sum$16($.$Iaui.LCFCM.PaymentModel, $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, ts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Amount >= 0;
                            }, $izMBHi ??= {"r":262145,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Amount;
                            }, $Taksrg ??= {"r":1179649,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                            return $i2;
                        })();
                        $i1.Expense = (() =>
                        {
                            //new $.$fPer.LCFCDM.Money()
                            const $t3 = $.$fPer.LCFCDM.Money;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.Value = $.$sl.SL.Enumerable.Sum$16($.$Iaui.LCFCM.PaymentModel, $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, ts, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Amount < 0;
                            }, $AJmvOc ??= {"r":262145,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                            {
                                return t.Amount;
                            }, $AjAOZj ??= {"r":1179649,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                            return $i3;
                        })();
                        return $i1;
                    })();
                }, $ycaMsg ??= {"r":1225405,"p":[{"n":"s","p":65994753},{"n":"e","p":65994753},{"n":"ts","p":$.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(21475865277)
            
            //--TRIMMABLE-BOUNDARY-START(8590963389)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590963389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "CommunityLayoutConfigure");
                __builder.AddAttribute$5(1, "Features", "CommunityLayoutFeatures.Default&~CommunityLayoutFeatures.Pad");
                __builder.CloseElement();
                __builder.AddMarkupContent(2, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.PaymentModel), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)), 3);
                __builder.AddComponentParameter(4, "IServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.PaymentModel), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/**/ s) =>
                {
                    return s.LCFCD$IReadManyDataService$LivingThing$Core$Frameworks$Common$Models$PaymentModel$ReadMany(new $.$fPer.LCFCD.DataFilter().$ctor$1(), null).ContinueWith$47($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.PaymentModel)), $.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Result;
                    }, $HfaKAc ??= {"r":$.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)).$h,"p":[{"n":"t","p":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                }), $fyCTkl ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.IWireTransportModel$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))).$h,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Iaui.LCFCM.PaymentModel).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/*transactions*/ transactions) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let incomes = $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, transactions.Model, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Amount >= 0;
                        }, $FIjuWf ??= {"r":262145,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                        /*var*/ let expenses = $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.PaymentModel, transactions.Model, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return t.Amount < 0;
                        }, $hngaCe ??= {"r":262145,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                        /*var*/ let totalIncome = (() =>
                        {
                            //new $.$fPer.LCFCDM.Money()
                            const $t4 = $.$fPer.LCFCDM.Money;
                            const $i4 = new $t4();
                            $i4.$ctor$2();
                            $i4.Value = $.$sl.SL.Enumerable.Sum$16($.$Iaui.LCFCM.PaymentModel, incomes, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Double))().$ctor(this,  (/**/ t) =>
                            {
                                return t.Amount;
                            }, $jItdfi ??= {"r":1179649,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                            return $i4;
                        })();
                        /*var*/ let totalExpense = (() =>
                        {
                            //new $.$fPer.LCFCDM.Money()
                            const $t5 = $.$fPer.LCFCDM.Money;
                            const $i5 = new $t5();
                            $i5.$ctor$2();
                            $i5.Value = $.$sl.SL.Enumerable.Sum$16($.$Iaui.LCFCM.PaymentModel, expenses, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.S.Double))().$ctor(this,  (/**/ t) =>
                            {
                                return t.Amount;
                            }, $hcGvhd ??= {"r":1179649,"p":[{"n":"t","p":12592470}],"n":"","d":1028797,"h":0,"f":17825794}));
                            return $i5;
                        })();
                        __builder2.OpenElement(6, "div");
                        __builder2.AddAttribute$5(7, "class", "pd");
                        __builder2.OpenElement(8, "div");
                        __builder2.AddAttribute$5(9, "class", "flex flex-spacebetween-x");
                        for(/*int*/ let i = 0; i < 2; i++)
                        {
                            __builder2.OpenElement(10, "div");
                            __builder2.AddAttribute$5(11, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("shadow" + " stack") + " bg-tb-") + $.$strNN((i === 0 ? "secondary-primary" : "error-fatal"))) + " corner-3") + " pd") + " miwx-15") + " mihx-1");
                            __builder2.AddMarkupContent(12, "<div><div class=\"hx-03 wx-03 bg-white-03 round mdi mdi-arrow-down mgc-a flex\"></div></div>\r\n                    ");
                            __builder2.OpenElement(13, "h3");
                            __builder2.AddAttribute$5(14, "class", "op-8 mgb-0");
                            __builder2.AddContent$4(15, i === 0 ? "Income" : "Expenses");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(16, "\r\n                    ");
                            __builder2.OpenElement(17, "h2");
                            __builder2.AddAttribute$5(18, "class", "op-8 mgt-1");
                            __builder2.AddContent$3(19, i === 0 ? totalIncome : totalExpense);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        if ($.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.PaymentModel, transactions.Model))
                        {
                            /*var*/ let stats = this.GetStat(transactions.Model);
                            __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 20);
                            __builder2.AddAttribute$3(21, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$cnlM.LCBCS$1.WalletStat), 22);
                                    __builder3.AddComponentParameter(23, "Class", "mgt");
                                    __builder3.AddComponentParameter(24, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$cnlM.LCBCS$1.WalletStat), stats));
                                    __builder3.AddComponentParameter(25, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                                    __builder3.AddComponentParameter(26, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$cnlM.LCBCS$1.WalletStat, $.$$.S.String))().$ctor(this, ( (/*x*/ x, /*i*/ i) =>
                                    {
                                        return i.Start.ToString$3("MMM");
                                    }), $TpSBjf ??= {"r":1310721,"p":[{"n":"x","p":655361},{"n":"i","p":1225405}],"n":"","d":1028797,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(27, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                                    __builder3.AddComponentParameter(28, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                    __builder3.AddComponentParameter(29, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Model.TextBackgroundColor));
                                    __builder3.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cnlM.LCBCS$1.WalletStat, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cnlM.LCBCS$1.WalletStat))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$cnlM.LCBCS$1.WalletStat), 31);
                                            __builder4.AddComponentParameter(32, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cnlM.LCBCS$1.WalletStat))().$ctor(this, ( (/*x*/ x) =>
                                            {
                                                return $.$box(x.LCFCCD$1$IDataListItemContext$$$Data.Income.Value, $.$$.S.Double);
                                            }), $Xptdyb ??= {"r":131073,"p":[{"n":"x","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cnlM.LCBCS$1.WalletStat).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                                            __builder4.AddComponentParameter(33, "Label", "Income");
                                            __builder4.AddComponentParameter(34, "BackgroundColor", "#00AEFF");
                                            __builder4.CloseComponent();
                                            __builder4.AddMarkupContent(35, "\r\n                    ");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$cnlM.LCBCS$1.WalletStat), 36);
                                            __builder4.AddComponentParameter(37, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$cnlM.LCBCS$1.WalletStat))().$ctor(this, ( (/*x*/ x) =>
                                            {
                                                return $.$box(x.LCFCCD$1$IDataListItemContext$$$Data.Expense.Value, $.$$.S.Double);
                                            }), $wLvTqc ??= {"r":131073,"p":[{"n":"x","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$cnlM.LCBCS$1.WalletStat).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                                            __builder4.AddComponentParameter(38, "Label", "Expenses");
                                            __builder4.AddComponentParameter(39, "BackgroundColor", "#FCAC00");
                                            __builder4.CloseComponent();
                                        }, $RRcbXd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1028797,"h":0,"f":17825794});
                                    }), $enlrsf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$cnlM.LCBCS$1.WalletStat, $.$hDPm.LCFCCC$3.ChartYAxis$$($.$cnlM.LCBCS$1.WalletStat)).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $SWItIh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1028797,"h":0,"f":17825794});
                            }), $XjWUFe ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(40, "\r\n            ");
                            __builder2.OpenElement(41, "div");
                            __builder2.AddAttribute$5(42, "class", "row mgt-10 bg-tb-fatal-error pd corner-5");
                            __builder2.OpenElement(43, "div");
                            __builder2.AddAttribute$5(44, "class", "col-a");
                            __builder2.OpenElement(45, "div");
                            __builder2.AddAttribute$5(46, "class", "bg-white-03 hx-07 wx-07 corner-2 pd-2");
                            /*var*/ let builder = $.$hDPm.LCFCCSF.SVGBuilder.Create(50, 50, 0/*DimensionUnit.None*/, true, 0, 0);
                            $.$hDPm.LCFCCSWD.DoughnutExtension.Doughnut(builder, (() =>
                            {
                                //new $.$hDPm.LCFCCSWD.DoughnutModel()
                                const $t6 = $.$hDPm.LCFCCSWD.DoughnutModel;
                                const $i6 = new $t6();
                                $i6.$ctor$1();
                                $i6.Size = 50;
                                $i6.BackgroundColor = "#FFFFFF20";
                                $i6.Sections = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCCSWD.DoughnutSection), [(() =>
                                {
                                    //new $.$hDPm.LCFCCSWD.DoughnutSection()
                                    const $t7 = $.$hDPm.LCFCCSWD.DoughnutSection;
                                    const $i7 = new $t7();
                                    $i7.$ctor$1();
                                    $i7.Proportion = 0.8;
                                    $i7.Color = "#FFFFFF";
                                    return $i7;
                                })()], [-1], null);
                                return $i6;
                            })());
                            builder.LCFCCSF$ISVGBuilder$MoveTo(0.5, 0.5).LCFCCSF$ISVGTextBuilder$Text("50%").LCFCCSF$ISVGBuilder$TextAnchor(2/*TextAnchor.Middle*/).LCFCCSF$ISVGBuilder$BaseLine(4/*BaseLine.Middle*/).LCFCCSF$ISVGBuilder$FillColor("#FFF").LCFCCSF$ISVGBuilder$StrokeColor("#FFF");
                            __builder2.AddContent$1(47, builder.LCFCCSF$ISVGBuilder$Build());
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(48, "\r\n                ");
                            __builder2.AddMarkupContent(49, "<div class=\"col-10 mgl stack\"><h3 class=\"mgb-1 mgt-a\">Low income this month</h3>\r\n                    <p class=\"mgt-0 mgb-a op-9\">Your income this month drops by 50%, expenses is up by 10%</p></div>\r\n                ");
                            __builder2.AddMarkupContent(50, "<div class=\"col-a stack mgl\"><i class=\"mgy-a mdi mdi-chevron-right fsz-25\"></i></div>");
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 51);
                            __builder2.AddComponentParameter(52, "Message", "Your monthly transaction trend will appear here");
                            __builder2.CloseComponent();
                        }
                        __builder2.CloseElement();
                    }, $RhtCDe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1028797,"h":0,"f":17825794});
                }), $mJTXcf ??= {"r":6881395,"p":[{"n":"transactions","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":1028797,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590963389)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295996093)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295996093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295996093)
            
            //--TRIMMABLE-BOUNDARY-START(4295996093)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295996093)
            
            static $h = 1028797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770832573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180897981,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1028797,
      "h": 25770832573,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770832573)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360767165),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 6130006
        }
      ],
      "n": "SetRange",
      "d": 1028797,
      "h": 34360767165,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360767165),
//--TRIMMABLE-BOUNDARY-START(21475865277),
    {
      "r": $.$$.SCG.IEnumerable$$($.$cnlM.LCBCS$1.WalletStat).$h,
      "p": [
        {
          "n": "transactions",
          "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel).$h
        }
      ],
      "n": "GetStat",
      "d": 1028797,
      "h": 21475865277,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475865277),
//--TRIMMABLE-BOUNDARY-START(8590963389),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1028797,
      "h": 8590963389,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590963389)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065799869),
    {
      "t": 6130006,
      "n": "range",
      "d": 1028797,
      "h": 30065799869,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065799869)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295996093),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1028797,
      "h": 4295996093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295996093)
  ],
  "h": 1028797
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillStatistics`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1028797)
        
        

        //--TRIMMABLE-BOUNDARY-START(832189)
        $asm.$cls(`$cnlM.LCBCS$1.BillHome`, ($self) => class BillHome extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(124554883773)
            /*string */ get OptimizedComponentName()
            {
                return "billhome";
            }
            //--TRIMMABLE-BOUNDARY-END(124554883773)
            
            //--TRIMMABLE-BOUNDARY-START(184684425917)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684425917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "App":
                    this.App = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                    case "Header":
                    this.Header = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "Commands":
                    this.Commands = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(184684425917)
            
            //--TRIMMABLE-BOUNDARY-START(115964949181)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964949181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillService, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(115964949181)
            
            //--TRIMMABLE-BOUNDARY-START(38655537853)
            /*BillApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(38655537853)
            
            //--TRIMMABLE-BOUNDARY-START(128849851069)
            /*BillService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(128849851069)
            
            //--TRIMMABLE-BOUNDARY-START(188979393213)
            /*IUIService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(188979393213)
            
            //--TRIMMABLE-BOUNDARY-START(34360570557)
            /*Application*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(34360570557)
            
            //--TRIMMABLE-BOUNDARY-START(111669981885)
            /*RenderFragment?*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(111669981885)
            
            //--TRIMMABLE-BOUNDARY-START(47245472445)
            /*RenderFragment?*/ Commands = null;
            //--TRIMMABLE-BOUNDARY-END(47245472445)
            
            //--TRIMMABLE-BOUNDARY-START(120259916477)
            /*ValueTask */ OpenSideBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259916477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.App.LeftSideBar?.Open() ?? null) ?? $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(120259916477)
            
            //--TRIMMABLE-BOUNDARY-START(42950505149)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950505149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "stack hf");
                __builder.OpenElement(2, "div");
                __builder.AddMultipleAttributes(3, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass(this.Application.Theme.ToHtmlAttributes("bg-"), "pdt-7 pdx-7 pdb-30"))));
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "row pos-rel");
                __builder.OpenElement(6, "div");
                __builder.AddAttribute$5(7, "class", "col-a stack mgr");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 8);
                __builder.AddComponentParameter(9, "Class", "mgy-a mdi mdi-menu fsz-20");
                __builder.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(11, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, $.$hDPm.LCFCC$1.BaseComponent.NoStateChanged$2(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.OpenSideBar)))));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n            ");
                __builder.OpenElement(13, "div");
                __builder.AddAttribute$5(14, "class", "col-a mgr");
                __builder.OpenElement(15, "CommunityUserAvatar");
                __builder.AddAttribute$5(16, "Size", "40");
                __builder.AddAttribute$5(17, "lass", "hx-06 wx-06 bd round");
                __builder.AddAttribute$5(18, "ViewModel", "Service.CommunityService.Account");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(19, "\r\n            ");
                __builder.AddMarkupContent(20, "<div class=\"col-10 stack mgl\"><h4 class=\"mgt-a mgb-0 op-8\">Hello</h4></div>\r\n            ");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "col-a");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 23);
                __builder.AddComponentParameter(24, "Class", "mdi mdi-bell fsz-20");
                __builder.AddComponentParameter(25, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(26, "\r\n        ");
                __builder.AddContent$1(27, this.Header);
                __builder.AddMarkupContent(28, "\r\n        ");
                __builder.OpenElement(29, "div");
                __builder.AddAttribute$5(30, "class", "mgt-10 flex flex-spacebetween-x pos-rel");
                __builder.AddContent$1(31, this.Commands);
                __builder.AddMarkupContent(32, "\r\n            ");
                __builder.AddMarkupContent(33, "<div class=\"stack text-center\"><a class=\"mgx-a hx-05 wx-05 mdi mdi-plus fsz-25 bg-transparent corner-3 pd\" Features=\"ButtonFeatures.Flat\" href=\"Bill/PayServices\"></a>\r\n                <span class=\"mg-1 text-center\">TopUp</span></div>\r\n            ");
                __builder.AddMarkupContent(34, "<div class=\"stack text-center\"><a class=\"mgx-a hx-05 wx-05 mdi mdi-chart-line fsz-25 bg-transparent corner-3 pd\" href=\"Bill/Histories\"></a>\r\n                <span class=\"mg-1 text-center\">Histories</span></div>\r\n            ");
                __builder.OpenElement(35, "div");
                __builder.AddAttribute$5(36, "class", "stack");
                __builder.OpenElement(37, "popup");
                __builder.AddAttribute$5(38, "tabindex", "-1");
                __builder.AddMarkupContent(39, "<button Class=\"mgx-a hx-05 wx-05 mdi mdi-dots-horizontal fsz-25 bg-transparent corner-3 pd\"></button>\r\n                    ");
                __builder.OpenElement(40, "pop");
                __builder.AddAttribute$5(41, "class", "at righttoright toptobottom bg-card cl-text wf shadow corner-b");
                __builder.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 42);
                __builder.AddComponentParameter(43, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575138/*MenuFeatures.DefaultVH*/ | 8/*MenuFeatures.Selectable*/ | 2097152/*MenuFeatures.Pad*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                __builder.AddAttribute$3(44, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 45);
                        __builder2.AddComponentParameter(46, "PageLink", "Statistics");
                        __builder2.AddAttribute$3(47, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(48, "<i class=\"mdi mdi-plus\"></i>");
                            }, $tJnvfg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":832189,"h":0,"f":17825794});
                        }), $FFvHQg ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":832189,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(49, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(50, "\r\n                                    Statistics\r\n                                ");
                            }, $heTZRk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":832189,"h":0,"f":17825794});
                        }), $cohwTa ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":832189,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $VmWfig ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":832189,"h":0,"f":17825794});
                }), $pcEFEj ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":832189,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(51, "\r\n                ");
                __builder.AddMarkupContent(52, "<span class=\"mg-1 text-center\">More</span>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(53, "\r\n    ");
                __builder.OpenElement(54, "div");
                __builder.AddAttribute$5(55, "class", "fill bg-card mgt--20 shadow pdt-10 pdx corner-t-7 scroll");
                __builder.AddMarkupContent(56, "<h3 class=\"mgt-0\">Recent Transactions</h3>\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.PaymentModel), 57);
                __builder.AddComponentParameter(58, "li-class", "pdy-3");
                __builder.AddComponentParameter(59, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$1()));
                __builder.AddAttribute$3(60, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/*data*/ data) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$cnlM.LCBCS$1.BillTransactionListItem, 61);
                        __builder2.AddComponentParameter(62, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel)).op_Implicit$1(data)));
                        __builder2.CloseComponent();
                    }, $YhITSh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":832189,"h":0,"f":17825794});
                }), $nSSigb ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":832189,"h":0,"f":17825794}));
                __builder.AddAttribute$3(63, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 64);
                    __builder2.AddComponentParameter(65, "Message", "Your recent transacctions will appear here");
                    __builder2.CloseComponent();
                }), $XBTdme ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":832189,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(42950505149)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(30065603261)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065603261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065603261)
            
            //--TRIMMABLE-BOUNDARY-START(30065603261)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30065603261)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655537853)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(38655537853)
                
                //--TRIMMABLE-BOUNDARY-START(128849851069)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(128849851069)
                
                //--TRIMMABLE-BOUNDARY-START(188979393213)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(188979393213)
                
            }
            static $h = 832189;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554883773),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195145405,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 832189,
      "h": 124554883773,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554883773),
//--TRIMMABLE-BOUNDARY-START(38655537853),
    {
      "p": 504509,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425341629,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029720253,
        "f": 83886081
      },
      "n": "Application",
      "d": 832189,
      "h": 38655537853,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655537853),
//--TRIMMABLE-BOUNDARY-START(128849851069),
    {
      "p": 570045,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785079997,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799524029,
        "f": 83886081
      },
      "n": "Service",
      "d": 832189,
      "h": 128849851069,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849851069),
//--TRIMMABLE-BOUNDARY-START(188979393213),
    {
      "p": 5594536,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375014589,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389458621,
        "f": 83886081
      },
      "n": "UI",
      "d": 832189,
      "h": 188979393213,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979393213),
//--TRIMMABLE-BOUNDARY-START(34360570557),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835407037,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439785661,
        "f": 83886081
      },
      "n": "App",
      "d": 832189,
      "h": 34360570557,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360570557),
//--TRIMMABLE-BOUNDARY-START(111669981885),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605210813,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209589437,
        "f": 83886081
      },
      "n": "Header",
      "d": 832189,
      "h": 111669981885,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669981885),
//--TRIMMABLE-BOUNDARY-START(47245472445),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015276221,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619654845,
        "f": 83886081
      },
      "n": "Commands",
      "d": 832189,
      "h": 47245472445,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245472445)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(184684425917),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 832189,
      "h": 184684425917,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684425917),
//--TRIMMABLE-BOUNDARY-START(115964949181),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 832189,
      "h": 115964949181,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964949181),
//--TRIMMABLE-BOUNDARY-START(120259916477),
    {
      "r": 181338113,
      "n": "OpenSideBar",
      "d": 832189,
      "h": 120259916477,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259916477),
//--TRIMMABLE-BOUNDARY-START(42950505149),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 832189,
      "h": 42950505149,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950505149)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065603261),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 832189,
      "h": 30065603261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065603261)
  ],
  "h": 832189
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(832189)
        
        

        //--TRIMMABLE-BOUNDARY-START(766653)
        $asm.$cls(`$cnlM.LCBCS$1.BillHistory`, ($self) => class BillHistory extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(25770570429)
            /*DateRange*/ range = 18;
            //--TRIMMABLE-BOUNDARY-END(25770570429)
            
            //--TRIMMABLE-BOUNDARY-START(30065537725)
            /*void */ SetRange(/*DateRange*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065537725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.range = range;
            }
            //--TRIMMABLE-BOUNDARY-END(30065537725)
            
            //--TRIMMABLE-BOUNDARY-START(21475603133)
            /*string */ get OptimizedComponentName()
            {
                return "billhistory";
            }
            //--TRIMMABLE-BOUNDARY-END(21475603133)
            
            //--TRIMMABLE-BOUNDARY-START(8590701245)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590701245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "row mgb-10");
                __builder.AddMarkupContent(2, "<div class=\"col-10\"><h3 class=\"mg-0\">Category</h3></div>\r\n    ");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "col-a");
                __builder.OpenElement(5, "popup");
                __builder.AddAttribute$5(6, "class", "pos-rel");
                __builder.OpenElement(7, "span");
                __builder.AddAttribute$5(8, "class", "nowrap");
                __builder.OpenElement(9, "span");
                __builder.AddAttribute$5(10, "class", "mgr-1 cl-primary");
                __builder.AddContent$4(11, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$fPer.LCFCDC.DateRange, $.$$.S.UInt32, this.range)));
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n                <i class=\"mdi mdi-chevron-down cl-primary\"></i>");
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n            ");
                __builder.OpenElement(14, "pop");
                __builder.AddAttribute$5(15, "class", "at toptobottom righttoright bg-card shadow pd corner-b");
                __builder.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 16);
                __builder.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575138/*MenuFeatures.DefaultVH*/ | 2097152/*MenuFeatures.Pad*/ | 8/*MenuFeatures.Selectable*/ | 16/*MenuFeatures.Bordered*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                __builder.AddAttribute$3(18, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        let $en1 = $.$sl.SL.Enumerable.Except$1($.$fPer.LCFCDC.DateRange, $.$$.S.Enum.GetValues$1($.$fPer.LCFCDC.DateRange), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCDC.DateRange), [1/*DateRange.Custom*/], null, null)).SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let range = $en1.SCG$IEnumerator$$$Current;
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuCommandItem$$($.$fPer.LCFCDC.DateRange), 19);
                                __builder2.AddComponentParameter(20, "CommandParameter", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDC.DateRange, range), $.$fPer.LCFCDC.DateRange));
                                __builder2.AddComponentParameter(21, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCDC.DateRange), $.$mac.MAC.EventCallback.Factory.Create$8($.$fPer.LCFCDC.DateRange, this, new ($.$$.S.Action$$($.$fPer.LCFCDC.DateRange))().$ctor(this, this.SetRange))));
                                __builder2.AddComponentParameter(22, "Class", "nowrap");
                                __builder2.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.AddContent$4(24, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$fPer.LCFCDC.DateRange, $.$$.S.UInt32, range)));
                                    }, $JueVUb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":766653,"h":0,"f":17825794});
                                }), $RqESFc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":766653,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }
                    }, $feoEvd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":766653,"h":0,"f":17825794});
                }), $Qysbsa ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":766653,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(25, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 26);
                __builder.AddComponentParameter(27, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddAttribute$3(28, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    let $en2 = $.$sl.SL.Enumerable.Except$1($.$nYKj.LCFCP.PaymentCategoryType, $.$$.S.Enum.GetValues$1($.$nYKj.LCFCP.PaymentCategoryType), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$nYKj.LCFCP.PaymentCategoryType), [0/*PaymentCategoryType.None*/], null, null)).SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let _type = $en2.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let type = _type;
                            /*var*/ let schema = $.$fPer.LCFCT.EnumExtensions.GetEnumAttribute($.$fPer.LCFCA$1.SchemaAttribute, $.$box(type, $.$nYKj.LCFCP.PaymentCategoryType));
                            /*var*/ let icon = $.$fPer.LCFCA$1.SchemaAttibutesExtension.GetIcon(schema);
                            __builder2.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 29);
                            __builder2.AddComponentParameter(30, "Class", "mgb-10 bg-card pd corner-3 shadow-5");
                            __builder2.AddAttribute$3(31, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*selected*/ selected) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(32, "div");
                                    __builder3.AddAttribute$5(33, "class", "row");
                                    __builder3.OpenElement(34, "div");
                                    __builder3.AddAttribute$5(35, "class", "col-a");
                                    __builder3.OpenElement(36, "div");
                                    __builder3.AddAttribute$5(37, "class", "hx-05 wx-05 round flex");
                                    __builder3.AddAttribute$5(38, "style", $.$strNN($.$strNN("background-color:" + $.$strNN((icon.Theme.BackgroundColor))) + ";color:") + $.$strNN((icon.Theme.ForegroundColor)));
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCI.Icon, 39);
                                    __builder3.AddComponentParameter(40, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$clone(icon)));
                                    __builder3.AddComponentParameter(41, "Class", "fsz-25 mg-a");
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(42, "\r\n                    ");
                                    __builder3.OpenElement(43, "div");
                                    __builder3.AddAttribute$5(44, "class", "col-10 mgl stack");
                                    __builder3.OpenElement(45, "div");
                                    __builder3.AddAttribute$5(46, "class", "mgt-a");
                                    __builder3.OpenElement(47, "h3");
                                    __builder3.AddAttribute$5(48, "class", "mg-0");
                                    __builder3.AddContent$4(49, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$nYKj.LCFCP.PaymentCategoryType, $.$$.S.UInt32, type)));
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(50, "\r\n                            ");
                                    __builder3.OpenElement(51, "p");
                                    __builder3.AddAttribute$5(52, "class", "mgb-0");
                                    __builder3.AddContent$4(53, (schema?.Description ?? null));
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(54, "\r\n                    ");
                                    __builder3.OpenElement(55, "div");
                                    __builder3.AddAttribute$5(56, "class", "col-a stack");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 57);
                                    __builder3.AddComponentParameter(58, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(59, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, ` mdi mdi-chevron-${$.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(selected) ? "up" : "down"))} fsz-20 mgy-a`));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }, $GMNEJc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":766653,"h":0,"f":17825794});
                            }), $fbymrj ??= {"r":6881395,"p":[{"n":"selected","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":766653,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(60, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Iaui.LCFCM.PaymentModel), 61);
                                    __builder3.AddComponentParameter(62, "li-class", "pdy-3");
                                    __builder3.AddComponentParameter(63, "Class", "bdt mgt pdt");
                                    __builder3.AddComponentParameter(64, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 536870912n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder3.AddComponentParameter(65, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                                    __builder3.AddComponentParameter(66, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(new $.$fPer.LCFCD.DataId().$ctor$3(null, $.$nYKj.LCFCP.PaymentCategoryType.$type.FullName), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(type, $.$nYKj.LCFCP.PaymentCategoryType) ], null, null))));
                                    __builder3.AddAttribute$3(67, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel))))().$ctor(this, ( (/*data*/ data) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$cnlM.LCBCS$1.BillTransactionListItem, 68);
                                            __builder4.AddComponentParameter(69, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel)).op_Implicit$1(data)));
                                            __builder4.CloseComponent();
                                        }, $DznZWb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":766653,"h":0,"f":17825794});
                                    }), $nFOqml ??= {"r":6881395,"p":[{"n":"data","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.PaymentModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.PaymentModel)).$h}],"n":"","d":766653,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(70, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 71);
                                        __builder4.AddComponentParameter(72, "Message", "Nothing here");
                                        __builder4.CloseComponent();
                                    }), $mKuSHh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":766653,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $Vqxwei ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":766653,"h":0,"f":17825794});
                            }), $iIdPSd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":766653,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }
                }), $MvCXsk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":766653,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590701245)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295733949)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295733949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295733949)
            
            //--TRIMMABLE-BOUNDARY-START(4295733949)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295733949)
            
            static $h = 766653;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475603133),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180635837,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 766653,
      "h": 21475603133,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475603133)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065537725),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 6130006
        }
      ],
      "n": "SetRange",
      "d": 766653,
      "h": 30065537725,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065537725),
//--TRIMMABLE-BOUNDARY-START(8590701245),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 766653,
      "h": 8590701245,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590701245)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770570429),
    {
      "t": 6130006,
      "n": "range",
      "d": 766653,
      "h": 25770570429,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770570429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295733949),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 766653,
      "h": 4295733949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295733949)
  ],
  "h": 766653
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillHistory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillHistory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(766653)
        
        

        //--TRIMMABLE-BOUNDARY-START(504509)
        $asm.$cls(`$cnlM.LCBCS.BillApplication`, ($self) => class BillApplication extends $.$sZVd.LCFCA.BaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885406397)
            $ctor$3(/*BillService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885406397);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885406397)
            
            //--TRIMMABLE-BOUNDARY-START(124554556093)
            /*string */ get Name()
            {
                return "Bill";
            }
            //--TRIMMABLE-BOUNDARY-END(124554556093)
            
            //--TRIMMABLE-BOUNDARY-START(146029392573)
            /*string */ get Title()
            {
                return "Bills";
            }
            //--TRIMMABLE-BOUNDARY-END(146029392573)
            
            //--TRIMMABLE-BOUNDARY-START(21475340989)
            /*string */ get Description()
            {
                return "Pay for bills and services; VTU, Electricity Tariffs";
            }
            //--TRIMMABLE-BOUNDARY-END(21475340989)
            
            //--TRIMMABLE-BOUNDARY-START(120259588797)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-contactless-payment"/*MaterialDesignIconNames.ContactlessPayment*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120259588797)
            
            //--TRIMMABLE-BOUNDARY-START(141734425277)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#6E9B26";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141734425277)
            
            //--TRIMMABLE-BOUNDARY-START(30065275581)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065275581)
            
            //--TRIMMABLE-BOUNDARY-START(17180373693)
            /*Type? */ get ApplicationViewType()
            {
                return $.$cnlM.LCBCP.BillApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180373693)
            
            //--TRIMMABLE-BOUNDARY-START(25770308285)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770308285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770308285)
            
            //--TRIMMABLE-BOUNDARY-START(133144490685)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144490685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(133144490685)
            
            //--TRIMMABLE-BOUNDARY-START(128849523389)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(128849523389)
            
            //--TRIMMABLE-BOUNDARY-START(4295471805)
            /*BillService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295471805)
            
            //--TRIMMABLE-BOUNDARY-START(137439457981)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(137439457981)
            
            static $h = 504509;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.BaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554556093),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604883133,
        "f": 50364417
      },
      "n": "Name",
      "d": 504509,
      "h": 124554556093,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554556093),
//--TRIMMABLE-BOUNDARY-START(146029392573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964621501,
        "f": 50364417
      },
      "n": "Title",
      "d": 504509,
      "h": 146029392573,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029392573),
//--TRIMMABLE-BOUNDARY-START(21475340989),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835079357,
        "f": 50364417
      },
      "n": "Description",
      "d": 504509,
      "h": 21475340989,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475340989),
//--TRIMMABLE-BOUNDARY-START(120259588797),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014948541,
        "f": 50364417
      },
      "n": "Icon",
      "d": 504509,
      "h": 120259588797,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259588797),
//--TRIMMABLE-BOUNDARY-START(141734425277),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374686909,
        "f": 50364417
      },
      "n": "Theme",
      "d": 504509,
      "h": 141734425277,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734425277),
//--TRIMMABLE-BOUNDARY-START(30065275581),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425013949,
        "f": 50364417
      },
      "n": "Features",
      "d": 504509,
      "h": 30065275581,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065275581),
//--TRIMMABLE-BOUNDARY-START(17180373693),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245144765,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 504509,
      "h": 17180373693,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180373693),
//--TRIMMABLE-BOUNDARY-START(128849523389),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194817725,
        "f": 50364417
      },
      "n": "Order",
      "d": 504509,
      "h": 128849523389,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849523389),
//--TRIMMABLE-BOUNDARY-START(4295471805),
    {
      "p": 570045,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655210173,
        "f": 50331650
      },
      "n": "_Service",
      "d": 504509,
      "h": 4295471805,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295471805),
//--TRIMMABLE-BOUNDARY-START(137439457981),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784752317,
        "f": 50364417
      },
      "n": "Service",
      "d": 504509,
      "h": 137439457981,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439457981)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770308285),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 504509,
      "h": 25770308285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770308285),
//--TRIMMABLE-BOUNDARY-START(133144490685),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 504509,
      "h": 133144490685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144490685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885406397),
    {
      "p": [
        {
          "n": "service",
          "p": 570045
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 504509,
      "h": 12885406397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885406397)
  ],
  "h": 504509
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationClient, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Services.BillApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Services${separator}BillApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(504509)
        
        

        //--TRIMMABLE-BOUNDARY-START(635581)
        $asm.$cls(`$cnlM.LCBCS$1.BillChooseService`, ($self) => class BillChooseService extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(47245275837)
            /*IEnumerable<IPaymentTierProvider>*/ PaymentTiers = null;
            //--TRIMMABLE-BOUNDARY-END(47245275837)
            
            //--TRIMMABLE-BOUNDARY-START(64425145021)
            /*WizardSteps?*/ wizard = null;
            //--TRIMMABLE-BOUNDARY-END(64425145021)
            
            //--TRIMMABLE-BOUNDARY-START(51540243133)
            /*IPaymentTierProvider?*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(51540243133)
            
            //--TRIMMABLE-BOUNDARY-START(38655341245)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<IPaymentTierProvider>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655341245);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.selected = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    if (this.wizard !== null)
                    {
                        let $t1, $r1;
                        ($t1 = this.wizard.NextView(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655341245)
            
            //--TRIMMABLE-BOUNDARY-START(42950308541)
            /*string */ get OptimizedComponentName()
            {
                return "billchooseservice";
            }
            //--TRIMMABLE-BOUNDARY-END(42950308541)
            
            //--TRIMMABLE-BOUNDARY-START(34360373949)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360373949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.PaymentTiers = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34360373949)
            
            //--TRIMMABLE-BOUNDARY-START(12885537469)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 2);
                    __builder2.AddComponentParameter(3, "Class", "pd");
                    __builder2.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$nYKj.LCFCP.IPaymentTierProvider), 5);
                            __builder3.AddComponentParameter(6, "ItemName", "Service");
                            __builder3.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | ($.$sl.SL.Enumerable.Count$1($.$nYKj.LCFCP.IPaymentTierProvider, this.PaymentTiers) > 10 ? 8n : 0n) | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(8, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider), this.PaymentTiers));
                            __builder3.AddComponentParameter(9, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 70), $.$$.S.Int32));
                            __builder3.AddComponentParameter(10, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                            __builder3.AddComponentParameter(11, "li-class", "text-center");
                            __builder3.AddComponentParameter(12, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                            __builder3.AddAttribute$3(13, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider))))().$ctor(this, ( (/**/ service) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(14, "div");
                                    __builder4.AddAttribute$5(15, "class", "bg-card pd shadow corner-3 flex hx-07 wx-07");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCI.Icon, 16);
                                    __builder4.AddComponentParameter(17, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, service.Model.LCFC$IDisplayable$Icon));
                                    __builder4.AddComponentParameter(18, "Class", "fsz-45 mg-a");
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(19, "\r\n                ");
                                    __builder4.OpenElement(20, "span");
                                    __builder4.AddAttribute$5(21, "class", "mgt-2 d-i-block");
                                    __builder4.AddContent$4(22, service.Model.LCFC$IDisplayable$Title);
                                    __builder4.CloseElement();
                                }, $cyZSkl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":635581,"h":0,"f":17825794});
                            }), $BCUyfg ??= {"r":6881395,"p":[{"n":"service","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$nYKj.LCFCP.IPaymentTierProvider)).$h}],"n":"","d":635581,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $iuiade ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":635581,"h":0,"f":17825794});
                    }), $ZSzXQf ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":635581,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(23, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 24);
                    __builder2.AddComponentParameter(25, "Class", "pd");
                    __builder2.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillChooseServiceTier, 27);
                            __builder3.AddComponentParameter(28, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTierProvider, this.selected));
                            __builder3.CloseComponent();
                        }, $wyravh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":635581,"h":0,"f":17825794});
                    }), $kclnnf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":635581,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $tTihQc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":635581,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(29, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.wizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                }, $jCiSTk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":635581,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885537469)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Payment$IPaymentTierProvider$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590570173)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590570173)
            
            //--TRIMMABLE-BOUNDARY-START(8590570173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590570173)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47245275837)
                this.PaymentTiers = null;
                //--TRIMMABLE-BOUNDARY-END(47245275837)
                
            }
            static $h = 635581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245275837),
    {
      "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065406653,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130177725,
        "f": 83886081
      },
      "n": "PaymentTiers",
      "d": 635581,
      "h": 47245275837,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245275837),
//--TRIMMABLE-BOUNDARY-START(42950308541),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475472061,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 635581,
      "h": 42950308541,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950308541)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655341245),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$nYKj.LCFCP.IPaymentTierProvider).$h
        }
      ],
      "n": "OnSelected",
      "d": 635581,
      "h": 38655341245,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(38655341245),
//--TRIMMABLE-BOUNDARY-START(34360373949),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 635581,
      "h": 34360373949,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360373949),
//--TRIMMABLE-BOUNDARY-START(12885537469),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 635581,
      "h": 12885537469,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885537469)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425145021),
    {
      "t": 59004586,
      "n": "wizard",
      "d": 635581,
      "h": 64425145021,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425145021),
//--TRIMMABLE-BOUNDARY-START(51540243133),
    {
      "t": 1001240,
      "n": "selected",
      "d": 635581,
      "h": 51540243133,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540243133)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590570173),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 635581,
      "h": 8590570173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590570173)
  ],
  "h": 635581
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$nYKj.LCFCP.IPaymentTierProvider), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$nYKj.LCFCP.IPaymentTierProvider), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillChooseService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillChooseService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(635581)
        
        

        //--TRIMMABLE-BOUNDARY-START(701117)
        $asm.$cls(`$cnlM.LCBCS$1.BillChooseServiceTier`, ($self) => class BillChooseServiceTier extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$nYKj.LCFCP.IPaymentTierProvider)
        {
            //--TRIMMABLE-BOUNDARY-START(73015145149)
            /*IUIPaymentProcessor?*/ Processor = null;
            //--TRIMMABLE-BOUNDARY-END(73015145149)
            
            //--TRIMMABLE-BOUNDARY-START(25770504893)
            /*IContact?*/ Customer = null;
            //--TRIMMABLE-BOUNDARY-END(25770504893)
            
            //--TRIMMABLE-BOUNDARY-START(64425210557)
            /*EventCallback<PaymentModel>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(64425210557)
            
            //--TRIMMABLE-BOUNDARY-START(68720177853)
            /*string */ get OptimizedComponentName()
            {
                return "billchooseservicetier";
            }
            //--TRIMMABLE-BOUNDARY-END(68720177853)
            
            //--TRIMMABLE-BOUNDARY-START(103079916221)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079916221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Processor":
                    this.Processor = $.$cast(parameter.Value, $.$hDPm.LCFCI.IUIPaymentProcessor);
                    return true;
                    case "Customer":
                    this.Customer = $.$cast(parameter.Value, $.$fPer.LCFCC$2.IContact);
                    return true;
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103079916221)
            
            //--TRIMMABLE-BOUNDARY-START(21475537597)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475537597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.LCFCP$IPaymentTierProvider$ServiceTiers === null)
                {
                    __builder.OpenComponent$1($.$cnlM.LCBCS$1.BillPayView, 0);
                    __builder.AddComponentParameter(1, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                    __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$xPgy.LCBCM.BillPaymentContext, (() =>
                    {
                        //new $.$xPgy.LCBCM.BillPaymentContext()
                        const $t2 = $.$xPgy.LCBCM.BillPaymentContext;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Provider = this.ViewModel;
                        $i2.Contact = this.Customer;
                        return $i2;
                    })()));
                    __builder.AddComponentParameter(3, "Processor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IUIPaymentProcessor, this.Processor));
                    __builder.AddComponentParameter(4, "OnPaid", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel), $.$mac.MAC.EventCallback.Factory.Create$6($.$Iaui.LCFCM.PaymentModel, this, this.OnPaid)));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(5, "div");
                    __builder.AddAttribute$5(6, "class", "mgb flex");
                    __builder.OpenComponent$1($.$hDPm.LCFCCI.Icon, 7);
                    __builder.AddComponentParameter(8, "Class", "fsz-40 hx-05 wx-05 bd round flex mgc-a");
                    __builder.AddComponentParameter(9, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, this.ViewModel.LCFC$IDisplayable$Icon));
                    __builder.AddComponentParameter(10, "IconSize", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 25), $.$$.S.Int32));
                    __builder.AddComponentParameter(11, "MediaHeight", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 25), $.$$.S.Int32));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(12, "\r\n        ");
                    __builder.OpenElement(13, "h3");
                    __builder.AddAttribute$5(14, "class", "mgl mgy-a");
                    __builder.AddContent$4(15, this.ViewModel.LCFC$IDisplayable$Title);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(16, "\r\n    ");
                    __builder.OpenComponent$1($.$dgLE.LCPCS$1.ChooseServiceTier, 17);
                    __builder.AddComponentParameter(18, "ServiceTierProvider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$nYKj.LCFCP.IPaymentTierProvider, this.ViewModel));
                    __builder.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier)))().$ctor(this, ( (/*selectedTier*/ selectedTier) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            if (selectedTier.Data !== null)
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 20);
                                __builder2.AddComponentParameter(21, "Class", "d-block mgt fw-bold");
                                __builder2.AddComponentParameter(22, "drawer-class", "pd bg-card");
                                __builder2.AddComponentParameter(23, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder2.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                                {
                                    __builder3.AddMarkupContent(25, "\r\n                        Proceed\r\n                    ");
                                }), $Whibng ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":701117,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(26, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$cnlM.LCBCS$1.BillPayView, 27);
                                        __builder3.AddComponentParameter(28, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$xPgy.LCBCM.BillPaymentContext, (() =>
                                        {
                                            //new $.$xPgy.LCBCM.BillPaymentContext()
                                            const $t3 = $.$xPgy.LCBCM.BillPaymentContext;
                                            const $i3 = new $t3();
                                            $i3.$ctor$1();
                                            $i3.Provider = this.ViewModel;
                                            $i3.Tier = selectedTier.Data;
                                            $i3.Contact = this.Customer;
                                            return $i3;
                                        })()));
                                        __builder3.AddComponentParameter(29, "Processor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IUIPaymentProcessor, this.Processor));
                                        __builder3.AddComponentParameter(30, "OnPaid", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel), $.$mac.MAC.EventCallback.Factory.Create$6($.$Iaui.LCFCM.PaymentModel, this, this.OnPaid)));
                                        __builder3.CloseComponent();
                                    }, $pgQUta ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":701117,"h":0,"f":17825794});
                                }), $xwHzPe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":701117,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }, $mIJRle ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":701117,"h":0,"f":17825794});
                    }), $IWRdZd ??= {"r":6881395,"p":[{"n":"selectedTier","p":$.$hDPm.LCFCI.ContainerContext$$($.$nYKj.LCFCP.IPaymentTier).$h}],"n":"","d":701117,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475537597)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180570301)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180570301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180570301)
            
            //--TRIMMABLE-BOUNDARY-START(17180570301)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17180570301)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425210557)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel));
                //--TRIMMABLE-BOUNDARY-END(64425210557)
                
            }
            static $h = 701117;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$nYKj.LCFCP.IPaymentTierProvider); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015145149),
    {
      "p": 65623722,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130243261,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784948925,
        "f": 83886081
      },
      "n": "Processor",
      "d": 701117,
      "h": 73015145149,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015145149),
//--TRIMMABLE-BOUNDARY-START(25770504893),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360439485,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605079741,
        "f": 83886081
      },
      "n": "Customer",
      "d": 701117,
      "h": 25770504893,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770504893),
//--TRIMMABLE-BOUNDARY-START(64425210557),
    {
      "p": $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950374077,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195014333,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 701117,
      "h": 64425210557,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425210557),
//--TRIMMABLE-BOUNDARY-START(68720177853),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540308669,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 701117,
      "h": 68720177853,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720177853)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079916221),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 701117,
      "h": 103079916221,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079916221),
//--TRIMMABLE-BOUNDARY-START(21475537597),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 701117,
      "h": 21475537597,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475537597)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180570301),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 701117,
      "h": 17180570301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180570301)
  ],
  "h": 701117
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillChooseServiceTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillChooseServiceTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(701117)
        
        

        //--TRIMMABLE-BOUNDARY-START(897725)
        $asm.$cls(`$cnlM.LCBCS$1.BillPay`, ($self) => class BillPay extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$xPgy.LCBCM.BillPaymentContext)
        {
            //--TRIMMABLE-BOUNDARY-START(12885799613)
            /*Application*/ App = null;
            //--TRIMMABLE-BOUNDARY-END(12885799613)
            
            //--TRIMMABLE-BOUNDARY-START(42950570685)
            /*Task *//*async*/  Paid(/*IPaymentOrderTransactionModel*/ tx)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950570685);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let btx;
                    if ($.$is(tx, $.$Iaui.LCFCM.PaymentModel, { set $v($v){ btx = $v; } }))
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        ($t1 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Page.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Page.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950570685)
            
            //--TRIMMABLE-BOUNDARY-START(38655603389)
            /*string */ get OptimizedComponentName()
            {
                return "billpay";
            }
            //--TRIMMABLE-BOUNDARY-END(38655603389)
            
            //--TRIMMABLE-BOUNDARY-START(55835472573)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835472573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "App":
                    this.App = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(55835472573)
            
            //--TRIMMABLE-BOUNDARY-START(17180766909)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180766909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$cnlM.LCBCS$1.BillPayView, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$xPgy.LCBCM.BillPaymentContext, this.Parameter));
                __builder.AddComponentParameter(2, "OnPaid", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$Iaui.LCFCM.PaymentModel, this, new ($.$$.S.Func$$$($.$Iaui.LCFCM.PaymentModel, $.$$.STT.Task))().$ctor(this, this.Paid))));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180766909)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590832317)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590832317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590832317)
            
            //--TRIMMABLE-BOUNDARY-START(8590832317)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590832317)
            
            static $h = 897725;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$xPgy.LCBCM.BillPaymentContext); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885799613),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770701501,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540505277,
        "f": 83886081
      },
      "n": "App",
      "d": 897725,
      "h": 12885799613,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885799613),
//--TRIMMABLE-BOUNDARY-START(38655603389),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360636093,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 897725,
      "h": 38655603389,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655603389)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950570685),
    {
      "r": 178454529,
      "p": [
        {
          "n": "tx",
          "p": 47810902
        }
      ],
      "n": "Paid",
      "d": 897725,
      "h": 42950570685,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42950570685),
//--TRIMMABLE-BOUNDARY-START(55835472573),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 897725,
      "h": 55835472573,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835472573),
//--TRIMMABLE-BOUNDARY-START(17180766909),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 897725,
      "h": 17180766909,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180766909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590832317),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 897725,
      "h": 8590832317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590832317)
  ],
  "h": 897725
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillPay`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillPay`; }
        });
        //--TRIMMABLE-BOUNDARY-END(897725)
        
        

        //--TRIMMABLE-BOUNDARY-START(963261)
        $asm.$cls(`$cnlM.LCBCS$1.BillPayView`, ($self) => class BillPayView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$xPgy.LCBCM.BillPaymentContext)
        {
            //--TRIMMABLE-BOUNDARY-START(197569458877)
            /*string */ get OptimizedComponentName()
            {
                return "billpayview";
            }
            //--TRIMMABLE-BOUNDARY-END(197569458877)
            
            //--TRIMMABLE-BOUNDARY-START(322123510461)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123510461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Processor":
                    this.Processor = $.$cast(parameter.Value, $.$hDPm.LCFCI.IUIPaymentProcessor);
                    return true;
                    case "OnPaid":
                    this.OnPaid = $.$cast(parameter.Value, $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(322123510461)
            
            //--TRIMMABLE-BOUNDARY-START(158914753213)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914753213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.PaymentServices = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider), serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(158914753213)
            
            //--TRIMMABLE-BOUNDARY-START(210454360765)
            /*IEnumerable<IPaymentTierProvider>*/ PaymentServices = null;
            //--TRIMMABLE-BOUNDARY-END(210454360765)
            
            //--TRIMMABLE-BOUNDARY-START(236224164541)
            /*BillService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(236224164541)
            
            //--TRIMMABLE-BOUNDARY-START(214749328061)
            /*IUIPaymentProcessor?*/ Processor = null;
            //--TRIMMABLE-BOUNDARY-END(214749328061)
            
            //--TRIMMABLE-BOUNDARY-START(193274491581)
            /*EventCallback<PaymentModel>*/ OnPaid;
            //--TRIMMABLE-BOUNDARY-END(193274491581)
            
            //--TRIMMABLE-BOUNDARY-START(171799655101)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(171799655101)
            
            //--TRIMMABLE-BOUNDARY-START(167504687805)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(167504687805)
            
            //--TRIMMABLE-BOUNDARY-START(231929197245)
            /*IPaymentTierProvider?*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(231929197245)
            
            //--TRIMMABLE-BOUNDARY-START(309238608573)
            /*IPaymentTier?*/ tier = null;
            //--TRIMMABLE-BOUNDARY-END(309238608573)
            
            //--TRIMMABLE-BOUNDARY-START(317828543165)
            /*string?*/ transactionDescription = null;
            //--TRIMMABLE-BOUNDARY-END(317828543165)
            
            //--TRIMMABLE-BOUNDARY-START(219044295357)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(219044295357)
            
            //--TRIMMABLE-BOUNDARY-START(219044295357)
            //--TRIMMABLE-BOUNDARY-START(47245603517)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245603517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47245603517)
            
            //--TRIMMABLE-BOUNDARY-START(227634229949)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634229949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(227634229949)
            
            //--TRIMMABLE-BOUNDARY-END(219044295357)
            
            //--TRIMMABLE-BOUNDARY-START(55835538109)
            /*Money*/ cost;
            //--TRIMMABLE-BOUNDARY-END(55835538109)
            
            //--TRIMMABLE-BOUNDARY-START(60130505405)
            /*Money */ get Cost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195276477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Payment.IPaymentTier?*/ let __ca1__;
                return (((__ca1__ = this.tier) !== null ? $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, __ca1__.LCFCP$IPaymentTier$Cost) : false)) ? this.tier.LCFCP$IPaymentTier$Cost : this.cost;
            }
            //--TRIMMABLE-BOUNDARY-END(60130505405)
            
            //--TRIMMABLE-BOUNDARY-START(180389589693)
            /*Money?*/ minimumCost = null;
            //--TRIMMABLE-BOUNDARY-END(180389589693)
            
            //--TRIMMABLE-BOUNDARY-START(176094622397)
            /*Money?*/ maximumCost = null;
            //--TRIMMABLE-BOUNDARY-END(176094622397)
            
            //--TRIMMABLE-BOUNDARY-START(244814099133)
            /*object?*/ serviceUserInformation = null;
            //--TRIMMABLE-BOUNDARY-END(244814099133)
            
            //--TRIMMABLE-BOUNDARY-START(313533575869)
            /*object?*/ tierUserInformation = null;
            //--TRIMMABLE-BOUNDARY-END(313533575869)
            
            //--TRIMMABLE-BOUNDARY-START(154619785917)
            /*Dictionary<string, string?>?*/ info = null;
            //--TRIMMABLE-BOUNDARY-END(154619785917)
            
            //--TRIMMABLE-BOUNDARY-START(184684556989)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684556989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._paymentReference = $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false);
                this.transactionDescription = (this.ViewModel.Tier?.LCFC$IDescribable$Description ?? null) ?? (this.ViewModel.Provider?.LCFC$IDescribable$Description ?? null);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(184684556989)
            
            //--TRIMMABLE-BOUNDARY-START(4295930557)
            /*double */ get _Cost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605341885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.cost.Value;
            }
            /*double */ set _Cost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404033725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.cost = $.$fPer.LCFCDM.Money.op_Implicit$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(4295930557)
            
            //--TRIMMABLE-BOUNDARY-START(188979524285)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979524285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = this.ViewModel.Provider;
                    this.tier = this.ViewModel.Tier;
                    if (this.service === null && this.ViewModel.RepeatTransaction !== null)
                    {
                        /*var*/ let svc = this.ViewModel.RepeatTransaction.ServiceId;
                        if (svc !== null)
                        {
                            this.service = $.$sl.SL.Enumerable.SingleOrDefault$1($.$nYKj.LCFCP.IPaymentTierProvider, this.PaymentServices, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                            {
                                return s.LCFCP$IPaymentTierProvider$Id === svc;
                            }, $jUYbof ??= {"r":262145,"p":[{"n":"s","p":1001240}],"n":"","d":963261,"h":0,"f":17825794}));
                        }
                    }
                    if (this.tier === null && this.service !== null && this.ViewModel.RepeatTransaction !== null)
                    {
                        /*var*/ let tr = this.ViewModel.RepeatTransaction.ServiceTierId;
                        if (tr !== null)
                        {
                            let $t2, $r2;
                            /*var*/ let tiers = ($t2 = $.$fPer.LCFCD.Paging.AsEnumerableAsync($.$nYKj.LCFCP.IPaymentTier, this.service.LCFCP$IPaymentTierProvider$ServiceTiers, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            this.tier = $.$sl.SL.Enumerable.SingleOrDefault$1($.$nYKj.LCFCP.IPaymentTier, tiers, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTier, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                            {
                                return d.LCFCP$IPaymentTier$Id === tr;
                            }, $uPSZzj ??= {"r":262145,"p":[{"n":"d","p":739096}],"n":"","d":963261,"h":0,"f":17825794}));
                        }
                    }
                    if (this.ViewModel.RepeatTransaction !== null)
                    {
                        this.transactionDescription = this.ViewModel.RepeatTransaction.Summary;
                        if ((this.tier?.LCFCP$IPaymentTier$Cost ?? null) === null)
                        {
                            this.cost = $.$fPer.LCFCDM.Money.op_Implicit$1(this.ViewModel.RepeatTransaction.Amount);
                        }
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188979524285)
            
            //--TRIMMABLE-BOUNDARY-START(326418477757)
            /*Task *//*async*/  Verify()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(326418477757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let ip;
                    if ($.$is(this.service, $.$nYKj.LCFCP.IPaymentTierInfoProvider, { set $v($v){ ip = $v; } }))
                    {
                        let $t4, $r4;
                        ($t4 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t5, $r5;
                                this.info = ($t5 = ip.LCFCP$IPaymentTierInfoProvider$GetInfo(this.tier, this.serviceUserInformation, this.tierUserInformation), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            });
                        }, $qQnEfj ??= {"r":181338113,"n":"","d":963261,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                        }, $TemKTc ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":963261,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(326418477757)
            
            //--TRIMMABLE-BOUNDARY-START(206159393469)
            /*PaymentModel?*/ payment = null;
            //--TRIMMABLE-BOUNDARY-END(206159393469)
            
            //--TRIMMABLE-BOUNDARY-START(8590897853)
            /*string*/ _paymentReference = null;
            //--TRIMMABLE-BOUNDARY-END(8590897853)
            
            //--TRIMMABLE-BOUNDARY-START(240519131837)
            /*IPaymentOrderTransactionModel?*/ serviceTransaction = null;
            //--TRIMMABLE-BOUNDARY-END(240519131837)
            
            //--TRIMMABLE-BOUNDARY-START(201864426173)
            /*ValueTask *//*async*/  Pay()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864426173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t11, $r11;
                            let $t12, $r12;
                            let $t18, $r18;
                            if ($.$$.S.String.IsNullOrEmpty(this.transactionDescription))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Transaction Description required");
                            }
                            if ((this.tier?.LCFCP$IPaymentTier$Cost ?? null) === null && this.Cost.Value === 0)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Package cost not specified");
                            }
                            if (this.minimumCost !== null && $.$fPer.LCFCDM.Money.op_Implicit(this.Cost) < $.$fPer.LCFCDM.Money.op_Implicit(this.minimumCost))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN((this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null))} requires a minimum amount of ${$.$strNN(this.minimumCost.ToString())}`);
                            }
                            if (this.maximumCost !== null && $.$fPer.LCFCDM.Money.op_Implicit(this.cost) > $.$fPer.LCFCDM.Money.op_Implicit(this.maximumCost))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN((this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null))} requires a maximum amount of ${$.$strNN(this.maximumCost.ToString())}`);
                            }
                            if (this.service !== null)
                            {
                                let $t7, $r7;
                                ($t7 = this.service.LCFCP$IPaymentTierProvider$Validate((() =>
                                {
                                    //new $.$nYKj.LCFCP.PaymentTierReceiptContext()
                                    const $t8 = $.$nYKj.LCFCP.PaymentTierReceiptContext;
                                    const $i8 = new $t8();
                                    $i8.$ctor$2();
                                    $i8.Tier = this.tier;
                                    $i8.AmountPaid = $.$clone(this.Cost);
                                    $i8.ServiceUserInformation = this.serviceUserInformation;
                                    $i8.TierUserInformation = this.tierUserInformation;
                                    $i8.IsClient = true;
                                    return $i8;
                                })()), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            }
                            /*var*/ let summary1 = ((this.serviceTransaction?.LCFC$IPaymentOrderTransactionModel$Name ?? null) ?? (this.tier?.LCFC$INamed$Name ?? null) ?? this.service.LCFC$INamed$Name);
                            /*var*/ let summary2 = ((($.$as(this.serviceUserInformation, $.$fPer.LCFC.IDescribable))?.LCFC$IDescribable$Description ?? null) ?? (this.serviceTransaction?.LCFC$IPaymentOrderTransactionModel$Summary ?? null) ?? (this.tier?.LCFC$IDescribable$Description ?? null) ?? (this.service?.LCFC$IDescribable$Description ?? null));
                            /*var*/ let summary3 = this.transactionDescription;
                            /*var*/ let summary4 = (($.$as(this.serviceUserInformation, $.$fPer.LCFC.IDisplayable))?.LCFC$IDisplayable$Title ?? null);
                            if (summary3 === summary2)
                            {
                                summary3 = null;
                            }
                            if (summary4 === summary2)
                            {
                                summary4 = null;
                            }
                            /*LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType?*/ let __ca2__;
                            /*object?*/ let __ca3__;
                            /*object?*/ let __ca4__;
                            /*var*/ let payment = (() =>
                            {
                                //new $.$Iaui.LCFCM.PaymentModel()
                                const $t9 = $.$Iaui.LCFCM.PaymentModel;
                                const $i9 = new $t9();
                                $i9.$ctor$3();
                                $i9.Summary = $.$strNN($.$strNN($.$strNN($.$strNN(summary1) + " | ") + $.$strNN(summary2)) + $.$strNN((summary3 !== null ? " | " + $.$strNN(summary3) : null))) + $.$strNN((summary4 !== null ? " | " + $.$strNN(summary4) : null));
                                let c;
                                let cc;
                                $i9.Category = ((__ca2__ = (($.$is((this.tier?.LCFCP$IPaymentTier$Tier ?? null), $.$nYKj.LCFCP.PaymentCategoryType, { set $v($v){ c = $v; } }) ? c : null) ?? ($.$is((this.service?.LCFCP$IPaymentTierProvider$Category ?? null), $.$nYKj.LCFCP.PaymentCategoryType, { set $v($v){ cc = $v; } }) ? cc : null))) !== null ? $.$$.S.Enum.ToStringT($.$nYKj.LCFCP.PaymentCategoryType, $.$$.S.UInt32, $.$$.S.Nullable$$($.$nYKj.LCFCP.PaymentCategoryType).Value$get.call(__ca2__)) : null);
                                $i9.Amount = $.$fPer.LCFCDM.Money.op_Implicit((this.serviceTransaction?.LCFC$IPaymentOrderTransactionModel$Amount ?? null) ?? this.Cost);
                                $i9.Reference = this._paymentReference;
                                const $t10 = this.service;
                                $i9.ServiceId = $.$ifnn($t10, ($t) => $.$$.S.Object.GetType.call($t).FullName);
                                $i9.ServiceTierId = (this.tier?.LCFCP$IPaymentTier$Id ?? null);
                                $i9.ServiceUserInformation = $.$fPer.LCFCS$1.Serialized.op_Implicit$1((__ca3__ = this.serviceUserInformation) !== null ? $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, __ca3__, true, false, true, false, false, false, false, "Pay", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Bills.Client.Blazor\\BillPayView.razor.cs", "Pay", 183) : null);
                                $i9.TierUserInformation = $.$fPer.LCFCS$1.Serialized.op_Implicit$1((__ca4__ = this.tierUserInformation) !== null ? $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, __ca4__, true, false, true, false, false, false, false, "Pay", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Bills.Client.Blazor\\BillPayView.razor.cs", "Pay", 184) : null);
                                return $i9;
                            })();
                            /*var*/ let ticket = ($t11 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IReadOnlyAuthenticationService$GetTicket(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            /*var*/ let paymentResult = ($t12 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$clone(this.Cost), (this.service?.LCFC$IDisplayable$Title ?? null) ?? (this.tier?.LCFC$IDisplayable$Title ?? null) ?? "Purchase", this._paymentReference, $.$strNN($.$strNN(((this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null))) + " | ") + $.$strNN(this.transactionDescription), `Pay for ${$.$strNN((this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null))}`, (this.tier?.LCFC$INamed$Name ?? null) ?? (this.service?.LCFC$INamed$Name ?? null), this.Processor, this.ViewModel.Contact ?? (() =>
                            {
                                //new $.$fPer.LCFCC$2.Contact()
                                const $t13 = $.$fPer.LCFCC$2.Contact;
                                const $i13 = new $t13();
                                $i13.$ctor$2();
                                $i13.Identifier = $.$fPer.LCFCD.DataId.op_Implicit$1(ticket.Id);
                                $i13.Email = ticket.Email;
                                return $i13;
                            })(), (($.$as(this.service, $.$nYKj.LCFCP.IPaymentTierSplitPaymentProvider))?.LCFCP$IPaymentTierSplitPaymentProvider$PayeeSplit ?? null), payment), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                            if (this.service !== null)
                            {
                                let $t14, $r14;
                                this.serviceTransaction = ($t14 = this.service.LCFCP$IPaymentTierProvider$Execute((() =>
                                {
                                    //new $.$nYKj.LCFCP.PaymentTierReceiptContext()
                                    const $t15 = $.$nYKj.LCFCP.PaymentTierReceiptContext;
                                    const $i15 = new $t15();
                                    $i15.$ctor$2();
                                    $i15.Tier = this.tier;
                                    $i15.AmountPaid = $.$clone(this.Cost);
                                    $i15.PaymentReference = paymentResult.Reference;
                                    $i15.ServiceUserInformation = this.serviceUserInformation;
                                    $i15.TierUserInformation = this.tierUserInformation;
                                    $i15.IsClient = true;
                                    return $i15;
                                })()), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            }
                            if (this.serviceTransaction !== null)
                            {
                                payment.OrderStatus = this.serviceTransaction.LCFC$IPaymentOrderTransactionModel$OrderStatus;
                            }
                            let container;
                            if ($.$is(this.serviceTransaction, $.$fPer.LCFCD.IReadOnlyDynamicDataContainer, { set $v($v){ container = $v; } }) && container.LCFCD$IReadOnlyDynamicDataContainer$Attributes !== null)
                            {
                                let $en16 = container.LCFCD$IReadOnlyDynamicDataContainer$Attributes.SCG$IEnumerable$$$GetEnumerator();
                                while ($en16.SC$1$IEnumerator$MoveNext())
                                {
                                    let att = $en16.SCG$IEnumerator$$$Current;
                                    {
                                        (payment).LCFCD$IDataHasProperties$SetProperty($.$$.S.Object, att.Value, att.Key);
                                    }
                                }
                            }
                            if (payment.Identifier.Empty)
                            {
                                let $t17, $r17;
                                payment = $.$sl.SL.Enumerable.First$1($.$Iaui.LCFCM.PaymentModel, (($t17 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Iaui.LCFCM.PaymentModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.PaymentModel), [ payment ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)))).AsEnumerable());
                            }
                            ($t18 = this.OnPaid.InvokeAsync$1(payment), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                            this.payment = payment;
                        });
                    }, $dahFah ??= {"r":181338113,"n":"","d":963261,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                    }, $cNMsrb ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":963261,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864426173)
            
            //--TRIMMABLE-BOUNDARY-START(163209720509)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209720509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(163209720509)
            
            //--TRIMMABLE-BOUNDARY-START(64425472701)
            /*int*/ costSequenceNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(64425472701)
            
            //--TRIMMABLE-BOUNDARY-START(73015407293)
            /*void */ Field(/*IObservableDataDescriptor*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015407293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                field.LCFCR$IReactiveObservable$Subscribe(new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable, $.$fPer.LCFCR.IReactiveObservableChanges))().$ctor(this,  (/*f*/ f, /*i*/ i) =>
                {
                    this.costSequenceNumber++;
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Bills.Client.Blazor\\BillPayView.razor.cs", "Field", 252);
                }, $bZrArk ??= {"r":65537,"p":[{"n":"f","p":54167894},{"n":"i","p":54298966}],"n":"","d":963261,"h":0,"f":17825794}), null, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(73015407293)
            
            //--TRIMMABLE-BOUNDARY-START(51540570813)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540570813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.payment === null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                    __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                    __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                    __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(4, "div");
                        __builder2.AddAttribute$5(5, "class", "stack hf");
                        __builder2.OpenElement(6, "h3");
                        __builder2.AddAttribute$5(7, "class", "mgt-0 mgl-5");
                        __builder2.AddContent$4(8, "Paying for ");
                        __builder2.AddContent$4(9, (this.tier?.LCFC$IDisplayable$Title ?? null) ?? this.service.LCFC$IDisplayable$Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(10, "\r\n            ");
                        __builder2.OpenElement(11, "div");
                        __builder2.AddAttribute$5(12, "class", "bg-card pd corner-3 shadow");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 13);
                        __builder2.AddComponentParameter(14, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, (this.tier?.LCFC$IDisplayable$Icon ?? null) ?? this.service.LCFC$IDisplayable$Icon));
                        __builder2.AddComponentParameter(15, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, (this.tier?.LCFC$IDisplayable$Title ?? null) ?? this.service.LCFC$IDisplayable$Title));
                        __builder2.AddComponentParameter(16, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN((this.tier?.LCFC$IDisplayable$Title ?? null) ?? this.service.LCFC$IDisplayable$Title)}${$.$strNN(($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Cost) ? " - " + $.$strNN(this.Cost.ToString$1(0)) : ""))}`));
                        __builder2.AddComponentParameter(17, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, (this.tier?.LCFC$IDescribable$Description ?? null) ?? this.service.LCFC$IDescribable$Description));
                        __builder2.AddComponentParameter(18, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(19, "\r\n            ");
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 20);
                        __builder2.AddComponentParameter(21, "class", "fill stack mgt-10");
                        __builder2.AddComponentParameter(22, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                        __builder2.AddComponentParameter(23, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macf.MACF.EditContext, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Pay))));
                        __builder2.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if ((this.service?.LCFCP$IPaymentTierProvider$UserInformation ?? null) !== null)
                                {
                                    if ($.$mac.MAC.IComponent.$type.IsAssignableFrom(this.service.LCFCP$IPaymentTierProvider$UserInformation))
                                    {
                                        __builder3.OpenComponent$1($.$mac.MAC.DynamicComponent, 25);
                                        __builder3.AddComponentParameter(26, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, this.service.LCFCP$IPaymentTierProvider$UserInformation));
                                        __builder3.AddComponentParameter(27, "Parameters", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), (() =>
                                        {
                                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                            const $t19 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                            const $i19 = new $t19();
                                            $i19.$ctor$1();
                                            $i19.set_Item("Service", this.service);
                                            $i19.set_Item("Tier", this.tier);
                                            $i19.set_Item("Pay", this);
                                            return $i19;
                                        })()));
                                        __builder3.CloseComponent();
                                    }
                                    else 
                                    {
                                        this.serviceUserInformation ??= $.$$.S.Activator.CreateInstance$9(this.service.LCFCP$IPaymentTierProvider$UserInformation);
                                        __builder3.AddContent(28, this.DynamicForm(T, this.serviceUserInformation));
                                    }
                                }
                                if ((this.tier?.LCFCP$IPaymentTier$UserInformation ?? null) !== null)
                                {
                                    if ($.$mac.MAC.IComponent.$type.IsAssignableFrom(this.tier.LCFCP$IPaymentTier$UserInformation))
                                    {
                                        __builder3.OpenComponent$1($.$mac.MAC.DynamicComponent, 29);
                                        __builder3.AddComponentParameter(30, "Type", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Type, this.tier.LCFCP$IPaymentTier$UserInformation));
                                        __builder3.AddComponentParameter(31, "Parameters", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), (() =>
                                        {
                                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                                            const $t20 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                                            const $i20 = new $t20();
                                            $i20.$ctor$1();
                                            $i20.set_Item("Service", this.service);
                                            $i20.set_Item("Tier", this.tier);
                                            $i20.set_Item("Pay", this);
                                            return $i20;
                                        })()));
                                        __builder3.CloseComponent();
                                    }
                                    else 
                                    {
                                        this.tierUserInformation ??= $.$$.S.Activator.CreateInstance$9(this.tier.LCFCP$IPaymentTier$UserInformation);
                                        __builder3.AddContent(32, this.DynamicForm(T, this.tierUserInformation));
                                    }
                                }
                                if ($.$fPer.LCFCDM.Money.op_Implicit((this.tier?.LCFCP$IPaymentTier$Cost ?? null)) > 0)
                                {
                                    __builder3.OpenElement(33, "h1");
                                    __builder3.AddAttribute$5(34, "class", "text-center fsz-60 mgy-10 cl-primary");
                                    __builder3.AddContent$3(35, this.tier.LCFCP$IPaymentTier$Cost);
                                    __builder3.CloseElement();
                                }
                                else 
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), 36);
                                    __builder3.AddComponentParameter(37, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$$.S.Func$$($.$$.STT.Task$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))), $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))), $.$fPer.LCFCR.ReactiveObservable$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$$.S.Func$$($.$$.STT.Task$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))), $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))), $.$fPer.LCFCR.ReactiveObservable$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))).op_Implicit$3((($.$as(this.service, $.$nYKj.LCFCP.IPaymentTierCostProvider))?.LCFCP$IPaymentTierCostProvider$GetCost(this.tier, this.tierUserInformation, this.serviceUserInformation) ?? null) ?? $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money), new ($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))()))));
                                    __builder3.AddComponentParameter(38, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$3.TaskViewFeatures, 7/*TaskViewFeatures.Default*/ & ~1/*TaskViewFeatures.Once*/), $.$hDPm.LCFCCT$3.TaskViewFeatures));
                                    __builder3.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money))))().$ctor(this, ( (/*_cost*/ _cost) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, _cost.Data.Minimum) && $.$fPer.LCFCDM.Money.op_Implicit(_cost.Data.Minimum) === $.$fPer.LCFCDM.Money.op_Implicit(_cost.Data.Maximum))
                                            {
                                                this.cost = _cost.Data.Minimum;
                                                __builder4.OpenElement(40, "h1");
                                                __builder4.AddAttribute$5(41, "class", "text-center fsz-60 mgy-10 cl-primary");
                                                __builder4.AddContent$3(42, _cost.Data.Minimum);
                                                __builder4.CloseElement();
                                            }
                                            else 
                                            {
                                                if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, _cost.Data.Minimum))
                                                {
                                                    this.minimumCost = _cost.Data.Minimum;
                                                }
                                                else 
                                                {
                                                    this.minimumCost = null;
                                                }
                                                if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, _cost.Data.Maximum))
                                                {
                                                    this.maximumCost = _cost.Data.Minimum;
                                                }
                                                else 
                                                {
                                                    this.maximumCost = null;
                                                }
                                                __builder4.AddMarkupContent(43, "<h4 class=\"mgb-0\">Enter Amount</h4>\r\n                            ");
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$fPer.LCFCDM.Money), 44);
                                                __builder4.AddComponentParameter(45, "Class", "fsz-60 text-center cl-primary bg-primary-01");
                                                __builder4.AddComponentParameter(46, "input-class", "fsz-60");
                                                __builder4.AddComponentParameter(47, "_Type", "InputType.Text");
                                                __builder4.AddComponentParameter(48, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                                                __builder4.AddComponentParameter(49, "PlaceHolder", "Amount");
                                                __builder4.AddComponentParameter(50, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDM.Money, $.$clone(this.cost)));
                                                __builder4.AddComponentParameter(51, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCDM.Money), $.$mac.MAC.EventCallback.Factory.Create$6($.$fPer.LCFCDM.Money, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$fPer.LCFCDM.Money, this, new ($.$$.S.Action$$($.$fPer.LCFCDM.Money))().$ctor(this,  (/*__value*/ __value) =>
                                                {
                                                    return this.cost = $.$clone(__value);
                                                }, $NVIzQh ??= {"r":65537,"p":[{"n":"__value","p":27822422}],"n":"","d":963261,"h":0,"f":17825794}), $.$clone(this.cost)))));
                                                __builder4.AddComponentParameter(52, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$fPer.LCFCDM.Money)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                {
                                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "cost"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                }, $gldezi ??= {"r":38797349,"n":"","d":963261,"h":0,"f":17825794})).Invoke())));
                                                __builder4.CloseComponent();
                                                if (this.minimumCost !== null && $.$fPer.LCFCDM.Money.op_Implicit(this.cost) < $.$fPer.LCFCDM.Money.op_Implicit(this.minimumCost))
                                                {
                                                    __builder4.OpenElement(53, "span");
                                                    __builder4.AddAttribute$5(54, "class", "cl-error d-block");
                                                    __builder4.AddContent$4(55, (this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null));
                                                    __builder4.AddContent$4(56, " requires a minimum amount of ");
                                                    __builder4.AddContent$3(57, $.$clone(this.minimumCost));
                                                    __builder4.CloseElement();
                                                }
                                                if (this.maximumCost !== null && $.$fPer.LCFCDM.Money.op_Implicit(this.cost) > $.$fPer.LCFCDM.Money.op_Implicit(this.maximumCost))
                                                {
                                                    __builder4.OpenElement(58, "span");
                                                    __builder4.AddAttribute$5(59, "class", "cl-error d-block");
                                                    __builder4.AddContent$4(60, (this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null));
                                                    __builder4.AddContent$4(61, " requires a maximum amount of ");
                                                    __builder4.AddContent$3(62, $.$clone(this.maximumCost));
                                                    __builder4.CloseElement();
                                                }
                                            }
                                        }, $zbItzi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":963261,"h":0,"f":17825794});
                                    }), $ARoPcj ??= {"r":6881395,"p":[{"n":"_cost","p":$.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h}],"n":"","d":963261,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                                __builder3.AddMarkupContent(63, "<h4 class=\"mgb-0\">Transaction Description</h4>\r\n                ");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 64);
                                __builder3.AddComponentParameter(65, "Class", "mgt text-center bd bg-primary-01");
                                __builder3.AddComponentParameter(66, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 16n), $.$fPer.LCFC.InputType));
                                __builder3.AddComponentParameter(67, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                                __builder3.AddComponentParameter(68, "PlaceHolder", "Transaction Description");
                                __builder3.AddComponentParameter(69, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.transactionDescription));
                                __builder3.AddComponentParameter(70, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.transactionDescription = __value;
                                }, $aIsGSe ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":963261,"h":0,"f":17825794}), this.transactionDescription))));
                                __builder3.AddComponentParameter(71, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "transactionDescription"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $CsXsYb ??= {"r":38797349,"n":"","d":963261,"h":0,"f":17825794})).Invoke())));
                                __builder3.CloseComponent();
                                let ip;
                                if ($.$is(this.service, $.$nYKj.LCFCP.IPaymentTierInfoProvider, { set $v($v){ ip = $v; } }) && this.info === null)
                                {
                                    __builder3.OpenElement(72, "div");
                                    __builder3.AddAttribute$5(73, "class", "mgt-a");
                                    __builder3.OpenElement(74, "button");
                                    __builder3.AddAttribute$5(75, "Class", "d-block wf mgt bg-primary pd corner");
                                    __builder3.AddAttribute$5(76, "type", "button");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 77, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Verify)));
                                    __builder3.AddMarkupContent(78, "\r\n                            Verify\r\n                        ");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                                else 
                                {
                                    if (this.info !== null)
                                    {
                                        $.$cnlM._LCBCSB.TypeInference.CreatePropertySheet_0($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), __builder3, 79, 80, this.info, 81, 2, 82, "fw-bold");
                                    }
                                    __builder3.OpenElement(83, "div");
                                    __builder3.AddAttribute$5(84, "class", "mgt-a");
                                    __builder3.OpenElement(85, "button");
                                    __builder3.AddAttribute$5(86, "class", "d-block wf mgt bg-primary pd corner");
                                    __builder3.AddAttribute$2(87, "disabled", this.cost.Value === 0);
                                    __builder3.AddAttribute$5(88, "type", "submit");
                                    __builder3.AddMarkupContent(89, "\r\n                            Pay\r\n                        ");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                            }, $weHhkb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":963261,"h":0,"f":17825794});
                        }), $RGhTzg ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":963261,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }), $GHMmQh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":963261,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenElement(90, "div");
                    __builder.AddAttribute$5(91, "class", "stack text-center");
                    __builder.AddMarkupContent(92, "<i class=\"mdi mdi-checkbox-marked-circle-outline cl-primary fsz-100 mgx-a\"></i>\r\n        ");
                    __builder.AddMarkupContent(93, "<h2>Transaction Successful</h2>\r\n        ");
                    __builder.OpenElement(94, "p");
                    __builder.AddContent$4(95, "Your ");
                    __builder.AddContent$4(96, (this.tier?.LCFC$IDisplayable$Title ?? null) ?? (this.service?.LCFC$IDisplayable$Title ?? null));
                    __builder.AddContent$4(97, " purchase is ");
                    __builder.AddContent$4(98, this.payment.OrderStatus === 5/*PaymentOrderTransactionStatus.Completed*/ ? "successful" : "on the way");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(99, "\r\n        ");
                    __builder.OpenElement(100, "div");
                    __builder.AddAttribute$5(101, "class", "bg-card pd");
                    __builder.OpenComponent$1($.$wtdm.LCFCPS.PaymentDetails, 102);
                    __builder.AddComponentParameter(103, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.PaymentModel, this.payment));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540570813)
            
            //--TRIMMABLE-BOUNDARY-START(68720439997)
            /*RenderFragment */ DynamicForm(T, /*T*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720439997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), 104);
                    __builder2.AddComponentParameter(105, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder2.AddComponentParameter(106, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$clone(this.Theme)));
                    __builder2.AddComponentParameter(107, "Model", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(T, model), T));
                    __builder2.AddComponentParameter(108, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$(T), $.$mac.MAC.EventCallback.Factory.Create$6(T, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1(T, this, new ($.$$.S.Action$$(T))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return model = __value;
                    }, $tgavRj ??= {"r":65537,"p":[{"n":"__value","p":(T) => T.$h}],"n":"","d":963261,"h":0,"f":17825794}), model))));
                    __builder2.AddComponentParameter(109, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$(T)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Constant$1($.$box(model, T)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $hfvxLg ??= {"r":38797349,"n":"","d":963261,"h":0,"f":17825794})).Invoke())));
                    __builder2.CloseComponent();
                }, $FBbdCg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":963261,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(68720439997)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(4318975658)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.FormBuilder.IFormFieldEditController.Field(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor)
            LCFCCF$2$IFormFieldEditController$Field()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4318975658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Field(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4318975658)
            
            //--TRIMMABLE-BOUNDARY-START(38655668925)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655668925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655668925)
            
            //--TRIMMABLE-BOUNDARY-START(38655668925)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(38655668925)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(210454360765)
                this.PaymentServices = null;
                //--TRIMMABLE-BOUNDARY-END(210454360765)
                
                //--TRIMMABLE-BOUNDARY-START(236224164541)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(236224164541)
                
                //--TRIMMABLE-BOUNDARY-START(193274491581)
                this.OnPaid = $.$default($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel));
                //--TRIMMABLE-BOUNDARY-END(193274491581)
                
                //--TRIMMABLE-BOUNDARY-START(171799655101)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(171799655101)
                
                //--TRIMMABLE-BOUNDARY-START(55835538109)
                this.cost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(55835538109)
                
                //--TRIMMABLE-BOUNDARY-START(180389589693)
                this.minimumCost = null;
                //--TRIMMABLE-BOUNDARY-END(180389589693)
                
                //--TRIMMABLE-BOUNDARY-START(176094622397)
                this.maximumCost = null;
                //--TRIMMABLE-BOUNDARY-END(176094622397)
                
                //--TRIMMABLE-BOUNDARY-START(244814099133)
                this.serviceUserInformation = null;
                //--TRIMMABLE-BOUNDARY-END(244814099133)
                
                //--TRIMMABLE-BOUNDARY-START(313533575869)
                this.tierUserInformation = null;
                //--TRIMMABLE-BOUNDARY-END(313533575869)
                
                //--TRIMMABLE-BOUNDARY-START(154619785917)
                this.info = null;
                //--TRIMMABLE-BOUNDARY-END(154619785917)
                
                //--TRIMMABLE-BOUNDARY-START(8590897853)
                this._paymentReference = null;
                //--TRIMMABLE-BOUNDARY-END(8590897853)
                
            }
            static $h = 963261;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$xPgy.LCBCM.BillPaymentContext); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197569458877),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555014845,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 963261,
      "h": 197569458877,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197569458877),
//--TRIMMABLE-BOUNDARY-START(210454360765),
    {
      "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144949437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763772093,
        "f": 83886081
      },
      "n": "PaymentServices",
      "d": 963261,
      "h": 210454360765,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210454360765),
//--TRIMMABLE-BOUNDARY-START(236224164541),
    {
      "p": 570045,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324818621,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943641277,
        "f": 83886081
      },
      "n": "Service",
      "d": 963261,
      "h": 236224164541,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236224164541),
//--TRIMMABLE-BOUNDARY-START(214749328061),
    {
      "p": 65623722,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734884029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353706685,
        "f": 83886081
      },
      "n": "Processor",
      "d": 963261,
      "h": 214749328061,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749328061),
//--TRIMMABLE-BOUNDARY-START(193274491581),
    {
      "p": $.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.PaymentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965080253,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173837501,
        "f": 83886081
      },
      "n": "OnPaid",
      "d": 963261,
      "h": 193274491581,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274491581),
//--TRIMMABLE-BOUNDARY-START(171799655101),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375145661,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583902909,
        "f": 83886081
      },
      "n": "Loading",
      "d": 963261,
      "h": 171799655101,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799655101),
//--TRIMMABLE-BOUNDARY-START(167504687805),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785211069,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993968317,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 963261,
      "h": 167504687805,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504687805),
//--TRIMMABLE-BOUNDARY-START(60130505405),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195276477,
        "f": 50331650
      },
      "n": "Cost",
      "d": 963261,
      "h": 60130505405,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130505405),
//--TRIMMABLE-BOUNDARY-START(4295930557),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605341885,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404033725,
        "f": 83886082
      },
      "n": "_Cost",
      "d": 963261,
      "h": 4295930557,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295930557)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(322123510461),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 963261,
      "h": 322123510461,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(322123510461),
//--TRIMMABLE-BOUNDARY-START(158914753213),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 963261,
      "h": 158914753213,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914753213),
//--TRIMMABLE-BOUNDARY-START(184684556989),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 963261,
      "h": 184684556989,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(184684556989),
//--TRIMMABLE-BOUNDARY-START(188979524285),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 963261,
      "h": 188979524285,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(188979524285),
//--TRIMMABLE-BOUNDARY-START(326418477757),
    {
      "r": 178454529,
      "n": "Verify",
      "d": 963261,
      "h": 326418477757,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(326418477757),
//--TRIMMABLE-BOUNDARY-START(201864426173),
    {
      "r": 181338113,
      "n": "Pay",
      "d": 963261,
      "h": 201864426173,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(201864426173),
//--TRIMMABLE-BOUNDARY-START(163209720509),
    {
      "r": 181338113,
      "n": "Load",
      "d": 963261,
      "h": 163209720509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209720509),
//--TRIMMABLE-BOUNDARY-START(73015407293),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": 40536406
        }
      ],
      "n": "Field",
      "d": 963261,
      "h": 73015407293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015407293),
//--TRIMMABLE-BOUNDARY-START(51540570813),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 963261,
      "h": 51540570813,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540570813),
//--TRIMMABLE-BOUNDARY-START(68720439997),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "DynamicForm",
      "d": 963261,
      "h": 68720439997,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(68720439997)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(231929197245),
    {
      "t": 1001240,
      "n": "service",
      "d": 963261,
      "h": 231929197245,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231929197245),
//--TRIMMABLE-BOUNDARY-START(309238608573),
    {
      "t": 739096,
      "n": "tier",
      "d": 963261,
      "h": 309238608573,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(309238608573),
//--TRIMMABLE-BOUNDARY-START(317828543165),
    {
      "t": 1310721,
      "n": "transactionDescription",
      "d": 963261,
      "h": 317828543165,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(317828543165),
//--TRIMMABLE-BOUNDARY-START(55835538109),
    {
      "t": 27822422,
      "n": "cost",
      "d": 963261,
      "h": 55835538109,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835538109),
//--TRIMMABLE-BOUNDARY-START(180389589693),
    {
      "t": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "n": "minimumCost",
      "d": 963261,
      "h": 180389589693,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(180389589693),
//--TRIMMABLE-BOUNDARY-START(176094622397),
    {
      "t": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "n": "maximumCost",
      "d": 963261,
      "h": 176094622397,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(176094622397),
//--TRIMMABLE-BOUNDARY-START(244814099133),
    {
      "t": 131073,
      "n": "serviceUserInformation",
      "d": 963261,
      "h": 244814099133,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(244814099133),
//--TRIMMABLE-BOUNDARY-START(313533575869),
    {
      "t": 131073,
      "n": "tierUserInformation",
      "d": 963261,
      "h": 313533575869,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(313533575869),
//--TRIMMABLE-BOUNDARY-START(154619785917),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "info",
      "d": 963261,
      "h": 154619785917,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154619785917),
//--TRIMMABLE-BOUNDARY-START(206159393469),
    {
      "t": 12592470,
      "n": "payment",
      "d": 963261,
      "h": 206159393469,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(206159393469),
//--TRIMMABLE-BOUNDARY-START(8590897853),
    {
      "t": 1310721,
      "n": "_paymentReference",
      "d": 963261,
      "h": 8590897853,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590897853),
//--TRIMMABLE-BOUNDARY-START(240519131837),
    {
      "t": 47810902,
      "n": "serviceTransaction",
      "d": 963261,
      "h": 240519131837,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(240519131837),
//--TRIMMABLE-BOUNDARY-START(64425472701),
    {
      "t": 655361,
      "n": "costSequenceNumber",
      "d": 963261,
      "h": 64425472701,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425472701)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655668925),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 963261,
      "h": 38655668925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655668925)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(219044295357),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 963261,
        "h": 47245603517,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 963261,
        "h": 227634229949,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 963261,
      "h": 219044295357,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(219044295357)
  ],
  "h": 963261
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCCF$2.IFormFieldEditController, $.$hDPm.LCFCCF$2.IFormController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCC$1.IManagedBaseComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillPayView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillPayView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(963261)
        
        

        //--TRIMMABLE-BOUNDARY-START(570045)
        $asm.$cls(`$cnlM.LCBCS.BillService`, ($self) => class BillService extends $.$sZVd.LCFCA.ApplicationBaseService
        {
            //--TRIMMABLE-BOUNDARY-START(4295537341)
            $ctor$5(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$4(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295537341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295537341)
            
            static $h = 570045;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sZVd.LCFCA.ApplicationBaseService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295537341),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 570045,
      "h": 4295537341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295537341)
  ],
  "h": 570045
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Services.BillService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Services${separator}BillService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(570045)
        
        

        //--TRIMMABLE-BOUNDARY-START(1094333)
        $asm.$cls(`$cnlM.LCBCS$1.BillTransactionDetails`, ($self) => class BillTransactionDetails extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$Iaui.LCFCM.PaymentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(77310505661)
            /*string */ get OptimizedComponentName()
            {
                return "billtransactiondetails";
            }
            //--TRIMMABLE-BOUNDARY-END(77310505661)
            
            //--TRIMMABLE-BOUNDARY-START(68720571069)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720571069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$cnlM.LCBCS.BillService, serviceProvider);
                this.PaymentServices = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720571069)
            
            //--TRIMMABLE-BOUNDARY-START(21475930813)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475930813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475930813)
            
            //--TRIMMABLE-BOUNDARY-START(94490374845)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(94490374845)
            
            //--TRIMMABLE-BOUNDARY-START(103080309437)
            /*BillService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(103080309437)
            
            //--TRIMMABLE-BOUNDARY-START(81605472957)
            /*IEnumerable<IPaymentTierProvider>*/ PaymentServices = null;
            //--TRIMMABLE-BOUNDARY-END(81605472957)
            
            //--TRIMMABLE-BOUNDARY-START(98785342141)
            /*IPaymentTierProvider?*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(98785342141)
            
            //--TRIMMABLE-BOUNDARY-START(133145080509)
            /*IPaymentTier?*/ tier = null;
            //--TRIMMABLE-BOUNDARY-END(133145080509)
            
            //--TRIMMABLE-BOUNDARY-START(85900440253)
            /*string?*/ peerId = null;
            //--TRIMMABLE-BOUNDARY-END(85900440253)
            
            //--TRIMMABLE-BOUNDARY-START(73015538365)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015538365);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let svc = this.Parameter.ServiceId;
                    if (svc !== null)
                    {
                        this.service = $.$sl.SL.Enumerable.SingleOrDefault$1($.$nYKj.LCFCP.IPaymentTierProvider, this.PaymentServices, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTierProvider, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCFCP$IPaymentTierProvider$Id === svc;
                        }, $KLxUxb ??= {"r":262145,"p":[{"n":"s","p":1001240}],"n":"","d":1094333,"h":0,"f":17825794}));
                    }
                    /*var*/ let tr = this.Parameter.ServiceTierId;
                    if (tr !== null && this.service !== null)
                    {
                        let $t2, $r2;
                        /*var*/ let tiers = ($t2 = this.service.LCFCP$IPaymentTierProvider$ServiceTiers.Invoke(new $.$fPer.LCFCD.DataFilter().$ctor$1()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Payment.IPaymentTier>?*/ let __ca1__;
                        this.tier = ((__ca1__ = tiers.Data) !== null ? $.$sl.SL.Enumerable.SingleOrDefault$1($.$nYKj.LCFCP.IPaymentTier, __ca1__, new ($.$$.S.Func$$$($.$nYKj.LCFCP.IPaymentTier, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                        {
                            return d.LCFCP$IPaymentTier$Id === tr;
                        }, $AMghvc ??= {"r":262145,"p":[{"n":"d","p":739096}],"n":"","d":1094333,"h":0,"f":17825794})) : null);
                    }
                    this.peerId = this.Parameter.PeerId;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015538365)
            
            //--TRIMMABLE-BOUNDARY-START(90195407549)
            /*Dictionary<String, object?> */ get Properties()
            {
                return $.$sl.SL.Enumerable.ToDictionary$5($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String, $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("TransactionId", this.Parameter.Name);
                    $i3.set_Item("Date", this.Parameter.DateCreated);
                    $i3.set_Item("Pre-Balance", this.Parameter.PreBalance);
                    $i3.set_Item("Deduction", $.$box(this.Parameter.Amount, $.$$.S.Double));
                    $i3.set_Item("Post-Balance", $.$fPer.LCFCDM.Money.op_Addition(this.Parameter.PreBalance, $.$fPer.LCFCDM.Money.op_Implicit$1(this.Parameter.Amount)));
                    return $i3;
                })(), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.Boolean))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value !== null;
                }, $SbZcOd ??= {"r":262145,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":1094333,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Key;
                }, $NMPxzj ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":1094333,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.Object))().$ctor(this,  (/*kv*/ kv) =>
                {
                    return kv.Value;
                }, $NFPXVe ??= {"r":131073,"p":[{"n":"kv","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":1094333,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(90195407549)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180963517)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180963517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180963517)
            
            //--TRIMMABLE-BOUNDARY-START(17180963517)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17180963517)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(94490374845)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(94490374845)
                
                //--TRIMMABLE-BOUNDARY-START(103080309437)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(103080309437)
                
                //--TRIMMABLE-BOUNDARY-START(81605472957)
                this.PaymentServices = null;
                //--TRIMMABLE-BOUNDARY-END(81605472957)
                
            }
            static $h = 1094333;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$Iaui.LCFCM.PaymentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310505661),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065865405,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1094333,
      "h": 77310505661,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310505661),
//--TRIMMABLE-BOUNDARY-START(94490374845),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835669181,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260178621,
        "f": 83886081
      },
      "n": "Server",
      "d": 1094333,
      "h": 94490374845,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490374845),
//--TRIMMABLE-BOUNDARY-START(103080309437),
    {
      "p": 570045,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425603773,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850113213,
        "f": 83886081
      },
      "n": "Service",
      "d": 1094333,
      "h": 103080309437,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080309437),
//--TRIMMABLE-BOUNDARY-START(81605472957),
    {
      "p": $.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655799997,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670244029,
        "f": 83886081
      },
      "n": "PaymentServices",
      "d": 1094333,
      "h": 81605472957,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605472957),
//--TRIMMABLE-BOUNDARY-START(90195407549),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245734589,
        "f": 50331650
      },
      "n": "Properties",
      "d": 1094333,
      "h": 90195407549,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90195407549)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720571069),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1094333,
      "h": 68720571069,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720571069),
//--TRIMMABLE-BOUNDARY-START(21475930813),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1094333,
      "h": 21475930813,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475930813),
//--TRIMMABLE-BOUNDARY-START(73015538365),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1094333,
      "h": 73015538365,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(73015538365)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98785342141),
    {
      "t": 1001240,
      "n": "service",
      "d": 1094333,
      "h": 98785342141,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785342141),
//--TRIMMABLE-BOUNDARY-START(133145080509),
    {
      "t": 739096,
      "n": "tier",
      "d": 1094333,
      "h": 133145080509,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133145080509),
//--TRIMMABLE-BOUNDARY-START(85900440253),
    {
      "t": 1310721,
      "n": "peerId",
      "d": 1094333,
      "h": 85900440253,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900440253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180963517),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1094333,
      "h": 17180963517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180963517)
  ],
  "h": 1094333
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillTransactionDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillTransactionDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1094333)
        
        

        //--TRIMMABLE-BOUNDARY-START(1159869)
        $asm.$cls(`$cnlM.LCBCS$1.BillTransactionListItem`, ($self) => class BillTransactionListItem extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Iaui.LCFCM.PaymentModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475996349)
            /*string */ get OptimizedComponentName()
            {
                return "billtransactionlistitem";
            }
            //--TRIMMABLE-BOUNDARY-END(21475996349)
            
            //--TRIMMABLE-BOUNDARY-START(8591094461)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591094461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591094461)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296127165)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296127165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296127165)
            
            //--TRIMMABLE-BOUNDARY-START(4296127165)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296127165)
            
            static $h = 1159869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Iaui.LCFCM.PaymentModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475996349),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181029053,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1159869,
      "h": 21475996349,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475996349)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591094461),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1159869,
      "h": 8591094461,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591094461)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296127165),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1159869,
      "h": 4296127165,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296127165)
  ],
  "h": 1159869
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Client.Shared.BillTransactionListItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Client${separator}Shared${separator}BillTransactionListItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1159869)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(45757)
