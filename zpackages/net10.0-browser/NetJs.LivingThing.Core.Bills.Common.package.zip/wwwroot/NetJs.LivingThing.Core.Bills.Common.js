
//--TRIMMABLE-BOUNDARY-START(19572)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ) {
    "use strict";
    let _;
    let $eUuyDe;
    let $enRRUd;
    let $WulfGj;
    let $amoIyd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Bills.Common", 
    {
  "h": 19572,
  "f": "LivingThing.Core.Bills.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Bills.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Bills.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(478324)
        $asm.$cls(`$xPgy.LCCBCS.BillSettingsCustomAttributesProvider`, ($self) => class BillSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295445620)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295445620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295445620)
            
            static $h = 478324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295445620),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 478324,
      "h": 4295445620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295445620)
  ],
  "h": 478324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.Settings.BillSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}Settings${separator}BillSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478324)
        
        

        //--TRIMMABLE-BOUNDARY-START(150644)
        $asm.$cls(`$xPgy.LCBCM.BillPaymentContext`, ($self) => class BillPaymentContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64424660084)
            /*IPaymentTierProvider?*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(64424660084)
            
            //--TRIMMABLE-BOUNDARY-START(107374333044)
            /*IPaymentTier?*/ Tier = null;
            //--TRIMMABLE-BOUNDARY-END(107374333044)
            
            //--TRIMMABLE-BOUNDARY-START(25769954420)
            /*IContact?*/ Contact = null;
            //--TRIMMABLE-BOUNDARY-END(25769954420)
            
            //--TRIMMABLE-BOUNDARY-START(68719627380)
            /*PaymentModel?*/ RepeatTransaction = null;
            //--TRIMMABLE-BOUNDARY-END(68719627380)
            
            //--TRIMMABLE-BOUNDARY-START(21474987124)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474987124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474987124)
            
            //--TRIMMABLE-BOUNDARY-START(21474987124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21474987124)
            
            static $h = 150644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424660084),
    {
      "p": 1001240,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949823604,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899496564,
        "f": 83886081
      },
      "n": "Provider",
      "d": 150644,
      "h": 64424660084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424660084),
//--TRIMMABLE-BOUNDARY-START(107374333044),
    {
      "p": 739096,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129692788,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079365748,
        "f": 83886081
      },
      "n": "Tier",
      "d": 150644,
      "h": 107374333044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374333044),
//--TRIMMABLE-BOUNDARY-START(25769954420),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359889012,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309561972,
        "f": 83886081
      },
      "n": "Contact",
      "d": 150644,
      "h": 25769954420,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25769954420),
//--TRIMMABLE-BOUNDARY-START(68719627380),
    {
      "p": 12592470,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539758196,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489431156,
        "f": 83886081
      },
      "n": "RepeatTransaction",
      "d": 150644,
      "h": 68719627380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719627380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474987124),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 150644,
      "h": 21474987124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474987124)
  ],
  "h": 150644
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Common.Models.BillPaymentContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Common${separator}Models${separator}BillPaymentContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150644)
        
        

        //--TRIMMABLE-BOUNDARY-START(740468)
        $asm.$cls(`$xPgy.LCCBCS$1.BillStatesCustomAttributesProvider`, ($self) => class BillStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295707764)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295707764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295707764)
            
            static $h = 740468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295707764),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 740468,
      "h": 4295707764,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295707764)
  ],
  "h": 740468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.States.BillStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}States${separator}BillStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(740468)
        
        

        //--TRIMMABLE-BOUNDARY-START(347252)
        $asm.$cls(`$xPgy.LCBC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295314548)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295314548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xPgy.LCCBCS.BillSettingsTypeDescriptorBuilder.Register();
                $.$xPgy.LCCBCS$1.BillStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4295314548)
            
            static $h = 347252;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295314548),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 347252,
      "h": 4295314548,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295314548)
  ],
  "h": 347252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(347252)
        
        

        //--TRIMMABLE-BOUNDARY-START(609396)
        $asm.$cls(`$xPgy.LCCBCS.BillSettingsTypeDescriptorBuilder`, ($self) => class BillSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590543988)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590543988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xPgy.LCCBCS.BillSettingsTypeDescriptor()
                        const $t1 = $.$xPgy.LCCBCS.BillSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Bill.Common.Settings.BillSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eUuyDe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":609396,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xPgy.LCCBCS.BillSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590543988)
            
            //--TRIMMABLE-BOUNDARY-START(4295576692)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295576692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295576692)
            
            //--TRIMMABLE-BOUNDARY-START(4295576692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295576692)
            
            static $h = 609396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590543988),
    {
      "r": 65537,
      "n": "Register",
      "d": 609396,
      "h": 8590543988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590543988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295576692),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 609396,
      "h": 4295576692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295576692)
  ],
  "h": 609396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.Settings.BillSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}Settings${separator}BillSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(609396)
        
        

        //--TRIMMABLE-BOUNDARY-START(871540)
        $asm.$cls(`$xPgy.LCCBCS$1.BillStatesTypeDescriptorBuilder`, ($self) => class BillStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590806132)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590806132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xPgy.LCCBCS$1.BillStatesTypeDescriptor()
                        const $t1 = $.$xPgy.LCCBCS$1.BillStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Bill.Common.States.BillStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WulfGj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":871540,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xPgy.LCCBCS$1.BillStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590806132)
            
            //--TRIMMABLE-BOUNDARY-START(4295838836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295838836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295838836)
            
            //--TRIMMABLE-BOUNDARY-START(4295838836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295838836)
            
            static $h = 871540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590806132),
    {
      "r": 65537,
      "n": "Register",
      "d": 871540,
      "h": 8590806132,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590806132)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295838836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 871540,
      "h": 4295838836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295838836)
  ],
  "h": 871540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.States.BillStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}States${separator}BillStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(871540)
        
        

        //--TRIMMABLE-BOUNDARY-START(85108)
        $asm.$cls(`$xPgy.LCBC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295052404)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295052404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xPgy.LCCBCS.BillSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xPgy.LCCBCS.BillSettingsCustomAttributesProvider, $.$xPgy.LCCBCS.BillSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xPgy.LCCBCS$1.BillStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xPgy.LCCBCS$1.BillStatesCustomAttributesProvider, $.$xPgy.LCCBCS$1.BillStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295052404)
            
            static $h = 85108;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295052404),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 85108,
      "h": 4295052404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295052404)
  ],
  "h": 85108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85108)
        
        

        //--TRIMMABLE-BOUNDARY-START(281716)
        $asm.$cls(`$xPgy.LCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590216308)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590216308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590216308)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$xPgy.LCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295249012)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295249012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295249012)
            
            //--TRIMMABLE-BOUNDARY-START(4295249012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295249012)
            
            static $h = 281716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590216308),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 281716,
      "h": 8590216308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590216308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295249012),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 281716,
      "h": 4295249012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295249012)
  ],
  "h": 281716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(281716)
        
        

        //--TRIMMABLE-BOUNDARY-START(216180)
        $asm.$cls(`$xPgy.LCBCM.BillUserPreference`, ($self) => class BillUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295183476)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295183476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295183476)
            
            //--TRIMMABLE-BOUNDARY-START(4295183476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295183476)
            
            static $h = 216180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295183476),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 216180,
      "h": 4295183476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295183476)
  ],
  "h": 216180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Bills.Common.Models.BillUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Bills${separator}Common${separator}Models${separator}BillUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216180)
        
        

        //--TRIMMABLE-BOUNDARY-START(674932)
        $asm.$cls(`$xPgy.LCCBCS$1.BillStates`, ($self) => class BillStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4295642228)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295642228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295642228)
            
            //--TRIMMABLE-BOUNDARY-START(4295642228)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295642228)
            
            static $h = 674932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295642228),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 674932,
      "h": 4295642228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295642228)
  ],
  "h": 674932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.States.BillStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}States${separator}BillStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(674932)
        
        

        //--TRIMMABLE-BOUNDARY-START(412788)
        $asm.$cls(`$xPgy.LCCBCS.BillSettings`, ($self) => class BillSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4295380084)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295380084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295380084)
            
            //--TRIMMABLE-BOUNDARY-START(4295380084)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295380084)
            
            static $h = 412788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295380084),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 412788,
      "h": 4295380084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295380084)
  ],
  "h": 412788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.Settings.BillSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}Settings${separator}BillSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(412788)
        
        

        //--TRIMMABLE-BOUNDARY-START(806004)
        $asm.$cls(`$xPgy.LCCBCS$1.BillStatesTypeDescriptor`, ($self) => class BillStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xPgy.LCCBCS$1.BillStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295773300)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295773300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xPgy.LCCBCS$1.BillStatesTypeDescriptor.GenerateProperties($.$xPgy.LCCBCS$1.BillStates, this, factory);
                    }, $amoIyd ??= {"r":65537,"n":"","d":806004,"h":0,"f":17825794}), 0, "BillStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Bills.Common\\States_BillStates_LivingThing.Core.Community.Bill.Common.States.BillStatesTypeDescriptorBuilder.g.cs", "BillStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295773300)
            
            //--TRIMMABLE-BOUNDARY-START(12885707892)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885707892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885707892)
            
            //--TRIMMABLE-BOUNDARY-START(17180675188)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Bill.Common.States.BillStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180675188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180675188)
            
            //--TRIMMABLE-BOUNDARY-START(8590740596)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Bill.Common.States.BillStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590740596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xPgy.LCCBCS$1.BillStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xPgy.LCCBCS$1.BillStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS$1.BillStates)))
                {
                    /*var*/ let result = $.$xPgy.LCCBCS$1.BillStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS$1.BillStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xPgy.LCCBCS$1.BillStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS$1.BillStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590740596)
            
            static $h = 806004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xPgy.LCCBCS$1.BillStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885707892),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 806004,
      "h": 12885707892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885707892),
//--TRIMMABLE-BOUNDARY-START(17180675188),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 674932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 806004,
      "h": 17180675188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180675188),
//--TRIMMABLE-BOUNDARY-START(8590740596),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 674932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 806004,
      "h": 8590740596,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590740596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295773300),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 806004,
      "h": 4295773300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295773300)
  ],
  "h": 806004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xPgy.LCCBCS$1.BillStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.States.BillStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}States${separator}BillStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(806004)
        
        

        //--TRIMMABLE-BOUNDARY-START(543860)
        $asm.$cls(`$xPgy.LCCBCS.BillSettingsTypeDescriptor`, ($self) => class BillSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xPgy.LCCBCS.BillSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4295511156)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295511156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xPgy.LCCBCS.BillSettingsTypeDescriptor.GenerateProperties($.$xPgy.LCCBCS.BillSettings, this, factory);
                    }, $enRRUd ??= {"r":65537,"n":"","d":543860,"h":0,"f":17825794}), 0, "BillSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Bills.Common\\Settings_BillSettings_LivingThing.Core.Community.Bill.Common.Settings.BillSettingsTypeDescriptorBuilder.g.cs", "BillSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295511156)
            
            //--TRIMMABLE-BOUNDARY-START(12885445748)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885445748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885445748)
            
            //--TRIMMABLE-BOUNDARY-START(17180413044)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Bill.Common.Settings.BillSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180413044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180413044)
            
            //--TRIMMABLE-BOUNDARY-START(8590478452)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Bill.Common.Settings.BillSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590478452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xPgy.LCCBCS.BillSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xPgy.LCCBCS.BillSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS.BillSettings)))
                {
                    /*var*/ let result = $.$xPgy.LCCBCS.BillSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS.BillSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xPgy.LCCBCS.BillSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xPgy.LCCBCS.BillSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590478452)
            
            static $h = 543860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xPgy.LCCBCS.BillSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885445748),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 543860,
      "h": 12885445748,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885445748),
//--TRIMMABLE-BOUNDARY-START(17180413044),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 412788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 543860,
      "h": 17180413044,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180413044),
//--TRIMMABLE-BOUNDARY-START(8590478452),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 412788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 543860,
      "h": 8590478452,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590478452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295511156),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 543860,
      "h": 4295511156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295511156)
  ],
  "h": 543860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xPgy.LCCBCS.BillSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Bill.Common.Settings.BillSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Bill${separator}Common${separator}Settings${separator}BillSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(543860)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product"));
})();
//--TRIMMABLE-BOUNDARY-END(19572)
