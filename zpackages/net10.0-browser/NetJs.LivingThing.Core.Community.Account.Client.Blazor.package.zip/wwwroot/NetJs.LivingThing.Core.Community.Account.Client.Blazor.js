
//--TRIMMABLE-BOUNDARY-START(43389)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $EruoAd;
    let $ZLxSGj;
    let $pUfEQc;
    let $Djslkl;
    let $XwtDih;
    let $NeIdWb;
    let $AvuRac;
    let $BNEXPd;
    let $OXtrPj;
    let $RpSoCh;
    let $AJZpQk;
    let $egaTBc;
    let $Enypok;
    let $tHcvDf;
    let $yHwKbg;
    let $Xxxuwe;
    let $tBxCTe;
    let $kmOqsi;
    let $iBRHgi;
    let $zNMumd;
    let $bayxUj;
    let $uaSDyb;
    let $UmslCi;
    let $wsqahh;
    let $LQbarb;
    let $AKPBwg;
    let $VTpBRf;
    let $HQUjci;
    let $AgFfYi;
    let $hoWRCi;
    let $YucGga;
    let $NRiwLf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Account.Client.Blazor", 
    {
  "h": 43389,
  "f": "LivingThing.Core.Community.Account.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Account.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Account.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(239997)
        $asm.$cls(`$GYJg.LCCAC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295207293)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295207293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$GYJg.LCCAC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295207293)
            
            static $h = 239997;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295207293),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 239997,
      "h": 4295207293,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295207293)
  ],
  "h": 239997
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(239997)
        
        

        //--TRIMMABLE-BOUNDARY-START(108925)
        $asm.$cls(`$GYJg._LCCACPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295076221)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::System.Int32?*/ __arg1, /*int*/ __seq2, /*global::System.Int32?*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295076221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "GridGap", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "GridWidth", $.$box(__arg2, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq4, "ChildContent", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295076221)
            
            static $h = 108925;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295076221),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 14505642
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 108925,
      "h": 4295076221,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295076221)
  ],
  "h": 108925
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Account.Client.Pages.CommunityAccountApp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}Pages${separator}CommunityAccountApp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(108925)
        
        

        //--TRIMMABLE-BOUNDARY-START(436605)
        $asm.$cls(`$GYJg.LCCAC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590371197)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590371197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$lJUR.LCFCS.IApplicationPageDataFromPathProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.CommunityAccountApplicationContextProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$GYJg.LCCACS.CommunityAccountApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GYJg.LCCACS.CommunityAccountApplication, x);
                }, $ZLxSGj ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":436605,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GYJg.LCCACS.CommunityAccountApplication, x);
                }, $pUfEQc ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":436605,"h":0,"f":17825794}));
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$ahDc.LCCCS.CommunityAccountService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$LCOv.LCFCPM$1.AccountModel, services);
                $.$GYJg.LCCAC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590371197)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$GYJg.LCCAC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295403901)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295403901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295403901)
            
            //--TRIMMABLE-BOUNDARY-START(4295403901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295403901)
            
            static $h = 436605;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590371197),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 436605,
      "h": 8590371197,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590371197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295403901),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 436605,
      "h": 4295403901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295403901)
  ],
  "h": 436605
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(436605)
        
        

        //--TRIMMABLE-BOUNDARY-START(305533)
        $asm.$cls(`$GYJg.LCCAC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180174717)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$GYJg.LCCACP.CommunityAccountApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$GYJg.LCCACP.CommunityAccountApp().$ctor$3();
                    }, $EruoAd ??= {"r":2752627,"n":"","d":305533,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180174717)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295272829)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295272829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295272829)
            
            //--TRIMMABLE-BOUNDARY-START(4295272829)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295272829)
            
            static $h = 305533;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180174717),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885207421,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 305533,
      "h": 17180174717,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180174717)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295272829),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 305533,
      "h": 4295272829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295272829)
  ],
  "h": 305533
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(305533)
        
        

        //--TRIMMABLE-BOUNDARY-START(567677)
        $asm.$cls(`$GYJg.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295534973)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295534973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295534973)
            
            //--TRIMMABLE-BOUNDARY-START(4295534973)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295534973)
            
            static $h = 567677;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295534973),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 567677,
      "h": 4295534973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295534973)
  ],
  "h": 567677
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(567677)
        
        

        //--TRIMMABLE-BOUNDARY-START(633213)
        $asm.$cls(`$GYJg.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295600509)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295600509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295600509)
            
            //--TRIMMABLE-BOUNDARY-START(4295600509)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295600509)
            
            static $h = 633213;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295600509),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 633213,
      "h": 4295600509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295600509)
  ],
  "h": 633213,
  "a": [
    {
      "t": 567677,
      "c": 4295534973
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(633213)
        
        

        //--TRIMMABLE-BOUNDARY-START(174461)
        $asm.$cls(`$GYJg.LCCAC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590109053)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590109053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590109053)
            
            //--TRIMMABLE-BOUNDARY-START(4295141757)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295141757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295141757)
            
            //--TRIMMABLE-BOUNDARY-START(4295141757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295141757)
            
            static $h = 174461;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590109053),
    {
      "r": 65537,
      "n": "Execute",
      "d": 174461,
      "h": 8590109053,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590109053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295141757),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 174461,
      "h": 4295141757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295141757)
  ],
  "h": 174461
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(174461)
        
        

        //--TRIMMABLE-BOUNDARY-START(371069)
        $asm.$cls(`$GYJg.LCCACP.CommunityAccountApp`, ($self) => class CommunityAccountApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42950044029)
            /*ICommentProvider*/ CommentProvider = null;
            //--TRIMMABLE-BOUNDARY-END(42950044029)
            
            //--TRIMMABLE-BOUNDARY-START(47245011325)
            /*ICommunityApplicationDeployment*/ Deployment = null;
            //--TRIMMABLE-BOUNDARY-END(47245011325)
            
            //--TRIMMABLE-BOUNDARY-START(111669520765)
            /*CommunityAccountService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(111669520765)
            
            //--TRIMMABLE-BOUNDARY-START(30065142141)
            /*CommunityAccountApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(30065142141)
            
            //--TRIMMABLE-BOUNDARY-START(34360109437)
            /*IEnumerable<IBadgeProvider>*/ BadgeProviders = null;
            //--TRIMMABLE-BOUNDARY-END(34360109437)
            
            //--TRIMMABLE-BOUNDARY-START(107374553469)
            /*string */ get OptimizedComponentName()
            {
                return "communityaccountapp";
            }
            //--TRIMMABLE-BOUNDARY-END(107374553469)
            
            //--TRIMMABLE-BOUNDARY-START(103079586173)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079586173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.CommentProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.ICommentProvider, serviceProvider);
                this.Deployment = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityApplicationDeployment, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.CommunityAccountService, serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$GYJg.LCCACS.CommunityAccountApplication, serviceProvider);
                this.BadgeProviders = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPS.IBadgeProvider), serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(103079586173)
            
            //--TRIMMABLE-BOUNDARY-START(38655076733)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655076733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Accounts");
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddAttribute$3(4, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 5);
                        __builder2.AddComponentParameter(6, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(8, wrap.View);
                        }), $Djslkl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $XwtDih ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                }), $NeIdWb ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":371069,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 10);
                        __builder2.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this.Service));
                        __builder2.CloseComponent();
                    }, $AvuRac ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                }), $BNEXPd ??= {"r":6881395,"p":[{"n":"context","p":6303817}],"n":"","d":371069,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 13);
                    __builder2.AddComponentParameter(14, "Name", "Badges");
                    __builder2.AddAttribute$3(15, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(16, "Badges");
                        }, $OXtrPj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $RpSoCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(17, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(18, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-shield"), false));
                        }, $AJZpQk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $egaTBc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 20);
                            __builder3.AddComponentParameter(21, "Class", "mgb");
                            __builder3.AddComponentParameter(22, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Deployment.LCFC$IDisplayable$Title));
                            __builder3.AddComponentParameter(23, "SubTitle", "Badges");
                            __builder3.CloseComponent();
                            /*var*/ let badges = $.$sl.SL.Enumerable.SelectMany$2($.$LCOv.LCFCPS.IBadgeProvider, $.$LCOv.LCFCPMB.BadgeModel, this.BadgeProviders, new ($.$$.S.Func$$$($.$LCOv.LCFCPS.IBadgeProvider, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMB.BadgeModel)))().$ctor(this,  (/*b*/ b) =>
                            {
                                return b.LCFCPS$IBadgeProvider$GetBadges();
                            }, $Enypok ??= {"r":$.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMB.BadgeModel).$h,"p":[{"n":"b","p":25881012}],"n":"","d":371069,"h":0,"f":17825794}));
                            $.$GYJg._LCCACPC.TypeInference.CreateDataList_0($.$LCOv.LCFCPMB.BadgeModel, __builder3, 24, 25, badges, 26, $.$ahDc.LCCC.Utility.GridGap$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box), 27, $.$ahDc.LCCC.Utility.GridWidth$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box), 28, 35184372092928n | 8192n, 29, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMB.BadgeModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMB.BadgeModel))))().$ctor(this,  (/*badge*/ badge) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSB.CommunityBadgeCard, 30);
                                    __builder4.AddComponentParameter(31, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPMB.BadgeModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMB.BadgeModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMB.BadgeModel)).op_Implicit$1(badge)));
                                    __builder4.CloseComponent();
                                }, $tHcvDf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                            }, $yHwKbg ??= {"r":6881395,"p":[{"n":"badge","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMB.BadgeModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMB.BadgeModel)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                        }, $Xxxuwe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $tBxCTe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(32, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 33);
                    __builder2.AddComponentParameter(34, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(35, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ | 128/*ApplicationPageFeatures.Search*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddAttribute$3(36, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(37, "Members");
                        }, $kmOqsi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $iBRHgi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(38, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(39, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account"), false));
                        }, $zNMumd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $bayxUj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(40, "SearchPopup", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(41, $.$ahDc.LCCCS$1.CommunityUtility.GetSearch($.$LCOv.LCFCPM$1.AccountModel, $.$$.S.Object, context.Model.LCFCS$IApplicationPageContext$SearchKey, null, null, null));
                        }, $uaSDyb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $UmslCi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 43);
                            __builder3.AddComponentParameter(44, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), $.$ahDc.LCCC.Utility.GridGap$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$$.S.Int32));
                            __builder3.AddComponentParameter(45, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.AddComponentParameter(46, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                            __builder3.AddComponentParameter(47, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n | 65536n | 524288n | 70368744177664n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddAttribute$3(48, "CustomRenderer", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*render*/ render) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 49);
                                    __builder4.AddComponentParameter(50, "Class", "mgb");
                                    __builder4.AddComponentParameter(51, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Deployment.LCFC$IDisplayable$Title));
                                    __builder4.AddComponentParameter(52, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `MEMBERS (${$.$strNN(render.DataList.DataManager.TotalItems)})`));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(53, "\r\n                        ");
                                    __builder4.AddContent$1(54, render.DefaultRenderer.Invoke(render.DataList, render.Data, null));
                                }, $wsqahh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                            }), $LQbarb ??= {"r":6881395,"p":[{"n":"render","p":$.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(55, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*account*/ account) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(56, "div");
                                    __builder4.AddAttribute$5(57, "class", "stack text-center");
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountCard, 58);
                                    __builder4.AddComponentParameter(59, "Link", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, false), $.$$.S.Boolean));
                                    __builder4.AddComponentParameter(60, "Class", "mg-a");
                                    __builder4.AddComponentParameter(61, "Account", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).op_Implicit$1(account)));
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(62, "\r\n                            ");
                                    __builder4.OpenElement(63, "span");
                                    __builder4.AddAttribute$5(64, "class", "lh-1 fsz-10 op-8");
                                    __builder4.AddAttribute$4(65, "title", account.Model.DateCreated);
                                    __builder4.AddContent$4(66, "Joined ");
                                    __builder4.AddContent$4(67, $.$fPer.LCFCDC.DateTimeExtension.Ago$2(account.Model.DateCreated, 2147483647));
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }, $AKPBwg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                            }), $VTpBRf ??= {"r":6881395,"p":[{"n":"account","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(68, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*account*/ account) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountDetailsInApplicationDrawer, 69);
                                    __builder4.AddComponentParameter(70, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, account.Data));
                                    __builder4.CloseComponent();
                                }, $HQUjci ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                            }), $AgFfYi ??= {"r":6881395,"p":[{"n":"account","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $hoWRCi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":371069,"h":0,"f":17825794});
                    }), $YucGga ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":371069,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $NRiwLf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":371069,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38655076733)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25770174845)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770174845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770174845)
            
            //--TRIMMABLE-BOUNDARY-START(25770174845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770174845)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950044029)
                this.CommentProvider = null;
                //--TRIMMABLE-BOUNDARY-END(42950044029)
                
                //--TRIMMABLE-BOUNDARY-START(47245011325)
                this.Deployment = null;
                //--TRIMMABLE-BOUNDARY-END(47245011325)
                
                //--TRIMMABLE-BOUNDARY-START(111669520765)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(111669520765)
                
                //--TRIMMABLE-BOUNDARY-START(30065142141)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(30065142141)
                
                //--TRIMMABLE-BOUNDARY-START(34360109437)
                this.BadgeProviders = null;
                //--TRIMMABLE-BOUNDARY-END(34360109437)
                
            }
            static $h = 371069;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950044029),
    {
      "p": 63723178,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014815101,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439324541,
        "f": 83886081
      },
      "n": "CommentProvider",
      "d": 371069,
      "h": 42950044029,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950044029),
//--TRIMMABLE-BOUNDARY-START(47245011325),
    {
      "p": 17012160,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604749693,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029259133,
        "f": 83886081
      },
      "n": "Deployment",
      "d": 371069,
      "h": 47245011325,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245011325),
//--TRIMMABLE-BOUNDARY-START(111669520765),
    {
      "p": 15177152,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784618877,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619193725,
        "f": 83886081
      },
      "n": "Service",
      "d": 371069,
      "h": 111669520765,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669520765),
//--TRIMMABLE-BOUNDARY-START(30065142141),
    {
      "p": 502141,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834945917,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259455357,
        "f": 83886081
      },
      "n": "Application",
      "d": 371069,
      "h": 30065142141,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065142141),
//--TRIMMABLE-BOUNDARY-START(34360109437),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPS.IBadgeProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424880509,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849389949,
        "f": 83886081
      },
      "n": "BadgeProviders",
      "d": 371069,
      "h": 34360109437,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360109437),
//--TRIMMABLE-BOUNDARY-START(107374553469),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194684285,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 371069,
      "h": 107374553469,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374553469)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079586173),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 371069,
      "h": 103079586173,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103079586173),
//--TRIMMABLE-BOUNDARY-START(38655076733),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 371069,
      "h": 38655076733,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655076733)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770174845),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 371069,
      "h": 25770174845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770174845)
  ],
  "h": 371069
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client.Pages.CommunityAccountApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}Pages${separator}CommunityAccountApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(371069)
        
        

        //--TRIMMABLE-BOUNDARY-START(502141)
        $asm.$cls(`$GYJg.LCCACS.CommunityAccountApplication`, ($self) => class CommunityAccountApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885404029)
            $ctor$5(/*CommunityAccountService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885404029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885404029)
            
            //--TRIMMABLE-BOUNDARY-START(128849521021)
            /*int */ get Order()
            {
                return 5000;
            }
            //--TRIMMABLE-BOUNDARY-END(128849521021)
            
            //--TRIMMABLE-BOUNDARY-START(124554553725)
            /*string */ get Name()
            {
                return "Accounts";
            }
            //--TRIMMABLE-BOUNDARY-END(124554553725)
            
            //--TRIMMABLE-BOUNDARY-START(146029390205)
            /*string */ get Title()
            {
                return "Accounts";
            }
            //--TRIMMABLE-BOUNDARY-END(146029390205)
            
            //--TRIMMABLE-BOUNDARY-START(17180371325)
            /*string */ get Description()
            {
                return "Profile info, messages, settings and much more!";
            }
            //--TRIMMABLE-BOUNDARY-END(17180371325)
            
            //--TRIMMABLE-BOUNDARY-START(120259586429)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-account"/*MaterialDesignIconNames.Account*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120259586429)
            
            //--TRIMMABLE-BOUNDARY-START(141734422909)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2374AB";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141734422909)
            
            //--TRIMMABLE-BOUNDARY-START(115964619133)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964619133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$GYJg.LCCACP.CommunityAccountApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115964619133)
            
            //--TRIMMABLE-BOUNDARY-START(21475338621)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475338621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(21475338621)
            
            //--TRIMMABLE-BOUNDARY-START(133144488317)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144488317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(133144488317)
            
            //--TRIMMABLE-BOUNDARY-START(4295469437)
            /*CommunityAccountService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295469437)
            
            //--TRIMMABLE-BOUNDARY-START(137439455613)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(137439455613)
            
            //--TRIMMABLE-BOUNDARY-START(25770305917)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(25770305917)
            
            //--TRIMMABLE-BOUNDARY-START(150324357501)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(2048/*PostTypes.Account*/, 2049/*PostTypes.AccountEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150324357501)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 502141;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128849521021),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309913469,
        "f": 50364417
      },
      "n": "Order",
      "d": 502141,
      "h": 128849521021,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849521021),
//--TRIMMABLE-BOUNDARY-START(124554553725),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719978877,
        "f": 50364417
      },
      "n": "Name",
      "d": 502141,
      "h": 124554553725,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554553725),
//--TRIMMABLE-BOUNDARY-START(146029390205),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079717245,
        "f": 50364417
      },
      "n": "Title",
      "d": 502141,
      "h": 146029390205,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029390205),
//--TRIMMABLE-BOUNDARY-START(17180371325),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950175101,
        "f": 50364417
      },
      "n": "Description",
      "d": 502141,
      "h": 17180371325,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180371325),
//--TRIMMABLE-BOUNDARY-START(120259586429),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130044285,
        "f": 50364417
      },
      "n": "Icon",
      "d": 502141,
      "h": 120259586429,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259586429),
//--TRIMMABLE-BOUNDARY-START(141734422909),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489782653,
        "f": 50364417
      },
      "n": "Theme",
      "d": 502141,
      "h": 141734422909,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734422909),
//--TRIMMABLE-BOUNDARY-START(4295469437),
    {
      "p": 15177152,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360240509,
        "f": 50331650
      },
      "n": "_Service",
      "d": 502141,
      "h": 4295469437,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295469437),
//--TRIMMABLE-BOUNDARY-START(137439455613),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899848061,
        "f": 50364417
      },
      "n": "Service",
      "d": 502141,
      "h": 137439455613,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439455613),
//--TRIMMABLE-BOUNDARY-START(25770305917),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540109693,
        "f": 50364417
      },
      "n": "Features",
      "d": 502141,
      "h": 25770305917,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770305917),
//--TRIMMABLE-BOUNDARY-START(150324357501),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669651837,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 502141,
      "h": 150324357501,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324357501)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964619133),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 502141,
      "h": 115964619133,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(115964619133),
//--TRIMMABLE-BOUNDARY-START(21475338621),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 502141,
      "h": 21475338621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475338621),
//--TRIMMABLE-BOUNDARY-START(133144488317),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 502141,
      "h": 133144488317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144488317)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885404029),
    {
      "p": [
        {
          "n": "service",
          "p": 15177152
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 502141,
      "h": 12885404029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885404029)
  ],
  "h": 502141
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$LCOv.LCFCPM$1.AccountModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Account.Client.Services.CommunityAccountApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Account${separator}Client${separator}Services${separator}CommunityAccountApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(502141)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(43389)
