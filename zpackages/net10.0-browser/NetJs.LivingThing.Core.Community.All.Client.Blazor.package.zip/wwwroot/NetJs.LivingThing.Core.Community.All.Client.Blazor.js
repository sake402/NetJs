
//--TRIMMABLE-BOUNDARY-START(52023)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mbc, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $mia, $mil, $mexl, $mit, $mij, $sih, $wZnq, $fnTP, $hqRR, $sitj, $Xjnw, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $uVBI, $yJPN, $yleQ, $nYKj, $AvdQ, $xPgy, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $xrPB, $BrCm, $OkRL, $wQhY, $oUrI, $tjSj, $RffN, $jfJD, $OnVo, $Filo, $bTOs, $tUzp, $Bykq, $qbhX, $PZCj, $yCMk, $PIIp, $cDXw, $pGPn, $IHYd, $ZaYa, $OUNt, $aImc, $dRCs, $UcdF, $JRhp, $bRsy, $Gjye, $SXZI, $TLvC, $TBFc, $Jsis, $lAxY, $gUjM, $WcGF, $QcZy, $tCiC, $uERE, $XtuU, $wmbl, $RoTr, $vOBI, $xvUV, $sQJD, $sUMr, $GETr, $Gokg, $fMQq, $ftPx, $Qqwn, $mMXL, $IUsF, $Fjop, $JkHl, $AEuu, $fXpo, $KuVO, $MICX, $OSmP, $QxAa, $hkBT, $Vfzz, $anJf, $GeIp, $fbjj, $UQAj, $irDD, $Mstz, $lmlW, $izAa, $FuXl, $aAgx, $dXSd, $dqzR, $OCet, $fycR, $awPs, $DiFq, $bMcF, $rfUg, $aElv, $yyXP, $eFOo, $lOHy, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $ntej, $MCAB, $Urjw, $fJEF, $oAeB, $MXzz, $BHhH, $dRBU, $uXRA, $MDmQ) {
    "use strict";
    let _;
    let $REEhrj;
    let $qYsDIk;
    let $PdZESi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.All.Client.Blazor", 
    {
  "h": 52023,
  "f": "LivingThing.Core.Community.All.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159973377,
      "c": 13044875265,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107741185,
      "c": 8697675777,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108593153,
      "c": 8698527745,
      "a": [
        {
          "v": "LivingThing.Core.Community.All.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108724225,
      "c": 8698658817,
      "a": [
        {
          "v": "LivingThing.Core.Community.All.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108855297,
      "c": 8698789889,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(117559)
        $asm.$cls(`$sAEu.LCCAC.CommunityStartup`, ($self) => class CommunityStartup
        {
            //--TRIMMABLE-BOUNDARY-START(4295084855)
            static /*void */ LoadAndRegisterCommunityStartupAssemblyModules(/*this IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295084855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$YUlm.LCSC.ServiceRegistrar.$type.Assembly;
                _ = $.$DZqk.LCAC.ServiceRegistrar.$type.Assembly;
                _ = $.$uVBI.LCAC.ServiceRegistrar.$type.Assembly;
                _ = $.$yJPN.LCACO.ServiceRegistrar.$type.Assembly;
                _ = $.$ydCm.LCCC.ServiceRegistrar.$type.Assembly;
                _ = $.$ahDc.LCCC.ServiceRegistrar.$type.Assembly;
                /*var*/ let assemblies = $.$sl.SL.Enumerable.Where($.$$.SR.Assembly, $.$$.S.AppDomain.CurrentDomain.GetAssemblies(), new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    /*string?*/ let __ca1__;
                    return ((__ca1__ = a.GetName().Name) !== null ? $.$$.S.String.StartsWith$3.call(__ca1__, "LivingThing.") : false);
                }, $REEhrj ??= {"r":262145,"p":[{"n":"a","p":106954753}],"n":"","d":117559,"h":0,"f":17825794}));
                $.$fPer.LCFCS$3.ServiceCollectionBuilderExtension.RegisterAssemblyServices(services, configuration, $.$clone(options), assemblies);
            }
            //--TRIMMABLE-BOUNDARY-END(4295084855)
            
            //--TRIMMABLE-BOUNDARY-START(8590052151)
            static /*void */ LoadAndRegisterLazyCommunityAssemblyModules(/*this IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590052151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let initialAssemblies = $.$sl.SL.Enumerable.Where($.$$.SR.Assembly, $.$$.S.AppDomain.CurrentDomain.GetAssemblies(), new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    /*string?*/ let __ca2__;
                    return ((__ca2__ = a.GetName().Name) !== null ? $.$$.S.String.StartsWith$3.call(__ca2__, "LivingThing.") : false);
                }, $qYsDIk ??= {"r":262145,"p":[{"n":"a","p":106954753}],"n":"","d":117559,"h":0,"f":17825794}));
                /*void*/  function ForceLoadAssemblies()
                {
                    _ = $.$dgLE.LCPC.ServiceRegistrar.$type.Assembly;
                    _ = $.$ydCm.LCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$ahDc.LCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$xrPB.LCCAC.ServiceRegistrar.$type.Assembly;
                    _ = $.$BrCm.LCCAC.ServiceRegistrar.$type.Assembly;
                    _ = $.$jlvo.LCCAC.ServiceRegistrar.$type.Assembly;
                    _ = $.$GYJg.LCCAC.ServiceRegistrar.$type.Assembly;
                    _ = $.$OkRL.LCCBC.ServiceRegistrar.$type.Assembly;
                    _ = $.$wQhY.LCCBC.ServiceRegistrar.$type.Assembly;
                    _ = $.$RffN.LCCBC.ServiceRegistrar.$type.Assembly;
                    _ = $.$jfJD.LCCBC.ServiceRegistrar.$type.Assembly;
                    _ = $.$OnVo.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Filo.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$bTOs.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$tUzp.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Bykq.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$qbhX.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$yCMk.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$pGPn.LCCCC.ServiceRegistrar.$type.Assembly;
                    _ = $.$FuXl.LCCRC.ServiceRegistrar.$type.Assembly;
                    _ = $.$aAgx.LCCRC.ServiceRegistrar.$type.Assembly;
                    _ = $.$ZaYa.LCCTC.ServiceRegistrar.$type.Assembly;
                    _ = $.$aImc.LCCTC.ServiceRegistrar.$type.Assembly;
                    _ = $.$dRCs.LCCD.ServiceRegistrar.$type.Assembly;
                    _ = $.$bRsy.LCCDC.ServiceRegistrar.$type.Assembly;
                    _ = $.$TLvC.LCCDC.ServiceRegistrar.$type.Assembly;
                    _ = $.$lAxY.LCCFC.ServiceRegistrar.$type.Assembly;
                    _ = $.$gUjM.LCCFC.ServiceRegistrar.$type.Assembly;
                    _ = $.$WcGF.LCCFC.ServiceRegistrar.$type.Assembly;
                    _ = $.$QcZy.LCCFC.ServiceRegistrar.$type.Assembly;
                    _ = $.$tCiC.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$uERE.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$XtuU.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$wmbl.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$PZCj.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$PIIp.LCCGC.ServiceRegistrar.$type.Assembly;
                    _ = $.$RoTr.LCCGUC.ServiceRegistrar.$type.Assembly;
                    _ = $.$vOBI.LCCGUC.ServiceRegistrar.$type.Assembly;
                    _ = $.$irDD.LCCOC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Mstz.LCCOC.ServiceRegistrar.$type.Assembly;
                    _ = $.$UcdF.LCCHC.ServiceRegistrar.$type.Assembly;
                    _ = $.$SXZI.LCCHC.ServiceRegistrar.$type.Assembly;
                    _ = $.$xvUV.LCCJC.ServiceRegistrar.$type.Assembly;
                    _ = $.$sQJD.LCCJC.ServiceRegistrar.$type.Assembly;
                    _ = $.$sUMr.LCCJC.ServiceRegistrar.$type.Assembly;
                    _ = $.$GETr.LCCJC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Gokg.LCCLC.ServiceRegistrar.$type.Assembly;
                    _ = $.$fMQq.LCCLC.ServiceRegistrar.$type.Assembly;
                    _ = $.$mMXL.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$IUsF.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Fjop.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$MICX.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$OSmP.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$QxAa.LCCMC.ServiceRegistrar.$type.Assembly;
                    _ = $.$hkBT.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Vfzz.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$anJf.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$GeIp.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$fbjj.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$UQAj.LCCNC.ServiceRegistrar.$type.Assembly;
                    _ = $.$lmlW.LCCPC.ServiceRegistrar.$type.Assembly;
                    _ = $.$izAa.LCCPC.ServiceRegistrar.$type.Assembly;
                    _ = $.$dXSd.LCCRC.ServiceRegistrar.$type.Assembly;
                    _ = $.$dqzR.LCCRC.ServiceRegistrar.$type.Assembly;
                    _ = $.$OCet.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$awPs.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$DiFq.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$Urjw.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$fJEF.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$oAeB.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$MXzz.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$BHhH.LCCSC.ServiceRegistrar.$type.Assembly;
                    _ = $.$AEuu.LCCWC.ServiceRegistrar.$type.Assembly;
                    _ = $.$MDmQ.LCCWC.ServiceRegistrar.$type.Assembly;
                }
                ForceLoadAssemblies.call(this);
                $.$fPer.LCFCS$3.ServiceCollectionBuilderExtension.RegisterAssemblyServices(services, configuration, $.$clone(options), $.$sl.SL.Enumerable.Except$1($.$$.SR.Assembly, $.$sl.SL.Enumerable.Where($.$$.SR.Assembly, $.$$.S.AppDomain.CurrentDomain.GetAssemblies(), new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    /*string?*/ let __ca3__;
                    return ((__ca3__ = a.GetName().Name) !== null ? $.$$.S.String.StartsWith$3.call(__ca3__, "LivingThing.") : false);
                }, $PdZESi ??= {"r":262145,"p":[{"n":"a","p":106954753}],"n":"","d":117559,"h":0,"f":17825794})), initialAssemblies));
                initialAssemblies = null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590052151)
            
            //--TRIMMABLE-BOUNDARY-START(12885019447)
            static /*void */ RegisterAllCommunityModules(/*this IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885019447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ydCm.LCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$ahDc.LCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$xrPB.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$BrCm.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$jlvo.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$GYJg.LCCAC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$OkRL.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$wQhY.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$RffN.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$jfJD.LCCBC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$OnVo.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Filo.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$bTOs.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$tUzp.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Bykq.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$qbhX.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$yCMk.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$pGPn.LCCCC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$FuXl.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$aAgx.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$ZaYa.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$aImc.LCCTC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$dRCs.LCCD.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$bRsy.LCCDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$TLvC.LCCDC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$lAxY.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$gUjM.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$WcGF.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$QcZy.LCCFC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$tCiC.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$uERE.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$XtuU.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$wmbl.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$PZCj.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$PIIp.LCCGC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$RoTr.LCCGUC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$vOBI.LCCGUC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$irDD.LCCOC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Mstz.LCCOC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$UcdF.LCCHC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$SXZI.LCCHC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$xvUV.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$sQJD.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$sUMr.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$GETr.LCCJC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Gokg.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$fMQq.LCCLC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$mMXL.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$IUsF.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Fjop.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$MICX.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$OSmP.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$QxAa.LCCMC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$hkBT.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Vfzz.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$anJf.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$GeIp.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$fbjj.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$UQAj.LCCNC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$lmlW.LCCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$izAa.LCCPC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$dXSd.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$dqzR.LCCRC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$OCet.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$awPs.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$DiFq.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$Urjw.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$fJEF.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$oAeB.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$MXzz.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$BHhH.LCCSC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$AEuu.LCCWC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
                $.$MDmQ.LCCWC.ServiceRegistrar.Configure(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(12885019447)
            
            static $h = 117559;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295084855),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LoadAndRegisterCommunityStartupAssemblyModules",
      "d": 117559,
      "h": 4295084855,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295084855),
//--TRIMMABLE-BOUNDARY-START(8590052151),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "LoadAndRegisterLazyCommunityAssemblyModules",
      "d": 117559,
      "h": 8590052151,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590052151),
//--TRIMMABLE-BOUNDARY-START(12885019447),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterAllCommunityModules",
      "d": 117559,
      "h": 12885019447,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885019447)
  ],
  "h": 117559
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.All.Client.CommunityStartup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}All${separator}Client${separator}CommunityStartup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(117559)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Bcl.Cryptography", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.Newtonsoft.Json", "NetJs.ReverseMarkdown", "NetJs.System.IdentityModel.Tokens.Jwt", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.Blazor", "NetJs.LivingThing.Core.Authentication.Client.OAuth.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Community.Article.Client.Blazor", "NetJs.LivingThing.Core.Community.Barter.Common", "NetJs.LivingThing.Core.Community.Barter.Client.Blazor", "NetJs.LivingThing.Core.Shipping.Client.Blazor", "NetJs.LivingThing.Core.Community.Base.Client.Blazor", "NetJs.LivingThing.Core.Community.BuyLink.Common", "NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor", "NetJs.LivingThing.Core.Community.Calendar.Common", "NetJs.LivingThing.Core.Community.Calendar.Client.Blazor", "NetJs.LivingThing.Core.Community.CampaignBot.Common", "NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor", "NetJs.LivingThing.Core.Community.Chat.Common", "NetJs.LivingThing.Core.Community.Chat.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Church.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Messaging.Blazor", "NetJs.LivingThing.Core.Community.Church.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common", "NetJs.LivingThing.Core.Community.TV.App.Blazor", "NetJs.LivingThing.Core.Community.TV.Client.Blazor", "NetJs.LivingThing.Core.Community.DIPTV", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Community.Dispatch.Common", "NetJs.LivingThing.Core.Community.Dispatch.Schemes.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Client.Blazor", "NetJs.LivingThing.Core.Community.Dispatch.Client.Blazor", "NetJs.LivingThing.Core.Community.Election.Common", "NetJs.LivingThing.Core.Community.Election.Client.Blazor", "NetJs.LivingThing.Core.Community.Forum.Common", "NetJs.LivingThing.Core.Community.Forum.Client.Blazor", "NetJs.LivingThing.Core.Community.FundMe.Common", "NetJs.LivingThing.Core.Community.FundMe.Client.Blazor", "NetJs.LivingThing.Core.Community.Games.Common", "NetJs.LivingThing.Core.Community.Games.Client.Blazor", "NetJs.LivingThing.Core.Community.Gift.Common", "NetJs.LivingThing.Core.Community.Gift.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.User.Common", "NetJs.LivingThing.Core.Community.Group.User.Client.Blazor", "NetJs.LivingThing.Core.Community.Job.Common", "NetJs.LivingThing.Core.Community.Job.Client.Blazor", "NetJs.LivingThing.Core.Community.Journal.Common", "NetJs.LivingThing.Core.Community.Journal.Client.Blazor", "NetJs.LivingThing.Core.Community.Loan.Common", "NetJs.LivingThing.Core.Community.Loan.Client.Blazor", "NetJs.LivingThing.Core.Community.LoanManagement.Common", "NetJs.LivingThing.Core.Community.LoanManagement.Client.Blazor", "NetJs.LivingThing.Core.Community.Make.Common", "NetJs.LivingThing.Core.Community.Make.Client.Blazor", "NetJs.LivingThing.Core.Community.Market.Common", "NetJs.LivingThing.Core.Community.Market.StorePaymentTier.Blazor", "NetJs.LivingThing.Core.Community.Website.Common", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Community.Market.Client.Blazor", "NetJs.LivingThing.Core.Community.Media.Common", "NetJs.LivingThing.Core.Community.Media.Client.Blazor", "NetJs.LivingThing.Core.Community.NairalandForum.Common", "NetJs.LivingThing.Core.Community.NairalandForum.Client.Blazor", "NetJs.LivingThing.Core.Community.NewsAggregator.Common", "NetJs.LivingThing.Core.Community.NewsAggregator.Client.Blazor", "NetJs.LivingThing.Core.Community.Note.Common", "NetJs.LivingThing.Core.Community.Note.Client.Blazor", "NetJs.LivingThing.Core.Community.Organization.Common", "NetJs.LivingThing.Core.Community.Organization.Client.Blazor", "NetJs.LivingThing.Core.Community.Pay.Common", "NetJs.LivingThing.Core.Community.Pay.Client.Blazor", "NetJs.LivingThing.Core.Community.Reply.Common", "NetJs.LivingThing.Core.Community.Reply.Client.Blazor", "NetJs.LivingThing.Core.Community.Review.Common", "NetJs.LivingThing.Core.Community.Review.Client.Blazor", "NetJs.LivingThing.Core.Community.School.Common", "NetJs.LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor", "NetJs.LivingThing.Core.Community.School.Client.Blazor", "NetJs.LivingThing.Core.Community.SchoolPortal.Common", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Attendant", "NetJs.LivingThing.Core.Community.SchoolPortal.Client.Blazor", "NetJs.LivingThing.Core.Community.Short.Common", "NetJs.LivingThing.Core.Community.Short.Client.Blazor", "NetJs.LivingThing.Core.Community.Sticky.Common", "NetJs.LivingThing.Core.Community.Sticky.Client.Blazor", "NetJs.LivingThing.Core.Community.Thrift.Common", "NetJs.LivingThing.Core.Community.Thrift.Client.Blazor", "NetJs.LivingThing.Core.Community.Website.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(52023)
