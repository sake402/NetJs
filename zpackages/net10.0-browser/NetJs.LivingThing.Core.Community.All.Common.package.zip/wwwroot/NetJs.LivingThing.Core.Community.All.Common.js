
//--TRIMMABLE-BOUNDARY-START(14862)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $fnTP, $Xjnw, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL, $DZqk, $kVHt, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $xrPB, $OkRL, $RffN, $OnVo, $bTOs, $Bykq, $PZCj, $yCMk, $UcdF, $JRhp, $bRsy, $TBFc, $lAxY, $WcGF, $tCiC, $XtuU, $RoTr, $xvUV, $sUMr, $Gokg, $mMXL, $Fjop, $OSmP, $hkBT, $anJf, $fbjj, $irDD, $lmlW, $FuXl, $dXSd, $DJRY, $EVvT, $OCet, $DiFq, $fJEF, $MXzz, $dRBU, $IHYd, $ZaYa, $AEuu) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.All.Common", 
    {
  "h": 14862,
  "f": "LivingThing.Core.Community.All.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.All.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.All.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(80398)
        $asm.$cls(`$SWDz.LCCAC.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295047694)
            static /*void */ AddJsonSerializerContext(/*this IServiceCollection*/ services, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295047694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295047694)
            
            static $h = 80398;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295047694),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "AddJsonSerializerContext",
      "d": 80398,
      "h": 4295047694,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295047694)
  ],
  "h": 80398
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.All.Common.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}All${separator}Common${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(80398)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.Newtonsoft.Json", "NetJs.TMDbLib", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Authentication.Common", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Community.Barter.Common", "NetJs.LivingThing.Core.Community.BuyLink.Common", "NetJs.LivingThing.Core.Community.Calendar.Common", "NetJs.LivingThing.Core.Community.CampaignBot.Common", "NetJs.LivingThing.Core.Community.Chat.Common", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Church.Common", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Community.Dispatch.Common", "NetJs.LivingThing.Core.Community.Election.Common", "NetJs.LivingThing.Core.Community.Forum.Common", "NetJs.LivingThing.Core.Community.FundMe.Common", "NetJs.LivingThing.Core.Community.Games.Common", "NetJs.LivingThing.Core.Community.Gift.Common", "NetJs.LivingThing.Core.Community.Group.User.Common", "NetJs.LivingThing.Core.Community.Job.Common", "NetJs.LivingThing.Core.Community.Journal.Common", "NetJs.LivingThing.Core.Community.Loan.Common", "NetJs.LivingThing.Core.Community.Make.Common", "NetJs.LivingThing.Core.Community.Market.Common", "NetJs.LivingThing.Core.Community.Media.Common", "NetJs.LivingThing.Core.Community.NairalandForum.Common", "NetJs.LivingThing.Core.Community.NewsAggregator.Common", "NetJs.LivingThing.Core.Community.Note.Common", "NetJs.LivingThing.Core.Community.Organization.Common", "NetJs.LivingThing.Core.Community.Pay.Common", "NetJs.LivingThing.Core.Community.Reply.Common", "NetJs.LivingThing.Core.Community.Review.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Community.School.Common", "NetJs.LivingThing.Core.Community.SchoolPortal.Common", "NetJs.LivingThing.Core.Community.Short.Common", "NetJs.LivingThing.Core.Community.Sticky.Common", "NetJs.LivingThing.Core.Community.Thrift.Common", "NetJs.LivingThing.Core.Frameworks.Common.Local", "NetJs.LivingThing.Core.Community.TV.Common", "NetJs.LivingThing.Core.Community.Website.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(14862)
