
//--TRIMMABLE-BOUNDARY-START(40623)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $xrPB, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $PgDsxg;
    let $jjoCGe;
    let $uwLoug;
    let $nlYjea;
    let $VnlQee;
    let $WmlSrd;
    let $wbILQd;
    let $gfbTek;
    let $EbfxOf;
    let $pHSEbc;
    let $DvtOGc;
    let $qbaSxi;
    let $dpePOb;
    let $ZARRyg;
    let $EelQgk;
    let $NLRIBh;
    let $cLMoqd;
    let $CWCgbl;
    let $aOrVwj;
    let $qedacj;
    let $gJfWCh;
    let $UiIiJb;
    let $mXqOUj;
    let $rCCwQc;
    let $HqPukd;
    let $KyLaDi;
    let $geVmRd;
    let $ukPdBh;
    let $cNQDrd;
    let $idbdYg;
    let $HaXiqb;
    let $xOZvYf;
    let $HyBaVf;
    let $BYPKof;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Article.Client.Blazor", 
    {
  "h": 40623,
  "f": "LivingThing.Core.Community.Article.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 1411414,
      "c": 8591346006,
      "a": [
        {
          "v": [
            "LivingThing.Core.Frameworks.Common.RPC.Http",
            "LivingThing.Core.Frameworks.Common.RPC.WebSocket",
            "LivingThing.Core.Authentication.Common",
            "LivingThing.Core.Authentication.Client.Blazor",
            "LivingThing.Core.Authentication.Client.OAuth.Blazor",
            "LivingThing.Core.Community.Client.Blazor",
            "LivingThing.Core.Community.Reply.Client.Blazor",
            "LivingThing.Core.Wallet.Client.Blazor"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Article.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Article.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(171695)
        $asm.$cls(`$BrCm.LCCAC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295138991)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295138991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$BrCm.LCCAC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295138991)
            
            static $h = 171695;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295138991),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 171695,
      "h": 4295138991,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295138991)
  ],
  "h": 171695
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(171695)
        
        

        //--TRIMMABLE-BOUNDARY-START(827055)
        $asm.$cls(`$BrCm.LCCACU.AuthenticationExtension`, ($self) => class AuthenticationExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295794351)
            static /*Task<bool> *//*async*/  CanEdit(/*this IAuthenticationService*/ authenticationService)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295794351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let principal = ($t1 = authenticationService.LCFCA$IReadOnlyAuthenticationService$GetClaimsPrincipal(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ((principal?.IsInRole("Admin") ?? null) ?? false) || ((principal?.IsInRole("SuperAdmin") ?? null) ?? false));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4295794351)
            
            static $h = 827055;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295794351),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "authenticationService",
          "p": 1655170
        }
      ],
      "n": "CanEdit",
      "d": 827055,
      "h": 4295794351,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(4295794351)
  ],
  "h": 827055
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Utility.AuthenticationExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Utility${separator}AuthenticationExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(827055)
        
        

        //--TRIMMABLE-BOUNDARY-START(237231)
        $asm.$cls(`$BrCm.LCCAC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180106415)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$BrCm.LCCACP.CommunityArticleApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$BrCm.LCCACP.CommunityArticleApp().$ctor$6();
                    }, $PgDsxg ??= {"r":2752627,"n":"","d":237231,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$BrCm.LCCACS$1.TodayNugget.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$BrCm.LCCACS$1.TodayNugget().$ctor$3();
                    }, $jjoCGe ??= {"r":2752627,"n":"","d":237231,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180106415)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295204527)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295204527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295204527)
            
            //--TRIMMABLE-BOUNDARY-START(4295204527)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295204527)
            
            static $h = 237231;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180106415),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885139119,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 237231,
      "h": 17180106415,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180106415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295204527),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 237231,
      "h": 4295204527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295204527)
  ],
  "h": 237231
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(237231)
        
        

        //--TRIMMABLE-BOUNDARY-START(433839)
        $asm.$cls(`$BrCm.LCCAC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590368431)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590368431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$BrCm.LCCACS.CommunityArticleService, $.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$BrCm.LCCACV.CategoriesViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$BrCm.LCCACV.HomeViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$BrCm.LCCACV.CategoryViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$BrCm.LCCACV.AllArticlesViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$BrCm.LCCACV.ArticleViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$BrCm.LCCACV.ArticleTagViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6($.$BrCm.LCCACV.NewArticleViewModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityNuggetProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityArticleProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IArticleViewProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$BrCm.LCCACS.ArticleProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IArticleViewProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.ArticleProvider, x);
                }, $uwLoug ??= {"r":63395498,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityArticleProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.ArticleProvider, x);
                }, $nlYjea ??= {"r":17274304,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityNuggetProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.ArticleProvider, x);
                }, $VnlQee ??= {"r":18060736,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$BrCm.LCCACS.CommunityArticleApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, x);
                }, $WmlSrd ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, x);
                }, $wbILQd ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, x);
                }, $gfbTek ??= {"r":$.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, x);
                }, $EbfxOf ??= {"r":19371456,"p":[{"n":"x","p":327718}],"n":"","d":433839,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$BrCm.LCCACS.CommunityArticleFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$xrPB.LCCACM.CommunityArticleCategoryModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$xrPB.LCCACM.CommunityArticlePostModel, services, null);
                $.$BrCm.LCCAC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590368431)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$BrCm.LCCAC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295401135)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295401135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295401135)
            
            //--TRIMMABLE-BOUNDARY-START(4295401135)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295401135)
            
            static $h = 433839;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590368431),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 433839,
      "h": 8590368431,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590368431)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295401135),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 433839,
      "h": 4295401135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295401135)
  ],
  "h": 433839
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(433839)
        
        

        //--TRIMMABLE-BOUNDARY-START(499375)
        $asm.$cls(`$BrCm.LCCACS.ArticleProvider`, ($self) => class ArticleProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590433967)
            /*CommunityArticleApplication*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(8590433967)
            
            //--TRIMMABLE-BOUNDARY-START(4295466671)
            $ctor$1(/*CommunityArticleApplication*/ application)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295466671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.application = application;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295466671)
            
            //--TRIMMABLE-BOUNDARY-START(17180368559)
            /*RenderFragment */ GetArticles$1(/*PostBaseModel*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180368559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$ahDc.LCCCS.ICommunityClientApplication), 1);
                    builder.AddAttribute$4(2, "Value", this.application);
                    builder.AddAttribute$3(3, "ChildContent", $.$hDPm.LCFC.FragmentView.From$1($.$BrCm.LCCACP.CommunityArticleApp, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.set_Item("ParentScope", parent);
                        return $i1;
                    })(), null, null));
                    builder.CloseComponent();
                }, $EelQgk ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":499375,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17180368559)
            
            //--TRIMMABLE-BOUNDARY-START(21475335855)
            /*RenderFragment */ GetArticles$2(/*params string[]*/ tags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475335855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$ahDc.LCCCSP.CommunityPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("CardWidthHint", $.$box(200, $.$$.S.Int32));
                    $i2.set_Item("CardSpaceHint", $.$box(20, $.$$.S.Int32));
                    $i2.set_Item("DataFilter", new $.$fPer.LCFCD.DataFilter().$ctor$19($.$$.S.String.Join$10(",", tags), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741845/*PostFilterTypes.Tag*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                    return $i2;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475335855)
            
            //--TRIMMABLE-BOUNDARY-START(12885401263)
            /*RenderFragment */ GetArticles(/*params DataId[]*/ ids)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885401263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$ahDc.LCCCSP.CommunityPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("CardWidthHint", $.$box(200, $.$$.S.Int32));
                    $i3.set_Item("CardSpaceHint", $.$box(20, $.$$.S.Int32));
                    $i3.set_Item("DataFilter", new $.$fPer.LCFCD.DataFilter().$ctor$2(new $.$fPer.LCFCD.CompositeDataId().$ctor$4(ids), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [  ], null, null)));
                    return $i3;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885401263)
            
            //--TRIMMABLE-BOUNDARY-START(25770303151)
            /*RenderFragment */ GetNuggets(/*PostBaseModel*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770303151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$ahDc.LCCCSP.CommunityPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.set_Item("DataFilter", new $.$fPer.LCFCD.DataFilter().$ctor$6(parent.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1286/*PostTypes.ArticleNugget*/, $.$LCOv.LCFCPM$1.PostTypes) ], null, null)));
                    return $i4;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770303151)
            
            //--TRIMMABLE-BOUNDARY-START(30065270447)
            /*RenderFragment */ GetTodayNugget(/*DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065270447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$BrCm.LCCACS$1.TodayNugget, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t5 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.set_Item("Filter", filter);
                    return $i5;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(30065270447)
            
            //--TRIMMABLE-BOUNDARY-START(4312241600)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityArticleProvider.GetArticles(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityArticleProvider$GetArticles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312241600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetArticles$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312241600)
            
            //--TRIMMABLE-BOUNDARY-START(4358362794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IArticleViewProvider.GetArticles(params LivingThing.Core.Frameworks.Common.Data.DataId[])
            LCFCI$IArticleViewProvider$GetArticles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358362794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetArticles(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358362794)
            
            //--TRIMMABLE-BOUNDARY-START(8653330090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IArticleViewProvider.GetArticles(params string[])
            LCFCI$IArticleViewProvider$GetArticles$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653330090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetArticles$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653330090)
            
            //--TRIMMABLE-BOUNDARY-START(4313028032)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityNuggetProvider.GetNuggets(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityNuggetProvider$GetNuggets()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313028032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetNuggets(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313028032)
            
            //--TRIMMABLE-BOUNDARY-START(8607995328)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityNuggetProvider.GetTodayNugget(LivingThing.Core.Frameworks.Common.Data.DataFilter)
            LCCCS$ICommunityNuggetProvider$GetTodayNugget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607995328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetTodayNugget(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607995328)
            
            static $h = 499375;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180368559),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetArticles",
      "o": "@$1",
      "d": 499375,
      "h": 17180368559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180368559),
//--TRIMMABLE-BOUNDARY-START(21475335855),
    {
      "r": 6881395,
      "p": [
        {
          "n": "tags",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetArticles",
      "o": "@$2",
      "d": 499375,
      "h": 21475335855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475335855),
//--TRIMMABLE-BOUNDARY-START(12885401263),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ids",
          "p": $.$typeArray($.$fPer.LCFCD.DataId).$h,
          "f": 16
        }
      ],
      "n": "GetArticles",
      "d": 499375,
      "h": 12885401263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885401263),
//--TRIMMABLE-BOUNDARY-START(25770303151),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetNuggets",
      "d": 499375,
      "h": 25770303151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770303151),
//--TRIMMABLE-BOUNDARY-START(30065270447),
    {
      "r": 6881395,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTodayNugget",
      "d": 499375,
      "h": 30065270447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065270447)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590433967),
    {
      "t": 564911,
      "n": "application",
      "d": 499375,
      "h": 8590433967,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590433967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295466671),
    {
      "p": [
        {
          "n": "application",
          "p": 564911
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 499375,
      "h": 4295466671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295466671)
  ],
  "h": 499375
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityArticleProvider, $.$hDPm.LCFCI.IArticleViewProvider, $.$ahDc.LCCCS.ICommunityNuggetProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Services.ArticleProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Services${separator}ArticleProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(499375)
        
        

        //--TRIMMABLE-BOUNDARY-START(1416879)
        $asm.$cls(`$BrCm.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296384175)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296384175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296384175)
            
            //--TRIMMABLE-BOUNDARY-START(4296384175)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296384175)
            
            static $h = 1416879;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296384175),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1416879,
      "h": 4296384175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296384175)
  ],
  "h": 1416879,
  "a": [
    {
      "t": 1351343,
      "c": 4296318639
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1416879)
        
        

        //--TRIMMABLE-BOUNDARY-START(1351343)
        $asm.$cls(`$BrCm.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296318639)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296318639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296318639)
            
            //--TRIMMABLE-BOUNDARY-START(4296318639)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296318639)
            
            static $h = 1351343;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296318639),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1351343,
      "h": 4296318639,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296318639)
  ],
  "h": 1351343
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1351343)
        
        

        //--TRIMMABLE-BOUNDARY-START(106159)
        $asm.$cls(`$BrCm.LCCAC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590040751)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590040751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590040751)
            
            //--TRIMMABLE-BOUNDARY-START(4295073455)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295073455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295073455)
            
            //--TRIMMABLE-BOUNDARY-START(4295073455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295073455)
            
            static $h = 106159;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590040751),
    {
      "r": 65537,
      "n": "Execute",
      "d": 106159,
      "h": 8590040751,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590040751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295073455),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 106159,
      "h": 4295073455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295073455)
  ],
  "h": 106159
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(106159)
        
        

        //--TRIMMABLE-BOUNDARY-START(761519)
        $asm.$cls(`$BrCm.LCCACS$1.TodayNugget`, ($self) => class TodayNugget extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17180630703)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(17180630703)
            
            //--TRIMMABLE-BOUNDARY-START(38655467183)
            /*string */ get OptimizedComponentName()
            {
                return "todaynugget";
            }
            //--TRIMMABLE-BOUNDARY-END(38655467183)
            
            //--TRIMMABLE-BOUNDARY-START(51540369071)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540369071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD.DataFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540369071)
            
            //--TRIMMABLE-BOUNDARY-START(12885663407)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885663407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel)), 0);
                __builder.AddComponentParameter(1, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel))))().$ctor(this, ( (/*s*/ s) =>
                {
                    return s.LCFCD$IReadManyDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$ReadMany($.$with(this.Filter, ($clone) =>
                    {
                        $clone.Page = 1;
                        $clone.Count = 1;
                    }), null).ContinueWith$47($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel)), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel)), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel))))().$ctor(this,  (/*t*/ t) =>
                    {
                        return (() =>
                        {
                            //new $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel))()
                            const $t2 = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel));
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Data = t.Result.Data;
                            $i2.Success = t.Result.Success;
                            return $i2;
                        })();
                    }, $DvtOGc ??= {"r":$.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel)).$h,"p":[{"n":"t","p":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel)).$h}],"n":"","d":761519,"h":0,"f":17825794}));
                }), $qbaSxi ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel))).$h,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$h}],"n":"","d":761519,"h":0,"f":17825794}));
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel))))().$ctor(this, ( (/*nuggets*/ nuggets) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>*/ let __ca1__;
                        if ((__ca1__ = nuggets.Model) !== null ? $.$sl.SL.Enumerable.Any$1($.$xrPB.LCCACM.CommunityArticlePostModel, __ca1__) : false)
                        {
                            /*var*/ let nugget = $.$sl.SL.Enumerable.First$1($.$xrPB.LCCACM.CommunityArticlePostModel, nuggets.Model);
                            __builder2.OpenElement(3, "div");
                            __builder2.AddAttribute$5(4, "class", "row mgb");
                            __builder2.OpenElement(5, "div");
                            __builder2.AddAttribute$5(6, "class", "col-2");
                            __builder2.OpenElement(7, "div");
                            __builder2.AddAttribute$5(8, "class", "hx-07 wx-07 round bd flex clip");
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 9);
                            __builder2.AddComponentParameter(10, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 70), $.$$.S.Int32));
                            __builder2.AddComponentParameter(11, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, nugget.Account));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(12, "\r\n            ");
                            __builder2.OpenElement(13, "div");
                            __builder2.AddAttribute$5(14, "class", "col-8 flex");
                            __builder2.OpenElement(15, "div");
                            __builder2.AddAttribute$5(16, "class", "bg-card pd tipleft corner-2 mgl mg-a");
                            __builder2.OpenElement(17, "p");
                            __builder2.AddContent$4(18, nugget.Summary);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                    }, $dpePOb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":761519,"h":0,"f":17825794});
                }), $ZARRyg ??= {"r":6881395,"p":[{"n":"nuggets","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticlePostModel)).$h}],"n":"","d":761519,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885663407)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590696111)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590696111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590696111)
            
            //--TRIMMABLE-BOUNDARY-START(8590696111)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590696111)
            
            static $h = 761519;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180630703),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770565295,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245401775,
        "f": 83886081
      },
      "n": "Filter",
      "d": 761519,
      "h": 17180630703,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180630703),
//--TRIMMABLE-BOUNDARY-START(38655467183),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360499887,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 761519,
      "h": 38655467183,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655467183)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540369071),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 761519,
      "h": 51540369071,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540369071),
//--TRIMMABLE-BOUNDARY-START(12885663407),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 761519,
      "h": 12885663407,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885663407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590696111),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 761519,
      "h": 8590696111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590696111)
  ],
  "h": 761519
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Shared.TodayNugget`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Shared${separator}TodayNugget`; }
        });
        //--TRIMMABLE-BOUNDARY-END(761519)
        
        

        //--TRIMMABLE-BOUNDARY-START(368303)
        $asm.$cls(`$BrCm.LCCACP.UserApp<>`, (TAccountModel) => $asm.$gt(`$BrCm.LCCACP.UserApp<>`, [TAccountModel], ($self) => class UserApp$$ extends $.$lJUR.LCFCS.ApplicationPageBase$$(TAccountModel)
        {
            //--TRIMMABLE-BOUNDARY-START(25770172079)
            /*CommunityArticleApplication*/ ArticleApplication = null;
            //--TRIMMABLE-BOUNDARY-END(25770172079)
            
            //--TRIMMABLE-BOUNDARY-START(30065139375)
            /*CommunityArticleService*/ ArticleService = null;
            //--TRIMMABLE-BOUNDARY-END(30065139375)
            
            //--TRIMMABLE-BOUNDARY-START(21475204783)
            /*TAccountModel*/ Account = $.$default(TAccountModel);
            //--TRIMMABLE-BOUNDARY-END(21475204783)
            
            //--TRIMMABLE-BOUNDARY-START(77309779631)
            /*string */ get OptimizedComponentName()
            {
                return "userapp";
            }
            //--TRIMMABLE-BOUNDARY-END(77309779631)
            
            //--TRIMMABLE-BOUNDARY-START(107374550703)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374550703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Account":
                    this.Account = $.$cast(parameter.Value, TAccountModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(107374550703)
            
            //--TRIMMABLE-BOUNDARY-START(73014812335)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014812335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ArticleApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, serviceProvider);
                this.ArticleService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73014812335)
            
            //--TRIMMABLE-BOUNDARY-START(34360106671)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360106671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Parameter !== null)
                {
                    __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                    __builder.AddComponentParameter(1, "Name", "Article/Published");
                    __builder.AddComponentParameter(2, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("OwnArticle/Published")));
                    __builder.AddAttribute$3(3, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(4, "<b>Published</b>");
                        }, $NLRIBh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $cLMoqd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(5, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$1(6, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.ArticleApplication, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-book"), false));
                        }, $CWCgbl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $aOrVwj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 8);
                            __builder2.AddComponentParameter(9, "Class", "mgb");
                            __builder2.AddComponentParameter(10, "Title", "Published");
                            __builder2.AddComponentParameter(11, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "BY " + $.$strNN(this.Parameter.Title)));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(12, "\r\n            ");
                            __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), 13);
                            __builder2.AddComponentParameter(14, "Class", "mgt-10");
                            __builder2.AddComponentParameter(15, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder2.CloseComponent();
                        }, $qedacj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $gJfWCh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(16, "\r\n    ");
                    __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 17);
                    __builder.AddComponentParameter(18, "Name", "Article/Read");
                    __builder.AddComponentParameter(19, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("OwnArticle/Read")));
                    __builder.AddAttribute$3(20, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(21, "<b>Read</b>");
                        }, $UiIiJb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $mXqOUj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(22, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$1(23, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.ArticleApplication, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-eye"), false));
                        }, $rCCwQc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $HqPukd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 25);
                            __builder2.AddComponentParameter(26, "Class", "mgb");
                            __builder2.AddComponentParameter(27, "Title", "Read");
                            __builder2.AddComponentParameter(28, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "BY YOU FROM " + $.$strNN(this.Parameter.Title)));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(29, "\r\n            ");
                            __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityViewedPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), 30);
                            __builder2.AddComponentParameter(31, "Class", "mgt-10");
                            __builder2.AddComponentParameter(32, "All", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(33, "Filter", new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$fPer.LCFCD.DataFilter))().$ctor(this, ( (/*s*/ s) =>
                            {
                                return new $.$fPer.LCFCD.DataFilter().$ctor$23(null, $.$$.S.String.Join$5(",", s), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741842/*PostFilterTypes.RecentlyViewed*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null));
                            }), $KyLaDi ??= {"r":9734486,"p":[{"n":"s","p":$.$$.SCG.IEnumerable$$($.$$.S.String).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $geVmRd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $ukPdBh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.AddMarkupContent(34, "\r\n    ");
                    __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 35);
                    __builder.AddComponentParameter(36, "Name", "Article/Followed");
                    __builder.AddComponentParameter(37, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("OwnArticle/Followed")));
                    __builder.AddAttribute$3(38, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddMarkupContent(39, "<b>Followed</b>");
                        }, $cNQDrd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $idbdYg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(40, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.AddContent$1(41, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.ArticleApplication, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-heart"), false));
                        }, $HaXiqb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $xOZvYf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunityAppIntro, 43);
                            __builder2.AddComponentParameter(44, "Class", "mgb");
                            __builder2.AddComponentParameter(45, "Title", "Followed");
                            __builder2.AddComponentParameter(46, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "BY YOU FROM " + $.$strNN(this.Parameter.Title)));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(47, "\r\n            ");
                            __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$xrPB.LCCACM.CommunityArticlePostModel), 48);
                            __builder2.AddComponentParameter(49, "Class", "mgt-10");
                            __builder2.AddComponentParameter(50, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741827/*PostFilterTypes.Subscriptions*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder2.CloseComponent();
                        }, $HyBaVf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $BYPKof ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360106671)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180237487)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180237487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180237487)
            
            //--TRIMMABLE-BOUNDARY-START(17180237487)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17180237487)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770172079)
                this.ArticleApplication = null;
                //--TRIMMABLE-BOUNDARY-END(25770172079)
                
                //--TRIMMABLE-BOUNDARY-START(30065139375)
                this.ArticleService = null;
                //--TRIMMABLE-BOUNDARY-END(30065139375)
                
                //--TRIMMABLE-BOUNDARY-START(21475204783)
                this.Account = null;
                //--TRIMMABLE-BOUNDARY-END(21475204783)
                
            }
            static $H = 368303;
            static $h = 368303;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$(TAccountModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770172079),
    {
      "p": 564911,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51539975855,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94489648815,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886081
      },
      "n": "ArticleApplication",
      "d": this.$h,
      "H": 25770172079,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770172079),
//--TRIMMABLE-BOUNDARY-START(30065139375),
    {
      "p": 695983,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129910447,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 103079583407,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886081
      },
      "n": "ArticleService",
      "d": this.$h,
      "H": 30065139375,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065139375),
//--TRIMMABLE-BOUNDARY-START(21475204783),
    {
      "p": TAccountModel?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950041263,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 85899714223,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 83886081
      },
      "n": "Account",
      "d": this.$h,
      "H": 21475204783,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475204783),
//--TRIMMABLE-BOUNDARY-START(77309779631),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719845039,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 77309779631,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309779631)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107374550703),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 107374550703,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374550703),
//--TRIMMABLE-BOUNDARY-START(73014812335),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 73014812335,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014812335),
//--TRIMMABLE-BOUNDARY-START(34360106671),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 34360106671,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360106671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180237487),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 17180237487,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180237487)
  ],
  "s": [
    {
      "h": TAccountModel?.$h??1572864,
      "n": "TAccountModel",
      "c": [6220212
      ]
    }
  ],
  "r": 1,
  "H": 368303,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Pages.UserApp<${TAccountModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Pages${separator}UserApp$${TAccountModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(368303)
        
        

        //--TRIMMABLE-BOUNDARY-START(892591)
        $asm.$cls(`$BrCm.LCCACV.AllArticlesViewModel`, ($self) => class AllArticlesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590827183)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590827183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RemoteService = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590827183)
            
            //--TRIMMABLE-BOUNDARY-START(21475729071)
            /*IServerRemoteService*/ RemoteService = null;
            //--TRIMMABLE-BOUNDARY-END(21475729071)
            
            static $h = 892591;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475729071),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180761775,
        "f": 50331650
      },
      "n": "RemoteService",
      "d": 892591,
      "h": 21475729071,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475729071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590827183),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 892591,
      "h": 8590827183,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590827183)
  ],
  "h": 892591
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.AllArticlesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}AllArticlesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(892591)
        
        

        //--TRIMMABLE-BOUNDARY-START(1089199)
        $asm.$cls(`$BrCm.LCCACV.CategoriesViewModel`, ($self) => class CategoriesViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591023791)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591023791);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591023791)
            
            //--TRIMMABLE-BOUNDARY-START(21475925679)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(21475925679)
            
            static $h = 1089199;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475925679),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180958383,
        "f": 50331650
      },
      "n": "Server",
      "d": 1089199,
      "h": 21475925679,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475925679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591023791),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1089199,
      "h": 8591023791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591023791)
  ],
  "h": 1089199
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.CategoriesViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}CategoriesViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1089199)
        
        

        //--TRIMMABLE-BOUNDARY-START(1220271)
        $asm.$cls(`$BrCm.LCCACV.HomeViewModel`, ($self) => class HomeViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(30065991343)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(30065991343)
            
            //--TRIMMABLE-BOUNDARY-START(8591154863)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591154863);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Load();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591154863)
            
            //--TRIMMABLE-BOUNDARY-START(12886122159)
            /*IEnumerable<CommunityArticleCategoryModel>*/ Categories = null;
            //--TRIMMABLE-BOUNDARY-END(12886122159)
            
            //--TRIMMABLE-BOUNDARY-START(25771024047)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771024047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let remoteService = null;
                    try
                    {
                        let $t1, $r1;
                        remoteService = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), null);
                        /*var*/ let response = ($t1 = remoteService.LCFCS$3$IServiceProxy$$$Service.LCFCD$IReadManyDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$ReadMany(new $.$fPer.LCFCD.DataFilter().$ctor$18(1, 10), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (response.Success)
                        {
                            this.Categories = response.Data;
                        }
                        this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                    }
                    finally
                    {
                        remoteService?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25771024047)
            
            static $h = 1220271;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886122159),
    {
      "p": $.$$.SCG.IEnumerable$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476056751,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655925935,
        "f": 83886082
      },
      "n": "Categories",
      "d": 1220271,
      "h": 12886122159,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886122159)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771024047),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1220271,
      "h": 25771024047,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(25771024047)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065991343),
    {
      "t": 1309651,
      "n": "Server",
      "d": 1220271,
      "h": 30065991343,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065991343)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591154863),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1220271,
      "h": 8591154863,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591154863)
  ],
  "h": 1220271
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.HomeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}HomeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1220271)
        
        

        //--TRIMMABLE-BOUNDARY-START(1154735)
        $asm.$cls(`$BrCm.LCCACV.CategoryViewModel`, ($self) => class CategoryViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(17181023919)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181023919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181023919)
            
            //--TRIMMABLE-BOUNDARY-START(60130696879)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(60130696879)
            
            //--TRIMMABLE-BOUNDARY-START(21475991215)
            /*DataId*/ CategoryId;
            //--TRIMMABLE-BOUNDARY-END(21475991215)
            
            //--TRIMMABLE-BOUNDARY-START(51540762287)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540762287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let service = null;
                    try
                    {
                        let $t1, $r1;
                        service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), null);
                        /*var*/ let response = ($t1 = service.LCFCS$3$IServiceProxy$$$Service.LCFCD$IReadSingleDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$ReadSingle(new $.$fPer.LCFCD.DataFilter().$ctor$12($.$clone(this.CategoryId)), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (response.Success)
                        {
                            this.Model = response.Data;
                            this.Loading = $.$vWqU.LCFCC.LoadState.Loaded;
                        }
                        else 
                        {
                            this.Loading = $.$vWqU.LCFCC.LoadState.LoadError;
                            this.LoadErrorMessage = response.Message;
                        }
                    }
                    finally
                    {
                        service?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540762287)
            
            //--TRIMMABLE-BOUNDARY-START(55835729583)
            /*CommunityArticleCategoryModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(55835729583)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475991215)
                this.CategoryId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(21475991215)
                
            }
            static $h = 1154735;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130696879),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245794991,
        "f": 50331650
      },
      "n": "Server",
      "d": 1154735,
      "h": 60130696879,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130696879),
//--TRIMMABLE-BOUNDARY-START(21475991215),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065925807,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720631471,
        "f": 83886081
      },
      "n": "CategoryId",
      "d": 1154735,
      "h": 21475991215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475991215),
//--TRIMMABLE-BOUNDARY-START(55835729583),
    {
      "p": 254893,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655860399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310566063,
        "f": 83886081
      },
      "n": "Model",
      "d": 1154735,
      "h": 55835729583,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835729583)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540762287),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1154735,
      "h": 51540762287,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(51540762287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181023919),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1154735,
      "h": 17181023919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181023919)
  ],
  "h": 1154735
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.CategoryViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}CategoryViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1154735)
        
        

        //--TRIMMABLE-BOUNDARY-START(958127)
        $asm.$cls(`$BrCm.LCCACV.ArticleTagViewModel`, ($self) => class ArticleTagViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590892719)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590892719);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RemoteService = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590892719)
            
            //--TRIMMABLE-BOUNDARY-START(21475794607)
            /*IServerRemoteService*/ RemoteService = null;
            //--TRIMMABLE-BOUNDARY-END(21475794607)
            
            static $h = 958127;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475794607),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180827311,
        "f": 50331650
      },
      "n": "RemoteService",
      "d": 958127,
      "h": 21475794607,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475794607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590892719),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 958127,
      "h": 8590892719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590892719)
  ],
  "h": 958127
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.ArticleTagViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}ArticleTagViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(958127)
        
        

        //--TRIMMABLE-BOUNDARY-START(1285807)
        $asm.$cls(`$BrCm.LCCACV.NewArticleViewModel`, ($self) => class NewArticleViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(12886187695)
            $ctor$3(/*IServerRemoteService*/ server, /*IAuthenticationService*/ authenticationService)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886187695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RemoteService = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886187695)
            
            //--TRIMMABLE-BOUNDARY-START(38655991471)
            /*IServerRemoteService*/ RemoteService = null;
            //--TRIMMABLE-BOUNDARY-END(38655991471)
            
            //--TRIMMABLE-BOUNDARY-START(34361024175)
            /*CommunityArticlePostModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(34361024175)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361024175)
                this.Model = (() =>
                {
                    //new $.$xrPB.LCCACM.CommunityArticlePostModel()
                    const $t1 = $.$xrPB.LCCACM.CommunityArticlePostModel;
                    const $i1 = new $t1();
                    $i1.$ctor$6();
                    $i1.Name = "New Article";
                    $i1.Post = "Content";
                    return $i1;
                })();
                //--TRIMMABLE-BOUNDARY-END(34361024175)
                
            }
            static $h = 1285807;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655991471),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066056879,
        "f": 50331650
      },
      "n": "RemoteService",
      "d": 1285807,
      "h": 38655991471,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655991471),
//--TRIMMABLE-BOUNDARY-START(34361024175),
    {
      "p": 582573,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476122287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245926063,
        "f": 83886081
      },
      "n": "Model",
      "d": 1285807,
      "h": 34361024175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361024175)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886187695),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "authenticationService",
          "p": 1655170
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1285807,
      "h": 12886187695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886187695)
  ],
  "h": 1285807
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.NewArticleViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}NewArticleViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1285807)
        
        

        //--TRIMMABLE-BOUNDARY-START(1023663)
        $asm.$cls(`$BrCm.LCCACV.ArticleViewModel`, ($self) => class ArticleViewModel extends $.$vWqU.LCFCC.BaseViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885925551)
            $ctor$3(/*IServerRemoteService*/ server)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885925551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RemoteService = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885925551)
            
            //--TRIMMABLE-BOUNDARY-START(47245663919)
            /*IServerRemoteService*/ RemoteService = null;
            //--TRIMMABLE-BOUNDARY-END(47245663919)
            
            //--TRIMMABLE-BOUNDARY-START(34360762031)
            /*ValueTask */ Load$3(/*string*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360762031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        this.Model = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$xrPB.LCCACM.CommunityArticlePostModel, this.RemoteService, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(id, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    });
                }, $pHSEbc ??= {"r":181338113,"n":"","d":1023663,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34360762031)
            
            //--TRIMMABLE-BOUNDARY-START(60130565807)
            /*Task */ Update()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130565807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let remoteService = null;
                try
                {
                    remoteService = this.RemoteService.LCFCR$IServerRemoteService$GetRemoteService($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), null);
                    return remoteService.LCFCS$3$IServiceProxy$$$Service.LCFCD$IUpdateDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$Update(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$xrPB.LCCACM.CommunityArticlePostModel), [ this.Model ], null, null));
                }
                finally
                {
                    remoteService?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130565807)
            
            //--TRIMMABLE-BOUNDARY-START(42950696623)
            /*void *//*async*/  Rate(/*int*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950696623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let remoteService = null;
                    try
                    {
                        remoteService = this.RemoteService.LCFCR$IServerRemoteService$GetRemoteService($.$LCOv.LCFCPS.IPostInteractionRemoteService, null);
                        try
                        {
                            let $t2, $r2;
                            /*var*/ let response = ($t2 = remoteService.LCFCS$3$IServiceProxy$$$Service.LCFCPS$IPostInteractionRemoteService$AddRating(this.Model.Identifier, value, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if (response.Success)
                            {
                            }
                            else 
                            {
                            }
                        }
                        catch(e)
                        {
                        }
                    }
                    finally
                    {
                        remoteService?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950696623)
            
            //--TRIMMABLE-BOUNDARY-START(38655729327)
            /*CommunityArticlePostModel*/ Model = null;
            //--TRIMMABLE-BOUNDARY-END(38655729327)
            
            static $h = 1023663;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.BaseViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245663919),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065794735,
        "f": 50331650
      },
      "n": "RemoteService",
      "d": 1023663,
      "h": 47245663919,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245663919),
//--TRIMMABLE-BOUNDARY-START(38655729327),
    {
      "p": 582573,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475860143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835598511,
        "f": 83886081
      },
      "n": "Model",
      "d": 1023663,
      "h": 38655729327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655729327)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360762031),
    {
      "r": 181338113,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "Load",
      "o": "@$3",
      "d": 1023663,
      "h": 34360762031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360762031),
//--TRIMMABLE-BOUNDARY-START(60130565807),
    {
      "r": 178454529,
      "n": "Update",
      "d": 1023663,
      "h": 60130565807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130565807),
//--TRIMMABLE-BOUNDARY-START(42950696623),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "Rate",
      "d": 1023663,
      "h": 42950696623,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(42950696623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885925551),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1023663,
      "h": 12885925551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885925551)
  ],
  "h": 1023663
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.ViewModels.ArticleViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}ViewModels${separator}ArticleViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1023663)
        
        

        //--TRIMMABLE-BOUNDARY-START(630447)
        $asm.$cls(`$BrCm.LCCACS.CommunityArticleFeedProvider`, ($self) => class CommunityArticleFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$xrPB.LCCACM.CommunityArticlePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295597743)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295597743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295597743)
            
            //--TRIMMABLE-BOUNDARY-START(8590565039)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityArticlePostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590565039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an article`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590565039)
            
            static $h = 630447;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$xrPB.LCCACM.CommunityArticlePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590565039),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 582573
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 630447,
      "h": 8590565039,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590565039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295597743),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 630447,
      "h": 4295597743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295597743)
  ],
  "h": 630447
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Services.CommunityArticleFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Services${separator}CommunityArticleFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(630447)
        
        

        //--TRIMMABLE-BOUNDARY-START(695983)
        $asm.$cls(`$BrCm.LCCACS.CommunityArticleService`, ($self) => class CommunityArticleService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295663279)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295663279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295663279)
            
            //--TRIMMABLE-BOUNDARY-START(17180565167)
            /*bool */ get LoadCategories()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180565167)
            
            static $h = 695983;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180565167),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885597871,
        "f": 50364417
      },
      "n": "LoadCategories",
      "d": 695983,
      "h": 17180565167,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180565167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295663279),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 695983,
      "h": 4295663279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295663279)
  ],
  "h": 695983
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Services.CommunityArticleService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Services${separator}CommunityArticleService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(695983)
        
        

        //--TRIMMABLE-BOUNDARY-START(302767)
        $asm.$cls(`$BrCm.LCCACP.CommunityArticleApp`, ($self) => class CommunityArticleApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(25770106543)
            /*CommunityArticleService*/ ArticleService = null;
            //--TRIMMABLE-BOUNDARY-END(25770106543)
            
            //--TRIMMABLE-BOUNDARY-START(21475139247)
            /*CommunityArticleApplication*/ ArticleApplication = null;
            //--TRIMMABLE-BOUNDARY-END(21475139247)
            
            //--TRIMMABLE-BOUNDARY-START(17180171951)
            /*ICommunityClientApplication */ get Application()
            {
                return this.ArticleApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(17180171951)
            
            //--TRIMMABLE-BOUNDARY-START(38655008431)
            /*CommunityPostView */ get CardView()
            {
                return 3/*CommunityPostView.CardFeed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655008431)
            
            //--TRIMMABLE-BOUNDARY-START(42949975727)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(42949975727)
            
            //--TRIMMABLE-BOUNDARY-START(34360041135)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(34360041135)
            
            //--TRIMMABLE-BOUNDARY-START(115964419759)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964419759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ArticleService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964419759)
            
            //--TRIMMABLE-BOUNDARY-START(47244943023)
            /*bool */ FilterPageType(/*PostTypes*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244943023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (a === 1280/*PostTypes.Article*/ || a === 1281/*PostTypes.ArticleCategory*/ || a === 1282/*PostTypes.ArticlePost*/ || !$.$$.S.String.StartsWith$3.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, a), "Article"))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(47244943023)
            
            //--TRIMMABLE-BOUNDARY-START(120259387055)
            /*string */ get OptimizedComponentName()
            {
                return "communityarticleapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(120259387055)
            
            //--TRIMMABLE-BOUNDARY-START(111669452463)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669452463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ArticleService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleService, serviceProvider);
                this.ArticleApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$BrCm.LCCACS.CommunityArticleApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(111669452463)
            
            //--TRIMMABLE-BOUNDARY-START(30065073839)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065073839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(30065073839)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885204655)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885204655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885204655)
            
            //--TRIMMABLE-BOUNDARY-START(12885204655)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885204655)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770106543)
                this.ArticleService = null;
                //--TRIMMABLE-BOUNDARY-END(25770106543)
                
                //--TRIMMABLE-BOUNDARY-START(21475139247)
                this.ArticleApplication = null;
                //--TRIMMABLE-BOUNDARY-END(21475139247)
                
            }
            static $h = 302767;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770106543),
    {
      "p": 695983,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014746799,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439256239,
        "f": 83886081
      },
      "n": "ArticleService",
      "d": 302767,
      "h": 25770106543,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770106543),
//--TRIMMABLE-BOUNDARY-START(21475139247),
    {
      "p": 564911,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424812207,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849321647,
        "f": 83886081
      },
      "n": "ArticleApplication",
      "d": 302767,
      "h": 21475139247,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475139247),
//--TRIMMABLE-BOUNDARY-START(17180171951),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834877615,
        "f": 50364420
      },
      "n": "Application",
      "d": 302767,
      "h": 17180171951,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180171951),
//--TRIMMABLE-BOUNDARY-START(38655008431),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194615983,
        "f": 50364420
      },
      "n": "CardView",
      "d": 302767,
      "h": 38655008431,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38655008431),
//--TRIMMABLE-BOUNDARY-START(42949975727),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784550575,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 302767,
      "h": 42949975727,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42949975727),
//--TRIMMABLE-BOUNDARY-START(34360041135),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604681391,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 302767,
      "h": 34360041135,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360041135),
//--TRIMMABLE-BOUNDARY-START(120259387055),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374485167,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 302767,
      "h": 120259387055,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259387055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964419759),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 302767,
      "h": 115964419759,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(115964419759),
//--TRIMMABLE-BOUNDARY-START(47244943023),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 21096884
        }
      ],
      "n": "FilterPageType",
      "d": 302767,
      "h": 47244943023,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244943023),
//--TRIMMABLE-BOUNDARY-START(111669452463),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 302767,
      "h": 111669452463,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669452463),
//--TRIMMABLE-BOUNDARY-START(30065073839),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 302767,
      "h": 30065073839,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065073839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885204655),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 302767,
      "h": 12885204655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885204655)
  ],
  "h": 302767
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Pages.CommunityArticleApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Pages${separator}CommunityArticleApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(302767)
        
        

        //--TRIMMABLE-BOUNDARY-START(564911)
        $asm.$cls(`$BrCm.LCCACS.CommunityArticleApplication`, ($self) => class CommunityArticleApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885466799)
            $ctor$3(/*CommunityArticleService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885466799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885466799)
            
            //--TRIMMABLE-BOUNDARY-START(176094224047)
            /*string */ get Name()
            {
                return "Article";
            }
            //--TRIMMABLE-BOUNDARY-END(176094224047)
            
            //--TRIMMABLE-BOUNDARY-START(197569060527)
            /*string */ get Title()
            {
                return "Article";
            }
            //--TRIMMABLE-BOUNDARY-END(197569060527)
            
            //--TRIMMABLE-BOUNDARY-START(34360303279)
            /*string */ get Description()
            {
                return "Post, Read Articles and News";
            }
            //--TRIMMABLE-BOUNDARY-END(34360303279)
            
            //--TRIMMABLE-BOUNDARY-START(171799256751)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-book-open-page-variant-outline"/*MaterialDesignIconNames.BookOpenPageVariantOutline*/);
            }
            //--TRIMMABLE-BOUNDARY-END(171799256751)
            
            //--TRIMMABLE-BOUNDARY-START(193274093231)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#EE964B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(193274093231)
            
            //--TRIMMABLE-BOUNDARY-START(42950237871)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/ | 4/*ApplicationServiceFeatures.Recommended*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950237871)
            
            //--TRIMMABLE-BOUNDARY-START(17180434095)
            /*Type? */ get ApplicationViewType()
            {
                return $.$BrCm.LCCACP.CommunityArticleApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180434095)
            
            //--TRIMMABLE-BOUNDARY-START(30065335983)
            /*DefaultAppDefinition<CommunityArticleCategoryModel, CommunityArticlePostModel, GenericPostModel, ApplicationBaseUserPreference> */ get Definition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899910831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let def = super.Definition;
                def.CardView = 3/*CommunityPostView.CardFeed*/;
                def.CardWidthHint = 250;
                def.CardSpaceHint = 20;
                return def;
            }
            //--TRIMMABLE-BOUNDARY-END(30065335983)
            
            //--TRIMMABLE-BOUNDARY-START(167504289455)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504289455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(167504289455)
            
            //--TRIMMABLE-BOUNDARY-START(38655270575)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655270575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(38655270575)
            
            //--TRIMMABLE-BOUNDARY-START(184684158639)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684158639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(184684158639)
            
            //--TRIMMABLE-BOUNDARY-START(180389191343)
            /*int */ get Order()
            {
                return 1000;
            }
            //--TRIMMABLE-BOUNDARY-END(180389191343)
            
            //--TRIMMABLE-BOUNDARY-START(25770368687)
            /*string */ get CreateLink()
            {
                return "Article/CreatePost";
            }
            //--TRIMMABLE-BOUNDARY-END(25770368687)
            
            //--TRIMMABLE-BOUNDARY-START(21475401391)
            /*string */ get CreateLabel()
            {
                return "Publish an Article";
            }
            //--TRIMMABLE-BOUNDARY-END(21475401391)
            
            //--TRIMMABLE-BOUNDARY-START(4295532207)
            /*CommunityArticleService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295532207)
            
            //--TRIMMABLE-BOUNDARY-START(188979125935)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(188979125935)
            
            //--TRIMMABLE-BOUNDARY-START(201864027823)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(1280/*PostTypes.Article*/, 1287/*PostTypes.ArticleEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(201864027823)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(25772137952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLink.get
            get LCFCA$ICreatorApplicationProxy$CreateLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592268768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLink;
            }
            //--TRIMMABLE-BOUNDARY-END(25772137952)
            
            //--TRIMMABLE-BOUNDARY-START(17182203360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLabel.get
            get LCFCA$ICreatorApplicationProxy$CreateLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297301472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLabel;
            }
            //--TRIMMABLE-BOUNDARY-END(17182203360)
            
            static $h = 564911;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176094224047),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259649199,
        "f": 50364417
      },
      "n": "Name",
      "d": 564911,
      "h": 176094224047,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094224047),
//--TRIMMABLE-BOUNDARY-START(197569060527),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619387567,
        "f": 50364417
      },
      "n": "Title",
      "d": 564911,
      "h": 197569060527,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197569060527),
//--TRIMMABLE-BOUNDARY-START(34360303279),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489845423,
        "f": 50364417
      },
      "n": "Description",
      "d": 564911,
      "h": 34360303279,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360303279),
//--TRIMMABLE-BOUNDARY-START(171799256751),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669714607,
        "f": 50364417
      },
      "n": "Icon",
      "d": 564911,
      "h": 171799256751,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799256751),
//--TRIMMABLE-BOUNDARY-START(193274093231),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029452975,
        "f": 50364417
      },
      "n": "Theme",
      "d": 564911,
      "h": 193274093231,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(193274093231),
//--TRIMMABLE-BOUNDARY-START(42950237871),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079780015,
        "f": 50364417
      },
      "n": "Features",
      "d": 564911,
      "h": 42950237871,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950237871),
//--TRIMMABLE-BOUNDARY-START(17180434095),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130107055,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 564911,
      "h": 17180434095,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180434095),
//--TRIMMABLE-BOUNDARY-START(30065335983),
    {
      "p": $.$ahDc.LCCCPD.DefaultAppDefinition$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899910831,
        "f": 50364417
      },
      "n": "Definition",
      "d": 564911,
      "h": 30065335983,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065335983),
//--TRIMMABLE-BOUNDARY-START(180389191343),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849583791,
        "f": 50364417
      },
      "n": "Order",
      "d": 564911,
      "h": 180389191343,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389191343),
//--TRIMMABLE-BOUNDARY-START(25770368687),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309976239,
        "f": 50331649
      },
      "n": "CreateLink",
      "d": 564911,
      "h": 25770368687,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770368687),
//--TRIMMABLE-BOUNDARY-START(21475401391),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720041647,
        "f": 50331649
      },
      "n": "CreateLabel",
      "d": 564911,
      "h": 21475401391,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475401391),
//--TRIMMABLE-BOUNDARY-START(4295532207),
    {
      "p": 695983,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540172463,
        "f": 50331650
      },
      "n": "_Service",
      "d": 564911,
      "h": 4295532207,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295532207),
//--TRIMMABLE-BOUNDARY-START(188979125935),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439518383,
        "f": 50364417
      },
      "n": "Service",
      "d": 564911,
      "h": 188979125935,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979125935),
//--TRIMMABLE-BOUNDARY-START(201864027823),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209322159,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 564911,
      "h": 201864027823,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(201864027823)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504289455),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 564911,
      "h": 167504289455,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(167504289455),
//--TRIMMABLE-BOUNDARY-START(38655270575),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 564911,
      "h": 38655270575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655270575),
//--TRIMMABLE-BOUNDARY-START(184684158639),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 564911,
      "h": 184684158639,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684158639)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885466799),
    {
      "p": [
        {
          "n": "service",
          "p": 695983
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 564911,
      "h": 12885466799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885466799)
  ],
  "h": 564911
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$xrPB.LCCACM.CommunityArticlePostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$ahDc.LCCCS.ICommunitySearchApplication, $.$ahDc.LCCCS.ICommunityCreatorApplication, $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$yleQ.LCFCA.ICreatorApplicationProxy, $.$ahDc.LCCCS.ICommunityUserDashboardApplicationPage, $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$LCOv.LCFCPM$1.AccountModel), $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Client.Services.CommunityArticleApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Client${separator}Services${separator}CommunityArticleApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(564911)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(40623)
