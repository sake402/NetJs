
//--TRIMMABLE-BOUNDARY-START(58285)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $WNPIdc;
    let $fOHKJh;
    let $OFXCZa;
    let $cXdDvi;
    let $ncEezb;
    let $lmTTde;
    let $iWgmne;
    let $JgxNgi;
    let $yCWQIg;
    let $InvyZk;
    let $wFyFkc;
    let $uTdhPj;
    let $YgXNoj;
    let $JjpUbf;
    let $CiXpqa;
    let $KnUNra;
    let $lzThkh;
    let $mfLwKi;
    let $LDuBck;
    let $gRQjUh;
    let $qauehf;
    let $xUHlMf;
    let $lGgJFe;
    let $SEUFAg;
    let $zdGhgj;
    let $ZaWHHb;
    let $aiQobc;
    let $EKmtLd;
    let $tXUamb;
    let $KXunAb;
    let $zYuItf;
    let $SDySye;
    let $PtRuKe;
    let $XHMnFc;
    let $Xcfsfj;
    let $XsgpTi;
    let $HXmwcg;
    let $kFOgla;
    let $lJKlmb;
    let $stjdqa;
    let $wzzgud;
    let $PZKVik;
    let $JxOyPj;
    let $xCVzfl;
    let $xYdcai;
    let $avtHPh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Article.Common", 
    {
  "h": 58285,
  "f": "LivingThing.Core.Community.Article.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Article.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Article.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1434541)
        $asm.$cls(`$xrPB.LCCACS.IArticleRemoteService`, ($self) => class IArticleRemoteService
        {
            static $h = 1434541;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1434541,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Services.IArticleRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Services${separator}IArticleRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1434541)
        
        

        //--TRIMMABLE-BOUNDARY-START(320429)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleCategoryModelCustomAttributesProvider`, ($self) => class CommunityArticleCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295287725)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295287725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295287725)
            
            static $h = 320429;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295287725),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 320429,
      "h": 4295287725,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295287725)
  ],
  "h": 320429
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(320429)
        
        

        //--TRIMMABLE-BOUNDARY-START(1631149)
        $asm.$cls(`$xrPB.LCCACS$1.ArticleSettingsCustomAttributesProvider`, ($self) => class ArticleSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296598445)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296598445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296598445)
            
            static $h = 1631149;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296598445),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1631149,
      "h": 4296598445,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296598445)
  ],
  "h": 1631149
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Settings.ArticleSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Settings${separator}ArticleSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1631149)
        
        

        //--TRIMMABLE-BOUNDARY-START(910253)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleServiceModelCustomAttributesProvider`, ($self) => class CommunityArticleServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295877549)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295877549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ServiceModelCustomAttributesProvider$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295877549)
            
            static $h = 910253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295877549),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 910253,
      "h": 4295877549,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295877549)
  ],
  "h": 910253
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(910253)
        
        

        //--TRIMMABLE-BOUNDARY-START(1893293)
        $asm.$cls(`$xrPB.LCCACS$2.ArticleStatesCustomAttributesProvider`, ($self) => class ArticleStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296860589)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296860589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296860589)
            
            static $h = 1893293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296860589),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1893293,
      "h": 4296860589,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296860589)
  ],
  "h": 1893293
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.States.ArticleStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}States${separator}ArticleStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1893293)
        
        

        //--TRIMMABLE-BOUNDARY-START(123821)
        $asm.$cls(`$xrPB.LCCAC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295091117)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295091117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xrPB.LCCACM.CommunityArticleCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xrPB.LCCACM.CommunityArticleCategoryModelCustomAttributesProvider, $.$xrPB.LCCACM.CommunityArticleCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xrPB.LCCACM.CommunityArticlePostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xrPB.LCCACM.CommunityArticlePostModelCustomAttributesProvider, $.$xrPB.LCCACM.CommunityArticlePostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xrPB.LCCACM.CommunityArticleServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelCustomAttributesProvider, $.$xrPB.LCCACM.CommunityArticleServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xrPB.LCCACS$1.ArticleSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xrPB.LCCACS$1.ArticleSettingsCustomAttributesProvider, $.$xrPB.LCCACS$1.ArticleSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xrPB.LCCACS$2.ArticleStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xrPB.LCCACS$2.ArticleStatesCustomAttributesProvider, $.$xrPB.LCCACS$2.ArticleStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295091117)
            
            static $h = 123821;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295091117),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 123821,
      "h": 4295091117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295091117)
  ],
  "h": 123821
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(123821)
        
        

        //--TRIMMABLE-BOUNDARY-START(1762221)
        $asm.$cls(`$xrPB.LCCACS$1.ArticleSettingsTypeDescriptorBuilder`, ($self) => class ArticleSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591696813)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591696813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xrPB.LCCACS$1.ArticleSettingsTypeDescriptor()
                        const $t1 = $.$xrPB.LCCACS$1.ArticleSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Article.Common.Settings.ArticleSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JgxNgi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1762221,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xrPB.LCCACS$1.ArticleSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591696813)
            
            //--TRIMMABLE-BOUNDARY-START(4296729517)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296729517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296729517)
            
            //--TRIMMABLE-BOUNDARY-START(4296729517)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296729517)
            
            static $h = 1762221;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591696813),
    {
      "r": 65537,
      "n": "Register",
      "d": 1762221,
      "h": 8591696813,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591696813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296729517),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1762221,
      "h": 4296729517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296729517)
  ],
  "h": 1762221
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Settings.ArticleSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Settings${separator}ArticleSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1762221)
        
        

        //--TRIMMABLE-BOUNDARY-START(189357)
        $asm.$cls(`$xrPB.LCCAC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295156653)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295156653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$xrPB.LCCACS.IArticleFeedRemoteService, $.$xrPB.LCCACS.IArticleFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCACS.IArticleFeedRemoteService_Mocking().$ctor$3(impl);
                }, $InvyZk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACS.IArticleFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCACS.IArticleFeedRemoteService_Mocking().$ctor$3(impl);
                }, $wFyFkc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$xrPB.LCCACS.IArticleRemoteService, $.$xrPB.LCCACS.IArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCACS.IArticleRemoteService_Mocking().$ctor$3(impl);
                }, $uTdhPj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$xrPB.LCCBCS.IComunityArticleRemoteService, $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $YgXNoj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $JjpUbf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $CiXpqa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $KnUNra ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $lzThkh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $mfLwKi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $LDuBck ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking().$ctor$3(impl);
                }, $gRQjUh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $qauehf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $xUHlMf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $lGgJFe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $SEUFAg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $zdGhgj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $ZaWHHb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking().$ctor$3(impl);
                }, $aiQobc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":189357,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295156653)
            
            static $h = 189357;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295156653),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 189357,
      "h": 4295156653,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295156653)
  ],
  "h": 189357
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(189357)
        
        

        //--TRIMMABLE-BOUNDARY-START(648109)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticlePostModelCustomAttributesProvider`, ($self) => class CommunityArticlePostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295615405)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295615405)
            
            //--TRIMMABLE-BOUNDARY-START(8590582701)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590582701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$xrPB.LCCACM.CommunityArticlePostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("SetType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Title = "Type";
                            $i3.Description = "Select the type of article you are creating";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-source-branch"], [-1], null);
                            $i3.OptionsReader = ($.$xrPB.LCCACM.CommunityArticleTypeReader.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$xrPB.LCCACM.CommunityArticlePostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $lmTTde ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":648109,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $iWgmne ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":648109,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590582701)
            
            static $h = 648109;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590582701),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 648109,
      "h": 8590582701,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590582701)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295615405),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 648109,
      "h": 4295615405,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295615405)
  ],
  "h": 648109
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticlePostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(648109)
        
        

        //--TRIMMABLE-BOUNDARY-START(2024365)
        $asm.$cls(`$xrPB.LCCACS$2.ArticleStatesTypeDescriptorBuilder`, ($self) => class ArticleStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591958957)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591958957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xrPB.LCCACS$2.ArticleStatesTypeDescriptor()
                        const $t1 = $.$xrPB.LCCACS$2.ArticleStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Article.Common.States.ArticleStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cXdDvi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2024365,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xrPB.LCCACS$2.ArticleStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591958957)
            
            //--TRIMMABLE-BOUNDARY-START(4296991661)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296991661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296991661)
            
            //--TRIMMABLE-BOUNDARY-START(4296991661)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296991661)
            
            static $h = 2024365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591958957),
    {
      "r": 65537,
      "n": "Register",
      "d": 2024365,
      "h": 8591958957,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591958957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296991661),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2024365,
      "h": 4296991661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296991661)
  ],
  "h": 2024365
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.States.ArticleStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}States${separator}ArticleStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2024365)
        
        

        //--TRIMMABLE-BOUNDARY-START(2089901)
        $asm.$cls(`$xrPB.LCCAC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297057197)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297057197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptorBuilder.Register();
                $.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptorBuilder.Register();
                $.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptorBuilder.Register();
                $.$xrPB.LCCACS$1.ArticleSettingsTypeDescriptorBuilder.Register();
                $.$xrPB.LCCACS$2.ArticleStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297057197)
            
            static $h = 2089901;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297057197),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2089901,
      "h": 4297057197,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297057197)
  ],
  "h": 2089901
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2089901)
        
        

        //--TRIMMABLE-BOUNDARY-START(451501)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityArticleCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590386093)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590386093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor()
                        const $t1 = $.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EKmtLd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":451501,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xrPB.LCCACM.CommunityArticleCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590386093)
            
            //--TRIMMABLE-BOUNDARY-START(4295418797)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295418797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295418797)
            
            //--TRIMMABLE-BOUNDARY-START(4295418797)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295418797)
            
            static $h = 451501;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590386093),
    {
      "r": 65537,
      "n": "Register",
      "d": 451501,
      "h": 8590386093,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590386093)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295418797),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 451501,
      "h": 4295418797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295418797)
  ],
  "h": 451501
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(451501)
        
        

        //--TRIMMABLE-BOUNDARY-START(779181)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptorBuilder`, ($self) => class CommunityArticlePostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590713773)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590713773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor()
                        const $t1 = $.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zYuItf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":779181,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xrPB.LCCACM.CommunityArticlePostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590713773)
            
            //--TRIMMABLE-BOUNDARY-START(4295746477)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295746477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295746477)
            
            //--TRIMMABLE-BOUNDARY-START(4295746477)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295746477)
            
            static $h = 779181;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590713773),
    {
      "r": 65537,
      "n": "Register",
      "d": 779181,
      "h": 8590713773,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590713773)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295746477),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 779181,
      "h": 4295746477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295746477)
  ],
  "h": 779181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticlePostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(779181)
        
        

        //--TRIMMABLE-BOUNDARY-START(1041325)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptorBuilder`, ($self) => class CommunityArticleServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590975917)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590975917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor()
                        const $t1 = $.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HXmwcg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1041325,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xrPB.LCCACM.CommunityArticleServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590975917)
            
            //--TRIMMABLE-BOUNDARY-START(4296008621)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296008621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296008621)
            
            //--TRIMMABLE-BOUNDARY-START(4296008621)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296008621)
            
            static $h = 1041325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590975917),
    {
      "r": 65537,
      "n": "Register",
      "d": 1041325,
      "h": 8590975917,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590975917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296008621),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1041325,
      "h": 4296008621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296008621)
  ],
  "h": 1041325
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1041325)
        
        

        //--TRIMMABLE-BOUNDARY-START(1237933)
        $asm.$cls(`$xrPB.LCCAC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591172525)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591172525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticleCategoryModel, 1281/*PostTypes.ArticleCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1280/*PostTypes.Article*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1282/*PostTypes.ArticlePost*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1283/*PostTypes.ArticleBlog*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1284/*PostTypes.ArticleJoke*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1285/*PostTypes.ArticleNews*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$xrPB.LCCACM.CommunityArticlePostModel, 1286/*PostTypes.ArticleNugget*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$xrPB.LCCACM.CommunityArticleCategoryReader, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$xrPB.LCCACM.CommunityArticleCategoryModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$xrPB.LCCACM.CommunityArticleCategoryReader, x);
                }, $WNPIdc ??= {"r":$.$fPer.LCFCA$1.ISchemaOptionReader$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":1237933,"h":0,"f":17825794}));
                $.$xrPB.LCCAC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$xrPB.LCCAC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$xrPB.LCCAC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591172525)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$xrPB.LCCAC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296205229)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296205229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296205229)
            
            //--TRIMMABLE-BOUNDARY-START(4296205229)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296205229)
            
            static $h = 1237933;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591172525),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1237933,
      "h": 8591172525,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591172525)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296205229),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1237933,
      "h": 4296205229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296205229)
  ],
  "h": 1237933
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1237933)
        
        

        //--TRIMMABLE-BOUNDARY-START(1500077)
        $asm.$cls(`$xrPB.LCCACS.IArticleRemoteService_Mocking`, ($self) => class IArticleRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296467373)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296467373);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296467373)
            
            static $h = 1500077;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296467373),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1500077,
      "h": 4296467373,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296467373)
  ],
  "h": 1500077
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$xrPB.LCCACS.IArticleRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Services.IArticleRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Services${separator}IArticleRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1500077)
        
        

        //--TRIMMABLE-BOUNDARY-START(1172397)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleUserPreference`, ($self) => class CommunityArticleUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4296139693)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296139693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296139693)
            
            //--TRIMMABLE-BOUNDARY-START(4296139693)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296139693)
            
            static $h = 1172397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296139693),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1172397,
      "h": 4296139693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296139693)
  ],
  "h": 1172397
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1172397)
        
        

        //--TRIMMABLE-BOUNDARY-START(1106861)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleTypeReader`, ($self) => class CommunityArticleTypeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591041453)
            /*Pager<ISelectOption<PostTypes?>> */ GetOptions(/*object*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591041453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCP.PostUtility.GetPostTypeOptions(this, "Article", null);
            }
            //--TRIMMABLE-BOUNDARY-END(8591041453)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Frameworks.Common.Posts.Models.PostTypes?>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            [`LCFCA$1$ISchemaOptionReader$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$$GetOptions`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4296074157)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296074157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296074157)
            
            //--TRIMMABLE-BOUNDARY-START(4296074157)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296074157)
            
            static $h = 1106861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591041453),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes))).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 1106861,
      "h": 8591041453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591041453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296074157),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1106861,
      "h": 4296074157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296074157)
  ],
  "h": 1106861
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleTypeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleTypeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1106861)
        
        

        //--TRIMMABLE-BOUNDARY-START(1827757)
        $asm.$cls(`$xrPB.LCCACS$2.ArticleStates`, ($self) => class ArticleStates extends $.$Iaui.LCFCMS$1.ServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296795053)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296795053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296795053)
            
            //--TRIMMABLE-BOUNDARY-START(4296795053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296795053)
            
            static $h = 1827757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296795053),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1827757,
      "h": 4296795053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296795053)
  ],
  "h": 1827757
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.States.ArticleStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}States${separator}ArticleStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1827757)
        
        

        //--TRIMMABLE-BOUNDARY-START(1565613)
        $asm.$cls(`$xrPB.LCCACS$1.ArticleSettings`, ($self) => class ArticleSettings extends $.$Iaui.LCFCMS.ServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296532909)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296532909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296532909)
            
            //--TRIMMABLE-BOUNDARY-START(4296532909)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296532909)
            
            static $h = 1565613;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296532909),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1565613,
      "h": 4296532909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296532909)
  ],
  "h": 1565613
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Settings.ArticleSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Settings${separator}ArticleSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1565613)
        
        

        //--TRIMMABLE-BOUNDARY-START(1696685)
        $asm.$cls(`$xrPB.LCCACS$1.ArticleSettingsTypeDescriptor`, ($self) => class ArticleSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACS$1.ArticleSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296663981)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296663981);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xrPB.LCCACS$1.ArticleSettingsTypeDescriptor.GenerateProperties($.$xrPB.LCCACS$1.ArticleSettings, this, factory);
                    }, $yCWQIg ??= {"r":65537,"n":"","d":1696685,"h":0,"f":17825794}), 0, "ArticleSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Article.Common\\Settings_ArticleSettings_LivingThing.Core.Community.Article.Common.Settings.ArticleSettingsTypeDescriptorBuilder.g.cs", "ArticleSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296663981)
            
            //--TRIMMABLE-BOUNDARY-START(12886598573)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886598573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886598573)
            
            //--TRIMMABLE-BOUNDARY-START(17181565869)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Settings.ArticleSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181565869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ServiceSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181565869)
            
            //--TRIMMABLE-BOUNDARY-START(8591631277)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Settings.ArticleSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591631277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xrPB.LCCACS$1.ArticleSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xrPB.LCCACS$1.ArticleSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$1.ArticleSettings)))
                {
                    /*var*/ let result = $.$xrPB.LCCACS$1.ArticleSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$1.ArticleSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xrPB.LCCACS$1.ArticleSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$1.ArticleSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591631277)
            
            static $h = 1696685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACS$1.ArticleSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886598573),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1696685,
      "h": 12886598573,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886598573),
//--TRIMMABLE-BOUNDARY-START(17181565869),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1565613,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1696685,
      "h": 17181565869,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181565869),
//--TRIMMABLE-BOUNDARY-START(8591631277),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1565613,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1696685,
      "h": 8591631277,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591631277)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296663981),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1696685,
      "h": 4296663981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296663981)
  ],
  "h": 1696685
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xrPB.LCCACS$1.ArticleSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Settings.ArticleSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Settings${separator}ArticleSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1696685)
        
        

        //--TRIMMABLE-BOUNDARY-START(1958829)
        $asm.$cls(`$xrPB.LCCACS$2.ArticleStatesTypeDescriptor`, ($self) => class ArticleStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACS$2.ArticleStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296926125)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296926125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xrPB.LCCACS$2.ArticleStatesTypeDescriptor.GenerateProperties($.$xrPB.LCCACS$2.ArticleStates, this, factory);
                    }, $ncEezb ??= {"r":65537,"n":"","d":1958829,"h":0,"f":17825794}), 0, "ArticleStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Article.Common\\States_ArticleStates_LivingThing.Core.Community.Article.Common.States.ArticleStatesTypeDescriptorBuilder.g.cs", "ArticleStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296926125)
            
            //--TRIMMABLE-BOUNDARY-START(12886860717)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886860717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886860717)
            
            //--TRIMMABLE-BOUNDARY-START(17181828013)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.States.ArticleStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181828013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ServiceStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181828013)
            
            //--TRIMMABLE-BOUNDARY-START(8591893421)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.States.ArticleStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591893421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xrPB.LCCACS$2.ArticleStates().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xrPB.LCCACS$2.ArticleStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$2.ArticleStates)))
                {
                    /*var*/ let result = $.$xrPB.LCCACS$2.ArticleStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$2.ArticleStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xrPB.LCCACS$2.ArticleStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACS$2.ArticleStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591893421)
            
            static $h = 1958829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACS$2.ArticleStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886860717),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1958829,
      "h": 12886860717,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886860717),
//--TRIMMABLE-BOUNDARY-START(17181828013),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1827757,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1958829,
      "h": 17181828013,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181828013),
//--TRIMMABLE-BOUNDARY-START(8591893421),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1827757,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1958829,
      "h": 8591893421,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591893421)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296926125),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1958829,
      "h": 4296926125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296926125)
  ],
  "h": 1958829
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xrPB.LCCACS$2.ArticleStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.States.ArticleStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}States${separator}ArticleStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1958829)
        
        

        $asm.$typeProxy("$xrPB.LCCACM.CommunityArticlePostModel", "$xrPB.LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel");
        //--TRIMMABLE-BOUNDARY-START(254893)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleCategoryModel`, ($self) => class CommunityArticleCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$xrPB.LCCACM.CommunityArticlePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180124077)
            /*PostTypes */ get Type()
            {
                return 1281/*PostTypes.ArticleCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180124077)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(4295222189)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295222189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295222189)
            
            //--TRIMMABLE-BOUNDARY-START(4295222189)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295222189)
            
            static $h = 254893;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180124077),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885156781,
        "f": 50364417
      },
      "n": "Type",
      "d": 254893,
      "h": 17180124077,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180124077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295222189),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 254893,
      "h": 4295222189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295222189)
  ],
  "h": 254893
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostByAdminOnly ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(254893)
        
        

        //--TRIMMABLE-BOUNDARY-START(582573)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticlePostModel`, ($self) => class CommunityArticlePostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $self)
        {
            //--TRIMMABLE-BOUNDARY-START(60130124717)
            /*PostTypes? */ get SetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475419053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType;
            }
            /*PostTypes? */ set SetType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835157421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60130124717)
            
            //--TRIMMABLE-BOUNDARY-START(64425092013)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 1282/*PostTypes.ArticlePost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64425092013)
            
            //--TRIMMABLE-BOUNDARY-START(42950255533)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950255533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950255533)
            
            //--TRIMMABLE-BOUNDARY-START(47245222829)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245222829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245222829)
            
            //--TRIMMABLE-BOUNDARY-START(34360320941)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Article", "Post"], null, null), null, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(34360320941)
            
            //--TRIMMABLE-BOUNDARY-START(38655288237)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655288237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Title", "Provide an appropriate title that identifies this article", null, null, null);
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(38655288237)
            
            //--TRIMMABLE-BOUNDARY-START(8593009076)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReactable.Reactions.get
            get LCFCP$IPostReactable$Reactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887976372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reactions;
            }
            //--TRIMMABLE-BOUNDARY-END(8593009076)
            
            //--TRIMMABLE-BOUNDARY-START(8592878004)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRatable.Ratings.get
            get LCFCP$IPostRatable$Ratings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887845300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Ratings;
            }
            //--TRIMMABLE-BOUNDARY-END(8592878004)
            
            //--TRIMMABLE-BOUNDARY-START(21477779892)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostRatable.Ratings.set
            set LCFCP$IPostRatable$Ratings(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887845300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Ratings = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477779892)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8594319796)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostViewTrackable.ViewsCount.get
            get LCFCP$IPostViewTrackable$ViewsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889287092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594319796)
            
            //--TRIMMABLE-BOUNDARY-START(8594057652)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostTaggable.Tags.get
            get LCFCP$IPostTaggable$Tags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889024948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tags;
            }
            //--TRIMMABLE-BOUNDARY-END(8594057652)
            
            //--TRIMMABLE-BOUNDARY-START(4295549869)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295549869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295549869)
            
            //--TRIMMABLE-BOUNDARY-START(4295549869)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295549869)
            
            static $h = 582573;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130124717),
    {
      "p": $.$typeNullable($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475419053,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835157421,
        "f": 83918849
      },
      "n": "SetType",
      "d": 582573,
      "h": 60130124717,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Type",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "Select the type of article you are creating",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-source-branch"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 1106861,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130124717),
//--TRIMMABLE-BOUNDARY-START(64425092013),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065353645,
        "f": 50364417
      },
      "n": "Type",
      "d": 582573,
      "h": 64425092013,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425092013),
//--TRIMMABLE-BOUNDARY-START(34360320941),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885484461,
        "f": 50364417
      },
      "n": "Link",
      "d": 582573,
      "h": 34360320941,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360320941)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950255533),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 582573,
      "h": 42950255533,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950255533),
//--TRIMMABLE-BOUNDARY-START(47245222829),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 582573,
      "h": 47245222829,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245222829),
//--TRIMMABLE-BOUNDARY-START(38655288237),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 582573,
      "h": 38655288237,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655288237)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295549869),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 582573,
      "h": 4295549869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295549869)
  ],
  "h": 582573
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostRatable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostTaggable, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticlePostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(582573)
        
        

        //--TRIMMABLE-BOUNDARY-START(1303469)
        $asm.$cls(`$xrPB.LCCACS.IArticleFeedRemoteService`, ($self) => class IArticleFeedRemoteService
        {
            static $h = 1303469;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1303469,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Services.IArticleFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Services${separator}IArticleFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1303469)
        
        

        //--TRIMMABLE-BOUNDARY-START(2155437)
        $asm.$cls(`$xrPB.LCCBCS.IComunityArticleRemoteService`, ($self) => class IComunityArticleRemoteService
        {
            static $h = 2155437;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2155437,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.IComunityArticleRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}IComunityArticleRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2155437)
        
        

        //--TRIMMABLE-BOUNDARY-START(517037)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleCategoryReader`, ($self) => class CommunityArticleCategoryReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885418925)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(12885418925)
            
            //--TRIMMABLE-BOUNDARY-START(17180386221)
            /*ICommunityApplicationService<CommunityArticleCategoryModel, CommunityArticlePostModel>*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(17180386221)
            
            //--TRIMMABLE-BOUNDARY-START(4295484333)
            $ctor$1(/*ICommunityApplicationService<CommunityArticleCategoryModel, CommunityArticlePostModel>*/ service, /*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295484333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.service = service;
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295484333)
            
            //--TRIMMABLE-BOUNDARY-START(8590451629)
            /*Pager<ISelectOption<CommunityArticleCategoryModel?>> */ GetOptions(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590451629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.service.LCCCS$ICommunityApplicationService$$$$$Categories !== null)
                {
                    return $.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$sl.SL.Enumerable.Select$1($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), this.service.LCCCS$ICommunityApplicationService$$$$$Categories, new ($.$$.S.Func$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return new ($.$fPer.LCFC.SelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel))().$ctor$3(c);
                    }, $fOHKJh ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,"p":[{"n":"c","p":254893}],"n":"","d":517037,"h":0,"f":17825794})), null);
                }
                return $.$fPer.LCFCD.Paging.Select($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$xrPB.LCCACM.CommunityArticleCategoryModel, this.server, null, null), new ($.$$.S.Func$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel)))().$ctor(this,  (/*c*/ c) =>
                {
                    return new ($.$fPer.LCFC.SelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel))().$ctor$3(c);
                }, $OFXCZa ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,"p":[{"n":"c","p":254893}],"n":"","d":517037,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590451629)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaOptionReader$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$GetOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            static $h = 517037;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590451629),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$xrPB.LCCACM.CommunityArticleCategoryModel)).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 517037,
      "h": 8590451629,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590451629)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885418925),
    {
      "t": 1309651,
      "n": "server",
      "d": 517037,
      "h": 12885418925,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885418925),
//--TRIMMABLE-BOUNDARY-START(17180386221),
    {
      "t": $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).$h,
      "n": "service",
      "d": 517037,
      "h": 17180386221,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180386221)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295484333),
    {
      "p": [
        {
          "n": "service",
          "p": $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).$h
        },
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 517037,
      "h": 4295484333,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295484333)
  ],
  "h": 517037
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$xrPB.LCCACM.CommunityArticleCategoryModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleCategoryReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(517037)
        
        

        //--TRIMMABLE-BOUNDARY-START(1369005)
        $asm.$cls(`$xrPB.LCCACS.IArticleFeedRemoteService_Mocking`, ($self) => class IArticleFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296336301)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296336301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296336301)
            
            //--TRIMMABLE-BOUNDARY-START(8591303597)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591303597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591303597)
            
            static $h = 1369005;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296336301),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1369005,
      "h": 4296336301,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296336301)
  ],
  "h": 1369005
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$xrPB.LCCACS.IArticleFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Services.IArticleFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Services${separator}IArticleFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1369005)
        
        

        //--TRIMMABLE-BOUNDARY-START(2286509)
        $asm.$cls(`$xrPB.LCFCR.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297253805)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297253805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297253805)
            
            //--TRIMMABLE-BOUNDARY-START(8592221101)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592221101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592221101)
            
            //--TRIMMABLE-BOUNDARY-START(17182155693)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182155693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xrPB.LCCACM.CommunityArticleCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182155693)
            
            //--TRIMMABLE-BOUNDARY-START(21477122989)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477122989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.WireTransportModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xrPB.LCCACM.CommunityArticleCategoryModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477122989)
            
            //--TRIMMABLE-BOUNDARY-START(25772090285)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticleCategoryModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772090285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772090285)
            
            //--TRIMMABLE-BOUNDARY-START(12887188397)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887188397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887188397)
            
            static $h = 2286509;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297253805),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2286509,
      "h": 4297253805,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297253805)
  ],
  "h": 2286509
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.IReadDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityArticleCategoryModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2286509)
        
        

        //--TRIMMABLE-BOUNDARY-START(2220973)
        $asm.$cls(`$xrPB.LCCBCS.IComunityArticleRemoteService_Mocking`, ($self) => class IComunityArticleRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297188269)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297188269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297188269)
            
            //--TRIMMABLE-BOUNDARY-START(8592155565)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592155565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592155565)
            
            //--TRIMMABLE-BOUNDARY-START(17182090157)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182090157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xrPB.LCCACM.CommunityArticlePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182090157)
            
            //--TRIMMABLE-BOUNDARY-START(21477057453)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477057453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportModel$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$xrPB.LCCACM.CommunityArticlePostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477057453)
            
            //--TRIMMABLE-BOUNDARY-START(25772024749)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Article$Common$Models$CommunityArticlePostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772024749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772024749)
            
            //--TRIMMABLE-BOUNDARY-START(12887122861)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887122861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887122861)
            
            static $h = 2220973;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297188269),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2220973,
      "h": 4297188269,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297188269)
  ],
  "h": 2220973
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$xrPB.LCCBCS.IComunityArticleRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.ICreateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.IComunityArticleRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}IComunityArticleRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2220973)
        
        

        //--TRIMMABLE-BOUNDARY-START(385965)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor`, ($self) => class CommunityArticleCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295353261)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295353261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor.GenerateProperties($.$xrPB.LCCACM.CommunityArticleCategoryModel, this, factory);
                    }, $tXUamb ??= {"r":65537,"n":"","d":385965,"h":0,"f":17825794}), 0, "CommunityArticleCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Article.Common\\Models_CommunityArticleCategoryModel_LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModelTypeDescriptorBuilder.g.cs", "CommunityArticleCategoryModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295353261)
            
            //--TRIMMABLE-BOUNDARY-START(12885287853)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885287853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticleCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$xrPB.LCCACM.CommunityArticleCategoryModel)).Type);
                        }, $KXunAb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":385965,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885287853)
            
            //--TRIMMABLE-BOUNDARY-START(17180255149)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180255149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel, LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180255149)
            
            //--TRIMMABLE-BOUNDARY-START(8590320557)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590320557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xrPB.LCCACM.CommunityArticleCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xrPB.LCCACM.CommunityArticleCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleCategoryModel)))
                {
                    /*var*/ let result = $.$xrPB.LCCACM.CommunityArticleCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xrPB.LCCACM.CommunityArticleCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590320557)
            
            static $h = 385965;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885287853),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 385965,
      "h": 12885287853,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885287853),
//--TRIMMABLE-BOUNDARY-START(17180255149),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 254893,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 385965,
      "h": 17180255149,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180255149),
//--TRIMMABLE-BOUNDARY-START(8590320557),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 254893,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 385965,
      "h": 8590320557,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590320557)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295353261),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 385965,
      "h": 4295353261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295353261)
  ],
  "h": 385965
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(385965)
        
        

        //--TRIMMABLE-BOUNDARY-START(713645)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor`, ($self) => class CommunityArticlePostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticlePostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295680941)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295680941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor.GenerateProperties($.$xrPB.LCCACM.CommunityArticlePostModel, this, factory);
                    }, $SDySye ??= {"r":65537,"n":"","d":713645,"h":0,"f":17825794}), 0, "CommunityArticlePostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Article.Common\\Models_CommunityArticlePostModel_LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModelTypeDescriptorBuilder.g.cs", "CommunityArticlePostModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295680941)
            
            //--TRIMMABLE-BOUNDARY-START(12885615533)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885615533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SetType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticlePostModel.$type, $.$discardRef(), "SetType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SetType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SetType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$xrPB.LCCACM.CommunityArticlePostModel)).SetType);
                        }, $PtRuKe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":713645,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SetType = value.AsNullableValue($.$LCOv.LCFCPM$1.PostTypes);
                        }, $XHMnFc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":713645,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticlePostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$xrPB.LCCACM.CommunityArticlePostModel)).Type);
                        }, $Xcfsfj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":713645,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticlePostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Link";
                        $i5.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$xrPB.LCCACM.CommunityArticlePostModel)).Link);
                        }, $XsgpTi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":713645,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885615533)
            
            //--TRIMMABLE-BOUNDARY-START(17180582829)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180582829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Article.Common.Models.CommunityArticleCategoryModel, LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$xrPB.LCCACM.CommunityArticleCategoryModel, $.$xrPB.LCCACM.CommunityArticlePostModel)));
                {
                    /*var*/ let _SetType = _target.SetType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SetType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), () => _SetType, ($v) => _SetType = $v, null, true)))
                    {
                        _target.SetType = _SetType;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180582829)
            
            //--TRIMMABLE-BOUNDARY-START(8590648237)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590648237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xrPB.LCCACM.CommunityArticlePostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xrPB.LCCACM.CommunityArticlePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticlePostModel)))
                {
                    /*var*/ let result = $.$xrPB.LCCACM.CommunityArticlePostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticlePostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xrPB.LCCACM.CommunityArticlePostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticlePostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590648237)
            
            static $h = 713645;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticlePostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885615533),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 713645,
      "h": 12885615533,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885615533),
//--TRIMMABLE-BOUNDARY-START(17180582829),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 582573,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 713645,
      "h": 17180582829,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180582829),
//--TRIMMABLE-BOUNDARY-START(8590648237),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 582573,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 713645,
      "h": 8590648237,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590648237)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295680941),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 713645,
      "h": 4295680941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295680941)
  ],
  "h": 713645
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xrPB.LCCACM.CommunityArticlePostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticlePostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticlePostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(713645)
        
        

        //--TRIMMABLE-BOUNDARY-START(844717)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleServiceModel`, ($self) => class CommunityArticleServiceModel extends $.$Iaui.LCFCM.ServiceModel$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates)
        {
            //--TRIMMABLE-BOUNDARY-START(25770648493)
            /*CommunityArticleCategoryModel[]*/ Categories = null;
            //--TRIMMABLE-BOUNDARY-END(25770648493)
            
            //--TRIMMABLE-BOUNDARY-START(30065615789)
            /*CommunityArticleCategoryModel[]*/ DateCategories = null;
            //--TRIMMABLE-BOUNDARY-END(30065615789)
            
            //--TRIMMABLE-BOUNDARY-START(34360583085)
            /*CommunityArticlePostModel[]*/ Featured = null;
            //--TRIMMABLE-BOUNDARY-END(34360583085)
            
            //--TRIMMABLE-BOUNDARY-START(73015288749)
            /*CommunityArticlePostModel[]*/ Recent = null;
            //--TRIMMABLE-BOUNDARY-END(73015288749)
            
            //--TRIMMABLE-BOUNDARY-START(21475681197)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475681197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475681197)
            
            //--TRIMMABLE-BOUNDARY-START(21475681197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(21475681197)
            
            static $h = 844717;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ServiceModel$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770648493),
    {
      "p": $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950517677,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605223341,
        "f": 83886081
      },
      "n": "Categories",
      "d": 844717,
      "h": 25770648493,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770648493),
//--TRIMMABLE-BOUNDARY-START(30065615789),
    {
      "p": $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540452269,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195157933,
        "f": 83886081
      },
      "n": "DateCategories",
      "d": 844717,
      "h": 30065615789,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065615789),
//--TRIMMABLE-BOUNDARY-START(34360583085),
    {
      "p": $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130386861,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785092525,
        "f": 83886081
      },
      "n": "Featured",
      "d": 844717,
      "h": 34360583085,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360583085),
//--TRIMMABLE-BOUNDARY-START(73015288749),
    {
      "p": $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720321453,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375027117,
        "f": 83886081
      },
      "n": "Recent",
      "d": 844717,
      "h": 73015288749,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015288749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475681197),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 844717,
      "h": 21475681197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475681197)
  ],
  "h": 844717
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(844717)
        
        

        //--TRIMMABLE-BOUNDARY-START(975789)
        $asm.$cls(`$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor`, ($self) => class CommunityArticleServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295943085)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295943085);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor.GenerateProperties($.$xrPB.LCCACM.CommunityArticleServiceModel, this, factory);
                    }, $kFOgla ??= {"r":65537,"n":"","d":975789,"h":0,"f":17825794}), 0, "CommunityArticleServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Article.Common\\Models_CommunityArticleServiceModel_LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModelTypeDescriptorBuilder.g.cs", "CommunityArticleServiceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295943085)
            
            //--TRIMMABLE-BOUNDARY-START(12885877677)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885877677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Categories"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticleServiceModel.$type, $.$discardRef(), "Categories", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Categories")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Categories";
                        $i1.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), ($.$cast(target, $.$xrPB.LCCACM.CommunityArticleServiceModel)).Categories);
                        }, $lJKlmb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":975789,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Categories = value.AsReference($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel));
                        }, $stjdqa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":975789,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DateCategories"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticleServiceModel.$type, $.$discardRef(), "DateCategories", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DateCategories")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DateCategories";
                        $i3.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), ($.$cast(target, $.$xrPB.LCCACM.CommunityArticleServiceModel)).DateCategories);
                        }, $wzzgud ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":975789,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.DateCategories = value.AsReference($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel));
                        }, $PZKVik ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":975789,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Featured"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticleServiceModel.$type, $.$discardRef(), "Featured", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Featured")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Featured";
                        $i5.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), ($.$cast(target, $.$xrPB.LCCACM.CommunityArticleServiceModel)).Featured);
                        }, $JxOyPj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":975789,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Featured = value.AsReference($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel));
                        }, $xCVzfl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":975789,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Recent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xrPB.LCCACM.CommunityArticleServiceModel.$type, $.$discardRef(), "Recent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Recent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Recent";
                        $i7.DelaredOn = "LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), ($.$cast(target, $.$xrPB.LCCACM.CommunityArticleServiceModel)).Recent);
                        }, $xYdcai ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":975789,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Recent = value.AsReference($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel));
                        }, $avtHPh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":975789,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885877677)
            
            //--TRIMMABLE-BOUNDARY-START(17180844973)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180844973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ServiceModel<LivingThing.Core.Community.Article.Common.Settings.ArticleSettings, LivingThing.Core.Community.Article.Common.States.ArticleStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ServiceModel$$$($.$xrPB.LCCACS$1.ArticleSettings, $.$xrPB.LCCACS$2.ArticleStates)));
                {
                    /*var*/ let _Categories = _target.Categories;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Categories"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel))))
                    {
                        _target.Categories = _Categories;
                        if (_Categories !== null)
                        {
                            let $i12 = 0;
                            let $arr12 = _Categories;
                            while ($i12 < $arr12.length)
                            {
                                let item = $arr12[$i12++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$xrPB.LCCACM.CommunityArticleCategoryModel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel)));
                    }
                }
                {
                    /*var*/ let _DateCategories = _target.DateCategories;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DateCategories"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel, property, $.$ref(() => _DateCategories, ($v) => _DateCategories = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel))))
                    {
                        _target.DateCategories = _DateCategories;
                        if (_DateCategories !== null)
                        {
                            let $i17 = 0;
                            let $arr17 = _DateCategories;
                            while ($i17 < $arr17.length)
                            {
                                let item = $arr17[$i17++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$xrPB.LCCACM.CommunityArticleCategoryModel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel), $.$xrPB.LCCACM.CommunityArticleCategoryModel, property, $.$ref(() => _DateCategories, ($v) => _DateCategories = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticleCategoryModel)));
                    }
                }
                {
                    /*var*/ let _Featured = _target.Featured;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Featured"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel, property, $.$ref(() => _Featured, ($v) => _Featured = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel))))
                    {
                        _target.Featured = _Featured;
                        if (_Featured !== null)
                        {
                            let $i22 = 0;
                            let $arr22 = _Featured;
                            while ($i22 < $arr22.length)
                            {
                                let item = $arr22[$i22++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$xrPB.LCCACM.CommunityArticlePostModel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel, property, $.$ref(() => _Featured, ($v) => _Featured = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel)));
                    }
                }
                {
                    /*var*/ let _Recent = _target.Recent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Recent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel, property, $.$ref(() => _Recent, ($v) => _Recent = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel))))
                    {
                        _target.Recent = _Recent;
                        if (_Recent !== null)
                        {
                            let $i27 = 0;
                            let $arr27 = _Recent;
                            while ($i27 < $arr27.length)
                            {
                                let item = $arr27[$i27++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$xrPB.LCCACM.CommunityArticlePostModel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel), $.$xrPB.LCCACM.CommunityArticlePostModel, property, $.$ref(() => _Recent, ($v) => _Recent = $v, $.$typeArray($.$xrPB.LCCACM.CommunityArticlePostModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180844973)
            
            //--TRIMMABLE-BOUNDARY-START(8590910381)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590910381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xrPB.LCCACM.CommunityArticleServiceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xrPB.LCCACM.CommunityArticleServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleServiceModel)))
                {
                    /*var*/ let result = $.$xrPB.LCCACM.CommunityArticleServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xrPB.LCCACM.CommunityArticleServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xrPB.LCCACM.CommunityArticleServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590910381)
            
            static $h = 975789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885877677),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 975789,
      "h": 12885877677,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885877677),
//--TRIMMABLE-BOUNDARY-START(17180844973),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 844717,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 975789,
      "h": 17180844973,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180844973),
//--TRIMMABLE-BOUNDARY-START(8590910381),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 844717,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 975789,
      "h": 8590910381,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590910381)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295943085),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 975789,
      "h": 4295943085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295943085)
  ],
  "h": 975789
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xrPB.LCCACM.CommunityArticleServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Article.Common.Models.CommunityArticleServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Article${separator}Common${separator}Models${separator}CommunityArticleServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(975789)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(58285)
