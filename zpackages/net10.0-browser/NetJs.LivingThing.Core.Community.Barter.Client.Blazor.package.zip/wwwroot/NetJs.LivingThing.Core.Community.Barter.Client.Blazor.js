
//--TRIMMABLE-BOUNDARY-START(20344)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $OkRL, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $yUlEDi;
    let $mlBoDe;
    let $gfBoIg;
    let $EUsqnb;
    let $iPyZlg;
    let $cfNxjl;
    let $qVCsLa;
    let $IApLib;
    let $UObjcl;
    let $nzxXHg;
    let $ThZZWi;
    let $WnNAPg;
    let $BDkcNf;
    let $tbWnLd;
    let $jTnMCj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Barter.Client.Blazor", 
    {
  "h": 20344,
  "f": "LivingThing.Core.Community.Barter.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Barter.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Barter.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(151416)
        $asm.$cls(`$wQhY.LCCBC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295118712)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295118712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$wQhY.LCCBC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295118712)
            
            static $h = 151416;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295118712),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 151416,
      "h": 4295118712,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295118712)
  ],
  "h": 151416
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(151416)
        
        

        //--TRIMMABLE-BOUNDARY-START(216952)
        $asm.$cls(`$wQhY.LCCBC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180086136)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$wQhY.LCCBCP.CommunityBarterApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$wQhY.LCCBCP.CommunityBarterApp().$ctor$3();
                    }, $yUlEDi ??= {"r":2752627,"n":"","d":216952,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180086136)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295184248)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295184248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295184248)
            
            //--TRIMMABLE-BOUNDARY-START(4295184248)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295184248)
            
            static $h = 216952;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180086136),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885118840,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 216952,
      "h": 17180086136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180086136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295184248),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 216952,
      "h": 4295184248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295184248)
  ],
  "h": 216952
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216952)
        
        

        //--TRIMMABLE-BOUNDARY-START(348024)
        $asm.$cls(`$wQhY.LCCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590282616)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590282616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$wQhY.LCCBCS.CommunityBarterService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$OkRL.LCCBCM.CommunityBarterPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$wQhY.LCCBCS.CommunityBarterApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wQhY.LCCBCS.CommunityBarterApplication, x);
                }, $mlBoDe ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":348024,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$wQhY.LCCBCS.CommunityBarterApplication, x);
                }, $gfBoIg ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":348024,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$wQhY.LCCBCS.CommunityBarterFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$OkRL.LCCBCM.CommunityBarterPostModel, services, null);
                $.$wQhY.LCCBC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590282616)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$wQhY.LCCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295315320)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295315320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295315320)
            
            //--TRIMMABLE-BOUNDARY-START(4295315320)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295315320)
            
            static $h = 348024;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590282616),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 348024,
      "h": 8590282616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590282616)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295315320),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 348024,
      "h": 4295315320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295315320)
  ],
  "h": 348024
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(348024)
        
        

        //--TRIMMABLE-BOUNDARY-START(675704)
        $asm.$cls(`$wQhY.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295643000)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295643000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295643000)
            
            //--TRIMMABLE-BOUNDARY-START(4295643000)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295643000)
            
            static $h = 675704;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295643000),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 675704,
      "h": 4295643000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295643000)
  ],
  "h": 675704,
  "a": [
    {
      "t": 610168,
      "c": 4295577464
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(675704)
        
        

        //--TRIMMABLE-BOUNDARY-START(610168)
        $asm.$cls(`$wQhY.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295577464)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295577464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295577464)
            
            //--TRIMMABLE-BOUNDARY-START(4295577464)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295577464)
            
            static $h = 610168;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295577464),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 610168,
      "h": 4295577464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295577464)
  ],
  "h": 610168
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(610168)
        
        

        //--TRIMMABLE-BOUNDARY-START(85880)
        $asm.$cls(`$wQhY.LCCBC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590020472)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590020472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590020472)
            
            //--TRIMMABLE-BOUNDARY-START(4295053176)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295053176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295053176)
            
            //--TRIMMABLE-BOUNDARY-START(4295053176)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295053176)
            
            static $h = 85880;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590020472),
    {
      "r": 65537,
      "n": "Execute",
      "d": 85880,
      "h": 8590020472,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590020472)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295053176),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 85880,
      "h": 4295053176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295053176)
  ],
  "h": 85880
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85880)
        
        

        //--TRIMMABLE-BOUNDARY-START(282488)
        $asm.$cls(`$wQhY.LCCBCP.CommunityBarterApp`, ($self) => class CommunityBarterApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(60129824632)
            /*CommunityBarterService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(60129824632)
            
            //--TRIMMABLE-BOUNDARY-START(21475118968)
            /*CommunityBarterApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475118968)
            
            //--TRIMMABLE-BOUNDARY-START(55834857336)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(55834857336)
            
            //--TRIMMABLE-BOUNDARY-START(25770086264)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770086264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "InitialViewIndex", "0");
                __builder.AddComponentParameter(2, "Name", "Barter");
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ & ~2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                        __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, wrap.View);
                        }), $EUsqnb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282488,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $iPyZlg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282488,"h":0,"f":17825794});
                }), $cfNxjl ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":282488,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/*splash*/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 11);
                        __builder2.AddComponentParameter(12, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(13, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $qVCsLa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282488,"h":0,"f":17825794});
                }), $IApLib ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":282488,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 15);
                    __builder2.AddComponentParameter(16, "Name", "");
                    __builder2.AddComponentParameter(17, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(19, "Barter");
                        }, $UObjcl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282488,"h":0,"f":17825794});
                    }), $nzxXHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":282488,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(21, "<i class=\"mdi mdi-book\"></i>");
                        }, $ThZZWi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282488,"h":0,"f":17825794});
                    }), $WnNAPg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":282488,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityApplicationUnderDevelopment, 23);
                            __builder3.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.Application));
                            __builder3.CloseComponent();
                        }, $BDkcNf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":282488,"h":0,"f":17825794});
                    }), $tbWnLd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":282488,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $jTnMCj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":282488,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770086264)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180151672)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180151672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180151672)
            
            //--TRIMMABLE-BOUNDARY-START(17180151672)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180151672)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129824632)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(60129824632)
                
                //--TRIMMABLE-BOUNDARY-START(21475118968)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475118968)
                
                //--TRIMMABLE-BOUNDARY-START(55834857336)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(55834857336)
                
            }
            static $h = 282488;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129824632),
    {
      "p": 544632,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539890040,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899628408,
        "f": 83886081
      },
      "n": "Service",
      "d": 282488,
      "h": 60129824632,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129824632),
//--TRIMMABLE-BOUNDARY-START(21475118968),
    {
      "p": 413560,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360020856,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719759224,
        "f": 83886081
      },
      "n": "Application",
      "d": 282488,
      "h": 21475118968,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475118968),
//--TRIMMABLE-BOUNDARY-START(55834857336),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949955448,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309693816,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 282488,
      "h": 55834857336,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834857336)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770086264),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 282488,
      "h": 25770086264,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770086264)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180151672),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 282488,
      "h": 17180151672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180151672)
  ],
  "h": 282488
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.Pages.CommunityBarterApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}Pages${separator}CommunityBarterApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(282488)
        
        

        //--TRIMMABLE-BOUNDARY-START(479096)
        $asm.$cls(`$wQhY.LCCBCS.CommunityBarterFeedProvider`, ($self) => class CommunityBarterFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OkRL.LCCBCM.CommunityBarterPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295446392)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295446392);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295446392)
            
            //--TRIMMABLE-BOUNDARY-START(8590413688)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityBarterPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590413688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an article`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590413688)
            
            static $h = 479096;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OkRL.LCCBCM.CommunityBarterPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590413688),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 510789
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 479096,
      "h": 8590413688,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590413688)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295446392),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 479096,
      "h": 4295446392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295446392)
  ],
  "h": 479096
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.Services.CommunityBarterFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}Services${separator}CommunityBarterFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(479096)
        
        

        //--TRIMMABLE-BOUNDARY-START(413560)
        $asm.$cls(`$wQhY.LCCBCS.CommunityBarterApplication`, ($self) => class CommunityBarterApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885315448)
            $ctor$5(/*CommunityBarterService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885315448);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885315448)
            
            //--TRIMMABLE-BOUNDARY-START(137439367032)
            /*string */ get Name()
            {
                return "Barter";
            }
            //--TRIMMABLE-BOUNDARY-END(137439367032)
            
            //--TRIMMABLE-BOUNDARY-START(158914203512)
            /*string */ get Title()
            {
                return "Barter";
            }
            //--TRIMMABLE-BOUNDARY-END(158914203512)
            
            //--TRIMMABLE-BOUNDARY-START(21475250040)
            /*string */ get Description()
            {
                return "Post a Barter agent, send, track and receive a package from the comfort of your phone.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475250040)
            
            //--TRIMMABLE-BOUNDARY-START(133144399736)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-package"/*MaterialDesignIconNames.Package*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144399736)
            
            //--TRIMMABLE-BOUNDARY-START(154619236216)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619236216)
            
            //--TRIMMABLE-BOUNDARY-START(30065184632)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065184632)
            
            //--TRIMMABLE-BOUNDARY-START(17180282744)
            /*Type? */ get ApplicationViewType()
            {
                return $.$wQhY.LCCBCP.CommunityBarterApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180282744)
            
            //--TRIMMABLE-BOUNDARY-START(128849432440)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849432440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$wQhY.LCCBCP.CommunityBarterApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849432440)
            
            //--TRIMMABLE-BOUNDARY-START(25770217336)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770217336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770217336)
            
            //--TRIMMABLE-BOUNDARY-START(146029301624)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029301624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029301624)
            
            //--TRIMMABLE-BOUNDARY-START(141734334328)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734334328)
            
            //--TRIMMABLE-BOUNDARY-START(4295380856)
            /*CommunityBarterService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295380856)
            
            //--TRIMMABLE-BOUNDARY-START(150324268920)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324268920)
            
            //--TRIMMABLE-BOUNDARY-START(163209170808)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(6144/*PostTypes.Barter*/, 6145/*PostTypes.BarterEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209170808)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 413560;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439367032),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604792184,
        "f": 50364417
      },
      "n": "Name",
      "d": 413560,
      "h": 137439367032,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439367032),
//--TRIMMABLE-BOUNDARY-START(158914203512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964530552,
        "f": 50364417
      },
      "n": "Title",
      "d": 413560,
      "h": 158914203512,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914203512),
//--TRIMMABLE-BOUNDARY-START(21475250040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834988408,
        "f": 50364417
      },
      "n": "Description",
      "d": 413560,
      "h": 21475250040,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475250040),
//--TRIMMABLE-BOUNDARY-START(133144399736),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014857592,
        "f": 50364417
      },
      "n": "Icon",
      "d": 413560,
      "h": 133144399736,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144399736),
//--TRIMMABLE-BOUNDARY-START(154619236216),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374595960,
        "f": 50364417
      },
      "n": "Theme",
      "d": 413560,
      "h": 154619236216,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619236216),
//--TRIMMABLE-BOUNDARY-START(30065184632),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424923000,
        "f": 50364417
      },
      "n": "Features",
      "d": 413560,
      "h": 30065184632,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065184632),
//--TRIMMABLE-BOUNDARY-START(17180282744),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245053816,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 413560,
      "h": 17180282744,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180282744),
//--TRIMMABLE-BOUNDARY-START(141734334328),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194726776,
        "f": 50364417
      },
      "n": "Order",
      "d": 413560,
      "h": 141734334328,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734334328),
//--TRIMMABLE-BOUNDARY-START(4295380856),
    {
      "p": 544632,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655119224,
        "f": 50331650
      },
      "n": "_Service",
      "d": 413560,
      "h": 4295380856,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295380856),
//--TRIMMABLE-BOUNDARY-START(150324268920),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784661368,
        "f": 50364417
      },
      "n": "Service",
      "d": 413560,
      "h": 150324268920,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324268920),
//--TRIMMABLE-BOUNDARY-START(163209170808),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554465144,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 413560,
      "h": 163209170808,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209170808)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849432440),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 413560,
      "h": 128849432440,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849432440),
//--TRIMMABLE-BOUNDARY-START(25770217336),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 413560,
      "h": 25770217336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770217336),
//--TRIMMABLE-BOUNDARY-START(146029301624),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 413560,
      "h": 146029301624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029301624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885315448),
    {
      "p": [
        {
          "n": "service",
          "p": 544632
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 413560,
      "h": 12885315448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885315448)
  ],
  "h": 413560
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$OkRL.LCCBCM.CommunityBarterPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.Services.CommunityBarterApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}Services${separator}CommunityBarterApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(413560)
        
        

        //--TRIMMABLE-BOUNDARY-START(544632)
        $asm.$cls(`$wQhY.LCCBCS.CommunityBarterService`, ($self) => class CommunityBarterService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OkRL.LCCBCM.CommunityBarterPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295511928)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295511928);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295511928)
            
            static $h = 544632;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OkRL.LCCBCM.CommunityBarterPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295511928),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 544632,
      "h": 4295511928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295511928)
  ],
  "h": 544632
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OkRL.LCCBCM.CommunityBarterPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OkRL.LCCBCM.CommunityBarterPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Client.Services.CommunityBarterService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Client${separator}Services${separator}CommunityBarterService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(544632)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Barter.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(20344)
