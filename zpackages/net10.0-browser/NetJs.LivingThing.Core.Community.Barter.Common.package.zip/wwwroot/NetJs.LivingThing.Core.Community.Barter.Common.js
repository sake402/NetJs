
//--TRIMMABLE-BOUNDARY-START(52037)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $PZwDBj;
    let $adWspj;
    let $fYfTuh;
    let $gkqzza;
    let $LYcnjc;
    let $raRzod;
    let $Syoqmc;
    let $rFARGh;
    let $AGuMEe;
    let $zNPxPh;
    let $nSNRKk;
    let $ScSQEc;
    let $YPoGUc;
    let $ihbiEj;
    let $Nfavmd;
    let $DmKQOk;
    let $pAFrLd;
    let $tYnypk;
    let $oWDbel;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Barter.Common", 
    {
  "h": 52037,
  "f": "LivingThing.Core.Community.Barter.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Barter.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Barter.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1493829)
        $asm.$cls(`$OkRL.LCCBCS$2.CommunityBarterStatesCustomAttributesProvider`, ($self) => class CommunityBarterStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296461125)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296461125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296461125)
            
            static $h = 1493829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296461125),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1493829,
      "h": 4296461125,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296461125)
  ],
  "h": 1493829
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.States.CommunityBarterStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}States${separator}CommunityBarterStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1493829)
        
        

        //--TRIMMABLE-BOUNDARY-START(1690437)
        $asm.$cls(`$OkRL.LCCBC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296657733)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296657733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OkRL.LCCBCM.CommunityBarterModelTypeDescriptorBuilder.Register();
                $.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptorBuilder.Register();
                $.$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptorBuilder.Register();
                $.$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296657733)
            
            static $h = 1690437;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296657733),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1690437,
      "h": 4296657733,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296657733)
  ],
  "h": 1690437
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1690437)
        
        

        //--TRIMMABLE-BOUNDARY-START(576325)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterPostModelCustomAttributesProvider`, ($self) => class CommunityBarterPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295543621)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295543621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295543621)
            
            static $h = 576325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295543621),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 576325,
      "h": 4295543621,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295543621)
  ],
  "h": 576325
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(576325)
        
        

        //--TRIMMABLE-BOUNDARY-START(314181)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterModelCustomAttributesProvider`, ($self) => class CommunityBarterModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295281477)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295281477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295281477)
            
            static $h = 314181;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295281477),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 314181,
      "h": 4295281477,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295281477)
  ],
  "h": 314181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(314181)
        
        

        //--TRIMMABLE-BOUNDARY-START(1231685)
        $asm.$cls(`$OkRL.LCCBCS$1.CommunityBarterSettingsCustomAttributesProvider`, ($self) => class CommunityBarterSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296198981)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296198981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296198981)
            
            static $h = 1231685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296198981),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1231685,
      "h": 4296198981,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296198981)
  ],
  "h": 1231685
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Settings${separator}CommunityBarterSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1231685)
        
        

        //--TRIMMABLE-BOUNDARY-START(117573)
        $asm.$cls(`$OkRL.LCCBC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295084869)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295084869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OkRL.LCCBCM.CommunityBarterModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OkRL.LCCBCM.CommunityBarterModelCustomAttributesProvider, $.$OkRL.LCCBCM.CommunityBarterModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OkRL.LCCBCM.CommunityBarterPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OkRL.LCCBCM.CommunityBarterPostModelCustomAttributesProvider, $.$OkRL.LCCBCM.CommunityBarterPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OkRL.LCCBCS$1.CommunityBarterSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OkRL.LCCBCS$1.CommunityBarterSettingsCustomAttributesProvider, $.$OkRL.LCCBCS$1.CommunityBarterSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OkRL.LCCBCS$2.CommunityBarterStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OkRL.LCCBCS$2.CommunityBarterStatesCustomAttributesProvider, $.$OkRL.LCCBCS$2.CommunityBarterStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295084869)
            
            static $h = 117573;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295084869),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 117573,
      "h": 4295084869,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295084869)
  ],
  "h": 117573
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(117573)
        
        

        //--TRIMMABLE-BOUNDARY-START(1362757)
        $asm.$cls(`$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptorBuilder`, ($self) => class CommunityBarterSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591297349)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591297349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptor()
                        const $t1 = $.$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nSNRKk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1362757,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OkRL.LCCBCS$1.CommunityBarterSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591297349)
            
            //--TRIMMABLE-BOUNDARY-START(4296330053)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296330053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296330053)
            
            //--TRIMMABLE-BOUNDARY-START(4296330053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296330053)
            
            static $h = 1362757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591297349),
    {
      "r": 65537,
      "n": "Register",
      "d": 1362757,
      "h": 8591297349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591297349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296330053),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1362757,
      "h": 4296330053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296330053)
  ],
  "h": 1362757
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Settings${separator}CommunityBarterSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1362757)
        
        

        //--TRIMMABLE-BOUNDARY-START(445253)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterModelTypeDescriptorBuilder`, ($self) => class CommunityBarterModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590379845)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590379845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OkRL.LCCBCM.CommunityBarterModelTypeDescriptor()
                        const $t1 = $.$OkRL.LCCBCM.CommunityBarterModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YPoGUc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":445253,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OkRL.LCCBCM.CommunityBarterModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590379845)
            
            //--TRIMMABLE-BOUNDARY-START(4295412549)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295412549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295412549)
            
            //--TRIMMABLE-BOUNDARY-START(4295412549)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295412549)
            
            static $h = 445253;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590379845),
    {
      "r": 65537,
      "n": "Register",
      "d": 445253,
      "h": 8590379845,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590379845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295412549),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 445253,
      "h": 4295412549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295412549)
  ],
  "h": 445253
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(445253)
        
        

        //--TRIMMABLE-BOUNDARY-START(183109)
        $asm.$cls(`$OkRL.LCCBC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295150405)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295150405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService, $.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService_Mocking().$ctor$3(impl);
                }, $PZwDBj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService_Mocking().$ctor$3(impl);
                }, $adWspj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$OkRL.LCCBCS.IComunityBarterRemoteService, $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $fYfTuh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $gkqzza ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $LYcnjc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $raRzod ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $Syoqmc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $rFARGh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $AGuMEe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking().$ctor$3(impl);
                }, $zNPxPh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":183109,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295150405)
            
            static $h = 183109;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295150405),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 183109,
      "h": 4295150405,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295150405)
  ],
  "h": 183109
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(183109)
        
        

        //--TRIMMABLE-BOUNDARY-START(1624901)
        $asm.$cls(`$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptorBuilder`, ($self) => class CommunityBarterStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591559493)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591559493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptor()
                        const $t1 = $.$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Barter.Common.States.CommunityBarterStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Nfavmd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1624901,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OkRL.LCCBCS$2.CommunityBarterStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591559493)
            
            //--TRIMMABLE-BOUNDARY-START(4296592197)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296592197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296592197)
            
            //--TRIMMABLE-BOUNDARY-START(4296592197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296592197)
            
            static $h = 1624901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591559493),
    {
      "r": 65537,
      "n": "Register",
      "d": 1624901,
      "h": 8591559493,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591559493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296592197),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1624901,
      "h": 4296592197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296592197)
  ],
  "h": 1624901
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.States.CommunityBarterStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}States${separator}CommunityBarterStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1624901)
        
        

        //--TRIMMABLE-BOUNDARY-START(707397)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptorBuilder`, ($self) => class CommunityBarterPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590641989)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590641989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor()
                        const $t1 = $.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pAFrLd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":707397,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OkRL.LCCBCM.CommunityBarterPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590641989)
            
            //--TRIMMABLE-BOUNDARY-START(4295674693)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295674693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295674693)
            
            //--TRIMMABLE-BOUNDARY-START(4295674693)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295674693)
            
            static $h = 707397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590641989),
    {
      "r": 65537,
      "n": "Register",
      "d": 707397,
      "h": 8590641989,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590641989)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295674693),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 707397,
      "h": 4295674693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295674693)
  ],
  "h": 707397
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(707397)
        
        

        //--TRIMMABLE-BOUNDARY-START(838469)
        $asm.$cls(`$OkRL.LCCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590773061)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590773061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OkRL.LCCBCM.CommunityBarterPostModel, 6144/*PostTypes.Barter*/);
                $.$OkRL.LCCBC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$OkRL.LCCBC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$OkRL.LCCBC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590773061)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OkRL.LCCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295805765)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295805765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295805765)
            
            //--TRIMMABLE-BOUNDARY-START(4295805765)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295805765)
            
            static $h = 838469;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590773061),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 838469,
      "h": 8590773061,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590773061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295805765),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 838469,
      "h": 4295805765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295805765)
  ],
  "h": 838469
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(838469)
        
        

        //--TRIMMABLE-BOUNDARY-START(772933)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterUserPreference`, ($self) => class CommunityBarterUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295740229)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295740229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295740229)
            
            //--TRIMMABLE-BOUNDARY-START(4295740229)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295740229)
            
            static $h = 772933;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295740229),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 772933,
      "h": 4295740229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295740229)
  ],
  "h": 772933
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(772933)
        
        

        //--TRIMMABLE-BOUNDARY-START(1428293)
        $asm.$cls(`$OkRL.LCCBCS$2.CommunityBarterStates`, ($self) => class CommunityBarterStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4296395589)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296395589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296395589)
            
            //--TRIMMABLE-BOUNDARY-START(4296395589)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296395589)
            
            static $h = 1428293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296395589),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1428293,
      "h": 4296395589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296395589)
  ],
  "h": 1428293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.States.CommunityBarterStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}States${separator}CommunityBarterStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1428293)
        
        

        //--TRIMMABLE-BOUNDARY-START(1166149)
        $asm.$cls(`$OkRL.LCCBCS$1.CommunityBarterSettings`, ($self) => class CommunityBarterSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296133445)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296133445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296133445)
            
            //--TRIMMABLE-BOUNDARY-START(4296133445)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296133445)
            
            static $h = 1166149;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296133445),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1166149,
      "h": 4296133445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296133445)
  ],
  "h": 1166149
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Settings${separator}CommunityBarterSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1166149)
        
        

        //--TRIMMABLE-BOUNDARY-START(1559365)
        $asm.$cls(`$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptor`, ($self) => class CommunityBarterStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCS$2.CommunityBarterStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296526661)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296526661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptor.GenerateProperties($.$OkRL.LCCBCS$2.CommunityBarterStates, this, factory);
                    }, $DmKQOk ??= {"r":65537,"n":"","d":1559365,"h":0,"f":17825794}), 0, "CommunityBarterStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Barter.Common\\States_CommunityBarterStates_LivingThing.Core.Community.Barter.Common.States.CommunityBarterStatesTypeDescriptorBuilder.g.cs", "CommunityBarterStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296526661)
            
            //--TRIMMABLE-BOUNDARY-START(12886461253)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886461253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886461253)
            
            //--TRIMMABLE-BOUNDARY-START(17181428549)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.States.CommunityBarterStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181428549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181428549)
            
            //--TRIMMABLE-BOUNDARY-START(8591493957)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.States.CommunityBarterStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591493957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OkRL.LCCBCS$2.CommunityBarterStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OkRL.LCCBCS$2.CommunityBarterStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$2.CommunityBarterStates)))
                {
                    /*var*/ let result = $.$OkRL.LCCBCS$2.CommunityBarterStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$2.CommunityBarterStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OkRL.LCCBCS$2.CommunityBarterStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$2.CommunityBarterStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591493957)
            
            static $h = 1559365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCS$2.CommunityBarterStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886461253),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1559365,
      "h": 12886461253,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886461253),
//--TRIMMABLE-BOUNDARY-START(17181428549),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1428293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1559365,
      "h": 17181428549,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181428549),
//--TRIMMABLE-BOUNDARY-START(8591493957),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1428293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1559365,
      "h": 8591493957,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591493957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296526661),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1559365,
      "h": 4296526661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296526661)
  ],
  "h": 1559365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OkRL.LCCBCS$2.CommunityBarterStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.States.CommunityBarterStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}States${separator}CommunityBarterStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1559365)
        
        

        //--TRIMMABLE-BOUNDARY-START(1297221)
        $asm.$cls(`$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptor`, ($self) => class CommunityBarterSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCS$1.CommunityBarterSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296264517)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296264517);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptor.GenerateProperties($.$OkRL.LCCBCS$1.CommunityBarterSettings, this, factory);
                    }, $ScSQEc ??= {"r":65537,"n":"","d":1297221,"h":0,"f":17825794}), 0, "CommunityBarterSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Barter.Common\\Settings_CommunityBarterSettings_LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettingsTypeDescriptorBuilder.g.cs", "CommunityBarterSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296264517)
            
            //--TRIMMABLE-BOUNDARY-START(12886199109)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886199109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886199109)
            
            //--TRIMMABLE-BOUNDARY-START(17181166405)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181166405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181166405)
            
            //--TRIMMABLE-BOUNDARY-START(8591231813)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591231813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OkRL.LCCBCS$1.CommunityBarterSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OkRL.LCCBCS$1.CommunityBarterSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$1.CommunityBarterSettings)))
                {
                    /*var*/ let result = $.$OkRL.LCCBCS$1.CommunityBarterSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$1.CommunityBarterSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OkRL.LCCBCS$1.CommunityBarterSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCS$1.CommunityBarterSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591231813)
            
            static $h = 1297221;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCS$1.CommunityBarterSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886199109),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1297221,
      "h": 12886199109,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886199109),
//--TRIMMABLE-BOUNDARY-START(17181166405),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1166149,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1297221,
      "h": 17181166405,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181166405),
//--TRIMMABLE-BOUNDARY-START(8591231813),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1166149,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1297221,
      "h": 8591231813,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591231813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296264517),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1297221,
      "h": 4296264517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296264517)
  ],
  "h": 1297221
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OkRL.LCCBCS$1.CommunityBarterSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Settings${separator}CommunityBarterSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1297221)
        
        

        //--TRIMMABLE-BOUNDARY-START(510789)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterPostModel`, ($self) => class CommunityBarterPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180379973)
            /*PostTypes */ get Type()
            {
                return 6144/*PostTypes.Barter*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180379973)
            
            //--TRIMMABLE-BOUNDARY-START(4295478085)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295478085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295478085)
            
            //--TRIMMABLE-BOUNDARY-START(4295478085)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295478085)
            
            static $h = 510789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180379973),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885412677,
        "f": 50364417
      },
      "n": "Type",
      "d": 510789,
      "h": 17180379973,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180379973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295478085),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 510789,
      "h": 4295478085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295478085)
  ],
  "h": 510789
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(510789)
        
        

        //--TRIMMABLE-BOUNDARY-START(904005)
        $asm.$cls(`$OkRL.LCCBCS.ICommunityBarterFeedRemoteService`, ($self) => class ICommunityBarterFeedRemoteService
        {
            static $h = 904005;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 904005,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.ICommunityBarterFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}ICommunityBarterFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(904005)
        
        

        //--TRIMMABLE-BOUNDARY-START(1035077)
        $asm.$cls(`$OkRL.LCCBCS.IComunityBarterRemoteService`, ($self) => class IComunityBarterRemoteService
        {
            static $h = 1035077;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1035077,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.IComunityBarterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}IComunityBarterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1035077)
        
        

        //--TRIMMABLE-BOUNDARY-START(969541)
        $asm.$cls(`$OkRL.LCCBCS.ICommunityBarterFeedRemoteService_Mocking`, ($self) => class ICommunityBarterFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295936837)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295936837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295936837)
            
            //--TRIMMABLE-BOUNDARY-START(8590904133)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Barter$Common$Models$CommunityBarterPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590904133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590904133)
            
            static $h = 969541;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295936837),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 969541,
      "h": 4295936837,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295936837)
  ],
  "h": 969541
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OkRL.LCCBCS.ICommunityBarterFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.ICommunityBarterFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}ICommunityBarterFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(969541)
        
        

        //--TRIMMABLE-BOUNDARY-START(1100613)
        $asm.$cls(`$OkRL.LCCBCS.IComunityBarterRemoteService_Mocking`, ($self) => class IComunityBarterRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296067909)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296067909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296067909)
            
            //--TRIMMABLE-BOUNDARY-START(8591035205)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Barter$Common$Models$CommunityBarterPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591035205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OkRL.LCCBCM.CommunityBarterPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591035205)
            
            //--TRIMMABLE-BOUNDARY-START(17180969797)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Barter$Common$Models$CommunityBarterPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180969797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OkRL.LCCBCM.CommunityBarterPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180969797)
            
            //--TRIMMABLE-BOUNDARY-START(21475937093)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Barter$Common$Models$CommunityBarterPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475937093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OkRL.LCCBCM.CommunityBarterPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475937093)
            
            //--TRIMMABLE-BOUNDARY-START(25770904389)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Barter$Common$Models$CommunityBarterPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770904389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OkRL.LCCBCM.CommunityBarterPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770904389)
            
            //--TRIMMABLE-BOUNDARY-START(12886002501)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886002501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OkRL.LCCBCM.CommunityBarterPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886002501)
            
            static $h = 1100613;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296067909),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1100613,
      "h": 4296067909,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296067909)
  ],
  "h": 1100613
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OkRL.LCCBCS.IComunityBarterRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Services.IComunityBarterRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Services${separator}IComunityBarterRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1100613)
        
        

        //--TRIMMABLE-BOUNDARY-START(641861)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor`, ($self) => class CommunityBarterPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295609157)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295609157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor.GenerateProperties($.$OkRL.LCCBCM.CommunityBarterPostModel, this, factory);
                    }, $tYnypk ??= {"r":65537,"n":"","d":641861,"h":0,"f":17825794}), 0, "CommunityBarterPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Barter.Common\\Models_CommunityBarterPostModel_LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModelTypeDescriptorBuilder.g.cs", "CommunityBarterPostModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295609157)
            
            //--TRIMMABLE-BOUNDARY-START(12885543749)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885543749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OkRL.LCCBCM.CommunityBarterPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OkRL.LCCBCM.CommunityBarterPostModel)).Type);
                        }, $oWDbel ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":641861,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885543749)
            
            //--TRIMMABLE-BOUNDARY-START(17180511045)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180511045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180511045)
            
            //--TRIMMABLE-BOUNDARY-START(8590576453)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590576453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OkRL.LCCBCM.CommunityBarterPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OkRL.LCCBCM.CommunityBarterPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterPostModel)))
                {
                    /*var*/ let result = $.$OkRL.LCCBCM.CommunityBarterPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OkRL.LCCBCM.CommunityBarterPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590576453)
            
            static $h = 641861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885543749),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 641861,
      "h": 12885543749,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885543749),
//--TRIMMABLE-BOUNDARY-START(17180511045),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 510789,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 641861,
      "h": 17180511045,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180511045),
//--TRIMMABLE-BOUNDARY-START(8590576453),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 510789,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 641861,
      "h": 8590576453,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590576453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295609157),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 641861,
      "h": 4295609157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295609157)
  ],
  "h": 641861
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(641861)
        
        

        //--TRIMMABLE-BOUNDARY-START(248645)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterModel`, ($self) => class CommunityBarterModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295215941)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295215941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295215941)
            
            //--TRIMMABLE-BOUNDARY-START(4295215941)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295215941)
            
            static $h = 248645;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295215941),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 248645,
      "h": 4295215941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295215941)
  ],
  "h": 248645
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(248645)
        
        

        //--TRIMMABLE-BOUNDARY-START(379717)
        $asm.$cls(`$OkRL.LCCBCM.CommunityBarterModelTypeDescriptor`, ($self) => class CommunityBarterModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295347013)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295347013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OkRL.LCCBCM.CommunityBarterModelTypeDescriptor.GenerateProperties($.$OkRL.LCCBCM.CommunityBarterModel, this, factory);
                    }, $ihbiEj ??= {"r":65537,"n":"","d":379717,"h":0,"f":17825794}), 0, "CommunityBarterModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Barter.Common\\Models_CommunityBarterModel_LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModelTypeDescriptorBuilder.g.cs", "CommunityBarterModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295347013)
            
            //--TRIMMABLE-BOUNDARY-START(12885281605)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885281605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885281605)
            
            //--TRIMMABLE-BOUNDARY-START(17180248901)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180248901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Barter.Common.Settings.CommunityBarterSettings, LivingThing.Core.Community.Barter.Common.States.CommunityBarterStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$OkRL.LCCBCS$1.CommunityBarterSettings, $.$OkRL.LCCBCS$2.CommunityBarterStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180248901)
            
            //--TRIMMABLE-BOUNDARY-START(8590314309)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590314309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OkRL.LCCBCM.CommunityBarterModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OkRL.LCCBCM.CommunityBarterModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterModel)))
                {
                    /*var*/ let result = $.$OkRL.LCCBCM.CommunityBarterModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OkRL.LCCBCM.CommunityBarterModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OkRL.LCCBCM.CommunityBarterModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590314309)
            
            static $h = 379717;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885281605),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 379717,
      "h": 12885281605,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885281605),
//--TRIMMABLE-BOUNDARY-START(17180248901),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 248645,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 379717,
      "h": 17180248901,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180248901),
//--TRIMMABLE-BOUNDARY-START(8590314309),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 248645,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 379717,
      "h": 8590314309,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590314309)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295347013),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 379717,
      "h": 4295347013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295347013)
  ],
  "h": 379717
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OkRL.LCCBCM.CommunityBarterModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Barter.Common.Models.CommunityBarterModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Barter${separator}Common${separator}Models${separator}CommunityBarterModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(379717)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(52037)
