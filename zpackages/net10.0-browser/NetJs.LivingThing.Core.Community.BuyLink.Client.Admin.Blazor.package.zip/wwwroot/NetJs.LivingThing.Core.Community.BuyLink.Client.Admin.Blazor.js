
//--TRIMMABLE-BOUNDARY-START(46589)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $RffN, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $oUrI, $jfJD, $Bnua) {
    "use strict";
    let _;
    let $Wosgfk;
    let $DDucwd;
    let $YuoEUg;
    let $EDOBAh;
    let $Rludgj;
    let $eIJRXf;
    let $zZdRFd;
    let $UbLWof;
    let $tBEmMj;
    let $lJsygl;
    let $IFOfyj;
    let $vJPKPa;
    let $FMhEah;
    let $CFbJqb;
    let $SrjVUg;
    let $yQbaMd;
    let $fSuzhf;
    let $oDKAQc;
    let $myJjLb;
    let $XjyoRj;
    let $ZVfJTg;
    let $rxiJSe;
    let $rpqCQd;
    let $GlZlEe;
    let $NKCZfd;
    let $hzxDLc;
    let $JEEbYf;
    let $syABYb;
    let $lKPdee;
    let $kENRlj;
    let $UwSeEe;
    let $MCKiGc;
    let $GfXDTd;
    let $hXLSAi;
    let $QOMTcl;
    let $JMsXNj;
    let $PHMuQe;
    let $aMCbwc;
    let $efZMkf;
    let $FWqbJa;
    let $YDxJVi;
    let $kXQAae;
    let $jjDWVg;
    let $BToLSk;
    let $ViBdUb;
    let $eQZRde;
    let $wsdGfh;
    let $tKTFjg;
    let $TINVEf;
    let $UoWSLb;
    let $itpQue;
    let $ktPQal;
    let $YDRGad;
    let $GVEtsb;
    let $qHwtid;
    let $BjROmd;
    let $wdyyhe;
    let $IaZGLe;
    let $QVLoxj;
    let $QUeXuk;
    let $MZdtHg;
    let $fdpeIc;
    let $QAgusd;
    let $NqMTne;
    let $KoKppg;
    let $JoQInk;
    let $PcyTVd;
    let $IaCoOj;
    let $ClPjVj;
    let $QftBec;
    let $cuDdff;
    let $WgXDYc;
    let $yTjDWi;
    let $uBlkia;
    let $DnWCmg;
    let $zFotVj;
    let $iAGOth;
    let $CiTapk;
    let $WsvAJc;
    let $LVmkQk;
    let $OZyZHc;
    let $FWVpVh;
    let $lxOnph;
    let $KDEzwf;
    let $HqOhag;
    let $LVQtDh;
    let $UhESod;
    let $iKluGk;
    let $FsxyFh;
    let $TmVcpe;
    let $ylnytk;
    let $vLJAtc;
    let $pxERhc;
    let $Oapmcc;
    let $NxXhkf;
    let $oFRYNc;
    let $KdsAXe;
    let $yCFMya;
    let $QbPdRg;
    let $ycePdd;
    let $UDGfxk;
    let $ufeSFj;
    let $VLfzwf;
    let $bUdXyk;
    let $sXloSi;
    let $dtfaSa;
    let $RNuCXg;
    let $dvqzEg;
    let $Meuvmh;
    let $Dlpcke;
    let $YRHYwk;
    let $GDjCDh;
    let $eScpte;
    let $sKPMtf;
    let $XJArnh;
    let $djGXDe;
    let $bckjEk;
    let $suvJBa;
    let $MaFBZk;
    let $glFbxj;
    let $qMEmqf;
    let $nqWDxi;
    let $lGUOfb;
    let $iceZdh;
    let $UbNaIb;
    let $Nkcprh;
    let $XIyNVj;
    let $JEblGk;
    let $TuNYCb;
    let $AkvUud;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.BuyLink.Client.Admin.Blazor", 
    {
  "h": 46589,
  "f": "LivingThing.Core.Community.BuyLink.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(636413)
        $asm.$cls(`$ehcb.LCCBCAP.BuyLinkDashboard`, ($self) => class BuyLinkDashboard extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68720113149)
            /*int*/ OrdersToday = 0;
            //--TRIMMABLE-BOUNDARY-END(68720113149)
            
            //--TRIMMABLE-BOUNDARY-START(73015080445)
            /*int*/ PendingOrders = 0;
            //--TRIMMABLE-BOUNDARY-END(73015080445)
            
            //--TRIMMABLE-BOUNDARY-START(25770440189)
            /*int*/ AwaitingPayments = 0;
            //--TRIMMABLE-BOUNDARY-END(25770440189)
            
            //--TRIMMABLE-BOUNDARY-START(64425145853)
            /*IEnumerable<IChartDataPoint>*/ InShipment = null;
            //--TRIMMABLE-BOUNDARY-END(64425145853)
            
            //--TRIMMABLE-BOUNDARY-START(21475472893)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475472893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475472893)
            
            //--TRIMMABLE-BOUNDARY-START(21475472893)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475472893)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425145853)
                this.InShipment = $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.ChartDataPoint), [new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1), new $.$fPer.LCFCD.ChartDataPoint().$ctor$2("1", 1)], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.ChartDataPoint), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChartDataPoint));
                //--TRIMMABLE-BOUNDARY-END(64425145853)
                
            }
            static $h = 636413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720113149),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540243965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784884221,
        "f": 83886081
      },
      "n": "OrdersToday",
      "d": 636413,
      "h": 68720113149,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "New orders since today",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=NewBox"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720113149),
//--TRIMMABLE-BOUNDARY-START(73015080445),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130178557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374818813,
        "f": 83886081
      },
      "n": "PendingOrders",
      "d": 636413,
      "h": 73015080445,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Orders waiting for processing",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=LanPending"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015080445),
//--TRIMMABLE-BOUNDARY-START(25770440189),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360374781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605015037,
        "f": 83886081
      },
      "n": "AwaitingPayments",
      "d": 636413,
      "h": 25770440189,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Orders waiting for customer payment",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=LanPending"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770440189),
//--TRIMMABLE-BOUNDARY-START(64425145853),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChartDataPoint).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950309373,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194949629,
        "f": 83886081
      },
      "n": "InShipment",
      "d": 636413,
      "h": 64425145853,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Orders currently shipping",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Airplane"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425145853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475472893),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 636413,
      "h": 21475472893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475472893)
  ],
  "h": 636413
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Pages.BuyLinkDashboard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Pages${separator}BuyLinkDashboard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(636413)
        
        

        //--TRIMMABLE-BOUNDARY-START(374269)
        $asm.$cls(`$ehcb.LCCBCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295341565)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295341565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$ehcb.LCCBCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295341565)
            
            static $h = 374269;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295341565),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 374269,
      "h": 4295341565,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295341565)
  ],
  "h": 374269
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(374269)
        
        

        //--TRIMMABLE-BOUNDARY-START(505341)
        $asm.$cls(`$ehcb.LCCBCA.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590439933)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590439933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$ehcb.LCCBCAP.Admin, "LivingThing.Core.Community.BuyLink.Client.Admin", "Pages\\Admin", "Admin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/BuyLink/Admin", "/BuyLink/Admin/{*Page}" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$ehcb.LCCBCAPE.Common, "LivingThing.Core.Community.BuyLink.Client.Admin", "Pages\\Emails\\Common", "Common", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/BuyLink/Email" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590439933)
            
            //--TRIMMABLE-BOUNDARY-START(4295472637)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295472637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295472637)
            
            //--TRIMMABLE-BOUNDARY-START(4295472637)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295472637)
            
            static $h = 505341;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590439933),
    {
      "r": 65537,
      "n": "Build",
      "d": 505341,
      "h": 8590439933,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590439933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295472637),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 505341,
      "h": 4295472637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295472637)
  ],
  "h": 505341
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(505341)
        
        

        //--TRIMMABLE-BOUNDARY-START(112125)
        $asm.$cls(`$ehcb._LCCBCAPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295079421)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295079421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295079421)
            
            static $h = 112125;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295079421),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 112125,
      "h": 4295079421,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295079421)
  ],
  "h": 112125
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Admin.Pages.Admin.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Pages${separator}Admin${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(112125)
        
        

        //--TRIMMABLE-BOUNDARY-START(177661)
        $asm.$cls(`$ehcb._LCCBCASB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295144957)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*T*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295144957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "Filter", __arg2);
                __builder.AddComponentParameter(__seq3, "Target", $.$box(__arg3, T));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295144957)
            
            static $h = 177661;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295144957),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 14505642
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 177661,
      "h": 4295144957,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295144957)
  ],
  "h": 177661
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminOrderDetails.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminOrderDetails${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(177661)
        
        

        //--TRIMMABLE-BOUNDARY-START(243197)
        $asm.$cls(`$ehcb._LCCBCASB$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295210493)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg0, /*int*/ __seq1, /*global::System.Int32*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*T*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295210493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Features", $.$box(__arg0, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq1, "PadContent", $.$box(__arg1, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq2, "Filter", __arg2);
                __builder.AddComponentParameter(__seq3, "Target", $.$box(__arg3, T));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295210493)
            
            static $h = 243197;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295210493),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 14505642
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 655361
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 243197,
      "h": 4295210493,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295210493)
  ],
  "h": 243197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminProductDetails.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminProductDetails${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(243197)
        
        

        //--TRIMMABLE-BOUNDARY-START(833021)
        $asm.$cls(`$ehcb.LCCBCAS.AdminDashboardProvider`, ($self) => class AdminDashboardProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60130375165)
            /*string */ get Title()
            {
                return "BuyLink";
            }
            //--TRIMMABLE-BOUNDARY-END(60130375165)
            
            //--TRIMMABLE-BOUNDARY-START(51540440573)
            /*string */ get Icon()
            {
                return "mdi mdi-cart-heart"/*MaterialDesignIconNames.CartHeart*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51540440573)
            
            //--TRIMMABLE-BOUNDARY-START(12885734909)
            /*RenderFragment */ get Content()
            {
                return $.$hDPm.LCFC.FragmentView.From$1($.$ehcb.LCCBCAP.Admin, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("BasePath", "");
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885734909)
            
            //--TRIMMABLE-BOUNDARY-START(55835407869)
            /*IEnumerable<IAdministrativePage>*/ Pages = null;
            //--TRIMMABLE-BOUNDARY-END(55835407869)
            
            //--TRIMMABLE-BOUNDARY-START(38717839018)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IAdministrativeComponentProvider.Title.get
            get LCFCI$IAdministrativeComponentProvider$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51602740906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(38717839018)
            
            //--TRIMMABLE-BOUNDARY-START(21537969834)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IAdministrativeComponentProvider.Icon.get
            get LCFCI$IAdministrativeComponentProvider$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012806314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(21537969834)
            
            //--TRIMMABLE-BOUNDARY-START(12948035242)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IAdministrativeComponentProvider.Content.get
            get LCFCI$IAdministrativeComponentProvider$Content()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358100650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Content;
            }
            //--TRIMMABLE-BOUNDARY-END(12948035242)
            
            //--TRIMMABLE-BOUNDARY-START(30127904426)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IAdministrativeComponentProvider.Pages.get
            get LCFCI$IAdministrativeComponentProvider$Pages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47307773610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Pages;
            }
            //--TRIMMABLE-BOUNDARY-END(30127904426)
            
            //--TRIMMABLE-BOUNDARY-START(8590767613)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590767613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590767613)
            
            //--TRIMMABLE-BOUNDARY-START(8590767613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590767613)
            
            static $h = 833021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130375165),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245473277,
        "f": 50331649
      },
      "n": "Title",
      "d": 833021,
      "h": 60130375165,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130375165),
//--TRIMMABLE-BOUNDARY-START(51540440573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065604093,
        "f": 50331649
      },
      "n": "Icon",
      "d": 833021,
      "h": 51540440573,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540440573),
//--TRIMMABLE-BOUNDARY-START(12885734909),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475669501,
        "f": 50331649
      },
      "n": "Content",
      "d": 833021,
      "h": 12885734909,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885734909),
//--TRIMMABLE-BOUNDARY-START(55835407869),
    {
      "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCI.IAdministrativePage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655538685,
        "f": 50331649
      },
      "n": "Pages",
      "d": 833021,
      "h": 55835407869,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835407869)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590767613),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 833021,
      "h": 8590767613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590767613)
  ],
  "h": 833021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IAdministrativeComponentProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Services.AdminDashboardProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Services${separator}AdminDashboardProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(833021)
        
        

        //--TRIMMABLE-BOUNDARY-START(767485)
        $asm.$cls(`$ehcb.LCCBCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590702077)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590702077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCI.IAdministrativeComponentProvider, $.$ehcb.LCCBCAS.AdminDashboardProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590702077)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ehcb.LCCBCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295734781)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295734781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295734781)
            
            //--TRIMMABLE-BOUNDARY-START(4295734781)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295734781)
            
            static $h = 767485;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590702077),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 767485,
      "h": 8590702077,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590702077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295734781),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 767485,
      "h": 4295734781,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295734781)
  ],
  "h": 767485
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(767485)
        
        

        //--TRIMMABLE-BOUNDARY-START(439805)
        $asm.$cls(`$ehcb.LCCBCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180308989)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAP.Admin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAP.Admin().$ctor$3();
                    }, $Rludgj ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAPE.Common.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAPE.Common().$ctor$4();
                    }, $eIJRXf ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAS$1.BuyLinkAdminAccountsPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAS$1.BuyLinkAdminAccountsPage().$ctor$3();
                    }, $zZdRFd ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAS$1.BuyLinkAdminOrderDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAS$1.BuyLinkAdminOrderDetails().$ctor$5();
                    }, $UbLWof ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAS$1.BuyLinkAdminOrderTable.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAS$1.BuyLinkAdminOrderTable().$ctor$3();
                    }, $tBEmMj ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAS$1.BuyLinkAdminProductDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAS$1.BuyLinkAdminProductDetails().$ctor$5();
                    }, $lJsygl ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable().$ctor$3();
                    }, $IFOfyj ??= {"r":2752627,"n":"","d":439805,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180308989)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295407101)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295407101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295407101)
            
            //--TRIMMABLE-BOUNDARY-START(4295407101)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295407101)
            
            static $h = 439805;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180308989),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885341693,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 439805,
      "h": 17180308989,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180308989)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295407101),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 439805,
      "h": 4295407101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295407101)
  ],
  "h": 439805
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(439805)
        
        

        //--TRIMMABLE-BOUNDARY-START(1226237)
        $asm.$cls(`$ehcb.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296193533)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296193533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296193533)
            
            //--TRIMMABLE-BOUNDARY-START(4296193533)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296193533)
            
            static $h = 1226237;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296193533),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1226237,
      "h": 4296193533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296193533)
  ],
  "h": 1226237
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1226237)
        
        

        //--TRIMMABLE-BOUNDARY-START(1291773)
        $asm.$cls(`$ehcb.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296259069)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296259069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296259069)
            
            //--TRIMMABLE-BOUNDARY-START(4296259069)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296259069)
            
            static $h = 1291773;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296259069),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1291773,
      "h": 4296259069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296259069)
  ],
  "h": 1291773,
  "a": [
    {
      "t": 1226237,
      "c": 4296193533
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1291773)
        
        

        //--TRIMMABLE-BOUNDARY-START(308733)
        $asm.$cls(`$ehcb.LCCBCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590243325)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590243325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590243325)
            
            //--TRIMMABLE-BOUNDARY-START(4295276029)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295276029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295276029)
            
            //--TRIMMABLE-BOUNDARY-START(4295276029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295276029)
            
            static $h = 308733;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590243325),
    {
      "r": 65537,
      "n": "Execute",
      "d": 308733,
      "h": 8590243325,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590243325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295276029),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 308733,
      "h": 4295276029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295276029)
  ],
  "h": 308733
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(308733)
        
        

        //--TRIMMABLE-BOUNDARY-START(1160701)
        $asm.$cls(`$ehcb.LCCBCAS$1.BuyLinkAdminProductTable`, ($self) => class BuyLinkAdminProductTable extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17181029885)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(17181029885)
            
            //--TRIMMABLE-BOUNDARY-START(38655866365)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkadminproducttable";
            }
            //--TRIMMABLE-BOUNDARY-END(38655866365)
            
            //--TRIMMABLE-BOUNDARY-START(51540768253)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540768253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD.DataFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540768253)
            
            //--TRIMMABLE-BOUNDARY-START(12886062589)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886062589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 0);
                __builder.AddComponentParameter(1, "Class", "bg-card-07 bdt bdb fill");
                __builder.AddComponentParameter(2, "paginator-class", "fill");
                __builder.AddComponentParameter(3, "paginator-menu-class", "pd bg-card");
                __builder.AddComponentParameter(4, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(5, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 2097152n | 8388608n | 4n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(7, "th-class", "nowrap fw-bold bg-primary-01 sd-1 bdb");
                __builder.AddComponentParameter(8, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.Filter));
                __builder.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*order*/ order) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 10);
                        __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                        __builder2.AddComponentParameter(12, "cell-class", "nowrap");
                        __builder2.CloseComponent();
                    }, $vJPKPa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1160701,"h":0,"f":17825794});
                }), $FMhEah ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1160701,"h":0,"f":17825794}));
                __builder.AddAttribute$3(13, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/**/ detail) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductDetails, 14);
                        __builder2.AddComponentParameter(15, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).op_Implicit$1(detail)));
                        __builder2.AddComponentParameter(16, "Class", "bg-card");
                        __builder2.CloseComponent();
                    }, $CFbJqb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1160701,"h":0,"f":17825794});
                }), $SrjVUg ??= {"r":6881395,"p":[{"n":"detail","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1160701,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886062589)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591095293)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591095293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591095293)
            
            //--TRIMMABLE-BOUNDARY-START(8591095293)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591095293)
            
            static $h = 1160701;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181029885),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770964477,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245800957,
        "f": 83886081
      },
      "n": "Filter",
      "d": 1160701,
      "h": 17181029885,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181029885),
//--TRIMMABLE-BOUNDARY-START(38655866365),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360899069,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1160701,
      "h": 38655866365,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655866365)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540768253),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1160701,
      "h": 51540768253,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540768253),
//--TRIMMABLE-BOUNDARY-START(12886062589),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1160701,
      "h": 12886062589,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886062589)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591095293),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1160701,
      "h": 8591095293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591095293)
  ],
  "h": 1160701
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminProductTable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminProductTable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1160701)
        
        

        //--TRIMMABLE-BOUNDARY-START(1029629)
        $asm.$cls(`$ehcb.LCCBCAS$1.BuyLinkAdminOrderTable`, ($self) => class BuyLinkAdminOrderTable extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17180898813)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(17180898813)
            
            //--TRIMMABLE-BOUNDARY-START(38655735293)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkadminordertable";
            }
            //--TRIMMABLE-BOUNDARY-END(38655735293)
            
            //--TRIMMABLE-BOUNDARY-START(51540637181)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540637181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD.DataFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540637181)
            
            //--TRIMMABLE-BOUNDARY-START(12885931517)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885931517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 0);
                __builder.AddComponentParameter(1, "Class", "bg-card-07 bdt bdb fill");
                __builder.AddComponentParameter(2, "paginator-class", "fill");
                __builder.AddComponentParameter(3, "paginator-menu-class", "pd bg-card");
                __builder.AddComponentParameter(4, "PaginatorButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(5, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(6, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 2097152n | 8388608n | 4n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(7, "th-class", "nowrap fw-bold bg-primary-01 sd-1 bdb");
                __builder.AddComponentParameter(8, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.Filter));
                __builder.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/**/ order) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 10);
                        __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                        __builder2.AddComponentParameter(12, "cell-class", "nowrap");
                        __builder2.CloseComponent();
                    }, $Wosgfk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1029629,"h":0,"f":17825794});
                }), $DDucwd ??= {"r":6881395,"p":[{"n":"order","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":1029629,"h":0,"f":17825794}));
                __builder.AddAttribute$3(13, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/**/ detail) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminOrderDetails, 14);
                        __builder2.AddComponentParameter(15, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).op_Implicit$1(detail)));
                        __builder2.AddComponentParameter(16, "Class", "bg-card");
                        __builder2.CloseComponent();
                    }, $YuoEUg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1029629,"h":0,"f":17825794});
                }), $EDOBAh ??= {"r":6881395,"p":[{"n":"detail","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":1029629,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885931517)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590964221)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590964221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590964221)
            
            //--TRIMMABLE-BOUNDARY-START(8590964221)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590964221)
            
            static $h = 1029629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180898813),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770833405,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245669885,
        "f": 83886081
      },
      "n": "Filter",
      "d": 1029629,
      "h": 17180898813,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180898813),
//--TRIMMABLE-BOUNDARY-START(38655735293),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360767997,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1029629,
      "h": 38655735293,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655735293)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540637181),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1029629,
      "h": 51540637181,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540637181),
//--TRIMMABLE-BOUNDARY-START(12885931517),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1029629,
      "h": 12885931517,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885931517)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590964221),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1029629,
      "h": 8590964221,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590964221)
  ],
  "h": 1029629
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminOrderTable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminOrderTable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1029629)
        
        

        //--TRIMMABLE-BOUNDARY-START(570877)
        $asm.$cls(`$ehcb.LCCBCAP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(64425080317)
            /*string*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(64425080317)
            
            //--TRIMMABLE-BOUNDARY-START(17180440061)
            /*string*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(17180440061)
            
            //--TRIMMABLE-BOUNDARY-START(25770374653)
            /*BuyLinkDashboard*/ dashboard = null;
            //--TRIMMABLE-BOUNDARY-END(25770374653)
            
            //--TRIMMABLE-BOUNDARY-START(55835145725)
            /*Task */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835145725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(55835145725)
            
            //--TRIMMABLE-BOUNDARY-START(60130113021)
            /*string */ get OptimizedComponentName()
            {
                return "admin";
            }
            //--TRIMMABLE-BOUNDARY-END(60130113021)
            
            //--TRIMMABLE-BOUNDARY-START(85899916797)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899916797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(85899916797)
            
            //--TRIMMABLE-BOUNDARY-START(21475407357)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475407357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ehcb._LCCBCAPA.TypeInference.CreateCascadingValue_0($.$ehcb.LCCBCAP.Admin, __builder, 0, 1, this, 2, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.Application, 3);
                    __builder2.AddComponentParameter(4, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(this.BasePath)));
                    __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                    __builder2.AddAttribute$3(6, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(7, "<i class=\"mdi mdi-cart-heart\"></i>");
                        }, $yTjDWi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                    }), $uBlkia ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 9);
                        __builder3.AddComponentParameter(10, "Name", "");
                        __builder3.AddAttribute$3(11, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(12, "Dashboard");
                            }, $DnWCmg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $zFotVj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(13, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(14, "<i class=\"mdi mdi-mac-dashboard\"></i>");
                            }, $iAGOth ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $CiTapk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                            }, $WsvAJc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $LVmkQk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(16, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 17);
                        __builder3.AddComponentParameter(18, "Name", "Orders");
                        __builder3.AddAttribute$3(19, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(20, "Orders");
                            }, $OZyZHc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $FWVpVh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(21, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(22, "<i class=\"mdi mdi-list-status\"></i>");
                            }, $lxOnph ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $KDEzwf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 24);
                                __builder4.AddComponentParameter(25, "Class", "hf");
                                __builder4.AddComponentParameter(26, "InitialViewIndex", "0");
                                __builder4.AddComponentParameter(27, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 65536/*MenuFeatures.Scroll*/ | 2097152/*MenuFeatures.Pad*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                                __builder4.AddComponentParameter(28, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                                __builder4.AddComponentParameter(29, "tabhead-class", "bg-card bdb bdt");
                                __builder4.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    let $en2 = $.$RffN.LCCBCS.ServiceFilters.Orders.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en2.SC$1$IEnumerator$MoveNext())
                                    {
                                        let _tab = $en2.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let tab = _tab;
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 31);
                                            __builder5.AddComponentParameter(32, "Class", "stack hf");
                                            __builder5.AddAttribute$3(33, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*t*/ t) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 34);
                                                    __builder6.AddComponentParameter(35, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                    __builder6.AddComponentParameter(36, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                    __builder6.AddAttribute$3(37, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                    {
                                                        __builder7.AddContent$4(38, tab.Key);
                                                    }), $HqOhag ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
                                                    __builder6.CloseComponent();
                                                }, $LVQtDh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                                            }), $UhESod ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenElement(40, "h4");
                                                    __builder6.AddAttribute$5(41, "class", "mgx");
                                                    __builder6.AddContent$4(42, tab.Key);
                                                    __builder6.AddContent$4(43, " Orders");
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(44, "\r\n                                    ");
                                                    __builder6.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminOrderTable, 45);
                                                    __builder6.AddComponentParameter(46, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, tab.Value));
                                                    __builder6.CloseComponent();
                                                }, $iKluGk ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                                            }), $FsxyFh ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }
                                    }
                                }), $TmVcpe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $ylnytk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $vLJAtc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(47, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 48);
                        __builder3.AddComponentParameter(49, "Name", "Products");
                        __builder3.AddAttribute$3(50, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(51, "Products");
                            }, $pxERhc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $Oapmcc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(52, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(53, "<i class=\"mdi mdi-shield\"></i>");
                            }, $NxXhkf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $oFRYNc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 55);
                                __builder4.AddComponentParameter(56, "Class", "hf");
                                __builder4.AddComponentParameter(57, "InitialViewIndex", "0");
                                __builder4.AddComponentParameter(58, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 65536/*MenuFeatures.Scroll*/ | 2097152/*MenuFeatures.Pad*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                                __builder4.AddComponentParameter(59, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                                __builder4.AddComponentParameter(60, "tabhead-class", "bg-card bdb bdt");
                                __builder4.AddAttribute$3(61, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    let $en3 = $.$RffN.LCCBCS.ServiceFilters.Products.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en3.SC$1$IEnumerator$MoveNext())
                                    {
                                        let _tab = $en3.SCG$IEnumerator$$$Current;
                                        {
                                            /*var*/ let tab = _tab;
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 62);
                                            __builder5.AddComponentParameter(63, "Class", "stack hf");
                                            __builder5.AddAttribute$3(64, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 65);
                                                    __builder6.AddComponentParameter(66, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                    __builder6.AddComponentParameter(67, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                    __builder6.AddAttribute$3(68, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                    {
                                                        __builder7.AddContent$4(69, tab.Key);
                                                    }), $KdsAXe ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
                                                    __builder6.CloseComponent();
                                                }, $yCFMya ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                                            }), $QbPdRg ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(70, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenElement(71, "h4");
                                                    __builder6.AddAttribute$5(72, "class", "mgx");
                                                    __builder6.AddContent$4(73, "Products ");
                                                    __builder6.AddContent$4(74, tab.Key);
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(75, "\r\n                                    ");
                                                    __builder6.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable, 76);
                                                    __builder6.AddComponentParameter(77, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, tab.Value));
                                                    __builder6.CloseComponent();
                                                }, $ycePdd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                                            }), $UDGfxk ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }
                                    }
                                }), $ufeSFj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }, $VLfzwf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $bUdXyk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(78, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 79);
                        __builder3.AddComponentParameter(80, "Name", "Accounts");
                        __builder3.AddAttribute$3(81, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(82, "User Accounts");
                            }, $sXloSi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $dtfaSa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(83, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(84, "<i class=\"mdi mdi-account\"></i>");
                            }, $RNuCXg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $dvqzEg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(85, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminAccountsPage, 86);
                                __builder4.CloseComponent();
                            }, $Meuvmh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $Dlpcke ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(87, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 88);
                        __builder3.AddComponentParameter(89, "Name", "Featured");
                        __builder3.AddAttribute$3(90, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(91, "Featured Products");
                            }, $YRHYwk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $GDjCDh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(92, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(93, "<i class=\"mdi mdi-cart-heart\"></i>");
                            }, $eScpte ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $sKPMtf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(94, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable, 95);
                                __builder4.AddComponentParameter(96, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder4.CloseComponent();
                            }, $XJArnh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $djGXDe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(97, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 98);
                        __builder3.AddComponentParameter(99, "Name", "HotDeals");
                        __builder3.AddAttribute$3(100, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(101, "Hot Deals");
                            }, $bckjEk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $suvJBa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(102, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(103, "<i class=\"mdi mdi-cart-heart\"></i>");
                            }, $MaFBZk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $glFbxj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(104, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable, 105);
                                __builder4.AddComponentParameter(106, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$23(null, "hotdeals"/*CommunityBuyLinkProductModel.HotDealsFeaturedAttribute*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder4.CloseComponent();
                            }, $qMEmqf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $nqWDxi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(107, "\r\n            ");
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 108);
                        __builder3.AddComponentParameter(109, "Name", "Banners");
                        __builder3.AddComponentParameter(110, "Class", "pd");
                        __builder3.AddAttribute$3(111, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(112, "App Banners");
                            }, $lGUOfb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $iceZdh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(113, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(114, "<i class=\"mdi mdi-account-details\"></i>");
                            }, $UbNaIb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $Nkcprh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(115, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$Bnua.LCCCAS.CommunityAdminBanners, 116);
                                __builder4.AddComponentParameter(117, "Tag", "BuyLink");
                                __builder4.CloseComponent();
                            }, $XIyNVj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":570877,"h":0,"f":17825794});
                        }), $JEblGk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":570877,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $TuNYCb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $AkvUud ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":570877,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(21475407357)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885472765)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885472765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885472765)
            
            //--TRIMMABLE-BOUNDARY-START(12885472765)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885472765)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180440061)
                this.BasePath = "BuyLink/Admin";
                //--TRIMMABLE-BOUNDARY-END(17180440061)
                
                //--TRIMMABLE-BOUNDARY-START(25770374653)
                this.dashboard = new $.$ehcb.LCCBCAP.BuyLinkDashboard().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25770374653)
                
            }
            static $h = 570877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425080317),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540178429,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604949501,
        "f": 83886081
      },
      "n": "Page",
      "d": 570877,
      "h": 64425080317,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425080317),
//--TRIMMABLE-BOUNDARY-START(17180440061),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360309245,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015014909,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 570877,
      "h": 17180440061,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180440061),
//--TRIMMABLE-BOUNDARY-START(60130113021),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950243837,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 570877,
      "h": 60130113021,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130113021)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835145725),
    {
      "r": 178454529,
      "n": "Load",
      "d": 570877,
      "h": 55835145725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835145725),
//--TRIMMABLE-BOUNDARY-START(85899916797),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 570877,
      "h": 85899916797,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899916797),
//--TRIMMABLE-BOUNDARY-START(21475407357),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 570877,
      "h": 21475407357,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475407357)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770374653),
    {
      "t": 636413,
      "n": "dashboard",
      "d": 570877,
      "h": 25770374653,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770374653)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885472765),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 570877,
      "h": 12885472765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885472765)
  ],
  "h": 570877,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/BuyLink/Admin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/BuyLink/Admin/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$jfJD.LCCBCS.ICommunityBuyLinkAdmin, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(570877)
        
        

        //--TRIMMABLE-BOUNDARY-START(701949)
        $asm.$cls(`$ehcb.LCCBCAPE.Common`, ($self) => class Common extends $.$hDPm.LCFCCE$1.EmailTemplateBase
        {
            //--TRIMMABLE-BOUNDARY-START(85900047869)
            /*string*/ title = null;
            //--TRIMMABLE-BOUNDARY-END(85900047869)
            
            //--TRIMMABLE-BOUNDARY-START(42950374909)
            /*string*/ message = null;
            //--TRIMMABLE-BOUNDARY-END(42950374909)
            
            //--TRIMMABLE-BOUNDARY-START(51540309501)
            /*CommunityBuyLinkOrderModel*/ order = null;
            //--TRIMMABLE-BOUNDARY-END(51540309501)
            
            //--TRIMMABLE-BOUNDARY-START(60130244093)
            /*IEnumerable<CommunityBuyLinkProductModel>*/ products = null;
            //--TRIMMABLE-BOUNDARY-END(60130244093)
            
            //--TRIMMABLE-BOUNDARY-START(55835276797)
            /*CommunityBuyLinkProductModel*/ product = null;
            //--TRIMMABLE-BOUNDARY-END(55835276797)
            
            //--TRIMMABLE-BOUNDARY-START(64425211389)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(64425211389)
            
            //--TRIMMABLE-BOUNDARY-START(21475538429)
            /*ICommunityApplicationDeployment*/ Deployment = null;
            //--TRIMMABLE-BOUNDARY-END(21475538429)
            
            //--TRIMMABLE-BOUNDARY-START(47245342205)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245342205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
                this.title = this.GetQuery("title", true);
                this.message = this.GetQuery("message", true);
                /*var*/ let type = $.$$.S.Int32.Parse$7(this.GetQuery("type", false));
                /*var*/ let id = this.GetQuery("id", true);
                if (type === 5122/*PostTypes.BuyLinkOrder*/)
                {
                    this.order = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(id, null)), null).GetAwaiter().GetResult();
                    this.products = this.order.Products ?? $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(new $.$fPer.LCFCD.DataId().$ctor$3(id, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null).GetAwaiter().GetResult().AsEnumerable();
                }
                else 
                {
                    this.product = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(id, null)), null).GetAwaiter().GetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245342205)
            
            //--TRIMMABLE-BOUNDARY-START(17180571133)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180571133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf wf flex bg-tertiary");
                __builder.AddAttribute$5(2, "style", "font-family: 'Roboto'");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "mgx-a mgy bd corner clip mawx-4 bg-card");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "pd row");
                __builder.AddAttribute$5(7, "style", $.$strNN("background-color:" + $.$strNN(("#ff4747"/*CommunityBuyLinkApplication.ThemeColor*/))) + ";color:#FFF");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "pdl stack");
                __builder.OpenElement(10, "div");
                __builder.AddAttribute$5(11, "class", "mgy-a");
                __builder.OpenElement(12, "h2");
                __builder.AddAttribute$5(13, "class", "mg-0");
                __builder.AddContent$4(14, "BuyLink ");
                __builder.AddContent$4(15, this.order !== null ? "Order" : "Product");
                __builder.AddContent$4(16, " Update");
                __builder.CloseElement();
                __builder.AddMarkupContent(17, "\r\n                    ");
                __builder.OpenElement(18, "h4");
                __builder.AddAttribute$5(19, "class", "mgb-0 mgt-5");
                __builder.AddContent$4(20, (this.order?.Title ?? null) ?? (this.product?.Title ?? null));
                __builder.AddContent$4(21, " (");
                __builder.AddContent$3(22, (this.order?.Identifier.Id ?? null) ?? (this.product?.Identifier.Id ?? null));
                __builder.AddContent$4(23, ")");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n        ");
                __builder.OpenElement(25, "div");
                __builder.AddAttribute$5(26, "class", "pd");
                __builder.OpenElement(27, "h2");
                __builder.AddContent$4(28, this.title);
                __builder.CloseElement();
                __builder.AddMarkupContent(29, "\r\n            ");
                __builder.AddContent(30, $.$mac.MAC.MarkupString.op_Explicit($.$ljzt.LCFCWM.MarkdownProcessor.ToHtml(this.message, this.ServiceProvider)));
                if (this.products !== null)
                {
                    __builder.AddMarkupContent(31, "<h3>Order Products</h3>\r\n                ");
                    __builder.OpenElement(32, "div");
                    __builder.AddAttribute$5(33, "class", "grid colm-1 gap-1");
                    let $en1 = this.products.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let product = $en1.SCG$IEnumerator$$$Current;
                        {
                            __builder.OpenElement(34, "div");
                            __builder.AddAttribute$5(35, "class", "bd corner clip");
                            __builder.OpenElement(36, "div");
                            __builder.AddAttribute$5(37, "class", "hx-1 clip");
                            __builder.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 38);
                            __builder.AddComponentParameter(39, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder.AddComponentParameter(40, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, product.IconDescriptor.Icon));
                            __builder.AddComponentParameter(41, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder.CloseComponent();
                            __builder.CloseElement();
                            __builder.AddMarkupContent(42, "\r\n                            ");
                            __builder.OpenElement(43, "p");
                            __builder.AddAttribute$5(44, "class", "fsz-small mgy-2 text-center nowrap");
                            __builder.AddContent$4(45, product.Title);
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                    __builder.CloseElement();
                    __builder.AddMarkupContent(46, "\r\n                ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 47);
                    __builder.AddComponentParameter(48, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder.AddComponentParameter(49, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 2048/*ButtonFeatures.XLarge*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(50, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `https://${$.$strNN(this.Deployment.LCCCS$ICommunityApplicationDeployment$Domain)}/${$.$strNN($.$$.S.String.Trim$3.call(this.order.Link, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /***/ 42, /*/*/ 47 ])))}`));
                    __builder.AddComponentParameter(51, "Class", "wf mgt-5 d-block");
                    __builder.AddComponentParameter(52, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `background-color:${$.$strNN("#ff4747"/*CommunityBuyLinkApplication.ThemeColor*/)};color:#FFF`));
                    __builder.AddAttribute$3(53, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(54, "Open Order");
                    }), $lKPdee ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":701949,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else if (this.product !== null)
                {
                    __builder.OpenElement(55, "div");
                    __builder.AddAttribute$5(56, "class", "bd corner clip");
                    __builder.OpenElement(57, "div");
                    __builder.AddAttribute$5(58, "class", "hx-2 clip");
                    __builder.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 59);
                    __builder.AddComponentParameter(60, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 200), $.$$.S.Int32));
                    __builder.AddComponentParameter(61, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.product.IconDescriptor.Icon));
                    __builder.AddComponentParameter(62, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(63, "\r\n                    ");
                    __builder.OpenElement(64, "p");
                    __builder.AddAttribute$5(65, "class", "fsz-small mgy-2 text-center nowrap");
                    __builder.AddContent$4(66, this.product.Title);
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(67, "\r\n                ");
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 68);
                    __builder.AddComponentParameter(69, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 2048/*ButtonFeatures.XLarge*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(70, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `https://${$.$strNN(this.Deployment.LCCCS$ICommunityApplicationDeployment$Domain)}/${$.$strNN($.$$.S.String.Trim$3.call(this.product.Link, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /***/ 42, /*/*/ 47 ])))}`));
                    __builder.AddComponentParameter(71, "Class", "wf mgt-5 d-block");
                    __builder.AddComponentParameter(72, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `background-color:${$.$strNN("#ff4747"/*CommunityBuyLinkApplication.ThemeColor*/)};color:#FFF`));
                    __builder.AddAttribute$3(73, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(74, "Open Product");
                    }), $kENRlj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":701949,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180571133)
            
            //--TRIMMABLE-BOUNDARY-START(12885603837)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885603837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885603837)
            
            //--TRIMMABLE-BOUNDARY-START(12885603837)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12885603837)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425211389)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(64425211389)
                
                //--TRIMMABLE-BOUNDARY-START(21475538429)
                this.Deployment = null;
                //--TRIMMABLE-BOUNDARY-END(21475538429)
                
            }
            static $h = 701949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCCE$1.EmailTemplateBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425211389),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655407613,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605080573,
        "f": 83886081
      },
      "n": "Server",
      "d": 701949,
      "h": 64425211389,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425211389),
//--TRIMMABLE-BOUNDARY-START(21475538429),
    {
      "p": 17012160,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065473021,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015145981,
        "f": 83886081
      },
      "n": "Deployment",
      "d": 701949,
      "h": 21475538429,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475538429)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245342205),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 701949,
      "h": 47245342205,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245342205),
//--TRIMMABLE-BOUNDARY-START(17180571133),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 701949,
      "h": 17180571133,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180571133)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85900047869),
    {
      "t": 1310721,
      "n": "title",
      "d": 701949,
      "h": 85900047869,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900047869),
//--TRIMMABLE-BOUNDARY-START(42950374909),
    {
      "t": 1310721,
      "n": "message",
      "d": 701949,
      "h": 42950374909,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950374909),
//--TRIMMABLE-BOUNDARY-START(51540309501),
    {
      "t": 937327,
      "n": "order",
      "d": 701949,
      "h": 51540309501,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540309501),
//--TRIMMABLE-BOUNDARY-START(60130244093),
    {
      "t": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
      "n": "products",
      "d": 701949,
      "h": 60130244093,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130244093),
//--TRIMMABLE-BOUNDARY-START(55835276797),
    {
      "t": 1789295,
      "n": "product",
      "d": 701949,
      "h": 55835276797,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835276797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885603837),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 701949,
      "h": 12885603837,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885603837)
  ],
  "h": 701949,
  "a": [
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/BuyLink/Email",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Pages.Emails.Common`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Pages${separator}Emails${separator}Common`; }
        });
        //--TRIMMABLE-BOUNDARY-END(701949)
        
        

        //--TRIMMABLE-BOUNDARY-START(964093)
        $asm.$cls(`$ehcb.LCCBCAS$1.BuyLinkAdminOrderDetails`, ($self) => class BuyLinkAdminOrderDetails extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)
        {
            //--TRIMMABLE-BOUNDARY-START(73015408125)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(73015408125)
            
            //--TRIMMABLE-BOUNDARY-START(21475800573)
            /*IChatProvider*/ Chat = null;
            //--TRIMMABLE-BOUNDARY-END(21475800573)
            
            //--TRIMMABLE-BOUNDARY-START(64425473533)
            /*QueryPostModel*/ query = null;
            //--TRIMMABLE-BOUNDARY-END(64425473533)
            
            //--TRIMMABLE-BOUNDARY-START(68720440829)
            /*ValueTask *//*async*/  Query(/*QueryPostModel*/ query)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720440829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$LCOv.LCFCPM$1.QueryPostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(this.ViewModel.Identifier), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.QueryPostModel), [ query ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720440829)
            
            //--TRIMMABLE-BOUNDARY-START(98785211901)
            /*ValueTask *//*async*/  SetWaitingForPayment()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785211901);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ViewModel.QueryState = 3072/*PostQueryableState.AwaitingPayment*/;
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98785211901)
            
            //--TRIMMABLE-BOUNDARY-START(94490244605)
            /*ValueTask *//*async*/  SetBack()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490244605);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ViewModel.QueryState = 0/*PostQueryableState.Submitted*/;
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490244605)
            
            //--TRIMMABLE-BOUNDARY-START(25770767869)
            /*bool */ FilterProperty(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770767869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25770767869)
            
            //--TRIMMABLE-BOUNDARY-START(60130506237)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkadminorderdetails";
            }
            //--TRIMMABLE-BOUNDARY-END(60130506237)
            
            //--TRIMMABLE-BOUNDARY-START(55835538941)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835538941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Chat = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IChatProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55835538941)
            
            //--TRIMMABLE-BOUNDARY-START(17180833277)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180833277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("class"), "clip pdb-10"))));
                __builder.OpenElement(2, "h4");
                __builder.AddAttribute$5(3, "class", "mgx");
                __builder.AddContent$4(4, "Order \"");
                __builder.AddContent$4(5, this.ViewModel.Title);
                __builder.AddContent$4(6, "\"");
                __builder.CloseElement();
                __builder.AddMarkupContent(7, "\r\n    ");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 8);
                __builder.AddComponentParameter(9, "Class", "mgt");
                __builder.AddComponentParameter(10, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Fatal));
                __builder.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 2097152n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(12, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ViewModel.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddComponentParameter(13, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.ViewModel.Products));
                __builder.AddComponentParameter(14, "th-class", "bg-gray");
                __builder.AddAttribute$3(15, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*products*/ products) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if (products.Models !== null)
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca1__;
                            this.ViewModel.Children = $.$sl.SL.Enumerable.ToList($.$LCOv.LCFCPM$1.PostAssociationModel, (((__ca1__ = this.ViewModel.Children) !== null ? ($.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostAssociationModel, __ca1__, $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel, products.Models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/*m*/ m) =>
                            {
                                return (() =>
                                {
                                    //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                    const $t4 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                    const $i4 = new $t4();
                                    $i4.$ctor$1();
                                    $i4.Association = m.Data;
                                    return $i4;
                                })();
                            }, $UoWSLb ??= {"r":15919540,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794}))) ?? $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel, products.Models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/*m*/ m) =>
                            {
                                return (() =>
                                {
                                    //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                    const $t5 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                    const $i5 = new $t5();
                                    $i5.$ctor$1();
                                    $i5.Association = m.Data;
                                    return $i5;
                                })();
                            }, $itpQue ??= {"r":15919540,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794}))) : $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel, products.Models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/**/ m) =>
                            {
                                return (() =>
                                {
                                    //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                    const $t6 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                    const $i6 = new $t6();
                                    $i6.$ctor$1();
                                    $i6.Association = m.Data;
                                    return $i6;
                                })();
                            }, $ktPQal ??= {"r":15919540,"p":[{"n":"m","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794})))));
                        }
                        __builder2.OpenElement(16, "div");
                        __builder2.AddAttribute$5(17, "class", "row");
                        __builder2.OpenElement(18, "div");
                        __builder2.AddAttribute$5(19, "class", "col-a");
                        __builder2.OpenElement(20, "div");
                        __builder2.AddAttribute$5(21, "class", "hx-1 wx-1 mgl-1");
                        __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 22);
                        __builder2.AddComponentParameter(23, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 100), $.$$.S.Int32));
                        __builder2.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.ViewModel.Account));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(25, "\r\n                    ");
                        __builder2.OpenElement(26, "div");
                        __builder2.AddAttribute$5(27, "class", "text-center");
                        __builder2.OpenElement(28, "h4");
                        __builder2.AddAttribute$5(29, "class", "mg-0");
                        __builder2.AddContent$4(30, this.ViewModel.Account.Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(31, "\r\n                        ");
                        __builder2.OpenElement(32, "small");
                        __builder2.AddAttribute$5(33, "class", "op-9 d-block");
                        __builder2.AddContent$4(34, this.ViewModel.Account.Summary);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(35, "\r\n                        ");
                        __builder2.AddMarkupContent(36, "<small class=\"mgt-2 d-block\">11 total orders</small>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(37, "\r\n                ");
                        __builder2.OpenElement(38, "div");
                        __builder2.AddAttribute$5(39, "class", "col-3 miwx-4 mawx-4 pdx");
                        __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkOrderBanner, 40);
                        __builder2.AddComponentParameter(41, "Class", "hf");
                        __builder2.AddComponentParameter(42, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.ViewModel));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(43, "\r\n                ");
                        __builder2.OpenElement(44, "div");
                        __builder2.AddAttribute$5(45, "class", "col-7");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 46);
                        __builder2.AddComponentParameter(47, "Class", "hf");
                        __builder2.AddComponentParameter(48, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(49, "InitialViewIndex", "0");
                        __builder2.AddComponentParameter(50, "tabshead-class", "bg-tertiary");
                        __builder2.AddComponentParameter(51, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 2/*TabsFeatures.TabsBorder*/ | 256/*TabsFeatures.TabBorder*/ | 4/*TabsFeatures.TabsSelectedBorder*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                        __builder2.AddAttribute$3(52, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 53);
                            __builder3.AddComponentParameter(54, "Class", "stack hf");
                            __builder3.AddAttribute$3(55, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*tt*/ tt) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(56, "<b>Information</b>");
                                }, $YDRGad ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $GVEtsb ??= {"r":6881395,"p":[{"n":"tt","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(57, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*cc*/ cc) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    $.$ehcb._LCCBCASB.TypeInference.CreatePropertySheet_0($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, __builder4, 58, 59, 35184372092928n | 65536n | 8388608n, 60, 2, 61, "FilterProperty", 62, this.ViewModel);
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>*/ let __ca2__;
                                    if ((this.ViewModel.QueryState === 0/*PostQueryableState.Submitted*/ || this.ViewModel.QueryState === 2048/*PostQueryableState.QueryAnswered*/) && (((__ca2__ = this.ViewModel.Products) !== null ? $.$sl.SL.Enumerable.All($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca2__, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                                    {
                                        return p.QueryState === 3072/*PostQueryableState.AwaitingPayment*/;
                                    }, $qHwtid ??= {"r":262145,"p":[{"n":"p","p":1789295}],"n":"","d":964093,"h":0,"f":17825794})) : false)))
                                    {
                                        __builder4.AddMarkupContent(63, "<div class=\"fill\"></div>\r\n                                    ");
                                        __builder4.OpenElement(64, "div");
                                        __builder4.AddAttribute$5(65, "class", "bdl bd-primary bdw-3 bg-primary-01 pd");
                                        __builder4.AddMarkupContent(66, "\r\n                                        All products price are set for this order.\r\n                                        ");
                                        __builder4.OpenElement(67, "a");
                                        __builder4.AddAttribute$5(68, "class", "bdb clickable f-right");
                                        __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 69, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.SetWaitingForPayment)));
                                        __builder4.AddContent$4(70, "Migrate to Awaiting Payment");
                                        __builder4.CloseElement();
                                        __builder4.CloseElement();
                                    }
                                }, $BjROmd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $wdyyhe ??= {"r":6881395,"p":[{"n":"cc","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(71, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 72);
                            __builder3.AddComponentParameter(73, "Class", "hx-3 scroll");
                            __builder3.AddAttribute$3(74, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(75, "<b>Queries</b>");
                                }, $IaZGLe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $QVLoxj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(76, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.QueryPostModel), 77);
                                    __builder4.AddComponentParameter(78, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.ViewModel));
                                    __builder4.AddComponentParameter(79, "Editable", "true");
                                    __builder4.CloseComponent();
                                }, $QUeXuk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $MZdtHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(80, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 81);
                            __builder3.AddComponentParameter(82, "Class", "hx-3 scroll");
                            __builder3.AddAttribute$3(83, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*tt*/ tt) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(84, "<b>Chat</b>");
                                }, $fdpeIc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $QAgusd ??= {"r":6881395,"p":[{"n":"tt","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(85, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*cc*/ cc) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(86, this.Chat.LCFCI$IChatProvider$GetChatThread($.$fPer.LCFCD.DataId.op_Implicit$1($.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.ViewModel.Identifier, this.ViewModel.Account.Identifier ], null, null))), this.ViewModel.Title, new $.$fPer.LCFCD.DataId(), null, 0, null));
                                }, $NqMTne ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                            }), $KoKppg ??= {"r":6881395,"p":[{"n":"cc","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $JoQInk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":964093,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(87, "\r\n\r\n            ");
                        __builder2.AddMarkupContent(88, "<h3 class=\"mgx\">Products</h3>\r\n            ");
                        __builder2.AddContent$1(89, products.View);
                    }, $PcyTVd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                }), $IaCoOj ??= {"r":6881395,"p":[{"n":"products","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                __builder.AddAttribute$3(90, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/**/ product) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 91);
                        __builder2.CloseComponent();
                    }, $ClPjVj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                }), $QftBec ??= {"r":6881395,"p":[{"n":"product","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                __builder.AddAttribute$3(92, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*detail*/ detail) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductDetails, 93);
                        __builder2.AddComponentParameter(94, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).op_Implicit$1(detail)));
                        __builder2.CloseComponent();
                    }, $cuDdff ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":964093,"h":0,"f":17825794});
                }), $WgXDYc ??= {"r":6881395,"p":[{"n":"detail","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":964093,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180833277)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885865981)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885865981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885865981)
            
            //--TRIMMABLE-BOUNDARY-START(12885865981)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885865981)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015408125)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(73015408125)
                
                //--TRIMMABLE-BOUNDARY-START(21475800573)
                this.Chat = null;
                //--TRIMMABLE-BOUNDARY-END(21475800573)
                
                //--TRIMMABLE-BOUNDARY-START(64425473533)
                this.query = new $.$LCOv.LCFCPM$1.QueryPostModel().$ctor$7();
                //--TRIMMABLE-BOUNDARY-END(64425473533)
                
            }
            static $h = 964093;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015408125),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540571645,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195277309,
        "f": 83886081
      },
      "n": "Server",
      "d": 964093,
      "h": 73015408125,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015408125),
//--TRIMMABLE-BOUNDARY-START(21475800573),
    {
      "p": 63526570,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360702461,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605342717,
        "f": 83886081
      },
      "n": "Chat",
      "d": 964093,
      "h": 21475800573,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475800573),
//--TRIMMABLE-BOUNDARY-START(60130506237),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950637053,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 964093,
      "h": 60130506237,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130506237)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720440829),
    {
      "r": 181338113,
      "p": [
        {
          "n": "query",
          "p": 22473140
        }
      ],
      "n": "Query",
      "d": 964093,
      "h": 68720440829,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720440829),
//--TRIMMABLE-BOUNDARY-START(98785211901),
    {
      "r": 181338113,
      "n": "SetWaitingForPayment",
      "d": 964093,
      "h": 98785211901,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(98785211901),
//--TRIMMABLE-BOUNDARY-START(94490244605),
    {
      "r": 181338113,
      "n": "SetBack",
      "d": 964093,
      "h": 94490244605,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(94490244605),
//--TRIMMABLE-BOUNDARY-START(25770767869),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "FilterProperty",
      "d": 964093,
      "h": 25770767869,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770767869),
//--TRIMMABLE-BOUNDARY-START(55835538941),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 964093,
      "h": 55835538941,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835538941),
//--TRIMMABLE-BOUNDARY-START(17180833277),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 964093,
      "h": 17180833277,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180833277)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425473533),
    {
      "t": 22473140,
      "n": "query",
      "d": 964093,
      "h": 64425473533,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425473533)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885865981),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 964093,
      "h": 12885865981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885865981)
  ],
  "h": 964093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminOrderDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminOrderDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(964093)
        
        

        //--TRIMMABLE-BOUNDARY-START(1095165)
        $asm.$cls(`$ehcb.LCCBCAS$1.BuyLinkAdminProductDetails`, ($self) => class BuyLinkAdminProductDetails extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)
        {
            //--TRIMMABLE-BOUNDARY-START(60130637309)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkadminproductdetails";
            }
            //--TRIMMABLE-BOUNDARY-END(60130637309)
            
            //--TRIMMABLE-BOUNDARY-START(55835670013)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835670013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Chat = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IChatProvider, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55835670013)
            
            //--TRIMMABLE-BOUNDARY-START(21475931645)
            /*IChatProvider*/ Chat = null;
            //--TRIMMABLE-BOUNDARY-END(21475931645)
            
            //--TRIMMABLE-BOUNDARY-START(64425604605)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(64425604605)
            
            //--TRIMMABLE-BOUNDARY-START(85900441085)
            /*ValueTask *//*async*/  SetPrice(/*double*/ amount)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900441085);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ViewModel.UnitCost = $.$fPer.LCFCDM.Money.op_Implicit$1(amount);
                    this.ViewModel.QueryState = 3072/*PostQueryableState.AwaitingPayment*/;
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900441085)
            
            //--TRIMMABLE-BOUNDARY-START(25770898941)
            /*bool */ FilterProperty(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770898941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25770898941)
            
            //--TRIMMABLE-BOUNDARY-START(17180964349)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180964349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddMultipleAttributes(1, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("class"), "bg-tertiary clip"))));
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "pd");
                __builder.OpenElement(4, "a");
                __builder.AddAttribute$5(5, "target", "_blank");
                __builder.AddAttribute$5(6, "href", this.ViewModel.Url);
                __builder.OpenElement(7, "h4");
                __builder.AddAttribute$5(8, "class", "mg-0");
                __builder.AddContent$4(9, "Product: \"");
                __builder.AddContent$4(10, this.ViewModel.Title);
                __builder.AddContent$4(11, "\"");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n        ");
                __builder.OpenElement(13, "em");
                __builder.AddAttribute$5(14, "class", "d-block mgt-2");
                __builder.AddContent$4(15, this.ViewModel.Summary);
                __builder.CloseElement();
                __builder.AddMarkupContent(16, "\r\n        ");
                __builder.OpenElement(17, "em");
                __builder.AddAttribute$5(18, "class", "d-block");
                __builder.AddContent$4(19, this.ViewModel.Post);
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(20, "\r\n    ");
                __builder.OpenElement(21, "div");
                __builder.AddAttribute$5(22, "class", "row");
                __builder.OpenElement(23, "div");
                __builder.AddAttribute$5(24, "class", "col-3 miwx-5 mawx-5");
                __builder.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductBanner, 25);
                __builder.AddComponentParameter(26, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this.ViewModel));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n        ");
                __builder.OpenElement(28, "div");
                __builder.AddAttribute$5(29, "class", "col-7");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 30);
                __builder.AddComponentParameter(31, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(32, "InitialViewIndex", "0");
                __builder.AddComponentParameter(33, "tabhead-class", "bg-card");
                __builder.AddComponentParameter(34, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 2/*TabsFeatures.TabsBorder*/ | 256/*TabsFeatures.TabBorder*/ | 4/*TabsFeatures.TabsSelectedBorder*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                __builder.AddAttribute$3(35, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 36);
                    __builder2.AddAttribute$3(37, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ tt) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(38, "<b>Information</b>");
                        }, $UwSeEe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $MCKiGc ??= {"r":6881395,"p":[{"n":"tt","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*cc*/ cc) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            $.$ehcb._LCCBCASB$1.TypeInference.CreatePropertySheet_0($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __builder3, 40, 41, 35184372092928n | 65536n | 8388608n, 42, 2, 43, "FilterProperty", 44, this.ViewModel);
                        }, $GfXDTd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $hXLSAi ??= {"r":6881395,"p":[{"n":"cc","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(45, "\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 46);
                    __builder2.AddComponentParameter(47, "Class", "hx-3 scroll");
                    __builder2.AddAttribute$3(48, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(49, "<b>Queries</b>");
                        }, $QOMTcl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $JMsXNj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(50, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.QueryPostModel), 51);
                            __builder3.AddComponentParameter(52, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.ViewModel));
                            __builder3.AddComponentParameter(53, "Editable", "true");
                            __builder3.CloseComponent();
                        }, $PHMuQe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $aMCbwc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(54, "\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 55);
                    __builder2.AddComponentParameter(56, "Class", "hx-3 scroll");
                    __builder2.AddAttribute$3(57, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*tt*/ tt) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(58, "<b>Chat</b>");
                        }, $efZMkf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $FWqbJa ??= {"r":6881395,"p":[{"n":"tt","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(59, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ cc) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$1(60, this.Chat.LCFCI$IChatProvider$GetChatThread($.$fPer.LCFCD.DataId.op_Implicit$1($.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.ViewModel.Identifier, this.ViewModel.Account.Identifier ], null, null))), this.ViewModel.Title, new $.$fPer.LCFCD.DataId(), null, 0, null));
                        }, $YDxJVi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $kXQAae ??= {"r":6881395,"p":[{"n":"cc","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(61, "\r\n                ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 62);
                    __builder2.AddComponentParameter(63, "Class", "pd");
                    __builder2.AddAttribute$3(64, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(65, "<b>Pricing</b>");
                        }, $jjDWVg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $BToLSk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(66, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(67, "<em>Please ensure all neccessary questions on this product are clarified before setting a price</em>\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$$.S.Double), 68);
                            __builder3.AddComponentParameter(69, "Class", "mgt");
                            __builder3.AddComponentParameter(70, "field-input-class", "bg-promary-01");
                            __builder3.AddComponentParameter(71, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(72, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 4/*FormBuilderFeatures.Horizontal*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                            __builder3.AddComponentParameter(73, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Double), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.S.Double, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.S.Double, $.$$.STT.ValueTask))().$ctor(this, this.SetPrice))));
                            __builder3.AddAttribute$3(74, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 75);
                                __builder4.AddComponentParameter(76, "Class", "mg-1");
                                __builder4.AddComponentParameter(77, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder4.AddComponentParameter(78, "type", "submit");
                                __builder4.AddAttribute$3(79, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(80, "Set Price");
                                }), $ViBdUb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }), $eQZRde ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $wsdGfh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794});
                    }), $tKTFjg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1095165,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $TINVEf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1095165,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180964349)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885997053)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885997053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885997053)
            
            //--TRIMMABLE-BOUNDARY-START(12885997053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885997053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475931645)
                this.Chat = null;
                //--TRIMMABLE-BOUNDARY-END(21475931645)
                
                //--TRIMMABLE-BOUNDARY-START(64425604605)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(64425604605)
                
            }
            static $h = 1095165;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130637309),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950768125,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1095165,
      "h": 60130637309,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130637309),
//--TRIMMABLE-BOUNDARY-START(21475931645),
    {
      "p": 63526570,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360833533,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015539197,
        "f": 83886081
      },
      "n": "Chat",
      "d": 1095165,
      "h": 21475931645,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475931645),
//--TRIMMABLE-BOUNDARY-START(64425604605),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540702717,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605473789,
        "f": 83886081
      },
      "n": "Server",
      "d": 1095165,
      "h": 64425604605,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425604605)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835670013),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1095165,
      "h": 55835670013,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835670013),
//--TRIMMABLE-BOUNDARY-START(85900441085),
    {
      "r": 181338113,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "SetPrice",
      "d": 1095165,
      "h": 85900441085,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85900441085),
//--TRIMMABLE-BOUNDARY-START(25770898941),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "FilterProperty",
      "d": 1095165,
      "h": 25770898941,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770898941),
//--TRIMMABLE-BOUNDARY-START(17180964349),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1095165,
      "h": 17180964349,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180964349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885997053),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1095165,
      "h": 12885997053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885997053)
  ],
  "h": 1095165
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminProductDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminProductDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1095165)
        
        

        //--TRIMMABLE-BOUNDARY-START(898557)
        $asm.$cls(`$ehcb.LCCBCAS$1.BuyLinkAdminAccountsPage`, ($self) => class BuyLinkAdminAccountsPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590833149)
            /*AccountModel*/ account = null;
            //--TRIMMABLE-BOUNDARY-END(8590833149)
            
            //--TRIMMABLE-BOUNDARY-START(25770702333)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<AccountModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770702333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.account = $.$sl.SL.Enumerable.First$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$LCOv.LCFCPM$1.AccountModel), selection.SelectedItems).LCFCCD$1$IDataListItemContext$$$Data;
                    ($t1 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Admin.Blazor\\BuyLinkAdminAccountsPage.razor.cs", "OnSelected", 17), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770702333)
            
            //--TRIMMABLE-BOUNDARY-START(30065669629)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkadminaccountspage";
            }
            //--TRIMMABLE-BOUNDARY-END(30065669629)
            
            //--TRIMMABLE-BOUNDARY-START(12885800445)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885800445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "bd row hf");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "col-a mawx-1 miwx-1 bdr");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 4);
                __builder.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n | 8n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(6, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                __builder.AddComponentParameter(7, "li-class", "pd");
                __builder.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 9);
                        __builder2.AddComponentParameter(10, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Title));
                        __builder2.AddComponentParameter(11, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Description));
                        __builder2.AddComponentParameter(12, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, context.Model.Icon));
                        __builder2.CloseComponent();
                    }, $yQbaMd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":898557,"h":0,"f":17825794});
                }), $fSuzhf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":898557,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n    ");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "col-10 flex");
                if (this.account !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 16);
                    __builder.AddComponentParameter(17, "Class", "wf hf");
                    __builder.AddComponentParameter(18, "InitialViewIndex", "0");
                    __builder.AddComponentParameter(19, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder.AddComponentParameter(20, "tabhead-class", "bg-card bdb bdt");
                    __builder.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 22);
                        __builder2.AddComponentParameter(23, "Class", "stack hf");
                        __builder2.AddAttribute$3(24, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 25);
                                __builder3.AddComponentParameter(26, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(27, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddAttribute$3(28, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(29, "\r\n                            Orders\r\n                        ");
                                }), $oDKAQc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":898557,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $myJjLb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":898557,"h":0,"f":17825794});
                        }), $XjyoRj ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":898557,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminOrderTable, 31);
                                __builder3.AddComponentParameter(32, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.account.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder3.CloseComponent();
                            }, $ZVfJTg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":898557,"h":0,"f":17825794});
                        }), $rxiJSe ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":898557,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(33, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 34);
                        __builder2.AddComponentParameter(35, "Class", "stack hf");
                        __builder2.AddAttribute$3(36, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 37);
                                __builder3.AddComponentParameter(38, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(39, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(41, "\r\n                            Products\r\n                        ");
                                }), $rpqCQd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":898557,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $GlZlEe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":898557,"h":0,"f":17825794});
                        }), $NKCZfd ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":898557,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$ehcb.LCCBCAS$1.BuyLinkAdminProductTable, 43);
                                __builder3.AddComponentParameter(44, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.account.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder3.CloseComponent();
                            }, $hzxDLc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":898557,"h":0,"f":17825794});
                        }), $JEEbYf ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":898557,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }), $syABYb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":898557,"h":0,"f":17825794}));
                    __builder.SetKey(this.account);
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 45);
                    __builder.AddComponentParameter(46, "Class", "mg-a");
                    __builder.AddComponentParameter(47, "Message", "Select an account for details");
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885800445)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Posts$Models$AccountModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295865853)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295865853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295865853)
            
            //--TRIMMABLE-BOUNDARY-START(4295865853)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295865853)
            
            static $h = 898557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065669629),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475735037,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 898557,
      "h": 30065669629,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065669629)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770702333),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$LCOv.LCFCPM$1.AccountModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 898557,
      "h": 25770702333,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770702333),
//--TRIMMABLE-BOUNDARY-START(12885800445),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 898557,
      "h": 12885800445,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885800445)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590833149),
    {
      "t": 7858612,
      "n": "account",
      "d": 898557,
      "h": 8590833149,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590833149)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295865853),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 898557,
      "h": 4295865853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295865853)
  ],
  "h": 898557
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Admin.Shared.BuyLinkAdminAccountsPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Admin${separator}Shared${separator}BuyLinkAdminAccountsPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(898557)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.BuyLink.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Shipping.Client.Blazor", "NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Admin.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(46589)
