
//--TRIMMABLE-BOUNDARY-START(49748)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $RffN, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $oUrI) {
    "use strict";
    let _;
    let $IBlOPb;
    let $IpTAzb;
    let $JNboTb;
    let $gZsQRd;
    let $NgXyTk;
    let $bSBLYk;
    let $bRqUia;
    let $YEoVNh;
    let $znPfDi;
    let $zCtYNc;
    let $nONmya;
    let $hGZwAj;
    let $UKHAcd;
    let $rlcohi;
    let $ihQzEc;
    let $ElBBgh;
    let $KwGZde;
    let $LDCPwf;
    let $juJuWh;
    let $EEWFBe;
    let $RIzbZf;
    let $YxAXOe;
    let $tZGYrc;
    let $rnptXh;
    let $dJEBfk;
    let $ywlixi;
    let $vXpVWc;
    let $wJlLKk;
    let $AOfwhl;
    let $jehWmc;
    let $XAikdc;
    let $BKHoOj;
    let $YYwjgk;
    let $vukzVb;
    let $wwswYd;
    let $RvghVk;
    let $clnWGb;
    let $jvRLnk;
    let $zSgPXd;
    let $LgxGNj;
    let $dqlxyc;
    let $qMMzlh;
    let $Sgitvh;
    let $BbaWPg;
    let $KpUkTh;
    let $ayIodd;
    let $OdyhNg;
    let $nLuaDj;
    let $iJHymc;
    let $XEFHof;
    let $YwnMzi;
    let $CtKhuk;
    let $BMQuIi;
    let $kLMzCj;
    let $wLjsBf;
    let $mZQPGd;
    let $KwBvbe;
    let $KIApZb;
    let $dXHzdd;
    let $yNhDea;
    let $MQrgCg;
    let $dzspSh;
    let $CZdkkj;
    let $sLcpnf;
    let $Giduue;
    let $qbglCf;
    let $FYElEk;
    let $GcPvWj;
    let $dYHNGd;
    let $mJpKIb;
    let $WJXpqb;
    let $BGpvqc;
    let $gBwWsc;
    let $PvmYAf;
    let $rkZzJh;
    let $JmCKlc;
    let $KPgMvf;
    let $xFRoYe;
    let $uTIWIe;
    let $slCOOk;
    let $dACbWd;
    let $cLiEDh;
    let $qYlgHa;
    let $RUeEGf;
    let $nQODNc;
    let $BKJLhl;
    let $sNmleh;
    let $kmVyUh;
    let $eLimQc;
    let $WxvGLg;
    let $oCHuli;
    let $ZaHOGf;
    let $Lirdba;
    let $JqYvlb;
    let $vWAgZf;
    let $dVTRHc;
    let $IJTSVg;
    let $unQQcj;
    let $zNIjzd;
    let $nRDRBd;
    let $gYTYKf;
    let $ozfNLe;
    let $rFOOXb;
    let $BPMogh;
    let $zBixle;
    let $SLRuTd;
    let $Rasrdb;
    let $SLjzVk;
    let $rIxEae;
    let $MvZgNj;
    let $jSvslh;
    let $bzSBOf;
    let $TRbWYa;
    let $xKCZHd;
    let $bNgMFi;
    let $mgUEvh;
    let $FvRqdc;
    let $TPWyrf;
    let $ULnaTj;
    let $aKGIxb;
    let $iobRYf;
    let $MbXBGc;
    let $cPSJdi;
    let $olIkDf;
    let $HHywIh;
    let $GiRujf;
    let $qjcBFe;
    let $XJmZdg;
    let $JEtxSd;
    let $sHyMhd;
    let $hZoLBd;
    let $Inpftc;
    let $jvQerj;
    let $ZTNhEf;
    let $QwCOJa;
    let $TrPIAj;
    let $SYirCc;
    let $kqsguj;
    let $uKlelk;
    let $jHELnb;
    let $sjacpi;
    let $UPuQJc;
    let $rfxuec;
    let $Tvwxke;
    let $fbLkgk;
    let $gkQtBb;
    let $SZyADh;
    let $kahxlc;
    let $DXOkva;
    let $vweDHe;
    let $yDnHwf;
    let $CNlUDg;
    let $tLHqdg;
    let $TFGDLf;
    let $itjaci;
    let $rXfwDg;
    let $cxVoOj;
    let $dCUpbh;
    let $ErROoh;
    let $UvXqxc;
    let $YbTcVf;
    let $aBoJte;
    let $IwMRil;
    let $rTqCYh;
    let $rBrFIk;
    let $sVpzXb;
    let $GKciVf;
    let $KJExAk;
    let $fifuzk;
    let $LQOJUj;
    let $SsQKGi;
    let $Dnuqbb;
    let $VQOyRk;
    let $vMgrJh;
    let $UcsjWf;
    let $mSIzZj;
    let $JPUmFk;
    let $pFQhMf;
    let $fRokbg;
    let $Wnqnrc;
    let $MSFCNc;
    let $jzBUok;
    let $mzaGRd;
    let $djLHYk;
    let $NwqJqf;
    let $JSrTsa;
    let $YKyaKa;
    let $sLIybb;
    let $cBnILk;
    let $OxRDkd;
    let $YodPMi;
    let $BfKqpk;
    let $duVIig;
    let $MrIfnl;
    let $CZGWlh;
    let $GzLpXc;
    let $OHEJfb;
    let $edBJQi;
    let $fAHFek;
    let $feWypf;
    let $gVCaZb;
    let $OnWYLh;
    let $xXBzhj;
    let $jtsEnf;
    let $BNRTBk;
    let $GLiUIj;
    let $szbFbh;
    let $XXgQOe;
    let $VowOha;
    let $KKZCuh;
    let $HtuYkd;
    let $uQLqlc;
    let $XimBBk;
    let $yiNwOk;
    let $xDUKob;
    let $mIbRTi;
    let $OkUWCc;
    let $kcYbaa;
    let $CAXSof;
    let $ZxZJSi;
    let $WKMgyb;
    let $cFUcAk;
    let $YtRkRd;
    let $UlAVqa;
    let $zzESjg;
    let $hHiHok;
    let $nsvJVi;
    let $fgbwjj;
    let $RLyZEk;
    let $cvrqti;
    let $fjWsAe;
    let $WtXbse;
    let $mmUiTf;
    let $aTOoIe;
    let $Ruqhad;
    let $gbsJya;
    let $zvYOZe;
    let $ecfamk;
    let $bombwf;
    let $ummBUf;
    let $pWCMuj;
    let $yhqSPf;
    let $reFbxg;
    let $lMlrse;
    let $tZefxk;
    let $AUUblh;
    let $EPPXzc;
    let $lvQdYc;
    let $RsnNGe;
    let $srkRhi;
    let $JEafCj;
    let $XFrHaa;
    let $yjJLkk;
    let $mBjBXk;
    let $UlMFjh;
    let $DUKbgg;
    let $iVKymf;
    let $bfiFmb;
    let $obOKUi;
    let $CnKPkf;
    let $bFOjec;
    let $yAjBQc;
    let $aBxUnb;
    let $MHgXfc;
    let $Ijqwtd;
    let $dQGKWa;
    let $xdOvDk;
    let $AkZEkl;
    let $COXKfj;
    let $eKIkyb;
    let $FZVnik;
    let $rURzWj;
    let $GZZcLd;
    let $NSbvga;
    let $iWEnMg;
    let $kJAABh;
    let $yCeeMe;
    let $nwSfqg;
    let $ZZSBhe;
    let $bUIYuh;
    let $WLaqYh;
    let $pSLxxe;
    let $VZCwwk;
    let $rnAnRc;
    let $atClig;
    let $uoKQhh;
    let $KNNubk;
    let $NSFmqg;
    let $ScTTfk;
    let $PkyPRb;
    let $WdAUyk;
    let $LRygmf;
    let $XYBNyj;
    let $vHzoRk;
    let $ZpFrWk;
    let $cRiCvc;
    let $xFuJTc;
    let $jMXJjg;
    let $FLpqRd;
    let $nUYVgd;
    let $WtiEee;
    let $Bktabe;
    let $qXdXNe;
    let $qzXiid;
    let $IAWrpc;
    let $iDAwAb;
    let $AoZpEe;
    let $Zuqvpe;
    let $aXGTik;
    let $nsjpvf;
    let $zNmosk;
    let $bduYyk;
    let $COnjJc;
    let $FHEhGb;
    let $BCQYCd;
    let $BjrZzb;
    let $rYapMb;
    let $eVBucc;
    let $tOzIJf;
    let $kiaOya;
    let $mgBbpf;
    let $mDkcTh;
    let $MHjlsj;
    let $TGxElb;
    let $RKtKLa;
    let $AfFsel;
    let $RdUokg;
    let $yFoOjg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor", 
    {
  "h": 49748,
  "f": "LivingThing.Core.Community.BuyLink.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(967252)
        $asm.$cls(`$jfJD.LCCBCS.ICommunityBuyLinkAdmin`, ($self) => class ICommunityBuyLinkAdmin
        {
            static $h = 967252;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 967252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.ICommunityBuyLinkAdmin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}ICommunityBuyLinkAdmin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(967252)
        
        

        //--TRIMMABLE-BOUNDARY-START(377428)
        $asm.$cls(`$jfJD.LCCBC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295344724)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295344724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$jfJD.LCCBC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295344724)
            
            static $h = 377428;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295344724),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 377428,
      "h": 4295344724,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295344724)
  ],
  "h": 377428
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(377428)
        
        

        //--TRIMMABLE-BOUNDARY-START(115284)
        $asm.$cls(`$jfJD._LCCBCSB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295082580)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::System.Object*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "li-class", __arg2);
                __builder.AddComponentParameter(__seq3, "li-style", __arg3);
                __builder.AddComponentParameter(__seq4, "ChildContent", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082580)
            
            static $h = 115284;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295082580),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 131073
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 115284,
      "h": 4295082580,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295082580)
  ],
  "h": 115284
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkHome.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkHome${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(115284)
        
        

        //--TRIMMABLE-BOUNDARY-START(246356)
        $asm.$cls(`$jfJD._LCCBCSB$2.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295213652)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "Features", $.$box(__arg2, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq3, "Class", __arg3);
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295213652)
            
            //--TRIMMABLE-BOUNDARY-START(8590180948)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.Object*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg3, /*int*/ __seq4, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg4, /*int*/ __seq5, /*global::System.String*/ __arg5, /*int*/ __seq6, /*TValue*/ __arg6, /*int*/ __seq7, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg7, /*int*/ __seq8, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg8)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590180948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "PlaceHolder", __arg0);
                __builder.AddComponentParameter(__seq1, "rows", __arg1);
                __builder.AddComponentParameter(__seq2, "Type", $.$box(__arg2, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq3, "Theme", $.$clone(__arg3));
                __builder.AddComponentParameter(__seq4, "Features", $.$box(__arg4, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq5, "Class", __arg5);
                __builder.AddComponentParameter(__seq6, "Value", $.$box(__arg6, TValue));
                __builder.AddComponentParameter(__seq7, "ValueChanged", __arg7);
                __builder.AddComponentParameter(__seq8, "ValueExpression", __arg8);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590180948)
            
            static $h = 246356;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213652),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 27612842
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 246356,
      "h": 4295213652,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295213652),
//--TRIMMABLE-BOUNDARY-START(8590180948),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 131073
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 47614294
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 65309014
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 27612842
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 1310721
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq7",
          "p": 655361
        },
        {
          "n": "__arg7",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq8",
          "p": 655361
        },
        {
          "n": "__arg8",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 246356,
      "h": 8590180948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590180948)
  ],
  "h": 246356
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProductToolBar.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProductToolBar${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(246356)
        
        

        //--TRIMMABLE-BOUNDARY-START(180820)
        $asm.$cls(`$jfJD._LCCBCSB$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295148116)
            static /*void */ CreateFormBuilder_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*T*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg1, /*int*/ __seq2, /*global::LivingThing.Core.Frameworks.Common.DataDescriptor.PropertyDescriptorFilter*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.FormBuilder.FormBuilderFeatures*/ __arg3, /*int*/ __seq4, /*global::System.Object*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295148116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Model", $.$box(__arg0, T));
                __builder.AddComponentParameter(__seq1, "Theme", $.$clone(__arg1));
                __builder.AddComponentParameter(__seq2, "Filter", __arg2);
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                __builder.AddComponentParameter(__seq4, "sidebar-bar-class", __arg4);
                __builder.AddComponentParameter(__seq5, "Submit", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295148116)
            
            static $h = 180820;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295148116),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => T.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 65309014
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 42305878
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 23287466
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 131073
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": 6881395
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateFormBuilder_0",
      "d": 180820,
      "h": 4295148116,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295148116)
  ],
  "h": 180820
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProduct.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProduct${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180820)
        
        

        //--TRIMMABLE-BOUNDARY-START(574036)
        $asm.$cls(`$jfJD.LCCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590508628)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590508628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService($.$jfJD.LCCBCS.CommunityBuyLinkService, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$jfJD.LCCBCS.CommunityBuyLinkProductViewProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkProductViewProvider, x);
                }, $bSBLYk ??= {"r":$.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":574036,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkProductViewProvider, x);
                }, $bRqUia ??= {"r":$.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":574036,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$jfJD.LCCBCS.CommunityBuyLinkApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkApplication, x);
                }, $YEoVNh ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":574036,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkApplication, x);
                }, $znPfDi ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":574036,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$jfJD.LCCBCS.CommunityBuyLinkProductFeedProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$jfJD.LCCBCS.CommunityBuyLinkProductPoolFeedProvider, services);
                $.$jfJD.LCCBC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590508628)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$jfJD.LCCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295541332)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295541332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295541332)
            
            //--TRIMMABLE-BOUNDARY-START(4295541332)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295541332)
            
            static $h = 574036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590508628),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 574036,
      "h": 8590508628,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590508628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295541332),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 574036,
      "h": 4295541332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295541332)
  ],
  "h": 574036
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(574036)
        
        

        //--TRIMMABLE-BOUNDARY-START(442964)
        $asm.$cls(`$jfJD.LCCBC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180312148)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCP.CommunityBuyLinkApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCP.CommunityBuyLinkApp().$ctor$6();
                    }, $dzspSh ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkCheckOut.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkCheckOut().$ctor$3();
                    }, $CZdkkj ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkHome.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkHome().$ctor$6();
                    }, $sLcpnf ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkHomeBanner.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkHomeBanner().$ctor$3();
                    }, $Giduue ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkHowItWorks.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkHowItWorks().$ctor$3();
                    }, $qbglCf ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkLoading.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkLoading().$ctor$3();
                    }, $FYElEk ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkOrder.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkOrder().$ctor$4();
                    }, $GcPvWj ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkOrderBanner.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkOrderBanner().$ctor$5();
                    }, $dYHNGd ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkProductBanner.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkProductBanner().$ctor$5();
                    }, $mJpKIb ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkProductToolBar.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkProductToolBar().$ctor$5();
                    }, $WJXpqb ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkSupplierFilter.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkSupplierFilter().$ctor$5();
                    }, $BGpvqc ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkTAndC.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkTAndC().$ctor$3();
                    }, $gBwWsc ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jfJD.LCCBCS$1.BuyLinkWhy.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jfJD.LCCBCS$1.BuyLinkWhy().$ctor$3();
                    }, $PvmYAf ??= {"r":2752627,"n":"","d":442964,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180312148)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295410260)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295410260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295410260)
            
            //--TRIMMABLE-BOUNDARY-START(4295410260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295410260)
            
            static $h = 442964;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180312148),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885344852,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 442964,
      "h": 17180312148,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180312148)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295410260),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 442964,
      "h": 4295410260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295410260)
  ],
  "h": 442964
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442964)
        
        

        //--TRIMMABLE-BOUNDARY-START(2015828)
        $asm.$cls(`$jfJD.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296983124)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296983124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296983124)
            
            //--TRIMMABLE-BOUNDARY-START(4296983124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296983124)
            
            static $h = 2015828;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296983124),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2015828,
      "h": 4296983124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296983124)
  ],
  "h": 2015828,
  "a": [
    {
      "t": 1950292,
      "c": 4296917588
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2015828)
        
        

        //--TRIMMABLE-BOUNDARY-START(1950292)
        $asm.$cls(`$jfJD.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296917588)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296917588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296917588)
            
            //--TRIMMABLE-BOUNDARY-START(4296917588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296917588)
            
            static $h = 1950292;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296917588),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1950292,
      "h": 4296917588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296917588)
  ],
  "h": 1950292
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1950292)
        
        

        //--TRIMMABLE-BOUNDARY-START(311892)
        $asm.$cls(`$jfJD.LCCBC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590246484)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590246484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590246484)
            
            //--TRIMMABLE-BOUNDARY-START(4295279188)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295279188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295279188)
            
            //--TRIMMABLE-BOUNDARY-START(4295279188)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295279188)
            
            static $h = 311892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590246484),
    {
      "r": 65537,
      "n": "Execute",
      "d": 311892,
      "h": 8590246484,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590246484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295279188),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 311892,
      "h": 4295279188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295279188)
  ],
  "h": 311892
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311892)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032788)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkCheckOut`, ($self) => class BuyLinkCheckOut extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(81605411412)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81605411412)
            
            //--TRIMMABLE-BOUNDARY-START(115965149780)
            /*IUIService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(115965149780)
            
            //--TRIMMABLE-BOUNDARY-START(21475869268)
            /*Application*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475869268)
            
            //--TRIMMABLE-BOUNDARY-START(68720509524)
            /*Task *//*async*/  MergeCart(/*CommunityBuyLinkOrderModel*/ order)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720509524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this,  () =>
                    {
                        return this.Service.MergeCart(order);
                    }, $JqYvlb ??= {"r":181338113,"n":"","d":1032788,"h":0,"f":17825794}), true, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if ($.$vWqU.LCFCC.LoadState.op_Equality(this.Service.Loading, $.$vWqU.LCFCC.LoadState.Loaded))
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer.LCFCI$IUIClientDrawerService$Close(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        ($t3 = $.$vWqU.LCFCC.IUIManagerExtension.NavigateTo$1($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UI.LCFCC$IUIService$Page, $.$fPer.LCFC.Stringy.op_Implicit$1($.$hDPm.LCFC.UtilityExtensions.GetAppLink$1("Order", this.Application.NavigationPathSegment)), order), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720509524)
            
            //--TRIMMABLE-BOUNDARY-START(77310444116)
            /*Task *//*async*/  Order(/*CommunityBuyLinkOrderModel*/ order)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310444116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ord = ($t4 = this.Service.Order(order), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if ($.$vWqU.LCFCC.LoadState.op_Equality(this.Service.Loading, $.$vWqU.LCFCC.LoadState.Loaded))
                    {
                        let $t5, $r5;
                        let $t6, $r6;
                        ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer.LCFCI$IUIClientDrawerService$Close(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        ($t6 = $.$vWqU.LCFCC.IUIManagerExtension.NavigateTo$1($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UI.LCFCC$IUIService$Page, $.$fPer.LCFC.Stringy.op_Implicit$1($.$hDPm.LCFC.UtilityExtensions.GetAppLink$1("Order", this.Application.NavigationPathSegment)), ord), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310444116)
            
            //--TRIMMABLE-BOUNDARY-START(73015476820)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkcheckout";
            }
            //--TRIMMABLE-BOUNDARY-END(73015476820)
            
            //--TRIMMABLE-BOUNDARY-START(111670182484)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670182484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch7 = parameter.Name;
                switch($switch7)
                {
                    case "Application":
                    this.Application = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111670182484)
            
            //--TRIMMABLE-BOUNDARY-START(64425542228)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425542228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64425542228)
            
            //--TRIMMABLE-BOUNDARY-START(25770836564)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770836564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h3 class=\"text-center mgb-0\">Ready to order these awesome things?</h3>\r\n");
                __builder.AddMarkupContent(1, "<p class=\"text-center\">Get price offers from BuyLinks within 24hrs</p>\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 2);
                __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(4, "li-class", "pdy");
                __builder.AddComponentParameter(5, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.Service.Cart));
                __builder.AddComponentParameter(6, "DataChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Service.Cart = __value;
                }, $vWAgZf ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h}],"n":"","d":1032788,"h":0,"f":17825794}), this.Service.Cart))));
                __builder.AddComponentParameter(7, "DataExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "Cart"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $dVTRHc ??= {"r":38797349,"n":"","d":1032788,"h":0,"f":17825794})).Invoke())));
                __builder.AddAttribute$3(8, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/**/ buyLink) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 9);
                        __builder2.AddComponentParameter(10, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLink.Model));
                        __builder2.CloseComponent();
                    }, $IJTSVg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794});
                }), $unQQcj ??= {"r":6881395,"p":[{"n":"buyLink","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1032788,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(11, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCA$3.AuthorizeUser, 12);
                __builder.AddComponentParameter(13, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCA$3.AuthorizeUserFeatures, 0/*AuthorizeUserFeatures.Default*/ | 4/*AuthorizeUserFeatures.LoginPopup*/ | 2/*AuthorizeUserFeatures.ShowLogin*/), $.$hDPm.LCFCCA$3.AuthorizeUserFeatures));
                __builder.AddComponentParameter(14, "EditorFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(15, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                __builder.AddComponentParameter(16, "FormTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfPrimary(0.1)));
                __builder.AddComponentParameter(17, "Intent", "Checkout");
                __builder.AddComponentParameter(18, "LoginCardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 0/*CardFeatures.None*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddComponentParameter(19, "Message", "Please login to continue");
                __builder.AddComponentParameter(20, "prompt-class", "mgy-10");
                __builder.AddAttribute$3(21, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*ticket*/ ticket) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 22);
                        __builder2.AddComponentParameter(23, "li-class", "pd");
                        __builder2.AddComponentParameter(24, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                        __builder2.AddComponentParameter(25, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddAttribute$3(26, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/**/ wrapper2) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel>>>?*/ let __ca1__;
                                if ((__ca1__ = wrapper2.Models) !== null ? $.$sl.SL.Enumerable.Any$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)), __ca1__) : false)
                                {
                                    __builder3.AddMarkupContent(27, "<p class=\"mgx\">\r\n                    \u270BWait, we found these pending (waiting for Buylink review) orders in your account.\r\n                    If you intend to merge these with them, click Merge, otherwise create a new order.\r\n                </p>");
                                }
                                __builder3.AddContent$1(28, wrapper2.View);
                            }, $zNIjzd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794});
                        }), $nRDRBd ??= {"r":6881395,"p":[{"n":"wrapper2","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":1032788,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(29, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 30);
                                __builder3.AddComponentParameter(31, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Title));
                                __builder3.AddComponentParameter(32, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(context.Model.DateCreated.ToString())}`));
                                __builder3.AddComponentParameter(33, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Description));
                                __builder3.AddComponentParameter(34, "Icon", "mdi mdi-cart");
                                __builder3.AddComponentParameter(35, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Link));
                                __builder3.AddComponentParameter(36, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, context.Model));
                                __builder3.AddComponentParameter(37, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                __builder3.CloseComponent();
                                __builder3.AddMarkupContent(38, "\r\n            ");
                                __builder3.OpenElement(39, "div");
                                __builder3.AddAttribute$5(40, "class", "pdb text-right");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 41);
                                __builder3.AddComponentParameter(42, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, context.Model));
                                __builder3.AddComponentParameter(43, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$$.STT.Task))().$ctor(this, this.MergeCart))));
                                __builder3.AddComponentParameter(44, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(45, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 128/*ButtonFeatures.XSmall*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddAttribute$3(46, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(47, "\r\n                    Merge into this\r\n                ");
                                }), $gYTYKf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                            }, $ozfNLe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794});
                        }), $rFOOXb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":1032788,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(48, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                        }), $BPMogh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(49, "\r\n    ");
                        __builder2.OpenElement(50, "div");
                        __builder2.AddAttribute$5(51, "class", "pd pos-rel");
                        __builder2.AddMarkupContent(52, "<h3>Order Information</h3>\r\n        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 53);
                        __builder2.AddComponentParameter(54, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$$.STT.Task))().$ctor(this, this.Order))));
                        __builder2.AddComponentParameter(55, "field-input-class", "bg-primary-01");
                        __builder2.AddAttribute$3(56, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 57);
                            __builder3.AddComponentParameter(58, "type", "submit");
                            __builder3.AddComponentParameter(59, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder3.AddComponentParameter(60, "Class", "mgt-10 wf");
                            __builder3.AddComponentParameter(61, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 1024/*ButtonFeatures.Large*/ | 8192/*ButtonFeatures.LoadingOnClick*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder3.AddAttribute$3(62, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddContent$4(63, "Create Order");
                            }), $zBixle ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $SLRuTd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }, $Rasrdb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1032788,"h":0,"f":17825794});
                }), $SLjzVk ??= {"r":6881395,"p":[{"n":"ticket","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":1032788,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770836564)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180901972)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180901972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180901972)
            
            //--TRIMMABLE-BOUNDARY-START(17180901972)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180901972)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605411412)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81605411412)
                
                //--TRIMMABLE-BOUNDARY-START(115965149780)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(115965149780)
                
            }
            static $h = 1032788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605411412),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540640340,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785280596,
        "f": 83886081
      },
      "n": "Service",
      "d": 1032788,
      "h": 81605411412,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605411412),
//--TRIMMABLE-BOUNDARY-START(115965149780),
    {
      "p": 5594536,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130574932,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375215188,
        "f": 83886081
      },
      "n": "UI",
      "d": 1032788,
      "h": 115965149780,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965149780),
//--TRIMMABLE-BOUNDARY-START(21475869268),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360771156,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195346004,
        "f": 83886081
      },
      "n": "Application",
      "d": 1032788,
      "h": 21475869268,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475869268),
//--TRIMMABLE-BOUNDARY-START(73015476820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950705748,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1032788,
      "h": 73015476820,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73015476820)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720509524),
    {
      "r": 178454529,
      "p": [
        {
          "n": "order",
          "p": 937327
        }
      ],
      "n": "MergeCart",
      "d": 1032788,
      "h": 68720509524,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720509524),
//--TRIMMABLE-BOUNDARY-START(77310444116),
    {
      "r": 178454529,
      "p": [
        {
          "n": "order",
          "p": 937327
        }
      ],
      "n": "Order",
      "d": 1032788,
      "h": 77310444116,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77310444116),
//--TRIMMABLE-BOUNDARY-START(111670182484),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1032788,
      "h": 111670182484,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670182484),
//--TRIMMABLE-BOUNDARY-START(64425542228),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1032788,
      "h": 64425542228,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425542228),
//--TRIMMABLE-BOUNDARY-START(25770836564),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1032788,
      "h": 25770836564,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770836564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180901972),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1032788,
      "h": 17180901972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180901972)
  ],
  "h": 1032788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkCheckOut`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkCheckOut`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032788)
        
        

        //--TRIMMABLE-BOUNDARY-START(1294932)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkLoading`, ($self) => class BuyLinkLoading extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476131412)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkloading";
            }
            //--TRIMMABLE-BOUNDARY-END(21476131412)
            
            //--TRIMMABLE-BOUNDARY-START(8591229524)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591229524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" style=\"margin: auto; background: rgba(255, 255, 255, 0); display: block; shape-rendering: auto;\" width=\"70px\" height=\"70px\" viewBox=\"0 0 100 100\" preserveAspectRatio=\"xMidYMid\"><g transform=\"translate(80,50)\"><g transform=\"rotate(0)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"1\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.875s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.875s\"></animate></circle></g></g>\r\n    <g transform=\"translate(71.21320343559643,71.21320343559643)\"><g transform=\"rotate(45)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.875\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.75s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.75s\"></animate></circle></g></g>\r\n    <g transform=\"translate(50,80)\"><g transform=\"rotate(90)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.75\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.625s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.625s\"></animate></circle></g></g>\r\n    <g transform=\"translate(28.786796564403577,71.21320343559643)\"><g transform=\"rotate(135)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.625\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.5s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.5s\"></animate></circle></g></g>\r\n    <g transform=\"translate(20,50.00000000000001)\"><g transform=\"rotate(180)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.5\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.375s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.375s\"></animate></circle></g></g>\r\n    <g transform=\"translate(28.78679656440357,28.786796564403577)\"><g transform=\"rotate(225)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.375\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.25s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.25s\"></animate></circle></g></g>\r\n    <g transform=\"translate(49.99999999999999,20)\"><g transform=\"rotate(270)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.25\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"-0.125s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"-0.125s\"></animate></circle></g></g>\r\n    <g transform=\"translate(71.21320343559643,28.78679656440357)\"><g transform=\"rotate(315)\"><circle cx=\"0\" cy=\"0\" r=\"6\" fill=\"#00aaee\" fill-opacity=\"0.125\"><animateTransform attributeName=\"transform\" type=\"scale\" begin=\"0s\" values=\"1.5 1.5;1 1\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\"></animateTransform>\r\n                <animate attributeName=\"fill-opacity\" keyTimes=\"0;1\" dur=\"1s\" repeatCount=\"indefinite\" values=\"1;0\" begin=\"0s\"></animate></circle></g></g></svg>");
            }
            //--TRIMMABLE-BOUNDARY-END(8591229524)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296262228)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296262228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296262228)
            
            //--TRIMMABLE-BOUNDARY-START(4296262228)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296262228)
            
            static $h = 1294932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476131412),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181164116,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1294932,
      "h": 21476131412,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476131412)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591229524),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1294932,
      "h": 8591229524,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591229524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296262228),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1294932,
      "h": 4296262228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296262228)
  ],
  "h": 1294932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkLoading`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkLoading`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1294932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1819220)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkTAndC`, ($self) => class BuyLinkTAndC extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591753812)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591753812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h3>BuyLink Terms and Conditions</h3>\r\n");
                __builder.AddMarkupContent(1, "<ul class=\"lh-2\"><li>\r\n        BuyLinks currently ship to just Nigeria from China.\r\n    </li>\r\n    <li>\r\n        That I, the user of BuyLink is responsible for the correctness \r\n        and originality of items whose links or images I post on BuyLink.\r\n    </li>\r\n    <li>\r\n        BuyLink, when given a link to an items, may not neccessarily purchase from the exact source, \r\n        but use its agents in China to buy the item from a trusted source, all while saving our users const on the purchase.\r\n    </li>\r\n    <li>\r\n        That BuyLink may decide, at its discretion, not to order some specific items that may breach some laws and standards.\r\n    </li>\r\n    <li>\r\n        That on notification of arrival of ordered items, \r\n        if I refuse to pay for shipment despite email remiders \r\n        within a month of arrival, the said items may be forfieted to BuyLink.\r\n    </li>\r\n    <li>\r\n        That BuyLink has the right to update this Terms and Conditions in the future, to which I agreed.\r\n    </li></ul>");
            }
            //--TRIMMABLE-BOUNDARY-END(8591753812)
            
            //--TRIMMABLE-BOUNDARY-START(21476655700)
            /*string */ get OptimizedComponentName()
            {
                return "buylinktandc";
            }
            //--TRIMMABLE-BOUNDARY-END(21476655700)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296786516)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296786516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296786516)
            
            //--TRIMMABLE-BOUNDARY-START(4296786516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296786516)
            
            static $h = 1819220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476655700),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181688404,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1819220,
      "h": 21476655700,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476655700)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591753812),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1819220,
      "h": 8591753812,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591753812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296786516),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1819220,
      "h": 4296786516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296786516)
  ],
  "h": 1819220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkTAndC`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkTAndC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1819220)
        
        

        //--TRIMMABLE-BOUNDARY-START(1884756)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkWhy`, ($self) => class BuyLinkWhy extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476721236)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkwhy";
            }
            //--TRIMMABLE-BOUNDARY-END(21476721236)
            
            //--TRIMMABLE-BOUNDARY-START(8591819348)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591819348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h2 class=\"text-center\">Why BuyLink?</h2>\r\n");
                __builder.OpenElement(1, "div");
                __builder.AddAttribute$5(2, "class", "mgl-10");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLines, 3);
                __builder.AddComponentParameter(4, "Style", "margin-left:-100%");
                __builder.AddAttribute$3(5, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 6);
                    __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(8, "<h4 class=\"mgt-0\">1.\uD83D\uDE32Because you love to buy the best of things online.</h4>");
                    }), $YxAXOe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1884756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(9, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 10);
                    __builder2.AddAttribute$3(11, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(12, "<h4 class=\"mgt-0\">2. And buying locally, you can only buy the limited available options.</h4>");
                    }), $tZGYrc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1884756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(13, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 14);
                    __builder2.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(16, "<h4 class=\"mgt-0\">3. And the things you buy locally are much more costly, as much as 100% of the prices online.</h4>");
                    }), $rnptXh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1884756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(17, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 18);
                    __builder2.AddAttribute$3(19, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(20, "<h4 class=\"mgt-0\">4. With BuyLink, you can buy it directly from the source, eliminating a lot of profit-making middle men.</h4>");
                    }), $dJEBfk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1884756,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $ywlixi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1884756,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8591819348)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296852052)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296852052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296852052)
            
            //--TRIMMABLE-BOUNDARY-START(4296852052)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296852052)
            
            static $h = 1884756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476721236),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181753940,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1884756,
      "h": 21476721236,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476721236)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591819348),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1884756,
      "h": 8591819348,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591819348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296852052),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1884756,
      "h": 4296852052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296852052)
  ],
  "h": 1884756
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkWhy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkWhy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1884756)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163860)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkHomeBanner`, ($self) => class BuyLinkHomeBanner extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34360902228)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkhomebanner";
            }
            //--TRIMMABLE-BOUNDARY-END(34360902228)
            
            //--TRIMMABLE-BOUNDARY-START(12886065748)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886065748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCS$1.CommunityBanners, 0);
                __builder.AddComponentParameter(1, "Tag", "BuyLink");
                __builder.AddAttribute$3(2, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$Iaui.LCFCM.ResourceModel)))))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(3, "div");
                        __builder2.AddAttribute$5(4, "class", "clip");
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<(LivingThing.Core.Frameworks.Common.Posts.Models.BannerPostModel, LivingThing.Core.Frameworks.Common.Models.ResourceModel), LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<(LivingThing.Core.Frameworks.Common.Posts.Models.BannerPostModel, LivingThing.Core.Frameworks.Common.Models.ResourceModel)>>>?*/ let __ca1__;
                        __builder2.AddAttribute$5(5, "style", /*((((__ca1__ = wrap.Models) != null ? __ca1__.Any(): false))||true) ?*/ `transition:height 0.5s linear;height:350px;${$.$strNN((this.Popping ? "height:0px" : ""))}`/* : ""*/);
                        __builder2.AddContent$1(6, wrap.View);
                        __builder2.CloseElement();
                    }, $rkZzJh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794});
                }), $JmCKlc ??= {"r":6881395,"p":[{"n":"wrap","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$Iaui.LCFCM.ResourceModel), $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.ValueTuple$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$Iaui.LCFCM.ResourceModel))).$h}],"n":"","d":1163860,"h":0,"f":17825794}));
                __builder.AddAttribute$3(7, "NoBanner", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(8, "<div class=\"icon-spin wx-17 hx-17 bg-primary-02 flex pos-rel mgx-a mgt bd round \"><div class=\"pos-abs t-0 l-0 r-0 b-0\"><div class=\"pos-rel wf hf\"><img class=\"hx-04 wx-04 pos-abs t-0 l-0\" src=\"_content/LivingThing.Core.Community.BuyLink.Client.Blazor/img/aliexpress.webp\">\r\n                    <img class=\"hx-04 wx-04 pos-abs t-0 r-0\" src=\"_content/LivingThing.Core.Community.BuyLink.Client.Blazor/img/alibaba.webp\">\r\n                    <img class=\"hx-04 wx-04 pos-abs b-0 l-0\" src=\"_content/LivingThing.Core.Community.BuyLink.Client.Blazor/img/ebay.webp\">\r\n                    <img class=\"hx-04 wx-04 pos-abs b-0 r-0\" src=\"_content/LivingThing.Core.Community.BuyLink.Client.Blazor/img/1688.webp\"></div></div>\r\n            <i class=\"mdi mdi-cart-heart fsz-70 mg-a flex mgc-a cl-primary\"></i></div>");
                }), $KPgMvf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794}));
                __builder.AddAttribute$3(9, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(10, "<p class=\"text-center fsz-20 mgt-10 mgb-0\">\r\n            Buy Anything Awesome Online\r\n        </p>\r\n        ");
                    __builder2.AddMarkupContent(11, "<h2 class=\"text-center mgt-1 mgb-0\">With just a LINK!</h2>\r\n        ");
                    __builder2.OpenElement(12, "div");
                    __builder2.AddAttribute$5(13, "class", "row mgt-5");
                    __builder2.OpenElement(14, "div");
                    __builder2.AddAttribute$5(15, "class", "col-5 bdr bd-primary");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 16);
                    __builder2.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(18, "Class", "wf");
                    __builder2.AddComponentParameter(19, "view-class", "bg-tertiary hf pd wf z-10 animated slideInUp");
                    __builder2.AddAttribute$3(20, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(21, "\r\n                        Why BuyLink?\r\n                    ");
                    }), $xFRoYe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(22, "View", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkWhy, 23);
                            __builder3.CloseComponent();
                        }, $uTIWIe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794});
                    }), $slCOOk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32).$h}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n            ");
                    __builder2.OpenElement(25, "div");
                    __builder2.AddAttribute$5(26, "class", "col-5 bdr bd-primary");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 27);
                    __builder2.AddComponentParameter(28, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(29, "Class", "wf");
                    __builder2.AddComponentParameter(30, "view-class", "bg-tertiary hf pd wf z-10 animated slideInUp");
                    __builder2.AddAttribute$3(31, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(32, "\r\n                        How it works?\r\n                    ");
                    }), $dACbWd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(33, "View", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkHowItWorks, 34);
                            __builder3.CloseComponent();
                        }, $cLiEDh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794});
                    }), $qYlgHa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32).$h}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(35, "\r\n            ");
                    __builder2.OpenElement(36, "div");
                    __builder2.AddAttribute$5(37, "class", "col-5");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 38);
                    __builder2.AddComponentParameter(39, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(40, "Class", "wf");
                    __builder2.AddComponentParameter(41, "view-class", "bg-tertiary hf pdy pdx-10 wf z-10 animated slideInUp");
                    __builder2.AddAttribute$3(42, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(43, "\r\n                        T & C\r\n                    ");
                    }), $RUeEGf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(44, "View", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkTAndC, 45);
                            __builder3.CloseComponent();
                        }, $nQODNc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794});
                    }), $BKJLhl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32).$h}],"n":"","d":1163860,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $sNmleh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1163860,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886065748)
            
            //--TRIMMABLE-BOUNDARY-START(38655869524)
            /*bool*/ Popping = false;
            //--TRIMMABLE-BOUNDARY-END(38655869524)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591098452)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591098452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591098452)
            
            //--TRIMMABLE-BOUNDARY-START(8591098452)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591098452)
            
            static $h = 1163860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360902228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476000340,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1163860,
      "h": 34360902228,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360902228),
//--TRIMMABLE-BOUNDARY-START(38655869524),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065934932,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245804116,
        "f": 83886081
      },
      "n": "Popping",
      "d": 1163860,
      "h": 38655869524,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655869524)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886065748),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1163860,
      "h": 12886065748,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886065748)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591098452),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1163860,
      "h": 8591098452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591098452)
  ],
  "h": 1163860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkHomeBanner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkHomeBanner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1229396)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkHowItWorks`, ($self) => class BuyLinkHowItWorks extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21476065876)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkhowitworks";
            }
            //--TRIMMABLE-BOUNDARY-END(21476065876)
            
            //--TRIMMABLE-BOUNDARY-START(8591163988)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591163988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h2 class=\"text-center\">Simple steps</h2>\r\n");
                __builder.AddMarkupContent(1, "<h3 class=\"text-center\">Awesome results</h3>\r\n");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mgl-10");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLines, 4);
                __builder.AddComponentParameter(5, "Style", "margin-left:-100%");
                __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 7);
                    __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(9, "<h4 class=\"mgt-0\">1.\uD83D\uDE32You see something awesome online.</h4>");
                    }), $rIxEae ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(10, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 11);
                    __builder2.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(13, "<h4 class=\"mgt-0\">2. You copy the link or download its image to BuyLink.</h4>");
                    }), $MvZgNj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(14, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 15);
                    __builder2.AddAttribute$3(16, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(17, "<h4 class=\"mgt-0\">3. BuyLink checks it out and give you a quote.</h4>");
                    }), $jSvslh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(18, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 19);
                    __builder2.AddAttribute$3(20, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(21, "<h4 class=\"mgt-0\">4. You pay BuyLink for the order.</h4>");
                    }), $bzSBOf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(22, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 23);
                    __builder2.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(25, "<h4 class=\"mgt-0\">5. BuyLink process your order.</h4>");
                    }), $TRbWYa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(26, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 27);
                    __builder2.AddAttribute$3(28, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(29, "<h4 class=\"mgt-0\">6. BuyLink notifies you of order shipment cost(in proportion to weight).</h4>");
                    }), $xKCZHd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(30, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 31);
                    __builder2.AddAttribute$3(32, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(33, "<h4 class=\"mgt-0\">7. BuyLink ships and tracks it to Nigeria, all the while keeping you updated of the progress.</h4>");
                    }), $bNgMFi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(34, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 35);
                    __builder2.AddAttribute$3(36, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(37, "<h4 class=\"mgt-0\">8. BuyLink notifies you of arrival.</h4>");
                    }), $mgUEvh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(38, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 39);
                    __builder2.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(41, "<h4 class=\"mgt-0\">9. You pay shipment cost and delivery on BuyLink App.</h4>");
                    }), $FvRqdc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(42, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$5.TimeLine, 43);
                    __builder2.AddAttribute$3(44, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddMarkupContent(45, "<h4 class=\"mgt-0\">10. BuyLink delivers\uD83D\uDE9A to your doorstep, something awesome.</h4>");
                    }), $TPWyrf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $ULnaTj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1229396,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8591163988)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296196692)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296196692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296196692)
            
            //--TRIMMABLE-BOUNDARY-START(4296196692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296196692)
            
            static $h = 1229396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476065876),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181098580,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1229396,
      "h": 21476065876,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476065876)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591163988),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1229396,
      "h": 8591163988,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591163988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296196692),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1229396,
      "h": 4296196692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296196692)
  ],
  "h": 1229396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkHowItWorks`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkHowItWorks`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1229396)
        
        

        //--TRIMMABLE-BOUNDARY-START(1491540)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkProduct<>`, (TProduct) => $asm.$gt(`$jfJD.LCCBCS$1.BuyLinkProduct<>`, [TProduct], ($self) => class BuyLinkProduct$$ extends $.$lJUR.LCFCS.ApplicationPageBase$$(TProduct)
        {
            //--TRIMMABLE-BOUNDARY-START(133145477716)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkproduct";
            }
            //--TRIMMABLE-BOUNDARY-END(133145477716)
            
            //--TRIMMABLE-BOUNDARY-START(210454889044)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454889044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Application":
                    this.Application = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(210454889044)
            
            //--TRIMMABLE-BOUNDARY-START(115965608532)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965608532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Chat = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IChatProvider, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
                this.Deployment = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityApplicationDeployment, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(115965608532)
            
            //--TRIMMABLE-BOUNDARY-START(38656197204)
            /*IChatProvider*/ Chat = null;
            //--TRIMMABLE-BOUNDARY-END(38656197204)
            
            //--TRIMMABLE-BOUNDARY-START(146030379604)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(146030379604)
            
            //--TRIMMABLE-BOUNDARY-START(51541099092)
            /*ICommunityApplicationDeployment*/ Deployment = null;
            //--TRIMMABLE-BOUNDARY-END(51541099092)
            
            //--TRIMMABLE-BOUNDARY-START(30066262612)
            /*Application?*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(30066262612)
            
            //--TRIMMABLE-BOUNDARY-START(197569987156)
            /*IPlatformShareManager?*/ ShareManager = null;
            //--TRIMMABLE-BOUNDARY-END(197569987156)
            
            //--TRIMMABLE-BOUNDARY-START(137440445012)
            /*CommunityBuyLinkPoolInteractionData*/ poolInfo = null;
            //--TRIMMABLE-BOUNDARY-END(137440445012)
            
            //--TRIMMABLE-BOUNDARY-START(128850510420)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850510420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ShareManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$fPer.LCFCP.IPlatformShareManager, this.ServiceProvider);
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(128850510420)
            
            //--TRIMMABLE-BOUNDARY-START(124555543124)
            /*WizardSteps?*/ joinPoolWizard = null;
            //--TRIMMABLE-BOUNDARY-END(124555543124)
            
            //--TRIMMABLE-BOUNDARY-START(141735412308)
            /*RemoteDataList<PostAccountInteractionModel>?*/ poolList = null;
            //--TRIMMABLE-BOUNDARY-END(141735412308)
            
            //--TRIMMABLE-BOUNDARY-START(55836066388)
            /*bool */ FilterPoolField(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836066388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Any($.$$.S.String, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Quantity", "UnitCost", "PoolStartDate", "PoolEndDate", "PaymentMode"], null, null), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                {
                    return descriptor.LCFCD$1$IPropertyDescriptor$Name === d;
                }, $yjJLkk ??= {"r":262145,"p":[{"n":"d","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55836066388)
            
            //--TRIMMABLE-BOUNDARY-START(120260575828)
            /*ValueTask *//*async*/  JoinPool()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260575828);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let pool = $.$cast($.$box(this.RequiredParameter, TProduct), $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel);
                    /*var*/ let queries = pool.Queries;
                    /*var*/ let answers = this.poolInfo.Answers;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.QueryPostModel>?*/ let __ca1__;
                    /*var*/ let allAnswered = ((__ca1__ = queries) !== null ? $.$sl.SL.Enumerable.All($.$LCOv.LCFCPM$1.QueryPostModel, __ca1__, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.QueryPostModel, $.$$.S.Boolean))().$ctor(this,  (/*q*/ q) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.IQueryAnswer>?*/ let __ca2__;
                        return ((__ca2__ = answers) !== null ? $.$sl.SL.Enumerable.Any($.$fPer.LCFCD.IQueryAnswer, __ca2__, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryAnswer, $.$$.S.Boolean))().$ctor(this,  (/**/ a) =>
                        {
                            return a.LCFCD$IQueryAnswer$QuestionId === $.$dspc(q.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString);
                        }, $mBjBXk ??= {"r":262145,"p":[{"n":"a","p":21662038}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : false);
                    }, $UlMFjh ??= {"r":262145,"p":[{"n":"q","p":22473140}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : true);
                    if (!allAnswered)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Some queries are not yet answered.");
                    }
                    if (pool.UnitCost.Value > 0 && pool.PaymentMode === 0/*CommunityBuyLinkPoolPaymentMode.PayBeforeJoin*/)
                    {
                        let $t2, $r2;
                        /*var*/ let paymentResult = ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(pool.UnitCost, this.RequiredParameter.Title, $.$hDPm.LCFCI.UIPaymentProcessorExtension.AsReferenceId$1(($.$strNN($.$strNN($.$dspc(this.RequiredParameter.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "__") + $.$strNN($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)))), this.RequiredParameter.Summary, `This buylink requires you to make its product payment(${$.$strNN(pool.UnitCost.ToString())}) before you can join its pool. Your payment is secured by BuyLink Escrow Service`, "buylink", null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.poolInfo.PaymentReference = paymentResult.Reference;
                    }
                    /*var*/ let interaction = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$LCOv.LCFCPMI.PostAccountInteractionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCPS$IPostInteractionRemoteService$AddCustomAccountInteraction(this.Parameter.Identifier, 4294967296n, $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, this.poolInfo, true, false, true, false, false, false, false, "JoinPool", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor\\BuyLinkProduct.razor.cs", "JoinPool", 98)));
                    }, $DUKbgg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h,"p":[{"n":"server","p":26536372}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    interaction.Account = this.Service.CommunityService.MainAccount;
                    ($t4 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Drawer.LCFCI$IUIClientDrawerService$Close(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = this.poolList.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPMI.PostAccountInteractionModel), [ interaction ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.poolInfo = new $.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData().$ctor$1();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120260575828)
            
            //--TRIMMABLE-BOUNDARY-START(193275019860)
            /*ValueTask */ Share()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275019860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShareManager.LCFCP$IPlatformShareManager$ShareAsync("Share BuyLink", null, new $.$spu.S.Uri().$ctor$5($.$fPer.LCFC.PathUtility.ToUrl("https", this.Deployment.LCCCS$ICommunityApplicationDeployment$Domain, $.$fPer.LCFC.Stringy.op_Implicit$1($.$hDPm.LCFC.UtilityExtensions.GetAppLink$1(this.RequiredParameter.Link, null)))));
            }
            //--TRIMMABLE-BOUNDARY-END(193275019860)
            
            //--TRIMMABLE-BOUNDARY-START(47246131796)
            /*ValueTask *//*async*/  DeleteProduct()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246131796);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete(TProduct, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TProduct), [ this.Parameter ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Page.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47246131796)
            
            //--TRIMMABLE-BOUNDARY-START(42951164500)
            /*ValueTask */ CloneToCart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951164500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let clone = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(TProduct, this.RequiredParameter, true, false, true, false, false, false, false, "CloneToCart", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor\\BuyLinkProduct.razor.cs", "CloneToCart", 118), false, "CloneToCart", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor\\BuyLinkProduct.razor.cs", "CloneToCart", 118);
                clone.Identifier = new $.$fPer.LCFCD.DataId().$ctor$2();
                clone.QueryState = 0/*PostQueryableState.Submitted*/;
                clone.Quantity = 1;
                clone.UnitCost = new $.$fPer.LCFCDM.Money().$ctor$2();
                clone.Account = null;
                return this.Service.AddToCart($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ clone ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42951164500)
            
            //--TRIMMABLE-BOUNDARY-START(201864954452)
            /*ValueTask *//*async*/  StartProcessing()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864954452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let product = $.$cast($.$box(this.RequiredParameter, TProduct), $.$RffN.LCCBCM.CommunityBuyLinkProductModel);
                    /*var*/ let clone = $.$LCOv.LCFCP.PostUtility.Clone($.$RffN.LCCBCM.CommunityBuyLinkProductModel, product);
                    clone.QueryState = 5120/*PostQueryableState.Processing*/;
                    ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ clone ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    product.QueryState = 5120/*PostQueryableState.Processing*/;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864954452)
            
            //--TRIMMABLE-BOUNDARY-START(206159921748)
            /*ValueTask *//*async*/  SupplyWeight(/*Weight*/ weight)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159921748);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Weight, $.$fPer.LCFCDM.WeightUnitTypes, weight))
                    {
                        /*var*/ let product = $.$cast($.$box(this.RequiredParameter, TProduct), $.$RffN.LCCBCM.CommunityBuyLinkProductModel);
                        /*var*/ let w = product.Weight;
                        /*var*/ let s = product.QueryState;
                        product.Weight = $.$clone(weight);
                        product.QueryState = 6144/*PostQueryableState.Weighed*/;
                        try
                        {
                            let $t9, $r9;
                            ($t9 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ product ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        catch($e)
                        {
                            product.Weight = $.$clone(w);
                            product.QueryState = s;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206159921748)
            
            //--TRIMMABLE-BOUNDARY-START(34361229908)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361229908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hasAdminRight = this.Service.CommunityService.UserAuthenticationTicket.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/ ], null, null));
                /*var*/ let product = $.$as(this.Parameter, $.$RffN.LCCBCM.CommunityBuyLinkProductModel);
                /*var*/ let pool = $.$as(this.Parameter, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel);
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pos-rel");
                __builder.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductBanner, 2);
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this.Parameter));
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n    ");
                __builder.AddContent$1(5, $.$jfJD.LCCBCS$1.BuyLinkProductSummary$$(TProduct).PriceTag(this.Parameter, this.Service));
                __builder.CloseElement();
                __builder.AddMarkupContent(6, "\r\n");
                __builder.OpenElement(7, "div");
                __builder.AddAttribute$5(8, "class", "pd");
                __builder.OpenElement(9, "h3");
                __builder.AddAttribute$5(10, "class", "mgt-0");
                __builder.AddContent$4(11, this.Parameter.Title);
                __builder.CloseElement();
                __builder.AddMarkupContent(12, "\r\n    ");
                __builder.OpenElement(13, "p");
                __builder.AddContent$4(14, this.Parameter.Summary ?? "_");
                __builder.AddMarkupContent(15, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 16);
                __builder.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                __builder.AddComponentParameter(18, "Class", "f-right text-underline");
                __builder.AddComponentParameter(19, "view-class", "bg-tertiary z-10 animated slideInUp");
                __builder.AddAttribute$3(20, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(21, "\r\n                View Source\r\n            ");
                }), $iVKymf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.AddAttribute$3(22, "View", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32)))().$ctor(this, ( (/*clicked*/ clicked) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(23, "iframe");
                        __builder2.AddAttribute$5(24, "style", "width:100%;height:100%");
                        __builder2.AddAttribute$5(25, "src", this.Parameter.Url);
                        __builder2.SetKey($.$box(clicked.Model, $.$$.S.Int32));
                        __builder2.CloseElement();
                    }, $bfiFmb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }), $obOKUi ??= {"r":6881395,"p":[{"n":"clicked","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(26, "\r\n    ");
                __builder.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 27);
                __builder.AddComponentParameter(28, "Tag", "p");
                __builder.AddComponentParameter(29, "EditableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCE.EditableFeatures, 54/*EditableFeatures.Default*/ | 4/*EditableFeatures.Inline*/ | 1/*EditableFeatures.ServerUpdate*/), $.$hDPm.LCFCCE.EditableFeatures));
                __builder.AddComponentParameter(30, "PlaceHolder", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, hasAdminRight ? "Add Notes" : ""));
                __builder.AddComponentParameter(31, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), hasAdminRight), $.$$.S.Boolean));
                __builder.AddComponentParameter(32, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Parameter.Post));
                __builder.AddComponentParameter(33, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.Parameter.Post = __value;
                }, $CnKPkf ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.Parameter.Post))));
                __builder.AddComponentParameter(34, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Parameter"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $bFOjec ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                __builder.CloseComponent();
                if (pool !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPMI.PostAccountInteractionModel), 35);
                    __builder.AddComponentParameter(36, "Class", "pooluser");
                    __builder.AddComponentParameter(37, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box($.$cast(4294967296n, $.$LCOv.LCFCPM$1.PostInteractionType), $.$LCOv.LCFCPM$1.PostInteractionType) ], null, null))));
                    __builder.AddComponentParameter(38, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, (35184372092928n & ~524288n) | 65536n | 70368744177664n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddAttribute$3(39, "CustomRenderer", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel))))().$ctor(this, ( (/*render*/ render) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            if (render.Data !== null && pool.Quantity > 0)
                            {
                                /*var*/ let pooled = $.$sl.SL.Enumerable.Sum$17($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), render.Data, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), $.$$.S.Int32))().$ctor(this,  (/*d*/ d) =>
                                {
                                    return (d.Data.Data?.GetCustomInteractionDataAs($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, 4294967296n)?.Quantity ?? null) ?? 0;
                                }, $yAjBQc ??= {"r":655361,"p":[{"n":"d","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder2.OpenElement(40, "div");
                                __builder2.AddAttribute$5(41, "class", "mgt");
                                __builder2.AddContent$3(42, $.$box(pooled, $.$$.S.Int32));
                                __builder2.AddContent$4(43, " pooled of ");
                                __builder2.AddContent$3(44, $.$box(pool.Quantity, $.$$.S.Int32));
                                __builder2.AddContent$4(45, " (");
                                __builder2.AddContent$3(46, $.$box($.trunc(((pooled * 100) | 0) / pool.Quantity), $.$$.S.Int32));
                                __builder2.AddContent$4(47, "%)");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(48, "\r\n                    ");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 49);
                                __builder2.AddComponentParameter(50, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.trunc(((pooled * 100) | 0) / pool.Quantity)), $.$$.S.Int32));
                                __builder2.AddComponentParameter(51, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder2.AddComponentParameter(52, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                __builder2.AddComponentParameter(53, "Class", "corner-2 clip mgb");
                                __builder2.CloseComponent();
                                if (pool.Queries !== null)
                                {
                                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 54);
                                    __builder2.AddAttribute$3(55, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                        {
                                            /*var*/ let stats = $.$fPer.LCFCD.QuestionAnswerExtension.BuildStatistics($.$$.N.InterfaceVarianceStubHandler.Create(pool.Queries, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQuery)), $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), $.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, render.Data, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), $.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData))().$ctor(this,  (/*d*/ d) =>
                                            {
                                                return d.Data.Data.GetCustomInteractionDataAs($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, 4294967296n);
                                            }, $aBxUnb ??= {"r":1199471,"p":[{"n":"d","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryAnswers)));
                                            __builder3.OpenComponent$1($.$hDPm.LCFCCC$2.Carousel, 56);
                                            __builder3.AddAttribute$3(57, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize)))().$ctor(this, ( (/*_*/ _0) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                                {
                                                    let $en10 = pool.Queries.SCG$IEnumerable$$$GetEnumerator();
                                                    while ($en10.SC$1$IEnumerator$MoveNext())
                                                    {
                                                        let q = $en10.SCG$IEnumerator$$$Current;
                                                        {
                                                            /*var*/ let stat = stats.get_Item(q);
                                                            /*int*/ let i = 0;
                                                            __builder4.OpenElement(58, "div");
                                                            __builder4.AddAttribute$5(59, "class", "wx-25 bdr mgr");
                                                            __builder4.OpenElement(60, "h3");
                                                            __builder4.AddAttribute$5(61, "class", "text-center");
                                                            __builder4.AddContent$4(62, q.Question);
                                                            __builder4.CloseElement();
                                                            __builder4.AddMarkupContent(63, "\r\n                                        ");
                                                            __builder4.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), 64);
                                                            __builder4.AddComponentParameter(65, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 2/*ChartType.Pie*/), $.$hDPm.LCFCCC$3.ChartType));
                                                            __builder4.AddComponentParameter(66, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), stat.AnswerCounts));
                                                            __builder4.AddComponentParameter(67, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                                                            {
                                                                return e.Key;
                                                            }), $MHgXfc ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                            __builder4.AddComponentParameter(68, "FontColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, theme.Data.TextBackgroundColor));
                                                            __builder4.AddComponentParameter(69, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                                                            __builder4.AddAttribute$3(70, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)))))().$ctor(this, ( (/*context*/ context) =>
                                                            {
                                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                                {
                                                                    let $en11 = stat.AnswerCounts.GetEnumerator();
                                                                    while ($en11.MoveNext())
                                                                    {
                                                                        let ans = $en11.Current;
                                                                        {
                                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), 71);
                                                                            __builder5.AddComponentParameter(72, "Label", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, ans.Key));
                                                                            __builder5.AddComponentParameter(73, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this, ( (/**/ e) =>
                                                                            {
                                                                                return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Value, $.$$.S.Int32);
                                                                            }), $Ijqwtd ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                                            __builder5.AddComponentParameter(74, "BorderColor", "transparent");
                                                                            __builder5.AddComponentParameter(75, "BackgroundColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), theme.Data.ChartColors));
                                                                            __builder5.SetKey(ans.Key);
                                                                            __builder5.CloseComponent();
                                                                            i++;
                                                                        }
                                                                    }
                                                                }, $dQGKWa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                            }), $xdOvDk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                            __builder4.SetKey(q);
                                                            __builder4.CloseComponent();
                                                            __builder4.CloseElement();
                                                        }
                                                    }
                                                }, $AkZEkl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                            }), $COXKfj ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder3.CloseComponent();
                                        }, $eKIkyb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                    }), $FZVnik ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder2.CloseComponent();
                                }
                            }
                            __builder2.AddMarkupContent(76, "<h3>Subscribers</h3>\r\n                ");
                            __builder2.AddContent$1(77, render.DefaultRenderer.Invoke(render.DataList, render.Data, null));
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Frameworks.Common.Posts.Models.Interactions.PostAccountInteractionModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Frameworks.Common.Posts.Models.Interactions.PostAccountInteractionModel>>>?*/ let __ca1__;
                            /*var*/ let hasJoined = ((__ca1__ = render.Data) !== null ? $.$sl.SL.Enumerable.Any($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), __ca1__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)), $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.Data.Account.Equals$1(this.Service.CommunityService.Account);
                            }, $rURzWj ??= {"r":262145,"p":[{"n":"d","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) : true);
                            if (this.Service.CommunityService.Account.Identifier.HasValue)
                            {
                                __builder2.OpenElement(78, "img");
                                __builder2.AddAttribute$5(79, "class", "d-block mgx-a mawx-3");
                                __builder2.AddAttribute$5(80, "src", this.ResolvePath$1("img/people.png", $.$ahDc.LCCC._Imports.$type.Assembly, true));
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(81, "\r\n                    ");
                                __builder2.AddMarkupContent(82, "<h4 class=\"text-center\">BuyLink Pool joins product orders from many people together, purchasing in bulk save everybody money.</h4>\r\n                    ");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 83);
                                __builder2.AddComponentParameter(84, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                __builder2.AddComponentParameter(85, "Class", "d-block mgx-a");
                                __builder2.AddAttribute$3(86, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddMarkupContent(87, "\r\n                            JOIN THIS POOL\r\n                        ");
                                }), $GZZcLd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(88, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*___*/ ___) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCW$1.WizardSteps, 89);
                                        __builder3.AddComponentParameter(90, "InitialViewIndex", "0");
                                        __builder3.AddComponentParameter(91, "WizardFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCW$1.WizardFeatures, 3/*WizardFeatures.Default*/ & ~3/*WizardFeatures.Controls*/), $.$hDPm.LCFCCW$1.WizardFeatures));
                                        __builder3.AddAttribute$3(92, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 93);
                                            __builder4.AddComponentParameter(94, "Class", "pd");
                                            __builder4.AddAttribute$3(95, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*step*/ step) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.AddMarkupContent(96, "<h3 class=\"mgt-0\">Join Pool</h3>\r\n                                    ");
                                                    __builder5.AddMarkupContent(97, "<p>If you have already joined this pool, this operation wil update your current pool quantity.</p>\r\n                                    ");
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData), 98);
                                                    __builder5.AddComponentParameter(99, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, $.$$.STT.ValueTask))().$ctor(this,  (/*v*/ v) =>
                                                    {
                                                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.QueryPostModel>?*/ let __ca2__;
                                                        return (((__ca2__ = pool.Queries) !== null ? $.$sl.SL.Enumerable.Any$1($.$LCOv.LCFCPM$1.QueryPostModel, __ca2__) : false)) ? this.joinPoolWizard.NextView() : this.JoinPool();
                                                    }, $NSbvga ??= {"r":181338113,"p":[{"n":"v","p":1199471}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                                                    __builder5.AddComponentParameter(100, "sidebar-bar-class", "text-right");
                                                    __builder5.AddComponentParameter(101, "EditorFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, (4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/) | 8/*InputEditorFeatures.Highlight*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                                                    __builder5.AddComponentParameter(102, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfPrimary(0.1)));
                                                    __builder5.AddComponentParameter(103, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, this.poolInfo));
                                                    __builder5.AddComponentParameter(104, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData), $.$mac.MAC.EventCallback.Factory.Create$6($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, this, new ($.$$.S.Action$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData))().$ctor(this,  (/*__value*/ __value) =>
                                                    {
                                                        return this.poolInfo = __value;
                                                    }, $iWEnMg ??= {"r":65537,"p":[{"n":"__value","p":1199471}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), this.poolInfo))));
                                                    __builder5.AddComponentParameter(105, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                                    {
                                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "poolInfo"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                                    }, $kJAABh ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                                                    __builder5.AddAttribute$3(106, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                    {
                                                        __builder6.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 107);
                                                        __builder6.AddComponentParameter(108, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                        __builder6.AddComponentParameter(109, "Class", "d-block mgt mgl-a");
                                                        __builder6.AddComponentParameter(110, "type", "submit");
                                                        __builder6.AddAttribute$3(111, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                        {
                                                            __builder7.AddContent$4(112, "Continue");
                                                        }), $yCeeMe ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                        __builder6.CloseComponent();
                                                    }), $nwSfqg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                }, $ZZSBhe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                            }), $bUIYuh ??= {"r":6881395,"p":[{"n":"step","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.QueryPostModel>?*/ let __ca3__;
                                            if ((__ca3__ = pool.Queries) !== null ? $.$sl.SL.Enumerable.Any$1($.$LCOv.LCFCPM$1.QueryPostModel, __ca3__) : false)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCW$1.WizardStep, 113);
                                                __builder4.AddAttribute$3(114, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*step*/ step) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder5) =>
                                                    {
                                                        __builder5.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$LCOv.LCFCPM$1.QueryPostModel), 115);
                                                        __builder5.AddComponentParameter(116, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, pool));
                                                        __builder5.AddComponentParameter(117, "AnswerStore", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.IQueryAnswers, this.poolInfo));
                                                        __builder5.AddComponentParameter(118, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                        __builder5.AddComponentParameter(119, "SubmitButtonText", "Finish");
                                                        __builder5.AddComponentParameter(120, "OnAnswerSubmitted", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$hDPm.LCFCC$1.ComponentExtension.Create($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.JoinPool))));
                                                        __builder5.AddComponentParameter(121, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSQ.CommunityPostQueriesFeatures, 0/*CommunityPostQueriesFeatures.Default*/ | 2/*CommunityPostQueriesFeatures.AnswerQueries*/), $.$ahDc.LCCCSQ.CommunityPostQueriesFeatures));
                                                        __builder5.CloseComponent();
                                                    }, $WLaqYh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $pSLxxe ??= {"r":6881395,"p":[{"n":"step","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                        }), $VZCwwk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder3.AddComponentReferenceCapture(122, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            this.joinPoolWizard = $.$cast(__value, $.$hDPm.LCFCCW$1.WizardSteps);
                                        }, $rnAnRc ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }, $atClig ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                }), $uoKQhh ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                        }, $KNNubk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $NSFmqg ??= {"r":6881395,"p":[{"n":"render","p":$.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(123, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel))))().$ctor(this, ( (/*joinUser*/ joinUser) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            /*var*/ let dat = joinUser.Data.Data.GetCustomInteractionDataAs($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, 4294967296n);
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 124);
                            __builder2.AddComponentParameter(125, "Class", "hx-05 wx-05 round bg-card bd");
                            __builder2.AddComponentParameter(126, "title", joinUser.Data.Account.Title);
                            __builder2.AddComponentParameter(127, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), false), $.$$.S.Boolean));
                            __builder2.AddComponentParameter(128, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, joinUser.Data.Account));
                            __builder2.AddComponentParameter(129, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 50), $.$$.S.Int32));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(130, "\r\n                ");
                            __builder2.OpenElement(131, "span");
                            __builder2.AddAttribute$5(132, "class", "label text-center d-block");
                            __builder2.AddContent$4(133, joinUser.Data.Account.Title);
                            if (dat !== null)
                            {
                                __builder2.AddContent$4(134, "(");
                                __builder2.AddContent$3(135, $.$box(dat.Quantity, $.$$.S.Int32));
                                __builder2.AddContent$4(136, ")");
                            }
                            __builder2.CloseElement();
                        }, $ScTTfk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $PkyPRb ??= {"r":6881395,"p":[{"n":"joinUser","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(137, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel))))().$ctor(this, ( (/*joinUser*/ joinUser) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountDetailsInApplicationDrawer, 138);
                            __builder2.AddComponentParameter(139, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, joinUser.Data.Account));
                            __builder2.AddAttribute$3(140, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.QueryPostModel>?*/ let __ca4__;
                                if (hasAdminRight && (((__ca4__ = pool.Queries) !== null ? $.$sl.SL.Enumerable.Any$1($.$LCOv.LCFCPM$1.QueryPostModel, __ca4__) : false)))
                                {
                                    __builder3.AddMarkupContent(141, "<h3>Query Answers</h3>\r\n                        ");
                                    __builder3.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$LCOv.LCFCPM$1.QueryPostModel), 142);
                                    __builder3.AddComponentParameter(143, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, pool));
                                    __builder3.AddComponentParameter(144, "AnswerStore", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.IQueryAnswers, joinUser.Data.Data.GetCustomInteractionDataAs($.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData, 4294967296n)));
                                    __builder3.AddComponentParameter(145, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                    __builder3.AddComponentParameter(146, "TQueryable", "CommunityBuyLinkProductPoolModel");
                                    __builder3.AddComponentParameter(147, "OnAnswerSubmitted", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$hDPm.LCFCC$1.ComponentExtension.Create($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.JoinPool))));
                                    __builder3.AddComponentParameter(148, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSQ.CommunityPostQueriesFeatures, 0/*CommunityPostQueriesFeatures.Default*/), $.$ahDc.LCCCSQ.CommunityPostQueriesFeatures));
                                    __builder3.CloseComponent();
                                }
                            }), $WdAUyk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $LRygmf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                    }), $XYBNyj ??= {"r":6881395,"p":[{"n":"joinUser","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPMI.PostAccountInteractionModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPMI.PostAccountInteractionModel)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.AddComponentReferenceCapture(149, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.poolList = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPMI.PostAccountInteractionModel));
                    }, $vHzoRk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(150, "\r\n");
                __builder.OpenElement(151, "div");
                __builder.AddAttribute$5(152, "class", "mgt-a");
                __builder.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductToolBar, 153);
                __builder.AddComponentParameter(154, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this.Parameter));
                __builder.AddComponentParameter(155, "Class", "mgt pdx");
                __builder.AddComponentParameter(156, "tabs-class", "bdt");
                __builder.AddComponentParameter(157, "-tabs-head-menuitem-class", "mgt-a");
                __builder.AddAttribute$3(158, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(159, "<li class=\"menuitem fill\"></li>");
                    if (product !== null)
                    {
                        if (hasAdminRight || this.Service.CommunityService.Account.Equals$1(this.Parameter.Account))
                        {
                            __builder2.OpenElement(160, "li");
                            __builder2.AddAttribute$5(161, "class", "menuitem");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 162);
                            __builder2.AddComponentParameter(163, "title", "Processings");
                            __builder2.AddComponentParameter(164, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 512/*ButtonFeatures.Medium*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(165, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "mdi mdi-progress-pencil pos-rel"));
                            __builder2.AddAttribute$3(166, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                if (product.QueryState === 1024/*PostQueryableState.Queried*/ || product.IsWaitingForPayment)
                                {
                                    __builder3.AddMarkupContent(167, "<sub class=\"bg-info d-block round fsz-small pos-abs t-0 r-0 mg-1\" style=\"height:12px;width:12px\">!</sub>");
                                }
                            }), $ZpFrWk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(168, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCA.Accordion, 169);
                                    __builder3.AddComponentParameter(170, "Exclusive", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder3.AddAttribute$3(171, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 172);
                                        __builder4.AddComponentParameter(173, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 1), $.$$.S.Int32));
                                        __builder4.AddComponentParameter(174, "Class", "bdb");
                                        __builder4.AddComponentParameter(175, "header-class", "clickable");
                                        __builder4.AddAttribute$3(176, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*opened*/ opened) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenElement(177, "div");
                                                __builder5.AddAttribute$5(178, "class", "row pd");
                                                __builder5.AddMarkupContent(179, "<div class=\"col-10\"><b>Queries</b></div>\r\n                                            ");
                                                __builder5.OpenElement(180, "div");
                                                __builder5.AddAttribute$5(181, "class", "col-a");
                                                __builder5.OpenElement(182, "i");
                                                __builder5.AddAttribute$5(183, "class", $.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(opened) ? "up" : "down")));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                            }, $cRiCvc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                        }), $xFuJTc ??= {"r":6881395,"p":[{"n":"opened","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder4.AddAttribute$3(184, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.QueryPostModel), 185);
                                                __builder5.AddComponentParameter(186, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                __builder5.AddComponentParameter(187, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, product));
                                                __builder5.AddComponentParameter(188, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSQ.CommunityPostQueriesFeatures, 0/*CommunityPostQueriesFeatures.Default*/ | (this.Service.CommunityService.Account.Equals$1(this.Parameter.Account) ? 2/*CommunityPostQueriesFeatures.AnswerQueries*/ : 0/*CommunityPostQueriesFeatures.None*/) | ((!$.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, product.UnitCost) && hasAdminRight && product.QueryState < 4096/*PostQueryableState.Paid*/) ? 1/*CommunityPostQueriesFeatures.AddQueries*/ : 0/*CommunityPostQueriesFeatures.None*/)), $.$ahDc.LCCCSQ.CommunityPostQueriesFeatures));
                                                __builder5.CloseComponent();
                                            }, $jMXJjg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                        }), $FLpqRd ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                        if (hasAdminRight)
                                        {
                                            if (product.QueryState === 0/*PostQueryableState.Submitted*/ || product.QueryState === 2048/*PostQueryableState.QueryAnswered*/ || product.QueryState === 3072/*PostQueryableState.AwaitingPayment*/)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 189);
                                                __builder4.AddComponentParameter(190, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                                                __builder4.AddComponentParameter(191, "Class", "bdb");
                                                __builder4.AddComponentParameter(192, "header-class", "clickable");
                                                __builder4.AddAttribute$3(193, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*opened*/ opened) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(194, "div");
                                                        __builder5.AddAttribute$5(195, "class", "row pd");
                                                        __builder5.AddMarkupContent(196, "<div class=\"col-10\"><b>Price Offer</b></div>\r\n                                                    ");
                                                        __builder5.OpenElement(197, "div");
                                                        __builder5.AddAttribute$5(198, "class", "col-a");
                                                        __builder5.OpenElement(199, "i");
                                                        __builder5.AddAttribute$5(200, "class", $.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(opened) ? "up" : "down")));
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                    }, $nUYVgd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $WtiEee ??= {"r":6881395,"p":[{"n":"opened","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.AddAttribute$3(201, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(202, "div");
                                                        __builder5.AddAttribute$5(203, "class", "mg");
                                                        __builder5.OpenComponent$1($.$ahDc.LCCCSP$1.CommunityPriceOfferings$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 204);
                                                        __builder5.AddComponentParameter(205, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, product));
                                                        __builder5.AddComponentParameter(206, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                        __builder5.AddComponentParameter(207, "OnPriceOffered", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$LCOv.LCFCPMP.PriceOfferingPostModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$LCOv.LCFCPMP.PriceOfferingPostModel, this, new ($.$$.S.Action$$($.$LCOv.LCFCPMP.PriceOfferingPostModel))().$ctor(this,  (/*o*/ o) =>
                                                        {
                                                        }, $Bktabe ??= {"r":65537,"p":[{"n":"o","p":21817780}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                                                        __builder5.AddComponentParameter(208, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                                        __builder5.CloseComponent();
                                                        __builder5.CloseElement();
                                                    }, $qXdXNe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $qzXiid ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                            if (product.QueryState === 4096/*PostQueryableState.Paid*/)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 209);
                                                __builder4.AddComponentParameter(210, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 3), $.$$.S.Int32));
                                                __builder4.AddComponentParameter(211, "content-class", "bdb");
                                                __builder4.AddComponentParameter(212, "header-class", "clickable bdb");
                                                __builder4.AddAttribute$3(213, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*opened*/ opened) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(214, "div");
                                                        __builder5.AddAttribute$5(215, "class", "row pd");
                                                        __builder5.AddMarkupContent(216, "<div class=\"col-10\"><b>Start Processing</b></div>\r\n                                                    ");
                                                        __builder5.OpenElement(217, "div");
                                                        __builder5.AddAttribute$5(218, "class", "col-a");
                                                        __builder5.OpenElement(219, "i");
                                                        __builder5.AddAttribute$5(220, "class", $.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(opened) ? "up" : "down")));
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                    }, $IAWrpc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $iDAwAb ??= {"r":6881395,"p":[{"n":"opened","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.AddAttribute$3(221, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(222, "div");
                                                        __builder5.AddAttribute$5(223, "class", "mg");
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 224);
                                                        __builder5.AddComponentParameter(225, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                        __builder5.AddComponentParameter(226, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.StartProcessing))));
                                                        __builder5.AddComponentParameter(227, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 8192/*ButtonFeatures.LoadingOnClick*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                                        __builder5.AddComponentParameter(228, "Class", "wf d-block");
                                                        __builder5.AddAttribute$3(229, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(230, "\r\n                                                        Start Processing\r\n                                                    ");
                                                        }), $AoZpEe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                        __builder5.CloseComponent();
                                                        __builder5.CloseElement();
                                                    }, $Zuqvpe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $aXGTik ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                            else if (product.QueryState === 5120/*PostQueryableState.Processing*/)
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCA.AccordionTab, 231);
                                                __builder4.AddComponentParameter(232, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 4), $.$$.S.Int32));
                                                __builder4.AddComponentParameter(233, "content-class", "bdb");
                                                __builder4.AddComponentParameter(234, "header-class", "clickable bdb");
                                                __builder4.AddAttribute$3(235, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*opened*/ opened) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenElement(236, "div");
                                                        __builder5.AddAttribute$5(237, "class", "row pd");
                                                        __builder5.AddMarkupContent(238, "<div class=\"col-10\"><b>Set Weight</b></div>\r\n                                                    ");
                                                        __builder5.OpenElement(239, "div");
                                                        __builder5.AddAttribute$5(240, "class", "col-a");
                                                        __builder5.OpenElement(241, "i");
                                                        __builder5.AddAttribute$5(242, "class", $.$strNN("mdi" + " mdi-chevron-") + $.$strNN(($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(opened) ? "up" : "down")));
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                        __builder5.CloseElement();
                                                    }, $nsjpvf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $zNmosk ??= {"r":6881395,"p":[{"n":"opened","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.AddAttribute$3(243, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$fPer.LCFCDM.Weight), 244);
                                                        __builder5.AddComponentParameter(245, "Class", "mg");
                                                        __builder5.AddComponentParameter(246, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCDM.Weight), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$fPer.LCFCDM.Weight, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$fPer.LCFCDM.Weight, $.$$.STT.ValueTask))().$ctor(this, this.SupplyWeight))));
                                                        __builder5.AddAttribute$3(247, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 248);
                                                            __builder6.AddComponentParameter(249, "type", "submit");
                                                            __builder6.AddComponentParameter(250, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                                            __builder6.AddComponentParameter(251, "Class", "wf d-block");
                                                            __builder6.AddAttribute$3(252, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                            {
                                                                __builder7.AddMarkupContent(253, "\r\n                                                            Set Weight\r\n                                                        ");
                                                            }), $bduYyk ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                            __builder6.CloseComponent();
                                                        }), $COnjJc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                        __builder5.CloseComponent();
                                                    }, $FHEhGb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                                                }), $BCQYCd ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }
                                        }
                                    }), $BjrZzb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $rYapMb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $eVBucc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                        if (this.Service.CommunityService.Account.Equals$1(this.Parameter.Account))
                        {
                            __builder2.OpenElement(254, "li");
                            __builder2.AddAttribute$5(255, "class", "menuitem");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 256);
                            __builder2.AddComponentParameter(257, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 512/*ButtonFeatures.Medium*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(258, "title", "Chats");
                            __builder2.AddComponentParameter(259, "Class", "menuitem mdi mdi-message");
                            __builder2.AddComponentParameter(260, "view-class", "pos-abs t-0 l-0 r-0 b-0 bg-tertiary text-left z-10 animated slideInUp");
                            __builder2.AddAttribute$3(261, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*clicked*/ clicked) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddContent$1(262, this.Chat.LCFCI$IChatProvider$GetChatThread($.$fPer.LCFCD.DataId.op_Implicit$1($.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Parameter.Identifier, this.Service.CommunityService.Account.Identifier ], null, null))), this.Parameter.Title, new $.$fPer.LCFCD.DataId(), null, 0, null));
                                }, $tOzIJf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $kiaOya ??= {"r":6881395,"p":[{"n":"clicked","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                    }
                    else if (pool !== null)
                    {
                        if (this.Service.CommunityService.Account.Equals$1(pool.Account))
                        {
                            __builder2.OpenElement(263, "li");
                            __builder2.AddAttribute$5(264, "class", "menuitem");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 265);
                            __builder2.AddComponentParameter(266, "title", "Settings");
                            __builder2.AddComponentParameter(267, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 512/*ButtonFeatures.Medium*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(268, "Class", "mdi mdi-cogs");
                            __builder2.AddComponentParameter(269, "drawer-class", "pd");
                            __builder2.AddAttribute$3(270, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*___*/ ___) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    $.$jfJD._LCCBCSB$1.TypeInference.CreateFormBuilder_0($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, __builder3, 271, 272, pool, 273, $.$fPer.LCFC.Theme.OfPrimary(0.1), 274, new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor(this, this.FilterPoolField), 275, 0/*FormBuilderFeatures.Default*/ | 2/*FormBuilderFeatures.ServerUpdate*/, 276, "pdt", 277, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 278);
                                        __builder4.AddComponentParameter(279, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                        __builder4.AddComponentParameter(280, "Class", "miwx-1");
                                        __builder4.AddComponentParameter(281, "type", "submit");
                                        __builder4.AddAttribute$3(282, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(283, "Save");
                                        }), $mgBbpf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                    }, $mDkcTh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                }, $MHjlsj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $TGxElb ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(284, "\r\n                ");
                            __builder2.OpenElement(285, "li");
                            __builder2.AddAttribute$5(286, "class", "menuitem");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 287);
                            __builder2.AddComponentParameter(288, "title", "Queries");
                            __builder2.AddComponentParameter(289, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 512/*ButtonFeatures.Medium*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(290, "Class", "mdi mdi-help");
                            __builder2.AddAttribute$3(291, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*___*/ ___) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$LCOv.LCFCPM$1.QueryPostModel), 292);
                                    __builder3.AddComponentParameter(293, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, pool));
                                    __builder3.AddComponentParameter(294, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                    __builder3.AddComponentParameter(295, "TQueryable", "CommunityBuyLinkProductPoolModel");
                                    __builder3.AddComponentParameter(296, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSQ.CommunityPostQueriesFeatures, 0/*CommunityPostQueriesFeatures.Default*/ | 1/*CommunityPostQueriesFeatures.AddQueries*/), $.$ahDc.LCCCSQ.CommunityPostQueriesFeatures));
                                    __builder3.CloseComponent();
                                }, $RKtKLa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                            }), $AfFsel ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                    }
                    if (product !== null)
                    {
                        __builder2.OpenElement(297, "li");
                        __builder2.AddAttribute$5(298, "class", "menuitem");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 299);
                        __builder2.AddComponentParameter(300, "title", "Clone To Cart");
                        __builder2.AddComponentParameter(301, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.CloneToCart))));
                        __builder2.AddComponentParameter(302, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 512/*ButtonFeatures.Medium*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(303, "SuccessMessage", "Product Added to Cart!!!");
                        __builder2.AddComponentParameter(304, "Class", "menuitem mdi mdi-cart");
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                }), $RdUokg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                if (this.Parameter.Identifier.HasValue)
                {
                    __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityRelatedPosts$$(TProduct), 305);
                    __builder.AddComponentParameter(306, "ViewModel", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck(TProduct, this.Parameter), TProduct));
                    __builder.AddComponentParameter(307, "Title", "Similar BuyLinks");
                    __builder.AddComponentParameter(308, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741858/*PostFilterTypes.Related*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361229908)
            
            //--TRIMMABLE-BOUNDARY-START(111670641236)
            /*RenderFragment */ GetToolBarControls(/*ContainerContext<IApplicationPageContext>*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670641236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    if (this.ShareManager !== null)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 309);
                        __builder2.AddComponentParameter(310, "Class", "mdi mdi-share");
                        __builder2.AddComponentParameter(311, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$hDPm.LCFCC$1.ComponentExtension.Create($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Share))));
                        __builder2.AddComponentParameter(312, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 33554432/*MenuFeatures.SwallowException*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.CloseComponent();
                    }
                    let product;
                    if (this.Parameter.Identifier.HasValue && $.$is(this.Parameter, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, { set $v($v){ product = $v; } }) && this.Service.CommunityService.Account.Equals$1(this.Parameter.Account) && product.QueryState < 4096/*PostQueryableState.Paid*/)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 313);
                        __builder2.AddComponentParameter(314, "Class", "mdi mdi-delete cl-error");
                        __builder2.AddComponentParameter(315, "Confirm", "Delete Product");
                        __builder2.AddComponentParameter(316, "ConfirmMessage", "This will remove this product from its order?");
                        __builder2.AddComponentParameter(317, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$hDPm.LCFCC$1.ComponentExtension.Create($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.DeleteProduct))));
                        __builder2.AddComponentParameter(318, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 33554432/*MenuFeatures.SwallowException*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.CloseComponent();
                    }
                }, $yFoOjg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(111670641236)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25771295316)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771295316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771295316)
            
            //--TRIMMABLE-BOUNDARY-START(25771295316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(25771295316)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38656197204)
                this.Chat = null;
                //--TRIMMABLE-BOUNDARY-END(38656197204)
                
                //--TRIMMABLE-BOUNDARY-START(146030379604)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(146030379604)
                
                //--TRIMMABLE-BOUNDARY-START(51541099092)
                this.Deployment = null;
                //--TRIMMABLE-BOUNDARY-END(51541099092)
                
                //--TRIMMABLE-BOUNDARY-START(137440445012)
                this.poolInfo = new $.$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(137440445012)
                
            }
            static $H = 1491540;
            static $h = 1491540;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$(TProduct); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145477716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90195804756,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 133145477716,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145477716),
//--TRIMMABLE-BOUNDARY-START(38656197204),
    {
      "p": 63526570,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73015935572,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 163210248788,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 83886081
      },
      "n": "Chat",
      "d": this.$h,
      "H": 38656197204,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656197204),
//--TRIMMABLE-BOUNDARY-START(146030379604),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98785739348,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 180390117972,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 146030379604,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146030379604),
//--TRIMMABLE-BOUNDARY-START(51541099092),
    {
      "p": 17012160,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81605870164,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 171800183380,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 83886081
      },
      "n": "Deployment",
      "d": this.$h,
      "H": 51541099092,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541099092),
//--TRIMMABLE-BOUNDARY-START(30066262612),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64426000980,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 154620314196,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 83886081
      },
      "n": "Application",
      "d": this.$h,
      "H": 30066262612,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066262612),
//--TRIMMABLE-BOUNDARY-START(197569987156),
    {
      "p": 53643606,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107375673940,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 188980052564,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 83886081
      },
      "n": "ShareManager",
      "d": this.$h,
      "H": 197569987156,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569987156)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(210454889044),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 210454889044,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210454889044),
//--TRIMMABLE-BOUNDARY-START(115965608532),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 115965608532,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965608532),
//--TRIMMABLE-BOUNDARY-START(128850510420),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": this.$h,
      "H": 128850510420,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(128850510420),
//--TRIMMABLE-BOUNDARY-START(55836066388),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "descriptor",
          "p": 40733014
        }
      ],
      "n": "FilterPoolField",
      "d": this.$h,
      "H": 55836066388,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836066388),
//--TRIMMABLE-BOUNDARY-START(120260575828),
    {
      "r": 181338113,
      "n": "JoinPool",
      "d": this.$h,
      "H": 120260575828,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(120260575828),
//--TRIMMABLE-BOUNDARY-START(193275019860),
    {
      "r": 181338113,
      "n": "Share",
      "d": this.$h,
      "H": 193275019860,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193275019860),
//--TRIMMABLE-BOUNDARY-START(47246131796),
    {
      "r": 181338113,
      "n": "DeleteProduct",
      "d": this.$h,
      "H": 47246131796,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47246131796),
//--TRIMMABLE-BOUNDARY-START(42951164500),
    {
      "r": 181338113,
      "n": "CloneToCart",
      "d": this.$h,
      "H": 42951164500,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951164500),
//--TRIMMABLE-BOUNDARY-START(201864954452),
    {
      "r": 181338113,
      "n": "StartProcessing",
      "d": this.$h,
      "H": 201864954452,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(201864954452),
//--TRIMMABLE-BOUNDARY-START(206159921748),
    {
      "r": 181338113,
      "p": [
        {
          "n": "weight",
          "p": 29985110
        }
      ],
      "n": "SupplyWeight",
      "d": this.$h,
      "H": 206159921748,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(206159921748),
//--TRIMMABLE-BOUNDARY-START(34361229908),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 34361229908,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361229908),
//--TRIMMABLE-BOUNDARY-START(111670641236),
    {
      "r": 6881395,
      "p": [
        {
          "n": "context",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext).$h
        }
      ],
      "n": "GetToolBarControls",
      "d": this.$h,
      "H": 111670641236,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111670641236)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(137440445012),
    {
      "t": 1199471,
      "n": "poolInfo",
      "d": this.$h,
      "H": 137440445012,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137440445012),
//--TRIMMABLE-BOUNDARY-START(124555543124),
    {
      "t": 59004586,
      "n": "joinPoolWizard",
      "d": this.$h,
      "H": 124555543124,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555543124),
//--TRIMMABLE-BOUNDARY-START(141735412308),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPMI.PostAccountInteractionModel).$h,
      "n": "poolList",
      "d": this.$h,
      "H": 141735412308,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141735412308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771295316),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 25771295316,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771295316)
  ],
  "s": [
    {
      "h": TProduct?.$h??1572864,
      "n": "TProduct",
      "c": [1527151
      ]
    }
  ],
  "r": 1,
  "H": 1491540,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProduct<${TProduct?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProduct$${TProduct?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1491540)
        
        

        //--TRIMMABLE-BOUNDARY-START(1753684)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkSupplierFilter`, ($self) => class BuyLinkSupplierFilter extends $.$lJUR.LCFCS.ApplicationPageBase
        {
            //--TRIMMABLE-BOUNDARY-START(12886655572)
            /*KeyValuePair<string, DataFilter>*/ currentFilter;
            //--TRIMMABLE-BOUNDARY-END(12886655572)
            
            //--TRIMMABLE-BOUNDARY-START(25771557460)
            /*string */ get OptimizedComponentName()
            {
                return "buylinksupplierfilter";
            }
            //--TRIMMABLE-BOUNDARY-END(25771557460)
            
            //--TRIMMABLE-BOUNDARY-START(8591688276)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591688276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "ApplicationPageConfigureToolBar");
                __builder.OpenElement(1, "Controls");
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 2);
                __builder.AddComponentParameter(3, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)), 5);
                        __builder2.AddComponentParameter(6, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.InputType, 21n), $.$fPer.LCFC.InputType));
                        __builder2.AddComponentParameter(7, "Class", "miwx-15");
                        __builder2.AddComponentParameter(8, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.OfPrimary(0.1)));
                        __builder2.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                        __builder2.AddComponentParameter(10, "Options", ($.$fPer.LCFCD.Paging.GetPager($.$fPer.LCFC.ISelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)), $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter), $.$fPer.LCFC.ISelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)), $.$RffN.LCCBCS.ServiceFilters.Products, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter), $.$fPer.LCFC.ISelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter))))().$ctor(this,  (/**/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFC.SelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter))()
                                const $t1 = $.$fPer.LCFC.SelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter));
                                const $i1 = new $t1();
                                $i1.$ctor$3(p);
                                $i1.Title = p.Key;
                                return $i1;
                            })();
                        }, $IBlOPb ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)).$h,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter).$h}],"n":"","d":1753684,"h":0,"f":17825794})), null)));
                        __builder2.AddComponentParameter(11, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter), this.currentFilter));
                        __builder2.AddComponentParameter(12, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter), this, new ($.$$.S.Action$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.currentFilter = __value;
                        }, $IpTAzb ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter).$h}],"n":"","d":1753684,"h":0,"f":17825794}), this.currentFilter))));
                        __builder2.AddComponentParameter(13, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter))), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "currentFilter"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $JNboTb ??= {"r":38797349,"n":"","d":1753684,"h":0,"f":17825794})).Invoke())));
                        __builder2.CloseComponent();
                    }, $gZsQRd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1753684,"h":0,"f":17825794});
                }), $NgXyTk ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":1753684,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(14, "\r\n\r\n");
                __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 15);
                __builder.AddComponentParameter(16, "PostsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSP.CommunityPostsFeatures, 0/*CommunityPostsFeatures.Default*/), $.$ahDc.LCCCSP.CommunityPostsFeatures));
                __builder.AddComponentParameter(17, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.currentFilter.Value));
                __builder.AddComponentParameter(18, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 52776558178304n & ~17592186044416n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(19, "CardWidthHint", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 250), $.$$.S.Int32));
                __builder.AddComponentParameter(20, "CardSpaceHint", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 20), $.$$.S.Int32));
                __builder.SetKey(this.currentFilter.Key);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8591688276)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296720980)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296720980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296720980)
            
            //--TRIMMABLE-BOUNDARY-START(4296720980)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296720980)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886655572)
                this.currentFilter = $.$default($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter));
                //--TRIMMABLE-BOUNDARY-END(12886655572)
                
            }
            static $h = 1753684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771557460),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476590164,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1753684,
      "h": 25771557460,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771557460)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591688276),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1753684,
      "h": 8591688276,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591688276)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886655572),
    {
      "t": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter).$h,
      "n": "currentFilter",
      "d": 1753684,
      "h": 12886655572,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886655572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296720980),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1753684,
      "h": 4296720980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296720980)
  ],
  "h": 1753684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkSupplierFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkSupplierFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1753684)
        
        

        //--TRIMMABLE-BOUNDARY-START(1622612)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkProductSummary<>`, (TProduct) => $asm.$gt(`$jfJD.LCCBCS$1.BuyLinkProductSummary<>`, [TProduct], ($self) => class BuyLinkProductSummary$$ extends $.$hDPm.LCFCC$1.BaseParameterizedContainer$$(TProduct)
        {
            //--TRIMMABLE-BOUNDARY-START(64426132052)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(64426132052)
            
            //--TRIMMABLE-BOUNDARY-START(21476459092)
            /*IContainerContext<CommunityBuyLinkProductBaseModel>*/ ContainerContext = null;
            //--TRIMMABLE-BOUNDARY-END(21476459092)
            
            //--TRIMMABLE-BOUNDARY-START(55836197460)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkproductsummary";
            }
            //--TRIMMABLE-BOUNDARY-END(55836197460)
            
            //--TRIMMABLE-BOUNDARY-START(85900968532)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900968532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ContainerContext":
                    this.ContainerContext = $.$cast(parameter.Value, $.$hDPm.LCFCI.IContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(85900968532)
            
            //--TRIMMABLE-BOUNDARY-START(51541230164)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541230164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(51541230164)
            
            //--TRIMMABLE-BOUNDARY-START(17181491796)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181491796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isInCarousel = (this.ContainerContext?.LCFCI$IContainerContext$HasAttribute($.$ahDc.LCCCSP.CommunityCardIntent, new ($.$$.S.Func$$$($.$ahDc.LCCCSP.CommunityCardIntent, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return c === 2/*CommunityCardIntent.Related*/;
                }, $vXpVWc ??= {"r":262145,"p":[{"n":"c","p":29595072}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) ?? null) ?? false;
                /*var*/ let hasAdminRight = this.Service.CommunityService.UserAuthenticationTicket.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/ ], null, null));
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", $.$strNN($.$strNN($.$strNN("container" + " d-block") + " clip") + " ") + $.$strNN((isInCarousel ? "wx-25" : "")));
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "row responsive");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", $.$strNN($.$strNN("col-4" + " miwx-2") + $.$strNN((!isInCarousel ? " mihx-25" : ""))) + " pos-rel");
                __builder.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductBanner, 6);
                __builder.AddComponentParameter(7, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this.ViewModel));
                __builder.AddComponentParameter(8, "Mini", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, isInCarousel), $.$$.S.Boolean));
                __builder.CloseComponent();
                __builder.AddMarkupContent(9, "\r\n                ");
                __builder.AddContent$1(10, $.$jfJD.LCCBCS$1.BuyLinkProductSummary$$(TProduct).PriceTag(this.ViewModel, this.Service));
                __builder.CloseElement();
                __builder.AddMarkupContent(11, "\r\n            ");
                __builder.OpenElement(12, "div");
                __builder.AddAttribute$5(13, "Class", "col-6 d-block");
                __builder.OpenElement(14, "div");
                __builder.AddAttribute$5(15, "class", "pdx");
                __builder.OpenElement(16, "h4");
                __builder.AddAttribute$5(17, "class", "mg-0");
                __builder.AddContent$4(18, this.ViewModel.Title);
                __builder.CloseElement();
                if (!isInCarousel)
                {
                    __builder.OpenElement(19, "p");
                    __builder.AddContent$4(20, this.ViewModel.Description);
                    if (this.ViewModel.SiteName !== null)
                    {
                        __builder.OpenElement(21, "em");
                        __builder.AddAttribute$5(22, "class", "f-right");
                        __builder.AddContent$4(23, "- ");
                        __builder.AddContent$4(24, this.ViewModel.SiteName);
                        __builder.CloseElement();
                    }
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                if (((this.ContainerContext?.LCFCI$IContainerContext$HasAttribute($.$ahDc.LCCCSP.CommunityCardIntent, new ($.$$.S.Func$$$($.$ahDc.LCCCSP.CommunityCardIntent, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return c === 1/*CommunityCardIntent.Major*/ || c === 0/*CommunityCardIntent.None*/;
                }, $wJlLKk ??= {"r":262145,"p":[{"n":"c","p":29595072}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})) ?? null) ?? false) && (this.ViewModel.Identifier.Empty || this.Service.CommunityService.Account.Equals$1(this.ViewModel.Account)))
                {
                    __builder.OpenElement(25, "div");
                    __builder.AddAttribute$5(26, "class", "mgt-a");
                    __builder.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductToolBar, 27);
                    __builder.AddComponentParameter(28, "Class", "mgt pdt pdx bdt");
                    __builder.AddComponentParameter(29, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this.ViewModel));
                    __builder.AddComponentParameter(30, "ToolBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSP.CommunityToolBarFeatures, -2147483137/*CommunityToolBarFeatures.Default*/ & ~-2147483648/*CommunityToolBarFeatures.Pad*/ & ~32/*CommunityToolBarFeatures.AddOn*/), $.$ahDc.LCCCSP.CommunityToolBarFeatures));
                    __builder.AddAttribute$3(31, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(32, "<li class=\"menuitem fill\"></li>\r\n                ");
                        __builder2.AddContent$1(33, this.ChildContent);
                    }), $AOfwhl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181491796)
            
            //--TRIMMABLE-BOUNDARY-START(60131164756)
            static /*RenderFragment */ PriceTag(/*TProduct*/ product, /*CommunityBuyLinkService*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131164756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hasAdminRight = service.CommunityService.UserAuthenticationTicket.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/ ], null, null));
                if ((service.CommunityService.Account.Equals$1(product.Account) || hasAdminRight) && ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, product.UnitCost) || product.Type === 5123/*PostTypes.BuyLinkProductPool*/))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(34, "div");
                        __builder2.AddAttribute$5(35, "class", "pos-abs b-0 r-0 bg-error-07 cl-white pd flex mgb-10");
                        __builder2.OpenElement(36, "div");
                        __builder2.AddAttribute$5(37, "class", "stack text-center mg-a");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCE.Editable$$($.$fPer.LCFCDM.Money), 1);
                        __builder2.AddAttribute$5(2, "Tag", "h2");
                        __builder2.AddAttribute$4(3, "Value", product.UnitCost);
                        __builder2.AddAttribute$7($.$fPer.LCFCDM.Money, 4, "ValueChanged", $.$mac.MAC.EventCallback.Factory.Create$8($.$fPer.LCFCDM.Money, $.$box(product, TProduct), new ($.$$.S.Action$$($.$fPer.LCFCDM.Money))().$ctor(this,  (/*v*/ v) =>
                        {
                            return product.UnitCost = $.$clone(v);
                        }, $jehWmc ??= {"r":65537,"p":[{"n":"v","p":27822422}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        __builder2.AddAttribute$4(5, "ValueExpression", (((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1($.$box(product, TProduct)), "UnitCost"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $XAikdc ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                        __builder2.AddAttribute$2(6, "Enable", hasAdminRight && product.Type === 5123/*PostTypes.BuyLinkProductPool*/);
                        __builder2.AddAttribute$5(7, "Class", "mg-0");
                        __builder2.AddAttribute$4(8, "EditableFeatures", $.$box(54/*EditableFeatures.Default*/ | 8/*EditableFeatures.Block*/ | 1/*EditableFeatures.ServerUpdate*/, $.$hDPm.LCFCCE.EditableFeatures));
                        __builder2.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$fPer.LCFCDM.Money))().$ctor(this, ( (/**/ m) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*b*/ b) =>
                            {
                                return b.AddContent$4(1, `${$.$strNN(($.$fPer.LCFCDM.Money.op_Multiply(product.UnitCost.Naira, (1 + (service.GlobalSettings.PercentageCommision / 100)))).ToString$1(1/*MoneyFormat.Scientific*/))}/qty`);
                            }, $BKHoOj ??= {"r":65537,"p":[{"n":"b","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $YYwjgk ??= {"r":6881395,"p":[{"n":"m","p":27822422}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.OpenComponent$1($.$hDPm.LCFCCE.Editable$$($.$$.S.Int32), 121);
                        __builder2.AddAttribute$5(122, "Tag", "small");
                        __builder2.AddAttribute$4(123, "Value", $.$box(product.Quantity, $.$$.S.Int32));
                        __builder2.AddAttribute$7($.$$.S.Int32, 124, "ValueChanged", $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.Int32, $.$box(product, TProduct), new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*v*/ v) =>
                        {
                            return product.Quantity = v;
                        }, $vukzVb ??= {"r":65537,"p":[{"n":"v","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                        __builder2.AddAttribute$4(125, "ValueExpression", (((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1($.$box(product, TProduct)), "Quantity"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $wwswYd ??= {"r":38797349,"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke())));
                        __builder2.AddAttribute$2(126, "Enable", hasAdminRight && product.Type === 5123/*PostTypes.BuyLinkProductPool*/);
                        __builder2.AddAttribute$4(127, "EditableFeatures", $.$box(54/*EditableFeatures.Default*/ | 8/*EditableFeatures.Block*/ | 1/*EditableFeatures.ServerUpdate*/, $.$hDPm.LCFCCE.EditableFeatures));
                        __builder2.AddAttribute$3(128, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$$.S.Int32))().$ctor(this, ( (/*m*/ m) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*b*/ b) =>
                            {
                                return b.AddContent$4(1, `${$.$strNN(product.Quantity)} ${$.$strNN((hasAdminRight && product.Type === 5123/*PostTypes.BuyLinkProductPool*/ ? "Pools" : "/qty"))}`);
                            }, $RvghVk ??= {"r":65537,"p":[{"n":"b","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                        }), $clnWGb ??= {"r":6881395,"p":[{"n":"m","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $jvRLnk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60131164756)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886524500)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886524500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886524500)
            
            //--TRIMMABLE-BOUNDARY-START(12886524500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12886524500)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64426132052)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(64426132052)
                
            }
            static $H = 1622612;
            static $h = 1622612;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedContainer$$(TProduct); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426132052),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246262868,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81606001236,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886081
      },
      "n": "Service",
      "d": this.$h,
      "H": 64426132052,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426132052),
//--TRIMMABLE-BOUNDARY-START(21476459092),
    {
      "p": $.$hDPm.LCFCI.IContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066393684,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73016066644,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886081
      },
      "n": "ContainerContext",
      "d": this.$h,
      "H": 21476459092,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476459092),
//--TRIMMABLE-BOUNDARY-START(55836197460),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656328276,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": this.$h,
      "H": 55836197460,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836197460)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900968532),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": this.$h,
      "H": 85900968532,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900968532),
//--TRIMMABLE-BOUNDARY-START(51541230164),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": this.$h,
      "H": 51541230164,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541230164),
//--TRIMMABLE-BOUNDARY-START(17181491796),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": this.$h,
      "H": 17181491796,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181491796),
//--TRIMMABLE-BOUNDARY-START(60131164756),
    {
      "r": 6881395,
      "p": [
        {
          "n": "product",
          "p": TProduct?.$h??1572864
        },
        {
          "n": "service",
          "p": 901716
        }
      ],
      "n": "PriceTag",
      "d": this.$h,
      "H": 60131164756,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131164756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886524500),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12886524500,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886524500)
  ],
  "s": [
    {
      "h": TProduct?.$h??1572864,
      "n": "TProduct",
      "c": [1527151
      ]
    }
  ],
  "r": 1,
  "H": 1622612,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProductSummary<${TProduct?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProductSummary$${TProduct?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1622612)
        
        

        //--TRIMMABLE-BOUNDARY-START(705108)
        $asm.$cls(`$jfJD.LCCBCS.CommunityBuyLinkProductFeedProvider`, ($self) => class CommunityBuyLinkProductFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295672404)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295672404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295672404)
            
            //--TRIMMABLE-BOUNDARY-START(8590639700)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityBuyLinkProductModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590639700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`wants to BuyLink ${$.$strNN($.$$.S.String.Substring.call(model.Title, 0, $.$$.S.Math.Min$4(32, model.Title.length)))}`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590639700)
            
            static $h = 705108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590639700),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 1789295
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 705108,
      "h": 8590639700,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590639700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295672404),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 705108,
      "h": 4295672404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295672404)
  ],
  "h": 705108
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.CommunityBuyLinkProductFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}CommunityBuyLinkProductFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(705108)
        
        

        //--TRIMMABLE-BOUNDARY-START(1360468)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkOrder`, ($self) => class BuyLinkOrder extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)
        {
            //--TRIMMABLE-BOUNDARY-START(25771164244)
            /*IChatProvider*/ Chat = null;
            //--TRIMMABLE-BOUNDARY-END(25771164244)
            
            //--TRIMMABLE-BOUNDARY-START(81605739092)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81605739092)
            
            //--TRIMMABLE-BOUNDARY-START(111670510164)
            /*IUIService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(111670510164)
            
            //--TRIMMABLE-BOUNDARY-START(30066131540)
            /*Task *//*async*/  DeleteOrder()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066131540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Delete($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ this.RequiredParameter ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.UI.LCFCC$IUIService$Page.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30066131540)
            
            //--TRIMMABLE-BOUNDARY-START(68720837204)
            /*Task *//*async*/  Hold()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720837204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let state = this.RequiredParameter.QueryState;
                    this.RequiredParameter.QueryState = 8192/*PostQueryableState.ShipmentCostNotAcceptable*/;
                    try
                    {
                        let $t3, $r3;
                        ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ this.RequiredParameter ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    catch($e)
                    {
                        this.RequiredParameter.QueryState = state;
                        throw $e;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720837204)
            
            //--TRIMMABLE-BOUNDARY-START(77310771796)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkorder";
            }
            //--TRIMMABLE-BOUNDARY-END(77310771796)
            
            //--TRIMMABLE-BOUNDARY-START(73015804500)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015804500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Chat = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IChatProvider, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015804500)
            
            //--TRIMMABLE-BOUNDARY-START(21476196948)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476196948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hasAdminRight = this.Service.CommunityService.UserAuthenticationTicket.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/ ], null, null));
                __builder.OpenElement(0, "ApplicationPageConfigureToolBarT");
                __builder.AddAttribute$5(1, "T", "CommunityBuyLinkOrderModel");
                __builder.OpenElement(2, "Controls");
                if (this.Service.CommunityService.Account.Equals$1(this.Parameter.Account) && this.Parameter.QueryState < 4096/*PostQueryableState.Paid*/)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 3);
                    __builder.AddComponentParameter(4, "Class", "mdi mdi-delete cl-error");
                    __builder.AddComponentParameter(5, "Confirm", "Delete Order");
                    __builder.AddComponentParameter(6, "ConfirmMessage", "Order will be deleted along wiith all products in it?");
                    __builder.AddComponentParameter(7, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$4(this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.DeleteOrder))));
                    __builder.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, 1575140/*MenuFeatures.Default*/ | 33554432/*MenuFeatures.SwallowException*/), $.$hDPm.LCFCCM$4.MenuFeatures));
                    __builder.CloseComponent();
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 10);
                __builder.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(12, "PageSize", "int.MaxValue");
                __builder.AddComponentParameter(13, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddComponentParameter(14, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.Parameter.Products));
                __builder.AddAttribute$3(15, "CustomRenderer", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*products*/ products) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>>>?*/ let __ca1__;
                        /*var*/ let ps = ((__ca1__ = products.Data) !== null ? $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca1__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$RffN.LCCBCM.CommunityBuyLinkProductModel))().$ctor(this,  (/**/ p) =>
                        {
                            return p.Model;
                        }, $mSIzZj ??= {"r":1789295,"p":[{"n":"p","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1360468,"h":0,"f":17825794})) : null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>*/ let __ca2__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca3__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>*/ let __ca4__;
                        this.Parameter.Children = ((__ca2__ = (((__ca3__ = this.Parameter.Children) !== null ? (((__ca4__ = $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostAssociationModel, __ca3__, $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, ps, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/**/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t4 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.Association = p;
                                return $i4;
                            })();
                        }, $JPUmFk ??= {"r":15919540,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794})))) !== null ? ($.$sl.SL.Enumerable.Distinct$1($.$LCOv.LCFCPM$1.PostAssociationModel, __ca4__) ?? $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, ps, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/*p*/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t5 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i5 = new $t5();
                                $i5.$ctor$1();
                                $i5.Association = p;
                                return $i5;
                            })();
                        }, $pFQhMf ??= {"r":15919540,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794}))) : $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, ps, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/*p*/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t6 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i6 = new $t6();
                                $i6.$ctor$1();
                                $i6.Association = p;
                                return $i6;
                            })();
                        }, $fRokbg ??= {"r":15919540,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794}))) ?? $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, ps, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/**/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t7 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i7 = new $t7();
                                $i7.$ctor$1();
                                $i7.Association = p;
                                return $i7;
                            })();
                        }, $Wnqnrc ??= {"r":15919540,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794}))) : $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, ps, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/*p*/ p) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t8 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i8 = new $t8();
                                $i8.$ctor$1();
                                $i8.Association = p;
                                return $i8;
                            })();
                        }, $MSFCNc ??= {"r":15919540,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794}))))) !== null ? $.$sl.SL.Enumerable.ToList($.$LCOv.LCFCPM$1.PostAssociationModel, __ca2__) : null);
                        __builder2.OpenElement(16, "div");
                        __builder2.AddAttribute$5(17, "class", "pos-rel");
                        __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkOrderBanner, 18);
                        __builder2.AddComponentParameter(19, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Parameter));
                        __builder2.CloseComponent();
                        if (this.Service.CommunityService.Account.Equals$1(this.Parameter.Account) && this.Parameter.Amount.Value > 0)
                        {
                            __builder2.OpenElement(20, "div");
                            __builder2.AddAttribute$5(21, "class", "pos-abs b-0 r-0 bg-error-07 cl-white pd flex mgb-25");
                            __builder2.OpenElement(22, "div");
                            __builder2.AddAttribute$5(23, "class", "stack text-center mg-a");
                            __builder2.OpenElement(24, "h2");
                            __builder2.AddAttribute$5(25, "class", "mg-0");
                            __builder2.AddContent$4(26, ($.$fPer.LCFCDM.Money.op_Multiply(this.Parameter.Amount, (1 + (this.Service.GlobalSettings.PercentageCommision / 100)))).ToString$1(1/*MoneyFormat.Scientific*/));
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(27, "\r\n                        ");
                            __builder2.OpenElement(28, "small");
                            __builder2.AddContent$3(29, $.$box($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Parameter.Products), $.$$.S.Int32));
                            __builder2.AddContent$4(30, " buylinks");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(31, "\r\n        ");
                        __builder2.OpenElement(32, "div");
                        __builder2.AddAttribute$5(33, "class", "pd");
                        __builder2.OpenElement(34, "small");
                        __builder2.AddContent$3(35, this.Parameter.DateCreated);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(36, "\r\n            ");
                        __builder2.OpenElement(37, "h2");
                        __builder2.AddAttribute$5(38, "class", "mg-0");
                        __builder2.AddContent$4(39, this.Parameter.Title);
                        __builder2.CloseElement();
                        if (!$.$$.S.String.IsNullOrEmpty(this.Parameter.Description))
                        {
                            __builder2.OpenElement(40, "p");
                            __builder2.AddContent$4(41, this.Parameter.Description);
                            __builder2.CloseElement();
                        }
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>*/ let __ca5__;
                        if (this.Parameter.Account.Equals$1(this.Service.CommunityService.Account) && this.Parameter.QueryState === 3072/*PostQueryableState.AwaitingPayment*/ && (((__ca5__ = this.Parameter.Products) !== null ? $.$sl.SL.Enumerable.All($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca5__, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.UnitCost.Value > 0;
                        }, $jzBUok ??= {"r":262145,"p":[{"n":"p","p":1789295}],"n":"","d":1360468,"h":0,"f":17825794})) : false)))
                        {
                            __builder2.OpenElement(42, "div");
                            __builder2.AddAttribute$5(43, "class", "pd bg-primary-01 bdl bdw-5 bd-primary");
                            __builder2.OpenElement(44, "b");
                            __builder2.AddContent$4(45, "\"");
                            __builder2.AddContent$4(46, this.Parameter.Title);
                            __builder2.AddContent$4(47, "\"");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(48, " is ready and waiting for your payment\r\n                ");
                            __builder2.CloseElement();
                        }
                        else if (this.Parameter.QueryState === 6144/*PostQueryableState.Weighed*/)
                        {
                            __builder2.OpenElement(49, "div");
                            __builder2.AddAttribute$5(50, "class", "pd bg-primary-01 bdl bdw-5 bd-primary");
                            __builder2.AddMarkupContent(51, "\r\n                    This order weigh ");
                            __builder2.OpenElement(52, "b");
                            __builder2.AddContent$4(53, "\"");
                            __builder2.AddContent$3(54, this.Parameter.Weight);
                            __builder2.AddContent$4(55, "\"");
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(56, " and will cost about\r\n                    ");
                            __builder2.OpenElement(57, "b");
                            if (this.Parameter.FreightShipment === 1/*BuyLinkOrderShipmentType.Express*/)
                            {
                                __builder2.AddContent$3(58, $.$fPer.LCFCDM.Money.op_Multiply(this.Service.GlobalSettings.ExpressShipmentRatePerKg, this.Parameter.Weight.Kg));
                            }
                            else if (this.Parameter.FreightShipment === 2/*BuyLinkOrderShipmentType.Cargo*/)
                            {
                                __builder2.AddContent$3(59, $.$fPer.LCFCDM.Money.op_Multiply(this.Service.GlobalSettings.CargoShipmentRatePerKg, this.Parameter.Weight.Kg));
                            }
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(60, " for international shipment.\r\n                    If you have any reservation about this cost, you can put the order on hold, while we discuss the way forward with you.\r\n                    If however this is not done on time, we will assume you are ok with this shipment cost and proceed with shipment.\r\n                    ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 61);
                            __builder2.AddComponentParameter(62, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.AddComponentParameter(63, "Class", "f-right text-underline");
                            __builder2.AddComponentParameter(64, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Hold))));
                            __builder2.AddAttribute$3(65, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(66, "Put on hold");
                            }), $mzaGRd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }
                        else 
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>>>?*/ let __ca6__;
                            if (this.Parameter.QueryState < 3072/*PostQueryableState.AwaitingPayment*/ && (((__ca6__ = products.Data) !== null ? $.$sl.SL.Enumerable.All($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), __ca6__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.Data.QueryState === 3072/*PostQueryableState.AwaitingPayment*/;
                            }, $djLHYk ??= {"r":262145,"p":[{"n":"d","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1360468,"h":0,"f":17825794})) : false)))
                            {
                                this.Parameter.QueryState = 3072/*PostQueryableState.AwaitingPayment*/;
                            }
                            __builder2.OpenElement(67, "div");
                            __builder2.AddAttribute$5(68, "class", "pd bg-info-01 bdl bdw-5 bd-info");
                            __builder2.AddMarkupContent(69, "\r\n                    Order State: ");
                            __builder2.OpenElement(70, "b");
                            __builder2.AddContent$4(71, "\"");
                            __builder2.AddContent$4(72, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$LCOv.LCFCP.PostQueryableState, $.$$.S.UInt32, this.Parameter.QueryState)));
                            __builder2.AddContent$4(73, "\"");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(74, "\r\n        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 75);
                        __builder2.AddComponentParameter(76, "InitialViewIndex", "0");
                        __builder2.AddComponentParameter(77, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(78, "tabs-head-class", "bg-card");
                        __builder2.AddComponentParameter(79, "TabsFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$1.TabsFeatures, 65/*TabsFeatures.Default*/ | 128/*TabsFeatures.ButtonTabs*/), $.$hDPm.LCFCCT$1.TabsFeatures));
                        __builder2.AddAttribute$3(80, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 81);
                            __builder3.AddAttribute$3(82, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*t*/ t) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 83);
                                    __builder4.AddComponentParameter(84, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, t.Model.Selected ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.OfPrimary(0.5)));
                                    __builder4.AddComponentParameter(85, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, (131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/) | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(86, "Class", "corner-5");
                                    __builder4.AddAttribute$3(87, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(88, "\r\n                        Manage\r\n                    ");
                                    }), $NwqJqf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $JSrTsa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                            }), $YKyaKa ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(89, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$oUrI.LCSCS$1.ShipmentPackage$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel), 90);
                                    __builder4.AddComponentParameter(91, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder4.AddComponentParameter(92, "Resolver", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$oUrI.LCSCS.IShipmentDashboardResolver$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.Service));
                                    __builder4.AddComponentParameter(93, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Parameter));
                                    __builder4.AddComponentParameter(94, "CanEdit", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.Parameter.Account.Equals$1(this.Service.CommunityService.Account)), $.$$.S.Boolean));
                                    __builder4.AddComponentParameter(95, "ScalePrice", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, (1 + (this.Service.GlobalSettings.PercentageCommision / 100))), $.$$.S.Double));
                                    __builder4.CloseComponent();
                                }, $sLIybb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                            }), $cBnILk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(96, "\r\n            ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 97);
                            __builder3.AddComponentParameter(98, "Class", "pd");
                            __builder3.AddAttribute$3(99, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*t*/ t) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 100);
                                    __builder4.AddComponentParameter(101, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, t.Model.Selected ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.OfPrimary(0.5)));
                                    __builder4.AddComponentParameter(102, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, (131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/) | 256/*ButtonFeatures.Small*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(103, "Class", "corner-5");
                                    __builder4.AddAttribute$3(104, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(105, "\r\n                        Queries\r\n                    ");
                                    }), $OxRDkd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $YodPMi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                            }), $BfKqpk ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(106, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSQ.CommunityPostQueries$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.QueryPostModel), 107);
                                    __builder4.AddComponentParameter(108, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.Parameter));
                                    __builder4.AddComponentParameter(109, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSQ.CommunityPostQueriesFeatures, 0/*CommunityPostQueriesFeatures.Default*/ | (this.Service.CommunityService.Account.Equals$1(this.Parameter.Account) ? 2/*CommunityPostQueriesFeatures.AnswerQueries*/ : 0/*CommunityPostQueriesFeatures.None*/) | ((hasAdminRight && this.Parameter.QueryState < 4096/*PostQueryableState.Paid*/) ? 1/*CommunityPostQueriesFeatures.AddQueries*/ : 0/*CommunityPostQueriesFeatures.None*/)), $.$ahDc.LCCCSQ.CommunityPostQueriesFeatures));
                                    __builder4.CloseComponent();
                                }, $duVIig ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                            }), $MrIfnl ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(110, "\r\n            ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 111);
                            __builder3.AddAttribute$3(112, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*t*/ t) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 113);
                                    __builder4.AddComponentParameter(114, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, t.Model.Selected ? $.$fPer.LCFC.Theme.Primary : $.$fPer.LCFC.Theme.OfPrimary(0.5)));
                                    __builder4.AddComponentParameter(115, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, (131634/*ButtonFeatures.Default*/ & ~32/*ButtonFeatures.Corner*/ & ~32768/*ButtonFeatures.PropagateClick*/) | 256/*ButtonFeatures.Small*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder4.AddComponentParameter(116, "Class", "corner-5");
                                    __builder4.AddComponentParameter(117, "view-class", "pos-abs t-0 l-0 r-0 b-0 text-left bg-tertiary z-10 animated slideInUp");
                                    __builder4.AddAttribute$3(118, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder5) =>
                                    {
                                        __builder5.AddMarkupContent(119, "\r\n                            Messages\r\n                        ");
                                    }), $CZGWlh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(120, "View", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32)))().$ctor(this, ( (/*clicked*/ clicked) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$1(121, this.Chat.LCFCI$IChatProvider$GetChatThread($.$fPer.LCFCD.DataId.op_Implicit$1($.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Parameter.Identifier, this.Service.CommunityService.Account.Identifier ], null, null))), this.Parameter.Title, new $.$fPer.LCFCD.DataId(), null, 0, null));
                                        }, $GzLpXc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                                    }), $OHEJfb ??= {"r":6881395,"p":[{"n":"clicked","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Int32).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $edBJQi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                            }), $fAHFek ??= {"r":6881395,"p":[{"n":"t","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $feWypf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $gVCaZb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1360468,"h":0,"f":17825794});
                }), $OnWYLh ??= {"r":6881395,"p":[{"n":"products","p":$.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1360468,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21476196948)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181229652)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181229652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181229652)
            
            //--TRIMMABLE-BOUNDARY-START(17181229652)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17181229652)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771164244)
                this.Chat = null;
                //--TRIMMABLE-BOUNDARY-END(25771164244)
                
                //--TRIMMABLE-BOUNDARY-START(81605739092)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81605739092)
                
                //--TRIMMABLE-BOUNDARY-START(111670510164)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(111670510164)
                
            }
            static $h = 1360468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771164244),
    {
      "p": 63526570,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656066132,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195673684,
        "f": 83886081
      },
      "n": "Chat",
      "d": 1360468,
      "h": 25771164244,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771164244),
//--TRIMMABLE-BOUNDARY-START(81605739092),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835935316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785608276,
        "f": 83886081
      },
      "n": "Service",
      "d": 1360468,
      "h": 81605739092,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605739092),
//--TRIMMABLE-BOUNDARY-START(111670510164),
    {
      "p": 5594536,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425869908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375542868,
        "f": 83886081
      },
      "n": "UI",
      "d": 1360468,
      "h": 111670510164,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670510164),
//--TRIMMABLE-BOUNDARY-START(77310771796),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246000724,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1360468,
      "h": 77310771796,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310771796)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066131540),
    {
      "r": 178454529,
      "n": "DeleteOrder",
      "d": 1360468,
      "h": 30066131540,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30066131540),
//--TRIMMABLE-BOUNDARY-START(68720837204),
    {
      "r": 178454529,
      "n": "Hold",
      "d": 1360468,
      "h": 68720837204,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68720837204),
//--TRIMMABLE-BOUNDARY-START(73015804500),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1360468,
      "h": 73015804500,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015804500),
//--TRIMMABLE-BOUNDARY-START(21476196948),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1360468,
      "h": 21476196948,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476196948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181229652),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1360468,
      "h": 17181229652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181229652)
  ],
  "h": 1360468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkOrder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkOrder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1360468)
        
        

        //--TRIMMABLE-BOUNDARY-START(1557076)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkProductBanner`, ($self) => class BuyLinkProductBanner extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(77310968404)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(77310968404)
            
            //--TRIMMABLE-BOUNDARY-START(81605935700)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81605935700)
            
            //--TRIMMABLE-BOUNDARY-START(68721033812)
            /*bool*/ Mini = false;
            //--TRIMMABLE-BOUNDARY-END(68721033812)
            
            //--TRIMMABLE-BOUNDARY-START(21476393556)
            /*Task *//*async*/  AddIcon(/*IEnumerable<ResourceModel>*/ resources)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476393556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.Identifier.HasValue)
                    {
                        try
                        {
                            let $t1, $r1;
                            ($t1 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.AddResources$1(this.Server, this.ViewModel.Identifier, $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.ResourceModel, $.$fPer.LCFCD.DataId, resources, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$fPer.LCFCD.DataId))().$ctor(this,  (/**/ r) =>
                            {
                                return r.Identifier;
                            }, $BMQuIi ??= {"r":10455382,"p":[{"n":"r","p":15279446}],"n":"","d":1557076,"h":0,"f":17825794})), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        }
                        catch($e)
                        {
                        }
                    }
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                    this.ViewModel.Resources = ((__ca1__ = this.ViewModel.Resources) !== null ? ($.$sl.SL.Enumerable.Concat($.$Iaui.LCFCM.ResourceModel, __ca1__, resources) ?? $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ResourceModel, resources)) : $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ResourceModel, resources));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476393556)
            
            //--TRIMMABLE-BOUNDARY-START(73016001108)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkproductbanner";
            }
            //--TRIMMABLE-BOUNDARY-END(73016001108)
            
            //--TRIMMABLE-BOUNDARY-START(111670706772)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670706772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "Mini":
                    this.Mini = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111670706772)
            
            //--TRIMMABLE-BOUNDARY-START(64426066516)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426066516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64426066516)
            
            //--TRIMMABLE-BOUNDARY-START(25771360852)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771360852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                if (!this.Mini && $.$$.S.Int32.op_GreaterThan(((__ca1__ = this.ViewModel.ProductIcons) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca1__) : null), 1))
                {
                    /*var*/ let icons = this.ViewModel.ProductIcons;
                    if (this.Service.CommunityService.Account.Equals$1(this.ViewModel.Account))
                    {
                        icons = $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, $.$sl.SL.Enumerable.Concat($.$$.S.String, icons, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [""], [-1], null)));
                    }
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$$.S.String), 0);
                    __builder.AddComponentParameter(1, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), icons));
                    __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 67108864n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(3, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, 96/*SliderFeatures.Default*/ | 4/*SliderFeatures.NavigatorBottom*/), $.$hDPm.LCFCCS$9.SliderFeatures));
                    __builder.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            if (context.Model !== "")
                            {
                                __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 5);
                                __builder2.AddComponentParameter(6, "Class", "d-block mihx-3 flex");
                                __builder2.AddComponentParameter(7, "href", this.ViewModel.Link);
                                __builder2.AddComponentParameter(8, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.ViewModel));
                                __builder2.AddAttribute$3(9, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 10);
                                    __builder3.AddComponentParameter(11, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.S.String.StartsWith$3.call(context.Model, "http") ? $.$fPer.LCFC.ProxyUrlExtension.GetProxyUrl(context.Model, this.UnitOfWork.LCFCI$IClientUnitOfWork$Context) : context.Model));
                                    __builder3.AddComponentParameter(12, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 300), $.$$.S.Int32));
                                    __builder3.AddComponentParameter(13, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                    __builder3.CloseComponent();
                                }), $kLMzCj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                            else 
                            {
                                __builder2.OpenElement(14, "div");
                                __builder2.AddAttribute$5(15, "class", "hx-45 flex text-center");
                                __builder2.OpenElement(16, "div");
                                __builder2.AddAttribute$5(17, "class", "mg-a");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCR$2.ResourceBrowser, 18);
                                __builder2.AddComponentParameter(19, "OnSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$$.STT.Task))().$ctor(this, this.AddIcon))));
                                __builder2.AddComponentParameter(20, "Title", "Add Product Image");
                                __builder2.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 22);
                                    __builder3.AddComponentParameter(23, "Class", "mdi mdi-plus fsz-80");
                                    __builder3.AddComponentParameter(24, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(25, "\r\n                                ");
                                    __builder3.AddMarkupContent(26, "<h4>Add more images</h4>");
                                }), $wLjsBf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }, $mZQPGd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794});
                    }), $KwBvbe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).$h}],"n":"","d":1557076,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(27, "SliderThumbNail", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.String)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            if (context.Model !== "")
                            {
                                __builder2.OpenElement(28, "div");
                                __builder2.AddAttribute$5(29, "class", "hx-05 wx-05 round clip flex");
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 30);
                                __builder2.AddComponentParameter(31, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                __builder2.AddComponentParameter(32, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                                __builder2.AddComponentParameter(33, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.S.String.StartsWith$3.call(context.Model, "http") ? $.$fPer.LCFC.ProxyUrlExtension.GetProxyUrl(context.Model, this.UnitOfWork.LCFCI$IClientUnitOfWork$Context) : context.Model));
                                __builder2.AddComponentParameter(34, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder2.CloseComponent();
                                __builder2.CloseElement();
                            }
                            else 
                            {
                                __builder2.AddMarkupContent(35, "<i class=\"mdi mdi-plus fsz-30 mg-a\"></i>");
                            }
                        }, $KIApZb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794});
                    }), $dXHzdd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.String).$h}],"n":"","d":1557076,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    if (this.Service.CommunityService.Account.Equals$1(this.ViewModel.Account))
                    {
                        __builder.OpenElement(36, "div");
                        __builder.AddAttribute$5(37, "class", "pos-abs l-0 b-0 mg bg-primary-01 round wx-05 hx-05 z-2 clip flex");
                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder, 38, "onclick", true);
                        __builder.OpenComponent$1($.$hDPm.LCFCCR$2.ResourceBrowser, 39);
                        __builder.AddComponentParameter(40, "OnSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$$.STT.Task))().$ctor(this, this.AddIcon))));
                        __builder.AddComponentParameter(41, "Title", "Add Product Image");
                        __builder.AddComponentParameter(42, "Class", "flex mg-a");
                        __builder.AddAttribute$3(43, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 44);
                            __builder2.AddComponentParameter(45, "Class", "mdi mdi-image-plus fsz-25 mg-a cl-black");
                            __builder2.AddComponentParameter(46, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 32768/*ButtonFeatures.PropagateClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                            __builder2.CloseComponent();
                        }), $yNhDea ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                    __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 47);
                    __builder.AddComponentParameter(48, "Class", "d-block hx-45 pos-rel");
                    __builder.AddComponentParameter(49, "href", this.ViewModel.Link);
                    __builder.AddComponentParameter(50, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.ViewModel));
                    __builder.AddAttribute$3(51, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 52);
                        __builder2.AddComponentParameter(53, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.S.String.StartsWith$3.call(this.ViewModel.IconDescriptor.Icon, "http") ? $.$fPer.LCFC.ProxyUrlExtension.GetProxyUrl(this.ViewModel.IconDescriptor.Icon, this.UnitOfWork.LCFCI$IClientUnitOfWork$Context) : this.ViewModel.IconDescriptor.Icon));
                        __builder2.AddComponentParameter(54, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                        __builder2.CloseComponent();
                    }), $MQrgCg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1557076,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771360852)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17181426260)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181426260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181426260)
            
            //--TRIMMABLE-BOUNDARY-START(17181426260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(17181426260)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310968404)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(77310968404)
                
                //--TRIMMABLE-BOUNDARY-START(81605935700)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81605935700)
                
            }
            static $h = 1557076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310968404),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541164628,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785804884,
        "f": 83886081
      },
      "n": "Server",
      "d": 1557076,
      "h": 77310968404,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310968404),
//--TRIMMABLE-BOUNDARY-START(81605935700),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131099220,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375739476,
        "f": 83886081
      },
      "n": "Service",
      "d": 1557076,
      "h": 81605935700,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605935700),
//--TRIMMABLE-BOUNDARY-START(68721033812),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361295444,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195870292,
        "f": 83886081
      },
      "n": "Mini",
      "d": 1557076,
      "h": 68721033812,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721033812),
//--TRIMMABLE-BOUNDARY-START(73016001108),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951230036,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1557076,
      "h": 73016001108,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016001108)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476393556),
    {
      "r": 178454529,
      "p": [
        {
          "n": "resources",
          "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h
        }
      ],
      "n": "AddIcon",
      "d": 1557076,
      "h": 21476393556,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476393556),
//--TRIMMABLE-BOUNDARY-START(111670706772),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1557076,
      "h": 111670706772,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670706772),
//--TRIMMABLE-BOUNDARY-START(64426066516),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1557076,
      "h": 64426066516,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426066516),
//--TRIMMABLE-BOUNDARY-START(25771360852),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1557076,
      "h": 25771360852,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771360852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181426260),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1557076,
      "h": 17181426260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181426260)
  ],
  "h": 1557076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProductBanner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProductBanner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1557076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1426004)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkOrderBanner`, ($self) => class BuyLinkOrderBanner extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21476262484)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkorderbanner";
            }
            //--TRIMMABLE-BOUNDARY-END(21476262484)
            
            //--TRIMMABLE-BOUNDARY-START(8591360596)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591360596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ViewModel.Products !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$$.S.String), 0);
                    __builder.AddComponentParameter(1, "_Data", "ViewModel.Products.SelectMany(p=>((CommunityBuyLinkPostModel)p).ProductIcons??new string[0])");
                    __builder.AddComponentParameter(2, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.String, this.ViewModel.Products, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                    {
                        return (p).IconDescriptor.Icon;
                    }, $zCtYNc ??= {"r":1310721,"p":[{"n":"p","p":1789295}],"n":"","d":1426004,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t !== null;
                    }, $nONmya ??= {"r":262145,"p":[{"n":"t","p":1310721}],"n":"","d":1426004,"h":0,"f":17825794})))));
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 67108864n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(4, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, 96/*SliderFeatures.Default*/ | 4/*SliderFeatures.NavigatorBottom*/), $.$hDPm.LCFCCS$9.SliderFeatures));
                    __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(6, "div");
                            __builder2.AddAttribute$5(7, "class", "hx-3");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 8);
                            __builder2.AddComponentParameter(9, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model));
                            __builder2.AddComponentParameter(10, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 300), $.$$.S.Int32));
                            __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }, $hGZwAj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1426004,"h":0,"f":17825794});
                    }), $UKHAcd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.String, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.String)).$h}],"n":"","d":1426004,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(12, "SliderThumbNail", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.String)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(13, "div");
                            __builder2.AddAttribute$5(14, "class", "hx-05 wx-05 round clip");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 15);
                            __builder2.AddComponentParameter(16, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder2.AddComponentParameter(17, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder2.AddComponentParameter(18, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model));
                            __builder2.AddComponentParameter(19, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }, $rlcohi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1426004,"h":0,"f":17825794});
                    }), $ihQzEc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.String).$h}],"n":"","d":1426004,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 20);
                    __builder.AddComponentParameter(21, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder.AddComponentParameter(22, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ViewModel.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder.AddComponentParameter(23, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 67108864n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(24, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, 96/*SliderFeatures.Default*/ | 4/*SliderFeatures.NavigatorBottom*/), $.$hDPm.LCFCCS$9.SliderFeatures));
                    __builder.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*product*/ product) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(26, "div");
                            __builder2.AddAttribute$5(27, "class", "hx-3");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 28);
                            __builder2.AddComponentParameter(29, "Height", "300");
                            __builder2.AddComponentParameter(30, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, product.Model.IconDescriptor));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }, $ElBBgh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1426004,"h":0,"f":17825794});
                    }), $KwGZde ??= {"r":6881395,"p":[{"n":"product","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1426004,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(31, "SliderThumbNail", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this, ( (/*product*/ product) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(32, "div");
                            __builder2.AddAttribute$5(33, "class", "hx-05 wx-05 round clip");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 34);
                            __builder2.AddComponentParameter(35, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder2.AddComponentParameter(36, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder2.AddComponentParameter(37, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, product.Model.IconDescriptor.Icon));
                            __builder2.AddComponentParameter(38, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder2.CloseComponent();
                            __builder2.CloseElement();
                        }, $LDCPwf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1426004,"h":0,"f":17825794});
                    }), $juJuWh ??= {"r":6881395,"p":[{"n":"product","p":$.$hDPm.LCFCI.ContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h}],"n":"","d":1426004,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591360596)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296393300)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296393300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296393300)
            
            //--TRIMMABLE-BOUNDARY-START(4296393300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296393300)
            
            static $h = 1426004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476262484),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181295188,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1426004,
      "h": 21476262484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476262484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591360596),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1426004,
      "h": 8591360596,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591360596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296393300),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1426004,
      "h": 4296393300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296393300)
  ],
  "h": 1426004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkOrderBanner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkOrderBanner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1426004)
        
        

        //--TRIMMABLE-BOUNDARY-START(1688148)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkProductToolBar`, ($self) => class BuyLinkProductToolBar extends $.$hDPm.LCFCC$1.BaseParameterizedContainer$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(124555739732)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(124555739732)
            
            //--TRIMMABLE-BOUNDARY-START(120260772436)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120260772436)
            
            //--TRIMMABLE-BOUNDARY-START(227634954836)
            /*CommunityToolBarFeatures*/ ToolBarFeatures = 0;
            //--TRIMMABLE-BOUNDARY-END(227634954836)
            
            //--TRIMMABLE-BOUNDARY-START(154620510804)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(154620510804)
            
            //--TRIMMABLE-BOUNDARY-START(163210445396)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(163210445396)
            
            //--TRIMMABLE-BOUNDARY-START(137440641620)
            /*PropertyChangedEventHandler*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(137440641620)
            
            //--TRIMMABLE-BOUNDARY-START(137440641620)
            //--TRIMMABLE-BOUNDARY-START(34361426516)
            add_PropertyChanged(/*PropertyChangedEventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361426516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34361426516)
            
            //--TRIMMABLE-BOUNDARY-START(150325543508)
            remove_PropertyChanged(/*PropertyChangedEventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325543508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(150325543508)
            
            //--TRIMMABLE-BOUNDARY-END(137440641620)
            
            //--TRIMMABLE-BOUNDARY-START(158915478100)
            /*ValueTask *//*async*/  ServerUpdate(T, /*T*/ viewModel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915478100);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$vWqU.LCFCC.LoadingExtension.Load$1($.$fPer.LCFCD.WireTransportManyModel$$(T), this, new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T))))().$ctor(this,  () =>
                    {
                        return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [ viewModel ], null, null));
                    }, $zSgPXd ??= {"r":(T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,"n":"","d":1688148,"h":0,"f":17825794}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                    }, $LgxGNj ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1688148,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158915478100)
            
            //--TRIMMABLE-BOUNDARY-START(115965805140)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965805140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServerUpdate(T, this.ViewModel);
            }
            //--TRIMMABLE-BOUNDARY-END(115965805140)
            
            //--TRIMMABLE-BOUNDARY-START(141735608916)
            /*int */ get Quantity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606066772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.Quantity;
            }
            /*int */ set Quantity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570183764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let initialQ = this.ViewModel.Quantity;
                this.ViewModel.Quantity = value;
                if (this.ViewModel.Identifier.HasValue)
                {
                    /*Task*/ let task = this.ServerUpdate(T, this.ViewModel);
                    _ = task.ContinueWith$11(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/*task*/ task) =>
                    {
                        if (task.Exception !== null)
                        {
                            this.ViewModel.Quantity = initialQ;
                        }
                    }, $dqlxyc ??= {"r":65537,"p":[{"n":"task","p":178454529}],"n":"","d":1688148,"h":0,"f":17825794}));
                }
                else 
                {
                    _ = this.Service.SaveCart();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735608916)
            
            //--TRIMMABLE-BOUNDARY-START(128850707028)
            /*string */ get Message()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426197588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.get_Item$1("message");
            }
            /*string */ set Message(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980249172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.set_Item$1("message", value);
                if (this.ViewModel.Identifier.HasValue)
                {
                    _ = this.ServerUpdate(T, this.ViewModel);
                }
                else 
                {
                    _ = this.Service.SaveCart();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850707028)
            
            //--TRIMMABLE-BOUNDARY-START(133145674324)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkproducttoolbar";
            }
            //--TRIMMABLE-BOUNDARY-END(133145674324)
            
            //--TRIMMABLE-BOUNDARY-START(231929922132)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929922132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "ToolBarFeatures":
                    this.ToolBarFeatures = $.$cast(parameter.Value, $.$ahDc.LCCCSP.CommunityToolBarFeatures);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(231929922132)
            
            //--TRIMMABLE-BOUNDARY-START(111670837844)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670837844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(111670837844)
            
            //--TRIMMABLE-BOUNDARY-START(38656393812)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656393812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, (336/*LoadingFeatures.Default*/ & ~32/*LoadingFeatures.Retry*/) | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostToolBar, 4);
                    __builder2.AddComponentParameter(5, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IPost, this.ViewModel));
                    __builder2.AddComponentParameter(6, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(7, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.OwnAttributes(null)));
                    __builder2.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSP.CommunityToolBarFeatures, this.ToolBarFeatures), $.$ahDc.LCCCSP.CommunityToolBarFeatures));
                    __builder2.AddAttribute$3(9, "MenuItems", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        if ($.$is(this.ViewModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel))
                        {
                            if (this.Service.CommunityService.Account.Equals$1(this.ViewModel.Account))
                            {
                                __builder3.OpenElement(10, "div");
                                __builder3.AddAttribute$5(11, "class", "menuitem");
                                __builder3.OpenComponent$1($.$macw.MACF.EditForm, 12);
                                __builder3.AddComponentParameter(13, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                __builder3.AddComponentParameter(14, "class", "stack hf wx-05 text-left");
                                __builder3.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(16, "<small class=\"op-8 mgb-2\">Qty</small>\r\n                            ");
                                        $.$jfJD._LCCBCSB$2.TypeInference.CreateInputEditor_0($.$$.S.Int32, __builder4, 17, 18, this.ViewModel.UnitCost.Value === 0 ? 0n : 3n, 19, $.$fPer.LCFC.Theme.OfCard(0.7), 20, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/, 21, "fill", 22, this.Quantity, 23, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Int32, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Int32, this, new ($.$$.S.Action$$($.$$.S.Int32))().$ctor(this,  (/*__value*/ __value) =>
                                        {
                                            return this.Quantity = __value;
                                        }, $qMMzlh ??= {"r":65537,"p":[{"n":"__value","p":655361}],"n":"","d":1688148,"h":0,"f":17825794}), this.Quantity)), 24, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                        {
                                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Quantity"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                        }, $Sgitvh ??= {"r":38797349,"n":"","d":1688148,"h":0,"f":17825794})).Invoke()));
                                    }, $BbaWPg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1688148,"h":0,"f":17825794});
                                }), $KpUkTh ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1688148,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                                if (!$.$$.S.String.IsNullOrEmpty(this.ViewModel.Post) || this.ViewModel.UnitCost.Value === 0)
                                {
                                    __builder3.OpenElement(25, "div");
                                    __builder3.AddAttribute$5(26, "class", "menuitem");
                                    __builder3.OpenComponent$1($.$macw.MACF.EditForm, 27);
                                    __builder3.AddComponentParameter(28, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                                    __builder3.AddComponentParameter(29, "class", "stack hf text-left");
                                    __builder3.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(31, "<small class=\"op-8 mgb-2\">Message</small>\r\n                                ");
                                            $.$jfJD._LCCBCSB$2.TypeInference.CreateInputEditor_1($.$$.S.String, __builder4, 32, 33, "Leave a message", 34, "1", 35, this.ViewModel.UnitCost.Value === 0 ? 16n : 3n, 36, $.$fPer.LCFC.Theme.Card, 37, 4131/*InputEditorFeatures.Default*/ | 8/*InputEditorFeatures.Highlight*/, 38, "fill bd", 39, this.Message, 40, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return this.Message = __value;
                                            }, $ayIodd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1688148,"h":0,"f":17825794}), this.Message)), 41, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Message"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $OdyhNg ??= {"r":38797349,"n":"","d":1688148,"h":0,"f":17825794})).Invoke()));
                                        }, $nLuaDj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1688148,"h":0,"f":17825794});
                                    }), $iJHymc ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1688148,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                }
                            }
                        }
                    }), $XEFHof ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1688148,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(42, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.AddContent$1(43, this.ChildContent);
                    }), $YwnMzi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1688148,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $CtKhuk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1688148,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38656393812)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25771491924)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771491924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771491924)
            
            //--TRIMMABLE-BOUNDARY-START(25771491924)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(25771491924)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(124555739732)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(124555739732)
                
                //--TRIMMABLE-BOUNDARY-START(227634954836)
                this.ToolBarFeatures = 511;
                //--TRIMMABLE-BOUNDARY-END(227634954836)
                
                //--TRIMMABLE-BOUNDARY-START(154620510804)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(154620510804)
                
                //--TRIMMABLE-BOUNDARY-START(163210445396)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(163210445396)
                
            }
            static $h = 1688148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedContainer$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124555739732),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836262996,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390314580,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1688148,
      "h": 124555739732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555739732),
//--TRIMMABLE-BOUNDARY-START(120260772436),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246328404,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800379988,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1688148,
      "h": 120260772436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260772436),
//--TRIMMABLE-BOUNDARY-START(227634954836),
    {
      "p": 31495616,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375870548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339987540,
        "f": 83886081
      },
      "n": "ToolBarFeatures",
      "d": 1688148,
      "h": 227634954836,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634954836),
//--TRIMMABLE-BOUNDARY-START(154620510804),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196001364,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160118356,
        "f": 83886081
      },
      "n": "Server",
      "d": 1688148,
      "h": 154620510804,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620510804),
//--TRIMMABLE-BOUNDARY-START(163210445396),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785935956,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750052948,
        "f": 83886081
      },
      "n": "Service",
      "d": 1688148,
      "h": 163210445396,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210445396),
//--TRIMMABLE-BOUNDARY-START(141735608916),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606066772,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570183764,
        "f": 83886082
      },
      "n": "Quantity",
      "d": 1688148,
      "h": 141735608916,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(141735608916),
//--TRIMMABLE-BOUNDARY-START(128850707028),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426197588,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980249172,
        "f": 83886082
      },
      "n": "Message",
      "d": 1688148,
      "h": 128850707028,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128850707028),
//--TRIMMABLE-BOUNDARY-START(133145674324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016132180,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1688148,
      "h": 133145674324,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145674324)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158915478100),
    {
      "r": 181338113,
      "p": [
        {
          "n": "viewModel",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ServerUpdate",
      "d": 1688148,
      "h": 158915478100,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(158915478100),
//--TRIMMABLE-BOUNDARY-START(115965805140),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1688148,
      "h": 115965805140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965805140),
//--TRIMMABLE-BOUNDARY-START(231929922132),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1688148,
      "h": 231929922132,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231929922132),
//--TRIMMABLE-BOUNDARY-START(111670837844),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1688148,
      "h": 111670837844,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670837844),
//--TRIMMABLE-BOUNDARY-START(38656393812),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1688148,
      "h": 38656393812,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38656393812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771491924),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1688148,
      "h": 25771491924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771491924)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(137440641620),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1688148,
        "h": 34361426516,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1688148,
        "h": 150325543508,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1688148,
      "h": 137440641620,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(137440641620)
  ],
  "h": 1688148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkProductToolBar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkProductToolBar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1688148)
        
        

        //--TRIMMABLE-BOUNDARY-START(836180)
        $asm.$cls(`$jfJD.LCCBCS.CommunityBuyLinkProductViewProvider`, ($self) => class CommunityBuyLinkProductViewProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590770772)
            /*RenderFragment */ GetView(/*ContainerContext<CommunityBuyLinkProductModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590770772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$2($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCCBCM.CommunityBuyLinkProductModel, value.Model, "ViewModel", new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*seq*/ seq) =>
                {
                    builder.AddAttribute$4(seq, "ContainerContext", $.$clone(value));
                }, $EEWFBe ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"seq","p":655361}],"n":"","d":836180,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590770772)
            
            //--TRIMMABLE-BOUNDARY-START(12885738068)
            /*RenderFragment */ GetView$1(/*ContainerContext<CommunityBuyLinkProductPoolModel>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885738068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$2($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, value.Model, "ViewModel", new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*seq*/ seq) =>
                {
                    builder.AddAttribute$4(seq, "ContainerContext", $.$clone(value));
                }, $RIzbZf ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"seq","p":655361}],"n":"","d":836180,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885738068)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>)
            LCFCI$IViewProvider$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>)
            LCFCI$IViewProvider$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(4295803476)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295803476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295803476)
            
            //--TRIMMABLE-BOUNDARY-START(4295803476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295803476)
            
            static $h = 836180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590770772),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h
        }
      ],
      "n": "GetView",
      "d": 836180,
      "h": 8590770772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590770772),
//--TRIMMABLE-BOUNDARY-START(12885738068),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$h
        }
      ],
      "n": "GetView",
      "o": "@$1",
      "d": 836180,
      "h": 12885738068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885738068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295803476),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 836180,
      "h": 4295803476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295803476)
  ],
  "h": 836180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$hDPm.LCFCI.IViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.CommunityBuyLinkProductViewProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}CommunityBuyLinkProductViewProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(836180)
        
        

        //--TRIMMABLE-BOUNDARY-START(770644)
        $asm.$cls(`$jfJD.LCCBCS.CommunityBuyLinkProductPoolFeedProvider`, ($self) => class CommunityBuyLinkProductPoolFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295737940)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295737940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295737940)
            
            //--TRIMMABLE-BOUNDARY-START(8590705236)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityBuyLinkProductPoolModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590705236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`joined BuyLink Pool ${$.$strNN(((__ca1__ = model.Title) !== null ? $.$$.S.String.Substring.call(__ca1__, 0, $.$$.S.Math.Min$4(32, model.Title.length)) : null))}`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590705236)
            
            static $h = 770644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590705236),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 2051439
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 770644,
      "h": 8590705236,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590705236)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295737940),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 770644,
      "h": 4295737940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295737940)
  ],
  "h": 770644
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.CommunityBuyLinkProductPoolFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}CommunityBuyLinkProductPoolFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(770644)
        
        

        //--TRIMMABLE-BOUNDARY-START(639572)
        $asm.$cls(`$jfJD.LCCBCS.CommunityBuyLinkApplication`, ($self) => class CommunityBuyLinkApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(171799331412)
            /*string*/ static ThemeColor = null;
            //--TRIMMABLE-BOUNDARY-END(171799331412)
            
            //--TRIMMABLE-BOUNDARY-START(12885541460)
            $ctor$3(/*CommunityBuyLinkService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885541460);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885541460)
            
            //--TRIMMABLE-BOUNDARY-START(146029527636)
            /*string */ get Name()
            {
                return "BuyLink";
            }
            //--TRIMMABLE-BOUNDARY-END(146029527636)
            
            //--TRIMMABLE-BOUNDARY-START(176094298708)
            /*string */ get Title()
            {
                return "BuyLink";
            }
            //--TRIMMABLE-BOUNDARY-END(176094298708)
            
            //--TRIMMABLE-BOUNDARY-START(21475476052)
            /*string */ get Description()
            {
                return "Buy and ship products from online with just a link.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475476052)
            
            //--TRIMMABLE-BOUNDARY-START(141734560340)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cart"/*MaterialDesignIconNames.Cart*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141734560340)
            
            //--TRIMMABLE-BOUNDARY-START(167504364116)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#ff4747"/*ThemeColor*/;
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(167504364116)
            
            //--TRIMMABLE-BOUNDARY-START(30065410644)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/ | 1/*ApplicationServiceFeatures.InDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065410644)
            
            //--TRIMMABLE-BOUNDARY-START(17180508756)
            /*Type? */ get ApplicationViewType()
            {
                return $.$jfJD.LCCBCP.CommunityBuyLinkApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180508756)
            
            //--TRIMMABLE-BOUNDARY-START(137439593044)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439593044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$jfJD.LCCBCP.CommunityBuyLinkApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(137439593044)
            
            //--TRIMMABLE-BOUNDARY-START(25770443348)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770443348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770443348)
            
            //--TRIMMABLE-BOUNDARY-START(158914429524)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914429524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(158914429524)
            
            //--TRIMMABLE-BOUNDARY-START(150324494932)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(150324494932)
            
            //--TRIMMABLE-BOUNDARY-START(4295606868)
            /*CommunityBuyLinkService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295606868)
            
            //--TRIMMABLE-BOUNDARY-START(163209396820)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(163209396820)
            
            //--TRIMMABLE-BOUNDARY-START(180389266004)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(5120/*PostTypes.BuyLink*/, 5124/*PostTypes.BuyLinkEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180389266004)
            
            //--TRIMMABLE-BOUNDARY-START(154619462228)
            /*IEnumerable<string> */ get ReferrerPerks()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Share BuyLink with your friends and benefits from their activities in the app", "Get 10% from the first purchase of your refererred friends on BuyLink", "Refer 50 friends and win BuyLink weekend perks"], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(154619462228)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(8608323008)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityReferrerApplication.ReferrerPerks.get
            get LCCCS$ICommunityReferrerApplication$ReferrerPerks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12903290304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReferrerPerks;
            }
            //--TRIMMABLE-BOUNDARY-END(8608323008)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(171799331412)
                    this.ThemeColor = "#ff4747";
                    //--TRIMMABLE-BOUNDARY-END(171799331412)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 639572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146029527636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605018196,
        "f": 50364417
      },
      "n": "Name",
      "d": 639572,
      "h": 146029527636,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029527636),
//--TRIMMABLE-BOUNDARY-START(176094298708),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554691156,
        "f": 50364417
      },
      "n": "Title",
      "d": 639572,
      "h": 176094298708,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094298708),
//--TRIMMABLE-BOUNDARY-START(21475476052),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835214420,
        "f": 50364417
      },
      "n": "Description",
      "d": 639572,
      "h": 21475476052,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475476052),
//--TRIMMABLE-BOUNDARY-START(141734560340),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015083604,
        "f": 50364417
      },
      "n": "Icon",
      "d": 639572,
      "h": 141734560340,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734560340),
//--TRIMMABLE-BOUNDARY-START(167504364116),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964756564,
        "f": 50364417
      },
      "n": "Theme",
      "d": 639572,
      "h": 167504364116,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504364116),
//--TRIMMABLE-BOUNDARY-START(30065410644),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425149012,
        "f": 50364417
      },
      "n": "Features",
      "d": 639572,
      "h": 30065410644,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065410644),
//--TRIMMABLE-BOUNDARY-START(17180508756),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245279828,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 639572,
      "h": 17180508756,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180508756),
//--TRIMMABLE-BOUNDARY-START(150324494932),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194952788,
        "f": 50364417
      },
      "n": "Order",
      "d": 639572,
      "h": 150324494932,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324494932),
//--TRIMMABLE-BOUNDARY-START(4295606868),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655345236,
        "f": 50331650
      },
      "n": "_Service",
      "d": 639572,
      "h": 4295606868,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295606868),
//--TRIMMABLE-BOUNDARY-START(163209396820),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374821972,
        "f": 50364417
      },
      "n": "Service",
      "d": 639572,
      "h": 163209396820,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209396820),
//--TRIMMABLE-BOUNDARY-START(180389266004),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144625748,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 639572,
      "h": 180389266004,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389266004),
//--TRIMMABLE-BOUNDARY-START(154619462228),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784887380,
        "f": 50331649
      },
      "n": "ReferrerPerks",
      "d": 639572,
      "h": 154619462228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619462228)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439593044),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 639572,
      "h": 137439593044,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(137439593044),
//--TRIMMABLE-BOUNDARY-START(25770443348),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 639572,
      "h": 25770443348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770443348),
//--TRIMMABLE-BOUNDARY-START(158914429524),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 639572,
      "h": 158914429524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914429524)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(171799331412),
    {
      "t": 1310721,
      "n": "ThemeColor",
      "d": 639572,
      "h": 171799331412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799331412)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885541460),
    {
      "p": [
        {
          "n": "service",
          "p": 901716
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 639572,
      "h": 12885541460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885541460)
  ],
  "h": 639572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$ahDc.LCCCS.ICommunitySearchApplication, $.$ahDc.LCCCS.ICommunityReferrerApplication, $.$ahDc.LCCCS.ICommunityClientApplication, $.$sZVd.LCFCA.IClientApplication, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.CommunityBuyLinkApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}CommunityBuyLinkApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(639572)
        
        

        //--TRIMMABLE-BOUNDARY-START(508500)
        $asm.$cls(`$jfJD.LCCBCP.CommunityBuyLinkApp`, ($self) => class CommunityBuyLinkApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages2$$$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(55835083348)
            /*CommunityBuyLinkService*/ BuyLinkService = null;
            //--TRIMMABLE-BOUNDARY-END(55835083348)
            
            //--TRIMMABLE-BOUNDARY-START(51540116052)
            /*CommunityBuyLinkApplication*/ BuyLinkApplication = null;
            //--TRIMMABLE-BOUNDARY-END(51540116052)
            
            //--TRIMMABLE-BOUNDARY-START(42950181460)
            /*string*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(42950181460)
            
            //--TRIMMABLE-BOUNDARY-START(34360246868)
            /*ICommunityClientApplication */ get Application()
            {
                return this.BuyLinkApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(34360246868)
            
            //--TRIMMABLE-BOUNDARY-START(64425017940)
            /*CommunityPostView */ get CardView()
            {
                return 4/*CommunityPostView.CardMediaFirst*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64425017940)
            
            //--TRIMMABLE-BOUNDARY-START(68719985236)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(68719985236)
            
            //--TRIMMABLE-BOUNDARY-START(60130050644)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(60130050644)
            
            //--TRIMMABLE-BOUNDARY-START(274878415444)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~1/*UseDefaultPage.Home*/ & ~2/*UseDefaultPage.PostView*/;
            }
            //--TRIMMABLE-BOUNDARY-END(274878415444)
            
            //--TRIMMABLE-BOUNDARY-START(201863971412)
            /*string */ get HomePageUrl()
            {
                return "Home";
            }
            //--TRIMMABLE-BOUNDARY-END(201863971412)
            
            //--TRIMMABLE-BOUNDARY-START(197569004116)
            /*string */ get HomePageTitle()
            {
                return "";
            }
            //--TRIMMABLE-BOUNDARY-END(197569004116)
            
            //--TRIMMABLE-BOUNDARY-START(38655214164)
            /*EventHandler?*/ ApplicationRendered = null;
            //--TRIMMABLE-BOUNDARY-END(38655214164)
            
            //--TRIMMABLE-BOUNDARY-START(38655214164)
            //--TRIMMABLE-BOUNDARY-START(25770312276)
            add_ApplicationRendered(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770312276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Combine$2(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770312276)
            
            //--TRIMMABLE-BOUNDARY-START(240518677076)
            remove_ApplicationRendered(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518677076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Remove(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(240518677076)
            
            //--TRIMMABLE-BOUNDARY-END(38655214164)
            
            //--TRIMMABLE-BOUNDARY-START(219043840596)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043840596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Community.BuyLink.Client.min.css", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(219043840596)
            
            //--TRIMMABLE-BOUNDARY-START(214748873300)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748873300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender)
                {
                    this.ApplicationRendered?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(214748873300)
            
            //--TRIMMABLE-BOUNDARY-START(210453906004)
            /*ValueTask */ NewOrderCreated(/*CommunityBuyLinkProductModel*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453906004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BuyLinkService.AddToCart($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ post ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(210453906004)
            
            //--TRIMMABLE-BOUNDARY-START(223338807892)
            /*string */ get OptimizedComponentName()
            {
                return "communitybuylinkapp communitydefaultpages2";
            }
            //--TRIMMABLE-BOUNDARY-END(223338807892)
            
            //--TRIMMABLE-BOUNDARY-START(270583448148)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583448148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(270583448148)
            
            //--TRIMMABLE-BOUNDARY-START(206158938708)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158938708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.BuyLinkService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
                this.BuyLinkApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(206158938708)
            
            //--TRIMMABLE-BOUNDARY-START(47245148756)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245148756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(47245148756)
            
            //--TRIMMABLE-BOUNDARY-START(231928742484)
            /*RenderFragment */ get ProfileTabs()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let isSupplier = (this.BuyLinkService.UserPreference?.Usage ?? null) === 1/*AppUsage.Supplier*/ && this.BuyLinkService.CommunityService.UserAuthenticationTicket.HasRoles("SuperAdmin,Admin," + $.$strNN("BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/));
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 1);
                    __builder2.AddComponentParameter(2, "Name", "Pools");
                    __builder2.AddComponentParameter(3, "Class", "pd-5");
                    __builder2.AddAttribute$3(4, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*_*/ _0) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(5, "My Pools");
                        }, $aKGIxb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $iobRYf ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCSP.CommunityPosts$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), 7);
                            __builder3.AddComponentParameter(8, "CardView", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSP.CommunityPostView, 4/*CommunityPostView.CardMediaFirst*/), $.$ahDc.LCCCSP.CommunityPostView));
                            __builder3.AddComponentParameter(9, "CardWidthHint", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 250), $.$$.S.Int32));
                            __builder3.AddComponentParameter(10, "CardSpaceHint", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 20), $.$$.S.Int32));
                            __builder3.AddComponentParameter(11, "content-class", "mgx--5");
                            __builder3.AddComponentParameter(12, "Filter", new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(isSupplier ? 1073741826/*PostFilterTypes.Account*/ : 1073741827/*PostFilterTypes.Subscriptions*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder3.AddAttribute$3(13, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 14);
                                __builder4.AddComponentParameter(15, "Class", "mg");
                                __builder4.AddComponentParameter(16, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `You buylink pool will appear here`));
                                __builder4.CloseComponent();
                            }), $MbXBGc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":508500,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $cPSJdi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $olIkDf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(17, "\r\n        ");
                }, $HHywIh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(231928742484)
            
            //--TRIMMABLE-BOUNDARY-START(227633775188)
            /*RenderFragment */ get PrependPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(18, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 19);
                    __builder2.AddComponentParameter(20, "Name", "Home");
                    __builder2.AddComponentParameter(21, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(22, "Class", "pos-rel");
                    __builder2.AddComponentParameter(23, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(24, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ & ~1/*ApplicationPageFeatures.TopToolBar*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(25, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutHeader($.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/ & ~1/*CommunityLayoutFeatures.PadT*/, null, null, true), this.GetBanner());
                    }), $GiRujf ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(26, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(27, "Home");
                        }, $qjcBFe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $XJmZdg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(28, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(29, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-home"), false));
                        }, $JEtxSd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $sHyMhd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(30, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*page*/ page) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkHome, 31);
                            __builder3.CloseComponent();
                        }, $hZoLBd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $Inpftc ??= {"r":6881395,"p":[{"n":"page","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(32, "\r\n    ");
                }, $jvQerj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(227633775188)
            
            //--TRIMMABLE-BOUNDARY-START(30065279572)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(33, "\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCA$3.AuthorizeUser, 34);
                    __builder2.AddComponentParameter(35, "Roles", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, "SuperAdmin,Admin," + $.$strNN("BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/)));
                    __builder2.AddAttribute$3(36, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*ticket*/ ticket) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 37);
                            __builder3.AddComponentParameter(38, "Name", "Filter");
                            __builder3.AddComponentParameter(39, "Class", "pos-rel");
                            __builder3.AddComponentParameter(40, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                            __builder3.AddComponentParameter(41, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddComponentParameter(42, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/**/ e) =>
                            {
                                return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                            }), $ZTNhEf ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(43, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddContent$4(44, "Supplier Filter");
                                }, $QwCOJa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                            }), $TrPIAj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(45, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(46, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-filter"), false));
                                }, $SYirCc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                            }), $kqsguj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(47, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*page*/ page) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkSupplierFilter, 48);
                                    __builder4.CloseComponent();
                                }, $uKlelk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                            }), $jHELnb ??= {"r":6881395,"p":[{"n":"page","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $sjacpi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $UPuQJc ??= {"r":6881395,"p":[{"n":"ticket","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(49, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), 50);
                    __builder2.AddComponentParameter(51, "Name", "Order");
                    __builder2.AddComponentParameter(52, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Order/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(53, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $rfxuec ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(54, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(55, "<i class=\"mdi mdi-cart\"></i>");
                        }, $Tvwxke ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $fbLkgk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(56, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(57, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $gkQtBb ??= {"r":131073,"p":[{"n":"e","p":937327}],"n":"","d":508500,"h":0,"f":17825794}), true));
                        }, $SZyADh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $kahxlc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(58, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkOrder, 59);
                            __builder3.CloseComponent();
                        }, $DXOkva ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $vweDHe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(60, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 61);
                    __builder2.AddComponentParameter(62, "Name", "Product");
                    __builder2.AddComponentParameter(63, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Product/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(64, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this, ( (/**/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $yDnHwf ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(65, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(66, "<i class=\"mdi mdi-cart\"></i>");
                        }, $CNlUDg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $tLHqdg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(67, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(68, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $TFGDLf ??= {"r":131073,"p":[{"n":"e","p":1789295}],"n":"","d":508500,"h":0,"f":17825794}), true));
                        }, $itjaci ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $rXfwDg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(69, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProduct$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 70);
                            __builder3.CloseComponent();
                        }, $cxVoOj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $dCUpbh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(71, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), 72);
                    __builder2.AddComponentParameter(73, "Name", "Pool");
                    __builder2.AddComponentParameter(74, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Pool/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(75, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)))().$ctor(this, ( (/**/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $ErROoh ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(76, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(77, "<i class=\"mdi mdi-cart\"></i>");
                        }, $UvXqxc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $YbTcVf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(78, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(79, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $aBoJte ??= {"r":131073,"p":[{"n":"e","p":2051439}],"n":"","d":508500,"h":0,"f":17825794}), true));
                        }, $IwMRil ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $rTqCYh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(80, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProduct$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), 81);
                            __builder3.CloseComponent();
                        }, $rBrFIk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $sVpzXb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(82, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 83);
                    __builder2.AddComponentParameter(84, "Name", "Create");
                    __builder2.AddComponentParameter(85, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $GKciVf ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(86, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(87, "<i class=\"mdi mdi-cart\"></i>");
                        }, $KJExAk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $fifuzk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(88, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$4(89, "New Product Order");
                        }, $LQOJUj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $SsQKGi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(90, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel), 91);
                            __builder3.AddComponentParameter(92, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.STT.ValueTask))().$ctor(this, this.NewOrderCreated))));
                            __builder3.CloseComponent();
                        }, $Dnuqbb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                    }), $VQOyRk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":508500,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(93, "\r\n    ");
                }, $vMgrJh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(30065279572)
            
            //--TRIMMABLE-BOUNDARY-START(193274036820)
            /*RenderFragment */ GetBanner()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274036820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkHomeBanner, 94);
                        __builder2.CloseComponent();
                    }, $UcsjWf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":508500,"h":0,"f":17825794});
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274036820)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180377684)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180377684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180377684)
            
            //--TRIMMABLE-BOUNDARY-START(17180377684)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17180377684)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835083348)
                this.BuyLinkService = null;
                //--TRIMMABLE-BOUNDARY-END(55835083348)
                
                //--TRIMMABLE-BOUNDARY-START(51540116052)
                this.BuyLinkApplication = null;
                //--TRIMMABLE-BOUNDARY-END(51540116052)
                
                //--TRIMMABLE-BOUNDARY-START(42950181460)
                this.BasePath = "BuyLink";
                //--TRIMMABLE-BOUNDARY-END(42950181460)
                
            }
            static $h = 508500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages2$$$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835083348),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669658196,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288480852,
        "f": 83886081
      },
      "n": "BuyLinkService",
      "d": 508500,
      "h": 55835083348,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835083348),
//--TRIMMABLE-BOUNDARY-START(51540116052),
    {
      "p": 639572,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079723604,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698546260,
        "f": 83886081
      },
      "n": "BuyLinkApplication",
      "d": 508500,
      "h": 51540116052,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540116052),
//--TRIMMABLE-BOUNDARY-START(42950181460),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489789012,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108611668,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 508500,
      "h": 42950181460,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950181460),
//--TRIMMABLE-BOUNDARY-START(34360246868),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899854420,
        "f": 50364420
      },
      "n": "Application",
      "d": 508500,
      "h": 34360246868,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(34360246868),
//--TRIMMABLE-BOUNDARY-START(64425017940),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849527380,
        "f": 50364420
      },
      "n": "CardView",
      "d": 508500,
      "h": 64425017940,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(64425017940),
//--TRIMMABLE-BOUNDARY-START(68719985236),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439461972,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 508500,
      "h": 68719985236,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(68719985236),
//--TRIMMABLE-BOUNDARY-START(60130050644),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259592788,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 508500,
      "h": 60130050644,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(60130050644),
//--TRIMMABLE-BOUNDARY-START(274878415444),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979069524,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 508500,
      "h": 274878415444,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(274878415444),
//--TRIMMABLE-BOUNDARY-START(201863971412),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619331156,
        "f": 50364420
      },
      "n": "HomePageUrl",
      "d": 508500,
      "h": 201863971412,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(201863971412),
//--TRIMMABLE-BOUNDARY-START(197569004116),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029396564,
        "f": 50364420
      },
      "n": "HomePageTitle",
      "d": 508500,
      "h": 197569004116,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(197569004116),
//--TRIMMABLE-BOUNDARY-START(223338807892),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209265748,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 508500,
      "h": 223338807892,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223338807892),
//--TRIMMABLE-BOUNDARY-START(231928742484),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389134932,
        "f": 50364420
      },
      "n": "ProfileTabs",
      "d": 508500,
      "h": 231928742484,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(231928742484),
//--TRIMMABLE-BOUNDARY-START(227633775188),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799200340,
        "f": 50364420
      },
      "n": "PrependPages",
      "d": 508500,
      "h": 227633775188,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(227633775188),
//--TRIMMABLE-BOUNDARY-START(30065279572),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309919828,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 508500,
      "h": 30065279572,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30065279572)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(219043840596),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 508500,
      "h": 219043840596,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(219043840596),
//--TRIMMABLE-BOUNDARY-START(214748873300),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 508500,
      "h": 214748873300,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(214748873300),
//--TRIMMABLE-BOUNDARY-START(210453906004),
    {
      "r": 181338113,
      "p": [
        {
          "n": "post",
          "p": 1789295
        }
      ],
      "n": "NewOrderCreated",
      "d": 508500,
      "h": 210453906004,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210453906004),
//--TRIMMABLE-BOUNDARY-START(270583448148),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 508500,
      "h": 270583448148,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270583448148),
//--TRIMMABLE-BOUNDARY-START(206158938708),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 508500,
      "h": 206158938708,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206158938708),
//--TRIMMABLE-BOUNDARY-START(47245148756),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 508500,
      "h": 47245148756,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245148756),
//--TRIMMABLE-BOUNDARY-START(193274036820),
    {
      "r": 6881395,
      "n": "GetBanner",
      "d": 508500,
      "h": 193274036820,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274036820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180377684),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 508500,
      "h": 17180377684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180377684)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(38655214164),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_ApplicationRendered",
        "d": 508500,
        "h": 25770312276,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_ApplicationRendered",
        "d": 508500,
        "h": 240518677076,
        "f": 285212673
      },
      "n": "ApplicationRendered",
      "d": 508500,
      "h": 38655214164,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(38655214164)
  ],
  "h": 508500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Pages.CommunityBuyLinkApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Pages${separator}CommunityBuyLinkApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(508500)
        
        

        //--TRIMMABLE-BOUNDARY-START(901716)
        $asm.$cls(`$jfJD.LCCBCS.CommunityBuyLinkService`, ($self) => class CommunityBuyLinkService extends $.$ahDc.LCCCS.CommunityApplicationBaseService$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(8590836308)
            $ctor$5(/*CommunityRootService*/ service)
            {
                super.$ctor$4(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590836308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590836308)
            
            //--TRIMMABLE-BOUNDARY-START(17180770900)
            /*IEnumerable<CommunityBuyLinkProductModel>*/ cart = null;
            //--TRIMMABLE-BOUNDARY-END(17180770900)
            
            //--TRIMMABLE-BOUNDARY-START(21475738196)
            /*IEnumerable<CommunityBuyLinkProductModel> */ get Cart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065672788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.cart;
            }
            /*IEnumerable<CommunityBuyLinkProductModel> */ set Cart(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900247636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.cart = value;
                $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart", this.cart);
            }
            //--TRIMMABLE-BOUNDARY-END(21475738196)
            
            //--TRIMMABLE-BOUNDARY-START(77310313044)
            /*ValueTask */ SaveCart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310313044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart", this.cart);
            }
            //--TRIMMABLE-BOUNDARY-END(77310313044)
            
            //--TRIMMABLE-BOUNDARY-START(12885803604)
            /*ValueTask *//*async*/  AddToCart(/*params CommunityBuyLinkProductModel[]*/ buys)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885803604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $i1 = 0;
                    let $arr1 = buys;
                    while ($i1 < $arr1.length)
                    {
                        let buy = $arr1[$i1++];
                        if ($.$sl.SL.Enumerable.Contains$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.cart, buy))
                        {
                            /*var*/ let _buy = $.$sl.SL.Enumerable.Single($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.cart, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                            {
                                return c.Equals$2(buy);
                            }, $kmVyUh ??= {"r":262145,"p":[{"n":"c","p":1789295}],"n":"","d":901716,"h":0,"f":17825794}));
                            _buy.Quantity++;
                        }
                        else 
                        {
                            this.cart = $.$sl.SL.Enumerable.Concat($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.cart, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [buy], null, null));
                        }
                    }
                    this.cart = $.$sl.SL.Enumerable.ToList($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.cart);
                    ($t2 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart", this.cart), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.RaisePropertyChanged$1("Cart");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885803604)
            
            //--TRIMMABLE-BOUNDARY-START(68720378452)
            /*ValueTask *//*async*/  MergeCart(/*CommunityBuyLinkOrderModel*/ order)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720378452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en3 = this.cart.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let $new = $en3.SCG$IEnumerator$$$Current;
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>?*/ let __ca1__;
                            /*var*/ let existing = ((__ca1__ = order.Products) !== null ? $.$sl.SL.Enumerable.SingleOrDefault$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca1__, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                            {
                                return p.Equals$2($new);
                            }, $eLimQc ??= {"r":262145,"p":[{"n":"p","p":1789295}],"n":"","d":901716,"h":0,"f":17825794})) : null);
                            if (existing !== null)
                            {
                                existing.Quantity += $new.Quantity;
                            }
                            else 
                            {
                                order.Children = $.$sl.SL.Enumerable.ToList($.$LCOv.LCFCPM$1.PostAssociationModel, $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostAssociationModel, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAssociationModel), [(() =>
                                {
                                    //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                    const $t4 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                    const $i4 = new $t4();
                                    $i4.$ctor$1();
                                    $i4.Association = $new;
                                    return $i4;
                                })()], null, null), order.Children ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPM$1.PostAssociationModel)));
                            }
                        }
                    }
                    ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ order ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.cart = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [], [-1], null);
                    ($t6 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart", this.cart), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this.RaisePropertyChanged$1("Cart");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720378452)
            
            //--TRIMMABLE-BOUNDARY-START(60130443860)
            /*CommunityBuyLinkGlobalSettings*/ GlobalSettings = null;
            //--TRIMMABLE-BOUNDARY-END(60130443860)
            
            //--TRIMMABLE-BOUNDARY-START(64425411156)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425411156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$vWqU.LCFCC.LoadState.op_Equality(this.Loading, $.$vWqU.LCFCC.LoadState.Loaded) || $.$vWqU.LCFCC.LoadState.op_Equality(this.Loading, $.$vWqU.LCFCC.LoadState.Loading))
                {
                    return $.$$.STT.ValueTask.CompletedTask;
                }
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t7, $r7;
                        let $t8, $r8;
                        /*var*/ let settingsTask = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)))().$ctor(this,  (/*service*/ service) =>
                        {
                            return service.LCCBCS$IComunityBuyLinkRemoteService$GetApplicationSettings();
                        }, $WxvGLg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)).$h,"p":[{"n":"service","p":2903407}],"n":"","d":901716,"h":0,"f":17825794}), null, null);
                        /*var*/ let cartTask = $.$fPer.LCFCS$5.LocalStorageExtension.GetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart");
                        ($t7 = super.Load().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        this.cart = ($t8 = cartTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        this.cart ??= new ($.$$.SCG.List$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))().$ctor$1();
                        try
                        {
                            let $t9, $r9;
                            this.GlobalSettings = ($t9 = settingsTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        catch($e)
                        {
                            this.GlobalSettings = new $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings().$ctor$3();
                        }
                    });
                }, $oCHuli ??= {"r":181338113,"n":"","d":901716,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64425411156)
            
            //--TRIMMABLE-BOUNDARY-START(73015345748)
            /*ValueTask<CommunityBuyLinkOrderModel> *//*async*/  Order(/*CommunityBuyLinkOrderModel*/ order)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), $.$RffN.LCCBCM.CommunityBuyLinkOrderModel, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015345748);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$sl.SL.Enumerable.Any$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.cart))
                    {
                        let $t11, $r11;
                        let $t12, $r12;
                        order.Children = $.$sl.SL.Enumerable.Select$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel, this.cart, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$LCOv.LCFCPM$1.PostAssociationModel))().$ctor(this,  (/**/ c) =>
                        {
                            return (() =>
                            {
                                //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                                const $t10 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                                const $i10 = new $t10();
                                $i10.$ctor$1();
                                $i10.Association = c;
                                return $i10;
                            })();
                        }, $ZaHOGf ??= {"r":15919540,"p":[{"n":"c","p":1789295}],"n":"","d":901716,"h":0,"f":17825794}));
                        order.DisplayIcon = $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, $.$sl.SL.Enumerable.SelectMany$2($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.String, this.cart, new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.ProductIcons ?? $.$sl.SL.Enumerable.Empty($.$$.S.String);
                        }, $Lirdba ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.String).$h,"p":[{"n":"c","p":1789295}],"n":"","d":901716,"h":0,"f":17825794})));
                        /*var*/ let or = (($t11 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ order ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)))).AsEnumerable();
                        this.cart = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [], [-1], null);
                        ($t12 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "cart", this.cart), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                        this.RaisePropertyChanged$1("Cart");
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.First$1($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, or));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, order);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015345748)
            
            //--TRIMMABLE-BOUNDARY-START(47245541972)
            /*Pager<CommunityBuyLinkOrderModel> */ GetShipmentPackages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245541972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245541972)
            
            //--TRIMMABLE-BOUNDARY-START(42950574676)
            /*Pager<CommunityBuyLinkProductModel> */ GetProductsInPackage(/*CommunityBuyLinkOrderModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950574676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$6($package.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null);
            }
            //--TRIMMABLE-BOUNDARY-END(42950574676)
            
            //--TRIMMABLE-BOUNDARY-START(98785149524)
            /*ValueTask *//*async*/  UpdatePackagePaid(/*CommunityBuyLinkOrderModel*/ $package, /*string*/ paymentReferenceId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785149524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $package.DatePaid = $.$$.S.DateTime.UtcNow;
                    $package.PaymentReference = paymentReferenceId;
                    $package.QueryState = 4096/*PostQueryableState.Paid*/;
                    if ($package.Products !== null)
                    {
                        let $en13 = $package.Products.SCG$IEnumerable$$$GetEnumerator();
                        while ($en13.SC$1$IEnumerator$MoveNext())
                        {
                            let product = $en13.SCG$IEnumerator$$$Current;
                            {
                                product.QueryState = 4096/*PostQueryableState.Paid*/;
                            }
                        }
                    }
                    ($t14 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), [ $package ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98785149524)
            
            //--TRIMMABLE-BOUNDARY-START(51540509268)
            /*RenderFragment? */ GetView(/*CommunityBuyLinkOrderModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540509268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(51540509268)
            
            //--TRIMMABLE-BOUNDARY-START(55835476564)
            /*RenderFragment */ GetView$1(/*CommunityBuyLinkProductModel*/ product)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835476564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t15 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i15 = new $t15();
                    $i15.$ctor$1();
                    $i15.set_Item("ViewModel", product);
                    return $i15;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(55835476564)
            
            //--TRIMMABLE-BOUNDARY-START(8590387640)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.GetShipmentPackages()
            LCSCS$IShipmentDashboardResolver$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkOrderModel$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$GetShipmentPackages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590387640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetShipmentPackages(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590387640)
            
            //--TRIMMABLE-BOUNDARY-START(4295420344)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.GetProductsInPackage(LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel)
            LCSCS$IShipmentDashboardResolver$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkOrderModel$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$GetProductsInPackage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295420344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProductsInPackage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295420344)
            
            //--TRIMMABLE-BOUNDARY-START(12885354936)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.GetView(LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel)
            LCSCS$IShipmentDashboardResolver$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkOrderModel$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885354936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885354936)
            
            //--TRIMMABLE-BOUNDARY-START(17180322232)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.GetView(LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel)
            LCSCS$IShipmentDashboardResolver$$$$GetView$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkOrderModel$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180322232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180322232)
            
            //--TRIMMABLE-BOUNDARY-START(21475289528)
            //Generated interface implemetation for LivingThing.Core.Shipping.Client.Services.IShipmentDashboardResolver<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>.UpdatePackagePaid(LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, string)
            LCSCS$IShipmentDashboardResolver$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkOrderModel$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$UpdatePackagePaid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475289528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdatePackagePaid(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475289528)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180770900)
                this.cart = new ($.$$.SCG.List$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180770900)
                
                //--TRIMMABLE-BOUNDARY-START(60130443860)
                this.GlobalSettings = new $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(60130443860)
                
            }
            static $h = 901716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityApplicationBaseService$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475738196),
    {
      "p": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065672788,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900247636,
        "f": 83886081
      },
      "n": "Cart",
      "d": 901716,
      "h": 21475738196,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475738196),
//--TRIMMABLE-BOUNDARY-START(60130443860),
    {
      "p": 3100015,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655607380,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490182228,
        "f": 83886082
      },
      "n": "GlobalSettings",
      "d": 901716,
      "h": 60130443860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130443860)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310313044),
    {
      "r": 181338113,
      "n": "SaveCart",
      "d": 901716,
      "h": 77310313044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310313044),
//--TRIMMABLE-BOUNDARY-START(12885803604),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buys",
          "p": $.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
          "f": 16
        }
      ],
      "n": "AddToCart",
      "d": 901716,
      "h": 12885803604,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12885803604),
//--TRIMMABLE-BOUNDARY-START(68720378452),
    {
      "r": 181338113,
      "p": [
        {
          "n": "order",
          "p": 937327
        }
      ],
      "n": "MergeCart",
      "d": 901716,
      "h": 68720378452,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(68720378452),
//--TRIMMABLE-BOUNDARY-START(64425411156),
    {
      "r": 181338113,
      "n": "Load",
      "d": 901716,
      "h": 64425411156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425411156),
//--TRIMMABLE-BOUNDARY-START(73015345748),
    {
      "r": $.$$.STT.ValueTask$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel).$h,
      "p": [
        {
          "n": "order",
          "p": 937327
        }
      ],
      "n": "Order",
      "d": 901716,
      "h": 73015345748,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(73015345748),
//--TRIMMABLE-BOUNDARY-START(47245541972),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel).$h,
      "n": "GetShipmentPackages",
      "d": 901716,
      "h": 47245541972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245541972),
//--TRIMMABLE-BOUNDARY-START(42950574676),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
      "p": [
        {
          "n": "package",
          "p": 937327
        }
      ],
      "n": "GetProductsInPackage",
      "d": 901716,
      "h": 42950574676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950574676),
//--TRIMMABLE-BOUNDARY-START(98785149524),
    {
      "r": 181338113,
      "p": [
        {
          "n": "package",
          "p": 937327
        },
        {
          "n": "paymentReferenceId",
          "p": 1310721
        }
      ],
      "n": "UpdatePackagePaid",
      "d": 901716,
      "h": 98785149524,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(98785149524),
//--TRIMMABLE-BOUNDARY-START(51540509268),
    {
      "r": 6881395,
      "p": [
        {
          "n": "package",
          "p": 937327
        }
      ],
      "n": "GetView",
      "d": 901716,
      "h": 51540509268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540509268),
//--TRIMMABLE-BOUNDARY-START(55835476564),
    {
      "r": 6881395,
      "p": [
        {
          "n": "product",
          "p": 1789295
        }
      ],
      "n": "GetView",
      "o": "@$1",
      "d": 901716,
      "h": 55835476564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835476564)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180770900),
    {
      "t": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
      "n": "cart",
      "d": 901716,
      "h": 17180770900,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180770900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590836308),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 901716,
      "h": 8590836308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590836308)
  ],
  "h": 901716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$RffN.LCCBCM.CommunityBuyLinkUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$RffN.LCCBCM.CommunityBuyLinkUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$oUrI.LCSCS.IShipmentDashboardResolver$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$$.S.IDisposable, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Services.CommunityBuyLinkService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Services${separator}CommunityBuyLinkService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901716)
        
        

        //--TRIMMABLE-BOUNDARY-START(1098324)
        $asm.$cls(`$jfJD.LCCBCS$1.BuyLinkHome`, ($self) => class BuyLinkHome extends $.$lJUR.LCFCS.ApplicationPageBaseOfViewModel$$($.$jfJD.LCCBCS.CommunityBuyLinkService)
        {
            //--TRIMMABLE-BOUNDARY-START(253404168788)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(253404168788)
            
            //--TRIMMABLE-BOUNDARY-START(257699136084)
            /*CommunityBuyLinkService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(257699136084)
            
            //--TRIMMABLE-BOUNDARY-START(188979659348)
            /*HttpClient*/ Http = null;
            //--TRIMMABLE-BOUNDARY-END(188979659348)
            
            //--TRIMMABLE-BOUNDARY-START(210454495828)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(210454495828)
            
            //--TRIMMABLE-BOUNDARY-START(68720575060)
            /*Application*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(68720575060)
            
            //--TRIMMABLE-BOUNDARY-START(347893449300)
            /*IDisposable*/ shareSubscription = null;
            //--TRIMMABLE-BOUNDARY-END(347893449300)
            
            //--TRIMMABLE-BOUNDARY-START(219044430420)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044430420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(219044430420)
            
            //--TRIMMABLE-BOUNDARY-START(214749463124)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749463124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender)
                {
                    this.shareSubscription = $.$fPer.LCFCR.ReactiveObservableExtension.Subscribe($.$$.S.String, this.Service.ShareUrl, new ($.$$.S.Action$$$($.$fPer.LCFCR.IReactiveObservable$$($.$$.S.String), $.$fPer.LCFCR.IReactiveObservableChanges$$($.$$.S.String)))().$ctor(this,  (/*o*/ o, /*url*/ url) =>
                    {
                        this.Url = url.LCFCR$IReactiveObservableChanges$$$NewValue;
                    }, $xXBzhj ??= {"r":65537,"p":[{"n":"o","p":$.$fPer.LCFCR.IReactiveObservable$$($.$$.S.String).$h},{"n":"url","p":$.$fPer.LCFCR.IReactiveObservableChanges$$($.$$.S.String).$h}],"n":"","d":1098324,"h":0,"f":17825794}), null, null, false);
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(214749463124)
            
            //--TRIMMABLE-BOUNDARY-START(85900444244)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900444244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.shareSubscription?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(85900444244)
            
            //--TRIMMABLE-BOUNDARY-START(365073318484)
            /*CommunityBuyLinkService */ get ViewModel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684692052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service;
            }
            /*CommunityBuyLinkService */ set ViewModel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598482004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(365073318484)
            
            //--TRIMMABLE-BOUNDARY-START(42950771284)
            /*AccountModel*/ Account = null;
            //--TRIMMABLE-BOUNDARY-END(42950771284)
            
            //--TRIMMABLE-BOUNDARY-START(236224299604)
            /*Popup?*/ popup = null;
            //--TRIMMABLE-BOUNDARY-END(236224299604)
            
            //--TRIMMABLE-BOUNDARY-START(231929332308)
            /*bool*/ popping = false;
            //--TRIMMABLE-BOUNDARY-END(231929332308)
            
            //--TRIMMABLE-BOUNDARY-START(227634365012)
            /*void */ Pop(/*bool*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634365012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.popping = s;
            }
            //--TRIMMABLE-BOUNDARY-END(227634365012)
            
            //--TRIMMABLE-BOUNDARY-START(356483383892)
            /*string*/ url = null;
            //--TRIMMABLE-BOUNDARY-END(356483383892)
            
            //--TRIMMABLE-BOUNDARY-START(360778351188)
            /*string */ get Url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094757460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.url;
            }
            /*string */ set Url(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008547412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.url = value;
                if (!$.$$.S.String.IsNullOrEmpty(this.url))
                {
                    this.popup.Show(null);
                }
                else 
                {
                    this.popup.Hide();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(360778351188)
            
            //--TRIMMABLE-BOUNDARY-START(77310509652)
            /*void */ ClearUrl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310509652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Url = null;
                this.Service.ShareUrl.Reset();
            }
            //--TRIMMABLE-BOUNDARY-END(77310509652)
            
            //--TRIMMABLE-BOUNDARY-START(206159528532)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(206159528532)
            
            //--TRIMMABLE-BOUNDARY-START(201864561236)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(201864561236)
            
            //--TRIMMABLE-BOUNDARY-START(240519266900)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(240519266900)
            
            //--TRIMMABLE-BOUNDARY-START(240519266900)
            //--TRIMMABLE-BOUNDARY-START(51540705876)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540705876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(51540705876)
            
            //--TRIMMABLE-BOUNDARY-START(249109201492)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109201492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(249109201492)
            
            //--TRIMMABLE-BOUNDARY-END(240519266900)
            
            //--TRIMMABLE-BOUNDARY-START(197569593940)
            /*Task */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569593940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(197569593940)
            
            //--TRIMMABLE-BOUNDARY-START(55835673172)
            /*ValueTask */ AddToCart(/*CommunityBuyLinkProductModel*/ buy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835673172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Url = null;
                this.Service.ShareUrl.Reset();
                return this.Service.AddToCart($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ buy ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55835673172)
            
            //--TRIMMABLE-BOUNDARY-START(64425607764)
            /*ValueTask */ AddToCartKeep(/*CommunityBuyLinkProductModel*/ buy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425607764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Service.ShareUrl.Reset();
                return this.Service.AddToCart($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$RffN.LCCBCM.CommunityBuyLinkProductModel), [ buy ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(64425607764)
            
            //--TRIMMABLE-BOUNDARY-START(60130640468)
            /*ValueTask */ AddToCart$1(/*IEnumerable<CommunityBuyLinkProductModel>*/ buy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130640468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Url = null;
                this.Service.ShareUrl.Reset();
                return this.Service.AddToCart($.$sl.SL.Enumerable.ToArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buy));
            }
            //--TRIMMABLE-BOUNDARY-END(60130640468)
            
            //--TRIMMABLE-BOUNDARY-START(81605476948)
            /*Task *//*async*/  CreatePool(/*IEnumerable<CommunityBuyLinkProductModel>*/ buy)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605476948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let pools = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), buy, true, false, true, false, false, false, false, "CreatePool", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor\\BuyLinkHome.razor.cs", "CreatePool", 123), false, "CreatePool", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Client.Blazor\\BuyLinkHome.razor.cs", "CreatePool", 123);
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), pools), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.Url = null;
                    this.Service.ShareUrl.Reset();
                    this.Navigation.NavigateTo$1($.$fPer.LCFC.Stringy.op_Implicit$1($.$hDPm.LCFC.UtilityExtensions.GetAppLink$1("Profile/Pools", this.Application.NavigationPathSegment)), false, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81605476948)
            
            //--TRIMMABLE-BOUNDARY-START(90195411540)
            /*Task<IEnumerable<CommunityBuyLinkProductModel>> *//*async*/  Fetch(/*string*/ url)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195411540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let buyLinks = (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this,  (/**/ server) =>
                    {
                        return server.LCCBCS$IComunityBuyLinkRemoteService$ParseProductUrl(url);
                    }, $jtsEnf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h,"p":[{"n":"server","p":2903407}],"n":"","d":1098324,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable();
                    if ($.$sl.SL.Enumerable.Any$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks))
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        /*var*/ let viewed = ($t3 = this.Service.CommunityService.GetRawViewed($.$RffN.LCCBCM.CommunityBuyLinkProductModel), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        ($t4 = this.Service.CommunityService.AddRawViewed($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$sl.SL.Enumerable.ToArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$sl.SL.Enumerable.Distinct$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$sl.SL.Enumerable.Except$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks, viewed)))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, buyLinks);
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Unable to parse this website");
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195411540)
            
            //--TRIMMABLE-BOUNDARY-START(223339397716)
            /*string */ get OptimizedComponentName()
            {
                return "buylinkhome";
            }
            //--TRIMMABLE-BOUNDARY-END(223339397716)
            
            //--TRIMMABLE-BOUNDARY-START(352188416596)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188416596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch5 = parameter.Name;
                switch($switch5)
                {
                    case "Application":
                    this.Application = $.$cast(parameter.Value, $.$lJUR.LCFCS.Application);
                    return true;
                    case "Account":
                    this.Account = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.AccountModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(352188416596)
            
            //--TRIMMABLE-BOUNDARY-START(193274626644)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274626644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jfJD.LCCBCS.CommunityBuyLinkService, serviceProvider);
                this.Http = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$snh.SNH.HttpClient, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(193274626644)
            
            //--TRIMMABLE-BOUNDARY-START(73015542356)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                let $t6 = this.Service.CommunityService;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015542356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.popping)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 0);
                    __builder.AddComponentParameter(1, "Class", "mdi mdi-menu z-10 pos-abs t-0 l-0 mg-5");
                    __builder.AddComponentParameter(2, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Tertiary));
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, (131634/*ButtonFeatures.Default*/ & ~16/*ButtonFeatures.Shadow*/) | 1024/*ButtonFeatures.Large*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(4, "_OnClicked", "NoStateChanged(Page.Page.Application.ToggleLeftSideBar)");
                    __builder.CloseComponent();
                }
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "pd");
                __builder.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 7);
                __builder.AddComponentParameter(8, "Relative", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$3.PopupFeatures, (24/*PopupFeatures.Default*/ & ~4/*PopupFeatures.HoverOpen*/ & ~16/*PopupFeatures.HideOnLostFocus*/) | 8/*PopupFeatures.ClickOpen*/), $.$hDPm.LCFCCP$3.PopupFeatures));
                __builder.AddComponentParameter(10, "ShowPopupChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Boolean), $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this, this.Pop))));
                __builder.AddComponentParameter(11, "pop-class", "bg-card shadow-1 drop wf z-2 corner-b-5");
                __builder.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*popping*/ popping) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 13);
                        __builder2.AddComponentParameter(14, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                        __builder2.AddComponentParameter(15, "class", `d-block ${$.$strNN((!$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(popping) ? "bg-primary-01 corner-5 drop" : "bg-card corner-t-5"))} shadow clip flex mgt`);
                        __builder2.AddAttribute$3(16, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$($.$$.S.String), 17);
                                __builder3.AddComponentParameter(18, "Class", "bg-transparent fsz-15 pdx-5");
                                __builder3.AddComponentParameter(19, "PlaceHolder", "Paste the awesome link here");
                                __builder3.AddComponentParameter(20, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCI$1.InputEditorFeatures, 4131/*InputEditorFeatures.Default*/ & ~2/*InputEditorFeatures.BorderBottom*/), $.$hDPm.LCFCCI$1.InputEditorFeatures));
                                __builder3.AddComponentParameter(21, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Url));
                                __builder3.AddComponentParameter(22, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                {
                                    return this.Url = __value;
                                }, $BNRTBk ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1098324,"h":0,"f":17825794}), this.Url))));
                                __builder3.AddComponentParameter(23, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                {
                                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Url"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                }, $GLiUIj ??= {"r":38797349,"n":"","d":1098324,"h":0,"f":17825794})).Invoke())));
                                __builder3.CloseComponent();
                                if ($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(popping))
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 24);
                                    __builder3.AddComponentParameter(25, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                    __builder3.AddComponentParameter(26, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ClearUrl))));
                                    __builder3.AddComponentParameter(27, "Class", "mdi mdi-close fsz-20");
                                    __builder3.CloseComponent();
                                }
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 28);
                                __builder3.AddComponentParameter(29, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(30, "type", "submit");
                                __builder3.AddComponentParameter(31, "Class", "mdi mdi-google-lens fsz-20 mgr  flex mgc-a");
                                __builder3.CloseComponent();
                            }, $szbFbh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                        }), $XXgQOe ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1098324,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        if (!$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).op_Implicit(popping))
                        {
                            __builder2.AddMarkupContent(32, "<small class=\"d-block text-center mgb-10 mgt-3 mgx-5\">Or search for what you want in your favourite app (AliExpress, Aibaba, Ebay, 1688) and share it to BuyLink</small>");
                        }
                    }, $VowOha ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $KKZCuh ??= {"r":6881395,"p":[{"n":"popping","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.AddAttribute$3(33, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if (!$.$$.S.String.IsNullOrEmpty(this.url))
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), 34);
                            __builder2.AddComponentParameter(35, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))).op_Implicit$2(new ($.$$.S.Func$$($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( () =>
                            {
                                return this.Fetch(this.url);
                            }), $HtuYkd ??= {"r":$.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h,"n":"","d":1098324,"h":0,"f":17825794}))));
                            __builder2.AddAttribute$3(36, "PlaceHolder", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(37, "<div class=\"pd\"><em>Loading something awesome...</em></div>");
                            }), $uQLqlc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(38, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*buyLinks*/ buyLinks) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(39, "div");
                                    __builder3.AddAttribute$5(40, "class", "row pd bdt");
                                    __builder3.OpenElement(41, "div");
                                    __builder3.AddAttribute$5(42, "class", "col-a stack");
                                    __builder3.OpenElement(43, "span");
                                    __builder3.AddAttribute$5(44, "class", "mgy-a");
                                    __builder3.AddContent$3(45, $.$box($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data), $.$$.S.Int32));
                                    __builder3.AddMarkupContent(46, " results\r\n                                ");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    if (this.Service.CommunityService.UserAuthenticationTicket.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "BuyLink.Supplier"/*CommunityBuyLinkRoles.Supplier*/ ], null, null)))
                                    {
                                        __builder3.OpenElement(47, "div");
                                        __builder3.AddAttribute$5(48, "class", "col-5 pdl");
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), 49);
                                        __builder3.AddComponentParameter(50, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), buyLinks.Data));
                                        __builder3.AddComponentParameter(51, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Secondary));
                                        __builder3.AddComponentParameter(52, "Class", "nowrap mgr");
                                        __builder3.AddComponentParameter(53, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder3.AddComponentParameter(54, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$$.STT.Task))().$ctor(this, this.CreatePool))));
                                        __builder3.AddAttribute$3(55, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.AddMarkupContent(56, "\r\n                                        Create Pool\r\n                                    ");
                                        }), $XimBBk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                        __builder3.CloseElement();
                                    }
                                    __builder3.OpenElement(57, "div");
                                    __builder3.AddAttribute$5(58, "class", "col-5 pdl");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), 59);
                                    __builder3.AddComponentParameter(60, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), buyLinks.Data));
                                    __builder3.AddComponentParameter(61, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                    __builder3.AddComponentParameter(62, "Class", "nowrap");
                                    __builder3.AddComponentParameter(63, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$$.STT.ValueTask))().$ctor(this, this.AddToCart$1))));
                                    __builder3.AddAttribute$3(64, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.AddMarkupContent(65, "\r\n                                    Add\r\n");
                                        if ($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data) > 1)
                                        {
                                            __builder4.AddContent$4(66, "All");
                                        }
                                        __builder4.AddMarkupContent(67, "                                    to Cart\r\n                                ");
                                    }), $yiNwOk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(68, "\r\n                        ");
                                    $.$jfJD._LCCBCSB.TypeInference.CreateDataList_0($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __builder3, 69, 70, buyLinks.Data, 71, 35184372092928n | ($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data) > 1 ? 33554432n : 0n), 72, `${$.$strNN(($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data) > 1 ? "mgr-5 clip" : ""))} stack`, 73, `width:${$.$strNN(($.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data) > 1 ? "80vw" : ""))}`, 74, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this,  (/**/ buyLink) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 75);
                                            __builder4.AddComponentParameter(76, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLink.Model));
                                            __builder4.AddAttribute$3(77, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenElement(78, "div");
                                                __builder5.AddAttribute$5(79, "class", "text-right mgt-a pdl");
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 80);
                                                __builder5.AddComponentParameter(81, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLink.Model));
                                                __builder5.AddComponentParameter(82, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddComponentParameter(83, "Class", "mgl-2 mgt-a nowrap mdi mdi-cart-plus");
                                                __builder5.AddComponentParameter(84, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$mac.MAC.EventCallback.Factory, this, $.$sl.SL.Enumerable.Count$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLinks.Data) > 0 ? new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.STT.ValueTask))().$ctor(this, this.AddToCartKeep) : new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.STT.ValueTask))().$ctor(this, this.AddToCart))));
                                                __builder5.AddAttribute$3(85, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(86, "Cart");
                                                }), $xDUKob ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                                __builder5.CloseComponent();
                                                __builder5.CloseElement();
                                            }), $mIbRTi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $OkUWCc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                                    }, $kcYbaa ??= {"r":6881395,"p":[{"n":"buyLink","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                                }, $CAXSof ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                            }), $ZxZJSi ??= {"r":6881395,"p":[{"n":"buyLinks","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                            __builder2.SetKey(this.url);
                            __builder2.CloseComponent();
                        }
                    }, $WKMgyb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $cFUcAk ??= {"r":6881395,"p":[{"n":"context","p":39540394}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(87, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.popup = $.$cast(__value, $.$hDPm.LCFCCP$3.Popup);
                }, $YtRkRd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(88, "\r\n    ");
                __builder.OpenElement(89, "div");
                __builder.AddAttribute$5(90, "class", /*(popping||!Service.Cart.Any()||true) ?*/ "mgt-10"/* : "d-hide"*/);
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 91);
                __builder.AddComponentParameter(92, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 16777216n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(93, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$23(null, "hotdeals"/*CommunityBuyLinkProductModel.HotDealsFeaturedAttribute*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddAttribute$3(94, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>>>?*/ let __ca1__;
                        if ((__ca1__ = wrap.Models) !== null ? $.$sl.SL.Enumerable.Any$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), __ca1__) : false)
                        {
                            __builder2.AddMarkupContent(95, "<h3 class=\"mgt-10\">Hot Deals</h3>");
                            __builder2.AddContent$1(96, wrap.View);
                        }
                    }, $UlAVqa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $zzESjg ??= {"r":6881395,"p":[{"n":"wrap","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.AddAttribute$3(97, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 98);
                        __builder2.AddComponentParameter(99, "href", context.Model.Link);
                        __builder2.AddComponentParameter(100, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, context.Model));
                        __builder2.AddComponentParameter(101, "Class", "d-block hx-1 wx-07 mgr-5 corner clip");
                        __builder2.AddAttribute$3(102, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 103);
                            __builder3.AddComponentParameter(104, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.IconDescriptor.Icon));
                            __builder3.AddComponentParameter(105, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.AddComponentParameter(106, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 70), $.$$.S.Int32));
                            __builder3.AddComponentParameter(107, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                        }), $hHiHok ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $nsvJVi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $fgbwjj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(108, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 109);
                __builder.AddComponentParameter(110, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 16777216n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(111, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                __builder.AddAttribute$3(112, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>>>?*/ let __ca2__;
                        if ((__ca2__ = wrap.Models) !== null ? $.$sl.SL.Enumerable.Any$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), __ca2__) : false)
                        {
                            __builder2.AddMarkupContent(113, "<h3 class=\"mgt-10\">Trending BuyLinks</h3>");
                            __builder2.AddContent$1(114, wrap.View);
                        }
                    }, $RLyZEk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $cvrqti ??= {"r":6881395,"p":[{"n":"wrap","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.AddAttribute$3(115, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 116);
                        __builder2.AddComponentParameter(117, "href", context.Model.Link);
                        __builder2.AddComponentParameter(118, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, context.Model));
                        __builder2.AddComponentParameter(119, "Class", "d-block hx-1 wx-07 mgr-5 corner clip");
                        __builder2.AddAttribute$3(120, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 121);
                            __builder3.AddComponentParameter(122, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.IconDescriptor.Icon));
                            __builder3.AddComponentParameter(123, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.AddComponentParameter(124, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                        }), $fjWsAe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $WtXbse ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $mmUiTf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(125, "\r\n        ");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$3.TaskView$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), 126);
                __builder.AddComponentParameter(127, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCT$3.TaskViewFeatures, 7/*TaskViewFeatures.Default*/ & ~4/*TaskViewFeatures.Loading*/), $.$hDPm.LCFCCT$3.TaskViewFeatures));
                __builder.AddComponentParameter(128, "Task", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$$.STT.ValueTask$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCO.OneOf$$$$$$$($.$$.STT.Task, $.$$.STT.Task$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.Task$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$$.STT.ValueTask$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$$.S.Func$$($.$$.STT.ValueTask$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), $.$fPer.LCFCR.ReactiveObservable$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))).op_Implicit$4(new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor($t6, (...args) => $t6.GetRawViewed($.$RffN.LCCBCM.CommunityBuyLinkProductModel,  ...args)))));
                __builder.AddAttribute$3(129, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*viewed*/ viewed) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if ($.$sl.SL.Enumerable.Any$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, viewed.Data))
                        {
                            __builder2.AddMarkupContent(130, "<h3 class=\"mgt-10\">My Recent Searches</h3>\r\n                ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 131);
                            __builder2.AddComponentParameter(132, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), viewed.Data));
                            __builder2.AddComponentParameter(133, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 16777216n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder2.AddComponentParameter(134, "li-class", "hx-1 wx-07 mgr corner clip");
                            __builder2.AddAttribute$3(135, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 136);
                                    __builder3.AddComponentParameter(137, "href", context.Model.Link);
                                    __builder3.AddComponentParameter(138, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, context.Model));
                                    __builder3.AddComponentParameter(139, "Class", "d-block hx-1 wx-07 mgr-5 corner clip");
                                    __builder3.AddAttribute$3(140, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 141);
                                        __builder4.AddComponentParameter(142, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.IconDescriptor.Icon));
                                        __builder4.AddComponentParameter(143, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                        __builder4.AddComponentParameter(144, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, (387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/) | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                        __builder4.CloseComponent();
                                    }), $aTOoIe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }, $Ruqhad ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                            }), $gbsJya ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }, $zvYOZe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                }), $ecfamk ??= {"r":6881395,"p":[{"n":"viewed","p":$.$hDPm.LCFCI.ContainerContext$$($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
                if ($.$sl.SL.Enumerable.Any$1($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this.Service.Cart))
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 145);
                    __builder.AddComponentParameter(146, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder.AddComponentParameter(147, "MenuButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(148, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 16777216n | 8388608n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(149, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 300), $.$$.S.Int32));
                    __builder.AddComponentParameter(150, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder.AddComponentParameter(151, "li-class", "pdy mihx-15");
                    __builder.AddComponentParameter(152, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this.Service.Cart));
                    __builder.AddComponentParameter(153, "DataChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), this, new ($.$$.S.Action$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.Service.Cart = __value;
                    }, $bombwf ??= {"r":65537,"p":[{"n":"__value","p":$.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h}],"n":"","d":1098324,"h":0,"f":17825794}), this.Service.Cart))));
                    __builder.AddComponentParameter(154, "DataExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Service"), "Cart"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $ummBUf ??= {"r":38797349,"n":"","d":1098324,"h":0,"f":17825794})).Invoke())));
                    __builder.AddAttribute$3(155, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*wrapper*/ wrapper) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(156, "div");
                            __builder2.AddAttribute$5(157, "class", "fill scroll mgt-10");
                            __builder2.OpenElement(158, "div");
                            __builder2.AddAttribute$5(159, "class", "flex pdx");
                            __builder2.AddMarkupContent(160, "<h3 class=\"fill\">My BuyLink Cart</h3>");
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>>>?*/ let __ca3__;
                            if ((__ca3__ = wrapper.Models) !== null ? $.$sl.SL.Enumerable.Any$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)), __ca3__) : false)
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 161);
                                __builder2.AddComponentParameter(162, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder2.AddComponentParameter(163, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder2.AddComponentParameter(164, "view-class", "pdb-10 stack bg-tertiary pos-rel hf scroll wf z-10 animated slideInUp");
                                __builder2.AddAttribute$3(165, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.AddMarkupContent(166, "\r\n                                Check out >>\r\n                            ");
                                }), $pWCMuj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                                __builder2.AddAttribute$3(167, "DrawerView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*clicked*/ clicked) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                    {
                                        __builder3.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkCheckOut, 168);
                                        __builder3.SetKey(clicked.Model);
                                        __builder3.CloseComponent();
                                    }, $yhqSPf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                                }), $reFbxg ??= {"r":6881395,"p":[{"n":"clicked","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                            }
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(169, "\r\n                ");
                            __builder2.AddContent$1(170, wrapper.View);
                            __builder2.CloseElement();
                        }, $lMlrse ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                    }), $tZefxk ??= {"r":6881395,"p":[{"n":"wrapper","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(171, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*buyLink*/ buyLink) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 172);
                            __builder2.AddComponentParameter(173, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLink.Model));
                            __builder2.CloseComponent();
                        }, $AUUblh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                    }), $EPPXzc ??= {"r":6881395,"p":[{"n":"buyLink","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(174, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 175);
                        __builder2.AddComponentParameter(176, "Message", "Search for what you want to buy above");
                        __builder2.CloseComponent();
                    }), $lvQdYc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 177);
                    __builder.AddComponentParameter(178, "SideBarFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$7.SideBarFeatures, 32/*SideBarFeatures.Default*/ & ~32/*SideBarFeatures.ContentScroll*/), $.$hDPm.LCFCCS$7.SideBarFeatures));
                    __builder.AddComponentParameter(179, "MenuButtonFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder.AddComponentParameter(180, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 16777216n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(181, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741843/*PostFilterTypes.RecentlyCreated*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder.AddComponentParameter(182, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 300), $.$$.S.Int32));
                    __builder.AddComponentParameter(183, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder.AddComponentParameter(184, "li-class", "pdy mihx-15");
                    __builder.AddAttribute$3(185, "Wrapper", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*wrapper*/ wrapper) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(186, "div");
                            __builder2.AddAttribute$5(187, "class", "fill scroll mgt-10");
                            __builder2.AddMarkupContent(188, "<div class=\"flex pdx\"><h3 class=\"fill\">Recent BuyLinks</h3></div>\r\n                ");
                            __builder2.AddContent$1(189, wrapper.View);
                            __builder2.CloseElement();
                        }, $RsnNGe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                    }), $srkRhi ??= {"r":6881395,"p":[{"n":"wrapper","p":$.$hDPm.LCFCCD$1.DataListWrapperContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(190, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))().$ctor(this, ( (/*buyLink*/ buyLink) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$jfJD.LCCBCS$1.BuyLinkProductSummary$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), 191);
                            __builder2.AddComponentParameter(192, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$RffN.LCCBCM.CommunityBuyLinkProductModel, buyLink.Model));
                            __builder2.CloseComponent();
                        }, $JEafCj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1098324,"h":0,"f":17825794});
                    }), $XFrHaa ??= {"r":6881395,"p":[{"n":"buyLink","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h}],"n":"","d":1098324,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015542356)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(38655803988)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655803988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655803988)
            
            //--TRIMMABLE-BOUNDARY-START(38655803988)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(38655803988)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(253404168788)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(253404168788)
                
                //--TRIMMABLE-BOUNDARY-START(257699136084)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(257699136084)
                
                //--TRIMMABLE-BOUNDARY-START(188979659348)
                this.Http = null;
                //--TRIMMABLE-BOUNDARY-END(188979659348)
                
                //--TRIMMABLE-BOUNDARY-START(210454495828)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(210454495828)
                
                //--TRIMMABLE-BOUNDARY-START(206159528532)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(206159528532)
                
            }
            static $h = 1098324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBaseOfViewModel$$($.$jfJD.LCCBCS.CommunityBuyLinkService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(253404168788),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914888276,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828678228,
        "f": 83886081
      },
      "n": "Server",
      "d": 1098324,
      "h": 253404168788,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404168788),
//--TRIMMABLE-BOUNDARY-START(257699136084),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504822868,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418612820,
        "f": 83886081
      },
      "n": "Service",
      "d": 1098324,
      "h": 257699136084,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257699136084),
//--TRIMMABLE-BOUNDARY-START(188979659348),
    {
      "p": 6488117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965215316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468939860,
        "f": 83886081
      },
      "n": "Http",
      "d": 1098324,
      "h": 188979659348,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979659348),
//--TRIMMABLE-BOUNDARY-START(210454495828),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735019092,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238743636,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1098324,
      "h": 210454495828,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210454495828),
//--TRIMMABLE-BOUNDARY-START(68720575060),
    {
      "p": 733257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375280724,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879005268,
        "f": 83886081
      },
      "n": "Application",
      "d": 1098324,
      "h": 68720575060,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720575060),
//--TRIMMABLE-BOUNDARY-START(365073318484),
    {
      "p": 901716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684692052,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343598482004,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 1098324,
      "h": 365073318484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365073318484),
//--TRIMMABLE-BOUNDARY-START(42950771284),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785346132,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289070676,
        "f": 83886081
      },
      "n": "Account",
      "d": 1098324,
      "h": 42950771284,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950771284),
//--TRIMMABLE-BOUNDARY-START(360778351188),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094757460,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008547412,
        "f": 83886082
      },
      "n": "Url",
      "d": 1098324,
      "h": 360778351188,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(360778351188),
//--TRIMMABLE-BOUNDARY-START(206159528532),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145084500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648809044,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1098324,
      "h": 206159528532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159528532),
//--TRIMMABLE-BOUNDARY-START(201864561236),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555149908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058874452,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1098324,
      "h": 201864561236,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864561236),
//--TRIMMABLE-BOUNDARY-START(223339397716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324953684,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1098324,
      "h": 223339397716,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223339397716)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(219044430420),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1098324,
      "h": 219044430420,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(219044430420),
//--TRIMMABLE-BOUNDARY-START(214749463124),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 1098324,
      "h": 214749463124,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(214749463124),
//--TRIMMABLE-BOUNDARY-START(85900444244),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1098324,
      "h": 85900444244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900444244),
//--TRIMMABLE-BOUNDARY-START(227634365012),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 262145
        }
      ],
      "n": "Pop",
      "d": 1098324,
      "h": 227634365012,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634365012),
//--TRIMMABLE-BOUNDARY-START(77310509652),
    {
      "r": 65537,
      "n": "ClearUrl",
      "d": 1098324,
      "h": 77310509652,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310509652),
//--TRIMMABLE-BOUNDARY-START(197569593940),
    {
      "r": 178454529,
      "n": "Load",
      "d": 1098324,
      "h": 197569593940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569593940),
//--TRIMMABLE-BOUNDARY-START(55835673172),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buy",
          "p": 1789295
        }
      ],
      "n": "AddToCart",
      "d": 1098324,
      "h": 55835673172,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835673172),
//--TRIMMABLE-BOUNDARY-START(64425607764),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buy",
          "p": 1789295
        }
      ],
      "n": "AddToCartKeep",
      "d": 1098324,
      "h": 64425607764,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425607764),
//--TRIMMABLE-BOUNDARY-START(60130640468),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buy",
          "p": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h
        }
      ],
      "n": "AddToCart",
      "o": "@$1",
      "d": 1098324,
      "h": 60130640468,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130640468),
//--TRIMMABLE-BOUNDARY-START(81605476948),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buy",
          "p": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h
        }
      ],
      "n": "CreatePool",
      "d": 1098324,
      "h": 81605476948,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81605476948),
//--TRIMMABLE-BOUNDARY-START(90195411540),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h,
      "p": [
        {
          "n": "url",
          "p": 1310721
        }
      ],
      "n": "Fetch",
      "d": 1098324,
      "h": 90195411540,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90195411540),
//--TRIMMABLE-BOUNDARY-START(352188416596),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1098324,
      "h": 352188416596,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(352188416596),
//--TRIMMABLE-BOUNDARY-START(193274626644),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1098324,
      "h": 193274626644,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274626644),
//--TRIMMABLE-BOUNDARY-START(73015542356),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1098324,
      "h": 73015542356,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73015542356)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(347893449300),
    {
      "t": 91095041,
      "n": "shareSubscription",
      "d": 1098324,
      "h": 347893449300,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(347893449300),
//--TRIMMABLE-BOUNDARY-START(236224299604),
    {
      "t": 39474858,
      "n": "popup",
      "d": 1098324,
      "h": 236224299604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(236224299604),
//--TRIMMABLE-BOUNDARY-START(231929332308),
    {
      "t": 262145,
      "n": "popping",
      "d": 1098324,
      "h": 231929332308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231929332308),
//--TRIMMABLE-BOUNDARY-START(356483383892),
    {
      "t": 1310721,
      "n": "url",
      "d": 1098324,
      "h": 356483383892,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(356483383892)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655803988),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1098324,
      "h": 38655803988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655803988)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(240519266900),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1098324,
        "h": 51540705876,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1098324,
        "h": 249109201492,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 1098324,
      "h": 240519266900,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(240519266900)
  ],
  "h": 1098324
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Client.Shared.BuyLinkHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Client${separator}Shared${separator}BuyLinkHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1098324)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.BuyLink.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Shipping.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(49748)
