
//--TRIMMABLE-BOUNDARY-START(19823)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $PhXPAk;
    let $NUihNc;
    let $MoYRbg;
    let $MqhBBc;
    let $xTbYIc;
    let $DtgSqa;
    let $szQDld;
    let $nhTvde;
    let $gBGOTc;
    let $amzABk;
    let $ReYGcl;
    let $ilkQhe;
    let $nkqGGe;
    let $GyBGbd;
    let $QtjCRa;
    let $AuQNae;
    let $Upbgah;
    let $qkBYKe;
    let $GEOdrk;
    let $cQVJKc;
    let $sDcEqh;
    let $qqpkqk;
    let $DsvIpj;
    let $syIBnd;
    let $EPPpZj;
    let $QOAXik;
    let $SIbeRk;
    let $MaHgfj;
    let $qfaXti;
    let $zaqJbd;
    let $igqkih;
    let $IonvJd;
    let $TZxMFc;
    let $dZgKMc;
    let $KeGsge;
    let $nJKmVi;
    let $EXemai;
    let $woXUhd;
    let $Sriuzf;
    let $BfVJVe;
    let $DuBCnf;
    let $uFaYFb;
    let $sFFcAf;
    let $izYIbf;
    let $NATbNb;
    let $IoCjua;
    let $hbOHod;
    let $UGJNpj;
    let $ZBBzjl;
    let $PPhgPb;
    let $jdHpIj;
    let $wXPdQa;
    let $gAGHRa;
    let $elkgPa;
    let $fXlhCk;
    let $hdbfQa;
    let $QnUejl;
    let $noBwif;
    let $JtlsTk;
    let $XBMNBd;
    let $ihiMxk;
    let $xJkMEe;
    let $ieiSfg;
    let $cWniok;
    let $pdKmJi;
    let $qShzbf;
    let $kwrTqb;
    let $fieFri;
    let $WHSWke;
    let $AqPYbb;
    let $yyStOf;
    let $bwMXok;
    let $JHVMpf;
    let $XSmRfc;
    let $geWLCg;
    let $HaByec;
    let $nqEZba;
    let $yHBIai;
    let $TeUagj;
    let $IFalOj;
    let $lKRrcb;
    let $bzanGe;
    let $BmXgfi;
    let $oWIzGa;
    let $LWHTel;
    let $uRKtWb;
    let $vjIdVk;
    let $snKbQh;
    let $FsCwnd;
    let $PZSlUh;
    let $VOWaBj;
    let $xszlQg;
    let $wUjpBg;
    let $tasSPc;
    let $FaZtLb;
    let $gyKJYi;
    let $NdpjEb;
    let $aDBLVc;
    let $wWnQcj;
    let $ulIcwe;
    let $TkYgfk;
    let $JhhIra;
    let $SlMAni;
    let $cRkwRf;
    let $dGvCga;
    let $ziftYf;
    let $HVgqmg;
    let $iemehh;
    let $gbPKPk;
    let $mXJHfh;
    let $nUrWGb;
    let $gfXJMg;
    let $mvQjua;
    let $bQswBb;
    let $djVECa;
    let $bhGLDb;
    let $UgQIXe;
    let $oLItCa;
    let $hUquOk;
    let $ilhGjc;
    let $jDCjUc;
    let $EGwSRc;
    let $zhlYyg;
    let $vPoenf;
    let $wKbQSh;
    let $Zukoii;
    let $QmJJLg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.BuyLink.Common", 
    {
  "h": 19823,
  "f": "LivingThing.Core.Community.BuyLink.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.BuyLink.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2903407)
        $asm.$cls(`$RffN.LCCBCS.IComunityBuyLinkRemoteService`, ($self) => class IComunityBuyLinkRemoteService
        {
            static $h = 2903407;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297870703),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)).$h,
      "n": "GetApplicationSettings",
      "o": "LCCBCS$IComunityBuyLinkRemoteService$GetApplicationSettings",
      "d": 2903407,
      "h": 4297870703,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297870703),
//--TRIMMABLE-BOUNDARY-START(12887805295),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)).$h,
      "p": [
        {
          "n": "url",
          "p": 1310721
        }
      ],
      "n": "ParseProductUrl",
      "o": "LCCBCS$IComunityBuyLinkRemoteService$ParseProductUrl",
      "d": 2903407,
      "h": 12887805295,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887805295),
//--TRIMMABLE-BOUNDARY-START(8592837999),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).$h,
      "p": [
        {
          "n": "url",
          "p": 1310721
        }
      ],
      "n": "ParseProductPoolUrl",
      "o": "LCCBCS$IComunityBuyLinkRemoteService$ParseProductPoolUrl",
      "d": 2903407,
      "h": 8592837999,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592837999)
  ],
  "h": 2903407,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.IComunityBuyLinkRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}IComunityBuyLinkRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2903407)
        
        

        //--TRIMMABLE-BOUNDARY-START(2444655)
        $asm.$cls(`$RffN.LCCBCM.ICommunityBuyLinkProductPoolModel`, ($self) => class ICommunityBuyLinkProductPoolModel
        {
            static $h = 2444655;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772248431),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182313839,
        "f": 50331905
      },
      "n": "PoolStartDate",
      "o": "LCCBCM$ICommunityBuyLinkProductPoolModel$PoolStartDate",
      "d": 2444655,
      "h": 25772248431,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25772248431),
//--TRIMMABLE-BOUNDARY-START(21477281135),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592379247,
        "f": 50331905
      },
      "n": "PoolEndDate",
      "o": "LCCBCM$ICommunityBuyLinkProductPoolModel$PoolEndDate",
      "d": 2444655,
      "h": 21477281135,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21477281135)
  ],
  "h": 2444655
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCP.IPostQueryable, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostQueryStore, $.$LCOv.LCFCP.IPostEditableQueryStore ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.ICommunityBuyLinkProductPoolModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}ICommunityBuyLinkProductPoolModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2444655)
        
        

        //--TRIMMABLE-BOUNDARY-START(2313583)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkRoles`, ($self) => class CommunityBuyLinkRoles
        {
            //--TRIMMABLE-BOUNDARY-START(4297280879)
            /*string*/ static Supplier = null;
            //--TRIMMABLE-BOUNDARY-END(4297280879)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4297280879)
                    this.Supplier = "BuyLink.Supplier";
                    //--TRIMMABLE-BOUNDARY-END(4297280879)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2313583;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297280879),
    {
      "t": 1310721,
      "n": "Supplier",
      "d": 2313583,
      "h": 4297280879,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4297280879)
  ],
  "h": 2313583
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkRoles`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkRoles`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2313583)
        
        

        //--TRIMMABLE-BOUNDARY-START(2510191)
        $asm.$cls(`$RffN.LCCBCM.ICommunityBuyLinkProductPoolModelCustomAttributesProvider`, ($self) => class ICommunityBuyLinkProductPoolModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297477487)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297477487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297477487)
            
            static $h = 2510191;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297477487),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2510191,
      "h": 4297477487,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297477487)
  ],
  "h": 2510191
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.ICommunityBuyLinkProductPoolModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}ICommunityBuyLinkProductPoolModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2510191)
        
        

        //--TRIMMABLE-BOUNDARY-START(544111)
        $asm.$cls(`$RffN.LCCBCM.BuyLinkOrderShipmentTypeCustomAttributesProvider`, ($self) => class BuyLinkOrderShipmentTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295511407)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295511407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295511407)
            
            static $h = 544111;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295511407),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 544111,
      "h": 4295511407,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295511407)
  ],
  "h": 544111
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.BuyLinkOrderShipmentTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}BuyLinkOrderShipmentTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(544111)
        
        

        //--TRIMMABLE-BOUNDARY-START(3689839)
        $asm.$cls(`$RffN.LCCBCS$2.CommunityBuyLinkStatesCustomAttributesProvider`, ($self) => class CommunityBuyLinkStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298657135)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298657135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298657135)
            
            static $h = 3689839;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298657135),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3689839,
      "h": 4298657135,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298657135)
  ],
  "h": 3689839
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}States${separator}CommunityBuyLinkStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3689839)
        
        

        //--TRIMMABLE-BOUNDARY-START(1461615)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkPostInteractionTypeCustomAttributesProvider`, ($self) => class CommunityBuyLinkPostInteractionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296428911)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296428911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296428911)
            
            static $h = 1461615;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296428911),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1461615,
      "h": 4296428911,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296428911)
  ],
  "h": 1461615
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkPostInteractionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkPostInteractionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1461615)
        
        

        //--TRIMMABLE-BOUNDARY-START(3427695)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkSettingsCustomAttributesProvider`, ($self) => class CommunityBuyLinkSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298394991)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298394991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298394991)
            
            static $h = 3427695;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298394991),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3427695,
      "h": 4298394991,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298394991)
  ],
  "h": 3427695
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3427695)
        
        

        //--TRIMMABLE-BOUNDARY-START(740719)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkModelCustomAttributesProvider`, ($self) => class CommunityBuyLinkModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295708015)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295708015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295708015)
            
            static $h = 740719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295708015),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 740719,
      "h": 4295708015,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295708015)
  ],
  "h": 740719
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(740719)
        
        

        //--TRIMMABLE-BOUNDARY-START(85359)
        $asm.$cls(`$RffN.LCCBC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295052655)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295052655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkModelCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.BuyLinkOrderShipmentType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.BuyLinkOrderShipmentTypeCustomAttributesProvider, $.$RffN.LCCBCM.BuyLinkOrderShipmentTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkOrderModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkPostInteractionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkPostInteractionTypeCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkPostInteractionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkProductModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentModeCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentModeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelCustomAttributesProvider, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.AppUsage.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.AppUsageCustomAttributesProvider, $.$RffN.LCCBCM.AppUsageCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCM.ICommunityBuyLinkProductPoolModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCM.ICommunityBuyLinkProductPoolModelCustomAttributesProvider, $.$RffN.LCCBCM.ICommunityBuyLinkProductPoolModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsCustomAttributesProvider, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCS$1.CommunityBuyLinkSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkSettingsCustomAttributesProvider, $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$RffN.LCCBCS$2.CommunityBuyLinkStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$RffN.LCCBCS$2.CommunityBuyLinkStatesCustomAttributesProvider, $.$RffN.LCCBCS$2.CommunityBuyLinkStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295052655)
            
            static $h = 85359;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295052655),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 85359,
      "h": 4295052655,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295052655)
  ],
  "h": 85359
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85359)
        
        

        //--TRIMMABLE-BOUNDARY-START(3165551)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsCustomAttributesProvider`, ($self) => class CommunityBuyLinkGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298132847)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298132847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298132847)
            
            static $h = 3165551;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298132847),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3165551,
      "h": 4298132847,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298132847)
  ],
  "h": 3165551
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3165551)
        
        

        //--TRIMMABLE-BOUNDARY-START(347503)
        $asm.$cls(`$RffN.LCCBCM.AppUsageCustomAttributesProvider`, ($self) => class AppUsageCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295314799)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295314799)
            
            //--TRIMMABLE-BOUNDARY-START(8590282095)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590282095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RffN.LCCBCM.AppUsageCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Buyer", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Title = "As a Buyer";
                            $i3.Description = "I will be buying using this app";
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Supplier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Title = "As a Supplier";
                            $i4.Description = "I will be supplying goods to users on this app";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RffN.LCCBCM.AppUsageCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MoYRbg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":347503,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MqhBBc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":347503,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590282095)
            
            static $h = 347503;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590282095),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 347503,
      "h": 8590282095,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590282095)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295314799),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 347503,
      "h": 4295314799,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295314799)
  ],
  "h": 347503
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.AppUsageCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}AppUsageCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(347503)
        
        

        //--TRIMMABLE-BOUNDARY-START(1854831)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductModelCustomAttributesProvider`, ($self) => class CommunityBuyLinkProductModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296822127)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296822127)
            
            //--TRIMMABLE-BOUNDARY-START(8591789423)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591789423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RffN.LCCBCM.CommunityBuyLinkProductModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.ExcludeFilter = ($.$RffN.LCCBCM.BuyLinkProductDataTableFilter.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CostInfo", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (3005);
                            $i4.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OffererId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3006);
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IsWaitingForPayment", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RffN.LCCBCM.CommunityBuyLinkProductModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $PhXPAk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1854831,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NUihNc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1854831,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591789423)
            
            static $h = 1854831;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591789423),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1854831,
      "h": 8591789423,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591789423)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296822127),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1854831,
      "h": 4296822127,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296822127)
  ],
  "h": 1854831
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1854831)
        
        

        //--TRIMMABLE-BOUNDARY-START(1592687)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider`, ($self) => class CommunityBuyLinkProductBaseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296559983)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296559983)
            
            //--TRIMMABLE-BOUNDARY-START(8591527279)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591527279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(10, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("QueryState", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3000);
                            $i3.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Quantity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (3001);
                            $i4.Description = "What quantity of this product you want to buy/offer";
                            $i4.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Numeric1"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Url", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3002);
                            $i5.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SiteName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (3003);
                            $i6.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SiteIcon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UnitCost", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (3004);
                            $i8.Description = "At what rate are you willing to buy/sell";
                            $i8.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Cash"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Weight", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (3006);
                            $i9.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HotDeal", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (3007);
                            $i10.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ProductIcons", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IconDescriptor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $gBGOTc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1592687,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $amzABk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1592687,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591527279)
            
            static $h = 1592687;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591527279),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1592687,
      "h": 8591527279,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591527279)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296559983),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1592687,
      "h": 4296559983,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296559983)
  ],
  "h": 1592687
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductBaseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1592687)
        
        

        //--TRIMMABLE-BOUNDARY-START(2116975)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductPoolModelCustomAttributesProvider`, ($self) => class CommunityBuyLinkProductPoolModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297084271)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297084271)
            
            //--TRIMMABLE-BOUNDARY-START(8592051567)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592051567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PaymentMode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Description = "How will someone pay for this product. Pay when joining or later";
                            $i3.Order = (4001);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=ContactlessPayment"], [-1], null);
                            $i3.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PoolStartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Description = "When can people start joining this pool. Empty indicates starts immediately";
                            $i4.Order = (4002);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Alarm"], [-1], null);
                            $i4.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PoolEndDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Description = "When should people stop joining this pool. Empty indicates ends indefinitely";
                            $i5.Order = (4003);
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=AlarmCheck"], [-1], null);
                            $i5.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Queries", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xTbYIc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2116975,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $DtgSqa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2116975,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592051567)
            
            static $h = 2116975;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592051567),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2116975,
      "h": 8592051567,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592051567)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297084271),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2116975,
      "h": 4297084271,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297084271)
  ],
  "h": 2116975
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductPoolModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2116975)
        
        

        //--TRIMMABLE-BOUNDARY-START(1330543)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkPoolPaymentModeCustomAttributesProvider`, ($self) => class CommunityBuyLinkPoolPaymentModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296297839)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296297839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296297839)
            
            static $h = 1330543;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296297839),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1330543,
      "h": 4296297839,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296297839)
  ],
  "h": 1330543
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkPoolPaymentModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkPoolPaymentModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1330543)
        
        

        //--TRIMMABLE-BOUNDARY-START(150895)
        $asm.$cls(`$RffN.LCCBC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295118191)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295118191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295118191)
            
            static $h = 150895;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295118191),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 150895,
      "h": 4295118191,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295118191)
  ],
  "h": 150895
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150895)
        
        

        //--TRIMMABLE-BOUNDARY-START(871791)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590806383)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590806383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $szQDld ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":871791,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCM.CommunityBuyLinkModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590806383)
            
            //--TRIMMABLE-BOUNDARY-START(4295839087)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295839087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295839087)
            
            //--TRIMMABLE-BOUNDARY-START(4295839087)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295839087)
            
            static $h = 871791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590806383),
    {
      "r": 65537,
      "n": "Register",
      "d": 871791,
      "h": 8590806383,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590806383)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295839087),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 871791,
      "h": 4295839087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295839087)
  ],
  "h": 871791
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(871791)
        
        

        //--TRIMMABLE-BOUNDARY-START(216431)
        $asm.$cls(`$RffN.LCCBC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295183727)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295183727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService, $.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService_Mocking().$ctor$3(impl);
                }, $QtjCRa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService_Mocking().$ctor$3(impl);
                }, $AuQNae ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService, $.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking().$ctor$3(impl);
                }, $Upbgah ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking().$ctor$3(impl);
                }, $qkBYKe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$RffN.LCCBCS.IComunityBuyLinkRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$RffN.LCCBCS.IComunityBuyLinkRemoteService_Mocking().$ctor$3(impl);
                }, $GEOdrk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $cQVJKc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $sDcEqh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $qqpkqk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $DsvIpj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $syIBnd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $EPPpZj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking().$ctor$3(impl);
                }, $QOAXik ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $SIbeRk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $MaHgfj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $qfaXti ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $zaqJbd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $igqkih ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $IonvJd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking().$ctor$3(impl);
                }, $TZxMFc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":216431,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295183727)
            
            static $h = 216431;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295183727),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 216431,
      "h": 4295183727,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295183727)
  ],
  "h": 216431
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216431)
        
        

        //--TRIMMABLE-BOUNDARY-START(1985903)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkProductModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591920495)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591920495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PPhgPb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1985903,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591920495)
            
            //--TRIMMABLE-BOUNDARY-START(4296953199)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296953199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296953199)
            
            //--TRIMMABLE-BOUNDARY-START(4296953199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296953199)
            
            static $h = 1985903;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591920495),
    {
      "r": 65537,
      "n": "Register",
      "d": 1985903,
      "h": 8591920495,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591920495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296953199),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1985903,
      "h": 4296953199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296953199)
  ],
  "h": 1985903
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1985903)
        
        

        //--TRIMMABLE-BOUNDARY-START(3558767)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593493359)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593493359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nkqGGe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3558767,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCS$1.CommunityBuyLinkSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593493359)
            
            //--TRIMMABLE-BOUNDARY-START(4298526063)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298526063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298526063)
            
            //--TRIMMABLE-BOUNDARY-START(4298526063)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298526063)
            
            static $h = 3558767;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593493359),
    {
      "r": 65537,
      "n": "Register",
      "d": 3558767,
      "h": 8593493359,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593493359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298526063),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3558767,
      "h": 4298526063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298526063)
  ],
  "h": 3558767
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3558767)
        
        

        //--TRIMMABLE-BOUNDARY-START(3034479)
        $asm.$cls(`$RffN.LCCBCS.ServiceFilters`, ($self) => class ServiceFilters
        {
            //--TRIMMABLE-BOUNDARY-START(201866497391)
            static /*DataFilter */ get TodayOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741856/*PostFilterTypes.Today*/, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(201866497391)
            
            //--TRIMMABLE-BOUNDARY-START(171801726319)
            static /*DataFilter */ get PendingOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t1 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t2 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i2 = new $t2();
                        $i2.$ctor$3();
                        $i2.Type = "QueryState";
                        $i2.NValue = 0/*PostQueryableState.Submitted*/;
                        return $i2;
                    })()], [-1], null);
                    return $i1;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(171801726319)
            
            //--TRIMMABLE-BOUNDARY-START(193276562799)
            static /*DataFilter */ get QueriedOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t3 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t4 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i4 = new $t4();
                        $i4.$ctor$3();
                        $i4.Type = "QueryState";
                        $i4.NValue = 1024/*PostQueryableState.Queried*/;
                        return $i4;
                    })()], [-1], null);
                    return $i3;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(193276562799)
            
            //--TRIMMABLE-BOUNDARY-START(4298001775)
            static /*DataFilter */ get AnsweredOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t5 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t6 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i6 = new $t6();
                        $i6.$ctor$3();
                        $i6.Type = "QueryState";
                        $i6.NValue = 2048/*PostQueryableState.QueryAnswered*/;
                        return $i6;
                    })()], [-1], null);
                    return $i5;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(4298001775)
            
            //--TRIMMABLE-BOUNDARY-START(12887936367)
            static /*DataFilter */ get AwaitingPaymentOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t7 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t8 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i8 = new $t8();
                        $i8.$ctor$3();
                        $i8.Type = "QueryState";
                        $i8.NValue = 3072/*PostQueryableState.AwaitingPayment*/;
                        return $i8;
                    })()], [-1], null);
                    return $i7;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12887936367)
            
            //--TRIMMABLE-BOUNDARY-START(21477870959)
            static /*DataFilter */ get CanceledOrderFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t9 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t10 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i10 = new $t10();
                        $i10.$ctor$3();
                        $i10.Type = "QueryState";
                        $i10.NValue = 2147483647/*PostQueryableState.Canceled*/;
                        return $i10;
                    })()], [-1], null);
                    return $i9;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21477870959)
            
            //--TRIMMABLE-BOUNDARY-START(206161464687)
            static /*DataFilter */ get TodayProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741856/*PostFilterTypes.Today*/, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(206161464687)
            
            //--TRIMMABLE-BOUNDARY-START(176096693615)
            static /*DataFilter */ get PendingProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t11 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i11 = new $t11();
                    $i11.$ctor$1();
                    $i11.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t12 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i12 = new $t12();
                        $i12.$ctor$3();
                        $i12.Type = "QueryState";
                        $i12.NValue = 0/*PostQueryableState.Submitted*/;
                        return $i12;
                    })()], [-1], null);
                    return $i11;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(176096693615)
            
            //--TRIMMABLE-BOUNDARY-START(197571530095)
            static /*DataFilter */ get QueriedProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t13 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i13 = new $t13();
                    $i13.$ctor$1();
                    $i13.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t14 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i14 = new $t14();
                        $i14.$ctor$3();
                        $i14.Type = "QueryState";
                        $i14.NValue = 1024/*PostQueryableState.Queried*/;
                        return $i14;
                    })()], [-1], null);
                    return $i13;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(197571530095)
            
            //--TRIMMABLE-BOUNDARY-START(8592969071)
            static /*DataFilter */ get AnsweredProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t15 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i15 = new $t15();
                    $i15.$ctor$1();
                    $i15.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t16 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i16 = new $t16();
                        $i16.$ctor$3();
                        $i16.Type = "QueryState";
                        $i16.NValue = 2048/*PostQueryableState.QueryAnswered*/;
                        return $i16;
                    })()], [-1], null);
                    return $i15;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8592969071)
            
            //--TRIMMABLE-BOUNDARY-START(17182903663)
            static /*DataFilter */ get AwaitingPaymentProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t17 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i17 = new $t17();
                    $i17.$ctor$1();
                    $i17.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t18 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i18 = new $t18();
                        $i18.$ctor$3();
                        $i18.Type = "QueryState";
                        $i18.NValue = 3072/*PostQueryableState.AwaitingPayment*/;
                        return $i18;
                    })()], [-1], null);
                    return $i17;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17182903663)
            
            //--TRIMMABLE-BOUNDARY-START(167506759023)
            static /*DataFilter */ get PaidProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t19 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i19 = new $t19();
                    $i19.$ctor$1();
                    $i19.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t20 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i20 = new $t20();
                        $i20.$ctor$3();
                        $i20.Type = "QueryState";
                        $i20.NValue = 4096/*PostQueryableState.Paid*/;
                        return $i20;
                    })()], [-1], null);
                    return $i19;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(167506759023)
            
            //--TRIMMABLE-BOUNDARY-START(184686628207)
            static /*DataFilter */ get ProcessingProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t21 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i21 = new $t21();
                    $i21.$ctor$1();
                    $i21.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t22 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i22 = new $t22();
                        $i22.$ctor$3();
                        $i22.Type = "QueryState";
                        $i22.NValue = 5120/*PostQueryableState.Processing*/;
                        return $i22;
                    })()], [-1], null);
                    return $i21;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(184686628207)
            
            //--TRIMMABLE-BOUNDARY-START(180391660911)
            static /*DataFilter */ get ProcessedProductFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$1().WithAttribute$2($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741853/*PostFilterTypes.Search*/, 0).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t23 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i23 = new $t23();
                    $i23.$ctor$1();
                    $i23.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t24 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i24 = new $t24();
                        $i24.$ctor$3();
                        $i24.Type = "QueryState";
                        $i24.NValue = 7168/*PostQueryableState.Processed*/;
                        return $i24;
                    })()], [-1], null);
                    return $i23;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(180391660911)
            
            //--TRIMMABLE-BOUNDARY-START(163211791727)
            static /*IDictionary<string, DataFilter> */ get Orders()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)()
                    const $t25 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter);
                    const $i25 = new $t25();
                    $i25.$ctor$1();
                    $i25.Add("All", new $.$fPer.LCFCD.DataFilter().$ctor$1());
                    $i25.Add("Today", $.$RffN.LCCBCS.ServiceFilters.TodayOrderFilter);
                    $i25.Add("Pending", $.$RffN.LCCBCS.ServiceFilters.PendingOrderFilter);
                    $i25.Add("Queried", $.$RffN.LCCBCS.ServiceFilters.QueriedOrderFilter);
                    $i25.Add("Answered", $.$RffN.LCCBCS.ServiceFilters.AnsweredOrderFilter);
                    $i25.Add("Awaiting Payment", $.$RffN.LCCBCS.ServiceFilters.AwaitingPaymentOrderFilter);
                    $i25.Add("Canceled", $.$RffN.LCCBCS.ServiceFilters.CanceledOrderFilter);
                    return $i25;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(163211791727)
            
            //--TRIMMABLE-BOUNDARY-START(188981595503)
            static /*IDictionary<string, DataFilter> */ get Products()
            {
                return (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter)()
                    const $t26 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter);
                    const $i26 = new $t26();
                    $i26.$ctor$1();
                    $i26.Add("All", new $.$fPer.LCFCD.DataFilter().$ctor$1());
                    $i26.Add("Today", $.$RffN.LCCBCS.ServiceFilters.TodayProductFilter);
                    $i26.Add("Pending", $.$RffN.LCCBCS.ServiceFilters.PendingProductFilter);
                    $i26.Add("Queried", $.$RffN.LCCBCS.ServiceFilters.QueriedProductFilter);
                    $i26.Add("Answered", $.$RffN.LCCBCS.ServiceFilters.AnsweredProductFilter);
                    $i26.Add("Awaiting Payment", $.$RffN.LCCBCS.ServiceFilters.AwaitingPaymentProductFilter);
                    $i26.Add("Paid", $.$RffN.LCCBCS.ServiceFilters.PaidProductFilter);
                    $i26.Add("Processing", $.$RffN.LCCBCS.ServiceFilters.ProcessingProductFilter);
                    $i26.Add("Processed", $.$RffN.LCCBCS.ServiceFilters.ProcessedProductFilter);
                    return $i26;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(188981595503)
            
            static $h = 3034479;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(201866497391),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326889839,
        "f": 50331681
      },
      "n": "TodayOrderFilter",
      "d": 3034479,
      "h": 201866497391,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(201866497391),
//--TRIMMABLE-BOUNDARY-START(171801726319),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197347695,
        "f": 50331681
      },
      "n": "PendingOrderFilter",
      "d": 3034479,
      "h": 171801726319,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(171801726319),
//--TRIMMABLE-BOUNDARY-START(193276562799),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133147020655,
        "f": 50331681
      },
      "n": "QueriedOrderFilter",
      "d": 3034479,
      "h": 193276562799,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193276562799),
//--TRIMMABLE-BOUNDARY-START(4298001775),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067805551,
        "f": 50331681
      },
      "n": "AnsweredOrderFilter",
      "d": 3034479,
      "h": 4298001775,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4298001775),
//--TRIMMABLE-BOUNDARY-START(12887936367),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247674735,
        "f": 50331681
      },
      "n": "AwaitingPaymentOrderFilter",
      "d": 3034479,
      "h": 12887936367,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12887936367),
//--TRIMMABLE-BOUNDARY-START(21477870959),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427543919,
        "f": 50331681
      },
      "n": "CanceledOrderFilter",
      "d": 3034479,
      "h": 21477870959,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21477870959),
//--TRIMMABLE-BOUNDARY-START(206161464687),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158916824431,
        "f": 50331681
      },
      "n": "TodayProductFilter",
      "d": 3034479,
      "h": 206161464687,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(206161464687),
//--TRIMMABLE-BOUNDARY-START(176096693615),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787282287,
        "f": 50331681
      },
      "n": "PendingProductFilter",
      "d": 3034479,
      "h": 176096693615,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(176096693615),
//--TRIMMABLE-BOUNDARY-START(197571530095),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736955247,
        "f": 50331681
      },
      "n": "QueriedProductFilter",
      "d": 3034479,
      "h": 197571530095,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197571530095),
//--TRIMMABLE-BOUNDARY-START(8592969071),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657740143,
        "f": 50331681
      },
      "n": "AnsweredProductFilter",
      "d": 3034479,
      "h": 8592969071,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8592969071),
//--TRIMMABLE-BOUNDARY-START(17182903663),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837609327,
        "f": 50331681
      },
      "n": "AwaitingPaymentProductFilter",
      "d": 3034479,
      "h": 17182903663,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17182903663),
//--TRIMMABLE-BOUNDARY-START(167506759023),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607413103,
        "f": 50331681
      },
      "n": "PaidProductFilter",
      "d": 3034479,
      "h": 167506759023,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(167506759023),
//--TRIMMABLE-BOUNDARY-START(184686628207),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967151471,
        "f": 50331681
      },
      "n": "ProcessingProductFilter",
      "d": 3034479,
      "h": 184686628207,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184686628207),
//--TRIMMABLE-BOUNDARY-START(180391660911),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377216879,
        "f": 50331681
      },
      "n": "ProcessedProductFilter",
      "d": 3034479,
      "h": 180391660911,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180391660911),
//--TRIMMABLE-BOUNDARY-START(163211791727),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017478511,
        "f": 50331681
      },
      "n": "Orders",
      "d": 3034479,
      "h": 163211791727,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(163211791727),
//--TRIMMABLE-BOUNDARY-START(188981595503),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$fPer.LCFCD.DataFilter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124557086063,
        "f": 50331681
      },
      "n": "Products",
      "d": 3034479,
      "h": 188981595503,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188981595503)
  ],
  "h": 3034479
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.ServiceFilters`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}ServiceFilters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3034479)
        
        

        //--TRIMMABLE-BOUNDARY-START(3296623)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593231215)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593231215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EXemai ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3296623,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593231215)
            
            //--TRIMMABLE-BOUNDARY-START(4298263919)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298263919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298263919)
            
            //--TRIMMABLE-BOUNDARY-START(4298263919)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298263919)
            
            static $h = 3296623;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593231215),
    {
      "r": 65537,
      "n": "Register",
      "d": 3296623,
      "h": 8593231215,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593231215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298263919),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3296623,
      "h": 4298263919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298263919)
  ],
  "h": 3296623
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3296623)
        
        

        //--TRIMMABLE-BOUNDARY-START(3820911)
        $asm.$cls(`$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593755503)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593755503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KeGsge ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3820911,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCS$2.CommunityBuyLinkStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593755503)
            
            //--TRIMMABLE-BOUNDARY-START(4298788207)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298788207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298788207)
            
            //--TRIMMABLE-BOUNDARY-START(4298788207)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298788207)
            
            static $h = 3820911;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593755503),
    {
      "r": 65537,
      "n": "Register",
      "d": 3820911,
      "h": 8593755503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593755503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298788207),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3820911,
      "h": 4298788207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298788207)
  ],
  "h": 3820911
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}States${separator}CommunityBuyLinkStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3820911)
        
        

        //--TRIMMABLE-BOUNDARY-START(1133935)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkOrderModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591068527)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591068527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tasSPc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1133935,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591068527)
            
            //--TRIMMABLE-BOUNDARY-START(4296101231)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296101231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296101231)
            
            //--TRIMMABLE-BOUNDARY-START(4296101231)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296101231)
            
            static $h = 1133935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591068527),
    {
      "r": 65537,
      "n": "Register",
      "d": 1133935,
      "h": 8591068527,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591068527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296101231),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1133935,
      "h": 4296101231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296101231)
  ],
  "h": 1133935
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkOrderModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1133935)
        
        

        //--TRIMMABLE-BOUNDARY-START(1002863)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkOrderModelCustomAttributesProvider`, ($self) => class CommunityBuyLinkOrderModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295970159)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295970159)
            
            //--TRIMMABLE-BOUNDARY-START(8590937455)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590937455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$RffN.LCCBCM.CommunityBuyLinkOrderModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(19, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.ExcludeFilter = ($.$RffN.LCCBCM.BuyLinkOrderDataTableFilter.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("QueryState", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2999);
                            $i4.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ShipmentId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DatePaid", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (3000);
                            $i6.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PaymentReference", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (3001);
                            $i7.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FreightShipment", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (3002);
                            $i8.Description = "How do we ship your order to Nigeria. Note that express shiment is faster but more costly";
                            $i8.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Delivery", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (3003);
                            $i9.Description = "How do we deliver to you in Nigeria";
                            $i9.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DeliveryAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (3004);
                            $i10.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            $i10.ExcludeFilter = ($.$YUlm.LCSCM.DeliveryInfoFilter.$type);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PickupLocation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Order = (3005);
                            $i11.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            $i11.ExcludeFilter = ($.$YUlm.LCSCM.DeliveryInfoFilter.$type);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DeliveryLocation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Order = (3005);
                            $i12.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            $i12.ExcludeFilter = ($.$YUlm.LCSCM.DeliveryInfoFilter.$type);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DateDelivered", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Order = (3006);
                            $i13.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DateConfirmed", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Order = (3007);
                            $i14.Exclude = $.$cast((16777209), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisplayIcon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IconDescriptor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Sender", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t17 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$4();
                            $i17.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Receiver", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t18 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$4();
                            $i18.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Products", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t19 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i19 = new $t19();
                            $i19.$ctor$4();
                            $i19.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i19;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t20 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i20 = new $t20();
                            $i20.$ctor$4();
                            $i20.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i20;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Weight", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t21 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i21 = new $t21();
                            $i21.$ctor$4();
                            $i21.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i21;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$RffN.LCCBCM.CommunityBuyLinkOrderModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UGJNpj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1002863,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ZBBzjl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1002863,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590937455)
            
            static $h = 1002863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590937455),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1002863,
      "h": 8590937455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590937455)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295970159),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1002863,
      "h": 4295970159,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295970159)
  ],
  "h": 1002863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkOrderModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1002863)
        
        

        //--TRIMMABLE-BOUNDARY-START(1723759)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkProductBaseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591658351)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591658351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JHVMpf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1723759,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591658351)
            
            //--TRIMMABLE-BOUNDARY-START(4296691055)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296691055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296691055)
            
            //--TRIMMABLE-BOUNDARY-START(4296691055)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296691055)
            
            static $h = 1723759;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591658351),
    {
      "r": 65537,
      "n": "Register",
      "d": 1723759,
      "h": 8591658351,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591658351)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296691055),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1723759,
      "h": 4296691055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296691055)
  ],
  "h": 1723759
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductBaseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1723759)
        
        

        //--TRIMMABLE-BOUNDARY-START(3886447)
        $asm.$cls(`$RffN.LCCBC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298853743)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298853743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptorBuilder.Register();
                $.$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298853743)
            
            static $h = 3886447;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298853743),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3886447,
      "h": 4298853743,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298853743)
  ],
  "h": 3886447
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3886447)
        
        

        //--TRIMMABLE-BOUNDARY-START(2248047)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptorBuilder`, ($self) => class CommunityBuyLinkProductPoolModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592182639)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592182639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor()
                        const $t1 = $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $JtlsTk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2248047,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592182639)
            
            //--TRIMMABLE-BOUNDARY-START(4297215343)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297215343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297215343)
            
            //--TRIMMABLE-BOUNDARY-START(4297215343)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297215343)
            
            static $h = 2248047;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592182639),
    {
      "r": 65537,
      "n": "Register",
      "d": 2248047,
      "h": 8592182639,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592182639)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297215343),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2248047,
      "h": 4297215343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297215343)
  ],
  "h": 2248047
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductPoolModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2248047)
        
        

        //--TRIMMABLE-BOUNDARY-START(2575727)
        $asm.$cls(`$RffN.LCCBC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592510319)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592510319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$RffN.LCCBCM.CommunityBuyLinkProductModel, 5121/*PostTypes.BuyLinkProduct*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, 5123/*PostTypes.BuyLinkProductPool*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, 5122/*PostTypes.BuyLinkOrder*/);
                $.$RffN.LCCBC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$RffN.LCCBC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$RffN.LCCBC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592510319)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$RffN.LCCBC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297543023)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297543023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297543023)
            
            //--TRIMMABLE-BOUNDARY-START(4297543023)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297543023)
            
            static $h = 2575727;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592510319),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2575727,
      "h": 8592510319,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592510319)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297543023),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2575727,
      "h": 4297543023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297543023)
  ],
  "h": 2575727
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2575727)
        
        

        //--TRIMMABLE-BOUNDARY-START(609647)
        $asm.$cls(`$RffN.LCCBCM.BuyLinkProductDataTableFilter`, ($self) => class BuyLinkProductDataTableFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590544239)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590544239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schema.Type === 4/*SchemaType.DataTable*/)
                {
                    /*var*/ let exclude = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Tags", "IconDescriptor", "Summary", "SiteIcon", "SiteName", "Url", "UnitCost"], null, null);
                    return !$.$sl.SL.Enumerable.Any($.$$.S.String, exclude, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                    {
                        return e === typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name;
                    }, $dZgKMc ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":609647,"h":0,"f":17825794}));
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8590544239)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4295576943)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295576943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295576943)
            
            //--TRIMMABLE-BOUNDARY-START(4295576943)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295576943)
            
            static $h = 609647;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590544239),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 609647,
      "h": 8590544239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590544239)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295576943),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 609647,
      "h": 4295576943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295576943)
  ],
  "h": 609647
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.BuyLinkProductDataTableFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}BuyLinkProductDataTableFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(609647)
        
        

        //--TRIMMABLE-BOUNDARY-START(413039)
        $asm.$cls(`$RffN.LCCBCM.BuyLinkOrderDataTableFilter`, ($self) => class BuyLinkOrderDataTableFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590347631)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590347631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schema.Type === 4/*SchemaType.DataTable*/)
                {
                    /*var*/ let exclude = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Tags", "Icon", "DatePaid", "PaymentReference", "DeliveryAddress", "DeliveryLocation", "DateDelivered", "DateConfirmed"], null, null);
                    return !$.$sl.SL.Enumerable.Any($.$$.S.String, exclude, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                    {
                        return typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name === e;
                    }, $hbOHod ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":413039,"h":0,"f":17825794}));
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8590347631)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4295380335)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295380335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295380335)
            
            //--TRIMMABLE-BOUNDARY-START(4295380335)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295380335)
            
            static $h = 413039;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590347631),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 413039,
      "h": 8590347631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590347631)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295380335),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 413039,
      "h": 4295380335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295380335)
  ],
  "h": 413039
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.BuyLinkOrderDataTableFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}BuyLinkOrderDataTableFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(413039)
        
        

        //--TRIMMABLE-BOUNDARY-START(1199471)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkPoolInteractionData`, ($self) => class CommunityBuyLinkPoolInteractionData extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835774319)
            /*int*/ Quantity = 0;
            //--TRIMMABLE-BOUNDARY-END(55835774319)
            
            //--TRIMMABLE-BOUNDARY-START(51540807023)
            /*string?*/ PaymentReference = null;
            //--TRIMMABLE-BOUNDARY-END(51540807023)
            
            //--TRIMMABLE-BOUNDARY-START(21476035951)
            /*IEnumerable<IQueryAnswer>?*/ Answers = null;
            //--TRIMMABLE-BOUNDARY-END(21476035951)
            
            //--TRIMMABLE-BOUNDARY-START(12906629462)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IQueryAnswers.Answers.get
            get LCFCD$IQueryAnswers$Answers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4316694870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Answers;
            }
            //--TRIMMABLE-BOUNDARY-END(12906629462)
            
            //--TRIMMABLE-BOUNDARY-START(17181068655)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181068655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181068655)
            
            //--TRIMMABLE-BOUNDARY-START(17181068655)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181068655)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835774319)
                this.Quantity = 1;
                //--TRIMMABLE-BOUNDARY-END(55835774319)
                
            }
            static $h = 1199471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835774319),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245839727,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605578095,
        "f": 83886081
      },
      "n": "Quantity",
      "d": 1199471,
      "h": 55835774319,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How many products you want from the pool",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835774319),
//--TRIMMABLE-BOUNDARY-START(51540807023),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655905135,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015643503,
        "f": 83886081
      },
      "n": "PaymentReference",
      "d": 1199471,
      "h": 51540807023,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540807023),
//--TRIMMABLE-BOUNDARY-START(21476035951),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryAnswer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065970543,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425708911,
        "f": 83886081
      },
      "n": "Answers",
      "d": 1199471,
      "h": 21476035951,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 1,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476035951)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181068655),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1199471,
      "h": 17181068655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181068655)
  ],
  "h": 1199471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCP.IPostQueryableUserAnswersStore, $.$fPer.LCFCD.IQueryAnswers ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkPoolInteractionData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkPoolInteractionData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1199471)
        
        

        //--TRIMMABLE-BOUNDARY-START(2968943)
        $asm.$cls(`$RffN.LCCBCS.IComunityBuyLinkRemoteService_Mocking`, ($self) => class IComunityBuyLinkRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297936239)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297936239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297936239)
            
            //--TRIMMABLE-BOUNDARY-START(8592903535)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings>> */ LCCBCS$IComunityBuyLinkRemoteService$GetApplicationSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592903535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$RffN.LCCBCS.IComunityBuyLinkRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings).$type;
                    $i1.MethodName = "GetApplicationSettings";
                    return $i1;
                })();
                return this.InvokeAsync($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592903535)
            
            //--TRIMMABLE-BOUNDARY-START(17182838127)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCCBCS$IComunityBuyLinkRemoteService$ParseProductUrl(/*string*/ url)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182838127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$RffN.LCCBCS.IComunityBuyLinkRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i2.MethodName = "ParseProductUrl";
                    return $i2;
                })();
                return this.InvokeAsync($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, url) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182838127)
            
            //--TRIMMABLE-BOUNDARY-START(12887870831)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCCBCS$IComunityBuyLinkRemoteService$ParseProductPoolUrl(/*string*/ url)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887870831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$RffN.LCCBCS.IComunityBuyLinkRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i3.MethodName = "ParseProductPoolUrl";
                    return $i3;
                })();
                return this.InvokeAsync($.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, url) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887870831)
            
            static $h = 2968943;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297936239),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2968943,
      "h": 4297936239,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297936239)
  ],
  "h": 2968943
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$RffN.LCCBCS.IComunityBuyLinkRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.IComunityBuyLinkRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}IComunityBuyLinkRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2968943)
        
        

        //--TRIMMABLE-BOUNDARY-START(281967)
        $asm.$str(`$RffN.LCCBCM.AppUsage`, ($self) => class AppUsage extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Buyer = 0;
            static Supplier = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(281967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Buyer": 0n,
                    "Supplier": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295249263)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295249263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295249263)
            
            //--TRIMMABLE-BOUNDARY-START(4295249263)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295249263)
            
            static $h = 281967;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590216559),
    {
      "t": 281967,
      "n": "Buyer",
      "d": 281967,
      "h": 8590216559,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "As a Buyer",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "I will be buying using this app",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590216559),
//--TRIMMABLE-BOUNDARY-START(12885183855),
    {
      "t": 281967,
      "n": "Supplier",
      "d": 281967,
      "h": 12885183855,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Title",
              "v": "As a Supplier",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "I will be supplying goods to users on this app",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885183855)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295249263),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 281967,
      "h": 4295249263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295249263)
  ],
  "h": 281967
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.AppUsage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}AppUsage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(281967)
        
        

        //--TRIMMABLE-BOUNDARY-START(1396079)
        $asm.$str(`$RffN.LCCBCM.CommunityBuyLinkPostInteractionType`, ($self) => class CommunityBuyLinkPostInteractionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt64)
        {
            static Pool = 4294967296n;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1396079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Pool": 4294967296n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296363375)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296363375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296363375)
            
            //--TRIMMABLE-BOUNDARY-START(4296363375)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296363375)
            
            static $h = 1396079;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 917505,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591330671),
    {
      "t": 1396079,
      "n": "Pool",
      "d": 1396079,
      "h": 8591330671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591330671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296363375),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1396079,
      "h": 4296363375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296363375)
  ],
  "h": 1396079
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkPostInteractionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkPostInteractionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1396079)
        
        

        //--TRIMMABLE-BOUNDARY-START(1265007)
        $asm.$str(`$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode`, ($self) => class CommunityBuyLinkPoolPaymentMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static PayBeforeJoin = 0;
            static PayLater = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1265007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "PayBeforeJoin": 0n,
                    "PayLater": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296232303)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296232303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296232303)
            
            //--TRIMMABLE-BOUNDARY-START(4296232303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296232303)
            
            static $h = 1265007;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591199599),
    {
      "t": 1265007,
      "n": "PayBeforeJoin",
      "d": 1265007,
      "h": 8591199599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591199599),
//--TRIMMABLE-BOUNDARY-START(12886166895),
    {
      "t": 1265007,
      "n": "PayLater",
      "d": 1265007,
      "h": 12886166895,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886166895)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296232303),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1265007,
      "h": 4296232303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296232303)
  ],
  "h": 1265007
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkPoolPaymentMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkPoolPaymentMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1265007)
        
        

        //--TRIMMABLE-BOUNDARY-START(478575)
        $asm.$str(`$RffN.LCCBCM.BuyLinkOrderShipmentType`, ($self) => class BuyLinkOrderShipmentType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Express = 1;
            static Cargo = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(478575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Express": 1n,
                    "Cargo": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295445871)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295445871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295445871)
            
            //--TRIMMABLE-BOUNDARY-START(4295445871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295445871)
            
            static $h = 478575;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180347759),
    {
      "t": 478575,
      "n": "None",
      "d": 478575,
      "h": 17180347759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180347759),
//--TRIMMABLE-BOUNDARY-START(12885380463),
    {
      "t": 478575,
      "n": "Express",
      "d": 478575,
      "h": 12885380463,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885380463),
//--TRIMMABLE-BOUNDARY-START(8590413167),
    {
      "t": 478575,
      "n": "Cargo",
      "d": 478575,
      "h": 8590413167,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590413167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295445871),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 478575,
      "h": 4295445871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295445871)
  ],
  "h": 478575
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.BuyLinkOrderShipmentType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}BuyLinkOrderShipmentType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478575)
        
        

        //--TRIMMABLE-BOUNDARY-START(2379119)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkUserPreference`, ($self) => class CommunityBuyLinkUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4297346415)
            /*string */ get _()
            {
                return "BuyLink enables you to buy anything awesome online, by just providing the link.\r\n\r\nGive us some information and we'll get you setup right away.";
            }
            //--TRIMMABLE-BOUNDARY-END(4297346415)
            
            //--TRIMMABLE-BOUNDARY-START(42952052079)
            /*AppUsage*/ Usage = 0;
            //--TRIMMABLE-BOUNDARY-END(42952052079)
            
            //--TRIMMABLE-BOUNDARY-START(12887281007)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887281007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887281007)
            
            //--TRIMMABLE-BOUNDARY-START(12887281007)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887281007)
            
            static $h = 2379119;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297346415),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477215599,
        "f": 50331649
      },
      "n": "_",
      "d": 2379119,
      "h": 4297346415,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Welcome to BuyLink",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "Let\u0027s get you started.",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297346415),
//--TRIMMABLE-BOUNDARY-START(42952052079),
    {
      "p": 281967,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067150191,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38657084783,
        "f": 83886081
      },
      "n": "Usage",
      "d": 2379119,
      "h": 42952052079,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Usage",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "How do you want to use BuyLink?",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952052079)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887281007),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2379119,
      "h": 12887281007,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887281007)
  ],
  "h": 2379119
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2379119)
        
        

        //--TRIMMABLE-BOUNDARY-START(3100015)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings`, ($self) => class CommunityBuyLinkGlobalSettings extends $.$Iaui.LCFCMS.ComponentGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(55837674863)
            /*double*/ PercentageCommision = 0;
            //--TRIMMABLE-BOUNDARY-END(55837674863)
            
            //--TRIMMABLE-BOUNDARY-START(25772903791)
            /*Money*/ ExpressShipmentRatePerKg;
            //--TRIMMABLE-BOUNDARY-END(25772903791)
            
            //--TRIMMABLE-BOUNDARY-START(21477936495)
            /*Money*/ CargoShipmentRatePerKg;
            //--TRIMMABLE-BOUNDARY-END(21477936495)
            
            //--TRIMMABLE-BOUNDARY-START(17182969199)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182969199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182969199)
            
            //--TRIMMABLE-BOUNDARY-START(17182969199)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17182969199)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55837674863)
                this.PercentageCommision = 20;
                //--TRIMMABLE-BOUNDARY-END(55837674863)
                
                //--TRIMMABLE-BOUNDARY-START(25772903791)
                this.ExpressShipmentRatePerKg = new $.$fPer.LCFCDM.Money().$ctor$3(10, 1/*MoneyUnitTypes.Naira*/);
                //--TRIMMABLE-BOUNDARY-END(25772903791)
                
                //--TRIMMABLE-BOUNDARY-START(21477936495)
                this.CargoShipmentRatePerKg = new $.$fPer.LCFCDM.Money().$ctor$3(10, 1/*MoneyUnitTypes.Naira*/);
                //--TRIMMABLE-BOUNDARY-END(21477936495)
                
            }
            static $h = 3100015;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837674863),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542707567,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607478639,
        "f": 83886081
      },
      "n": "PercentageCommision",
      "d": 3100015,
      "h": 55837674863,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837674863),
//--TRIMMABLE-BOUNDARY-START(25772903791),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952772975,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017544047,
        "f": 83886081
      },
      "n": "ExpressShipmentRatePerKg",
      "d": 3100015,
      "h": 25772903791,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772903791),
//--TRIMMABLE-BOUNDARY-START(21477936495),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362838383,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427609455,
        "f": 83886081
      },
      "n": "CargoShipmentRatePerKg",
      "d": 3100015,
      "h": 21477936495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477936495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182969199),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3100015,
      "h": 17182969199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182969199)
  ],
  "h": 3100015
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3100015)
        
        

        //--TRIMMABLE-BOUNDARY-START(3362159)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkSettings`, ($self) => class CommunityBuyLinkSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298329455)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298329455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298329455)
            
            //--TRIMMABLE-BOUNDARY-START(4298329455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298329455)
            
            static $h = 3362159;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298329455),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3362159,
      "h": 4298329455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298329455)
  ],
  "h": 3362159
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3362159)
        
        

        //--TRIMMABLE-BOUNDARY-START(3624303)
        $asm.$cls(`$RffN.LCCBCS$2.CommunityBuyLinkStates`, ($self) => class CommunityBuyLinkStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298591599)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298591599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298591599)
            
            //--TRIMMABLE-BOUNDARY-START(4298591599)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298591599)
            
            static $h = 3624303;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298591599),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3624303,
      "h": 4298591599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298591599)
  ],
  "h": 3624303
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}States${separator}CommunityBuyLinkStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3624303)
        
        

        //--TRIMMABLE-BOUNDARY-START(3231087)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor`, ($self) => class CommunityBuyLinkGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298198383)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298198383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor.GenerateProperties($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings, this, factory);
                    }, $woXUhd ??= {"r":65537,"n":"","d":3231087,"h":0,"f":17825794}), 0, "CommunityBuyLinkGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Settings_CommunityBuyLinkGlobalSettings_LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettingsTypeDescriptorBuilder.g.cs", "CommunityBuyLinkGlobalSettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298198383)
            
            //--TRIMMABLE-BOUNDARY-START(12888132975)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888132975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PercentageCommision"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings.$type, $.$discardRef(), "PercentageCommision", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PercentageCommision")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PercentageCommision";
                        $i1.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)).PercentageCommision);
                        }, $Sriuzf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3231087,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PercentageCommision = value.AsDouble();
                        }, $BfVJVe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3231087,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ExpressShipmentRatePerKg"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings.$type, $.$discardRef(), "ExpressShipmentRatePerKg", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ExpressShipmentRatePerKg")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ExpressShipmentRatePerKg";
                        $i3.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)).ExpressShipmentRatePerKg);
                        }, $DuBCnf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3231087,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ExpressShipmentRatePerKg = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $uFaYFb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3231087,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CargoShipmentRatePerKg"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings.$type, $.$discardRef(), "CargoShipmentRatePerKg", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CargoShipmentRatePerKg")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "CargoShipmentRatePerKg";
                        $i5.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)).CargoShipmentRatePerKg);
                        }, $sFFcAf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3231087,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.CargoShipmentRatePerKg = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $izYIbf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3231087,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888132975)
            
            //--TRIMMABLE-BOUNDARY-START(17183100271)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183100271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentGlobalSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentGlobalSettings));
                {
                    /*var*/ let _PercentageCommision = _target.PercentageCommision;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PercentageCommision"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _PercentageCommision, ($v) => _PercentageCommision = $v, $.$$.S.Double)))
                    {
                        _target.PercentageCommision = _PercentageCommision;
                    }
                }
                {
                    /*var*/ let _ExpressShipmentRatePerKg = _target.ExpressShipmentRatePerKg;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ExpressShipmentRatePerKg"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _ExpressShipmentRatePerKg, ($v) => _ExpressShipmentRatePerKg = $v, null, true)))
                    {
                        _target.ExpressShipmentRatePerKg = $.$clone(_ExpressShipmentRatePerKg);
                    }
                }
                {
                    /*var*/ let _CargoShipmentRatePerKg = _target.CargoShipmentRatePerKg;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CargoShipmentRatePerKg"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _CargoShipmentRatePerKg, ($v) => _CargoShipmentRatePerKg = $v, null, true)))
                    {
                        _target.CargoShipmentRatePerKg = $.$clone(_CargoShipmentRatePerKg);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183100271)
            
            //--TRIMMABLE-BOUNDARY-START(8593165679)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593165679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings)))
                {
                    /*var*/ let result = $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593165679)
            
            static $h = 3231087;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888132975),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3231087,
      "h": 12888132975,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888132975),
//--TRIMMABLE-BOUNDARY-START(17183100271),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3100015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3231087,
      "h": 17183100271,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183100271),
//--TRIMMABLE-BOUNDARY-START(8593165679),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3100015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3231087,
      "h": 8593165679,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593165679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298198383),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3231087,
      "h": 4298198383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298198383)
  ],
  "h": 3231087
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3231087)
        
        

        //--TRIMMABLE-BOUNDARY-START(3493231)
        $asm.$cls(`$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptor`, ($self) => class CommunityBuyLinkSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298460527)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298460527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptor.GenerateProperties($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, this, factory);
                    }, $GyBGbd ??= {"r":65537,"n":"","d":3493231,"h":0,"f":17825794}), 0, "CommunityBuyLinkSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Settings_CommunityBuyLinkSettings_LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettingsTypeDescriptorBuilder.g.cs", "CommunityBuyLinkSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298460527)
            
            //--TRIMMABLE-BOUNDARY-START(12888395119)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888395119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888395119)
            
            //--TRIMMABLE-BOUNDARY-START(17183362415)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183362415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183362415)
            
            //--TRIMMABLE-BOUNDARY-START(8593427823)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593427823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCS$1.CommunityBuyLinkSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCS$1.CommunityBuyLinkSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkSettings)))
                {
                    /*var*/ let result = $.$RffN.LCCBCS$1.CommunityBuyLinkSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCS$1.CommunityBuyLinkSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$1.CommunityBuyLinkSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593427823)
            
            static $h = 3493231;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888395119),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3493231,
      "h": 12888395119,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888395119),
//--TRIMMABLE-BOUNDARY-START(17183362415),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3362159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3493231,
      "h": 17183362415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183362415),
//--TRIMMABLE-BOUNDARY-START(8593427823),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3362159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3493231,
      "h": 8593427823,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593427823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298460527),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3493231,
      "h": 4298460527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298460527)
  ],
  "h": 3493231
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Settings${separator}CommunityBuyLinkSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3493231)
        
        

        //--TRIMMABLE-BOUNDARY-START(3755375)
        $asm.$cls(`$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptor`, ($self) => class CommunityBuyLinkStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$2.CommunityBuyLinkStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298722671)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298722671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptor.GenerateProperties($.$RffN.LCCBCS$2.CommunityBuyLinkStates, this, factory);
                    }, $nJKmVi ??= {"r":65537,"n":"","d":3755375,"h":0,"f":17825794}), 0, "CommunityBuyLinkStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\States_CommunityBuyLinkStates_LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStatesTypeDescriptorBuilder.g.cs", "CommunityBuyLinkStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298722671)
            
            //--TRIMMABLE-BOUNDARY-START(12888657263)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888657263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888657263)
            
            //--TRIMMABLE-BOUNDARY-START(17183624559)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183624559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183624559)
            
            //--TRIMMABLE-BOUNDARY-START(8593689967)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593689967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCS$2.CommunityBuyLinkStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCS$2.CommunityBuyLinkStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$2.CommunityBuyLinkStates)))
                {
                    /*var*/ let result = $.$RffN.LCCBCS$2.CommunityBuyLinkStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$2.CommunityBuyLinkStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCS$2.CommunityBuyLinkStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCS$2.CommunityBuyLinkStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593689967)
            
            static $h = 3755375;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCS$2.CommunityBuyLinkStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888657263),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3755375,
      "h": 12888657263,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888657263),
//--TRIMMABLE-BOUNDARY-START(17183624559),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3624303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3755375,
      "h": 17183624559,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183624559),
//--TRIMMABLE-BOUNDARY-START(8593689967),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3624303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3755375,
      "h": 8593689967,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593689967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298722671),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3755375,
      "h": 4298722671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298722671)
  ],
  "h": 3755375
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCS$2.CommunityBuyLinkStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}States${separator}CommunityBuyLinkStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3755375)
        
        

        $asm.$typeProxy("$RffN.LCCBCM.CommunityBuyLinkOrderModel", "$RffN.LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel");
        //--TRIMMABLE-BOUNDARY-START(1527151)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductBaseModel`, ($self) => class CommunityBuyLinkProductBaseModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(111670676847)
            /*string*/ static HotDealsFeaturedAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(111670676847)
            
            //--TRIMMABLE-BOUNDARY-START(133145513327)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133145513327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133145513327)
            
            //--TRIMMABLE-BOUNDARY-START(128850546031)
            /*PostQueryableState */ get QueryState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836101999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$LCOv.LCFCP.PostQueryableState, 0, "QueryState", null);
            }
            /*PostQueryableState */ set QueryState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505251695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$LCOv.LCFCP.PostQueryableState, value, "QueryState");
            }
            //--TRIMMABLE-BOUNDARY-END(128850546031)
            
            //--TRIMMABLE-BOUNDARY-START(124555578735)
            /*int */ get Quantity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246167407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 1, "Quantity", "BuyLinkProductQuantity");
            }
            /*int */ set Quantity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915317103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Quantity");
            }
            //--TRIMMABLE-BOUNDARY-END(124555578735)
            
            //--TRIMMABLE-BOUNDARY-START(227634793839)
            /*string? */ get Url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195840367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "Url", "BuyLinkProductUrl");
            }
            /*string? */ set Url(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864990063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Url");
            }
            //--TRIMMABLE-BOUNDARY-END(227634793839)
            
            //--TRIMMABLE-BOUNDARY-START(219044859247)
            /*string? */ get SiteName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015971183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "SiteName", "BuyLinkProductSiteName");
            }
            /*string? */ set SiteName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685120879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "SiteName");
            }
            //--TRIMMABLE-BOUNDARY-END(219044859247)
            
            //--TRIMMABLE-BOUNDARY-START(214749891951)
            /*string? */ get SiteIcon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426036591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "SiteIcon", null);
            }
            /*string? */ set SiteIcon(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095186287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "SiteIcon");
            }
            //--TRIMMABLE-BOUNDARY-END(214749891951)
            
            //--TRIMMABLE-BOUNDARY-START(223339826543)
            /*Money */ get UnitCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605905775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money(), "UnitCost", "BuyLinkProductCost");
            }
            /*Money */ set UnitCost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275055471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "UnitCost");
                if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, value) && this.QueryState < 3072/*PostQueryableState.AwaitingPayment*/ && $.$is(this, $.$LCOv.LCFCP.IPostSinglePriceOfferable))
                {
                    this.QueryState = 3072/*PostQueryableState.AwaitingPayment*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339826543)
            
            //--TRIMMABLE-BOUNDARY-START(231929761135)
            /*Weight */ get Weight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785774959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Weight, new $.$fPer.LCFCDM.Weight(), "Weight", null);
            }
            /*Weight */ set Weight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454924655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Weight, $.$clone(value), "Weight");
            }
            //--TRIMMABLE-BOUNDARY-END(231929761135)
            
            //--TRIMMABLE-BOUNDARY-START(107375709551)
            /*bool */ get HotDeal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476363631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "HotDeal", null) === "hotdeals"/*HotDealsFeaturedAttribute*/;
            }
            /*bool */ set HotDeal(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735447919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value ? "hotdeals"/*HotDealsFeaturedAttribute*/ : null, "HotDeal");
            }
            //--TRIMMABLE-BOUNDARY-END(107375709551)
            
            //--TRIMMABLE-BOUNDARY-START(120260611439)
            /*IEnumerable<string>? */ get ProductIcons()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656232815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ic = this.GetProperty($.$$.SCG.IEnumerable$$($.$$.S.String), null, "ProductIcons", "BuyLinkProductIcons");
                if (ic !== null && this.Icons !== null)
                {
                    return $.$sl.SL.Enumerable.Concat($.$$.S.String, ic, $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.ResourceModel, $.$$.S.String, this.Icons, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.String))().$ctor(this,  (/**/ i) =>
                    {
                        return i.FullPath;
                    }, $ReYGcl ??= {"r":1310721,"p":[{"n":"i","p":15279446}],"n":"","d":1527151,"h":0,"f":17825794})));
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                return ic ?? ((__ca1__ = this.Icons) !== null ? $.$sl.SL.Enumerable.Select$1($.$Iaui.LCFCM.ResourceModel, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.String))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.FullPath;
                }, $ilkQhe ??= {"r":1310721,"p":[{"n":"i","p":15279446}],"n":"","d":1527151,"h":0,"f":17825794})) : null);
            }
            /*IEnumerable<string>? */ set ProductIcons(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325382511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.SCG.IEnumerable$$($.$$.S.String), value, "ProductIcons");
            }
            //--TRIMMABLE-BOUNDARY-END(120260611439)
            
            //--TRIMMABLE-BOUNDARY-START(115965644143)
            /*IconDescriptor */ get IconDescriptor()
            {
                let $t1;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066298223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                return ((__ca2__ = this.ProductIcons) !== null ? ((($t1 = $.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, __ca2__)) !== null ? $.$fPer.LCFC.IconDescriptor.op_Implicit($t1) : null) ?? super.IconDescriptor) : super.IconDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(115965644143)
            
            //--TRIMMABLE-BOUNDARY-START(103080742255)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080742255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca3__;
                return ((__ca3__ = this.Url) !== null ? $.$$.S.String.GetHashCode.call(__ca3__) : super.GetHashCode());
            }
            //--TRIMMABLE-BOUNDARY-END(103080742255)
            
            //--TRIMMABLE-BOUNDARY-START(8591461743)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591461743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let buy;
                if ($.$is(obj, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, { set $v($v){ buy = $v; } }))
                {
                    return this.Url === buy.Url;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(8591461743)
            
            //--TRIMMABLE-BOUNDARY-START(12886429039)
            /*bool */ Equals$2(/*CommunityBuyLinkProductBaseModel*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886429039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Url === other.Url;
            }
            //--TRIMMABLE-BOUNDARY-END(12886429039)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel>.Equals(LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel?)
            S$IEquatable$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductBaseModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4296494447)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296494447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296494447)
            
            //--TRIMMABLE-BOUNDARY-START(4296494447)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296494447)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(111670676847)
                    this.HotDealsFeaturedAttribute = "hotdeals";
                    //--TRIMMABLE-BOUNDARY-END(111670676847)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1527151;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128850546031),
    {
      "p": 24897972,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836101999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505251695,
        "f": 83886081
      },
      "n": "QueryState",
      "d": 1527151,
      "h": 128850546031,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3000,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850546031),
//--TRIMMABLE-BOUNDARY-START(124555578735),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246167407,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915317103,
        "f": 83886081
      },
      "n": "Quantity",
      "d": 1527151,
      "h": 124555578735,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3001,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "What quantity of this product you want to buy/offer",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Numeric1"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555578735),
//--TRIMMABLE-BOUNDARY-START(227634793839),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195840367,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864990063,
        "f": 83886081
      },
      "n": "Url",
      "d": 1527151,
      "h": 227634793839,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3002,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634793839),
//--TRIMMABLE-BOUNDARY-START(219044859247),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015971183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685120879,
        "f": 83886081
      },
      "n": "SiteName",
      "d": 1527151,
      "h": 219044859247,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3003,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219044859247),
//--TRIMMABLE-BOUNDARY-START(214749891951),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426036591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095186287,
        "f": 83886081
      },
      "n": "SiteIcon",
      "d": 1527151,
      "h": 214749891951,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749891951),
//--TRIMMABLE-BOUNDARY-START(223339826543),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605905775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193275055471,
        "f": 83886081
      },
      "n": "UnitCost",
      "d": 1527151,
      "h": 223339826543,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3004,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "At what rate are you willing to buy/sell",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Cash"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223339826543),
//--TRIMMABLE-BOUNDARY-START(231929761135),
    {
      "p": 29985110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785774959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454924655,
        "f": 83886081
      },
      "n": "Weight",
      "d": 1527151,
      "h": 231929761135,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3006,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231929761135),
//--TRIMMABLE-BOUNDARY-START(107375709551),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476363631,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735447919,
        "f": 83886081
      },
      "n": "HotDeal",
      "d": 1527151,
      "h": 107375709551,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3007,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375709551),
//--TRIMMABLE-BOUNDARY-START(120260611439),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656232815,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325382511,
        "f": 83886081
      },
      "n": "ProductIcons",
      "d": 1527151,
      "h": 120260611439,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260611439),
//--TRIMMABLE-BOUNDARY-START(115965644143),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066298223,
        "f": 50364417
      },
      "n": "IconDescriptor",
      "d": 1527151,
      "h": 115965644143,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965644143)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133145513327),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 1527151,
      "h": 133145513327,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133145513327),
//--TRIMMABLE-BOUNDARY-START(103080742255),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1527151,
      "h": 103080742255,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080742255),
//--TRIMMABLE-BOUNDARY-START(8591461743),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1527151,
      "h": 8591461743,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591461743),
//--TRIMMABLE-BOUNDARY-START(12886429039),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1527151
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1527151,
      "h": 12886429039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886429039)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111670676847),
    {
      "t": 1310721,
      "n": "HotDealsFeaturedAttribute",
      "d": 1527151,
      "h": 111670676847,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670676847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296494447),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1527151,
      "h": 4296494447,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296494447)
  ],
  "h": 1527151
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostSubscribable, $.$$.S.IEquatable$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductBaseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1527151)
        
        

        $asm.$typeProxy("$RffN.LCCBCM.CommunityBuyLinkProductModel", "$RffN.LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel");
        //--TRIMMABLE-BOUNDARY-START(937327)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkOrderModel`, ($self) => class CommunityBuyLinkOrderModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)
        {
            //--TRIMMABLE-BOUNDARY-START(390842961263)
            /*PostTypes */ get Type()
            {
                return 5122/*PostTypes.BuyLinkOrder*/;
            }
            //--TRIMMABLE-BOUNDARY-END(390842961263)
            
            //--TRIMMABLE-BOUNDARY-START(257698975087)
            /*PostQueryableState */ get QueryState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799629167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$LCOv.LCFCP.PostQueryableState, 0, "QueryState", null);
            }
            /*PostQueryableState */ set QueryState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663092079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$LCOv.LCFCP.PostQueryableState, value, "QueryState");
            }
            //--TRIMMABLE-BOUNDARY-END(257698975087)
            
            //--TRIMMABLE-BOUNDARY-START(386547993967)
            /*DataId */ get ShipmentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569432943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCD.DataId, new $.$fPer.LCFCD.DataId(), "ShipmentId", null);
            }
            /*DataId */ set ShipmentId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253026671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCD.DataId, $.$clone(value), "ShipmentId");
            }
            //--TRIMMABLE-BOUNDARY-END(386547993967)
            
            //--TRIMMABLE-BOUNDARY-START(21475773807)
            /*DateTime? */ get DatePaid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310348655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.QueryState > 3072/*PostQueryableState.AwaitingPayment*/ ? this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "DatePaid", null) : null;
            }
            /*DateTime? */ set DatePaid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943615343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "DatePaid");
            }
            //--TRIMMABLE-BOUNDARY-END(21475773807)
            
            //--TRIMMABLE-BOUNDARY-START(244814073199)
            /*string? */ get PaymentReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029825391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "PaymentReference", null);
            }
            /*string? */ set PaymentReference(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483222895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "PaymentReference");
            }
            //--TRIMMABLE-BOUNDARY-END(244814073199)
            
            //--TRIMMABLE-BOUNDARY-START(42950610287)
            /*BuyLinkOrderShipmentType */ get FreightShipment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260021615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$RffN.LCCBCM.BuyLinkOrderShipmentType, 0, "FreightShipment", null);
            }
            /*BuyLinkOrderShipmentType */ set FreightShipment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893288303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$RffN.LCCBCM.BuyLinkOrderShipmentType, value, "FreightShipment");
            }
            //--TRIMMABLE-BOUNDARY-END(42950610287)
            
            //--TRIMMABLE-BOUNDARY-START(25770741103)
            /*ShipmentDeliveryType */ get Delivery()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900283247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$YUlm.LCSCM.ShipmentDeliveryType, 0, "Delivery", null);
            }
            /*ShipmentDeliveryType */ set Delivery(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533549935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$YUlm.LCSCM.ShipmentDeliveryType, value, "Delivery");
            }
            //--TRIMMABLE-BOUNDARY-END(25770741103)
            
            //--TRIMMABLE-BOUNDARY-START(30065708399)
            /*string? */ get DeliveryAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490217839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "DeliveryAddress", null);
            }
            /*string? */ set DeliveryAddress(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123484527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "DeliveryAddress");
            }
            //--TRIMMABLE-BOUNDARY-END(30065708399)
            
            //--TRIMMABLE-BOUNDARY-START(249109040495)
            /*GeoLocation? */ get PickupLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619759983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDG.GeoLocation, null, "PickupLocation", null);
            }
            /*GeoLocation? */ set PickupLocation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073157487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDG.GeoLocation, value, "PickupLocation");
            }
            //--TRIMMABLE-BOUNDARY-END(249109040495)
            
            //--TRIMMABLE-BOUNDARY-START(34360675695)
            /*GeoLocation? */ get DeliveryLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080152431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDG.GeoLocation, null, "DeliveryLocation", null);
            }
            /*GeoLocation? */ set DeliveryLocation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713419119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDG.GeoLocation, value, "DeliveryLocation");
            }
            //--TRIMMABLE-BOUNDARY-END(34360675695)
            
            //--TRIMMABLE-BOUNDARY-START(17180806511)
            /*DateTime? */ get DateDelivered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720414063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "DateDelivered", null);
            }
            /*DateTime? */ set DateDelivered(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353680751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "DateDelivered");
            }
            //--TRIMMABLE-BOUNDARY-END(17180806511)
            
            //--TRIMMABLE-BOUNDARY-START(12885839215)
            /*DateTime? */ get DateConfirmed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130479471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "DateConfirmed", null);
            }
            /*DateTime? */ set DateConfirmed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763746159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "DateConfirmed");
            }
            //--TRIMMABLE-BOUNDARY-END(12885839215)
            
            //--TRIMMABLE-BOUNDARY-START(38655642991)
            /*string? */ get DisplayIcon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670087023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "DisplayIcon", null);
            }
            /*string? */ set DisplayIcon(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303353711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "DisplayIcon");
            }
            //--TRIMMABLE-BOUNDARY-END(38655642991)
            
            //--TRIMMABLE-BOUNDARY-START(219044269423)
            /*IconDescriptor */ get IconDescriptor()
            {
                let $t1;
                return (($t1 = this.DisplayIcon) !== null ? $.$fPer.LCFC.IconDescriptor.op_Implicit($t1) : null) ?? super.IconDescriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(219044269423)
            
            //--TRIMMABLE-BOUNDARY-START(279173811567)
            /*IShipmentAccount */ get Sender()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(279173811567)
            
            //--TRIMMABLE-BOUNDARY-START(261993942383)
            /*IShipmentAccount */ get Receiver()
            {
                return this.Account;
            }
            //--TRIMMABLE-BOUNDARY-END(261993942383)
            
            //--TRIMMABLE-BOUNDARY-START(253404007791)
            /*IEnumerable<CommunityBuyLinkProductModel> */ get Products()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209694575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca1__;
                return _ = ((__ca1__ = this.Children) !== null ? $.$sl.SL.Enumerable.OfType($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca1__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(253404007791)
            
            //--TRIMMABLE-BOUNDARY-START(236224138607)
            /*IEnumerable<IShipmentProductModel> */ get LCSCM$IShipmentPackageModel$Products()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Products, $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentProductModel));
            }
            //--TRIMMABLE-BOUNDARY-END(236224138607)
            
            //--TRIMMABLE-BOUNDARY-START(8590871919)
            /*Money */ get Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540544879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca2__;
                return (() =>
                {
                    //new $.$fPer.LCFCDM.Money()
                    const $t2 = $.$fPer.LCFCDM.Money;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Value = ((__ca2__ = this.Children) !== null ? $.$sl.SL.Enumerable.Sum$16($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$sl.SL.Enumerable.OfType($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca2__), new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Double))().$ctor(this,  (/*p*/ p) =>
                    {
                        return p.UnitCost.Naira.Value * p.Quantity;
                    }, $NATbNb ??= {"r":1179649,"p":[{"n":"p","p":1789295}],"n":"","d":937327,"h":0,"f":17825794})) : 0);
                    $i2.Unit = 1/*MoneyUnitTypes.Naira*/;
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8590871919)
            
            //--TRIMMABLE-BOUNDARY-START(403727863151)
            /*Weight */ get Weight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749302127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca3__;
                return (() =>
                {
                    //new $.$fPer.LCFCDM.Weight()
                    const $t3 = $.$fPer.LCFCDM.Weight;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Value = ((__ca3__ = this.Children) !== null ? $.$sl.SL.Enumerable.Sum$16($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$sl.SL.Enumerable.OfType($.$RffN.LCCBCM.CommunityBuyLinkProductModel, __ca3__), new ($.$$.S.Func$$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel, $.$$.S.Double))().$ctor(this,  (/**/ p) =>
                    {
                        return p.Weight.Kg;
                    }, $IoCjua ??= {"r":1179649,"p":[{"n":"p","p":1789295}],"n":"","d":937327,"h":0,"f":17825794})) : 0);
                    $i3.Unit = 4/*WeightUnitTypes.kg*/;
                    return $i3;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(403727863151)
            
            //--TRIMMABLE-BOUNDARY-START(223339236719)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "BuyLink/Order", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(223339236719)
            
            //--TRIMMABLE-BOUNDARY-START(266288909679)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266288909679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266288909679)
            
            //--TRIMMABLE-BOUNDARY-START(270583876975)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270583876975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270583876975)
            
            //--TRIMMABLE-BOUNDARY-START(274878844271)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274878844271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274878844271)
            
            //--TRIMMABLE-BOUNDARY-START(240519105903)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519105903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/ || propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 4/*SchemaType.DataTable*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Order Label", "Your order package is tagged with this label", null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "Order Description", "More information on this order", null, 16n, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Delivery", "Local Delivery", null, null, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(240519105903)
            
            //--TRIMMABLE-BOUNDARY-START(395137928559)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137928559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = super.UpdateDescriptors(descriptors, $.$clone(schema));
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/ || $.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 4/*SchemaType.DataTable*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "Category", "PostFlags", "Tags", "Icon", "Summary" ], null, null));
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(395137928559)
            
            //--TRIMMABLE-BOUNDARY-START(399432895855)
            /*ValueTask<bool> *//*async*/  Validate(/*SchemaContext*/ schema)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399432895855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let v = ($t4 = super.Validate($.$clone(schema)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (v)
                    {
                        if (this.FreightShipment === 0/*BuyLinkOrderShipmentType.None*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle("FreightShipment"))} is required.`);
                        }
                        if (this.Delivery === 0/*ShipmentDeliveryType.None*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`Local ${$.$strNN("Delivery")} is required.`);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, v);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(399432895855)
            
            //--TRIMMABLE-BOUNDARY-START(133144938617)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.SKU.get
            get LCSCM$IShipmentPackageModel$SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504676985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(133144938617)
            
            //--TRIMMABLE-BOUNDARY-START(124555004025)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.ShipmentId.get
            get LCSCM$IShipmentPackageModel$ShipmentId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209709689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShipmentId;
            }
            //--TRIMMABLE-BOUNDARY-END(124555004025)
            
            //--TRIMMABLE-BOUNDARY-START(81605331065)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.PaymentReference.get
            get LCSCM$IShipmentPackageModel$PaymentReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734873209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PaymentReference;
            }
            //--TRIMMABLE-BOUNDARY-END(81605331065)
            
            //--TRIMMABLE-BOUNDARY-START(47245592697)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.DatePaid.get
            get LCSCM$IShipmentPackageModel$DatePaid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885854329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DatePaid;
            }
            //--TRIMMABLE-BOUNDARY-END(47245592697)
            
            //--TRIMMABLE-BOUNDARY-START(55835527289)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.Delivery.get
            get LCSCM$IShipmentPackageModel$Delivery()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180821625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Delivery;
            }
            //--TRIMMABLE-BOUNDARY-END(55835527289)
            
            //--TRIMMABLE-BOUNDARY-START(90195265657)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.PickupLocation.get
            get LCSCM$IShipmentPackageModel$PickupLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029840505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PickupLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(90195265657)
            
            //--TRIMMABLE-BOUNDARY-START(64425461881)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.DeliveryLocation.get
            get LCSCM$IShipmentPackageModel$DeliveryLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475788921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DeliveryLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(64425461881)
            
            //--TRIMMABLE-BOUNDARY-START(38655658105)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.DateDelivered.get
            get LCSCM$IShipmentPackageModel$DateDelivered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590887033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DateDelivered;
            }
            //--TRIMMABLE-BOUNDARY-END(38655658105)
            
            //--TRIMMABLE-BOUNDARY-START(30065723513)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.DateConfirmed.get
            get LCSCM$IShipmentPackageModel$DateConfirmed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295919737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DateConfirmed;
            }
            //--TRIMMABLE-BOUNDARY-END(30065723513)
            
            //--TRIMMABLE-BOUNDARY-START(115965069433)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.Sender.get
            get LCSCM$IShipmentPackageModel$Sender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914742393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sender;
            }
            //--TRIMMABLE-BOUNDARY-END(115965069433)
            
            //--TRIMMABLE-BOUNDARY-START(107375134841)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.Receiver.get
            get LCSCM$IShipmentPackageModel$Receiver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619775097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Receiver;
            }
            //--TRIMMABLE-BOUNDARY-END(107375134841)
            
            //--TRIMMABLE-BOUNDARY-START(73015396473)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel.Link.get
            get LCSCM$IShipmentPackageModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439905913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(73015396473)
            
            //--TRIMMABLE-BOUNDARY-START(8592615860)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.get
            get LCFCP$IPostQueryable$QueryState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.QueryState;
            }
            //--TRIMMABLE-BOUNDARY-END(8592615860)
            
            //--TRIMMABLE-BOUNDARY-START(21477517748)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.set
            set LCFCP$IPostQueryable$QueryState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.QueryState = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477517748)
            
            //--TRIMMABLE-BOUNDARY-START(4295904623)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295904623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295904623)
            
            //--TRIMMABLE-BOUNDARY-START(4295904623)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295904623)
            
            static $h = 937327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(390842961263),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159367535,
        "f": 50364417
      },
      "n": "Type",
      "d": 937327,
      "h": 390842961263,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(390842961263),
//--TRIMMABLE-BOUNDARY-START(257698975087),
    {
      "p": 24897972,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799629167,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373663092079,
        "f": 83886081
      },
      "n": "QueryState",
      "d": 937327,
      "h": 257698975087,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2999,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257698975087),
//--TRIMMABLE-BOUNDARY-START(386547993967),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569432943,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382253026671,
        "f": 83886081
      },
      "n": "ShipmentId",
      "d": 937327,
      "h": 386547993967,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(386547993967),
//--TRIMMABLE-BOUNDARY-START(21475773807),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310348655,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943615343,
        "f": 83886081
      },
      "n": "DatePaid",
      "d": 937327,
      "h": 21475773807,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3000,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475773807),
//--TRIMMABLE-BOUNDARY-START(244814073199),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029825391,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356483222895,
        "f": 83886081
      },
      "n": "PaymentReference",
      "d": 937327,
      "h": 244814073199,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3001,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244814073199),
//--TRIMMABLE-BOUNDARY-START(42950610287),
    {
      "p": 478575,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260021615,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893288303,
        "f": 83886081
      },
      "n": "FreightShipment",
      "d": 937327,
      "h": 42950610287,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3002,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How do we ship your order to Nigeria. Note that express shiment is faster but more costly",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950610287),
//--TRIMMABLE-BOUNDARY-START(25770741103),
    {
      "p": 1214585,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900283247,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533549935,
        "f": 83886081
      },
      "n": "Delivery",
      "d": 937327,
      "h": 25770741103,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3003,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "How do we deliver to you in Nigeria",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770741103),
//--TRIMMABLE-BOUNDARY-START(30065708399),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490217839,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123484527,
        "f": 83886081
      },
      "n": "DeliveryAddress",
      "d": 937327,
      "h": 30065708399,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3004,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            },
            {
              "n": "ExcludeFilter",
              "v": 231545,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065708399),
//--TRIMMABLE-BOUNDARY-START(249109040495),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619759983,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365073157487,
        "f": 83886081
      },
      "n": "PickupLocation",
      "d": 937327,
      "h": 249109040495,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3005,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            },
            {
              "n": "ExcludeFilter",
              "v": 231545,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109040495),
//--TRIMMABLE-BOUNDARY-START(34360675695),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080152431,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713419119,
        "f": 83886081
      },
      "n": "DeliveryLocation",
      "d": 937327,
      "h": 34360675695,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3005,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            },
            {
              "n": "ExcludeFilter",
              "v": 231545,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360675695),
//--TRIMMABLE-BOUNDARY-START(17180806511),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720414063,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353680751,
        "f": 83886081
      },
      "n": "DateDelivered",
      "d": 937327,
      "h": 17180806511,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3006,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180806511),
//--TRIMMABLE-BOUNDARY-START(12885839215),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130479471,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763746159,
        "f": 83886081
      },
      "n": "DateConfirmed",
      "d": 937327,
      "h": 12885839215,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3007,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885839215),
//--TRIMMABLE-BOUNDARY-START(38655642991),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670087023,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303353711,
        "f": 83886081
      },
      "n": "DisplayIcon",
      "d": 937327,
      "h": 38655642991,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655642991),
//--TRIMMABLE-BOUNDARY-START(219044269423),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849956207,
        "f": 50364417
      },
      "n": "IconDescriptor",
      "d": 937327,
      "h": 219044269423,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219044269423),
//--TRIMMABLE-BOUNDARY-START(279173811567),
    {
      "p": 755833,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979498351,
        "f": 50331649
      },
      "n": "Sender",
      "d": 937327,
      "h": 279173811567,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173811567),
//--TRIMMABLE-BOUNDARY-START(261993942383),
    {
      "p": 755833,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389563759,
        "f": 50331649
      },
      "n": "Receiver",
      "d": 937327,
      "h": 261993942383,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993942383),
//--TRIMMABLE-BOUNDARY-START(253404007791),
    {
      "p": $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209694575,
        "f": 50331649
      },
      "n": "Products",
      "d": 937327,
      "h": 253404007791,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404007791),
//--TRIMMABLE-BOUNDARY-START(236224138607),
    {
      "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentProductModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929171311,
        "f": 50331650
      },
      "n": "{952441}.Products",
      "o": "LCSCM$IShipmentPackageModel$Products",
      "d": 937327,
      "h": 236224138607,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(236224138607),
//--TRIMMABLE-BOUNDARY-START(8590871919),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540544879,
        "f": 50331649
      },
      "n": "Amount",
      "d": 937327,
      "h": 8590871919,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590871919),
//--TRIMMABLE-BOUNDARY-START(403727863151),
    {
      "p": 29985110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749302127,
        "f": 50331649
      },
      "n": "Weight",
      "d": 937327,
      "h": 403727863151,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403727863151),
//--TRIMMABLE-BOUNDARY-START(223339236719),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439890799,
        "f": 50364417
      },
      "n": "Link",
      "d": 937327,
      "h": 223339236719,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223339236719)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(266288909679),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 937327,
      "h": 266288909679,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266288909679),
//--TRIMMABLE-BOUNDARY-START(270583876975),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 937327,
      "h": 270583876975,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270583876975),
//--TRIMMABLE-BOUNDARY-START(274878844271),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 937327,
      "h": 274878844271,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(274878844271),
//--TRIMMABLE-BOUNDARY-START(240519105903),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 937327,
      "h": 240519105903,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(240519105903),
//--TRIMMABLE-BOUNDARY-START(395137928559),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 937327,
      "h": 395137928559,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(395137928559),
//--TRIMMABLE-BOUNDARY-START(399432895855),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Validate",
      "d": 937327,
      "h": 399432895855,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(399432895855)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295904623),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 937327,
      "h": 4295904623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295904623)
  ],
  "h": 937327,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "ExcludeFilter",
          "v": 413039,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostCategory, $.$YUlm.LCSCM.IShipmentPackageModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostQueryable, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkOrderModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(937327)
        
        

        //--TRIMMABLE-BOUNDARY-START(1789295)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductModel`, ($self) => class CommunityBuyLinkProductModel extends $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel
        {
            //--TRIMMABLE-BOUNDARY-START(98786037103)
            /*PostTypes */ get Type()
            {
                return 5121/*PostTypes.BuyLinkProduct*/;
            }
            //--TRIMMABLE-BOUNDARY-END(98786037103)
            
            //--TRIMMABLE-BOUNDARY-START(8591723887)
            /*string? */ get CostInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181658479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "CostInfo", null);
            }
            /*string? */ set CostInfo(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901135215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "CostInfo");
            }
            //--TRIMMABLE-BOUNDARY-END(8591723887)
            
            //--TRIMMABLE-BOUNDARY-START(77311200623)
            /*DataId */ get OffererId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951462255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCD.DataId, new $.$fPer.LCFCD.DataId(), "OffererId", null);
            }
            /*DataId */ set OffererId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491069807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCD.DataId, $.$clone(value), "OffererId");
            }
            //--TRIMMABLE-BOUNDARY-END(77311200623)
            
            //--TRIMMABLE-BOUNDARY-START(60131331439)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["BuyLink", "Product"], null, null), null, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(60131331439)
            
            //--TRIMMABLE-BOUNDARY-START(55836364143)
            /*bool */ get IsWaitingForPayment()
            {
                return !$.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.UnitCost) && (this.QueryState === 0/*PostQueryableState.Submitted*/ || this.QueryState === 2048/*PostQueryableState.QueryAnswered*/);
            }
            //--TRIMMABLE-BOUNDARY-END(55836364143)
            
            //--TRIMMABLE-BOUNDARY-START(64426298735)
            /*Money */ get LCSCM$IShipmentProductModel$Cost()
            {
                return this.UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(64426298735)
            
            //--TRIMMABLE-BOUNDARY-START(30065854585)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentProductModel.Quantity.get
            get LCSCM$IShipmentProductModel$Quantity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655789177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Quantity;
            }
            //--TRIMMABLE-BOUNDARY-END(30065854585)
            
            //--TRIMMABLE-BOUNDARY-START(21475919993)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Models.IShipmentProductModel.Link.get
            get LCSCM$IShipmentProductModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360821881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(21475919993)
            
            //--TRIMMABLE-BOUNDARY-START(8592615860)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.get
            get LCFCP$IPostQueryable$QueryState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.QueryState;
            }
            //--TRIMMABLE-BOUNDARY-END(8592615860)
            
            //--TRIMMABLE-BOUNDARY-START(21477517748)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.set
            set LCFCP$IPostQueryable$QueryState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.QueryState = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477517748)
            
            //--TRIMMABLE-BOUNDARY-START(30068763060)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.UnitCost.get
            get LCFCP$IPostSinglePriceOfferable$UnitCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428501428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(30068763060)
            
            //--TRIMMABLE-BOUNDARY-START(60133534132)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.UnitCost.set
            set LCFCP$IPostSinglePriceOfferable$UnitCost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428501428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitCost = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60133534132)
            
            //--TRIMMABLE-BOUNDARY-START(12888893876)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.CostInfo.get
            get LCFCP$IPostSinglePriceOfferable$CostInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298959284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CostInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(12888893876)
            
            //--TRIMMABLE-BOUNDARY-START(42953664948)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.CostInfo.set
            set LCFCP$IPostSinglePriceOfferable$CostInfo(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298959284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CostInfo = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42953664948)
            
            //--TRIMMABLE-BOUNDARY-START(21478828468)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.OffererId.get
            get LCFCP$IPostSinglePriceOfferable$OffererId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363730356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OffererId;
            }
            //--TRIMMABLE-BOUNDARY-END(21478828468)
            
            //--TRIMMABLE-BOUNDARY-START(51543599540)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSinglePriceOfferable.OffererId.set
            set LCFCP$IPostSinglePriceOfferable$OffererId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363730356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OffererId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(51543599540)
            
            //--TRIMMABLE-BOUNDARY-START(4296756591)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296756591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296756591)
            
            //--TRIMMABLE-BOUNDARY-START(4296756591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296756591)
            
            static $h = 1789295;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98786037103),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541396847,
        "f": 50364417
      },
      "n": "Type",
      "d": 1789295,
      "h": 98786037103,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98786037103),
//--TRIMMABLE-BOUNDARY-START(8591723887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181658479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901135215,
        "f": 83886081
      },
      "n": "CostInfo",
      "d": 1789295,
      "h": 8591723887,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3005,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777209,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591723887),
//--TRIMMABLE-BOUNDARY-START(77311200623),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951462255,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491069807,
        "f": 83886081
      },
      "n": "OffererId",
      "d": 1789295,
      "h": 77311200623,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3006,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311200623),
//--TRIMMABLE-BOUNDARY-START(60131331439),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361527663,
        "f": 50364417
      },
      "n": "Link",
      "d": 1789295,
      "h": 60131331439,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60131331439),
//--TRIMMABLE-BOUNDARY-START(55836364143),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771593071,
        "f": 50331649
      },
      "n": "IsWaitingForPayment",
      "d": 1789295,
      "h": 55836364143,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836364143),
//--TRIMMABLE-BOUNDARY-START(64426298735),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016233327,
        "f": 50331650
      },
      "n": "{1083513}.Cost",
      "o": "LCSCM$IShipmentProductModel$Cost",
      "d": 1789295,
      "h": 64426298735,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64426298735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296756591),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1789295,
      "h": 4296756591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296756591)
  ],
  "h": 1789295,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "ExcludeFilter",
          "v": 609647,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostSubscribable, $.$$.S.IEquatable$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel), $.$YUlm.LCSCM.IShipmentProductModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostQueryable, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostPriceOfferable, $.$LCOv.LCFCP.IPostSinglePriceOfferable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1789295)
        
        

        //--TRIMMABLE-BOUNDARY-START(2641263)
        $asm.$cls(`$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService`, ($self) => class ICommunityBuyLinkProductFeedRemoteService
        {
            static $h = 2641263;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2641263,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.ICommunityBuyLinkProductFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}ICommunityBuyLinkProductFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2641263)
        
        

        //--TRIMMABLE-BOUNDARY-START(2051439)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductPoolModel`, ($self) => class CommunityBuyLinkProductPoolModel extends $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel
        {
            //--TRIMMABLE-BOUNDARY-START(176095710575)
            /*PostTypes */ get Type()
            {
                return 5123/*PostTypes.BuyLinkProductPool*/;
            }
            //--TRIMMABLE-BOUNDARY-END(176095710575)
            
            //--TRIMMABLE-BOUNDARY-START(73016495471)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["BuyLink", "Pool"], null, null), null, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(73016495471)
            
            //--TRIMMABLE-BOUNDARY-START(115966168431)
            /*CommunityBuyLinkPoolPaymentMode */ get PaymentMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361789807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode, 0, "PaymentMode", null);
            }
            /*CommunityBuyLinkPoolPaymentMode */ set PaymentMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030939503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode, value, "PaymentMode");
            }
            //--TRIMMABLE-BOUNDARY-END(115966168431)
            
            //--TRIMMABLE-BOUNDARY-START(124556103023)
            /*DateTime? */ get PoolStartDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541658991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "PoolStartDate", null);
            }
            /*DateTime? */ set PoolStartDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210808687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "PoolStartDate");
            }
            //--TRIMMABLE-BOUNDARY-END(124556103023)
            
            //--TRIMMABLE-BOUNDARY-START(120261135727)
            /*DateTime? */ get PoolEndDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951724399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.DateTime), null, "PoolEndDate", null);
            }
            /*DateTime? */ set PoolEndDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620874095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.DateTime), $.$clone(value), "PoolEndDate");
            }
            //--TRIMMABLE-BOUNDARY-END(120261135727)
            
            //--TRIMMABLE-BOUNDARY-START(128851070319)
            /*IEnumerable<QueryPostModel>? */ get Queries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131593583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$LCOv.LCFCPM$1.QueryPostModel, null);
            }
            /*IEnumerable<QueryPostModel>? */ set Queries(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800743279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$LCOv.LCFCPM$1.QueryPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(128851070319)
            
            //--TRIMMABLE-BOUNDARY-START(111671201135)
            /*IEnumerable<IPostQuery>? */ get LCFCP$IPostQueryStore$Queries()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Queries, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IPostQuery));
            }
            //--TRIMMABLE-BOUNDARY-END(111671201135)
            
            //--TRIMMABLE-BOUNDARY-START(90196364655)
            /*IEnumerable<IPostQuery>? */ set LCFCP$IPostEditableQueryStore$Queries(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786299247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.IPostQuery>?*/ let __ca1__;
                this.Queries = ((__ca1__ = value) !== null ? $.$sl.SL.Enumerable.Cast($.$LCOv.LCFCPM$1.QueryPostModel, __ca1__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(90196364655)
            
            //--TRIMMABLE-BOUNDARY-START(8591986031)
            /*IEnumerable<QueryAnswer>? */ get Answers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181920623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$fPer.LCFCD.QueryAnswer, "Answers");
            }
            /*IEnumerable<QueryAnswer>? */ set Answers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441004911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$fPer.LCFCD.QueryAnswer, value, "Answers");
            }
            //--TRIMMABLE-BOUNDARY-END(8591986031)
            
            //--TRIMMABLE-BOUNDARY-START(77311462767)
            /*IEnumerable<IQueryAnswer>? */ get LCFCD$IQueryAnswers$Answers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901397359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.QueryAnswer>?*/ let __ca2__;
                return _ = ((__ca2__ = this.Answers) !== null ? $.$sl.SL.Enumerable.Cast($.$fPer.LCFCD.IQueryAnswer, __ca2__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(77311462767)
            
            //--TRIMMABLE-BOUNDARY-START(17182313839)
            //Generated interface implemetation for LivingThing.Core.Community.BuyLink.Common.Models.ICommunityBuyLinkProductPoolModel.PoolStartDate.get
            get LCCBCM$ICommunityBuyLinkProductPoolModel$PoolStartDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772248431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PoolStartDate;
            }
            //--TRIMMABLE-BOUNDARY-END(17182313839)
            
            //--TRIMMABLE-BOUNDARY-START(8592379247)
            //Generated interface implemetation for LivingThing.Core.Community.BuyLink.Common.Models.ICommunityBuyLinkProductPoolModel.PoolEndDate.get
            get LCCBCM$ICommunityBuyLinkProductPoolModel$PoolEndDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477281135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PoolEndDate;
            }
            //--TRIMMABLE-BOUNDARY-END(8592379247)
            
            //--TRIMMABLE-BOUNDARY-START(8592615860)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.get
            get LCFCP$IPostQueryable$QueryState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.QueryState;
            }
            //--TRIMMABLE-BOUNDARY-END(8592615860)
            
            //--TRIMMABLE-BOUNDARY-START(21477517748)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostQueryable.QueryState.set
            set LCFCP$IPostQueryable$QueryState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887583156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.QueryState = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477517748)
            
            //--TRIMMABLE-BOUNDARY-START(4297018735)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297018735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297018735)
            
            //--TRIMMABLE-BOUNDARY-START(4297018735)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4297018735)
            
            static $h = 2051439;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176095710575),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721528175,
        "f": 50364417
      },
      "n": "Type",
      "d": 2051439,
      "h": 176095710575,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176095710575),
//--TRIMMABLE-BOUNDARY-START(73016495471),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771855215,
        "f": 50364417
      },
      "n": "Link",
      "d": 2051439,
      "h": 73016495471,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016495471),
//--TRIMMABLE-BOUNDARY-START(115966168431),
    {
      "p": 1265007,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361789807,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030939503,
        "f": 83886081
      },
      "n": "PaymentMode",
      "d": 2051439,
      "h": 115966168431,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "How will someone pay for this product. Pay when joining or later",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 4001,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=ContactlessPayment"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966168431),
//--TRIMMABLE-BOUNDARY-START(124556103023),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541658991,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210808687,
        "f": 83886081
      },
      "n": "PoolStartDate",
      "d": 2051439,
      "h": 124556103023,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "When can people start joining this pool. Empty indicates starts immediately",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 4002,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Alarm"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124556103023),
//--TRIMMABLE-BOUNDARY-START(120261135727),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951724399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620874095,
        "f": 83886081
      },
      "n": "PoolEndDate",
      "d": 2051439,
      "h": 120261135727,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "When should people stop joining this pool. Empty indicates ends indefinitely",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 4003,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=AlarmCheck"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261135727),
//--TRIMMABLE-BOUNDARY-START(128851070319),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131593583,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800743279,
        "f": 83886081
      },
      "n": "Queries",
      "d": 2051439,
      "h": 128851070319,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128851070319),
//--TRIMMABLE-BOUNDARY-START(111671201135),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IPostQuery).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376233839,
        "f": 50331650
      },
      "n": "{2877876}.Queries",
      "o": "LCFCP$IPostQueryStore$Queries",
      "d": 2051439,
      "h": 111671201135,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111671201135),
//--TRIMMABLE-BOUNDARY-START(90196364655),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IPostQuery).$h,
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786299247,
        "f": 83886082
      },
      "n": "{1829300}.Queries",
      "o": "LCFCP$IPostEditableQueryStore$Queries",
      "d": 2051439,
      "h": 90196364655,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90196364655),
//--TRIMMABLE-BOUNDARY-START(8591986031),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181920623,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441004911,
        "f": 83886081
      },
      "n": "Answers",
      "d": 2051439,
      "h": 8591986031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591986031),
//--TRIMMABLE-BOUNDARY-START(77311462767),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryAnswer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901397359,
        "f": 50331650
      },
      "n": "{21727574}.Answers",
      "o": "LCFCD$IQueryAnswers$Answers",
      "d": 2051439,
      "h": 77311462767,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77311462767)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297018735),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 2051439,
      "h": 4297018735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297018735)
  ],
  "h": 2051439
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostSubscribable, $.$$.S.IEquatable$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel), $.$RffN.LCCBCM.ICommunityBuyLinkProductPoolModel, $.$LCOv.LCFCP.IPostQueryable, $.$LCOv.LCFCP.IPost, $.$LCOv.LCFCP.IPostQueryStore, $.$LCOv.LCFCP.IPostEditableQueryStore, $.$LCOv.LCFCP.IPostByAdminOnly, $.$fPer.LCFCD.IQueryAnswers ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductPoolModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2051439)
        
        

        //--TRIMMABLE-BOUNDARY-START(2772335)
        $asm.$cls(`$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService`, ($self) => class ICommunityBuyLinkProductPoolFeedRemoteService
        {
            static $h = 2772335;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2772335,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.ICommunityBuyLinkProductPoolFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}ICommunityBuyLinkProductPoolFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2772335)
        
        

        //--TRIMMABLE-BOUNDARY-START(2706799)
        $asm.$cls(`$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService_Mocking`, ($self) => class ICommunityBuyLinkProductFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297674095)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297674095);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297674095)
            
            //--TRIMMABLE-BOUNDARY-START(8592641391)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592641391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592641391)
            
            static $h = 2706799;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297674095),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2706799,
      "h": 4297674095,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297674095)
  ],
  "h": 2706799
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$RffN.LCCBCS.ICommunityBuyLinkProductFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.ICommunityBuyLinkProductFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}ICommunityBuyLinkProductFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2706799)
        
        

        //--TRIMMABLE-BOUNDARY-START(3951983)
        $asm.$cls(`$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298919279)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298919279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298919279)
            
            //--TRIMMABLE-BOUNDARY-START(8593886575)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593886575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593886575)
            
            //--TRIMMABLE-BOUNDARY-START(17183821167)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183821167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183821167)
            
            //--TRIMMABLE-BOUNDARY-START(21478788463)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478788463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478788463)
            
            //--TRIMMABLE-BOUNDARY-START(25773755759)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773755759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773755759)
            
            //--TRIMMABLE-BOUNDARY-START(12888853871)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888853871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888853871)
            
            static $h = 3951983;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298919279),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3951983,
      "h": 4298919279,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298919279)
  ],
  "h": 3951983
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.IReadDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityBuyLinkProductModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3951983)
        
        

        //--TRIMMABLE-BOUNDARY-START(1920367)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor`, ($self) => class CommunityBuyLinkProductModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296887663)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296887663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor.GenerateProperties($.$RffN.LCCBCM.CommunityBuyLinkProductModel, this, factory);
                    }, $jdHpIj ??= {"r":65537,"n":"","d":1920367,"h":0,"f":17825794}), 0, "CommunityBuyLinkProductModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Models_CommunityBuyLinkProductModel_LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModelTypeDescriptorBuilder.g.cs", "CommunityBuyLinkProductModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296887663)
            
            //--TRIMMABLE-BOUNDARY-START(12886822255)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886822255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CostInfo"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, $.$discardRef(), "CostInfo", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CostInfo")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "CostInfo";
                        $i1.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)).CostInfo);
                        }, $wXPdQa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1920367,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CostInfo = value.AsReference($.$$.S.String);
                        }, $gAGHRa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1920367,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OffererId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, $.$discardRef(), "OffererId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OffererId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "OffererId";
                        $i3.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)).OffererId);
                        }, $elkgPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1920367,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OffererId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $fXlhCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1920367,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Type";
                        $i5.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)).Type);
                        }, $hdbfQa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1920367,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Link";
                        $i7.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)).Link);
                        }, $QnUejl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1920367,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsWaitingForPayment"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductModel.$type, $.$discardRef(), "IsWaitingForPayment", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsWaitingForPayment")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "IsWaitingForPayment";
                        $i9.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)).IsWaitingForPayment);
                        }, $noBwif ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1920367,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886822255)
            
            //--TRIMMABLE-BOUNDARY-START(17181789551)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181789551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel?*/ let targetBase = _target;
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel));
                {
                    /*var*/ let _CostInfo = _target.CostInfo;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CostInfo"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CostInfo, ($v) => _CostInfo = $v, $.$$.S.String)))
                    {
                        _target.CostInfo = _CostInfo;
                    }
                }
                {
                    /*var*/ let _OffererId = _target.OffererId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OffererId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _OffererId, ($v) => _OffererId = $v, null, true)))
                    {
                        _target.OffererId = $.$clone(_OffererId);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _IsWaitingForPayment = _target.IsWaitingForPayment;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsWaitingForPayment"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsWaitingForPayment, ($v) => _IsWaitingForPayment = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181789551)
            
            //--TRIMMABLE-BOUNDARY-START(8591854959)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591854959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCM.CommunityBuyLinkProductModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)))
                {
                    /*var*/ let result = $.$RffN.LCCBCM.CommunityBuyLinkProductModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591854959)
            
            static $h = 1920367;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886822255),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1920367,
      "h": 12886822255,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886822255),
//--TRIMMABLE-BOUNDARY-START(17181789551),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1789295,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1920367,
      "h": 17181789551,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181789551),
//--TRIMMABLE-BOUNDARY-START(8591854959),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1789295,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1920367,
      "h": 8591854959,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591854959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296887663),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1920367,
      "h": 4296887663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296887663)
  ],
  "h": 1920367
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1920367)
        
        

        //--TRIMMABLE-BOUNDARY-START(1068399)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor`, ($self) => class CommunityBuyLinkOrderModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296035695)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296035695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor.GenerateProperties($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, this, factory);
                    }, $FaZtLb ??= {"r":65537,"n":"","d":1068399,"h":0,"f":17825794}), 0, "CommunityBuyLinkOrderModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Models_CommunityBuyLinkOrderModel_LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModelTypeDescriptorBuilder.g.cs", "CommunityBuyLinkOrderModelTypeDescriptor", 46);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296035695)
            
            //--TRIMMABLE-BOUNDARY-START(12885970287)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885970287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("QueryState"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "QueryState", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("QueryState")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCP.PostQueryableState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "QueryState";
                        $i1.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCP.PostQueryableState, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).QueryState);
                        }, $gyKJYi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.QueryState = value.AsEnumValue($.$LCOv.LCFCP.PostQueryableState);
                        }, $NdpjEb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DatePaid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DatePaid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DatePaid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DatePaid";
                        $i3.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DatePaid);
                        }, $aDBLVc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DatePaid = value.AsNullableValue($.$$.S.DateTime);
                        }, $wWnQcj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PaymentReference"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "PaymentReference", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PaymentReference")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PaymentReference";
                        $i5.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).PaymentReference);
                        }, $ulIcwe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PaymentReference = value.AsReference($.$$.S.String);
                        }, $TkYgfk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FreightShipment"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "FreightShipment", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FreightShipment")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$RffN.LCCBCM.BuyLinkOrderShipmentType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "FreightShipment";
                        $i7.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$RffN.LCCBCM.BuyLinkOrderShipmentType, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).FreightShipment);
                        }, $JhhIra ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FreightShipment = value.AsEnumValue($.$RffN.LCCBCM.BuyLinkOrderShipmentType);
                        }, $SlMAni ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Delivery"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Delivery", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Delivery")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.ShipmentDeliveryType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Delivery";
                        $i9.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$YUlm.LCSCM.ShipmentDeliveryType, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Delivery);
                        }, $cRkwRf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Delivery = value.AsEnumValue($.$YUlm.LCSCM.ShipmentDeliveryType);
                        }, $dGvCga ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DeliveryAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DeliveryAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DeliveryAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "DeliveryAddress";
                        $i11.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DeliveryAddress);
                        }, $ziftYf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.DeliveryAddress = value.AsReference($.$$.S.String);
                        }, $HVgqmg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PickupLocation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "PickupLocation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PickupLocation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDG.GeoLocation, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "PickupLocation";
                        $i13.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDG.GeoLocation, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).PickupLocation);
                        }, $iemehh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PickupLocation = value.AsReference($.$fPer.LCFCDG.GeoLocation);
                        }, $gbPKPk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DeliveryLocation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DeliveryLocation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DeliveryLocation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDG.GeoLocation, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "DeliveryLocation";
                        $i15.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDG.GeoLocation, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DeliveryLocation);
                        }, $mXJHfh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DeliveryLocation = value.AsReference($.$fPer.LCFCDG.GeoLocation);
                        }, $nUrWGb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DateDelivered"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DateDelivered", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DateDelivered")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "DateDelivered";
                        $i17.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DateDelivered);
                        }, $gfXJMg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DateDelivered = value.AsNullableValue($.$$.S.DateTime);
                        }, $mvQjua ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DateConfirmed"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DateConfirmed", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DateConfirmed")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "DateConfirmed";
                        $i19.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DateConfirmed);
                        }, $bQswBb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DateConfirmed = value.AsNullableValue($.$$.S.DateTime);
                        }, $djVECa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Type";
                        $i21.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Type);
                        }, $bhGLDb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ShipmentId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "ShipmentId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ShipmentId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "ShipmentId";
                        $i23.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).ShipmentId);
                        }, $UgQIXe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ShipmentId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $oLItCa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisplayIcon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "DisplayIcon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisplayIcon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "DisplayIcon";
                        $i25.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).DisplayIcon);
                        }, $hUquOk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisplayIcon = value.AsReference($.$$.S.String);
                        }, $ilhGjc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IconDescriptor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "IconDescriptor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IconDescriptor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "IconDescriptor";
                        $i27.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).IconDescriptor);
                        }, $jDCjUc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Sender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.IShipmentAccount, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "Sender";
                        $i29.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$YUlm.LCSCM.IShipmentAccount, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Sender);
                        }, $EGwSRc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Receiver"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Receiver", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Receiver")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$YUlm.LCSCM.IShipmentAccount, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "Receiver";
                        $i31.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$YUlm.LCSCM.IShipmentAccount, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Receiver);
                        }, $zhlYyg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Products"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Products", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Products")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t33 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Name = "Products";
                        $i33.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i33.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Products);
                        }, $vPoenf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i33;
                    })()), schemas, null, factory);
                    let $en34 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en34.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t35 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i35 = new $t35();
                        $i35.$ctor$2();
                        $i35.Name = "Amount";
                        $i35.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i35.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Amount);
                        }, $wKbQSh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i35;
                    })()), schemas, null, factory);
                    let $en36 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en36.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en36.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Weight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Weight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Weight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Weight, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t37 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i37 = new $t37();
                        $i37.$ctor$2();
                        $i37.Name = "Weight";
                        $i37.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i37.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Weight, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Weight);
                        }, $Zukoii ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i37;
                    })()), schemas, null, factory);
                    let $en38 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en38.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t39 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i39 = new $t39();
                        $i39.$ctor$2();
                        $i39.Name = "Link";
                        $i39.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel";
                        $i39.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)).Link);
                        }, $QmJJLg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1068399,"h":0,"f":17825826});
                        return $i39;
                    })()), schemas, null, factory);
                    let $en40 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en40.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en40.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885970287)
            
            //--TRIMMABLE-BOUNDARY-START(17180937583)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180937583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)));
                {
                    /*var*/ let _QueryState = _target.QueryState;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("QueryState"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCP.PostQueryableState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCP.PostQueryableState, () => _QueryState, ($v) => _QueryState = $v, null, true)))
                    {
                        _target.QueryState = _QueryState;
                    }
                }
                {
                    /*var*/ let _DatePaid = _target.DatePaid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DatePaid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _DatePaid, ($v) => _DatePaid = $v, null, true)))
                    {
                        _target.DatePaid = $.$clone(_DatePaid);
                    }
                }
                {
                    /*var*/ let _PaymentReference = _target.PaymentReference;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PaymentReference"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PaymentReference, ($v) => _PaymentReference = $v, $.$$.S.String)))
                    {
                        _target.PaymentReference = _PaymentReference;
                    }
                }
                {
                    /*var*/ let _FreightShipment = _target.FreightShipment;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FreightShipment"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$RffN.LCCBCM.BuyLinkOrderShipmentType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$RffN.LCCBCM.BuyLinkOrderShipmentType, () => _FreightShipment, ($v) => _FreightShipment = $v, null, true)))
                    {
                        _target.FreightShipment = _FreightShipment;
                    }
                }
                {
                    /*var*/ let _Delivery = _target.Delivery;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Delivery"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.ShipmentDeliveryType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$YUlm.LCSCM.ShipmentDeliveryType, () => _Delivery, ($v) => _Delivery = $v, null, true)))
                    {
                        _target.Delivery = _Delivery;
                    }
                }
                {
                    /*var*/ let _DeliveryAddress = _target.DeliveryAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DeliveryAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DeliveryAddress, ($v) => _DeliveryAddress = $v, $.$$.S.String)))
                    {
                        _target.DeliveryAddress = _DeliveryAddress;
                    }
                }
                {
                    /*var*/ let _PickupLocation = _target.PickupLocation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PickupLocation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDG.GeoLocation));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _PickupLocation, ($v) => _PickupLocation = $v, $.$fPer.LCFCDG.GeoLocation)))
                    {
                        _target.PickupLocation = _PickupLocation;
                    }
                }
                {
                    /*var*/ let _DeliveryLocation = _target.DeliveryLocation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DeliveryLocation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDG.GeoLocation));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _DeliveryLocation, ($v) => _DeliveryLocation = $v, $.$fPer.LCFCDG.GeoLocation)))
                    {
                        _target.DeliveryLocation = _DeliveryLocation;
                    }
                }
                {
                    /*var*/ let _DateDelivered = _target.DateDelivered;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DateDelivered"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _DateDelivered, ($v) => _DateDelivered = $v, null, true)))
                    {
                        _target.DateDelivered = $.$clone(_DateDelivered);
                    }
                }
                {
                    /*var*/ let _DateConfirmed = _target.DateConfirmed;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DateConfirmed"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _DateConfirmed, ($v) => _DateConfirmed = $v, null, true)))
                    {
                        _target.DateConfirmed = $.$clone(_DateConfirmed);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _ShipmentId = _target.ShipmentId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ShipmentId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _ShipmentId, ($v) => _ShipmentId = $v, null, true)))
                    {
                        _target.ShipmentId = $.$clone(_ShipmentId);
                    }
                }
                {
                    /*var*/ let _DisplayIcon = _target.DisplayIcon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisplayIcon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DisplayIcon, ($v) => _DisplayIcon = $v, $.$$.S.String)))
                    {
                        _target.DisplayIcon = _DisplayIcon;
                    }
                }
                {
                    /*var*/ let _IconDescriptor = _target.IconDescriptor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IconDescriptor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _IconDescriptor, ($v) => _IconDescriptor = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Sender = _target.Sender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.IShipmentAccount));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Sender, ($v) => _Sender = $v, $.$YUlm.LCSCM.IShipmentAccount)))
                    {
                    }
                }
                {
                    /*var*/ let _Receiver = _target.Receiver;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Receiver"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$YUlm.LCSCM.IShipmentAccount));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Receiver, ($v) => _Receiver = $v, $.$YUlm.LCSCM.IShipmentAccount)))
                    {
                    }
                }
                {
                    /*var*/ let _Products = _target.Products;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Products"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCCBCM.CommunityBuyLinkProductModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCCBCM.CommunityBuyLinkProductModel, property, $.$ref(() => _Products, ($v) => _Products = $v, $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel))))
                    {
                        if (_Products !== null)
                        {
                            let $en73 = _Products.SCG$IEnumerable$$$GetEnumerator();
                            while ($en73.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en73.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel), $.$RffN.LCCBCM.CommunityBuyLinkProductModel, property, $.$ref(() => _Products, ($v) => _Products = $v, $.$$.SCG.IEnumerable$$($.$RffN.LCCBCM.CommunityBuyLinkProductModel)));
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Amount, ($v) => _Amount = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Weight = _target.Weight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Weight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Weight));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Weight, () => _Weight, ($v) => _Weight = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180937583)
            
            //--TRIMMABLE-BOUNDARY-START(8591002991)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591002991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCM.CommunityBuyLinkOrderModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel)))
                {
                    /*var*/ let result = $.$RffN.LCCBCM.CommunityBuyLinkOrderModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkOrderModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591002991)
            
            static $h = 1068399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885970287),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1068399,
      "h": 12885970287,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885970287),
//--TRIMMABLE-BOUNDARY-START(17180937583),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 937327,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1068399,
      "h": 17180937583,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180937583),
//--TRIMMABLE-BOUNDARY-START(8591002991),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 937327,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1068399,
      "h": 8591002991,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591002991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296035695),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1068399,
      "h": 4296035695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296035695)
  ],
  "h": 1068399
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkOrderModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1068399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1658223)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor`, ($self) => class CommunityBuyLinkProductBaseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296625519)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296625519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.GenerateProperties($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, this, factory);
                    }, $XSmRfc ??= {"r":65537,"n":"","d":1658223,"h":0,"f":17825794}), 0, "CommunityBuyLinkProductBaseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Models_CommunityBuyLinkProductBaseModel_LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModelTypeDescriptorBuilder.g.cs", "CommunityBuyLinkProductBaseModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296625519)
            
            //--TRIMMABLE-BOUNDARY-START(12886560111)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886560111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("QueryState"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "QueryState", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("QueryState")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCP.PostQueryableState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "QueryState";
                        $i1.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCP.PostQueryableState, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).QueryState);
                        }, $geWLCg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.QueryState = value.AsEnumValue($.$LCOv.LCFCP.PostQueryableState);
                        }, $HaByec ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Quantity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "Quantity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Quantity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Quantity";
                        $i3.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).Quantity);
                        }, $nqEZba ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Quantity = value.AsInt();
                        }, $yHBIai ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Url"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "Url", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Url")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Url";
                        $i5.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).Url);
                        }, $TeUagj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Url = value.AsReference($.$$.S.String);
                        }, $IFalOj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SiteName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "SiteName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SiteName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "SiteName";
                        $i7.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).SiteName);
                        }, $lKRrcb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SiteName = value.AsReference($.$$.S.String);
                        }, $bzanGe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UnitCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "UnitCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UnitCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "UnitCost";
                        $i9.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).UnitCost);
                        }, $BmXgfi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UnitCost = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $oWIzGa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Weight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "Weight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Weight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Weight, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Weight";
                        $i11.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Weight, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).Weight);
                        }, $LWHTel ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Weight = value.AsValue($.$fPer.LCFCDM.Weight);
                        }, $uRKtWb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HotDeal"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "HotDeal", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HotDeal")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "HotDeal";
                        $i13.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).HotDeal);
                        }, $vjIdVk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.HotDeal = value.AsBool();
                        }, $snKbQh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SiteIcon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "SiteIcon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SiteIcon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "SiteIcon";
                        $i15.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).SiteIcon);
                        }, $FsCwnd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SiteIcon = value.AsReference($.$$.S.String);
                        }, $PZSlUh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProductIcons"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "ProductIcons", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProductIcons")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "ProductIcons";
                        $i17.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).ProductIcons);
                        }, $VOWaBj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ProductIcons = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $xszlQg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IconDescriptor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel.$type, $.$discardRef(), "IconDescriptor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IconDescriptor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "IconDescriptor";
                        $i19.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)).IconDescriptor);
                        }, $wUjpBg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1658223,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886560111)
            
            //--TRIMMABLE-BOUNDARY-START(17181527407)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181527407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkOrderModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$RffN.LCCBCM.CommunityBuyLinkOrderModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _QueryState = _target.QueryState;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("QueryState"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCP.PostQueryableState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCP.PostQueryableState, () => _QueryState, ($v) => _QueryState = $v, null, true)))
                    {
                        _target.QueryState = _QueryState;
                    }
                }
                {
                    /*var*/ let _Quantity = _target.Quantity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Quantity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Quantity, ($v) => _Quantity = $v, $.$$.S.Int32)))
                    {
                        _target.Quantity = _Quantity;
                    }
                }
                {
                    /*var*/ let _Url = _target.Url;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Url"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Url, ($v) => _Url = $v, $.$$.S.String)))
                    {
                        _target.Url = _Url;
                    }
                }
                {
                    /*var*/ let _SiteName = _target.SiteName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SiteName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SiteName, ($v) => _SiteName = $v, $.$$.S.String)))
                    {
                        _target.SiteName = _SiteName;
                    }
                }
                {
                    /*var*/ let _UnitCost = _target.UnitCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UnitCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _UnitCost, ($v) => _UnitCost = $v, null, true)))
                    {
                        _target.UnitCost = $.$clone(_UnitCost);
                    }
                }
                {
                    /*var*/ let _Weight = _target.Weight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Weight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Weight));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Weight, () => _Weight, ($v) => _Weight = $v, null, true)))
                    {
                        _target.Weight = $.$clone(_Weight);
                    }
                }
                {
                    /*var*/ let _HotDeal = _target.HotDeal;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HotDeal"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _HotDeal, ($v) => _HotDeal = $v, null, true)))
                    {
                        _target.HotDeal = _HotDeal;
                    }
                }
                {
                    /*var*/ let _SiteIcon = _target.SiteIcon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SiteIcon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SiteIcon, ($v) => _SiteIcon = $v, $.$$.S.String)))
                    {
                        _target.SiteIcon = _SiteIcon;
                    }
                }
                {
                    /*var*/ let _ProductIcons = _target.ProductIcons;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProductIcons"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _ProductIcons, ($v) => _ProductIcons = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.ProductIcons = _ProductIcons;
                        if (_ProductIcons !== null)
                        {
                            let $en35 = _ProductIcons.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en35.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _ProductIcons, ($v) => _ProductIcons = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _IconDescriptor = _target.IconDescriptor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IconDescriptor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _IconDescriptor, ($v) => _IconDescriptor = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181527407)
            
            //--TRIMMABLE-BOUNDARY-START(8591592815)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591592815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel)))
                {
                    /*var*/ let result = $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591592815)
            
            static $h = 1658223;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886560111),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1658223,
      "h": 12886560111,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886560111),
//--TRIMMABLE-BOUNDARY-START(17181527407),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1527151,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1658223,
      "h": 17181527407,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181527407),
//--TRIMMABLE-BOUNDARY-START(8591592815),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1527151,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1658223,
      "h": 8591592815,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591592815)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296625519),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1658223,
      "h": 4296625519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296625519)
  ],
  "h": 1658223
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductBaseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1658223)
        
        

        //--TRIMMABLE-BOUNDARY-START(2837871)
        $asm.$cls(`$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking`, ($self) => class ICommunityBuyLinkProductPoolFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297805167)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297805167);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297805167)
            
            //--TRIMMABLE-BOUNDARY-START(8592772463)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592772463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592772463)
            
            static $h = 2837871;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297805167),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2837871,
      "h": 4297805167,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297805167)
  ],
  "h": 2837871
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$RffN.LCCBCS.ICommunityBuyLinkProductPoolFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Services.ICommunityBuyLinkProductPoolFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Services${separator}ICommunityBuyLinkProductPoolFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2837871)
        
        

        //--TRIMMABLE-BOUNDARY-START(4017519)
        $asm.$cls(`$RffN.LCFCR.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298984815)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298984815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298984815)
            
            //--TRIMMABLE-BOUNDARY-START(8593952111)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593952111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593952111)
            
            //--TRIMMABLE-BOUNDARY-START(17183886703)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183886703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183886703)
            
            //--TRIMMABLE-BOUNDARY-START(21478853999)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478853999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478853999)
            
            //--TRIMMABLE-BOUNDARY-START(25773821295)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$BuyLink$Common$Models$CommunityBuyLinkProductPoolModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773821295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773821295)
            
            //--TRIMMABLE-BOUNDARY-START(12888919407)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888919407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888919407)
            
            static $h = 4017519;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298984815),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4017519,
      "h": 4298984815,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298984815)
  ],
  "h": 4017519
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.ICreateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.IReadDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.IReadManyDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.IUpdateDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD.IDeleteDataService$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityBuyLinkProductPoolModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4017519)
        
        

        //--TRIMMABLE-BOUNDARY-START(675183)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkModel`, ($self) => class CommunityBuyLinkModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295642479)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295642479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295642479)
            
            //--TRIMMABLE-BOUNDARY-START(4295642479)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295642479)
            
            static $h = 675183;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295642479),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 675183,
      "h": 4295642479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295642479)
  ],
  "h": 675183
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(675183)
        
        

        //--TRIMMABLE-BOUNDARY-START(2182511)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor`, ($self) => class CommunityBuyLinkProductPoolModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297149807)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297149807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor.GenerateProperties($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, this, factory);
                    }, $XBMNBd ??= {"r":65537,"n":"","d":2182511,"h":0,"f":17825794}), 0, "CommunityBuyLinkProductPoolModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Models_CommunityBuyLinkProductPoolModel_LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModelTypeDescriptorBuilder.g.cs", "CommunityBuyLinkProductPoolModelTypeDescriptor", 43);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297149807)
            
            //--TRIMMABLE-BOUNDARY-START(12887084399)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887084399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PaymentMode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "PaymentMode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PaymentMode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PaymentMode";
                        $i1.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).PaymentMode);
                        }, $ihiMxk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.PaymentMode = value.AsEnumValue($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode);
                        }, $xJkMEe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PoolStartDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "PoolStartDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PoolStartDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PoolStartDate";
                        $i3.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).PoolStartDate);
                        }, $ieiSfg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PoolStartDate = value.AsNullableValue($.$$.S.DateTime);
                        }, $cWniok ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PoolEndDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "PoolEndDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PoolEndDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PoolEndDate";
                        $i5.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).PoolEndDate);
                        }, $pdKmJi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PoolEndDate = value.AsNullableValue($.$$.S.DateTime);
                        }, $qShzbf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Type";
                        $i7.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).Type);
                        }, $kwrTqb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Link";
                        $i9.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).Link);
                        }, $fieFri ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Queries"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "Queries", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Queries")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Queries";
                        $i11.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).Queries);
                        }, $WHSWke ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Queries = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel));
                        }, $AqPYbb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Answers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel.$type, $.$discardRef(), "Answers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Answers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Answers";
                        $i13.DelaredOn = "LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer), ($.$cast(target, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)).Answers);
                        }, $yyStOf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2182511,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Answers = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer));
                        }, $bwMXok ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2182511,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887084399)
            
            //--TRIMMABLE-BOUNDARY-START(17182051695)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182051695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductBaseModel?*/ let targetBase = _target;
                $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductBaseModel));
                {
                    /*var*/ let _PaymentMode = _target.PaymentMode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PaymentMode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$RffN.LCCBCM.CommunityBuyLinkPoolPaymentMode, () => _PaymentMode, ($v) => _PaymentMode = $v, null, true)))
                    {
                        _target.PaymentMode = _PaymentMode;
                    }
                }
                {
                    /*var*/ let _PoolStartDate = _target.PoolStartDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PoolStartDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _PoolStartDate, ($v) => _PoolStartDate = $v, null, true)))
                    {
                        _target.PoolStartDate = $.$clone(_PoolStartDate);
                    }
                }
                {
                    /*var*/ let _PoolEndDate = _target.PoolEndDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PoolEndDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _PoolEndDate, ($v) => _PoolEndDate = $v, null, true)))
                    {
                        _target.PoolEndDate = $.$clone(_PoolEndDate);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Queries = _target.Queries;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Queries"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), $.$LCOv.LCFCPM$1.QueryPostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), $.$LCOv.LCFCPM$1.QueryPostModel, property, $.$ref(() => _Queries, ($v) => _Queries = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel))))
                    {
                        _target.Queries = _Queries;
                        if (_Queries !== null)
                        {
                            let $en27 = _Queries.SCG$IEnumerable$$$GetEnumerator();
                            while ($en27.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en27.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.QueryPostModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel), $.$LCOv.LCFCPM$1.QueryPostModel, property, $.$ref(() => _Queries, ($v) => _Queries = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.QueryPostModel)));
                    }
                }
                {
                    /*var*/ let _Answers = _target.Answers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Answers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer), $.$fPer.LCFCD.QueryAnswer));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer), $.$fPer.LCFCD.QueryAnswer, property, $.$ref(() => _Answers, ($v) => _Answers = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer))))
                    {
                        _target.Answers = _Answers;
                        if (_Answers !== null)
                        {
                            let $en32 = _Answers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en32.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en32.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.QueryAnswer, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer), $.$fPer.LCFCD.QueryAnswer, property, $.$ref(() => _Answers, ($v) => _Answers = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.QueryAnswer)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182051695)
            
            //--TRIMMABLE-BOUNDARY-START(8592117103)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592117103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel)))
                {
                    /*var*/ let result = $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592117103)
            
            static $h = 2182511;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887084399),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2182511,
      "h": 12887084399,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887084399),
//--TRIMMABLE-BOUNDARY-START(17182051695),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2051439,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2182511,
      "h": 17182051695,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182051695),
//--TRIMMABLE-BOUNDARY-START(8592117103),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2051439,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2182511,
      "h": 8592117103,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592117103)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297149807),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2182511,
      "h": 4297149807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297149807)
  ],
  "h": 2182511
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkProductPoolModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkProductPoolModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkProductPoolModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2182511)
        
        

        //--TRIMMABLE-BOUNDARY-START(806255)
        $asm.$cls(`$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptor`, ($self) => class CommunityBuyLinkModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295773551)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295773551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptor.GenerateProperties($.$RffN.LCCBCM.CommunityBuyLinkModel, this, factory);
                    }, $nhTvde ??= {"r":65537,"n":"","d":806255,"h":0,"f":17825794}), 0, "CommunityBuyLinkModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.BuyLink.Common\\Models_CommunityBuyLinkModel_LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModelTypeDescriptorBuilder.g.cs", "CommunityBuyLinkModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295773551)
            
            //--TRIMMABLE-BOUNDARY-START(12885708143)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885708143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885708143)
            
            //--TRIMMABLE-BOUNDARY-START(17180675439)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180675439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.BuyLink.Common.Settings.CommunityBuyLinkSettings, LivingThing.Core.Community.BuyLink.Common.States.CommunityBuyLinkStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$RffN.LCCBCS$1.CommunityBuyLinkSettings, $.$RffN.LCCBCS$2.CommunityBuyLinkStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180675439)
            
            //--TRIMMABLE-BOUNDARY-START(8590740847)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590740847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$RffN.LCCBCM.CommunityBuyLinkModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkModel)))
                {
                    /*var*/ let result = $.$RffN.LCCBCM.CommunityBuyLinkModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$RffN.LCCBCM.CommunityBuyLinkModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$RffN.LCCBCM.CommunityBuyLinkModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590740847)
            
            static $h = 806255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885708143),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 806255,
      "h": 12885708143,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885708143),
//--TRIMMABLE-BOUNDARY-START(17180675439),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 675183,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 806255,
      "h": 17180675439,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180675439),
//--TRIMMABLE-BOUNDARY-START(8590740847),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 675183,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 806255,
      "h": 8590740847,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590740847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295773551),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 806255,
      "h": 4295773551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295773551)
  ],
  "h": 806255
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$RffN.LCCBCM.CommunityBuyLinkModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.BuyLink.Common.Models.CommunityBuyLinkModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}BuyLink${separator}Common${separator}Models${separator}CommunityBuyLinkModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(806255)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(19823)
