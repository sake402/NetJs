
//--TRIMMABLE-BOUNDARY-START(52497)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $OnVo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $rBVewb;
    let $eEAnqi;
    let $cjcJta;
    let $BtiiEf;
    let $HdYTNe;
    let $dZehAk;
    let $dhoFua;
    let $BpInGg;
    let $bKtiij;
    let $LeISlb;
    let $uvfYYd;
    let $ONGGoi;
    let $xhCkcf;
    let $TeKWGk;
    let $LbrGyg;
    let $FVTysi;
    let $vPdjTg;
    let $TAucpf;
    let $JtyVlc;
    let $AAvQCf;
    let $jdEtyf;
    let $WuYMfi;
    let $AFkDQj;
    let $CXYMRj;
    let $rmZLge;
    let $VUnHTd;
    let $zKFDZj;
    let $JcfpSg;
    let $GQIcsi;
    let $KZjVQj;
    let $nNGeFg;
    let $jWcWjk;
    let $SaSFWk;
    let $tbSmPa;
    let $VniWrd;
    let $JseLbg;
    let $UzaQRc;
    let $dzZEHh;
    let $Uwgofg;
    let $Lkapii;
    let $GhtmKa;
    let $SMJBDa;
    let $bcoRLa;
    let $iCyHWh;
    let $bCWmOj;
    let $gzOzUi;
    let $eaDwVi;
    let $ljushf;
    let $tDNhxa;
    let $SVBUff;
    let $GpTQqk;
    let $IXgEag;
    let $XeatRh;
    let $zzjuDa;
    let $tLLOdb;
    let $ZxdRej;
    let $HwdzRb;
    let $wMZRdj;
    let $FlpCbb;
    let $hvOAAc;
    let $msKQnl;
    let $zgeNFk;
    let $ieSvDj;
    let $fluinb;
    let $vKtmzj;
    let $CHOYQc;
    let $QHFQZh;
    let $lVHXqe;
    let $grDdpi;
    let $XnSpke;
    let $fBTRTk;
    let $regPsd;
    let $Klfqzk;
    let $VfWwjg;
    let $eoJxId;
    let $uKwSOk;
    let $MmKljl;
    let $QIKrDa;
    let $sDFzQg;
    let $APfvLj;
    let $eEcrZj;
    let $eVUhnf;
    let $SXoyOf;
    let $jxOCif;
    let $dwnFzb;
    let $BhwhTi;
    let $ywcHkl;
    let $vqkgRj;
    let $IQBFxa;
    let $TKXRhc;
    let $qhlwAg;
    let $dlTXdk;
    let $eRARKc;
    let $XQzTHf;
    let $NoiLEd;
    let $YfuxHi;
    let $IRxWSf;
    let $xGTVDe;
    let $VNmuXj;
    let $eHEzZd;
    let $kvUNhd;
    let $FTNptb;
    let $WXztnh;
    let $bvSghl;
    let $OicFXf;
    let $VZpSlj;
    let $LUFQlg;
    let $chAWBb;
    let $DDBwid;
    let $CipHXj;
    let $JWTLLk;
    let $TxTPGe;
    let $SbUfib;
    let $PKQKBk;
    let $COpfdd;
    let $ZCaVSc;
    let $JADZWd;
    let $UeNmec;
    let $CkpaOj;
    let $SNVZea;
    let $uMpIHi;
    let $oiztqd;
    let $vaJoxf;
    let $iisvwj;
    let $xVrUll;
    let $BIyOue;
    let $GjAdDe;
    let $lNaKBg;
    let $pdLloi;
    let $MSSnTd;
    let $EDEUqg;
    let $TQZuYe;
    let $rvhHBh;
    let $QtDPxi;
    let $dfyFTf;
    let $gzIDxj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Calendar.Client.Blazor", 
    {
  "h": 52497,
  "f": "LivingThing.Core.Community.Calendar.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Calendar.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Calendar.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(773393)
        $asm.$cls(`$Filo.LCCCCS$1.CalendarHourly`, ($self) => class CalendarHourly extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360511761)
            /*int*/ Hour = 0;
            //--TRIMMABLE-BOUNDARY-END(34360511761)
            
            //--TRIMMABLE-BOUNDARY-START(38655479057)
            /*CommunityCalendarEventSessionPostModel?*/ Session = null;
            //--TRIMMABLE-BOUNDARY-END(38655479057)
            
            //--TRIMMABLE-BOUNDARY-START(12885675281)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885675281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885675281)
            
            //--TRIMMABLE-BOUNDARY-START(12885675281)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885675281)
            
            static $h = 773393;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360511761),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475609873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245413649,
        "f": 83886081
      },
      "n": "Hour",
      "d": 773393,
      "h": 34360511761,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360511761),
//--TRIMMABLE-BOUNDARY-START(38655479057),
    {
      "p": 2106739,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065544465,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835348241,
        "f": 83886081
      },
      "n": "Session",
      "d": 773393,
      "h": 38655479057,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655479057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885675281),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 773393,
      "h": 12885675281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885675281)
  ],
  "h": 773393
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CalendarHourly`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CalendarHourly`; }
        });
        //--TRIMMABLE-BOUNDARY-END(773393)
        
        

        //--TRIMMABLE-BOUNDARY-START(249105)
        $asm.$cls(`$Filo.LCCCC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295216401)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295216401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Filo.LCCCC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295216401)
            
            static $h = 249105;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295216401),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 249105,
      "h": 4295216401,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295216401)
  ],
  "h": 249105
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(249105)
        
        

        //--TRIMMABLE-BOUNDARY-START(118033)
        $asm.$cls(`$Filo._LCCCCSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295085329)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295085329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295085329)
            
            static $h = 118033;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295085329),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 118033,
      "h": 4295085329,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295085329)
  ],
  "h": 118033
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendarUpcomingEvents.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendarUpcomingEvents${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(118033)
        
        

        //--TRIMMABLE-BOUNDARY-START(642321)
        $asm.$cls(`$Filo.LCCCCS.CommunityCalendarProvider`, ($self) => class CommunityCalendarProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590576913)
            /*CommunityCalendarApplication*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(8590576913)
            
            //--TRIMMABLE-BOUNDARY-START(4295609617)
            $ctor$1(/*CommunityCalendarApplication*/ application)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295609617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.application = application;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295609617)
            
            //--TRIMMABLE-BOUNDARY-START(17180511505)
            /*RenderFragment */ GetUpcomingEvents(/*PostBaseModel*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180511505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Filo.LCCCCS$1.CommunityCalendarUpcomingEvents, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Scope", scope);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180511505)
            
            //--TRIMMABLE-BOUNDARY-START(12885544209)
            /*RenderFragment */ GetCalendars(/*PostBaseModel*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885544209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*builder*/ builder) =>
                {
                    builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$ahDc.LCCCS.ICommunityClientApplication), 1);
                    builder.AddAttribute$4(2, "Value", this.application);
                    builder.AddAttribute$3(3, "ChildContent", $.$hDPm.LCFC.FragmentView.From$1($.$Filo.LCCCCP.CommunityCalendarApp, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.set_Item("ParentScope", parent);
                        return $i2;
                    })(), null, null));
                    builder.CloseComponent();
                }, $rBVewb ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":642321,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(12885544209)
            
            //--TRIMMABLE-BOUNDARY-START(8607274432)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityCalendarProvider.GetUpcomingEvents(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityCalendarProvider$GetUpcomingEvents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607274432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetUpcomingEvents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607274432)
            
            //--TRIMMABLE-BOUNDARY-START(4312307136)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityCalendarProvider.GetCalendars(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityCalendarProvider$GetCalendars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312307136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCalendars(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312307136)
            
            static $h = 642321;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180511505),
    {
      "r": 6881395,
      "p": [
        {
          "n": "scope",
          "p": 16771508
        }
      ],
      "n": "GetUpcomingEvents",
      "d": 642321,
      "h": 17180511505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180511505),
//--TRIMMABLE-BOUNDARY-START(12885544209),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetCalendars",
      "d": 642321,
      "h": 12885544209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885544209)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590576913),
    {
      "t": 511249,
      "n": "application",
      "d": 642321,
      "h": 8590576913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590576913)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295609617),
    {
      "p": [
        {
          "n": "application",
          "p": 511249
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 642321,
      "h": 4295609617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295609617)
  ],
  "h": 642321
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityCalendarProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Services.CommunityCalendarProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Services${separator}CommunityCalendarProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(642321)
        
        

        //--TRIMMABLE-BOUNDARY-START(314641)
        $asm.$cls(`$Filo.LCCCC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180183825)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCP.CommunityCalendarApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCP.CommunityCalendarApp().$ctor$6();
                    }, $eEAnqi ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCS$1.CommunityCalendar.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCS$1.CommunityCalendar().$ctor$5();
                    }, $cjcJta ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCS$1.CommunityCalendarCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCS$1.CommunityCalendarCard().$ctor$5();
                    }, $BtiiEf ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCS$1.CommunityCalendarPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCS$1.CommunityCalendarPage().$ctor$4();
                    }, $HdYTNe ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCS$1.CommunityCalendarTimeline.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCS$1.CommunityCalendarTimeline().$ctor$5();
                    }, $dZehAk ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Filo.LCCCCS$1.CommunityCalendarUpcomingEvents.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Filo.LCCCCS$1.CommunityCalendarUpcomingEvents().$ctor$3();
                    }, $dhoFua ??= {"r":2752627,"n":"","d":314641,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180183825)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295281937)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295281937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295281937)
            
            //--TRIMMABLE-BOUNDARY-START(4295281937)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295281937)
            
            static $h = 314641;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180183825),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885216529,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 314641,
      "h": 17180183825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180183825)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295281937),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 314641,
      "h": 4295281937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295281937)
  ],
  "h": 314641
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(314641)
        
        

        //--TRIMMABLE-BOUNDARY-START(445713)
        $asm.$cls(`$Filo.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590380305)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590380305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$Filo.LCCCCS.CommunityCalendarService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityCalendarProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Filo.LCCCCS.CommunityCalendarProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityCalendarProvider))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarProvider, x);
                }, $BpInGg ??= {"r":17339840,"p":[{"n":"x","p":327718}],"n":"","d":445713,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Filo.LCCCCS.CommunityCalendarApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarApplication, x);
                }, $bKtiij ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":445713,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarApplication, x);
                }, $LeISlb ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":445713,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, services, null);
                $.$hDPm.LCFCI.ViewProviderEtension.AddViewProvider($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$Filo.LCCCCS$1.CommunityCalendarCard, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$Filo.LCCCCS.CommunityCalendarFeedProvider, services);
                $.$Filo.LCCCC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590380305)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Filo.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295413009)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295413009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295413009)
            
            //--TRIMMABLE-BOUNDARY-START(4295413009)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295413009)
            
            static $h = 445713;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590380305),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 445713,
      "h": 8590380305,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590380305)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295413009),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 445713,
      "h": 4295413009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295413009)
  ],
  "h": 445713
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(445713)
        
        

        //--TRIMMABLE-BOUNDARY-START(1232145)
        $asm.$cls(`$Filo.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296199441)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296199441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296199441)
            
            //--TRIMMABLE-BOUNDARY-START(4296199441)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296199441)
            
            static $h = 1232145;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296199441),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1232145,
      "h": 4296199441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296199441)
  ],
  "h": 1232145,
  "a": [
    {
      "t": 1166609,
      "c": 4296133905
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1232145)
        
        

        //--TRIMMABLE-BOUNDARY-START(1166609)
        $asm.$cls(`$Filo.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296133905)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296133905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296133905)
            
            //--TRIMMABLE-BOUNDARY-START(4296133905)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296133905)
            
            static $h = 1166609;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296133905),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1166609,
      "h": 4296133905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296133905)
  ],
  "h": 1166609
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1166609)
        
        

        //--TRIMMABLE-BOUNDARY-START(183569)
        $asm.$cls(`$Filo.LCCCC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590118161)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590118161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590118161)
            
            //--TRIMMABLE-BOUNDARY-START(4295150865)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295150865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295150865)
            
            //--TRIMMABLE-BOUNDARY-START(4295150865)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295150865)
            
            static $h = 183569;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590118161),
    {
      "r": 65537,
      "n": "Execute",
      "d": 183569,
      "h": 8590118161,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590118161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295150865),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 183569,
      "h": 4295150865,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295150865)
  ],
  "h": 183569
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(183569)
        
        

        //--TRIMMABLE-BOUNDARY-START(1101073)
        $asm.$cls(`$Filo.LCCCCS$1.CommunityCalendarUpcomingEvents`, ($self) => class CommunityCalendarUpcomingEvents extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(47245741329)
            /*PostBaseModel*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(47245741329)
            
            //--TRIMMABLE-BOUNDARY-START(64425610513)
            /*DataFilter */ get UpcomingCalendarFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655806737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let now = $.$$.S.DateTime.UtcNow.Date;
                /*var*/ let thiryDaysAway = now.AddDays(30);
                return new $.$fPer.LCFCD.DataFilter().$ctor$17(1, 4, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                {
                    //new $.$LCOv.LCFCPM$1.PostSearchModel()
                    const $t1 = $.$LCOv.LCFCPM$1.PostSearchModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Attributes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAttributeFilterModel), [(() =>
                    {
                        //new $.$LCOv.LCFCPM$1.PostAttributeFilterModel()
                        const $t2 = $.$LCOv.LCFCPM$1.PostAttributeFilterModel;
                        const $i2 = new $t2();
                        $i2.$ctor$3();
                        $i2.Type = "StartDate";
                        $i2.SValue = $.$fPer.LCFCD.ValueRange$$($.$$.S.Double).op_Implicit((() =>
                        {
                            //new $.$fPer.LCFCD.ValueRange$$($.$$.S.Double)()
                            const $t3 = $.$fPer.LCFCD.ValueRange$$($.$$.S.Double);
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.Minimum = Number(now.Ticks);
                            $i3.Maximum = Number(thiryDaysAway.Ticks);
                            return $i3;
                        })());
                        return $i2;
                    })()], null, null);
                    return $i1;
                })(), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(64425610513)
            
            //--TRIMMABLE-BOUNDARY-START(42950774033)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendarupcomingevents";
            }
            //--TRIMMABLE-BOUNDARY-END(42950774033)
            
            //--TRIMMABLE-BOUNDARY-START(60130643217)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130643217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "Scope":
                    this.Scope = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(60130643217)
            
            //--TRIMMABLE-BOUNDARY-START(12886002961)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886002961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), 0);
                __builder.AddComponentParameter(1, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/**/ s) =>
                {
                    return s.LCFCD$IReadManyDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$ReadMany(this.UpcomingCalendarFilter, null).ContinueWith$47($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this,  (/*t*/ t) =>
                    {
                        return (() =>
                        {
                            //new $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))()
                            const $t5 = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                            const $i5 = new $t5();
                            $i5.$ctor$2();
                            $i5.Data = t.Result.Data;
                            $i5.Success = t.Result.Success;
                            return $i5;
                        })();
                    }, $WuYMfi ??= {"r":$.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h,"p":[{"n":"t","p":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":1101073,"h":0,"f":17825794}));
                }), $AFkDQj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))).$h,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$h}],"n":"","d":1101073,"h":0,"f":17825794}));
                __builder.AddComponentParameter(2, "Features", "RemoteFeatures.Default|RemoteFeatures.RenderWhileLoading");
                __builder.AddComponentParameter(3, "Class", "pdx");
                __builder.AddAttribute$3(4, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*upComingCalendars*/ upComingCalendars) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenElement(5, "div");
                        __builder2.AddAttribute$5(6, "class", "text-center bdb mgb");
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>*/ let __ca1__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>*/ let __ca2__;
                        /*var*/ let banners = ((__ca1__ = upComingCalendars.Model) !== null ? (((__ca2__ = $.$sl.SL.Enumerable.SelectMany$2($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$Iaui.LCFCM.ResourceModel, __ca1__, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.Resources;
                        }, $CXYMRj ??= {"r":$.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h,"p":[{"n":"e","p":1320307}],"n":"","d":1101073,"h":0,"f":17825794}))) !== null ? ($.$sl.SL.Enumerable.ToArray($.$Iaui.LCFCM.ResourceModel, __ca2__) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ResourceModel), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ResourceModel), null, [0], null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ResourceModel), null, [0], null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.ResourceModel), null, [0], null));
                        __builder2.OpenComponent$1($.$hDPm.LCFCCS$9.Slider, 7);
                        __builder2.AddComponentParameter(8, "CurrentSlide", "0");
                        __builder2.AddComponentParameter(9, "Class", "pos mg-a");
                        __builder2.AddComponentParameter(10, "Context", "_");
                        __builder2.AddComponentParameter(11, "AutoPlay", "true");
                        __builder2.AddComponentParameter(12, "ShowNavigators", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        __builder2.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            let $i6 = 0;
                            let $arr6 = banners;
                            while ($i6 < $arr6.length)
                            {
                                let banner = $arr6[$i6++];
                                __builder3.OpenComponent$1($.$hDPm.LCFCCS$9.Slide, 14);
                                __builder3.AddComponentParameter(15, "TransitionIn", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 81/*DisplayMode.SlideInLeft*/), $.$hDPm.LCFCI.DisplayMode));
                                __builder3.AddComponentParameter(16, "TransitionOut", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.DisplayMode, 3/*DisplayMode.Hide*/), $.$hDPm.LCFCI.DisplayMode));
                                __builder3.AddComponentParameter(17, "Class", "flex");
                                __builder3.AddComponentParameter(18, "Duration", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 7000), $.$$.S.Int32));
                                __builder3.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(20, "div");
                                        __builder4.AddAttribute$5(21, "class", "mg-a");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 22);
                                        __builder4.AddComponentParameter(23, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, banner));
                                        __builder4.AddComponentParameter(24, "Class", "mawp-10");
                                        __builder4.CloseComponent();
                                        __builder4.CloseElement();
                                    }, $rmZLge ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1101073,"h":0,"f":17825794});
                                }), $VUnHTd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1101073,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                        }), $zKFDZj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1101073,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>?*/ let __ca3__;
                        if ((__ca3__ = upComingCalendars.Model) !== null ? $.$sl.SL.Enumerable.Any$1($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, __ca3__) : false)
                        {
                            __builder2.AddMarkupContent(25, "<h2 class=\"mgb-0 cl-primary\">Upcoming Calendars</h2>\r\n        ");
                            $.$Filo._LCCCCSC.TypeInference.CreateDataList_0($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, __builder2, 26, 27, upComingCalendars.Model, 28, 35184372092928n | 65536n | 8388608n, 29, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this,  (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    /*var*/ let startDays = 1;
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 30);
                                    __builder3.AddComponentParameter(31, "Icon", "mdi-book");
                                    __builder3.AddComponentParameter(32, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Name));
                                    __builder3.AddComponentParameter(33, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, startDays > 0 ? `Starting in ${$.$strNN(startDays)} days` : "Ongoing"));
                                    __builder3.AddComponentParameter(34, "NavigateIcon", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                    __builder3.AddComponentParameter(35, "Page", "Calendar");
                                    __builder3.AddComponentParameter(36, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, context));
                                    __builder3.CloseComponent();
                                }, $JcfpSg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1101073,"h":0,"f":17825794});
                            }, $GQIcsi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":1101073,"h":0,"f":17825794}));
                        }
                    }, $KZjVQj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1101073,"h":0,"f":17825794});
                }), $nNGeFg ??= {"r":6881395,"p":[{"n":"upComingCalendars","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":1101073,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886002961)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591035665)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591035665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591035665)
            
            //--TRIMMABLE-BOUNDARY-START(8591035665)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591035665)
            
            static $h = 1101073;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245741329),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065872145,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835675921,
        "f": 83886081
      },
      "n": "Scope",
      "d": 1101073,
      "h": 47245741329,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245741329),
//--TRIMMABLE-BOUNDARY-START(64425610513),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655806737,
        "f": 50331650
      },
      "n": "UpcomingCalendarFilter",
      "d": 1101073,
      "h": 64425610513,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425610513),
//--TRIMMABLE-BOUNDARY-START(42950774033),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475937553,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1101073,
      "h": 42950774033,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950774033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130643217),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1101073,
      "h": 60130643217,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130643217),
//--TRIMMABLE-BOUNDARY-START(12886002961),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1101073,
      "h": 12886002961,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886002961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591035665),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1101073,
      "h": 8591035665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591035665)
  ],
  "h": 1101073
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendarUpcomingEvents`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendarUpcomingEvents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1101073)
        
        

        //--TRIMMABLE-BOUNDARY-START(838929)
        $asm.$cls(`$Filo.LCCCCS$1.CommunityCalendar`, ($self) => class CommunityCalendar extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(34360577297)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendar";
            }
            //--TRIMMABLE-BOUNDARY-END(34360577297)
            
            //--TRIMMABLE-BOUNDARY-START(25770642705)
            /*IEnumerable<CommunityCalendarEventPostModel> */ GetCalendars(/*IEnumerable<CommunityCalendarEventPostModel>*/ calendars, /*DateOnly*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770642705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Where($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, calendars, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.OccursOn(date);
                }, $jWcWjk ??= {"r":262145,"p":[{"n":"c","p":1320307}],"n":"","d":838929,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770642705)
            
            //--TRIMMABLE-BOUNDARY-START(30065610001)
            /*void */ OnCreated(/*object*/ sender, /*CommunityCalendarEventPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065610001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30065610001)
            
            //--TRIMMABLE-BOUNDARY-START(12885740817)
            /*Task *//*async*/  Delete(/*CommunityCalendarEventPostModel*/ Calendar)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885740817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885740817)
            
            //--TRIMMABLE-BOUNDARY-START(8590773521)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590773521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteServiceCall$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), 0);
                __builder.AddComponentParameter(1, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*s*/ s) =>
                {
                    return s.LCFCD$IReadManyDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$ReadMany(new $.$fPer.LCFCD.DataFilter().$ctor$21(`${$.$strNN(this.ViewModel.Identifier.ToString())}`, 1, 2147483647/*int.MaxValue*/), null).ContinueWith$47($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), new ($.$$.S.Func$$$($.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)), $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this,  (/*t*/ t) =>
                    {
                        return (() =>
                        {
                            //new $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))()
                            const $t1 = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                            const $i1 = new $t1();
                            $i1.$ctor$2();
                            $i1.Data = t.Result.Data;
                            $i1.Success = t.Result.Success;
                            return $i1;
                        })();
                    }, $SaSFWk ??= {"r":$.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h,"p":[{"n":"t","p":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                }), $tbSmPa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))).$h,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*calendars*/ calendars) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCIF.DateTimePicker, 3);
                        __builder2.AddComponentParameter(4, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.None));
                        __builder2.AddComponentParameter(5, "Class", "hf wf");
                        __builder2.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCIF.DateCell)))().$ctor(this, ( (/*date*/ date) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(7, "div");
                                __builder3.AddAttribute$5(8, "class", "hx-05 flex bdx pos-rel");
                                __builder3.OpenElement(9, "div");
                                __builder3.AddAttribute$5(10, "class", "mg-a clip");
                                __builder3.OpenElement(11, "div");
                                __builder3.AddContent$4(12, $.$$.S.Int32.ToString.call(date.Model.DateOfMonth));
                                __builder3.CloseElement();
                                let $en2 = this.GetCalendars(calendars.Model, date.Model.Date).SCG$IEnumerable$$$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let _Calendar = $en2.SCG$IEnumerator$$$Current;
                                    {
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 13);
                                        __builder3.AddComponentParameter(14, "VerticalPosition", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionY, (date.Model.DateOfMonth < 15 || date.Model.MonthOffset < 0) ? 3/*PositionY.TopToBottom*/ : 2/*PositionY.BottomToTop*/), $.$hDPm.LCFCCP$4.PositionY));
                                        __builder3.AddComponentParameter(15, "pop-class", "z-2 bg-dark");
                                        $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder3, 16, "onclick", true);
                                        __builder3.AddAttribute$3(17, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenElement(18, "button");
                                                __builder4.AddAttribute$5(19, "class", "lt primary corner-2 pd-1 nowrap bd-0");
                                                __builder4.AddAttribute$5(20, "title", _Calendar.Name);
                                                __builder4.AddContent$4(21, _Calendar.Name);
                                                __builder4.CloseElement();
                                            }, $VniWrd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                        }), $JseLbg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                        __builder3.AddAttribute$3(22, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*context*/ context) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                            {
                                                __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 23);
                                                __builder4.AddComponentParameter(24, "Selectable", "true");
                                                __builder4.AddComponentParameter(25, "Class", "text-left");
                                                __builder4.AddAttribute$3(26, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                                {
                                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                    {
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 27);
                                                        __builder5.AddComponentParameter(28, "Class", "nowrap");
                                                        __builder5.AddAttribute$3(29, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                        {
                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                            {
                                                                __builder6.AddMarkupContent(30, "<i class=\"mdi mdi-information-outline\"></i>");
                                                            }, $UzaQRc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                        }), $dzZEHh ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                        __builder5.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                        {
                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                            {
                                                                __builder6.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 32);
                                                                __builder6.AddComponentParameter(33, "href", "Calendar");
                                                                __builder6.AddComponentParameter(34, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, _Calendar));
                                                                __builder6.AddAttribute$3(35, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                                {
                                                                    __builder7.AddMarkupContent(36, "\r\n                                            Details\r\n                                        ");
                                                                }), $Uwgofg ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":838929,"h":0,"f":17825794}));
                                                                __builder6.CloseComponent();
                                                            }, $Lkapii ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                        }), $GhtmKa ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                        __builder5.CloseComponent();
                                                        __builder5.AddMarkupContent(37, "\r\n                                ");
                                                        __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 38);
                                                        __builder5.AddComponentParameter(39, "Class", "nowrap");
                                                        __builder5.AddAttribute$3(40, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                        {
                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                            {
                                                                __builder6.AddMarkupContent(41, "<i class=\"mdi mdi-chart-timeline\"></i>");
                                                            }, $SMJBDa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                        }), $bcoRLa ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                        __builder5.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                        {
                                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                            {
                                                                __builder6.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 43);
                                                                __builder6.AddComponentParameter(44, "href", "CalendarTimeline");
                                                                __builder6.AddComponentParameter(45, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, _Calendar));
                                                                __builder6.AddAttribute$3(46, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder7*/ __builder7) =>
                                                                {
                                                                    __builder7.AddMarkupContent(47, "\r\n                                            Timeline\r\n                                        ");
                                                                }), $iCyHWh ??= {"r":65537,"p":[{"n":"__builder7","p":7536755}],"n":"","d":838929,"h":0,"f":17825794}));
                                                                __builder6.CloseComponent();
                                                            }, $bCWmOj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                        }), $gzOzUi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                        __builder5.CloseComponent();
                                                        //if (true)
                                                        {
                                                            __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuCommandItem$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), 48);
                                                            __builder5.AddComponentParameter(49, "Class", "nowrap");
                                                            __builder5.AddComponentParameter(50, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, _Calendar));
                                                            __builder5.AddComponentParameter(51, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, this, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$$.STT.Task))().$ctor(this, this.Delete))));
                                                            __builder5.AddAttribute$3(52, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/**/ __) =>
                                                            {
                                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                                {
                                                                    __builder6.AddMarkupContent(53, "<i class=\"mdi mdi-delete\"></i>");
                                                                }, $eaDwVi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                            }), $ljushf ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                            __builder5.AddAttribute$3(54, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                                            {
                                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                                {
                                                                    __builder6.AddMarkupContent(55, "\r\n                                            Delete\r\n                                        ");
                                                                }, $tDNhxa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                            }), $SVBUff ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                            __builder5.CloseComponent();
                                                        }
                                                    }, $GpTQqk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                                }), $IXgEag ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                                                __builder4.CloseComponent();
                                            }, $XeatRh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                                        }), $zzjuDa ??= {"r":6881395,"p":[{"n":"context","p":39540394}],"n":"","d":838929,"h":0,"f":17825794}));
                                        __builder3.CloseComponent();
                                    }
                                }
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $tLLOdb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                        }), $ZxdRej ??= {"r":6881395,"p":[{"n":"date","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCIF.DateCell).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $HwdzRb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":838929,"h":0,"f":17825794});
                }), $wMZRdj ??= {"r":6881395,"p":[{"n":"calendars","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":838929,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590773521)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295806225)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295806225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295806225)
            
            //--TRIMMABLE-BOUNDARY-START(4295806225)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295806225)
            
            static $h = 838929;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360577297),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475675409,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 838929,
      "h": 34360577297,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360577297)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770642705),
    {
      "r": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$h,
      "p": [
        {
          "n": "calendars",
          "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$h
        },
        {
          "n": "date",
          "p": 65929217
        }
      ],
      "n": "GetCalendars",
      "d": 838929,
      "h": 25770642705,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770642705),
//--TRIMMABLE-BOUNDARY-START(30065610001),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "model",
          "p": 1320307
        }
      ],
      "n": "OnCreated",
      "d": 838929,
      "h": 30065610001,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30065610001),
//--TRIMMABLE-BOUNDARY-START(12885740817),
    {
      "r": 178454529,
      "p": [
        {
          "n": "Calendar",
          "p": 1320307
        }
      ],
      "n": "Delete",
      "d": 838929,
      "h": 12885740817,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(12885740817),
//--TRIMMABLE-BOUNDARY-START(8590773521),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 838929,
      "h": 8590773521,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590773521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295806225),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 838929,
      "h": 4295806225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295806225)
  ],
  "h": 838929
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(838929)
        
        

        //--TRIMMABLE-BOUNDARY-START(576785)
        $asm.$cls(`$Filo.LCCCCS.CommunityCalendarFeedProvider`, ($self) => class CommunityCalendarFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295544081)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295544081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295544081)
            
            //--TRIMMABLE-BOUNDARY-START(8590511377)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityCalendarEventPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590511377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an event on their calendar`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590511377)
            
            static $h = 576785;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590511377),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 1320307
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 576785,
      "h": 8590511377,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590511377)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295544081),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 576785,
      "h": 4295544081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295544081)
  ],
  "h": 576785
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Services.CommunityCalendarFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Services${separator}CommunityCalendarFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(576785)
        
        

        //--TRIMMABLE-BOUNDARY-START(904465)
        $asm.$cls(`$Filo.LCCCCS$1.CommunityCalendarCard`, ($self) => class CommunityCalendarCard extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21475740945)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendarcard";
            }
            //--TRIMMABLE-BOUNDARY-END(21475740945)
            
            //--TRIMMABLE-BOUNDARY-START(8590839057)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590839057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 0);
                __builder.AddComponentParameter(1, "href", this.ViewModel.Link);
                __builder.AddComponentParameter(2, "Class", "bg-card d-block corner-3 bd hx-35 stack bg-fill");
                __builder.AddComponentParameter(3, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `background-image:url(${$.$strNN(this.ResolvePath((this.ViewModel.Icon?.FullPath ?? null), true, false, false))})`));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "row pd");
                    __builder2.AddMarkupContent(7, "<div class=\"col-10 flex\"></div>\r\n        ");
                    __builder2.OpenElement(8, "div");
                    __builder2.AddAttribute$5(9, "class", "col-a");
                    __builder2.OpenElement(10, "div");
                    __builder2.AddAttribute$5(11, "class", "corner-3 hx-06 wx-06 bg-white bd stack");
                    __builder2.OpenElement(12, "h1");
                    __builder2.AddAttribute$5(13, "class", "text-center mgb-0 mgt-a");
                    __builder2.AddContent$3(14, $.$box(this.ViewModel.StartDate.Day, $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(15, "\r\n                ");
                    __builder2.OpenElement(16, "h5");
                    __builder2.AddAttribute$5(17, "class", "mgt-0 mgb-a text-center");
                    __builder2.AddContent$4(18, $.$$.S.String.ToUpper.call(this.ViewModel.StartDate.ToString$3("MMM")));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(19, "\r\n    <div class=\"fill\"></div>\r\n    ");
                    __builder2.OpenElement(20, "div");
                    __builder2.AddAttribute$5(21, "class", "bg-tertiary-05 pd row");
                    __builder2.OpenElement(22, "div");
                    __builder2.AddAttribute$5(23, "class", "col-a flex");
                    __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 24);
                    __builder2.AddComponentParameter(25, "Class", "hx-05 wx-05 mg-a");
                    __builder2.AddComponentParameter(26, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 50), $.$$.S.Int32));
                    __builder2.AddComponentParameter(27, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.ViewModel.Account));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(28, "\r\n        ");
                    __builder2.OpenElement(29, "div");
                    __builder2.AddAttribute$5(30, "class", "col-10 pdl");
                    __builder2.OpenElement(31, "p");
                    __builder2.AddAttribute$5(32, "class", "mg-0");
                    __builder2.AddContent$4(33, this.ViewModel.Account.Title);
                    __builder2.AddContent$4(34, " posted a ");
                    __builder2.AddContent$4(35, $.$$.S.String.ToUpper.call($.$$.S.Enum.ToStringT($.$OnVo.LCCCCM.CommunityCalendarEventType, $.$$.S.UInt32, this.ViewModel.EventType)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(36, "\r\n            ");
                    __builder2.OpenElement(37, "h3");
                    __builder2.AddAttribute$5(38, "class", "mg-0");
                    /*var*/ let icon = $.$fPer.LCFCT.EnumExtensions.GetDisplayable($.$box(this.ViewModel.EventType, $.$OnVo.LCCCCM.CommunityCalendarEventType));
                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 39);
                    __builder2.AddComponentParameter(40, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, icon.LCFC$IDisplayable$Icon));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(41, "\r\n                ");
                    __builder2.AddContent$4(42, this.ViewModel.Title);
                    __builder2.CloseElement();
                    if ($.$$.S.Int32.op_GreaterThan(this.ViewModel.SubscribersCount, 0))
                    {
                        __builder2.OpenElement(43, "small");
                        __builder2.AddAttribute$5(44, "class", "mg-0 op-8");
                        __builder2.AddContent$4(45, "Booked by ");
                        __builder2.AddContent$3(46, $.$box(this.ViewModel.SubscribersCount, $.$$.S.Int32));
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }), $uvfYYd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":904465,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590839057)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295871761)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295871761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295871761)
            
            //--TRIMMABLE-BOUNDARY-START(4295871761)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295871761)
            
            static $h = 904465;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475740945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180773649,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 904465,
      "h": 21475740945,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475740945)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590839057),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 904465,
      "h": 8590839057,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590839057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295871761),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 904465,
      "h": 4295871761,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295871761)
  ],
  "h": 904465
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendarCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendarCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(904465)
        
        

        //--TRIMMABLE-BOUNDARY-START(1035537)
        $asm.$cls(`$Filo.LCCCCS$1.CommunityCalendarTimeline`, ($self) => class CommunityCalendarTimeline extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(60130577681)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendartimeline";
            }
            //--TRIMMABLE-BOUNDARY-END(60130577681)
            
            //--TRIMMABLE-BOUNDARY-START(77310446865)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310446865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Date":
                    this.Date = $.$cast(parameter.Value, $.$$.S.Nullable$$($.$$.S.DateTime));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(77310446865)
            
            //--TRIMMABLE-BOUNDARY-START(17180904721)
            /*DateTime?*/ Date = null;
            //--TRIMMABLE-BOUNDARY-END(17180904721)
            
            //--TRIMMABLE-BOUNDARY-START(55835610385)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835610385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Date === null)
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel>?*/ let __ca1__;
                    if ($.$$.S.Int32.op_GreaterThan(((__ca1__ = this.ViewModel.Sessions) !== null ? $.$sl.SL.Enumerable.Count$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, __ca1__) : null), 0))
                    {
                        this.Date = $.$sl.SL.Enumerable.Min$22($.$$.S.DateTime, $.$sl.SL.Enumerable.Select$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$$.S.DateTime, this.ViewModel.Sessions, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$$.S.DateTime))().$ctor(this,  (/**/ s) =>
                        {
                            return s.StartDate.ToDateTime$1(s.StartTime);
                        }, $FlpCbb ??= {"r":65994753,"p":[{"n":"s","p":2106739}],"n":"","d":1035537,"h":0,"f":17825794})));
                    }
                    else 
                    {
                        this.Date = $.$$.S.DateTime.UtcNow;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835610385)
            
            //--TRIMMABLE-BOUNDARY-START(64425544977)
            /*void */ PreviousDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425544977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Date = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date).Subtract($.$$.S.TimeSpan.FromDays$2(1));
            }
            //--TRIMMABLE-BOUNDARY-END(64425544977)
            
            //--TRIMMABLE-BOUNDARY-START(51540643089)
            /*void */ NextDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540643089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Date = $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date).Add($.$$.S.TimeSpan.FromDays$2(1));
            }
            //--TRIMMABLE-BOUNDARY-END(51540643089)
            
            //--TRIMMABLE-BOUNDARY-START(47245675793)
            /*CalendarHourly[] */ get hours()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360773905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let daySessions = $.$sl.SL.Enumerable.Where($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, this.ViewModel.Sessions, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$$.S.DateTime.op_Equality(s.StartDate.ToDateTime$1(s.StartTime), $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date));
                }, $hvOAAc ??= {"r":262145,"p":[{"n":"s","p":2106739}],"n":"","d":1035537,"h":0,"f":17825794}));
                return $.$sl.SL.Enumerable.ToArray($.$Filo.LCCCCS$1.CalendarHourly, $.$sl.SL.Enumerable.Where($.$Filo.LCCCCS$1.CalendarHourly, $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$Filo.LCCCCS$1.CalendarHourly, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 1, 6, 17, 18, 19, 20, 21, 22, 23], null, null), new ($.$$.S.Func$$$($.$$.S.Int32, $.$Filo.LCCCCS$1.CalendarHourly))().$ctor(this,  (/*h*/ h) =>
                {
                    return (() =>
                    {
                        //new $.$Filo.LCCCCS$1.CalendarHourly()
                        const $t2 = $.$Filo.LCCCCS$1.CalendarHourly;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Hour = h;
                        $i2.Session = $.$sl.SL.Enumerable.FirstOrDefault$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, daySessions, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.StartTime.Hour === h;
                        }, $msKQnl ??= {"r":262145,"p":[{"n":"s","p":2106739}],"n":"","d":1035537,"h":0,"f":17825794}));
                        return $i2;
                    })();
                }, $zgeNFk ??= {"r":773393,"p":[{"n":"h","p":655361}],"n":"","d":1035537,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$$.S.Boolean))().$ctor(this,  (/*h*/ h) =>
                {
                    return h.Session !== null;
                }, $ieSvDj ??= {"r":262145,"p":[{"n":"h","p":773393}],"n":"","d":1035537,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(47245675793)
            
            //--TRIMMABLE-BOUNDARY-START(12885937425)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885937425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$2.DataTable$$($.$Filo.LCCCCS$1.CalendarHourly), 0);
                __builder.AddComponentParameter(1, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Filo.LCCCCS$1.CalendarHourly), this.hours));
                __builder.AddComponentParameter(2, "Selectable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddComponentParameter(3, "Bordered", "true");
                __builder.AddComponentParameter(4, "CellBordered", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly))))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly), 6);
                        __builder2.AddAttribute$3(7, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$Filo.LCCCCS$1.CalendarHourly)))().$ctor(this, ( (/*items*/ items) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(8, "div");
                                __builder3.AddAttribute$5(9, "class", "stack");
                                __builder3.OpenElement(10, "span");
                                __builder3.AddAttribute$5(11, "class", "mg-a mgb-2");
                                __builder3.AddContent$3(12, $.$box($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date).DayOfWeek, $.$$.S.DayOfWeek));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(13, "\r\n                ");
                                __builder3.OpenElement(14, "div");
                                __builder3.AddAttribute$5(15, "class", "mg-a hx-04 wx-04 round bg-primary flex fsz-18");
                                __builder3.OpenElement(16, "span");
                                __builder3.AddAttribute$5(17, "class", "mg-a");
                                __builder3.AddContent$3(18, $.$box($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date).Day, $.$$.S.Int32));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(19, "\r\n                ");
                                __builder3.OpenElement(20, "span");
                                __builder3.AddAttribute$5(21, "class", "mg-a mgt-2");
                                __builder3.AddContent$4(22, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Date).ToString$3("MMMM"));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $fluinb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                        }), $vKtmzj ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$Filo.LCCCCS$1.CalendarHourly).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(23, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly))))().$ctor(this, ( (/*item*/ item) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(24, "div");
                                __builder3.AddAttribute$5(25, "class", "text-center");
                                __builder3.AddContent$3(26, $.$box(item.Model.Hour, $.$$.S.Int32));
                                __builder3.AddContent$4(27, " ");
                                __builder3.AddContent$4(28, item.Model.Hour < 12 ? "AM" : "PM");
                                __builder3.CloseElement();
                            }, $CHOYQc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                        }), $QHFQZh ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly)).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(29, "\r\n    ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly), 30);
                        __builder2.AddAttribute$3(31, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$Filo.LCCCCS$1.CalendarHourly)))().$ctor(this, ( (/*items*/ items) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 32);
                                __builder3.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 34);
                                        __builder4.AddAttribute$3(35, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 36);
                                                __builder5.AddComponentParameter(37, "Outline", "true");
                                                __builder5.AddComponentParameter(38, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddComponentParameter(39, "Class", "fsz-30 round mdi mdi-chevron-double-left");
                                                __builder5.AddComponentParameter(40, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.PreviousDate))));
                                                __builder5.CloseComponent();
                                            }, $lVHXqe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                        }), $grDdpi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                        __builder4.AddMarkupContent(41, "\r\n                ");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 42);
                                        __builder4.AddComponentParameter(43, "Fill", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                                        __builder4.CloseComponent();
                                        __builder4.AddMarkupContent(44, "\r\n                ");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 45);
                                        __builder4.AddAttribute$3(46, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                        {
                                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                            {
                                                __builder5.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 47);
                                                __builder5.AddComponentParameter(48, "Outline", "true");
                                                __builder5.AddComponentParameter(49, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                                __builder5.AddComponentParameter(50, "Class", "fsz-30 round mdi mdi-chevron-double-right");
                                                __builder5.AddComponentParameter(51, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NextDate))));
                                                __builder5.CloseComponent();
                                            }, $XnSpke ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                        }), $fBTRTk ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                        __builder4.CloseComponent();
                                    }, $regPsd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                }), $Klfqzk ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $VfWwjg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                        }), $eoJxId ??= {"r":6881395,"p":[{"n":"items","p":$.$$.SCG.IEnumerable$$($.$Filo.LCCCCS$1.CalendarHourly).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(52, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly))))().$ctor(this, ( (/*item*/ item) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if (item.Model.Session !== null)
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCP$3.Popup, 53);
                                    __builder3.AddComponentParameter(54, "VerticalPosition", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionY, 2/*PositionY.BottomToTop*/), $.$hDPm.LCFCCP$4.PositionY));
                                    __builder3.AddComponentParameter(55, "Class", "pos-rel");
                                    __builder3.AddComponentParameter(56, "pop-class", "z-2 bg-dark");
                                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder3, 57, "onclick", true);
                                    __builder3.AddAttribute$3(58, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*_*/ _0) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenElement(59, "div");
                                            __builder4.AddAttribute$5(60, "class", "flex");
                                            __builder4.OpenElement(61, "div");
                                            __builder4.OpenElement(62, "div");
                                            __builder4.AddAttribute$5(63, "class", "hx-1 wx-1 bg-primary round clip flex");
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 64);
                                            __builder4.AddComponentParameter(65, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, item.Model.Session.Account.Icon));
                                            __builder4.AddComponentParameter(66, "Class", "mawh-10 mawp-10 mg-a");
                                            __builder4.AddComponentParameter(67, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/user.png", true, false, false)));
                                            __builder4.CloseComponent();
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(68, "\r\n                            ");
                                            __builder4.OpenElement(69, "div");
                                            __builder4.AddAttribute$5(70, "class", "stack");
                                            __builder4.AddAttribute$5(71, "style", "margin-left:-5px");
                                            __builder4.OpenElement(72, "button");
                                            __builder4.AddAttribute$5(73, "class", "lt text-left primary corner-right-2 pdy-1 pdx-5 nowrap mg-a");
                                            __builder4.AddAttribute$5(74, "title", item.Model.Session.Title);
                                            __builder4.AddContent$4(75, item.Model.Session.Title);
                                            __builder4.AddMarkupContent(76, "\r\n                                    ");
                                            __builder4.OpenElement(77, "small");
                                            __builder4.AddAttribute$5(78, "class", "text-muted d-block");
                                            __builder4.OpenElement(79, "i");
                                            __builder4.AddContent$4(80, item.Model.Session.Account.Title);
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                        }, $uKwSOk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                    }), $MmKljl ??= {"r":6881395,"p":[{"n":"_","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(81, "Pop", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCP$3.PopupContext))().$ctor(this, ( (/*_*/ _0) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                        {
                                            __builder4.OpenComponent$1($.$hDPm.LCFCCM$4.Menu, 82);
                                            __builder4.AddComponentParameter(83, "Selectable", "true");
                                            __builder4.AddComponentParameter(84, "Class", "text-left");
                                            __builder4.AddAttribute$3(85, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*__*/ __) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                                {
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 86);
                                                    __builder5.AddComponentParameter(87, "Class", "nowrap");
                                                    __builder5.AddAttribute$3(88, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(89, "<i class=\"mdi mdi-content-save\"></i>");
                                                        }, $QIKrDa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                                    }), $sDFzQg ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                                    __builder5.AddAttribute$3(90, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(91, "\r\n                                    Save the date\r\n                                ");
                                                        }, $APfvLj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                                    }), $eEcrZj ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                    __builder5.AddMarkupContent(92, "\r\n                            ");
                                                    __builder5.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 93);
                                                    __builder5.AddComponentParameter(94, "Class", "nowrap");
                                                    __builder5.AddAttribute$3(95, "IconLeft", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(96, "<i class=\"mdi mdi-car-child-seat\"></i>");
                                                        }, $eVUhnf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                                    }), $SXoyOf ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                                    __builder5.AddAttribute$3(97, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*___*/ ___) =>
                                                    {
                                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                        {
                                                            __builder6.AddMarkupContent(98, "\r\n                                    Book a seat\r\n                                ");
                                                        }, $jxOCif ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                                    }), $dwnFzb ??= {"r":6881395,"p":[{"n":"___","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                                    __builder5.CloseComponent();
                                                }, $BhwhTi ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                            }), $ywcHkl ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                                            __builder4.CloseComponent();
                                        }, $vqkgRj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                                    }), $IQBFxa ??= {"r":6881395,"p":[{"n":"_","p":39540394}],"n":"","d":1035537,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                            }, $TKXRhc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                        }), $qhlwAg ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly)).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $dlTXdk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1035537,"h":0,"f":17825794});
                }), $eRARKc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Filo.LCCCCS$1.CalendarHourly, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$Filo.LCCCCS$1.CalendarHourly)).$h}],"n":"","d":1035537,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885937425)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590970129)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590970129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590970129)
            
            //--TRIMMABLE-BOUNDARY-START(8590970129)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590970129)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180904721)
                this.Date = null;
                //--TRIMMABLE-BOUNDARY-END(17180904721)
                
            }
            static $h = 1035537;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130577681),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950708497,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1035537,
      "h": 60130577681,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130577681),
//--TRIMMABLE-BOUNDARY-START(17180904721),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770839313,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015479569,
        "f": 83886081
      },
      "n": "Date",
      "d": 1035537,
      "h": 17180904721,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180904721),
//--TRIMMABLE-BOUNDARY-START(47245675793),
    {
      "p": $.$typeArray($.$Filo.LCCCCS$1.CalendarHourly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360773905,
        "f": 50331650
      },
      "n": "hours",
      "d": 1035537,
      "h": 47245675793,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245675793)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310446865),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1035537,
      "h": 77310446865,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310446865),
//--TRIMMABLE-BOUNDARY-START(55835610385),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1035537,
      "h": 55835610385,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835610385),
//--TRIMMABLE-BOUNDARY-START(64425544977),
    {
      "r": 65537,
      "n": "PreviousDate",
      "d": 1035537,
      "h": 64425544977,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425544977),
//--TRIMMABLE-BOUNDARY-START(51540643089),
    {
      "r": 65537,
      "n": "NextDate",
      "d": 1035537,
      "h": 51540643089,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540643089),
//--TRIMMABLE-BOUNDARY-START(12885937425),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1035537,
      "h": 12885937425,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885937425)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590970129),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1035537,
      "h": 8590970129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590970129)
  ],
  "h": 1035537
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendarTimeline`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendarTimeline`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1035537)
        
        

        //--TRIMMABLE-BOUNDARY-START(970001)
        $asm.$cls(`$Filo.LCCCCS$1.CommunityCalendarPage`, ($self) => class CommunityCalendarPage extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(60130512145)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendarpage";
            }
            //--TRIMMABLE-BOUNDARY-END(60130512145)
            
            //--TRIMMABLE-BOUNDARY-START(55835544849)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835544849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(55835544849)
            
            //--TRIMMABLE-BOUNDARY-START(64425479441)
            /*CommunityCalendarService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(64425479441)
            
            //--TRIMMABLE-BOUNDARY-START(85900315921)
            /*IEnumerable<AccountBaseModel> */ get Speakers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245610257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel>?*/ let __ca1__;
                return ((__ca1__ = this.Parameter.Sessions) !== null ? ($.$sl.SL.Enumerable.Select$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$LCOv.LCFCPM$1.AccountBaseModel, __ca1__, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$LCOv.LCFCPM$1.AccountBaseModel))().$ctor(this,  (/**/ e) =>
                {
                    return e.Account;
                }, $XQzTHf ??= {"r":6220212,"p":[{"n":"e","p":2106739}],"n":"","d":970001,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPM$1.AccountBaseModel)) : $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPM$1.AccountBaseModel));
            }
            //--TRIMMABLE-BOUNDARY-END(85900315921)
            
            //--TRIMMABLE-BOUNDARY-START(17180839185)
            /*CommunityAccountAvatarList?*/ attendance = null;
            //--TRIMMABLE-BOUNDARY-END(17180839185)
            
            //--TRIMMABLE-BOUNDARY-START(81605348625)
            /*RemoteDataList<CommunityCalendarEventSpeakerModel>?*/ speakers = null;
            //--TRIMMABLE-BOUNDARY-END(81605348625)
            
            //--TRIMMABLE-BOUNDARY-START(51540577553)
            /*string */ GetSubTitle(/*CommunityCalendarEventSessionPostModel*/ session)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540577553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let endTime = session.StartDate.ToDateTime$1(new $.$$.S.TimeOnly()).AddMinutes(session.Duration);
                return `${$.$strNN(session.StartDate.ToString$3("t"))} - ${$.$strNN(endTime.ToString$3("t"))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(51540577553)
            
            //--TRIMMABLE-BOUNDARY-START(12885871889)
            /*ValueTask *//*async*/  Attend(/*DataId*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885871889);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Service.CommunityService.AuthenticateAsync(null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.Service.CommunityService.ToggleFollow$1($.$clone(id)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.attendance.DataList.Append$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountModel), [ this.Service.CommunityService.MainAccount ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885871889)
            
            //--TRIMMABLE-BOUNDARY-START(77310381329)
            /*IEnumerable<IDataListItemContext<CommunityCalendarEventSessionPostModel>> */ Sort(/*IEnumerable<IDataListItemContext<CommunityCalendarEventSessionPostModel>>*/ models, /*Sorting*/ sorting)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310381329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.OrderBy$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$$.S.DateOnly, models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$$.S.DateOnly))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.LCFCCD$1$IDataListItemContext$$$Data.StartDate;
                }, $NoiLEd ??= {"r":65929217,"p":[{"n":"o","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel).$h}],"n":"","d":970001,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(77310381329)
            
            //--TRIMMABLE-BOUNDARY-START(21475806481)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475806481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$hDPm.LCFCI.IDataFilterContext$$($.$Iaui.LCFCM.ResourceModel)), 0);
                __builder.AddComponentParameter(1, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IDataFilterContext$$($.$Iaui.LCFCM.ResourceModel), (() =>
                {
                    //new $.$hDPm.LCFCI.DataFilterContext$$($.$Iaui.LCFCM.ResourceModel)()
                    const $t4 = $.$hDPm.LCFCI.DataFilterContext$$($.$Iaui.LCFCM.ResourceModel);
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.CreateFilter = new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Parameter.Identifier);
                    return $i4;
                })()));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let ownsCalendar = this.Service.CommunityService.IsOwnedByCurrentUser(this.Parameter);
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.MediaGroup, 3);
                    __builder2.AddComponentParameter(4, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this.Parameter.Icons));
                    __builder2.AddComponentParameter(5, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Parameter.Identifier)));
                    __builder2.AddComponentParameter(6, "Class", "hx-35");
                    __builder2.AddComponentParameter(7, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 350), $.$$.S.Int32));
                    __builder2.AddComponentParameter(8, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 67108864n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(9, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, 96/*SliderFeatures.Default*/ | 4/*SliderFeatures.NavigatorBottom*/ | 1/*SliderFeatures.NavigatorOverlay*/), $.$hDPm.LCFCCS$9.SliderFeatures));
                    __builder2.AddAttribute$3(10, "SliderThumbNail", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$Iaui.LCFCM.ResourceModel)))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(11, "div");
                            __builder3.AddAttribute$5(12, "class", "hx-05 wx-05 round clip flex");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 13);
                            __builder3.AddComponentParameter(14, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder3.AddComponentParameter(15, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 50), $.$$.S.Int32));
                            __builder3.AddComponentParameter(16, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, context.Model));
                            __builder3.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                        }, $YfuxHi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $IRxWSf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$Iaui.LCFCM.ResourceModel).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(18, "FullScreenView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$3.MediaContext))().$ctor(this, ( (/*media*/ media) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityMedia, 19);
                            __builder3.AddComponentParameter(20, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, media.Resource));
                            __builder3.CloseComponent();
                        }, $xGTVDe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $VNmuXj ??= {"r":6881395,"p":[{"n":"media","p":35083946}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(21, "\r\n    ");
                    __builder2.OpenElement(22, "div");
                    __builder2.OpenElement(23, "div");
                    __builder2.AddAttribute$5(24, "class", "bg-tb-dark-card pdx pdt pdb-2 row");
                    __builder2.OpenElement(25, "div");
                    __builder2.AddAttribute$5(26, "class", "col-a flex");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 27);
                    __builder2.AddComponentParameter(28, "href", this.Parameter.Account.Link);
                    __builder2.AddComponentParameter(29, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Parameter.Account));
                    __builder2.AddAttribute$3(30, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 31);
                        __builder3.AddComponentParameter(32, "Class", "hx-07 wx-07 mg-a");
                        __builder3.AddComponentParameter(33, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 70), $.$$.S.Int32));
                        __builder3.AddComponentParameter(34, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.Parameter.Account));
                        __builder3.CloseComponent();
                    }), $eHEzZd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(35, "\r\n            ");
                    __builder2.OpenElement(36, "div");
                    __builder2.AddAttribute$5(37, "class", "col-10 pdl");
                    __builder2.OpenElement(38, "p");
                    __builder2.AddAttribute$5(39, "class", "mg-0");
                    __builder2.AddContent$4(40, this.Parameter.Account.Title);
                    __builder2.AddContent$4(41, " posted a ");
                    __builder2.AddContent$4(42, $.$$.S.String.ToUpper.call($.$$.S.Enum.ToStringT($.$OnVo.LCCCCM.CommunityCalendarEventType, $.$$.S.UInt32, this.Parameter.EventType)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(43, "\r\n                ");
                    __builder2.OpenElement(44, "div");
                    __builder2.AddAttribute$5(45, "class", "flex");
                    /*var*/ let icon = $.$fPer.LCFCT.EnumExtensions.GetDisplayable($.$box(this.Parameter.EventType, $.$OnVo.LCCCCM.CommunityCalendarEventType));
                    __builder2.OpenComponent$1($.$hDPm.LCFCCI.Icon, 46);
                    __builder2.AddComponentParameter(47, "Class", "mgy-a fsz-35");
                    __builder2.AddComponentParameter(48, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, icon.LCFC$IDisplayable$Icon));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(49, "\r\n                    ");
                    __builder2.OpenElement(50, "h2");
                    __builder2.AddAttribute$5(51, "class", "mgy-a mgl nowrap-2");
                    __builder2.AddContent$4(52, this.Parameter.Title);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.Parameter.Capacity > 0)
                    {
                        __builder2.OpenElement(53, "small");
                        __builder2.AddAttribute$5(54, "class", "mg-0 op-8 cl-text");
                        __builder2.AddContent$4(55, "Booked ");
                        __builder2.AddContent$3(56, $.$box(this.Parameter.SubscribersCount, $.$$.S.Int32));
                        __builder2.AddContent$4(57, " of ");
                        __builder2.AddContent$3(58, $.$box(this.Parameter.Capacity, $.$$.S.Int32));
                        __builder2.AddContent$4(59, " seats");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    if ($.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Parameter.Amount))
                    {
                        __builder2.OpenElement(60, "div");
                        __builder2.AddAttribute$5(61, "class", "pdl col-a flex");
                        __builder2.OpenElement(62, "h3");
                        __builder2.AddAttribute$5(63, "class", "mgy-a cl-primary font-cursive");
                        __builder2.AddContent$3(64, this.Parameter.Amount);
                        __builder2.AddContent$4(65, "/st");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(66, "\r\n        ");
                    __builder2.AddMarkupContent(67, "<div class=\"hx-005 bg-gray\"><div class=\"wp-50 hf bg-primary\"></div></div>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(68, "\r\n    ");
                    __builder2.OpenElement(69, "div");
                    __builder2.AddAttribute$5(70, "class", "row bg-card corner-b pd");
                    __builder2.OpenElement(71, "div");
                    __builder2.AddAttribute$5(72, "class", "col-5");
                    __builder2.OpenElement(73, "p");
                    __builder2.AddAttribute$5(74, "class", "mg-0");
                    if ($.$$.S.DateOnly.op_LessThan(this.Parameter.StartDate, $.$$.S.DateOnly.FromDateTime($.$$.S.DateTime.UtcNow)))
                    {
                        __builder2.AddContent$4(75, "Started");
                    }
                    else 
                    {
                        __builder2.AddContent$4(76, "Starting");
                    }
                    __builder2.AddContent$4(77, this.Parameter.StartDate.ToString$3("D"));
                    __builder2.CloseElement();
                    if (this.Parameter.Type === 5634/*PostTypes.CalendarEventRecurring*/)
                    {
                        __builder2.OpenElement(78, "small");
                        __builder2.AddAttribute$5(79, "class", "op-8");
                        __builder2.AddContent$4(80, $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$OnVo.LCCCCM.CommunityCalendarEventRecurrenceType, $.$$.S.UInt32, this.Parameter.Recurrence.Recurrence)));
                        __builder2.AddContent$4(81, " Event");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(82, "\r\n                ");
                        __builder2.AddMarkupContent(83, "<p>25 editions</p>");
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(84, "\r\n        ");
                    __builder2.OpenElement(85, "div");
                    __builder2.AddAttribute$5(86, "class", "col-a flex");
                    __builder2.OpenElement(87, "div");
                    __builder2.AddAttribute$5(88, "class", "stack");
                    __builder2.OpenElement(89, "p");
                    __builder2.AddAttribute$5(90, "class", "mgy-a nowrap");
                    if ($.$$.S.DateOnly.op_LessThan(this.Parameter.StartDate, $.$$.S.DateOnly.FromDateTime($.$$.S.DateTime.UtcNow)))
                    {
                        __builder2.AddContent$4(91, "Came up");
                    }
                    else 
                    {
                        __builder2.AddContent$4(92, "Coming up");
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(93, "\r\n                ");
                    __builder2.OpenElement(94, "div");
                    __builder2.AddAttribute$5(95, "class", "mgt-a bg-text cl-tertiary pd corner text-center");
                    __builder2.OpenElement(96, "b");
                    __builder2.AddAttribute$5(97, "class", "mg-0 nowrap");
                    __builder2.AddContent$4(98, $.$$.S.String.ToUpper.call(this.Parameter.StartTime.ToString$3("HH:mm tt")));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(99, "\r\n            ");
                    __builder2.OpenElement(100, "div");
                    __builder2.AddAttribute$5(101, "class", "stack bg-text cl-tertiary pd corner mgl text-center");
                    __builder2.OpenElement(102, "h2");
                    __builder2.AddAttribute$5(103, "class", "mgt-a mgb-0 nowrap");
                    __builder2.AddContent$4(104, $.$$.S.String.ToUpper.call(this.Parameter.StartDate.ToString$3("MMM d")));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(105, "\r\n                ");
                    __builder2.OpenElement(106, "h3");
                    __builder2.AddAttribute$5(107, "class", "mgt-0 mgb-a");
                    __builder2.AddContent$4(108, $.$$.S.String.ToUpper.call($.$$.S.String.ToUpper.call(this.Parameter.StartDate.ToString$3("ddd"))));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(109, "\r\n\r\n    ");
                    __builder2.OpenElement(110, "div");
                    __builder2.AddAttribute$5(111, "class", "mgx");
                    __builder2.AddMarkupContent(112, "<h3>About</h3>\r\n        ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 113);
                    __builder2.AddComponentParameter(114, "Class", "lh-15");
                    __builder2.AddComponentParameter(115, "EditableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCE.EditableFeatures, 54/*EditableFeatures.Default*/ | 1/*EditableFeatures.ServerUpdate*/), $.$hDPm.LCFCCE.EditableFeatures));
                    __builder2.AddComponentParameter(116, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Parameter.Post));
                    __builder2.AddComponentParameter(117, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.Parameter.Post = __value;
                    }, $kvUNhd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":970001,"h":0,"f":17825794}), this.Parameter.Post))));
                    __builder2.AddComponentParameter(118, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Parameter"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $FTNptb ??= {"r":38797349,"n":"","d":970001,"h":0,"f":17825794})).Invoke())));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(119, "\r\n\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), 120);
                    __builder2.AddComponentParameter(121, "Class", "mgt-10 corner bg-card pd");
                    __builder2.AddComponentParameter(122, "ItemName", "Speaker");
                    __builder2.AddComponentParameter(123, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder2.AddComponentParameter(124, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 34359738368n | 2097152n | 65536n | 70368744177664n | (ownsCalendar ? 64n | 2199023255552n | 256n | 8796093022208n | 128n | 4398046511104n : 0n)), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(125, "li-class", "pdy-2");
                    __builder2.AddAttribute$3(126, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))().$ctor(this, ( (/*tool*/ tool) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (tool.Features === 34359738368n)
                            {
                                __builder3.AddMarkupContent(127, "<h3 class=\"mg-0\">Featuring</h3>");
                            }
                        }, $WXztnh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $bvSghl ??= {"r":6881395,"p":[{"n":"tool","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(128, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))().$ctor(this, ( (/*speaker*/ speaker) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(129, "div");
                            __builder3.AddAttribute$5(130, "class", "row");
                            __builder3.OpenElement(131, "div");
                            __builder3.AddAttribute$5(132, "class", "col-a");
                            __builder3.OpenElement(133, "div");
                            __builder3.AddAttribute$5(134, "class", "wx-03 hx-03 round clip");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 135);
                            __builder3.AddComponentParameter(136, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, speaker.Data.Icon));
                            __builder3.AddComponentParameter(137, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(138, "\r\n                ");
                            __builder3.OpenElement(139, "div");
                            __builder3.AddAttribute$5(140, "class", "col-10 pdl");
                            __builder3.OpenElement(141, "h4");
                            __builder3.AddAttribute$5(142, "class", "mgt-a mgb-0");
                            __builder3.AddContent$4(143, speaker.Data.Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(144, "\r\n                    ");
                            __builder3.OpenElement(145, "small");
                            __builder3.AddAttribute$5(146, "class", "mgt-0 mgb-a op-8");
                            __builder3.AddContent$4(147, speaker.Data.Summary);
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $OicFXf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $VZpSlj ??= {"r":6881395,"p":[{"n":"speaker","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(148, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 149);
                        __builder3.AddComponentParameter(150, "Message", "No speaker has been added to this event yet");
                        __builder3.CloseComponent();
                    }), $LUFQlg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(151, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))().$ctor(this, ( (/*speaker*/ speaker) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(152, "div");
                            __builder3.AddAttribute$5(153, "class", "stack text-center pd");
                            __builder3.OpenElement(154, "div");
                            __builder3.AddAttribute$5(155, "class", "hx-1 wx-1 round bd mg-a clip");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 156);
                            __builder3.AddComponentParameter(157, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, speaker.Data.Icon));
                            __builder3.AddComponentParameter(158, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(159, "\r\n                ");
                            __builder3.OpenElement(160, "h2");
                            __builder3.AddContent$4(161, speaker.Data.Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(162, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 163);
                            __builder3.AddComponentParameter(164, "Class", "lh-15");
                            __builder3.AddComponentParameter(165, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                            __builder3.AddComponentParameter(166, "EditableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCE.EditableFeatures, 54/*EditableFeatures.Default*/ | 1/*EditableFeatures.ServerUpdate*/), $.$hDPm.LCFCCE.EditableFeatures));
                            __builder3.AddComponentParameter(167, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, speaker.Data.Post));
                            __builder3.AddComponentParameter(168, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return speaker.Data.Post = __value;
                            }, $chAWBb ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":970001,"h":0,"f":17825794}), speaker.Data.Post))));
                            __builder3.AddComponentParameter(169, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(speaker), "Data"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $DDBwid ??= {"r":38797349,"n":"","d":970001,"h":0,"f":17825794})).Invoke())));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                        }, $CipHXj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $JWTLLk ??= {"r":6881395,"p":[{"n":"speaker","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(170, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.speakers = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                    }, $TxTPGe ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(171, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), 172);
                    __builder2.AddComponentParameter(173, "ItemName", "Session");
                    __builder2.AddComponentParameter(174, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder2.AddComponentParameter(175, "Class", "mgt-10 pd corner bg-card");
                    __builder2.AddComponentParameter(176, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, $.$with(new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), ($clone) =>
                    {
                        $clone.Sorting = $.$fPer.LCFCD.Sorting.Ascending;
                    })));
                    __builder2.AddComponentParameter(177, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 34359738368n | 65536n | 2097152n | 70368744177664n | (ownsCalendar ? 64n | 2199023255552n | 256n | 8796093022208n | 128n | 4398046511104n : 0n)), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(178, "li-class", "pdy-2");
                    __builder2.AddAttribute$3(179, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel))))().$ctor(this, ( (/*tool*/ tool) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (tool.Features === 34359738368n)
                            {
                                __builder3.AddMarkupContent(180, "<h3 class=\"mg-0\">Sessions</h3>");
                            }
                        }, $SbUfib ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $PKQKBk ??= {"r":6881395,"p":[{"n":"tool","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(181, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel))))().$ctor(this, ( (/*session*/ session) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(182, "div");
                            __builder3.AddAttribute$5(183, "class", "row");
                            if (session.Data.Icon !== null)
                            {
                                __builder3.OpenElement(184, "div");
                                __builder3.AddAttribute$5(185, "class", "col-a mgr");
                                __builder3.OpenElement(186, "div");
                                __builder3.AddAttribute$5(187, "class", "wx-03 hx-03 round clip");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 188);
                                __builder3.AddComponentParameter(189, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, session.Data.Icon));
                                __builder3.AddComponentParameter(190, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }
                            __builder3.OpenElement(191, "div");
                            __builder3.AddAttribute$5(192, "class", "col-10");
                            __builder3.OpenElement(193, "h4");
                            __builder3.AddAttribute$5(194, "class", "mgt-a mgb-0");
                            __builder3.AddContent$4(195, session.Data.Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(196, "\r\n                    ");
                            __builder3.OpenElement(197, "small");
                            __builder3.AddAttribute$5(198, "class", "mgt-0 mgb-a op-8");
                            __builder3.AddContent$4(199, session.Data.Summary);
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(200, "\r\n                ");
                            __builder3.OpenElement(201, "div");
                            __builder3.AddAttribute$5(202, "class", "col-a stack");
                            __builder3.OpenElement(203, "small");
                            __builder3.AddAttribute$5(204, "class", "mgy-a nowrap");
                            __builder3.AddContent$4(205, session.Data.StartDate.ToDateTime$1(session.Data.StartTime).ToString());
                            if (session.Data.Duration > 0)
                            {
                                __builder3.AddContent$4(206, "- ");
                                __builder3.AddContent$4(207, session.Data.StartDate.ToDateTime$1(session.Data.StartTime).AddMinutes(session.Data.Duration).ToString$3("HH:mm tt"));
                                __builder3.AddContent$4(208, " (");
                                __builder3.AddContent$3(209, $.$box(session.Data.Duration, $.$$.S.Int32));
                                __builder3.AddContent$4(210, " min)");
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $COpfdd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $ZCaVSc ??= {"r":6881395,"p":[{"n":"session","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(211, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel))))().$ctor(this, ( (/*session*/ session) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(212, "div");
                            __builder3.AddAttribute$5(213, "class", "stack text-center pd");
                            if (session.Data.Icon !== null)
                            {
                                __builder3.OpenElement(214, "div");
                                __builder3.AddAttribute$5(215, "class", "hx-1 wx-1 round bd mg-a clip");
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 216);
                                __builder3.AddComponentParameter(217, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, session.Data.Icon));
                                __builder3.AddComponentParameter(218, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                __builder3.CloseComponent();
                                __builder3.CloseElement();
                            }
                            __builder3.OpenElement(219, "h2");
                            __builder3.AddContent$4(220, session.Data.Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(221, "\r\n                ");
                            __builder3.OpenElement(222, "h4");
                            __builder3.AddAttribute$5(223, "class", "mgy-a nowrap");
                            __builder3.AddContent$4(224, session.Data.StartDate.ToDateTime$1(session.Data.StartTime).ToString());
                            if (session.Data.Duration > 0)
                            {
                                __builder3.AddContent$4(225, "- ");
                                __builder3.AddContent$4(226, session.Data.StartDate.ToDateTime$1(session.Data.StartTime).AddMinutes(session.Data.Duration).ToString$3("HH:mm tt"));
                                __builder3.AddContent$4(227, " (");
                                __builder3.AddContent$3(228, $.$box(session.Data.Duration, $.$$.S.Int32));
                                __builder3.AddContent$4(229, " min)");
                            }
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(230, "\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 231);
                            __builder3.AddComponentParameter(232, "Class", "lh-15");
                            __builder3.AddComponentParameter(233, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), true), $.$$.S.Boolean));
                            __builder3.AddComponentParameter(234, "EditableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCE.EditableFeatures, 54/*EditableFeatures.Default*/ | 1/*EditableFeatures.ServerUpdate*/), $.$hDPm.LCFCCE.EditableFeatures));
                            __builder3.AddComponentParameter(235, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, session.Data.Post));
                            __builder3.AddComponentParameter(236, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                return session.Data.Post = __value;
                            }, $JADZWd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":970001,"h":0,"f":17825794}), session.Data.Post))));
                            __builder3.AddComponentParameter(237, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(session), "Data"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $UeNmec ??= {"r":38797349,"n":"","d":970001,"h":0,"f":17825794})).Invoke())));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(238, "\r\n                ");
                            __builder3.AddMarkupContent(239, "<h4>Speakers</h4>\r\n                ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), 240);
                            __builder3.AddComponentParameter(241, "Class", "mgt-10 bdb pdb");
                            __builder3.AddComponentParameter(242, "ItemName", "Speaker");
                            __builder3.AddComponentParameter(243, "_DataFilter", new $.$fPer.LCFCD.DataFilter().$ctor$6(session.Data.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)));
                            __builder3.AddComponentParameter(244, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 34359738368n | 2097152n | 65536n | 70368744177664n | (ownsCalendar ? 64n | 2199023255552n | 256n | 8796093022208n | 128n | 4398046511104n : 0n)), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(245, "li-class", "pdy-2");
                            __builder3.AddAttribute$3(246, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))().$ctor(this, ( (/*speaker*/ speaker) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                }, $CkpaOj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                            }), $SNVZea ??= {"r":6881395,"p":[{"n":"speaker","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(247, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 248);
                                __builder4.AddComponentParameter(249, "Message", "No speaker has been added to this event yet");
                                __builder4.CloseComponent();
                            }), $uMpIHi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(250, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.speakers = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                            }, $oiztqd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":970001,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                        }, $vaJoxf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $iisvwj ??= {"r":6881395,"p":[{"n":"session","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(251, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 252);
                        __builder3.AddComponentParameter(253, "Message", "No session has been added to this event yet");
                        __builder3.CloseComponent();
                    }), $xVrUll ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(254, "\r\n\r\n\r\n    ");
                    __builder2.OpenElement(255, "div");
                    __builder2.AddAttribute$5(256, "class", "mgt-10 pd bg-card corner");
                    __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountAvatarList, 257);
                    __builder2.AddComponentParameter(258, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.Parameter.Capacity > 0 ? new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741861/*PostFilterTypes.HasInteraction*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box($.$cast(4294967296n, $.$LCOv.LCFCPM$1.PostInteractionType), $.$LCOv.LCFCPM$1.PostInteractionType) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741828/*PostFilterTypes.Subscribers*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder2.AddAttribute$3(259, "TitleView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*list*/ list) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(260, "div");
                            __builder3.AddAttribute$5(261, "class", "row");
                            __builder3.OpenElement(262, "div");
                            __builder3.AddAttribute$5(263, "class", "col-a");
                            __builder3.OpenElement(264, "h3");
                            __builder3.AddAttribute$5(265, "class", "mg-0 nowrap");
                            __builder3.AddMarkupContent(266, "\r\n                            Seat Booking (");
                            __builder3.AddContent$4(267, $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Parameter.Amount) ? this.Parameter.Amount.ToString$1(0) : "Free");
                            __builder3.AddMarkupContent(268, ")\r\n                        ");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(269, "\r\n                    ");
                            __builder3.OpenElement(270, "div");
                            __builder3.AddAttribute$5(271, "class", "col-10 stack pdl");
                            __builder3.OpenElement(272, "small");
                            __builder3.AddAttribute$5(273, "class", "mgy-a nowrap text-center op-8");
                            if (list.DataList.TotalItems >= 0)
                            {
                                __builder3.AddContent$3(274, $.$box(list.DataList.TotalItems, $.$$.S.Int32));
                            }
                            if (this.Parameter.Capacity > 0)
                            {
                                __builder3.AddContent$4(275, "of ");
                                __builder3.AddContent$3(276, $.$box(this.Parameter.Capacity, $.$$.S.Int32));
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(277, "\r\n                    ");
                            __builder3.OpenElement(278, "div");
                            __builder3.AddAttribute$5(279, "class", "col-a stack pdl");
                            if (this.Parameter.Capacity > 0)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$fPer.LCFCD.DataId), 280);
                                __builder3.AddComponentParameter(281, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, this.Parameter.Identifier));
                                __builder3.AddComponentParameter(282, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCD.DataId), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$fPer.LCFCD.DataId, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataId, $.$$.STT.ValueTask))().$ctor(this, this.Attend))));
                                __builder3.AddComponentParameter(283, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(284, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 4096/*ButtonFeatures.SwallowClickException*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(285, "Class", "nowrap mgt-a fsz-small mdi mdi-plus");
                                __builder3.AddAttribute$3(286, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(287, "\r\n                                Book a Seat\r\n                            ");
                                }), $BIyOue ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            else 
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$fPer.LCFCD.DataId), 288);
                                __builder3.AddComponentParameter(289, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, this.Parameter.Identifier));
                                __builder3.AddComponentParameter(290, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$fPer.LCFCD.DataId), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$fPer.LCFCD.DataId, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataId, $.$$.STT.ValueTask))().$ctor(this, this.Attend))));
                                __builder3.AddComponentParameter(291, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(292, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 4096/*ButtonFeatures.SwallowClickException*/ | 128/*ButtonFeatures.XSmall*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(293, "Class", "nowrap mgt-a fsz-small mdi mdi-plus");
                                __builder3.AddAttribute$3(294, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(295, "\r\n                                Book a Seat\r\n                            ");
                                }), $GjAdDe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            if (this.Parameter.Capacity > 0)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCP$5.ProgressBar, 296);
                                __builder3.AddComponentParameter(297, "Class", "mgt");
                                __builder3.AddComponentParameter(298, "Progress", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, $.trunc(((list.DataList.TotalItems * 100) | 0) / this.Parameter.Capacity)), $.$$.S.Int32));
                                __builder3.AddComponentParameter(299, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(300, "BackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Gray));
                                __builder3.CloseComponent();
                            }
                        }, $lNaKBg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $pdLloi ??= {"r":6881395,"p":[{"n":"list","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddComponentReferenceCapture(301, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.attendance = $.$cast(__value, $.$ahDc.LCCCSA$1.CommunityAccountAvatarList);
                    }, $MSSnTd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(302, "\r\n\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel), 303);
                    __builder2.AddComponentParameter(304, "ItemName", "Material");
                    __builder2.AddComponentParameter(305, "Class", "mgt-10 pd bg-card corner");
                    __builder2.AddComponentParameter(306, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 150), $.$$.S.Int32));
                    __builder2.AddComponentParameter(307, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                    __builder2.AddComponentParameter(308, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Parameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                    __builder2.AddComponentParameter(309, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 34359738368n | 65536n | (ownsCalendar ? 64n | 2199023255552n | 256n | 8796093022208n | 128n | 4398046511104n : 0n)), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(310, "li-class", "pdy-2");
                    __builder2.AddAttribute$3(311, "CustomToolBar", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel))))().$ctor(this, ( (/*tool*/ tool) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (tool.Features === 34359738368n)
                            {
                                __builder3.AddMarkupContent(312, "<h3 class=\"mg-0\">Materials</h3>");
                            }
                        }, $EDEUqg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $TQZuYe ??= {"r":6881395,"p":[{"n":"tool","p":$.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(313, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel))))().$ctor(this, ( (/*material*/ material) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(314, "div");
                            __builder3.AddAttribute$5(315, "class", "bg-card hx-2 clip stack");
                            __builder3.AddAttribute$5(316, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN(((material.Data.Icon?.FullPath ?? null)))) + ");");
                            __builder3.AddMarkupContent(317, "<div class=\"fill\"></div>\r\n                ");
                            __builder3.OpenElement(318, "div");
                            __builder3.AddAttribute$5(319, "class", "bg-tertiary-06 pd");
                            __builder3.OpenElement(320, "h3");
                            __builder3.AddAttribute$5(321, "class", "mg-0 nowrap");
                            __builder3.AddContent$4(322, material.Data.Title);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(323, "\r\n                    ");
                            __builder3.OpenElement(324, "small");
                            __builder3.AddAttribute$5(325, "class", "nowrap");
                            __builder3.AddContent$4(326, material.Data.Summary);
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $rvhHBh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794});
                    }), $QtDPxi ??= {"r":6881395,"p":[{"n":"material","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel)).$h}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(327, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 328);
                        __builder3.AddComponentParameter(329, "Message", "No material has been added to this event yet");
                        __builder3.CloseComponent();
                    }), $dfyFTf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(330, "\r\n\r\n    ");
                    __builder2.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostToolBar, 331);
                    __builder2.AddComponentParameter(332, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IPost, this.Parameter));
                    __builder2.CloseComponent();
                }), $gzIDxj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":970001,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475806481)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313274026)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSortableController<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel>.Sort(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.IDataListItemContext<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel>>, LivingThing.Core.Frameworks.Common.Data.Sorting)
            LCFCCD$1$IDataListSortableController$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventSessionPostModel$Sort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313274026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sort(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313274026)
            
            //--TRIMMABLE-BOUNDARY-START(8590904593)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590904593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590904593)
            
            //--TRIMMABLE-BOUNDARY-START(8590904593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590904593)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425479441)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(64425479441)
                
            }
            static $h = 970001;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130512145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065741073,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 970001,
      "h": 60130512145,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130512145),
//--TRIMMABLE-BOUNDARY-START(64425479441),
    {
      "p": 707857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655675665,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015414033,
        "f": 83886081
      },
      "n": "Service",
      "d": 970001,
      "h": 64425479441,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425479441),
//--TRIMMABLE-BOUNDARY-START(85900315921),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245610257,
        "f": 50331650
      },
      "n": "Speakers",
      "d": 970001,
      "h": 85900315921,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85900315921)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835544849),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 970001,
      "h": 55835544849,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835544849),
//--TRIMMABLE-BOUNDARY-START(51540577553),
    {
      "r": 1310721,
      "p": [
        {
          "n": "session",
          "p": 2106739
        }
      ],
      "n": "GetSubTitle",
      "d": 970001,
      "h": 51540577553,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540577553),
//--TRIMMABLE-BOUNDARY-START(12885871889),
    {
      "r": 181338113,
      "p": [
        {
          "n": "id",
          "p": 10455382
        }
      ],
      "n": "Attend",
      "d": 970001,
      "h": 12885871889,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(12885871889),
//--TRIMMABLE-BOUNDARY-START(77310381329),
    {
      "r": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).$h
        },
        {
          "n": "sorting",
          "p": 36997462
        }
      ],
      "n": "Sort",
      "d": 970001,
      "h": 77310381329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310381329),
//--TRIMMABLE-BOUNDARY-START(21475806481),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 970001,
      "h": 21475806481,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475806481)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180839185),
    {
      "t": 20420032,
      "n": "attendance",
      "d": 970001,
      "h": 17180839185,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180839185),
//--TRIMMABLE-BOUNDARY-START(81605348625),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel).$h,
      "n": "speakers",
      "d": 970001,
      "h": 81605348625,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81605348625)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590904593),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 970001,
      "h": 8590904593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590904593)
  ],
  "h": 970001
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSortableController$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Shared.CommunityCalendarPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Shared${separator}CommunityCalendarPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(970001)
        
        

        //--TRIMMABLE-BOUNDARY-START(511249)
        $asm.$cls(`$Filo.LCCCCS.CommunityCalendarApplication`, ($self) => class CommunityCalendarApplication extends $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(12885413137)
            $ctor$3(/*CommunityCalendarService*/ service)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885413137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885413137)
            
            //--TRIMMABLE-BOUNDARY-START(137439464721)
            /*string */ get Name()
            {
                return "Calendar";
            }
            //--TRIMMABLE-BOUNDARY-END(137439464721)
            
            //--TRIMMABLE-BOUNDARY-START(158914301201)
            /*string */ get Title()
            {
                return "Calendar";
            }
            //--TRIMMABLE-BOUNDARY-END(158914301201)
            
            //--TRIMMABLE-BOUNDARY-START(21475347729)
            /*string */ get Description()
            {
                return "Plan events and organize your tasks";
            }
            //--TRIMMABLE-BOUNDARY-END(21475347729)
            
            //--TRIMMABLE-BOUNDARY-START(133144497425)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-calendar"/*MaterialDesignIconNames.Calendar*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144497425)
            
            //--TRIMMABLE-BOUNDARY-START(154619333905)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#5E269B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619333905)
            
            //--TRIMMABLE-BOUNDARY-START(30065282321)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065282321)
            
            //--TRIMMABLE-BOUNDARY-START(17180380433)
            /*Type? */ get ApplicationViewType()
            {
                return $.$Filo.LCCCCP.CommunityCalendarApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180380433)
            
            //--TRIMMABLE-BOUNDARY-START(128849530129)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849530129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Filo.LCCCCP.CommunityCalendarApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849530129)
            
            //--TRIMMABLE-BOUNDARY-START(25770315025)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770315025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770315025)
            
            //--TRIMMABLE-BOUNDARY-START(146029399313)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029399313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029399313)
            
            //--TRIMMABLE-BOUNDARY-START(141734432017)
            /*int */ get Order$1()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734432017)
            
            //--TRIMMABLE-BOUNDARY-START(4295478545)
            /*CommunityCalendarService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295478545)
            
            //--TRIMMABLE-BOUNDARY-START(150324366609)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324366609)
            
            //--TRIMMABLE-BOUNDARY-START(163209268497)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(5632/*PostTypes.Calendar*/, 5642/*PostTypes.CalendarEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209268497)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 511249;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication$$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439464721),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604889873,
        "f": 50364417
      },
      "n": "Name",
      "d": 511249,
      "h": 137439464721,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439464721),
//--TRIMMABLE-BOUNDARY-START(158914301201),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964628241,
        "f": 50364417
      },
      "n": "Title",
      "d": 511249,
      "h": 158914301201,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914301201),
//--TRIMMABLE-BOUNDARY-START(21475347729),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835086097,
        "f": 50364417
      },
      "n": "Description",
      "d": 511249,
      "h": 21475347729,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475347729),
//--TRIMMABLE-BOUNDARY-START(133144497425),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014955281,
        "f": 50364417
      },
      "n": "Icon",
      "d": 511249,
      "h": 133144497425,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144497425),
//--TRIMMABLE-BOUNDARY-START(154619333905),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374693649,
        "f": 50364417
      },
      "n": "Theme",
      "d": 511249,
      "h": 154619333905,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619333905),
//--TRIMMABLE-BOUNDARY-START(30065282321),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425020689,
        "f": 50364417
      },
      "n": "Features",
      "d": 511249,
      "h": 30065282321,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065282321),
//--TRIMMABLE-BOUNDARY-START(17180380433),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245151505,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 511249,
      "h": 17180380433,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180380433),
//--TRIMMABLE-BOUNDARY-START(141734432017),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194824465,
        "f": 50331649
      },
      "n": "Order",
      "o": "@$1",
      "d": 511249,
      "h": 141734432017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734432017),
//--TRIMMABLE-BOUNDARY-START(4295478545),
    {
      "p": 707857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655216913,
        "f": 50331650
      },
      "n": "_Service",
      "d": 511249,
      "h": 4295478545,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295478545),
//--TRIMMABLE-BOUNDARY-START(150324366609),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784759057,
        "f": 50364417
      },
      "n": "Service",
      "d": 511249,
      "h": 150324366609,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324366609),
//--TRIMMABLE-BOUNDARY-START(163209268497),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554562833,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 511249,
      "h": 163209268497,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209268497)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849530129),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 511249,
      "h": 128849530129,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849530129),
//--TRIMMABLE-BOUNDARY-START(25770315025),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 511249,
      "h": 25770315025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770315025),
//--TRIMMABLE-BOUNDARY-START(146029399313),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 511249,
      "h": 146029399313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029399313)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885413137),
    {
      "p": [
        {
          "n": "service",
          "p": 707857
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 511249,
      "h": 12885413137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885413137)
  ],
  "h": 511249
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Services.CommunityCalendarApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Services${separator}CommunityCalendarApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(511249)
        
        

        //--TRIMMABLE-BOUNDARY-START(380177)
        $asm.$cls(`$Filo.LCCCCP.CommunityCalendarApp`, ($self) => class CommunityCalendarApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(150324235537)
            /*string */ get OptimizedComponentName()
            {
                return "communitycalendarapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(150324235537)
            
            //--TRIMMABLE-BOUNDARY-START(141734300945)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734300945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.CalendarService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarService, serviceProvider);
                this.CalendarApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Filo.LCCCCS.CommunityCalendarApplication, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(141734300945)
            
            //--TRIMMABLE-BOUNDARY-START(34360118545)
            /*CommunityCalendarService*/ CalendarService = null;
            //--TRIMMABLE-BOUNDARY-END(34360118545)
            
            //--TRIMMABLE-BOUNDARY-START(30065151249)
            /*CommunityCalendarApplication*/ CalendarApplication = null;
            //--TRIMMABLE-BOUNDARY-END(30065151249)
            
            //--TRIMMABLE-BOUNDARY-START(21475216657)
            /*ICommunityClientApplication */ get Application()
            {
                return this.CalendarApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(21475216657)
            
            //--TRIMMABLE-BOUNDARY-START(42950053137)
            /*CommunityPostView */ get CardView()
            {
                return 4/*CommunityPostView.CardMediaFirst*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950053137)
            
            //--TRIMMABLE-BOUNDARY-START(47245020433)
            /*int? */ get CardWidthHint()
            {
                return 250;
            }
            //--TRIMMABLE-BOUNDARY-END(47245020433)
            
            //--TRIMMABLE-BOUNDARY-START(38655085841)
            /*int? */ get CardSpaceHint()
            {
                return 20;
            }
            //--TRIMMABLE-BOUNDARY-END(38655085841)
            
            //--TRIMMABLE-BOUNDARY-START(171799072017)
            /*UseDefaultPage */ get UsePage()
            {
                return 65535/*UseDefaultPage.Default*/ & ~2/*UseDefaultPage.PostView*/;
            }
            //--TRIMMABLE-BOUNDARY-END(171799072017)
            
            //--TRIMMABLE-BOUNDARY-START(137439333649)
            /*string? */ get HomePageTitle()
            {
                return "Upcoming Events";
            }
            //--TRIMMABLE-BOUNDARY-END(137439333649)
            
            //--TRIMMABLE-BOUNDARY-START(146029268241)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029268241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.CalendarService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146029268241)
            
            //--TRIMMABLE-BOUNDARY-START(25770183953)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770183953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddContent$1(0, this.GetApp());
            }
            //--TRIMMABLE-BOUNDARY-END(25770183953)
            
            //--TRIMMABLE-BOUNDARY-START(17180249361)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(1, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), 2);
                    __builder2.AddComponentParameter(3, "Name", "Calendar");
                    __builder2.AddComponentParameter(4, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Event/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(5, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 16/*ApplicationPageFeatures.TopToolBarOverlay*/ : 0/*ApplicationPageFeatures.None*/)), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(6, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? $.$fPer.LCFC.Theme.OfTertiary(0.5) : $.$fPer.LCFC.Theme.None));
                    __builder2.AddComponentParameter(7, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $ONGGoi ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$h}],"n":"","d":380177,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*c*/ c) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(9, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, c.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $xhCkcf ??= {"r":131073,"p":[{"n":"e","p":1320307}],"n":"","d":380177,"h":0,"f":17825794}), true));
                        }, $TeKWGk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":380177,"h":0,"f":17825794});
                    }), $LbrGyg ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":380177,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(10, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*cal*/ cal) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(11, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, cal.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                return this.EditPostButton($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, e);
                            }, $FVTysi ??= {"r":6881395,"p":[{"n":"e","p":1320307}],"n":"","d":380177,"h":0,"f":17825794}), null, true));
                        }, $vPdjTg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":380177,"h":0,"f":17825794});
                    }), $TAucpf ??= {"r":6881395,"p":[{"n":"cal","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":380177,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$Filo.LCCCCS$1.CommunityCalendarPage, 13);
                            __builder3.CloseComponent();
                        }, $JtyVlc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":380177,"h":0,"f":17825794});
                    }), $AAvQCf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).$h}],"n":"","d":380177,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(14, "\r\n    ");
                }, $jdEtyf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":380177,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17180249361)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885282065)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885282065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885282065)
            
            //--TRIMMABLE-BOUNDARY-START(12885282065)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12885282065)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360118545)
                this.CalendarService = null;
                //--TRIMMABLE-BOUNDARY-END(34360118545)
                
                //--TRIMMABLE-BOUNDARY-START(30065151249)
                this.CalendarApplication = null;
                //--TRIMMABLE-BOUNDARY-END(30065151249)
                
            }
            static $h = 380177;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324235537),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554431761,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 380177,
      "h": 150324235537,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324235537),
//--TRIMMABLE-BOUNDARY-START(34360118545),
    {
      "p": 707857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604758801,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504104721,
        "f": 83886081
      },
      "n": "CalendarService",
      "d": 380177,
      "h": 34360118545,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360118545),
//--TRIMMABLE-BOUNDARY-START(30065151249),
    {
      "p": 511249,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014824209,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914170129,
        "f": 83886081
      },
      "n": "CalendarApplication",
      "d": 380177,
      "h": 30065151249,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065151249),
//--TRIMMABLE-BOUNDARY-START(21475216657),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424889617,
        "f": 50364420
      },
      "n": "Application",
      "d": 380177,
      "h": 21475216657,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(21475216657),
//--TRIMMABLE-BOUNDARY-START(42950053137),
    {
      "p": 31299008,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784627985,
        "f": 50364420
      },
      "n": "CardView",
      "d": 380177,
      "h": 42950053137,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(42950053137),
//--TRIMMABLE-BOUNDARY-START(47245020433),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374562577,
        "f": 50364420
      },
      "n": "CardWidthHint",
      "d": 380177,
      "h": 47245020433,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(47245020433),
//--TRIMMABLE-BOUNDARY-START(38655085841),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194693393,
        "f": 50364420
      },
      "n": "CardSpaceHint",
      "d": 380177,
      "h": 38655085841,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38655085841),
//--TRIMMABLE-BOUNDARY-START(171799072017),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144366353,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 380177,
      "h": 171799072017,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(171799072017),
//--TRIMMABLE-BOUNDARY-START(137439333649),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964497169,
        "f": 50364420
      },
      "n": "HomePageTitle",
      "d": 380177,
      "h": 137439333649,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(137439333649),
//--TRIMMABLE-BOUNDARY-START(17180249361),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834955025,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 380177,
      "h": 17180249361,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(17180249361)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141734300945),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 380177,
      "h": 141734300945,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734300945),
//--TRIMMABLE-BOUNDARY-START(146029268241),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 380177,
      "h": 146029268241,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(146029268241),
//--TRIMMABLE-BOUNDARY-START(25770183953),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 380177,
      "h": 25770183953,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770183953)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885282065),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 380177,
      "h": 12885282065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885282065)
  ],
  "h": 380177
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Pages.CommunityCalendarApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Pages${separator}CommunityCalendarApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(380177)
        
        

        //--TRIMMABLE-BOUNDARY-START(707857)
        $asm.$cls(`$Filo.LCCCCS.CommunityCalendarService`, ($self) => class CommunityCalendarService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295675153)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295675153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295675153)
            
            static $h = 707857;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295675153),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 707857,
      "h": 4295675153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295675153)
  ],
  "h": 707857
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Client.Services.CommunityCalendarService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Client${separator}Services${separator}CommunityCalendarService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(707857)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Calendar.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(52497)
