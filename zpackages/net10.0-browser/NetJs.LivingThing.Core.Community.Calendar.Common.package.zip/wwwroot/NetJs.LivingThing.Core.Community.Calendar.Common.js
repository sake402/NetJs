
//--TRIMMABLE-BOUNDARY-START(9587)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $HiSiZj;
    let $svKhub;
    let $ldveig;
    let $OVqqlf;
    let $NVzbgb;
    let $xfddpd;
    let $iakoTk;
    let $YVBISh;
    let $UaoXnl;
    let $KztEOg;
    let $HcTXIc;
    let $miIAWg;
    let $yxvwAf;
    let $PKEHqf;
    let $cWwFFj;
    let $CmAPnc;
    let $opqFVh;
    let $TsNFRf;
    let $bJLgVk;
    let $xjAaTi;
    let $DwIlAi;
    let $ZkGpwh;
    let $rzRhik;
    let $RVKPWk;
    let $FwzEJj;
    let $yIYCGh;
    let $pGBxVc;
    let $qMieWe;
    let $xRvfEc;
    let $DLGhLe;
    let $achJBk;
    let $fqSiZi;
    let $Hpfdqb;
    let $Uarmpa;
    let $mDPptb;
    let $BfkAoc;
    let $hjrabk;
    let $nXaPIc;
    let $tytEJj;
    let $FTkpAj;
    let $GvVzfj;
    let $UAiCsk;
    let $psFxSe;
    let $eAcOYb;
    let $EFeIBc;
    let $dsKXQd;
    let $cUFLRa;
    let $uikjRf;
    let $kcmWwb;
    let $hpVwUe;
    let $qVexoe;
    let $HCrSxk;
    let $lOmCye;
    let $eNwKba;
    let $Gmgzok;
    let $vyfKmi;
    let $onCVZj;
    let $EtGiAh;
    let $jaWuFh;
    let $ItSkAj;
    let $twSPig;
    let $eAiznj;
    let $QiZpKd;
    let $qPObCk;
    let $tIrXjc;
    let $MDWbXh;
    let $mBUMqi;
    let $ZAozja;
    let $BATxLb;
    let $mFbbKc;
    let $CXjlVh;
    let $hWboIg;
    let $ldgSXf;
    let $DVRpTe;
    let $fFyCIc;
    let $PtTwbi;
    let $KqSUoi;
    let $wffhml;
    let $NYGuIh;
    let $jvrxwi;
    let $TRUhXd;
    let $nNAWZj;
    let $MPaoVd;
    let $TCCDLf;
    let $KiDLCk;
    let $KUNEgb;
    let $dSDQGh;
    let $kBYuxf;
    let $ONuOCf;
    let $kHRoBb;
    let $eWbKQk;
    let $qrrOih;
    let $qaYHoj;
    let $gTZEpa;
    let $ngRoTd;
    let $ZHOZJe;
    let $KhYbDk;
    let $bwFTMi;
    let $foGnHa;
    let $rVkMKe;
    let $YWhHJc;
    let $fhLKGb;
    let $LXpgjh;
    let $EefOMg;
    let $mMUmZf;
    let $lMriOc;
    let $QSZpBd;
    let $rfmwig;
    let $SUuJWf;
    let $usmYFc;
    let $XflRKe;
    let $RbYqzc;
    let $xwPaDa;
    let $KAlCHe;
    let $GiqXie;
    let $HZdLTa;
    let $zMsIGg;
    let $RhjMIi;
    let $VLQOTi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Calendar.Common", 
    {
  "h": 9587,
  "f": "LivingThing.Core.Community.Calendar.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Calendar.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Calendar.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1779059)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventRecurrenceTypeCustomAttributesProvider`, ($self) => class CommunityCalendarEventRecurrenceTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296746355)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296746355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296746355)
            
            static $h = 1779059;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296746355),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1779059,
      "h": 4296746355,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296746355)
  ],
  "h": 1779059
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventRecurrenceTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventRecurrenceTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1779059)
        
        

        //--TRIMMABLE-BOUNDARY-START(861555)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventEditionModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventEditionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295828851)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295828851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295828851)
            
            static $h = 861555;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295828851),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 861555,
      "h": 4295828851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295828851)
  ],
  "h": 861555
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventEditionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(861555)
        
        

        //--TRIMMABLE-BOUNDARY-START(3810675)
        $asm.$cls(`$OnVo.LCCCCS$1.CommunityCalendarSettingsCustomAttributesProvider`, ($self) => class CommunityCalendarSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298777971)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298777971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298777971)
            
            static $h = 3810675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298777971),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3810675,
      "h": 4298777971,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298777971)
  ],
  "h": 3810675
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Settings${separator}CommunityCalendarSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3810675)
        
        

        //--TRIMMABLE-BOUNDARY-START(1123699)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventMaterialModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventMaterialModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296090995)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296090995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296090995)
            
            static $h = 1123699;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296090995),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1123699,
      "h": 4296090995,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296090995)
  ],
  "h": 1123699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventMaterialModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1123699)
        
        

        //--TRIMMABLE-BOUNDARY-START(2893171)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventWeekOfMonthCustomAttributesProvider`, ($self) => class CommunityCalendarEventWeekOfMonthCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297860467)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297860467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297860467)
            
            static $h = 2893171;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297860467),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2893171,
      "h": 4297860467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297860467)
  ],
  "h": 2893171
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventWeekOfMonthCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventWeekOfMonthCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2893171)
        
        

        //--TRIMMABLE-BOUNDARY-START(599411)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventCategoryModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295566707)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295566707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295566707)
            
            static $h = 599411;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295566707),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 599411,
      "h": 4295566707,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295566707)
  ],
  "h": 599411
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(599411)
        
        

        //--TRIMMABLE-BOUNDARY-START(140659)
        $asm.$cls(`$OnVo.LCCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295107955)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295107955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295107955)
            
            static $h = 140659;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295107955),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 140659,
      "h": 4295107955,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295107955)
  ],
  "h": 140659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(140659)
        
        

        //--TRIMMABLE-BOUNDARY-START(3286387)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarPostInteractionTypeCustomAttributesProvider`, ($self) => class CommunityCalendarPostInteractionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298253683)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298253683)
            
            //--TRIMMABLE-BOUNDARY-START(8593220979)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593220979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarPostInteractionTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarPostInteractionTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $svKhub ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3286387,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ldveig ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3286387,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593220979)
            
            static $h = 3286387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593220979),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3286387,
      "h": 8593220979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593220979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298253683),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3286387,
      "h": 4298253683,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298253683)
  ],
  "h": 3286387
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarPostInteractionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarPostInteractionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3286387)
        
        

        //--TRIMMABLE-BOUNDARY-START(3024243)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarModelCustomAttributesProvider`, ($self) => class CommunityCalendarModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297991539)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297991539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297991539)
            
            static $h = 3024243;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297991539),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3024243,
      "h": 4297991539,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297991539)
  ],
  "h": 3024243
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3024243)
        
        

        //--TRIMMABLE-BOUNDARY-START(337267)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventBookingModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventBookingModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295304563)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295304563)
            
            //--TRIMMABLE-BOUNDARY-START(8590271859)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590271859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("FirstName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LastName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Email", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PhoneNumber", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AmountPaid", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Session", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Seats", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t11 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i11 = new $t11();
                        $i11.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i11.set_Item("FirstName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t12 = $.$sca.SCD.RequiredAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$6();
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i11.set_Item("LastName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t13 = $.$sca.SCD.RequiredAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$6();
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i11.set_Item("Email", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t14 = $.$sca.SCD.RequiredAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$6();
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i11;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xfddpd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":337267,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $iakoTk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":337267,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590271859)
            
            static $h = 337267;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590271859),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 337267,
      "h": 8590271859,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590271859)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295304563),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 337267,
      "h": 4295304563,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295304563)
  ],
  "h": 337267
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventBookingModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(337267)
        
        

        //--TRIMMABLE-BOUNDARY-START(992627)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventEditionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590927219)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590927219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KztEOg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":992627,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590927219)
            
            //--TRIMMABLE-BOUNDARY-START(4295959923)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295959923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295959923)
            
            //--TRIMMABLE-BOUNDARY-START(4295959923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295959923)
            
            static $h = 992627;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590927219),
    {
      "r": 65537,
      "n": "Register",
      "d": 992627,
      "h": 8590927219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590927219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295959923),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 992627,
      "h": 4295959923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295959923)
  ],
  "h": 992627
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventEditionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(992627)
        
        

        //--TRIMMABLE-BOUNDARY-START(2696563)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventTypeCustomAttributesProvider`, ($self) => class CommunityCalendarEventTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297663859)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297663859)
            
            //--TRIMMABLE-BOUNDARY-START(8592631155)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592631155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarEventTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(9, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Birthday", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-alarm"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Trip", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-road"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Meeting", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-group"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HouseWarming", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-home"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Marriage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-cake-variant"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Concert", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-music"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Conference", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-account-group"], [-1], null);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Sport", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-football"], [-1], null);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Exhibition", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-handball"], [-1], null);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarEventTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $OVqqlf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2696563,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NVzbgb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2696563,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592631155)
            
            static $h = 2696563;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592631155),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2696563,
      "h": 8592631155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592631155)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297663859),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2696563,
      "h": 4297663859,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297663859)
  ],
  "h": 2696563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2696563)
        
        

        //--TRIMMABLE-BOUNDARY-START(730483)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590665075)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590665075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yIYCGh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":730483,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590665075)
            
            //--TRIMMABLE-BOUNDARY-START(4295697779)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295697779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295697779)
            
            //--TRIMMABLE-BOUNDARY-START(4295697779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295697779)
            
            static $h = 730483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590665075),
    {
      "r": 65537,
      "n": "Register",
      "d": 730483,
      "h": 8590665075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590665075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295697779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 730483,
      "h": 4295697779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295697779)
  ],
  "h": 730483
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(730483)
        
        

        //--TRIMMABLE-BOUNDARY-START(1254771)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventMaterialModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591189363)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591189363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rzRhik ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1254771,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591189363)
            
            //--TRIMMABLE-BOUNDARY-START(4296222067)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296222067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296222067)
            
            //--TRIMMABLE-BOUNDARY-START(4296222067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296222067)
            
            static $h = 1254771;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591189363),
    {
      "r": 65537,
      "n": "Register",
      "d": 1254771,
      "h": 8591189363,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591189363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296222067),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1254771,
      "h": 4296222067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296222067)
  ],
  "h": 1254771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventMaterialModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1254771)
        
        

        //--TRIMMABLE-BOUNDARY-START(4269427)
        $asm.$cls(`$OnVo.LCCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299236723)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299236723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptorBuilder.Register();
                $.$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299236723)
            
            static $h = 4269427;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299236723),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4269427,
      "h": 4299236723,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299236723)
  ],
  "h": 4269427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4269427)
        
        

        //--TRIMMABLE-BOUNDARY-START(206195)
        $asm.$cls(`$OnVo.LCCCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295173491)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295173491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService, $.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService_Mocking().$ctor$3(impl);
                }, $yxvwAf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService_Mocking().$ctor$3(impl);
                }, $PKEHqf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$OnVo.LCCCCS.IComunityCalendarRemoteService, $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $cWwFFj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $CmAPnc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $opqFVh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $TsNFRf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $bJLgVk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $xjAaTi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $DwIlAi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking().$ctor$3(impl);
                }, $ZkGpwh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":206195,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295173491)
            
            static $h = 206195;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295173491),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 206195,
      "h": 4295173491,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295173491)
  ],
  "h": 206195
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(206195)
        
        

        //--TRIMMABLE-BOUNDARY-START(3155315)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593089907)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593089907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YVBISh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3155315,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593089907)
            
            //--TRIMMABLE-BOUNDARY-START(4298122611)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298122611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298122611)
            
            //--TRIMMABLE-BOUNDARY-START(4298122611)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298122611)
            
            static $h = 3155315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593089907),
    {
      "r": 65537,
      "n": "Register",
      "d": 3155315,
      "h": 8593089907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593089907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298122611),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3155315,
      "h": 4298122611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298122611)
  ],
  "h": 3155315
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3155315)
        
        

        //--TRIMMABLE-BOUNDARY-START(1910131)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventSeatTypeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296877427)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296877427)
            
            //--TRIMMABLE-BOUNDARY-START(8591844723)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591844723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Capacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Session", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $achJBk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1910131,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $fqSiZi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1910131,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591844723)
            
            static $h = 1910131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591844723),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1910131,
      "h": 8591844723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591844723)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296877427),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1910131,
      "h": 4296877427,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296877427)
  ],
  "h": 1910131
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSeatTypeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1910131)
        
        

        //--TRIMMABLE-BOUNDARY-START(4203891)
        $asm.$cls(`$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptorBuilder`, ($self) => class CommunityCalendarStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594138483)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594138483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xRvfEc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4203891,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCS$2.CommunityCalendarStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594138483)
            
            //--TRIMMABLE-BOUNDARY-START(4299171187)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299171187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299171187)
            
            //--TRIMMABLE-BOUNDARY-START(4299171187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299171187)
            
            static $h = 4203891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594138483),
    {
      "r": 65537,
      "n": "Register",
      "d": 4203891,
      "h": 8594138483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594138483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299171187),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4203891,
      "h": 4299171187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299171187)
  ],
  "h": 4203891
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}States${separator}CommunityCalendarStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4203891)
        
        

        //--TRIMMABLE-BOUNDARY-START(3941747)
        $asm.$cls(`$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptorBuilder`, ($self) => class CommunityCalendarSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593876339)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593876339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Hpfdqb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3941747,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCS$1.CommunityCalendarSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593876339)
            
            //--TRIMMABLE-BOUNDARY-START(4298909043)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298909043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298909043)
            
            //--TRIMMABLE-BOUNDARY-START(4298909043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298909043)
            
            static $h = 3941747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593876339),
    {
      "r": 65537,
      "n": "Register",
      "d": 3941747,
      "h": 8593876339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593876339)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298909043),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3941747,
      "h": 4298909043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298909043)
  ],
  "h": 3941747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Settings${separator}CommunityCalendarSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3941747)
        
        

        //--TRIMMABLE-BOUNDARY-START(2434419)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventSpeakerModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297401715)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297401715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297401715)
            
            static $h = 2434419;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297401715),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2434419,
      "h": 4297401715,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297401715)
  ],
  "h": 2434419
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSpeakerModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2434419)
        
        

        //--TRIMMABLE-BOUNDARY-START(2041203)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591975795)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591975795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UAiCsk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2041203,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591975795)
            
            //--TRIMMABLE-BOUNDARY-START(4297008499)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297008499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297008499)
            
            //--TRIMMABLE-BOUNDARY-START(4297008499)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297008499)
            
            static $h = 2041203;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591975795),
    {
      "r": 65537,
      "n": "Register",
      "d": 2041203,
      "h": 8591975795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591975795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297008499),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2041203,
      "h": 4297008499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297008499)
  ],
  "h": 2041203
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2041203)
        
        

        //--TRIMMABLE-BOUNDARY-START(75123)
        $asm.$cls(`$OnVo.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295042419)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295042419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventEditionModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarPostInteractionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarPostInteractionTypeCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarPostInteractionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventRecurrenceType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventRecurrenceTypeCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventRecurrenceTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventTypeCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarEventWeekOfMonth.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventWeekOfMonthCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarEventWeekOfMonthCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCM.CommunityCalendarModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCM.CommunityCalendarModelCustomAttributesProvider, $.$OnVo.LCCCCM.CommunityCalendarModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCS$1.CommunityCalendarSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCS$1.CommunityCalendarSettingsCustomAttributesProvider, $.$OnVo.LCCCCS$1.CommunityCalendarSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OnVo.LCCCCS$2.CommunityCalendarStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OnVo.LCCCCS$2.CommunityCalendarStatesCustomAttributesProvider, $.$OnVo.LCCCCS$2.CommunityCalendarStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295042419)
            
            static $h = 75123;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295042419),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 75123,
      "h": 4295042419,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295042419)
  ],
  "h": 75123
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(75123)
        
        

        //--TRIMMABLE-BOUNDARY-START(1385843)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296353139)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296353139)
            
            //--TRIMMABLE-BOUNDARY-START(8591320435)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591320435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(13, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("SetType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i3.Order = (-2147483648);
                            $i3.Description = "Tell us the type of calendar you are creating";
                            $i3.InputType = $.$cast(41n, $.$fPer.LCFC.InputType);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-calendar"], [-1], null);
                            $i3.OptionsReader = ($.$OnVo.LCCCCM.CommunityCalendarEventTypeReader.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Resources", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i4.Order = (1023);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=AudioVideo"], [-1], null);
                            $i4.Description = "Upload more banners";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EventType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1024);
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i5.Description = "Type of event";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=CalendarHeart"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (1025);
                            $i6.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i6.Description = "Date and time event commences";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=CalendarStart"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (1025);
                            $i7.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i7.Description = "Date and time event commences";
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=CalendarStart"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Recurrence", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (1026);
                            $i8.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i8.Description = "How will this event recur/repeat";
                            $i8.ExcludeFilter = ($.$OnVo.LCCCCM.CommunityCallendarEventRecurrenceFilter.$type);
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Repeat", "//DependsOn=EventType"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Capacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (1027);
                            $i9.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i9.Description = "How many attendee can this event take, zero for no limit";
                            $i9.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Head"], [-1], null);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (1028);
                            $i10.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i10.Description = "How much will it cost to attend this event, 0 for free";
                            $i10.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Head"], [-1], null);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Sessions", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Speakers", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SeatTypes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SeatBookings", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ScheduledDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t16 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i16 = new $t16();
                        $i16.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i16.set_Item("StartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t17 = $.$sca.SCD.RequiredAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$6();
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i16.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t18 = $.$sca.SCD.RequiredAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$6();
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i16;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarEventPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $FTkpAj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1385843,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GvVzfj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1385843,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591320435)
            
            static $h = 1385843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591320435),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1385843,
      "h": 8591320435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591320435)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296353139),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1385843,
      "h": 4296353139,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296353139)
  ],
  "h": 1385843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1385843)
        
        

        //--TRIMMABLE-BOUNDARY-START(2172275)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelCustomAttributesProvider`, ($self) => class CommunityCalendarEventSessionPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297139571)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297139571)
            
            //--TRIMMABLE-BOUNDARY-START(8592106867)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592106867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(8, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("StartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1024);
                            $i3.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1024);
                            $i4.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Duration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1025);
                            $i5.Description = "In minutes";
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Capacity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (1027);
                            $i6.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i6.Description = "How many attendee can this event take, zero for no limit";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Head"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Amount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (1028);
                            $i7.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i7.Description = "How much will it cost to attend this event, 0 for free";
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=Head"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Speakers", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SeatTypes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Bookings", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t11 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i11 = new $t11();
                        $i11.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i11.set_Item("StartDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t12 = $.$sca.SCD.RequiredAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$6();
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i11.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t13 = $.$sca.SCD.RequiredAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$6();
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i11.set_Item("Duration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t14 = $.$sca.SCD.RequiredAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$6();
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i11;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $nXaPIc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2172275,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tytEJj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2172275,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592106867)
            
            static $h = 2172275;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592106867),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2172275,
      "h": 8592106867,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592106867)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297139571),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2172275,
      "h": 4297139571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297139571)
  ],
  "h": 2172275
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSessionPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2172275)
        
        

        //--TRIMMABLE-BOUNDARY-START(2565491)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventSpeakerModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592500083)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592500083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mDPptb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2565491,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592500083)
            
            //--TRIMMABLE-BOUNDARY-START(4297532787)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297532787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297532787)
            
            //--TRIMMABLE-BOUNDARY-START(4297532787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297532787)
            
            static $h = 2565491;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592500083),
    {
      "r": 65537,
      "n": "Register",
      "d": 2565491,
      "h": 8592500083,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592500083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297532787),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2565491,
      "h": 4297532787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297532787)
  ],
  "h": 2565491
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSpeakerModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2565491)
        
        

        //--TRIMMABLE-BOUNDARY-START(4072819)
        $asm.$cls(`$OnVo.LCCCCS$2.CommunityCalendarStatesCustomAttributesProvider`, ($self) => class CommunityCalendarStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299040115)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299040115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299040115)
            
            static $h = 4072819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299040115),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4072819,
      "h": 4299040115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299040115)
  ],
  "h": 4072819
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}States${separator}CommunityCalendarStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4072819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1516915)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591451507)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591451507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hWboIg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1516915,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591451507)
            
            //--TRIMMABLE-BOUNDARY-START(4296484211)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296484211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296484211)
            
            //--TRIMMABLE-BOUNDARY-START(4296484211)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296484211)
            
            static $h = 1516915;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591451507),
    {
      "r": 65537,
      "n": "Register",
      "d": 1516915,
      "h": 8591451507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591451507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296484211),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1516915,
      "h": 4296484211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296484211)
  ],
  "h": 1516915
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1516915)
        
        

        //--TRIMMABLE-BOUNDARY-START(2303347)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventSessionPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592237939)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592237939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lOmCye ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2303347,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592237939)
            
            //--TRIMMABLE-BOUNDARY-START(4297270643)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297270643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297270643)
            
            //--TRIMMABLE-BOUNDARY-START(4297270643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297270643)
            
            static $h = 2303347;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592237939),
    {
      "r": 65537,
      "n": "Register",
      "d": 2303347,
      "h": 8592237939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592237939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297270643),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2303347,
      "h": 4297270643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297270643)
  ],
  "h": 2303347
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSessionPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2303347)
        
        

        //--TRIMMABLE-BOUNDARY-START(468339)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptorBuilder`, ($self) => class CommunityCalendarEventBookingModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590402931)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590402931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor()
                        const $t1 = $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YWhHJc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":468339,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590402931)
            
            //--TRIMMABLE-BOUNDARY-START(4295435635)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295435635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295435635)
            
            //--TRIMMABLE-BOUNDARY-START(4295435635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295435635)
            
            static $h = 468339;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590402931),
    {
      "r": 65537,
      "n": "Register",
      "d": 468339,
      "h": 8590402931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590402931)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295435635),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 468339,
      "h": 4295435635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295435635)
  ],
  "h": 468339
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventBookingModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(468339)
        
        

        //--TRIMMABLE-BOUNDARY-START(1647987)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventRecurrenceFilter`, ($self) => class CommunityCalendarEventRecurrenceFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591582579)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591582579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let rc;
                if ($.$is(target, $.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, { set $v($v){ rc = $v; } }))
                {
                    let $switch1 = typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name;
                    switch($switch1)
                    {
                        case "Date":
                        return rc.Recurrence === 2/*CommunityCalendarEventRecurrenceType.Monthly*/;
                        case "Week":
                        return rc.Recurrence === 3/*CommunityCalendarEventRecurrenceType.WeekMonthly*/;
                        case "WeekDay":
                        return rc.Recurrence === 1/*CommunityCalendarEventRecurrenceType.Weekly*/ || rc.Recurrence === 3/*CommunityCalendarEventRecurrenceType.WeekMonthly*/;
                    }
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8591582579)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4296615283)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296615283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296615283)
            
            //--TRIMMABLE-BOUNDARY-START(4296615283)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296615283)
            
            static $h = 1647987;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591582579),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 1647987,
      "h": 8591582579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591582579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296615283),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1647987,
      "h": 4296615283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296615283)
  ],
  "h": 1647987
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventRecurrenceFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventRecurrenceFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1647987)
        
        

        //--TRIMMABLE-BOUNDARY-START(3417459)
        $asm.$cls(`$OnVo.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593352051)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593352051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, 5632/*PostTypes.Calendar*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, 5633/*PostTypes.CalendarEventOnce*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, 5634/*PostTypes.CalendarEventRecurring*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel, 5635/*PostTypes.CalendarEventEdition*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, 5636/*PostTypes.CalendarEventSession*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, 5637/*PostTypes.CalendarEventSpeaker*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, 5638/*PostTypes.CalendarEventMaterial*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, 5639/*PostTypes.CalendarEventCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, 5640/*PostTypes.CalendarEventSeatType*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, 5641/*PostTypes.CalendarEventBooking*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$uvJL.LCFCR.RemoteSchemaOptionReader$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel), services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.RemoteSchemaOptionReader$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel), x);
                }, $HiSiZj ??= {"r":$.$fPer.LCFCA$1.ISchemaOptionReader$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":3417459,"h":0,"f":17825794}));
                $.$OnVo.LCCCC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$OnVo.LCCCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$OnVo.LCCCC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593352051)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OnVo.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298384755)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298384755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298384755)
            
            //--TRIMMABLE-BOUNDARY-START(4298384755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298384755)
            
            static $h = 3417459;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593352051),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3417459,
      "h": 8593352051,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593352051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298384755),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3417459,
      "h": 4298384755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298384755)
  ],
  "h": 3417459
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3417459)
        
        

        //--TRIMMABLE-BOUNDARY-START(3351923)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCallendarEventRecurrenceFilter`, ($self) => class CommunityCallendarEventRecurrenceFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593286515)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593286515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ev;
                if ($.$is(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, { set $v($v){ ev = $v; } }))
                {
                    return ev.Type === 5634/*PostTypes.CalendarEventRecurring*/;
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8593286515)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4298319219)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298319219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298319219)
            
            //--TRIMMABLE-BOUNDARY-START(4298319219)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298319219)
            
            static $h = 3351923;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593286515),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 3351923,
      "h": 8593286515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593286515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298319219),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3351923,
      "h": 4298319219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298319219)
  ],
  "h": 3351923
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCallendarEventRecurrenceFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCallendarEventRecurrenceFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3351923)
        
        

        //--TRIMMABLE-BOUNDARY-START(1582451)
        $asm.$str(`$OnVo.LCCCCM.CommunityCalendarEventRecurrence`, ($self) => class CommunityCalendarEventRecurrence extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(64426091891)
            /*CommunityCalendarEventRecurrenceType*/ Recurrence = 0;
            //--TRIMMABLE-BOUNDARY-END(64426091891)
            
            //--TRIMMABLE-BOUNDARY-START(25771386227)
            /*int*/ Date = 0;
            //--TRIMMABLE-BOUNDARY-END(25771386227)
            
            //--TRIMMABLE-BOUNDARY-START(103080797555)
            /*CommunityCalendarEventWeekOfMonth*/ Week = 0;
            //--TRIMMABLE-BOUNDARY-END(103080797555)
            
            //--TRIMMABLE-BOUNDARY-START(107375764851)
            /*DayOfWeek*/ WeekDay = 0;
            //--TRIMMABLE-BOUNDARY-END(107375764851)
            
            //--TRIMMABLE-BOUNDARY-START(21476418931)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476418931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476418931)
            
            //--TRIMMABLE-BOUNDARY-START(21476418931)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21476418931)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Recurrence = this.Recurrence;
                copy.Date = this.Date;
                copy.Week = this.Week;
                copy.WeekDay = this.WeekDay;
                return copy;
            }
            static $h = 1582451;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426091891),
    {
      "p": 1713523,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951255411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605961075,
        "f": 83886081
      },
      "n": "Recurrence",
      "d": 1582451,
      "h": 64426091891,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426091891),
//--TRIMMABLE-BOUNDARY-START(25771386227),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361320819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016026483,
        "f": 83886081
      },
      "n": "Date",
      "d": 1582451,
      "h": 25771386227,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "ExcludeFilter",
              "v": 1647987,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771386227),
//--TRIMMABLE-BOUNDARY-START(103080797555),
    {
      "p": 2827635,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541190003,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195895667,
        "f": 83886081
      },
      "n": "Week",
      "d": 1582451,
      "h": 103080797555,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "ExcludeFilter",
              "v": 1647987,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080797555),
//--TRIMMABLE-BOUNDARY-START(107375764851),
    {
      "p": 66715649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131124595,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785830259,
        "f": 83886081
      },
      "n": "WeekDay",
      "d": 1582451,
      "h": 107375764851,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "ExcludeFilter",
              "v": 1647987,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375764851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476418931),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1582451,
      "h": 21476418931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476418931)
  ],
  "h": 1582451
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventRecurrence`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventRecurrence`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1582451)
        
        

        //--TRIMMABLE-BOUNDARY-START(1713523)
        $asm.$str(`$OnVo.LCCCCM.CommunityCalendarEventRecurrenceType`, ($self) => class CommunityCalendarEventRecurrenceType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Daily = 0;
            static Weekly = 1;
            static Monthly = 2;
            static WeekMonthly = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1713523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Daily": 0n,
                    "Weekly": 1n,
                    "Monthly": 2n,
                    "WeekMonthly": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296680819)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296680819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296680819)
            
            //--TRIMMABLE-BOUNDARY-START(4296680819)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296680819)
            
            static $h = 1713523;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591648115),
    {
      "t": 1713523,
      "n": "Daily",
      "d": 1713523,
      "h": 8591648115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591648115),
//--TRIMMABLE-BOUNDARY-START(17181582707),
    {
      "t": 1713523,
      "n": "Weekly",
      "d": 1713523,
      "h": 17181582707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181582707),
//--TRIMMABLE-BOUNDARY-START(12886615411),
    {
      "t": 1713523,
      "n": "Monthly",
      "d": 1713523,
      "h": 12886615411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886615411),
//--TRIMMABLE-BOUNDARY-START(21476550003),
    {
      "t": 1713523,
      "n": "WeekMonthly",
      "d": 1713523,
      "h": 21476550003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476550003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296680819),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1713523,
      "h": 4296680819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296680819)
  ],
  "h": 1713523
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventRecurrenceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventRecurrenceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1713523)
        
        

        //--TRIMMABLE-BOUNDARY-START(2827635)
        $asm.$str(`$OnVo.LCCCCM.CommunityCalendarEventWeekOfMonth`, ($self) => class CommunityCalendarEventWeekOfMonth extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static FirstWeek = 1;
            static SecondWeek = 2;
            static ThirdWeek = 3;
            static FourthWeek = 4;
            static LastWeek = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2827635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FirstWeek": 1n,
                    "SecondWeek": 2n,
                    "ThirdWeek": 3n,
                    "FourthWeek": 4n,
                    "LastWeek": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297794931)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297794931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297794931)
            
            //--TRIMMABLE-BOUNDARY-START(4297794931)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297794931)
            
            static $h = 2827635;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592762227),
    {
      "t": 2827635,
      "n": "FirstWeek",
      "d": 2827635,
      "h": 8592762227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592762227),
//--TRIMMABLE-BOUNDARY-START(21477664115),
    {
      "t": 2827635,
      "n": "SecondWeek",
      "d": 2827635,
      "h": 21477664115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477664115),
//--TRIMMABLE-BOUNDARY-START(25772631411),
    {
      "t": 2827635,
      "n": "ThirdWeek",
      "d": 2827635,
      "h": 25772631411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772631411),
//--TRIMMABLE-BOUNDARY-START(12887729523),
    {
      "t": 2827635,
      "n": "FourthWeek",
      "d": 2827635,
      "h": 12887729523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887729523),
//--TRIMMABLE-BOUNDARY-START(17182696819),
    {
      "t": 2827635,
      "n": "LastWeek",
      "d": 2827635,
      "h": 17182696819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182696819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297794931),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2827635,
      "h": 4297794931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297794931)
  ],
  "h": 2827635
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventWeekOfMonth`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventWeekOfMonth`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2827635)
        
        

        //--TRIMMABLE-BOUNDARY-START(2631027)
        $asm.$str(`$OnVo.LCCCCM.CommunityCalendarEventType`, ($self) => class CommunityCalendarEventType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static General = 0;
            static Birthday = 1;
            static Trip = 2;
            static Meeting = 3;
            static HouseWarming = 4;
            static Marriage = 5;
            static Concert = 6;
            static Conference = 7;
            static Sport = 8;
            static Exhibition = 9;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2631027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "General": 0n,
                    "Birthday": 1n,
                    "Trip": 2n,
                    "Meeting": 3n,
                    "HouseWarming": 4n,
                    "Marriage": 5n,
                    "Concert": 6n,
                    "Conference": 7n,
                    "Sport": 8n,
                    "Exhibition": 9n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297598323)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297598323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297598323)
            
            //--TRIMMABLE-BOUNDARY-START(4297598323)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297598323)
            
            static $h = 2631027;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772434803),
    {
      "t": 2631027,
      "n": "General",
      "d": 2631027,
      "h": 25772434803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772434803),
//--TRIMMABLE-BOUNDARY-START(8592565619),
    {
      "t": 2631027,
      "n": "Birthday",
      "d": 2631027,
      "h": 8592565619,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-alarm"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592565619),
//--TRIMMABLE-BOUNDARY-START(47247271283),
    {
      "t": 2631027,
      "n": "Trip",
      "d": 2631027,
      "h": 47247271283,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-road"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247271283),
//--TRIMMABLE-BOUNDARY-START(38657336691),
    {
      "t": 2631027,
      "n": "Meeting",
      "d": 2631027,
      "h": 38657336691,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-group"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38657336691),
//--TRIMMABLE-BOUNDARY-START(30067402099),
    {
      "t": 2631027,
      "n": "HouseWarming",
      "d": 2631027,
      "h": 30067402099,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-home"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067402099),
//--TRIMMABLE-BOUNDARY-START(34362369395),
    {
      "t": 2631027,
      "n": "Marriage",
      "d": 2631027,
      "h": 34362369395,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-cake-variant"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34362369395),
//--TRIMMABLE-BOUNDARY-START(12887532915),
    {
      "t": 2631027,
      "n": "Concert",
      "d": 2631027,
      "h": 12887532915,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-music"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887532915),
//--TRIMMABLE-BOUNDARY-START(17182500211),
    {
      "t": 2631027,
      "n": "Conference",
      "d": 2631027,
      "h": 17182500211,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-account-group"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182500211),
//--TRIMMABLE-BOUNDARY-START(42952303987),
    {
      "t": 2631027,
      "n": "Sport",
      "d": 2631027,
      "h": 42952303987,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-football"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952303987),
//--TRIMMABLE-BOUNDARY-START(21477467507),
    {
      "t": 2631027,
      "n": "Exhibition",
      "d": 2631027,
      "h": 21477467507,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-handball"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477467507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297598323),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2631027,
      "h": 4297598323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297598323)
  ],
  "h": 2631027
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2631027)
        
        

        //--TRIMMABLE-BOUNDARY-START(3220851)
        $asm.$str(`$OnVo.LCCCCM.CommunityCalendarPostInteractionType`, ($self) => class CommunityCalendarPostInteractionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt64)
        {
            static BookSeat = 4294967296n;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3220851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "BookSeat": 4294967296n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298188147)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298188147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298188147)
            
            //--TRIMMABLE-BOUNDARY-START(4298188147)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298188147)
            
            static $h = 3220851;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 917505,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593155443),
    {
      "t": 3220851,
      "n": "BookSeat",
      "d": 3220851,
      "h": 8593155443,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593155443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298188147),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3220851,
      "h": 4298188147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298188147)
  ],
  "h": 3220851,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarPostInteractionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarPostInteractionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3220851)
        
        

        //--TRIMMABLE-BOUNDARY-START(3745139)
        $asm.$cls(`$OnVo.LCCCCS$1.CommunityCalendarSettings`, ($self) => class CommunityCalendarSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298712435)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298712435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298712435)
            
            //--TRIMMABLE-BOUNDARY-START(4298712435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298712435)
            
            static $h = 3745139;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298712435),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3745139,
      "h": 4298712435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298712435)
  ],
  "h": 3745139
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Settings${separator}CommunityCalendarSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3745139)
        
        

        //--TRIMMABLE-BOUNDARY-START(4007283)
        $asm.$cls(`$OnVo.LCCCCS$2.CommunityCalendarStates`, ($self) => class CommunityCalendarStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298974579)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298974579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298974579)
            
            //--TRIMMABLE-BOUNDARY-START(4298974579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298974579)
            
            static $h = 4007283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298974579),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4007283,
      "h": 4298974579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298974579)
  ],
  "h": 4007283
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}States${separator}CommunityCalendarStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4007283)
        
        

        //--TRIMMABLE-BOUNDARY-START(2762099)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventTypeReader`, ($self) => class CommunityCalendarEventTypeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592696691)
            /*Pager<ISelectOption<PostTypes?>> */ GetOptions(/*object*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592696691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCP.PostUtility.GetPostTypeOptions(this, "Calendar", null);
            }
            //--TRIMMABLE-BOUNDARY-END(8592696691)
            
            //--TRIMMABLE-BOUNDARY-START(4297034070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaOptionReader<LivingThing.Core.Frameworks.Common.Posts.Models.PostTypes?>.GetOptions(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            [`LCFCA$1$ISchemaOptionReader$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$LivingThing$Core$Frameworks$Common$Posts$Models$PostTypes$$GetOptions`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297034070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOptions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297034070)
            
            //--TRIMMABLE-BOUNDARY-START(4297729395)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297729395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297729395)
            
            //--TRIMMABLE-BOUNDARY-START(4297729395)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297729395)
            
            static $h = 2762099;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592696691),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFC.ISelectOption$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes))).$h,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "GetOptions",
      "d": 2762099,
      "h": 8592696691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592696691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297729395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2762099,
      "h": 4297729395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297729395)
  ],
  "h": 2762099
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventTypeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventTypeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2762099)
        
        

        //--TRIMMABLE-BOUNDARY-START(4138355)
        $asm.$cls(`$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptor`, ($self) => class CommunityCalendarStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCS$2.CommunityCalendarStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4299105651)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299105651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptor.GenerateProperties($.$OnVo.LCCCCS$2.CommunityCalendarStates, this, factory);
                    }, $DLGhLe ??= {"r":65537,"n":"","d":4138355,"h":0,"f":17825794}), 0, "CommunityCalendarStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\States_CommunityCalendarStates_LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStatesTypeDescriptorBuilder.g.cs", "CommunityCalendarStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299105651)
            
            //--TRIMMABLE-BOUNDARY-START(12889040243)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889040243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889040243)
            
            //--TRIMMABLE-BOUNDARY-START(17184007539)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184007539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184007539)
            
            //--TRIMMABLE-BOUNDARY-START(8594072947)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594072947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCS$2.CommunityCalendarStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCS$2.CommunityCalendarStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$2.CommunityCalendarStates)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCS$2.CommunityCalendarStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$2.CommunityCalendarStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCS$2.CommunityCalendarStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$2.CommunityCalendarStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594072947)
            
            static $h = 4138355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCS$2.CommunityCalendarStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889040243),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4138355,
      "h": 12889040243,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889040243),
//--TRIMMABLE-BOUNDARY-START(17184007539),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4007283,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4138355,
      "h": 17184007539,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184007539),
//--TRIMMABLE-BOUNDARY-START(8594072947),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4007283,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4138355,
      "h": 8594072947,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594072947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299105651),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4138355,
      "h": 4299105651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299105651)
  ],
  "h": 4138355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCS$2.CommunityCalendarStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}States${separator}CommunityCalendarStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4138355)
        
        

        //--TRIMMABLE-BOUNDARY-START(3876211)
        $asm.$cls(`$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptor`, ($self) => class CommunityCalendarSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298843507)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298843507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptor.GenerateProperties($.$OnVo.LCCCCS$1.CommunityCalendarSettings, this, factory);
                    }, $Uarmpa ??= {"r":65537,"n":"","d":3876211,"h":0,"f":17825794}), 0, "CommunityCalendarSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Settings_CommunityCalendarSettings_LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettingsTypeDescriptorBuilder.g.cs", "CommunityCalendarSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298843507)
            
            //--TRIMMABLE-BOUNDARY-START(12888778099)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888778099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888778099)
            
            //--TRIMMABLE-BOUNDARY-START(17183745395)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183745395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183745395)
            
            //--TRIMMABLE-BOUNDARY-START(8593810803)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593810803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCS$1.CommunityCalendarSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCS$1.CommunityCalendarSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$1.CommunityCalendarSettings)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCS$1.CommunityCalendarSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$1.CommunityCalendarSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCS$1.CommunityCalendarSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCS$1.CommunityCalendarSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593810803)
            
            static $h = 3876211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888778099),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3876211,
      "h": 12888778099,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888778099),
//--TRIMMABLE-BOUNDARY-START(17183745395),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3745139,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3876211,
      "h": 17183745395,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183745395),
//--TRIMMABLE-BOUNDARY-START(8593810803),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3745139,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3876211,
      "h": 8593810803,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593810803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298843507),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3876211,
      "h": 4298843507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298843507)
  ],
  "h": 3876211
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Settings${separator}CommunityCalendarSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3876211)
        
        

        //--TRIMMABLE-BOUNDARY-START(1844595)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel`, ($self) => class CommunityCalendarEventSeatTypeModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(111670994291)
            /*PostTypes */ get Type()
            {
                return 5640/*PostTypes.CalendarEventSeatType*/;
            }
            //--TRIMMABLE-BOUNDARY-END(111670994291)
            
            //--TRIMMABLE-BOUNDARY-START(68721321331)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721321331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721321331)
            
            //--TRIMMABLE-BOUNDARY-START(64426354035)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426354035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426354035)
            
            //--TRIMMABLE-BOUNDARY-START(12886746483)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361582963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Capacity", null);
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196157811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Capacity");
            }
            //--TRIMMABLE-BOUNDARY-END(12886746483)
            
            //--TRIMMABLE-BOUNDARY-START(8591779187)
            /*Money */ get Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771648371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money(), "Amount", null);
            }
            /*Money */ set Amount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606223219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "Amount");
            }
            //--TRIMMABLE-BOUNDARY-END(8591779187)
            
            //--TRIMMABLE-BOUNDARY-START(17181713779)
            /*CommunityCalendarEventPostModel? */ get Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951517555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, null);
            }
            /*CommunityCalendarEventPostModel? */ set Event(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786092403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17181713779)
            
            //--TRIMMABLE-BOUNDARY-START(73016288627)
            /*CommunityCalendarEventSessionPostModel? */ get Session()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541452147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, null);
            }
            /*CommunityCalendarEventSessionPostModel? */ set Session(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376026995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(73016288627)
            
            //--TRIMMABLE-BOUNDARY-START(4296811891)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296811891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296811891)
            
            //--TRIMMABLE-BOUNDARY-START(4296811891)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296811891)
            
            static $h = 1844595;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670994291),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131386739,
        "f": 50364417
      },
      "n": "Type",
      "d": 1844595,
      "h": 111670994291,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111670994291),
//--TRIMMABLE-BOUNDARY-START(12886746483),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361582963,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196157811,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 1844595,
      "h": 12886746483,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886746483),
//--TRIMMABLE-BOUNDARY-START(8591779187),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771648371,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606223219,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1844595,
      "h": 8591779187,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591779187),
//--TRIMMABLE-BOUNDARY-START(17181713779),
    {
      "p": 1320307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951517555,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786092403,
        "f": 83886081
      },
      "n": "Event",
      "d": 1844595,
      "h": 17181713779,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181713779),
//--TRIMMABLE-BOUNDARY-START(73016288627),
    {
      "p": 2106739,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541452147,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376026995,
        "f": 83886081
      },
      "n": "Session",
      "d": 1844595,
      "h": 73016288627,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016288627)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721321331),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1844595,
      "h": 68721321331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721321331),
//--TRIMMABLE-BOUNDARY-START(64426354035),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 1844595,
      "h": 64426354035,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426354035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296811891),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1844595,
      "h": 4296811891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296811891)
  ],
  "h": 1844595
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSeatTypeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1844595)
        
        

        //--TRIMMABLE-BOUNDARY-START(271731)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventBookingModel`, ($self) => class CommunityCalendarEventBookingModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(188978832755)
            /*PostTypes */ get Type()
            {
                return 5641/*PostTypes.CalendarEventBooking*/;
            }
            //--TRIMMABLE-BOUNDARY-END(188978832755)
            
            //--TRIMMABLE-BOUNDARY-START(21475108211)
            /*string? */ get FirstName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834846579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "FirstName", null);
            }
            /*string? */ set FirstName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324127091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "FirstName");
            }
            //--TRIMMABLE-BOUNDARY-END(21475108211)
            
            //--TRIMMABLE-BOUNDARY-START(103079486835)
            /*string? */ get LastName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424781171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "LastName", null);
            }
            /*string? */ set LastName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914061683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "LastName");
            }
            //--TRIMMABLE-BOUNDARY-END(103079486835)
            
            //--TRIMMABLE-BOUNDARY-START(12885173619)
            /*string? */ get Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654977395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "Email", null);
            }
            /*string? */ set Email(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144257907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Email");
            }
            //--TRIMMABLE-BOUNDARY-END(12885173619)
            
            //--TRIMMABLE-BOUNDARY-START(107374454131)
            /*PhoneNumber */ get PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014715763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCD.PhoneNumber, new $.$fPer.LCFCD.PhoneNumber(), "PhoneNumber", null);
            }
            /*PhoneNumber */ set PhoneNumber(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503996275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCD.PhoneNumber, $.$clone(value), "PhoneNumber");
            }
            //--TRIMMABLE-BOUNDARY-END(107374454131)
            
            //--TRIMMABLE-BOUNDARY-START(8590206323)
            /*Money */ get AmountPaid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065042803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money(), "AmountPaid", null);
            }
            /*Money */ set AmountPaid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554323315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "AmountPaid");
            }
            //--TRIMMABLE-BOUNDARY-END(8590206323)
            
            //--TRIMMABLE-BOUNDARY-START(17180140915)
            /*CommunityCalendarEventPostModel? */ get Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244911987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, null);
            }
            /*CommunityCalendarEventPostModel? */ set Event(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734192499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17180140915)
            
            //--TRIMMABLE-BOUNDARY-START(115964388723)
            /*CommunityCalendarEventSessionPostModel? */ get Session()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194584947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociation$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, null);
            }
            /*CommunityCalendarEventSessionPostModel? */ set Session(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683865459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociation($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(115964388723)
            
            //--TRIMMABLE-BOUNDARY-START(111669421427)
            /*IEnumerable<KeyValuePair<string, int>>? */ get Seats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604650355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), "Seats");
            }
            /*IEnumerable<KeyValuePair<string, int>>? */ set Seats(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093930867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), value, "Seats");
            }
            //--TRIMMABLE-BOUNDARY-END(111669421427)
            
            //--TRIMMABLE-BOUNDARY-START(4295239027)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295239027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295239027)
            
            //--TRIMMABLE-BOUNDARY-START(4295239027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295239027)
            
            static $h = 271731;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(188978832755),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784519539,
        "f": 50364417
      },
      "n": "Type",
      "d": 271731,
      "h": 188978832755,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188978832755),
//--TRIMMABLE-BOUNDARY-START(21475108211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834846579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324127091,
        "f": 83886081
      },
      "n": "FirstName",
      "d": 271731,
      "h": 21475108211,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475108211),
//--TRIMMABLE-BOUNDARY-START(103079486835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424781171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914061683,
        "f": 83886081
      },
      "n": "LastName",
      "d": 271731,
      "h": 103079486835,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079486835),
//--TRIMMABLE-BOUNDARY-START(12885173619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654977395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144257907,
        "f": 83886081
      },
      "n": "Email",
      "d": 271731,
      "h": 12885173619,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 1245223,
          "c": 4296212519
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885173619),
//--TRIMMABLE-BOUNDARY-START(107374454131),
    {
      "p": 32409942,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014715763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167503996275,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 271731,
      "h": 107374454131,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374454131),
//--TRIMMABLE-BOUNDARY-START(8590206323),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065042803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554323315,
        "f": 83886081
      },
      "n": "AmountPaid",
      "d": 271731,
      "h": 8590206323,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590206323),
//--TRIMMABLE-BOUNDARY-START(17180140915),
    {
      "p": 1320307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244911987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734192499,
        "f": 83886081
      },
      "n": "Event",
      "d": 271731,
      "h": 17180140915,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180140915),
//--TRIMMABLE-BOUNDARY-START(115964388723),
    {
      "p": 2106739,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194584947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184683865459,
        "f": 83886081
      },
      "n": "Session",
      "d": 271731,
      "h": 115964388723,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964388723),
//--TRIMMABLE-BOUNDARY-START(111669421427),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604650355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176093930867,
        "f": 83886081
      },
      "n": "Seats",
      "d": 271731,
      "h": 111669421427,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669421427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295239027),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 271731,
      "h": 4295239027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295239027)
  ],
  "h": 271731
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventBookingModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(271731)
        
        

        //--TRIMMABLE-BOUNDARY-START(2368883)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel`, ($self) => class CommunityCalendarEventSpeakerModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21477205363)
            /*PostTypes */ get Type()
            {
                return 5637/*PostTypes.CalendarEventSpeaker*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21477205363)
            
            //--TRIMMABLE-BOUNDARY-START(17182238067)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182238067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Name", "Speaker Name", "", null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Summary", "Role", "", null, null, null);
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "About", "About this speaker", null, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(17182238067)
            
            //--TRIMMABLE-BOUNDARY-START(25772172659)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772172659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = super.UpdateDescriptors(descriptors, $.$clone(schema));
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "PostFlags" ], null, null));
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(25772172659)
            
            //--TRIMMABLE-BOUNDARY-START(4297336179)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297336179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297336179)
            
            //--TRIMMABLE-BOUNDARY-START(4297336179)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297336179)
            
            static $h = 2368883;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477205363),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887270771,
        "f": 50364417
      },
      "n": "Type",
      "d": 2368883,
      "h": 21477205363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21477205363)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182238067),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 2368883,
      "h": 17182238067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182238067),
//--TRIMMABLE-BOUNDARY-START(25772172659),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 2368883,
      "h": 25772172659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772172659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297336179),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2368883,
      "h": 4297336179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297336179)
  ],
  "h": 2368883
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSpeakerModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2368883)
        
        

        //--TRIMMABLE-BOUNDARY-START(2106739)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel`, ($self) => class CommunityCalendarEventSessionPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(197570602355)
            /*PostTypes */ get Type()
            {
                return 5636/*PostTypes.CalendarEventSession*/;
            }
            //--TRIMMABLE-BOUNDARY-END(197570602355)
            
            //--TRIMMABLE-BOUNDARY-START(107376289139)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376289139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376289139)
            
            //--TRIMMABLE-BOUNDARY-START(103081321843)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081321843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081321843)
            
            //--TRIMMABLE-BOUNDARY-START(188980667763)
            /*DateOnly */ get StartDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606485363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.DateOnly, new $.$$.S.DateOnly(), "StartDate", null);
            }
            /*DateOnly */ set StartDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800798579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.DateOnly, value, "StartDate");
            }
            //--TRIMMABLE-BOUNDARY-END(188980667763)
            
            //--TRIMMABLE-BOUNDARY-START(193275635059)
            /*TimeOnly */ get StartTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196419955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.TimeOnly, new $.$$.S.TimeOnly(), "StartTime", null);
            }
            /*TimeOnly */ set StartTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390733171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.TimeOnly, value, "StartTime");
            }
            //--TRIMMABLE-BOUNDARY-END(193275635059)
            
            //--TRIMMABLE-BOUNDARY-START(21476943219)
            /*int */ get Duration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836681587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Duration", null);
            }
            /*int */ set Duration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030994803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Duration");
            }
            //--TRIMMABLE-BOUNDARY-END(21476943219)
            
            //--TRIMMABLE-BOUNDARY-START(17181975923)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246746995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Capacity", null);
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441060211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Capacity");
            }
            //--TRIMMABLE-BOUNDARY-END(17181975923)
            
            //--TRIMMABLE-BOUNDARY-START(8592041331)
            /*Money */ get Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066877811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money(), "Amount", null);
            }
            /*Money */ set Amount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261191027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "Amount");
            }
            //--TRIMMABLE-BOUNDARY-END(8592041331)
            
            //--TRIMMABLE-BOUNDARY-START(184685700467)
            /*IEnumerable<CommunityCalendarEventSpeakerModel>? */ get Speakers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016550771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, null);
            }
            /*IEnumerable<CommunityCalendarEventSpeakerModel>? */ set Speakers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210863987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(184685700467)
            
            //--TRIMMABLE-BOUNDARY-START(111671256435)
            /*IEnumerable<CommunityCalendarEventSeatTypeModel>? */ get SeatTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426616179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, null);
            }
            /*IEnumerable<CommunityCalendarEventSeatTypeModel>? */ set SeatTypes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620929395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(111671256435)
            
            //--TRIMMABLE-BOUNDARY-START(12887008627)
            /*IEnumerable<CommunityCalendarEventBookingModel>? */ get Bookings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656812403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, null);
            }
            /*IEnumerable<CommunityCalendarEventBookingModel>? */ set Bookings(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851125619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(12887008627)
            
            //--TRIMMABLE-BOUNDARY-START(201865569651)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865569651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = super.UpdateDescriptors(descriptors, $.$clone(schema));
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "PostFlags" ], null, null));
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(201865569651)
            
            //--TRIMMABLE-BOUNDARY-START(4297074035)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297074035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297074035)
            
            //--TRIMMABLE-BOUNDARY-START(4297074035)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297074035)
            
            static $h = 2106739;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197570602355),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786354547,
        "f": 50364417
      },
      "n": "Type",
      "d": 2106739,
      "h": 197570602355,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197570602355),
//--TRIMMABLE-BOUNDARY-START(188980667763),
    {
      "p": 65929217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606485363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800798579,
        "f": 83886081
      },
      "n": "StartDate",
      "d": 2106739,
      "h": 188980667763,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980667763),
//--TRIMMABLE-BOUNDARY-START(193275635059),
    {
      "p": 186318849,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196419955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390733171,
        "f": 83886081
      },
      "n": "StartTime",
      "d": 2106739,
      "h": 193275635059,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193275635059),
//--TRIMMABLE-BOUNDARY-START(21476943219),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836681587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030994803,
        "f": 83886081
      },
      "n": "Duration",
      "d": 2106739,
      "h": 21476943219,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "In minutes",
              "t": 1310721
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476943219),
//--TRIMMABLE-BOUNDARY-START(17181975923),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246746995,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441060211,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 2106739,
      "h": 17181975923,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1027,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "How many attendee can this event take, zero for no limit",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Head"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181975923),
//--TRIMMABLE-BOUNDARY-START(8592041331),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066877811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261191027,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2106739,
      "h": 8592041331,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1028,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "How much will it cost to attend this event, 0 for free",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Head"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592041331),
//--TRIMMABLE-BOUNDARY-START(184685700467),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016550771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210863987,
        "f": 83886081
      },
      "n": "Speakers",
      "d": 2106739,
      "h": 184685700467,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685700467),
//--TRIMMABLE-BOUNDARY-START(111671256435),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426616179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620929395,
        "f": 83886081
      },
      "n": "SeatTypes",
      "d": 2106739,
      "h": 111671256435,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111671256435),
//--TRIMMABLE-BOUNDARY-START(12887008627),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656812403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851125619,
        "f": 83886081
      },
      "n": "Bookings",
      "d": 2106739,
      "h": 12887008627,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887008627)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107376289139),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 2106739,
      "h": 107376289139,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376289139),
//--TRIMMABLE-BOUNDARY-START(103081321843),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 2106739,
      "h": 103081321843,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081321843),
//--TRIMMABLE-BOUNDARY-START(201865569651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 2106739,
      "h": 201865569651,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201865569651)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297074035),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2106739,
      "h": 4297074035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297074035)
  ],
  "h": 2106739
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSessionPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2106739)
        
        

        //--TRIMMABLE-BOUNDARY-START(1058163)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventMaterialModel`, ($self) => class CommunityCalendarEventMaterialModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180927347)
            /*PostTypes */ get Type()
            {
                return 5638/*PostTypes.CalendarEventMaterial*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180927347)
            
            //--TRIMMABLE-BOUNDARY-START(21475894643)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475894643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                descriptors = super.UpdateDescriptors(descriptors, $.$clone(schema));
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$LCOv.LCFCPM$1.PostBaseModel.Exclude(descriptors, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "PostFlags" ], null, null));
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(21475894643)
            
            //--TRIMMABLE-BOUNDARY-START(4296025459)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296025459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296025459)
            
            //--TRIMMABLE-BOUNDARY-START(4296025459)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296025459)
            
            static $h = 1058163;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180927347),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885960051,
        "f": 50364417
      },
      "n": "Type",
      "d": 1058163,
      "h": 17180927347,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180927347)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475894643),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 1058163,
      "h": 21475894643,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475894643)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296025459),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1058163,
      "h": 4296025459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296025459)
  ],
  "h": 1058163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventMaterialModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1058163)
        
        

        //--TRIMMABLE-BOUNDARY-START(1189235)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor`, ($self) => class CommunityCalendarEventMaterialModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296156531)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296156531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, this, factory);
                    }, $RVKPWk ??= {"r":65537,"n":"","d":1189235,"h":0,"f":17825794}), 0, "CommunityCalendarEventMaterialModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventMaterialModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventMaterialModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296156531)
            
            //--TRIMMABLE-BOUNDARY-START(12886091123)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886091123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel)).Type);
                        }, $FwzEJj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1189235,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886091123)
            
            //--TRIMMABLE-BOUNDARY-START(17181058419)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181058419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181058419)
            
            //--TRIMMABLE-BOUNDARY-START(8591123827)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591123827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591123827)
            
            static $h = 1189235;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886091123),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1189235,
      "h": 12886091123,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886091123),
//--TRIMMABLE-BOUNDARY-START(17181058419),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1058163,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1189235,
      "h": 17181058419,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181058419),
//--TRIMMABLE-BOUNDARY-START(8591123827),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1058163,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1189235,
      "h": 8591123827,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591123827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296156531),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1189235,
      "h": 4296156531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296156531)
  ],
  "h": 1189235
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventMaterialModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventMaterialModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventMaterialModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1189235)
        
        

        //--TRIMMABLE-BOUNDARY-START(1975667)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor`, ($self) => class CommunityCalendarEventSeatTypeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296942963)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296942963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, this, factory);
                    }, $psFxSe ??= {"r":65537,"n":"","d":1975667,"h":0,"f":17825794}), 0, "CommunityCalendarEventSeatTypeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventSeatTypeModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventSeatTypeModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296942963)
            
            //--TRIMMABLE-BOUNDARY-START(12886877555)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886877555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)).Type);
                        }, $eAcOYb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1975667,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Capacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, $.$discardRef(), "Capacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Capacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Capacity";
                        $i3.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)).Capacity);
                        }, $EFeIBc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1975667,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Capacity = value.AsInt();
                        }, $dsKXQd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1975667,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Amount";
                        $i5.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)).Amount);
                        }, $cUFLRa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1975667,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $uikjRf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1975667,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Event";
                        $i7.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)).Event);
                        }, $kcmWwb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1975667,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsReference($.$OnVo.LCCCCM.CommunityCalendarEventPostModel);
                        }, $hpVwUe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1975667,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Session"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel.$type, $.$discardRef(), "Session", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Session")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Session";
                        $i9.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)).Session);
                        }, $qVexoe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1975667,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Session = value.AsReference($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel);
                        }, $HCrSxk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1975667,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886877555)
            
            //--TRIMMABLE-BOUNDARY-START(17181844851)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181844851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Capacity = _target.Capacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Capacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Capacity, ($v) => _Capacity = $v, $.$$.S.Int32)))
                    {
                        _target.Capacity = _Capacity;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Amount, ($v) => _Amount = $v, null, true)))
                    {
                        _target.Amount = $.$clone(_Amount);
                    }
                }
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Event, ($v) => _Event = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)))
                    {
                        _target.Event = _Event;
                    }
                }
                {
                    /*var*/ let _Session = _target.Session;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Session"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Session, ($v) => _Session = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)))
                    {
                        _target.Session = _Session;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181844851)
            
            //--TRIMMABLE-BOUNDARY-START(8591910259)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591910259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591910259)
            
            static $h = 1975667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886877555),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1975667,
      "h": 12886877555,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886877555),
//--TRIMMABLE-BOUNDARY-START(17181844851),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1844595,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1975667,
      "h": 17181844851,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181844851),
//--TRIMMABLE-BOUNDARY-START(8591910259),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1844595,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1975667,
      "h": 8591910259,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591910259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296942963),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1975667,
      "h": 4296942963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296942963)
  ],
  "h": 1975667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSeatTypeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSeatTypeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1975667)
        
        

        //--TRIMMABLE-BOUNDARY-START(2499955)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor`, ($self) => class CommunityCalendarEventSpeakerModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297467251)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297467251);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, this, factory);
                    }, $BfkAoc ??= {"r":65537,"n":"","d":2499955,"h":0,"f":17825794}), 0, "CommunityCalendarEventSpeakerModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventSpeakerModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventSpeakerModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297467251)
            
            //--TRIMMABLE-BOUNDARY-START(12887401843)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887401843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)).Type);
                        }, $hjrabk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2499955,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887401843)
            
            //--TRIMMABLE-BOUNDARY-START(17182369139)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182369139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182369139)
            
            //--TRIMMABLE-BOUNDARY-START(8592434547)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592434547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592434547)
            
            static $h = 2499955;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887401843),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2499955,
      "h": 12887401843,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887401843),
//--TRIMMABLE-BOUNDARY-START(17182369139),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2368883,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2499955,
      "h": 17182369139,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182369139),
//--TRIMMABLE-BOUNDARY-START(8592434547),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2368883,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2499955,
      "h": 8592434547,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592434547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297467251),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2499955,
      "h": 4297467251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297467251)
  ],
  "h": 2499955
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSpeakerModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSpeakerModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2499955)
        
        

        //--TRIMMABLE-BOUNDARY-START(2237811)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor`, ($self) => class CommunityCalendarEventSessionPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297205107)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297205107);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, this, factory);
                    }, $eNwKba ??= {"r":65537,"n":"","d":2237811,"h":0,"f":17825794}), 0, "CommunityCalendarEventSessionPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventSessionPostModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventSessionPostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297205107)
            
            //--TRIMMABLE-BOUNDARY-START(12887139699)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887139699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "StartDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "StartDate";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$3(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).StartDate);
                        }, $Gmgzok ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartDate = value.AsDateOnly();
                        }, $vyfKmi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "StartTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "StartTime";
                        $i3.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$10(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).StartTime);
                        }, $onCVZj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartTime = value.AsTimeOnly();
                        }, $EtGiAh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Duration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Duration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Duration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Duration";
                        $i5.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Duration);
                        }, $jaWuFh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Duration = value.AsInt();
                        }, $ItSkAj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Capacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Capacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Capacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Capacity";
                        $i7.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Capacity);
                        }, $twSPig ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Capacity = value.AsInt();
                        }, $eAiznj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Amount";
                        $i9.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Amount);
                        }, $QiZpKd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $qPObCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Type";
                        $i11.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Type);
                        }, $tIrXjc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Speakers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Speakers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Speakers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Speakers";
                        $i13.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Speakers);
                        }, $MDWbXh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Speakers = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                        }, $mBUMqi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SeatTypes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "SeatTypes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SeatTypes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "SeatTypes";
                        $i15.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).SeatTypes);
                        }, $ZAozja ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SeatTypes = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                        }, $BATxLb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bookings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel.$type, $.$discardRef(), "Bookings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bookings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Bookings";
                        $i17.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)).Bookings);
                        }, $mFbbKc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2237811,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Bookings = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                        }, $CXjlVh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2237811,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887139699)
            
            //--TRIMMABLE-BOUNDARY-START(17182106995)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182106995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _StartDate = _target.StartDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateOnly, () => _StartDate, ($v) => _StartDate = $v, null, true)))
                    {
                        _target.StartDate = _StartDate;
                    }
                }
                {
                    /*var*/ let _StartTime = _target.StartTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeOnly, () => _StartTime, ($v) => _StartTime = $v, null, true)))
                    {
                        _target.StartTime = _StartTime;
                    }
                }
                {
                    /*var*/ let _Duration = _target.Duration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Duration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Duration, ($v) => _Duration = $v, $.$$.S.Int32)))
                    {
                        _target.Duration = _Duration;
                    }
                }
                {
                    /*var*/ let _Capacity = _target.Capacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Capacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Capacity, ($v) => _Capacity = $v, $.$$.S.Int32)))
                    {
                        _target.Capacity = _Capacity;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Amount, ($v) => _Amount = $v, null, true)))
                    {
                        _target.Amount = $.$clone(_Amount);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Speakers = _target.Speakers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Speakers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, property, $.$ref(() => _Speakers, ($v) => _Speakers = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))
                    {
                        _target.Speakers = _Speakers;
                        if (_Speakers !== null)
                        {
                            let $en32 = _Speakers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en32.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en32.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, property, $.$ref(() => _Speakers, ($v) => _Speakers = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)));
                    }
                }
                {
                    /*var*/ let _SeatTypes = _target.SeatTypes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SeatTypes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, property, $.$ref(() => _SeatTypes, ($v) => _SeatTypes = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel))))
                    {
                        _target.SeatTypes = _SeatTypes;
                        if (_SeatTypes !== null)
                        {
                            let $en37 = _SeatTypes.SCG$IEnumerable$$$GetEnumerator();
                            while ($en37.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en37.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, property, $.$ref(() => _SeatTypes, ($v) => _SeatTypes = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)));
                    }
                }
                {
                    /*var*/ let _Bookings = _target.Bookings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bookings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, property, $.$ref(() => _Bookings, ($v) => _Bookings = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel))))
                    {
                        _target.Bookings = _Bookings;
                        if (_Bookings !== null)
                        {
                            let $en42 = _Bookings.SCG$IEnumerable$$$GetEnumerator();
                            while ($en42.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en42.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, property, $.$ref(() => _Bookings, ($v) => _Bookings = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182106995)
            
            //--TRIMMABLE-BOUNDARY-START(8592172403)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592172403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592172403)
            
            static $h = 2237811;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887139699),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2237811,
      "h": 12887139699,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887139699),
//--TRIMMABLE-BOUNDARY-START(17182106995),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2106739,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2237811,
      "h": 17182106995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182106995),
//--TRIMMABLE-BOUNDARY-START(8592172403),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2106739,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2237811,
      "h": 8592172403,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592172403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297205107),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2237811,
      "h": 4297205107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297205107)
  ],
  "h": 2237811
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventSessionPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventSessionPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2237811)
        
        

        //--TRIMMABLE-BOUNDARY-START(402803)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor`, ($self) => class CommunityCalendarEventBookingModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295370099)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295370099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, this, factory);
                    }, $fhLKGb ??= {"r":65537,"n":"","d":402803,"h":0,"f":17825794}), 0, "CommunityCalendarEventBookingModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventBookingModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventBookingModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295370099)
            
            //--TRIMMABLE-BOUNDARY-START(12885304691)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885304691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).Type);
                        }, $LXpgjh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FirstName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "FirstName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FirstName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "FirstName";
                        $i3.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).FirstName);
                        }, $EefOMg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FirstName = value.AsReference($.$$.S.String);
                        }, $mMUmZf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "LastName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "LastName";
                        $i5.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).LastName);
                        }, $lMriOc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastName = value.AsReference($.$$.S.String);
                        }, $QSZpBd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Email"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "Email", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Email")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Email";
                        $i7.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).Email);
                        }, $rfmwig ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Email = value.AsReference($.$$.S.String);
                        }, $SUuJWf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.PhoneNumber, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "PhoneNumber";
                        $i9.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.PhoneNumber, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).PhoneNumber);
                        }, $usmYFc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsValue($.$fPer.LCFCD.PhoneNumber);
                        }, $XflRKe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AmountPaid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "AmountPaid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AmountPaid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "AmountPaid";
                        $i11.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).AmountPaid);
                        }, $RbYqzc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AmountPaid = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $xwPaDa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Event";
                        $i13.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).Event);
                        }, $KAlCHe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsReference($.$OnVo.LCCCCM.CommunityCalendarEventPostModel);
                        }, $GiqXie ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Session"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "Session", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Session")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Session";
                        $i15.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).Session);
                        }, $HZdLTa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Session = value.AsReference($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel);
                        }, $zMsIGg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Seats"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel.$type, $.$discardRef(), "Seats", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Seats")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Seats";
                        $i17.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)).Seats);
                        }, $RhjMIi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":402803,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Seats = value.AsReference($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)));
                        }, $VLQOTi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":402803,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885304691)
            
            //--TRIMMABLE-BOUNDARY-START(17180271987)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180271987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _FirstName = _target.FirstName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FirstName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FirstName, ($v) => _FirstName = $v, $.$$.S.String)))
                    {
                        _target.FirstName = _FirstName;
                    }
                }
                {
                    /*var*/ let _LastName = _target.LastName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LastName, ($v) => _LastName = $v, $.$$.S.String)))
                    {
                        _target.LastName = _LastName;
                    }
                }
                {
                    /*var*/ let _Email = _target.Email;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Email"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Email, ($v) => _Email = $v, $.$$.S.String)))
                    {
                        _target.Email = _Email;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.PhoneNumber));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.PhoneNumber, () => _PhoneNumber, ($v) => _PhoneNumber = $v, null, true)))
                    {
                        _target.PhoneNumber = $.$clone(_PhoneNumber);
                    }
                }
                {
                    /*var*/ let _AmountPaid = _target.AmountPaid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AmountPaid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _AmountPaid, ($v) => _AmountPaid = $v, null, true)))
                    {
                        _target.AmountPaid = $.$clone(_AmountPaid);
                    }
                }
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Event, ($v) => _Event = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)))
                    {
                        _target.Event = _Event;
                    }
                }
                {
                    /*var*/ let _Session = _target.Session;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Session"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Session, ($v) => _Session = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)))
                    {
                        _target.Session = _Session;
                    }
                }
                {
                    /*var*/ let _Seats = _target.Seats;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Seats"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32))));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), property, $.$ref(() => _Seats, ($v) => _Seats = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)))))
                    {
                        _target.Seats = _Seats;
                        if (_Seats !== null)
                        {
                            let $en35 = _Seats.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en35.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32), property, $.$ref(() => _Seats, ($v) => _Seats = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Int32))));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180271987)
            
            //--TRIMMABLE-BOUNDARY-START(8590337395)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590337395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventBookingModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590337395)
            
            static $h = 402803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885304691),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 402803,
      "h": 12885304691,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885304691),
//--TRIMMABLE-BOUNDARY-START(17180271987),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 271731,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 402803,
      "h": 17180271987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180271987),
//--TRIMMABLE-BOUNDARY-START(8590337395),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 271731,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 402803,
      "h": 8590337395,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590337395)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295370099),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 402803,
      "h": 4295370099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295370099)
  ],
  "h": 402803
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventBookingModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventBookingModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(402803)
        
        

        $asm.$typeProxy("$OnVo.LCCCCM.CommunityCalendarEventPostModel", "$OnVo.LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel");
        //--TRIMMABLE-BOUNDARY-START(533875)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventCategoryModel`, ($self) => class CommunityCalendarEventCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180403059)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 5639/*PostTypes.CalendarEventCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180403059)
            
            //--TRIMMABLE-BOUNDARY-START(4295501171)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295501171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295501171)
            
            //--TRIMMABLE-BOUNDARY-START(4295501171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295501171)
            
            static $h = 533875;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180403059),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885435763,
        "f": 50364417
      },
      "n": "Type",
      "d": 533875,
      "h": 17180403059,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180403059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295501171),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 533875,
      "h": 4295501171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295501171)
  ],
  "h": 533875
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(533875)
        
        

        //--TRIMMABLE-BOUNDARY-START(1320307)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventPostModel`, ($self) => class CommunityCalendarEventPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(300649031027)
            /*PostTypes? */ get SetType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670470003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType;
            }
            /*PostTypes? */ set SetType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584259955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(300649031027)
            
            //--TRIMMABLE-BOUNDARY-START(326418834803)
            /*PostTypes */ get Type()
            {
                return this.SetType ?? 5632/*PostTypes.Calendar*/;
            }
            //--TRIMMABLE-BOUNDARY-END(326418834803)
            
            //--TRIMMABLE-BOUNDARY-START(176094979443)
            /*IEnumerable<ResourceModel>? */ get Resources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720797043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Resources;
            }
            /*IEnumerable<ResourceModel>? */ set Resources(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224521587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.Resources = value;
            }
            //--TRIMMABLE-BOUNDARY-END(176094979443)
            
            //--TRIMMABLE-BOUNDARY-START(17181189491)
            /*CommunityCalendarEventType */ get EventType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950993267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$OnVo.LCCCCM.CommunityCalendarEventType, 0, "EventType", null);
            }
            /*CommunityCalendarEventType */ set EventType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044652403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$OnVo.LCCCCM.CommunityCalendarEventType, value, "EventType");
            }
            //--TRIMMABLE-BOUNDARY-END(17181189491)
            
            //--TRIMMABLE-BOUNDARY-START(317828900211)
            /*DateOnly */ get StartDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850339187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.DateOnly, new $.$$.S.DateOnly(), "StartDate", null);
            }
            /*DateOnly */ set StartDate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764129139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.DateOnly, value, "StartDate");
            }
            //--TRIMMABLE-BOUNDARY-END(317828900211)
            
            //--TRIMMABLE-BOUNDARY-START(322123867507)
            /*TimeOnly */ get StartTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440273779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.TimeOnly, new $.$$.S.TimeOnly(), "StartTime", null);
            }
            /*TimeOnly */ set StartTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354063731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.TimeOnly, value, "StartTime");
            }
            //--TRIMMABLE-BOUNDARY-END(322123867507)
            
            //--TRIMMABLE-BOUNDARY-START(163210077555)
            /*CommunityCalendarEventRecurrence */ get Recurrence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130862451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, new $.$OnVo.LCCCCM.CommunityCalendarEventRecurrence(), "Recurrence", null);
            }
            /*CommunityCalendarEventRecurrence */ set Recurrence(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634586995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, $.$clone(value), "Recurrence");
            }
            //--TRIMMABLE-BOUNDARY-END(163210077555)
            
            //--TRIMMABLE-BOUNDARY-START(12886222195)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361058675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, 0, "Capacity", null);
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454717811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Capacity");
            }
            //--TRIMMABLE-BOUNDARY-END(12886222195)
            
            //--TRIMMABLE-BOUNDARY-START(8591254899)
            /*Money */ get Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771124083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, new $.$fPer.LCFCDM.Money(), "Amount", null);
            }
            /*Money */ set Amount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864783219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "Amount");
            }
            //--TRIMMABLE-BOUNDARY-END(8591254899)
            
            //--TRIMMABLE-BOUNDARY-START(193274848627)
            /*IEnumerable<CommunityCalendarEventSessionPostModel>? */ get Sessions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080535411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, null);
            }
            /*IEnumerable<CommunityCalendarEventSessionPostModel>? */ set Sessions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994325363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(193274848627)
            
            //--TRIMMABLE-BOUNDARY-START(313533932915)
            /*IEnumerable<CommunityCalendarEventSpeakerModel>? */ get Speakers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260404595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, null);
            }
            /*IEnumerable<CommunityCalendarEventSpeakerModel>? */ set Speakers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174194547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(313533932915)
            
            //--TRIMMABLE-BOUNDARY-START(188979881331)
            /*IEnumerable<CommunityCalendarEventSeatTypeModel>? */ get SeatTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490600819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, null);
            }
            /*IEnumerable<CommunityCalendarEventSeatTypeModel>? */ set SeatTypes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404390771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(188979881331)
            
            //--TRIMMABLE-BOUNDARY-START(184684914035)
            /*IEnumerable<CommunityCalendarEventBookingModel>? */ get SeatBookings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900666227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAssociations$1($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, null);
            }
            /*IEnumerable<CommunityCalendarEventBookingModel>? */ set SeatBookings(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814456179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAssociations($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, value, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(184684914035)
            
            //--TRIMMABLE-BOUNDARY-START(180389946739)
            /*DateOnly? */ get ScheduledDate()
            {
                return this.StartDate;
            }
            //--TRIMMABLE-BOUNDARY-END(180389946739)
            
            //--TRIMMABLE-BOUNDARY-START(150325175667)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$1(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Calendar", "Event"], null, null), null, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(150325175667)
            
            //--TRIMMABLE-BOUNDARY-START(158915110259)
            /*bool */ OccursOn(/*DateOnly*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915110259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Type === 5633/*PostTypes.CalendarEventOnce*/)
                {
                    return $.$$.S.DateOnly.op_Equality(this.StartDate, date);
                }
                else if (this.Type === 5634/*PostTypes.CalendarEventRecurring*/)
                {
                    let $switch1 = this.Recurrence.Recurrence;
                    switch($switch1)
                    {
                        case 0/*CommunityCalendarEventRecurrenceType.Daily*/:
                        return true;
                        case 1/*CommunityCalendarEventRecurrenceType.Weekly*/:
                        return date.DayOfWeek === this.Recurrence.WeekDay;
                        case 2/*CommunityCalendarEventRecurrenceType.Monthly*/:
                        return date.Day === this.Recurrence.Date;
                        case 3/*CommunityCalendarEventRecurrenceType.WeekMonthly*/:
                        if (date.DayOfWeek === this.Recurrence.WeekDay)
                        {
                            /*int*/ let weekOfMonth = 1;
                            /*int*/ let weeksInThisMonth = 4;
                            if (this.Recurrence.Week < 5/*CommunityCalendarEventWeekOfMonth.LastWeek*/)
                            {
                                return this.Recurrence.Week === weekOfMonth;
                            }
                            else if (this.Recurrence.Week === 5/*CommunityCalendarEventWeekOfMonth.LastWeek*/)
                            {
                                return weeksInThisMonth === weekOfMonth;
                            }
                        }
                        return false;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(158915110259)
            
            //--TRIMMABLE-BOUNDARY-START(304943998323)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304943998323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943998323)
            
            //--TRIMMABLE-BOUNDARY-START(167505044851)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505044851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505044851)
            
            //--TRIMMABLE-BOUNDARY-START(309238965619)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309238965619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309238965619)
            
            //--TRIMMABLE-BOUNDARY-START(171800012147)
            /*bool */ RequiresTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800012147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800012147)
            
            //--TRIMMABLE-BOUNDARY-START(154620142963)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620142963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", null, `About this event`, null, null, null);
                }
                super.ModifyDescriptor(propertyBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(154620142963)
            
            //--TRIMMABLE-BOUNDARY-START(8593533364)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSchedulable.ScheduledDate.get
            get LCFCP$IPostSchedulable$ScheduledDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888500660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ScheduledDate;
            }
            //--TRIMMABLE-BOUNDARY-END(8593533364)
            
            //--TRIMMABLE-BOUNDARY-START(8594319796)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostViewTrackable.ViewsCount.get
            get LCFCP$IPostViewTrackable$ViewsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889287092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewsCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8594319796)
            
            //--TRIMMABLE-BOUNDARY-START(8593992116)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostSubscribable.SubscribersCount.get
            get LCFCP$IPostSubscribable$SubscribersCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888959412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SubscribersCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593992116)
            
            //--TRIMMABLE-BOUNDARY-START(8593009076)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReactable.Reactions.get
            get LCFCP$IPostReactable$Reactions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887976372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reactions;
            }
            //--TRIMMABLE-BOUNDARY-END(8593009076)
            
            //--TRIMMABLE-BOUNDARY-START(8593271220)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesCount.get
            get LCFCP$IPostReplyable$RepliesCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478173108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(8593271220)
            
            //--TRIMMABLE-BOUNDARY-START(17183205812)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostReplyable.RepliesDepth.get
            get LCFCP$IPostReplyable$RepliesDepth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773140404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RepliesDepth;
            }
            //--TRIMMABLE-BOUNDARY-END(17183205812)
            
            //--TRIMMABLE-BOUNDARY-START(4296287603)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296287603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296287603)
            
            //--TRIMMABLE-BOUNDARY-START(4296287603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296287603)
            
            static $h = 1320307;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(300649031027),
    {
      "p": $.$typeNullable($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670470003,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584259955,
        "f": 83918849
      },
      "n": "SetType",
      "d": 1320307,
      "h": 300649031027,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "Order",
              "v": -2147483648,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "Tell us the type of calendar you are creating",
              "t": 1310721
            },
            {
              "n": "InputType",
              "v": 41,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-calendar"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "OptionsReader",
              "v": 2762099,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(300649031027),
//--TRIMMABLE-BOUNDARY-START(326418834803),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030208371,
        "f": 50364417
      },
      "n": "Type",
      "d": 1320307,
      "h": 326418834803,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(326418834803),
//--TRIMMABLE-BOUNDARY-START(176094979443),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720797043,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224521587,
        "f": 83918849
      },
      "n": "Resources",
      "d": 1320307,
      "h": 176094979443,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "Order",
              "v": 1023,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "//Icon=AudioVideo"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            },
            {
              "n": "Description",
              "v": "Upload more banners",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094979443),
//--TRIMMABLE-BOUNDARY-START(17181189491),
    {
      "p": 2631027,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950993267,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044652403,
        "f": 83886081
      },
      "n": "EventType",
      "d": 1320307,
      "h": 17181189491,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "Type of event",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=CalendarHeart"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181189491),
//--TRIMMABLE-BOUNDARY-START(317828900211),
    {
      "p": 65929217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850339187,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764129139,
        "f": 83886081
      },
      "n": "StartDate",
      "d": 1320307,
      "h": 317828900211,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "Date and time event commences",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=CalendarStart"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(317828900211),
//--TRIMMABLE-BOUNDARY-START(322123867507),
    {
      "p": 186318849,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440273779,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354063731,
        "f": 83886081
      },
      "n": "StartTime",
      "d": 1320307,
      "h": 322123867507,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "Date and time event commences",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=CalendarStart"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(322123867507),
//--TRIMMABLE-BOUNDARY-START(163210077555),
    {
      "p": 1582451,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130862451,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634586995,
        "f": 83886081
      },
      "n": "Recurrence",
      "d": 1320307,
      "h": 163210077555,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1026,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "How will this event recur/repeat",
              "t": 1310721
            },
            {
              "n": "ExcludeFilter",
              "v": 3351923,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Repeat",
                "//DependsOn=EventType"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210077555),
//--TRIMMABLE-BOUNDARY-START(12886222195),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361058675,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454717811,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 1320307,
      "h": 12886222195,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1027,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "How many attendee can this event take, zero for no limit",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Head"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886222195),
//--TRIMMABLE-BOUNDARY-START(8591254899),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771124083,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864783219,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1320307,
      "h": 8591254899,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1028,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "Description",
              "v": "How much will it cost to attend this event, 0 for free",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=Head"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591254899),
//--TRIMMABLE-BOUNDARY-START(193274848627),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080535411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994325363,
        "f": 83886081
      },
      "n": "Sessions",
      "d": 1320307,
      "h": 193274848627,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274848627),
//--TRIMMABLE-BOUNDARY-START(313533932915),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260404595,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279174194547,
        "f": 83886081
      },
      "n": "Speakers",
      "d": 1320307,
      "h": 313533932915,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(313533932915),
//--TRIMMABLE-BOUNDARY-START(188979881331),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490600819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404390771,
        "f": 83886081
      },
      "n": "SeatTypes",
      "d": 1320307,
      "h": 188979881331,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979881331),
//--TRIMMABLE-BOUNDARY-START(184684914035),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900666227,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814456179,
        "f": 83886081
      },
      "n": "SeatBookings",
      "d": 1320307,
      "h": 184684914035,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684914035),
//--TRIMMABLE-BOUNDARY-START(180389946739),
    {
      "p": $.$typeNullable($.$$.S.DateOnly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310731635,
        "f": 50331649
      },
      "n": "ScheduledDate",
      "d": 1320307,
      "h": 180389946739,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389946739),
//--TRIMMABLE-BOUNDARY-START(150325175667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540927859,
        "f": 50364417
      },
      "n": "Link",
      "d": 1320307,
      "h": 150325175667,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325175667)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158915110259),
    {
      "r": 262145,
      "p": [
        {
          "n": "date",
          "p": 65929217
        }
      ],
      "n": "OccursOn",
      "d": 1320307,
      "h": 158915110259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915110259),
//--TRIMMABLE-BOUNDARY-START(304943998323),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 1320307,
      "h": 304943998323,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304943998323),
//--TRIMMABLE-BOUNDARY-START(167505044851),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1320307,
      "h": 167505044851,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167505044851),
//--TRIMMABLE-BOUNDARY-START(309238965619),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 1320307,
      "h": 309238965619,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238965619),
//--TRIMMABLE-BOUNDARY-START(171800012147),
    {
      "r": 262145,
      "n": "RequiresTags",
      "d": 1320307,
      "h": 171800012147,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800012147),
//--TRIMMABLE-BOUNDARY-START(154620142963),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 1320307,
      "h": 154620142963,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620142963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296287603),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1320307,
      "h": 4296287603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296287603)
  ],
  "h": 1320307
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostSchedulable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostReplyable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1320307)
        
        

        //--TRIMMABLE-BOUNDARY-START(3482995)
        $asm.$cls(`$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService`, ($self) => class ICommunityCalendarFeedRemoteService
        {
            static $h = 3482995;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3482995,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Services.ICommunityCalendarFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Services${separator}ICommunityCalendarFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3482995)
        
        

        //--TRIMMABLE-BOUNDARY-START(3614067)
        $asm.$cls(`$OnVo.LCCCCS.IComunityCalendarRemoteService`, ($self) => class IComunityCalendarRemoteService
        {
            static $h = 3614067;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3614067,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Services.IComunityCalendarRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Services${separator}IComunityCalendarRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3614067)
        
        

        //--TRIMMABLE-BOUNDARY-START(796019)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventEditionModel`, ($self) => class CommunityCalendarEventEditionModel extends $.$OnVo.LCCCCM.CommunityCalendarEventPostModel
        {
            //--TRIMMABLE-BOUNDARY-START(17180665203)
            /*PostTypes */ get Type()
            {
                return 5635/*PostTypes.CalendarEventEdition*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180665203)
            
            //--TRIMMABLE-BOUNDARY-START(4295763315)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295763315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295763315)
            
            //--TRIMMABLE-BOUNDARY-START(4295763315)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295763315)
            
            static $h = 796019;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$OnVo.LCCCCM.CommunityCalendarEventPostModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180665203),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885697907,
        "f": 50364417
      },
      "n": "Type",
      "d": 796019,
      "h": 17180665203,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180665203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295763315),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 796019,
      "h": 4295763315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295763315)
  ],
  "h": 796019
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostSchedulable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostReplyable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventEditionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(796019)
        
        

        //--TRIMMABLE-BOUNDARY-START(3548531)
        $asm.$cls(`$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService_Mocking`, ($self) => class ICommunityCalendarFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298515827)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298515827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298515827)
            
            //--TRIMMABLE-BOUNDARY-START(8593483123)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593483123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593483123)
            
            static $h = 3548531;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298515827),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3548531,
      "h": 4298515827,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298515827)
  ],
  "h": 3548531
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OnVo.LCCCCS.ICommunityCalendarFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Services.ICommunityCalendarFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Services${separator}ICommunityCalendarFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3548531)
        
        

        //--TRIMMABLE-BOUNDARY-START(3679603)
        $asm.$cls(`$OnVo.LCCCCS.IComunityCalendarRemoteService_Mocking`, ($self) => class IComunityCalendarRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4298646899)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298646899);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298646899)
            
            //--TRIMMABLE-BOUNDARY-START(8593614195)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593614195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8593614195)
            
            //--TRIMMABLE-BOUNDARY-START(17183548787)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183548787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17183548787)
            
            //--TRIMMABLE-BOUNDARY-START(21478516083)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478516083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21478516083)
            
            //--TRIMMABLE-BOUNDARY-START(25773483379)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Calendar$Common$Models$CommunityCalendarEventPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773483379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25773483379)
            
            //--TRIMMABLE-BOUNDARY-START(12888581491)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888581491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OnVo.LCCCCM.CommunityCalendarEventPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12888581491)
            
            static $h = 3679603;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298646899),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3679603,
      "h": 4298646899,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298646899)
  ],
  "h": 3679603
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OnVo.LCCCCS.IComunityCalendarRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Services.IComunityCalendarRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Services${separator}IComunityCalendarRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3679603)
        
        

        //--TRIMMABLE-BOUNDARY-START(664947)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor`, ($self) => class CommunityCalendarEventCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295632243)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295632243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, this, factory);
                    }, $pGBxVc ??= {"r":65537,"n":"","d":664947,"h":0,"f":17825794}), 0, "CommunityCalendarEventCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventCategoryModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventCategoryModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295632243)
            
            //--TRIMMABLE-BOUNDARY-START(12885566835)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885566835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel)).Type);
                        }, $qMieWe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":664947,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885566835)
            
            //--TRIMMABLE-BOUNDARY-START(17180534131)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180534131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel, LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180534131)
            
            //--TRIMMABLE-BOUNDARY-START(8590599539)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590599539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590599539)
            
            static $h = 664947;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885566835),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 664947,
      "h": 12885566835,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885566835),
//--TRIMMABLE-BOUNDARY-START(17180534131),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 533875,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 664947,
      "h": 17180534131,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180534131),
//--TRIMMABLE-BOUNDARY-START(8590599539),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 533875,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 664947,
      "h": 8590599539,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590599539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295632243),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 664947,
      "h": 4295632243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295632243)
  ],
  "h": 664947
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(664947)
        
        

        //--TRIMMABLE-BOUNDARY-START(1451379)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor`, ($self) => class CommunityCalendarEventPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296418675)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296418675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventPostModel, this, factory);
                    }, $ldgSXf ??= {"r":65537,"n":"","d":1451379,"h":0,"f":17825794}), 0, "CommunityCalendarEventPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventPostModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventPostModelTypeDescriptor", 44);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296418675)
            
            //--TRIMMABLE-BOUNDARY-START(12886353267)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886353267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SetType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "SetType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SetType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "SetType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).SetType);
                        }, $DVRpTe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SetType = value.AsNullableValue($.$LCOv.LCFCPM$1.PostTypes);
                        }, $fFyCIc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Resources"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Resources", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Resources")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Resources";
                        $i3.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Resources);
                        }, $PtTwbi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Resources = value.AsReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel));
                        }, $KqSUoi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EventType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "EventType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EventType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "EventType";
                        $i5.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$OnVo.LCCCCM.CommunityCalendarEventType, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).EventType);
                        }, $wffhml ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EventType = value.AsEnumValue($.$OnVo.LCCCCM.CommunityCalendarEventType);
                        }, $NYGuIh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "StartDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "StartDate";
                        $i7.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$3(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).StartDate);
                        }, $jvrxwi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartDate = value.AsDateOnly();
                        }, $TRUhXd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "StartTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "StartTime";
                        $i9.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$10(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).StartTime);
                        }, $nNAWZj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartTime = value.AsTimeOnly();
                        }, $MPaoVd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Recurrence"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Recurrence", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Recurrence")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Recurrence";
                        $i11.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Recurrence);
                        }, $TCCDLf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Recurrence = value.AsValue($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence);
                        }, $KiDLCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Capacity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Capacity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Capacity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Capacity";
                        $i13.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Capacity);
                        }, $KUNEgb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Capacity = value.AsInt();
                        }, $dSDQGh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Amount";
                        $i15.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Amount);
                        }, $kBYuxf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $ONuOCf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Type";
                        $i17.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Type);
                        }, $kHRoBb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sessions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Sessions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sessions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Sessions";
                        $i19.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Sessions);
                        }, $eWbKQk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Sessions = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                        }, $qrrOih ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Speakers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Speakers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Speakers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Speakers";
                        $i21.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Speakers);
                        }, $qaYHoj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Speakers = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                        }, $gTZEpa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SeatTypes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "SeatTypes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SeatTypes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "SeatTypes";
                        $i23.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).SeatTypes);
                        }, $ngRoTd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SeatTypes = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                        }, $ZHOZJe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SeatBookings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "SeatBookings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SeatBookings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "SeatBookings";
                        $i25.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).SeatBookings);
                        }, $KhYbDk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SeatBookings = value.AsReference($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                        }, $bwFTMi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ScheduledDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "ScheduledDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ScheduledDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateOnly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "ScheduledDate";
                        $i27.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateOnly, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).ScheduledDate);
                        }, $foGnHa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "Link";
                        $i29.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)).Link);
                        }, $rVkMKe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1451379,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886353267)
            
            //--TRIMMABLE-BOUNDARY-START(17181320563)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181320563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$OnVo.LCCCCM.CommunityCalendarEventCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _SetType = _target.SetType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SetType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$LCOv.LCFCPM$1.PostTypes)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$LCOv.LCFCPM$1.PostTypes), () => _SetType, ($v) => _SetType = $v, null, true)))
                    {
                        _target.SetType = _SetType;
                    }
                }
                {
                    /*var*/ let _Resources = _target.Resources;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Resources"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel, property, $.$ref(() => _Resources, ($v) => _Resources = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel))))
                    {
                        _target.Resources = _Resources;
                        if (_Resources !== null)
                        {
                            let $en36 = _Resources.SCG$IEnumerable$$$GetEnumerator();
                            while ($en36.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en36.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$Iaui.LCFCM.ResourceModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), $.$Iaui.LCFCM.ResourceModel, property, $.$ref(() => _Resources, ($v) => _Resources = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)));
                    }
                }
                {
                    /*var*/ let _EventType = _target.EventType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EventType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OnVo.LCCCCM.CommunityCalendarEventType, () => _EventType, ($v) => _EventType = $v, null, true)))
                    {
                        _target.EventType = _EventType;
                    }
                }
                {
                    /*var*/ let _StartDate = _target.StartDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateOnly, () => _StartDate, ($v) => _StartDate = $v, null, true)))
                    {
                        _target.StartDate = _StartDate;
                    }
                }
                {
                    /*var*/ let _StartTime = _target.StartTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeOnly, () => _StartTime, ($v) => _StartTime = $v, null, true)))
                    {
                        _target.StartTime = _StartTime;
                    }
                }
                {
                    /*var*/ let _Recurrence = _target.Recurrence;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Recurrence"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OnVo.LCCCCM.CommunityCalendarEventRecurrence, () => _Recurrence, ($v) => _Recurrence = $v, null, true)))
                    {
                        _target.Recurrence = $.$clone(_Recurrence);
                    }
                }
                {
                    /*var*/ let _Capacity = _target.Capacity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Capacity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Capacity, ($v) => _Capacity = $v, $.$$.S.Int32)))
                    {
                        _target.Capacity = _Capacity;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Amount, ($v) => _Amount = $v, null, true)))
                    {
                        _target.Amount = $.$clone(_Amount);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Sessions = _target.Sessions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sessions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, property, $.$ref(() => _Sessions, ($v) => _Sessions = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel))))
                    {
                        _target.Sessions = _Sessions;
                        if (_Sessions !== null)
                        {
                            let $en54 = _Sessions.SCG$IEnumerable$$$GetEnumerator();
                            while ($en54.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en54.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel), $.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel, property, $.$ref(() => _Sessions, ($v) => _Sessions = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSessionPostModel)));
                    }
                }
                {
                    /*var*/ let _Speakers = _target.Speakers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Speakers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, property, $.$ref(() => _Speakers, ($v) => _Speakers = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel))))
                    {
                        _target.Speakers = _Speakers;
                        if (_Speakers !== null)
                        {
                            let $en59 = _Speakers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en59.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en59.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel), $.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel, property, $.$ref(() => _Speakers, ($v) => _Speakers = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSpeakerModel)));
                    }
                }
                {
                    /*var*/ let _SeatTypes = _target.SeatTypes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SeatTypes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, property, $.$ref(() => _SeatTypes, ($v) => _SeatTypes = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel))))
                    {
                        _target.SeatTypes = _SeatTypes;
                        if (_SeatTypes !== null)
                        {
                            let $en64 = _SeatTypes.SCG$IEnumerable$$$GetEnumerator();
                            while ($en64.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en64.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel), $.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel, property, $.$ref(() => _SeatTypes, ($v) => _SeatTypes = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventSeatTypeModel)));
                    }
                }
                {
                    /*var*/ let _SeatBookings = _target.SeatBookings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SeatBookings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, property, $.$ref(() => _SeatBookings, ($v) => _SeatBookings = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel))))
                    {
                        _target.SeatBookings = _SeatBookings;
                        if (_SeatBookings !== null)
                        {
                            let $en69 = _SeatBookings.SCG$IEnumerable$$$GetEnumerator();
                            while ($en69.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en69.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel), $.$OnVo.LCCCCM.CommunityCalendarEventBookingModel, property, $.$ref(() => _SeatBookings, ($v) => _SeatBookings = $v, $.$$.SCG.IEnumerable$$($.$OnVo.LCCCCM.CommunityCalendarEventBookingModel)));
                    }
                }
                {
                    /*var*/ let _ScheduledDate = _target.ScheduledDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ScheduledDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateOnly)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateOnly), () => _ScheduledDate, ($v) => _ScheduledDate = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181320563)
            
            //--TRIMMABLE-BOUNDARY-START(8591385971)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591385971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591385971)
            
            static $h = 1451379;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886353267),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1451379,
      "h": 12886353267,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886353267),
//--TRIMMABLE-BOUNDARY-START(17181320563),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1320307,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1451379,
      "h": 17181320563,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181320563),
//--TRIMMABLE-BOUNDARY-START(8591385971),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1320307,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1451379,
      "h": 8591385971,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591385971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296418675),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1451379,
      "h": 4296418675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296418675)
  ],
  "h": 1451379
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1451379)
        
        

        //--TRIMMABLE-BOUNDARY-START(2958707)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarModel`, ($self) => class CommunityCalendarModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297926003)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297926003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297926003)
            
            //--TRIMMABLE-BOUNDARY-START(4297926003)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4297926003)
            
            static $h = 2958707;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297926003),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 2958707,
      "h": 4297926003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297926003)
  ],
  "h": 2958707
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2958707)
        
        

        //--TRIMMABLE-BOUNDARY-START(927091)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor`, ($self) => class CommunityCalendarEventEditionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295894387)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295894387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel, this, factory);
                    }, $HcTXIc ??= {"r":65537,"n":"","d":927091,"h":0,"f":17825794}), 0, "CommunityCalendarEventEditionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarEventEditionModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModelTypeDescriptorBuilder.g.cs", "CommunityCalendarEventEditionModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295894387)
            
            //--TRIMMABLE-BOUNDARY-START(12885828979)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885828979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel)).Type);
                        }, $miIAWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":927091,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885828979)
            
            //--TRIMMABLE-BOUNDARY-START(17180796275)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180796275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventPostModel?*/ let targetBase = _target;
                $.$OnVo.LCCCCM.CommunityCalendarEventPostModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$OnVo.LCCCCM.CommunityCalendarEventPostModel));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180796275)
            
            //--TRIMMABLE-BOUNDARY-START(8590861683)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590861683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarEventEditionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarEventEditionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590861683)
            
            static $h = 927091;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885828979),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 927091,
      "h": 12885828979,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885828979),
//--TRIMMABLE-BOUNDARY-START(17180796275),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 796019,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 927091,
      "h": 17180796275,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180796275),
//--TRIMMABLE-BOUNDARY-START(8590861683),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 796019,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 927091,
      "h": 8590861683,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590861683)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295894387),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 927091,
      "h": 4295894387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295894387)
  ],
  "h": 927091
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarEventEditionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarEventEditionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarEventEditionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(927091)
        
        

        //--TRIMMABLE-BOUNDARY-START(3089779)
        $asm.$cls(`$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptor`, ($self) => class CommunityCalendarModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298057075)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298057075);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptor.GenerateProperties($.$OnVo.LCCCCM.CommunityCalendarModel, this, factory);
                    }, $UaoXnl ??= {"r":65537,"n":"","d":3089779,"h":0,"f":17825794}), 0, "CommunityCalendarModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Calendar.Common\\Models_CommunityCalendarModel_LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModelTypeDescriptorBuilder.g.cs", "CommunityCalendarModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298057075)
            
            //--TRIMMABLE-BOUNDARY-START(12887991667)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887991667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887991667)
            
            //--TRIMMABLE-BOUNDARY-START(17182958963)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182958963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Calendar.Common.Settings.CommunityCalendarSettings, LivingThing.Core.Community.Calendar.Common.States.CommunityCalendarStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$OnVo.LCCCCS$1.CommunityCalendarSettings, $.$OnVo.LCCCCS$2.CommunityCalendarStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182958963)
            
            //--TRIMMABLE-BOUNDARY-START(8593024371)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593024371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OnVo.LCCCCM.CommunityCalendarModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OnVo.LCCCCM.CommunityCalendarModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarModel)))
                {
                    /*var*/ let result = $.$OnVo.LCCCCM.CommunityCalendarModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OnVo.LCCCCM.CommunityCalendarModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OnVo.LCCCCM.CommunityCalendarModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593024371)
            
            static $h = 3089779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887991667),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3089779,
      "h": 12887991667,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887991667),
//--TRIMMABLE-BOUNDARY-START(17182958963),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2958707,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3089779,
      "h": 17182958963,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182958963),
//--TRIMMABLE-BOUNDARY-START(8593024371),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2958707,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3089779,
      "h": 8593024371,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593024371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298057075),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3089779,
      "h": 4298057075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298057075)
  ],
  "h": 3089779
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OnVo.LCCCCM.CommunityCalendarModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Calendar.Common.Models.CommunityCalendarModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Calendar${separator}Common${separator}Models${separator}CommunityCalendarModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3089779)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(9587)
