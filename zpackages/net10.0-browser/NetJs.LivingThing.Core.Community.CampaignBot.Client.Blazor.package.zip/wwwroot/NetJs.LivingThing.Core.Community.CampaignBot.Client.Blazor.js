
//--TRIMMABLE-BOUNDARY-START(22986)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $bTOs, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $NKVjfc;
    let $qylYSd;
    let $qzkTck;
    let $aZllFa;
    let $nhIARa;
    let $wKrLJg;
    let $PNPOKg;
    let $DVVdyd;
    let $rwLYfg;
    let $FcvaDa;
    let $EngTke;
    let $SuDJYa;
    let $ZfrTVi;
    let $oyJtvg;
    let $hPsyji;
    let $sYWTbe;
    let $gLZrth;
    let $nsZgfa;
    let $XMMhRb;
    let $zKWfJf;
    let $jlFgFh;
    let $vKWSyk;
    let $JEwLIf;
    let $PDkrmi;
    let $eCgsOf;
    let $DzESfd;
    let $GSYhUa;
    let $DJvege;
    let $gdsiDi;
    let $zTcCok;
    let $KjNcKb;
    let $ZCxvAe;
    let $qJGOoh;
    let $coNwGh;
    let $VGGdbd;
    let $rhTvdh;
    let $vteTJi;
    let $fpbqeg;
    let $HSlzff;
    let $yABLEh;
    let $iasACa;
    let $pswuuk;
    let $Cpwiec;
    let $eIbcij;
    let $HylOMh;
    let $nAnzHe;
    let $uNNTCd;
    let $bqNkHe;
    let $LUdoQh;
    let $YaIzQc;
    let $iQrhzf;
    let $UMYYSi;
    let $OoRrKi;
    let $xmkgVa;
    let $IqZGBh;
    let $JppZse;
    let $wBzNll;
    let $eiXPHg;
    let $Ashqck;
    let $WiOhlb;
    let $vknCLj;
    let $lMCqYg;
    let $wjNOTe;
    let $SsJifi;
    let $fChWii;
    let $CSnEKk;
    let $xHnRai;
    let $rzBkfa;
    let $UDlDpc;
    let $PxLCYf;
    let $JpsTvg;
    let $pGxWvd;
    let $mydRMh;
    let $latEJc;
    let $qkubmb;
    let $oDyrug;
    let $taqCfg;
    let $XiOYkh;
    let $KMGKkc;
    let $txBpdg;
    let $uUkIcf;
    let $BqGbPh;
    let $XVzOOg;
    let $gokfma;
    let $TuNoWe;
    let $DDwPoi;
    let $Wsigqb;
    let $TZmAje;
    let $lPWRzk;
    let $PsuVVi;
    let $meQNYj;
    let $JMdlsb;
    let $qxwNoc;
    let $EHKksi;
    let $Phjorc;
    let $OMxcjf;
    let $LXrizg;
    let $hXgJWf;
    let $llFKqb;
    let $eXybKd;
    let $xrCAih;
    let $dlAUHk;
    let $FaFzBe;
    let $ALiaQb;
    let $JPirxe;
    let $SfkOud;
    let $Zakyma;
    let $KHGFIa;
    let $ZFztAf;
    let $FlOPcd;
    let $iAyrnk;
    let $ohjhLa;
    let $UCulSf;
    let $LkkhMi;
    let $Wjjxoj;
    let $JfvMJg;
    let $btKTvj;
    let $JfZzya;
    let $FhURml;
    let $YXFYNd;
    let $sjKdBi;
    let $VOWFuf;
    let $WKxjZd;
    let $VqAfrf;
    let $jdHoHd;
    let $TgBJdd;
    let $TgJejj;
    let $VGGqfb;
    let $FrmGUc;
    let $CyUZob;
    let $pIJdbf;
    let $YWJGmb;
    let $iwVByk;
    let $kJFWJg;
    let $QgJfIi;
    let $QqlQij;
    let $ypjIKa;
    let $brMTRa;
    let $QSpzMd;
    let $fcYWre;
    let $AegTIe;
    let $LCLNWb;
    let $tRwyki;
    let $pQSgJa;
    let $HCAtPe;
    let $WONZNc;
    let $IFSurg;
    let $HZNdgh;
    let $onUcre;
    let $sgCdve;
    let $sfKlAd;
    let $FgnLmi;
    let $nXCZli;
    let $nHnWtg;
    let $pzORab;
    let $UTJoGf;
    let $XSRBOj;
    let $jsikfe;
    let $oKFosc;
    let $Wqcjnc;
    let $TMxuMg;
    let $VeLYAe;
    let $ktPqAa;
    let $lDzINh;
    let $HlQfPd;
    let $cxDyAj;
    let $eukOoa;
    let $BnBrXd;
    let $gfWlLf;
    let $ojJagd;
    let $XaTNPk;
    let $nOTyhg;
    let $sZLwJj;
    let $tpXNbi;
    let $qGryVd;
    let $OygALa;
    let $wAGede;
    let $kspxBd;
    let $kUuQWg;
    let $DlCcid;
    let $BpcTOj;
    let $Vtncbl;
    let $wufBWa;
    let $sEbEsa;
    let $SIVqmd;
    let $XBvZpa;
    let $UZttcl;
    let $wrQYme;
    let $FDhDij;
    let $kupLuk;
    let $qQPPZf;
    let $qyabyk;
    let $ezJkbj;
    let $iMlcMj;
    let $Guhmfk;
    let $YDgmzf;
    let $MGZXCk;
    let $ePVYFj;
    let $yYrXck;
    let $mmRRLh;
    let $alWHVc;
    let $jHxFCa;
    let $AboDXb;
    let $aebAQe;
    let $eFrhee;
    let $EXFllj;
    let $iiZAye;
    let $hwHElk;
    let $WjsLhe;
    let $vaQwUi;
    let $YCansf;
    let $lzASek;
    let $pYAOib;
    let $OXjlcd;
    let $Bxwyug;
    let $lyIzQh;
    let $ETxxRj;
    let $oKuJOh;
    let $Uigvpj;
    let $UEwqBa;
    let $RmSkij;
    let $gZTtoh;
    let $gIxJpk;
    let $BTEnIi;
    let $AInnSi;
    let $tJtsnd;
    let $CFefUj;
    let $QEHoBe;
    let $EFOPXj;
    let $NmSmEa;
    let $pQMGil;
    let $irSPxi;
    let $MVbsPe;
    let $Etjoje;
    let $XmzrNh;
    let $pFhlpl;
    let $EnmrEf;
    let $fBXSQd;
    let $HJzYff;
    let $cfQIgj;
    let $eNmMbl;
    let $lEYkZi;
    let $AgbIFc;
    let $xcYcUf;
    let $rgKMTh;
    let $BOfyOe;
    let $fTZqce;
    let $FISsSa;
    let $YxZjJj;
    let $HCWrah;
    let $wsAgIa;
    let $zWzOBi;
    let $bCcrOc;
    let $ZfHOpb;
    let $phcErb;
    let $UJJkAh;
    let $fDehmc;
    let $TjPoch;
    let $IQUCte;
    let $BWkSLh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor", 
    {
  "h": 22986,
  "f": "LivingThing.Core.Community.CampaignBot.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.CampaignBot.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.CampaignBot.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(416202)
        $asm.$cls(`$tUzp.LCCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295383498)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295383498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295383498)
            
            static $h = 416202;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295383498),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 416202,
      "h": 4295383498,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295383498)
  ],
  "h": 416202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(416202)
        
        

        //--TRIMMABLE-BOUNDARY-START(285130)
        $asm.$cls(`$tUzp.LCCCC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295252426)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295252426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$tUzp.LCCCC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295252426)
            
            static $h = 285130;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295252426),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 285130,
      "h": 4295252426,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295252426)
  ],
  "h": 285130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(285130)
        
        

        //--TRIMMABLE-BOUNDARY-START(1595850)
        $asm.$cls(`$tUzp.LCCCCS$1.SignupModeCustomAttributesProvider`, ($self) => class SignupModeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296563146)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296563146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296563146)
            
            static $h = 1595850;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296563146),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1595850,
      "h": 4296563146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296563146)
  ],
  "h": 1595850
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.SignupModeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}SignupModeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1595850)
        
        

        //--TRIMMABLE-BOUNDARY-START(547274)
        $asm.$cls(`$tUzp.LCCCC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590481866)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590481866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$tUzp.LCCCCP.Admin, "LivingThing.Core.Community.CampaignBot.Client", "Pages\\Admin", "Admin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/CampaignBot/Admin" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$tUzp.LCCCCP.CommunityCampaignBotLandingPage, "LivingThing.Core.Community.CampaignBot.Client", "Pages\\CommunityCampaignBotLandingPage", "Community Campaign Bot Landing Page", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/CampaignBotHome" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$tUzp.LCCCCP.Index, "LivingThing.Core.Community.CampaignBot.Client", "Pages\\Index", "Index", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/CampaignBot" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590481866)
            
            //--TRIMMABLE-BOUNDARY-START(4295514570)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295514570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295514570)
            
            //--TRIMMABLE-BOUNDARY-START(4295514570)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295514570)
            
            static $h = 547274;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590481866),
    {
      "r": 65537,
      "n": "Build",
      "d": 547274,
      "h": 8590481866,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590481866)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295514570),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 547274,
      "h": 4295514570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295514570)
  ],
  "h": 547274
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(547274)
        
        

        //--TRIMMABLE-BOUNDARY-START(350666)
        $asm.$cls(`$tUzp.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295317962)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295317962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$tUzp.LCCCCS$1.SignupMode.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$tUzp.LCCCCS$1.SignupModeCustomAttributesProvider, $.$tUzp.LCCCCS$1.SignupModeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295317962)
            
            static $h = 350666;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295317962),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 350666,
      "h": 4295317962,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295317962)
  ],
  "h": 350666
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(350666)
        
        

        //--TRIMMABLE-BOUNDARY-START(88522)
        $asm.$cls(`$tUzp._LCCCCSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295055818)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::System.String*/ __arg3, /*int*/ __seq4, /*TValue*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg5, /*int*/ __seq6, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg6)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295055818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "rows", __arg2);
                __builder.AddComponentParameter(__seq3, "Class", __arg3);
                __builder.AddComponentParameter(__seq4, "Value", $.$box(__arg4, TValue));
                __builder.AddComponentParameter(__seq5, "ValueChanged", __arg5);
                __builder.AddComponentParameter(__seq6, "ValueExpression", __arg6);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295055818)
            
            //--TRIMMABLE-BOUNDARY-START(8590023114)
            static /*void */ CreateInputEditor_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590023114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Type", $.$box(__arg1, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590023114)
            
            static $h = 88522;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295055818),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 1310721
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 88522,
      "h": 4295055818,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295055818),
//--TRIMMABLE-BOUNDARY-START(8590023114),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 47614294
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_1",
      "d": 88522,
      "h": 8590023114,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590023114)
  ],
  "h": 88522
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.CampaignBot.Client.Shared.CommunityCampaignEditor.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CommunityCampaignEditor${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(88522)
        
        

        //--TRIMMABLE-BOUNDARY-START(154058)
        $asm.$cls(`$tUzp._LCCCCSD.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295121354)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295121354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295121354)
            
            static $h = 154058;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295121354),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 154058,
      "h": 4295121354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295121354)
  ],
  "h": 154058
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.CampaignBot.Client.Shared.Dashboard.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}Dashboard${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(154058)
        
        

        //--TRIMMABLE-BOUNDARY-START(940490)
        $asm.$cls(`$tUzp.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590875082)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590875082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$tUzp.LCCCCS.CommunityCampaignBotService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$tUzp.LCCCCS.CommunityCampaignBotApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotApplication, x);
                }, $oyJtvg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":940490,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotApplication, x);
                }, $hPsyji ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":940490,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, services, null);
                $.$tUzp.LCCCC._Startup.AddGeneratedComponentOptimizers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590875082)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tUzp.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295907786)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295907786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295907786)
            
            //--TRIMMABLE-BOUNDARY-START(4295907786)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295907786)
            
            static $h = 940490;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590875082),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 940490,
      "h": 8590875082,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590875082)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295907786),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 940490,
      "h": 4295907786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295907786)
  ],
  "h": 940490
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(940490)
        
        

        //--TRIMMABLE-BOUNDARY-START(481738)
        $asm.$cls(`$tUzp.LCCCC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180350922)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCP.Admin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCP.Admin().$ctor$3();
                    }, $sYWTbe ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCP.CommunityCampaignBotApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCP.CommunityCampaignBotApp().$ctor$3();
                    }, $gLZrth ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage().$ctor$3();
                    }, $nsZgfa ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCP.Index.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCP.Index().$ctor$3();
                    }, $XMMhRb ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.CampaignView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.CampaignView().$ctor$3();
                    }, $zKWfJf ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.CommunityCampaignBotsView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.CommunityCampaignBotsView().$ctor$3();
                    }, $jlFgFh ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.CommunityCampaignEditor.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.CommunityCampaignEditor().$ctor$5();
                    }, $vKWSyk ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.CommunityCampaignHome.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.CommunityCampaignHome().$ctor$3();
                    }, $JEwLIf ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.CommunityCampaignView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.CommunityCampaignView().$ctor$5();
                    }, $PDkrmi ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$tUzp.LCCCCS$1.Dashboard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$tUzp.LCCCCS$1.Dashboard().$ctor$3();
                    }, $eCgsOf ??= {"r":2752627,"n":"","d":481738,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180350922)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295449034)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295449034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295449034)
            
            //--TRIMMABLE-BOUNDARY-START(4295449034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295449034)
            
            static $h = 481738;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180350922),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885383626,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 481738,
      "h": 17180350922,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180350922)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295449034),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 481738,
      "h": 4295449034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295449034)
  ],
  "h": 481738
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(481738)
        
        

        //--TRIMMABLE-BOUNDARY-START(1661386)
        $asm.$cls(`$tUzp.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296628682)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296628682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296628682)
            
            //--TRIMMABLE-BOUNDARY-START(4296628682)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296628682)
            
            static $h = 1661386;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296628682),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1661386,
      "h": 4296628682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296628682)
  ],
  "h": 1661386
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1661386)
        
        

        //--TRIMMABLE-BOUNDARY-START(1726922)
        $asm.$cls(`$tUzp.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296694218)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296694218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296694218)
            
            //--TRIMMABLE-BOUNDARY-START(4296694218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296694218)
            
            static $h = 1726922;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296694218),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1726922,
      "h": 4296694218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296694218)
  ],
  "h": 1726922,
  "a": [
    {
      "t": 1661386,
      "c": 4296628682
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1726922)
        
        

        //--TRIMMABLE-BOUNDARY-START(1530314)
        $asm.$str(`$tUzp.LCCCCS$1.SignupMode`, ($self) => class SignupMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static SignupBegin = 1;
            static SignupToken = 2;
            static Login = 3;
            static ForgotPasswordBegin = 4;
            static ForgotPasswordToken = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1530314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SignupBegin": 1n,
                    "SignupToken": 2n,
                    "Login": 3n,
                    "ForgotPasswordBegin": 4n,
                    "ForgotPasswordToken": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296497610)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296497610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296497610)
            
            //--TRIMMABLE-BOUNDARY-START(4296497610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296497610)
            
            static $h = 1530314;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476366794),
    {
      "t": 1530314,
      "n": "None",
      "d": 1530314,
      "h": 21476366794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476366794),
//--TRIMMABLE-BOUNDARY-START(25771334090),
    {
      "t": 1530314,
      "n": "SignupBegin",
      "d": 1530314,
      "h": 25771334090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771334090),
//--TRIMMABLE-BOUNDARY-START(30066301386),
    {
      "t": 1530314,
      "n": "SignupToken",
      "d": 1530314,
      "h": 30066301386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066301386),
//--TRIMMABLE-BOUNDARY-START(17181399498),
    {
      "t": 1530314,
      "n": "Login",
      "d": 1530314,
      "h": 17181399498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181399498),
//--TRIMMABLE-BOUNDARY-START(8591464906),
    {
      "t": 1530314,
      "n": "ForgotPasswordBegin",
      "d": 1530314,
      "h": 8591464906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591464906),
//--TRIMMABLE-BOUNDARY-START(12886432202),
    {
      "t": 1530314,
      "n": "ForgotPasswordToken",
      "d": 1530314,
      "h": 12886432202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886432202)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296497610),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1530314,
      "h": 4296497610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296497610)
  ],
  "h": 1530314
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.SignupMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}SignupMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1530314)
        
        

        //--TRIMMABLE-BOUNDARY-START(219594)
        $asm.$cls(`$tUzp.LCCCC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590154186)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590154186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590154186)
            
            //--TRIMMABLE-BOUNDARY-START(4295186890)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295186890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295186890)
            
            //--TRIMMABLE-BOUNDARY-START(4295186890)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295186890)
            
            static $h = 219594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590154186),
    {
      "r": 65537,
      "n": "Execute",
      "d": 219594,
      "h": 8590154186,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590154186)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295186890),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 219594,
      "h": 4295186890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295186890)
  ],
  "h": 219594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(219594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1137098)
        $asm.$cls(`$tUzp.LCCCCS$1.CampaignView`, ($self) => class CampaignView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(30065908170)
            /*string */ get OptimizedComponentName()
            {
                return "campaignview";
            }
            //--TRIMMABLE-BOUNDARY-END(30065908170)
            
            //--TRIMMABLE-BOUNDARY-START(12886038986)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886038986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886038986)
            
            //--TRIMMABLE-BOUNDARY-START(8591071690)
            static /*RenderFragment */ AudioPlayer(/*CommunityCampaignBotPostModel*/ campaign, /*string ?*/ _class)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591071690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let tts = campaign.SpeechBinary !== null ? `data:audio/mpeg;base64,${$.$strNN($.$$.S.Convert.ToBase64String$3(campaign.SpeechBinary))}` : null;
                /*var*/ let url = campaign.SpeechBinary !== null ? tts : campaign.MediaUrl;
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(0, "audio");
                    __builder2.AddAttribute$6(1, "controls");
                    __builder2.AddAttribute$5(2, "class", _class);
                    __builder2.AddAttribute$5(3, "src", url);
                    __builder2.CloseElement();
                }, $rwLYfg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1137098,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8591071690)
            
            //--TRIMMABLE-BOUNDARY-START(25770940874)
            static /*RenderFragment */ ListView(/*CommunityCampaignBotPostModel*/ campaign, /*Func<ValueTask>?*/ onApprove, /*Func<ValueTask>?*/ onReject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770940874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "stack fill");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 6);
                    __builder2.AddComponentParameter(7, "Class", "flex");
                    __builder2.AddComponentParameter(8, "href", campaign.Link);
                    __builder2.AddComponentParameter(9, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, campaign));
                    __builder2.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenElement(11, "h3");
                        __builder3.AddAttribute$5(12, "class", "mg-0 cl-primary");
                        __builder3.AddContent$4(13, campaign.Title);
                        __builder3.CloseElement();
                    }), $FcvaDa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1137098,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(14, "\r\n        ");
                    __builder2.OpenElement(15, "div");
                    __builder2.AddAttribute$5(16, "class", "grid colm-1 gap-1 mgt-2 bdt pdt-2");
                    __builder2.OpenElement(17, "div");
                    __builder2.AddAttribute$5(18, "class", "flex");
                    __builder2.AddMarkupContent(19, "<small class=\"mgy-a mgr\">Type: </small>\r\n                ");
                    __builder2.OpenElement(20, "b");
                    __builder2.AddAttribute$5(21, "class", "mdi mdi-music nowrap");
                    __builder2.AddContent$3(22, $.$box(campaign.BotType, $.$bTOs.LCCCCM.CommunityCampaignBotType));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (campaign.Contacts !== null)
                    {
                        __builder2.OpenElement(23, "div");
                        __builder2.AddAttribute$5(24, "class", "flex");
                        __builder2.AddMarkupContent(25, "<small class=\"mgy-a mgr\">Contacts: </small>\r\n                    ");
                        __builder2.OpenElement(26, "b");
                        __builder2.AddAttribute$5(27, "class", "mdi mdi-phone nowrap");
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>*/ let __ca1__;
                        __builder2.AddContent$3(28, $.$box(($.$box((__ca1__ = campaign.Contacts) !== null ? $.$sl.SL.Enumerable.Count$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca1__) : null, $.$$.S.Int32)), $.$$.S.Int32));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    if (((campaign.Targeting?.Gender ?? null) ?? 0/*Gender.None*/) !== 0/*Gender.None*/)
                    {
                        __builder2.OpenElement(29, "div");
                        __builder2.AddAttribute$5(30, "class", "flex");
                        __builder2.AddMarkupContent(31, "<small class=\"mgy-a mgr\">Gender: </small>\r\n                    ");
                        __builder2.OpenElement(32, "b");
                        __builder2.AddAttribute$5(33, "class", "nowrap");
                        __builder2.AddContent$3(34, $.$box((campaign.Targeting?.Gender ?? null), $.$fPer.LCFCD.Gender));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    if ((campaign.Targeting?.AgeRange.Minimum ?? null) !== null || (campaign.Targeting?.AgeRange.Maximum ?? null) !== null)
                    {
                        __builder2.OpenElement(35, "div");
                        __builder2.AddAttribute$5(36, "class", "flex");
                        __builder2.AddMarkupContent(37, "<small class=\"mgy-a mgr\">Age: </small>\r\n                    ");
                        __builder2.OpenElement(38, "b");
                        __builder2.AddAttribute$5(39, "class", "nowrap");
                        __builder2.AddContent$4(40, $.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)).op_Implicit(campaign.Targeting.AgeRange));
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(41, "div");
                    __builder2.AddAttribute$5(42, "class", "flex");
                    __builder2.AddMarkupContent(43, "<small class=\"mgy-a mgr\">Budget: </small>\r\n                ");
                    __builder2.OpenElement(44, "b");
                    __builder2.AddAttribute$5(45, "class", "nowrap");
                    __builder2.AddMarkupContent(46, "\u20A6");
                    __builder2.AddContent$4(47, $.$$.S.Double.ToString$3.call(campaign.Wallet, "f"));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(48, "\r\n            ");
                    __builder2.OpenElement(49, "div");
                    __builder2.AddAttribute$5(50, "class", "flex");
                    __builder2.AddMarkupContent(51, "<small class=\"mgy-a mgr\">State: </small>");
                    /*var*/ let fnt = campaign.State === 0/*CommunityCampaignBotState.Draft*/ ? "pencil" : campaign.State === 1/*CommunityCampaignBotState.Published*/ ? "check" : campaign.State === 2/*CommunityCampaignBotState.Paused*/ ? "pause" : campaign.State === 5/*CommunityCampaignBotState.Rejected*/ ? "cancel" : campaign.State === 3/*CommunityCampaignBotState.Running*/ ? "check" : "pencil";
                    /*var*/ let col = campaign.State === 0/*CommunityCampaignBotState.Draft*/ ? "black" : campaign.State === 1/*CommunityCampaignBotState.Published*/ ? "warning" : campaign.State === 2/*CommunityCampaignBotState.Paused*/ ? "error" : campaign.State === 5/*CommunityCampaignBotState.Rejected*/ ? "fatal" : campaign.State === 3/*CommunityCampaignBotState.Running*/ ? "success" : "primary";
                    __builder2.OpenElement(52, "b");
                    __builder2.AddAttribute$5(53, "class", $.$strNN($.$strNN($.$strNN($.$strNN("mdi" + " mdi-") + $.$strNN((fnt))) + " cl-") + $.$strNN((col))) + " nowrap");
                    __builder2.AddContent$3(54, $.$box(campaign.State, $.$bTOs.LCCCCM.CommunityCampaignBotState));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (campaign.State === 1/*CommunityCampaignBotState.Published*/ && (onApprove !== null || onReject !== null))
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCA$3.AuthorizeUser, 55);
                        __builder2.AddComponentParameter(56, "Roles", "SuperAdmin");
                        __builder2.AddAttribute$3(57, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(58, "div");
                                __builder3.AddAttribute$5(59, "class", "text-right");
                                __builder3.AddContent$1(60, $.$hDPm.LCFCCB$4.Button.Static($.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$mac.MAC.RenderFragment).op_Implicit(""), "bg-primary mgr corner mdi mdi-check", $.$fPer.LCFCO.OneOf$$$($.$$.S.Func$$($.$$.STT.Task), $.$$.S.Func$$($.$$.STT.ValueTask)).op_Implicit$1(onApprove)));
                                __builder3.AddMarkupContent(61, "\r\n                        ");
                                __builder3.AddContent$1(62, $.$hDPm.LCFCCB$4.Button.Static($.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$mac.MAC.RenderFragment).op_Implicit(""), "bg-error corner mdi mdi-cancel", $.$fPer.LCFCO.OneOf$$$($.$$.S.Func$$($.$$.STT.Task), $.$$.S.Func$$($.$$.STT.ValueTask)).op_Implicit$1(onReject)));
                                __builder3.CloseElement();
                            }, $EngTke ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1137098,"h":0,"f":17825794});
                        }), $SuDJYa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":1137098,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(63, "\r\n        ");
                    __builder2.AddContent$1(64, $.$tUzp.LCCCCS$1.CampaignView.AudioPlayer(campaign, "mgt wf"));
                    __builder2.CloseElement();
                }, $ZfrTVi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1137098,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(25770940874)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296104394)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296104394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296104394)
            
            //--TRIMMABLE-BOUNDARY-START(4296104394)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296104394)
            
            static $h = 1137098;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065908170),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475973578,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1137098,
      "h": 30065908170,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065908170)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886038986),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1137098,
      "h": 12886038986,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886038986),
//--TRIMMABLE-BOUNDARY-START(8591071690),
    {
      "r": 6881395,
      "p": [
        {
          "n": "campaign",
          "p": 1863683
        },
        {
          "n": "_class",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "AudioPlayer",
      "d": 1137098,
      "h": 8591071690,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591071690),
//--TRIMMABLE-BOUNDARY-START(25770940874),
    {
      "r": 6881395,
      "p": [
        {
          "n": "campaign",
          "p": 1863683
        },
        {
          "n": "onApprove",
          "p": $.$$.S.Func$$($.$$.STT.ValueTask).$h,
          "f": 65
        },
        {
          "n": "onReject",
          "p": $.$$.S.Func$$($.$$.STT.ValueTask).$h,
          "f": 65
        }
      ],
      "n": "ListView",
      "d": 1137098,
      "h": 25770940874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770940874)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296104394),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1137098,
      "h": 4296104394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296104394)
  ],
  "h": 1137098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.CampaignView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CampaignView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1137098)
        
        

        //--TRIMMABLE-BOUNDARY-START(743882)
        $asm.$cls(`$tUzp.LCCCCP.CommunityCampaignBotLandingPage`, ($self) => class CommunityCampaignBotLandingPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(809418)
            static $_Banner;
            static get Banner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(809418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage;
                return $cls.$_Banner ??= $asm.$nstr(`$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner`, ($self) => class Banner extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(55835384266)
                    /*MarkupString*/ Title;
                    //--TRIMMABLE-BOUNDARY-END(55835384266)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180678602)
                    /*int?*/ Duration = null;
                    //--TRIMMABLE-BOUNDARY-END(17180678602)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885711306)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885711306);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885711306)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885711306)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885711306)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Title = this.Title.$clone();
                        copy.Duration = this.Duration;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(55835384266)
                        this.Title = $.$default($.$mac.MAC.MarkupString);
                        //--TRIMMABLE-BOUNDARY-END(55835384266)
                        
                    }
                    static $h = 809418;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835384266),
    {
      "p": 4849779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360547786,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540416970,
        "f": 83886081
      },
      "n": "Title",
      "d": 809418,
      "h": 55835384266,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835384266),
//--TRIMMABLE-BOUNDARY-START(17180678602),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770613194,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950482378,
        "f": 83886081
      },
      "n": "Duration",
      "d": 809418,
      "h": 17180678602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180678602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885711306),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 809418,
      "h": 12885711306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885711306)
  ],
  "d": 743882,
  "h": 809418
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Pages.CommunityCampaignBotLandingPage+Banner`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Pages${separator}CommunityCampaignBotLandingPage${separator}Banner`; }
                }, $cls, ($v) => $cls.$_Banner = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(809418)
            
            //--TRIMMABLE-BOUNDARY-START(8590678474)
            static /*Banner[] */ get Banners()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner), [(() =>
                {
                    //new $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner()
                    const $t1 = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Title = $.$mac.MAC.MarkupString.op_Explicit("BRING YOUR PRODUCT AND SERVICE MARKETING TO THE <span class=\"cl-primary mdi mdi-grass nowrap\">GRASSROOT</span> WITH");
                    return $i1;
                })(), (() =>
                {
                    //new $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner()
                    const $t2 = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Title = $.$mac.MAC.MarkupString.op_Explicit("LASER FOCUSED MARKETING, <span class=\"cl-primary mdi mdi-grass nowrap\">DIRECT TARGETING</span>");
                    return $i2;
                })(), (() =>
                {
                    //new $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner()
                    const $t3 = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Title = $.$mac.MAC.MarkupString.op_Explicit("CUSTOMERS NOT <span class=\"cl-primary mdi mdi-grass nowrap\">ONLINE</span>, NO PROBLEM, REACH THEM WITH");
                    return $i3;
                })(), (() =>
                {
                    //new $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner()
                    const $t4 = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Title = $.$mac.MAC.MarkupString.op_Explicit("INTUITIVE AND UNMATCHED <span class=\"cl-primary mdi mdi-grass nowrap\">AI GENERATIVE VOICEMAKER</span> ENGINE THAT IS CONFIDENT AND ARGUABLY HUMAN");
                    $i4.Duration = 10000;
                    return $i4;
                })()], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590678474)
            
            //--TRIMMABLE-BOUNDARY-START(34360482250)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360482250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$Assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Community.CampaignBot.Client.Blazor.css", true, false, false) ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(34360482250)
            
            //--TRIMMABLE-BOUNDARY-START(38655449546)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaignbotlandingpage";
            }
            //--TRIMMABLE-BOUNDARY-END(38655449546)
            
            //--TRIMMABLE-BOUNDARY-START(12885645770)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885645770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf scroll light-theme ltroot bg-tertiary campaignbothome");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "hx-6 clip pos-rel");
                __builder.OpenElement(4, "div");
                __builder.AddAttribute$5(5, "class", "pos-abs t-0 b-0 l-0 r-0 stack bg-fill bg-no-repeat");
                __builder.AddAttribute$5(6, "style", $.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/bg.jpg", true, false, false)))) + "');");
                __builder.OpenComponent$1($.$hDPm.LCFCCS$9.Slider, 7);
                __builder.AddComponentParameter(8, "Class", "hf");
                __builder.AddComponentParameter(9, "SliderFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCS$9.SliderFeatures, 96/*SliderFeatures.Default*/ | 128/*SliderFeatures.AutoPlay*/), $.$hDPm.LCFCCS$9.SliderFeatures));
                __builder.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    let $i5 = 0;
                    let $arr5 = $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banners;
                    while ($i5 < $arr5.length)
                    {
                        let _banner = $arr5[$i5++];
                        /*var*/ let banner = $.$clone(_banner);
                        __builder2.OpenComponent$1($.$hDPm.LCFCCS$9.Slide, 11);
                        __builder2.AddComponentParameter(12, "Class", "hf wf flex bg-dark-08");
                        __builder2.AddComponentParameter(13, "Duration", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, banner.Duration ?? 5000), $.$$.S.Int32));
                        __builder2.AddAttribute$3(14, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                __builder3.OpenElement(15, "div");
                                __builder3.AddAttribute$5(16, "class", "mg-a pdx-10 pdt-30");
                                __builder3.OpenElement(17, "h1");
                                __builder3.AddAttribute$5(18, "class", "cl-white text-center");
                                __builder3.AddAttribute$5(19, "style", "font-size: max(4vw, 30px);");
                                __builder3.AddContent(20, banner.Title);
                                __builder3.AddMarkupContent(21, "\r\n                                <br>\r\n                                ");
                                __builder3.AddMarkupContent(22, "<span class=\"cl-success mgt-5 d-block fsv-5 bg-success-01 pd-5 mgx-a mdi mdi-robot\">CAMPAIGNBOT</span>\r\n                                ");
                                __builder3.AddMarkupContent(23, "<div class=\"flex flex-center-x mgt-10\"><a href=\"CampaignBot\" class=\"bg-success corner-10 fsz-30 pdx-10 pdy-5 fw-bold\">\r\n                                        START CAMPAIGN\r\n                                    </a></div>");
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $gdsiDi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":743882,"h":0,"f":17825794});
                        }), $zTcCok ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Boolean).$h}],"n":"","d":743882,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }), $KjNcKb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":743882,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n        ");
                __builder.OpenElement(25, "div");
                __builder.AddAttribute$5(26, "class", "pdl-10 pdr-5 pdy-5 corner-10 bg-white mgx-5 mgy-10 pos-stick t-0 b-0 l-0 r-0 flex");
                __builder.OpenElement(27, "img");
                __builder.AddAttribute$5(28, "src", this.ResolvePath("img/icon.png", true, false, false));
                __builder.AddAttribute$5(29, "class", "mahx-07");
                __builder.CloseElement();
                __builder.AddMarkupContent(30, "\r\n            ");
                __builder.AddMarkupContent(31, "<div class=\"mgy-a stack mgl-2\"><h3 class=\"mg-0 cl-primary\" style=\"font-size: max(3.5vw, 15px);\">CampaignBot</h3>\r\n                <h5 class=\"mg-0 text-italic\">Direct one to one marketing tool</h5></div>\r\n            <div class=\"fill\"></div>\r\n            ");
                __builder.AddMarkupContent(32, "<a href=\"CampaignBot\" class=\"flex text-center cl-white bg-success corner-10 fsz-20 pdx-5\"><span class=\"mgy-a fw-bold\">\r\n                    START CAMPAIGN\r\n                </span></a>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(33, "\r\n    ");
                __builder.OpenElement(34, "div");
                __builder.AddAttribute$5(35, "class", "mawx10 mgx-a");
                __builder.OpenElement(36, "div");
                __builder.AddAttribute$6(37, "class");
                __builder.OpenElement(38, "div");
                __builder.AddAttribute$5(39, "class", "container clip pdx");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$5(41, "class", "row responsive");
                __builder.AddMarkupContent(42, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>\r\n                                Let the real people know about you\r\n                                and your business offerings\r\n                            </h1>\r\n                            <p>\r\n                                A buisness without marketing cannot survive and the competition tightens on daily basis.\r\n                            </p>\r\n                            <p>\r\n                                CampaignBot helps you with the hard part;\r\n                                telling your would-be customers about your products and\r\n                                services, while you focus on building a better products and profits.\r\n                            </p></div></div>\r\n                    ");
                __builder.OpenElement(43, "div");
                __builder.AddAttribute$5(44, "class", "col-5 flex");
                __builder.OpenElement(45, "div");
                __builder.AddAttribute$5(46, "class", "mgy-5 mgx-a wx-3 hx-3 round bg-fill");
                __builder.AddAttribute$5(47, "style", $.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/womanonphone.jpg", true, false, false)))) + "');");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(48, "\r\n        ");
                __builder.OpenElement(49, "div");
                __builder.AddAttribute$5(50, "class", "bg-gray-05");
                __builder.OpenElement(51, "div");
                __builder.AddAttribute$5(52, "class", "container clip");
                __builder.OpenElement(53, "div");
                __builder.AddAttribute$5(54, "class", "row responsive");
                __builder.OpenElement(55, "div");
                __builder.AddAttribute$5(56, "class", "col-5 flex");
                __builder.OpenElement(57, "img");
                __builder.AddAttribute$5(58, "src", this.ResolvePath("img/iot.jpg", true, false, false));
                __builder.AddAttribute$5(59, "class", "mawf hx-4 mg-a corner-5");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(60, "\r\n                    ");
                __builder.AddMarkupContent(61, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>The IOT future is here now.</h1>\r\n                            <p>\r\n                                Ask around, they would tell you that IOT(Internet of Things) is the future\r\n                                and is currently estimated\r\n                                to worth billions of dollars in the next few years.\r\n                            </p>\r\n                            <p>\r\n                                IOT find its applications in different sectors,\r\n                                ranging from health to smart homes and businesses,\r\n                                CampaignBot leverages on IOT to make your business benefit from the huge IOT market\r\n                                share.\r\n                            </p>\r\n                            <div class=\"flex flex-end mgb-10\"><a href=\"CampaignBot\" class=\"bg-success cl-white pd-5 d-block fsz-30 fw-bold\">Get Started Now</a></div></div></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(62, "\r\n        ");
                __builder.OpenElement(63, "div");
                __builder.AddAttribute$6(64, "class");
                __builder.OpenElement(65, "div");
                __builder.AddAttribute$5(66, "class", "container clip pdx");
                __builder.OpenElement(67, "div");
                __builder.AddAttribute$5(68, "class", "row responsive");
                __builder.AddMarkupContent(69, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>Take your businesses out of the information overload.</h1>\r\n                            <p>\r\n                                Since the advent of social media, the rate at which information is created\r\n                                online is alarming. Infact, before you finish reading this sentence, there are millions\r\n                                of new post created on social media.\r\n                            </p>\r\n                            <p>\r\n                                How then does your prospective customer gets to notice you amidst the loads\r\n                                of information on the social media. With <span class=\"cl-success fw-bold\">CampaignBot</span>,\r\n                                you stand out in the heart of your customer\r\n                                with a direct one to one campaign system.\r\n                            </p></div></div>\r\n                    ");
                __builder.OpenElement(70, "div");
                __builder.AddAttribute$5(71, "class", "col-5 mihx-2 bg-fill bg-no-repeat");
                __builder.AddAttribute$5(72, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/info-overload.jpg", true, false, false)))) + "');background-position-x:") + " right;");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(73, "\r\n        ");
                __builder.OpenElement(74, "div");
                __builder.AddAttribute$6(75, "class");
                __builder.OpenElement(76, "div");
                __builder.AddAttribute$5(77, "class", "container clip pdx");
                __builder.OpenElement(78, "div");
                __builder.AddAttribute$5(79, "class", "row responsive");
                __builder.OpenElement(80, "div");
                __builder.AddAttribute$5(81, "class", "col-5 mihx-2 bg-fill bg-no-repeat");
                __builder.AddAttribute$5(82, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/sfunnel.jpg", true, false, false)))) + "');background-position-x:") + " right;");
                __builder.CloseElement();
                __builder.AddMarkupContent(83, "\r\n                    ");
                __builder.AddMarkupContent(84, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>Automated Sales funnel</h1>\r\n                            <p>\r\n                                Let's face it, when you pitch your product to customers,\r\n                                most won't take action the first time.\r\n                            </p>\r\n                            <p>\r\n                                Perhaps few months down the line, they now need the product or service you offer,\r\n                                but many a times, they dont know how to contact you again.\r\n                            </p>\r\n                            <p>\r\n                                CampaignBot makes sure you dont loose contact with your target by automating\r\n                                follow-ups with them and keeping open your sales funnel.\r\n                            </p></div></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(85, "\r\n        ");
                __builder.OpenElement(86, "div");
                __builder.AddAttribute$6(87, "class");
                __builder.OpenElement(88, "div");
                __builder.AddAttribute$5(89, "class", "container clip pdx");
                __builder.OpenElement(90, "div");
                __builder.AddAttribute$5(91, "class", "row responsive");
                __builder.AddMarkupContent(92, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>\r\n                                Better and more cost effective that <i class=\"mdi mdi-radio cl-success\"></i>radio advert\r\n                            </h1>\r\n                            <p>\r\n                                Yes, we have all been there before,\r\n                                you just launch that great product or service and you want\r\n                                to blow its trumpet on air over a radio or tv program; but it costs <em>\r\n                                    two pairs of arm\r\n                                    and leg\r\n                                </em>.\r\n                            </p>\r\n                            <p>\r\n                                And you are to spend the money anyway, even if no one listen to the radio.\r\n                            </p>\r\n                            <p>\r\n                                With CampaignBot however, it's a pay as you call plan,\r\n                                you pay based on who picked your bot calls.\r\n                                They dont pickup, you don't pay for it. Easy-Peasy\r\n                            </p>\r\n                            <p>\r\n                                CampaignBot is billed on a per second call plan. Your campaign jingle is 15second,\r\n                                you spend as low as \u20A63.00 per target.\r\n                                You reach up to 1000 potential customers with as low as \u20A63000\r\n                            </p></div></div>\r\n                    ");
                __builder.OpenElement(93, "div");
                __builder.AddAttribute$5(94, "class", "col-5 mihx-2 bg-fill bg-no-repeat");
                __builder.AddAttribute$5(95, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/savemoney.jpg", true, false, false)))) + "');background-position-x:") + " right;");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(96, "\r\n        ");
                __builder.OpenElement(97, "div");
                __builder.AddAttribute$5(98, "class", " pdt-10");
                __builder.OpenElement(99, "div");
                __builder.AddAttribute$5(100, "class", "container clip pdx");
                __builder.OpenElement(101, "div");
                __builder.AddAttribute$5(102, "class", "row responsive");
                __builder.OpenElement(103, "div");
                __builder.AddAttribute$5(104, "class", "col-5");
                __builder.OpenElement(105, "div");
                __builder.AddAttribute$5(106, "class", "mgy-5 mgx-a wx-3 hx-3 round bg-fill");
                __builder.AddAttribute$5(107, "style", $.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/confused.jpg", true, false, false)))) + "');");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(108, "\r\n                    ");
                __builder.AddMarkupContent(109, "<div class=\"col-5 miwx-3\"><div class=\"pd-10\"><h1>No-nonsense Ad creation flow</h1>\r\n                            <p>\r\n                                Sometimes people forget that business owners are not IT specialist\r\n                                and they bombard you with hundreds of workflows and techno-jargons\r\n                                when creating your ad campaign on their platform.\r\n                            </p>\r\n                            <p>\r\n                                Not us though, all your campaign creation process with CampaignBot\r\n                                happen on one page, seamless, <span class=\"cl-success fw-bold\">Easy-Peasy</span></p></div></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(110, "\r\n        ");
                __builder.OpenElement(111, "div");
                __builder.AddAttribute$5(112, "class", "stack bg-fill");
                __builder.AddAttribute$5(113, "style", $.$strNN($.$strNN("background-image:" + " url('") + $.$strNN((this.ResolvePath("img/bg.jpg", true, false, false)))) + "');");
                __builder.AddMarkupContent(114, "<div class=\"bg-tertiary-09 pd-10\"><h1 class=\"text-center fsz-40 mgt-0\">\r\n                    It gets that easy with\r\n                    <span class=\"cl-success mdi mdi-robot nowrap\">CampaignBot</span></h1>\r\n                <p class=\"text-center\">\r\n                    We even offer you 3 minutes of free campaign to any contacts of your choice.\r\n                    Use this to test our services.\r\n                </p>\r\n                <div class=\"flex flex-center-x mgt-10\"><a href=\"CampaignBot\" class=\"bg-success cl-white corner-10 fsz-30 pdx-10 pdy-5 fw-bold\">\r\n                        START CAMPAIGN\r\n                    </a></div></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(115, "\r\n        ");
                __builder.AddMarkupContent(116, "<div class=\"stack pdx mgx-a\"><h1>Frequently Asked Questions</h1>\r\n            <div class=\"bg-success-01 pd-5 flex clickable\"><h2 class=\"mg-0 fill\">How does it work?</h2>\r\n                <i class=\"mdi mdi-chevron-down mgy-a\"></i></div>\r\n            <p>\r\n                Glad you asked!\r\n                Once we have your campaign jingle and we know the people you\r\n                want to sell your product to,\r\n                either by providing their contacts or we providing them\r\n                based on your required demographies, we deliver\r\n                a phone calls directly to their mobile phones while playing\r\n                your jingle to them once picked up.\r\n            </p>\r\n            <p>\r\n                Think of it as a radio advert only delivered directly to your customers and they dont even have to listen\r\n                to\r\n                a radio.\r\n            </p>\r\n            <div class=\"bg-success-01 pd-5 flex clickable\"><h2 class=\"mg-0 fill\">How do I get contacts?</h2>\r\n                <i class=\"mdi mdi-chevron-down mgy-a\"></i></div>\r\n            <p>\r\n                CampaignBot needs contacts to target the advert at. You can either provide this for the Bots or purchase\r\n                targeted contacts from us or any other third party\r\n            </p>\r\n            <div class=\"bg-success-01 pd-5 flex clickable\"><h2 class=\"mg-0 fill\">How can I be sure the campaign actually runs?</h2>\r\n                <i class=\"mdi mdi-chevron-down mgy-a\"></i></div>\r\n            <p>\r\n                Yes some platform and people actually do that,\r\n                they collect your funds for marketing and do nothing; since you probabbly wont know anyway.\r\n            </p>\r\n            <p>\r\n                Not us though. But we encourage our customers to mix in some of their\r\n                personal and friends contacts with their campaign contacts\r\n                so when they receive the campaign too, you can be sure our bots are doing their job.\r\n            </p></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(117, "\r\n\r\n    ");
                __builder.AddMarkupContent(118, "<div class=\"bg-success pd text-center\"><h3 class=\"mg-0\">CampaignBot is powered by Zoey.Africa</h3>\r\n        <small>A product of SAKE Innovations and Technologies (SIT)</small></div>");
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12885645770)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295711178)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295711178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295711178)
            
            //--TRIMMABLE-BOUNDARY-START(4295711178)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295711178)
            
            static $h = 743882;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590678474),
    {
      "p": $.$typeArray($.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475580362,
        "f": 50331682
      },
      "n": "Banners",
      "d": 743882,
      "h": 8590678474,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(8590678474),
//--TRIMMABLE-BOUNDARY-START(38655449546),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065514954,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 743882,
      "h": 38655449546,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655449546)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360482250),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 743882,
      "h": 34360482250,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360482250),
//--TRIMMABLE-BOUNDARY-START(12885645770),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 743882,
      "h": 12885645770,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885645770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295711178),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 743882,
      "h": 4295711178,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295711178)
  ],
  "h": 743882,
  "a": [
    {
      "t": $.$fPer.LCFCD.OpenGraphProviderServiceAttribute$$($.$tUzp.LCCCCS.CommunityCampaignBotApplication).$h,
      "c": Number(BigInt($.$fPer.LCFCD.OpenGraphProviderServiceAttribute$$($.$tUzp.LCCCCS.CommunityCampaignBotApplication).$h)|0x100000000n)
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/CampaignBotHome",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$tUzp.LCCCCP.CommunityCampaignBotLandingPage.Banner ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Pages.CommunityCampaignBotLandingPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Pages${separator}CommunityCampaignBotLandingPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(743882)
        
        

        //--TRIMMABLE-BOUNDARY-START(678346)
        $asm.$cls(`$tUzp.LCCCCP.CommunityCampaignBotApp`, ($self) => class CommunityCampaignBotApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(38655384010)
            /*CommunityCampaignBotService*/ CampaignBotService = null;
            //--TRIMMABLE-BOUNDARY-END(38655384010)
            
            //--TRIMMABLE-BOUNDARY-START(34360416714)
            /*CommunityCampaignBotApplication*/ CampaignBotApplication = null;
            //--TRIMMABLE-BOUNDARY-END(34360416714)
            
            //--TRIMMABLE-BOUNDARY-START(42950351306)
            /*CommunityCampaignBotWalletProvider*/ CoinIssuer = null;
            //--TRIMMABLE-BOUNDARY-END(42950351306)
            
            //--TRIMMABLE-BOUNDARY-START(94489958858)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(94489958858)
            
            //--TRIMMABLE-BOUNDARY-START(25770482122)
            /*ValueTask *//*async*/  Approve(/*CommunityCampaignBotPostModel*/ job)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770482122);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    job.State = 3/*CommunityCampaignBotState.Running*/;
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ job ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770482122)
            
            //--TRIMMABLE-BOUNDARY-START(103079893450)
            /*ValueTask *//*async*/  Reject(/*CommunityCampaignBotPostModel*/ job)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079893450);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let reason = ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Prompt($.$$.S.String, "Reason", null, "OK", "Cancel", null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    job.State = 5/*CommunityCampaignBotState.Rejected*/;
                    job.StateReason = reason;
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ job ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103079893450)
            
            //--TRIMMABLE-BOUNDARY-START(98784926154)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaignbotapp";
            }
            //--TRIMMABLE-BOUNDARY-END(98784926154)
            
            //--TRIMMABLE-BOUNDARY-START(90194991562)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194991562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.CampaignBotService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotService, serviceProvider);
                this.CampaignBotApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotApplication, serviceProvider);
                this.CoinIssuer = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$bTOs.LCCCCS.CommunityCampaignBotWalletProvider, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90194991562)
            
            //--TRIMMABLE-BOUNDARY-START(30065449418)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065449418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.CampaignBotApplication.Name));
                __builder.AddComponentParameter(2, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$ahDc.LCCCS.ApplicationExtension.GetBasePath(this.CampaignBotApplication, this.Navigation)));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.CampaignBotService));
                __builder.AddComponentParameter(4, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$vWqU.LCFCC.ThemePack.op_Implicit(this.CampaignBotApplication.Theme)));
                __builder.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, (1125027/*ApplicationFeatures.Default*/ | 524288/*ApplicationFeatures.RenderPageWhileViewModelIsNotLoaded*/)), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(6, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/**/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 7);
                        __builder2.AddComponentParameter(8, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(9, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $rzBkfa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                }), $UDlDpc ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":678346,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "NotAuthorizedView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.IApplicationPageComponent))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAuthentication, 11);
                        __builder2.AddComponentParameter(12, "Application", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityClientApplication, this.CampaignBotApplication));
                        __builder2.AddComponentParameter(13, "_BannerImage", this.ResolvePath("img/bg.jpg", true, false, false));
                        __builder2.CloseComponent();
                    }, $PxLCYf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                }), $JpsTvg ??= {"r":6881395,"p":[{"n":"context","p":4599881}],"n":"","d":678346,"h":0,"f":17825794}));
                __builder.AddAttribute$3(14, "LeftSideBarPrologue", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$4.MenuFeatures))().$ctor(this, ( (/*menuFeatures*/ menuFeatures) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySideBarPrologue, 15);
                        __builder2.AddComponentParameter(16, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, null));
                        __builder2.AddComponentParameter(17, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, menuFeatures), $.$hDPm.LCFCCM$4.MenuFeatures));
                        __builder2.CloseComponent();
                    }, $pGxWvd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                }), $mydRMh ??= {"r":6881395,"p":[{"n":"menuFeatures","p":36394666}],"n":"","d":678346,"h":0,"f":17825794}));
                __builder.AddAttribute$3(18, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 19);
                        __builder2.AddComponentParameter(20, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                        __builder2.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(22, wrap.View);
                        }), $latEJc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":678346,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $qkubmb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                }), $oDyrug ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":678346,"h":0,"f":17825794}));
                __builder.AddAttribute$3(23, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCU.CascadingValueReceiver$$($.$vWqU.LCFCC.BoxSize), 24);
                    __builder2.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize)))().$ctor(this, ( (/*box*/ box) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 26);
                            __builder3.AddComponentParameter(27, "Name", "CampaignHome");
                            __builder3.AddComponentParameter(28, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder3.AddAttribute$3(29, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(30, "Home");
                                }, $taqCfg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $XiOYkh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(31, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(32, "<i class=\"mdi mdi-home\"></i>");
                                }, $KMGKkc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $txBpdg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignHome, 34);
                                    __builder4.CloseComponent();
                                }, $uUkIcf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $BqGbPh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(35, "\r\n            ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 36);
                            __builder3.AddComponentParameter(37, "Name", "Transactions");
                            __builder3.AddComponentParameter(38, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Transactions")));
                            __builder3.AddAttribute$3(39, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(40, "Transactions");
                                }, $XVzOOg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $gokfma ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(41, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(42, "<i class=\"mdi mdi-cash\"></i>");
                                }, $TuNoWe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $DDwPoi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(43, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(44, "<h2 class=\"mgt-0\">Wallet Transaction</h2>\r\n                    ");
                                    __builder4.OpenElement(45, "CommunityCoinTransactions");
                                    __builder4.AddAttribute$5(46, "Issuer", "CoinIssuer");
                                    __builder4.CloseElement();
                                }, $Wsigqb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $TZmAje ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(47, "\r\n            ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 48);
                            __builder3.AddComponentParameter(49, "Name", "Jobs");
                            __builder3.AddComponentParameter(50, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Jobs")));
                            __builder3.AddAttribute$3(51, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(52, "Jobs");
                                }, $lPWRzk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $PsuVVi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(53, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(54, "<i class=\"mdi mdi-briefcase\"></i>");
                                }, $meQNYj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $JMdlsb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(55, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(56, "<h2 class=\"mgt-0\">Jobs</h2>\r\n                    ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListFilter$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 57);
                                    __builder4.AddAttribute$3(58, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter)))().$ctor(this, ( (/**/ filter) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 59);
                                            __builder5.AddComponentParameter(60, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                            __builder5.AddComponentParameter(61, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, $.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter).op_Implicit(filter)));
                                            __builder5.AddComponentParameter(62, "li-class", "bg-card mgy pd");
                                            __builder5.AddAttribute$3(63, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*campaign*/ campaign) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder6) =>
                                                {
                                                    __builder6.AddContent$1(64, $.$tUzp.LCCCCS$1.CampaignView.ListView(campaign.Data, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this,  () =>
                                                    {
                                                        return this.Approve(campaign.Data);
                                                    }, $qxwNoc ??= {"r":181338113,"n":"","d":678346,"h":0,"f":17825794}), new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this,  () =>
                                                    {
                                                        return this.Reject(campaign.Data);
                                                    }, $EHKksi ??= {"r":181338113,"n":"","d":678346,"h":0,"f":17825794})));
                                                }, $Phjorc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                                            }), $OMxcjf ??= {"r":6881395,"p":[{"n":"campaign","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                                            __builder5.SetKey($.$box(filter.Data.GetHashCode(), $.$$.S.Int32));
                                            __builder5.CloseComponent();
                                        }, $LXrizg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                                    }), $hXgJWf ??= {"r":6881395,"p":[{"n":"filter","p":$.$hDPm.LCFCI.ContainerContext$$($.$fPer.LCFCD.DataFilter).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $llFKqb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $eXybKd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(65, "\r\n            ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 66);
                            __builder3.AddComponentParameter(67, "Name", "Bots");
                            __builder3.AddComponentParameter(68, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Bots")));
                            __builder3.AddAttribute$3(69, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(70, "Bots");
                                }, $xrCAih ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $dlAUHk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(71, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(72, "<i class=\"mdi mdi-robot\"></i>");
                                }, $FaFzBe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $ALiaQb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(73, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(74, "<h2 class=\"mgt-0\">Bots</h2>\r\n                    ");
                                    __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignBotsView, 75);
                                    __builder4.CloseComponent();
                                }, $JPirxe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $SfkOud ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(76, "\r\n            ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 77);
                            __builder3.AddComponentParameter(78, "Name", "CampaignEdit");
                            __builder3.AddComponentParameter(79, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ & ~256/*ApplicationPageFeatures.ParameterRequired*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                            __builder3.AddComponentParameter(80, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Edit/${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}`)));
                            __builder3.AddComponentParameter(81, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*e*/ e) =>
                            {
                                return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutContentMaxWidth(e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 900);
                            }), $Zakyma ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(82, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$4(83, "Create Campaign");
                                }, $KHGFIa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $ZFztAf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(84, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(85, "<i class=\"mdi mdi-pencil\"></i>");
                                }, $FlOPcd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $iAyrnk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(86, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(87, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignEditor, 88);
                                            __builder5.AddComponentParameter(89, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, e));
                                            __builder5.CloseComponent();
                                        }, $ohjhLa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                                    }, $UCulSf ??= {"r":6881395,"p":[{"n":"e","p":1863683}],"n":"","d":678346,"h":0,"f":17825794}), null, true));
                                }, $LkkhMi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $Wjjxoj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(90, "\r\n            ");
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 91);
                            __builder3.AddComponentParameter(92, "Name", "CampaignView");
                            __builder3.AddComponentParameter(93, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Post/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                            __builder3.AddComponentParameter(94, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/**/ e) =>
                            {
                                return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutContentMaxWidth(e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 900);
                            }), $JfvMJg ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(95, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(96, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                                    {
                                        return e.Title;
                                    }, $btKTvj ??= {"r":131073,"p":[{"n":"e","p":1863683}],"n":"","d":678346,"h":0,"f":17825794}), true));
                                }, $JfZzya ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $FhURml ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(97, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(98, "<i class=\"mdi mdi-megaphone\"></i>");
                                }, $YXFYNd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $sjKdBi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(99, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddContent$1(100, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            if (e.State >= 1/*CommunityCampaignBotState.Published*/)
                                            {
                                                __builder5.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignView, 101);
                                                __builder5.AddComponentParameter(102, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, e));
                                                __builder5.CloseComponent();
                                            }
                                            else 
                                            {
                                                __builder5.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignEditor, 103);
                                                __builder5.AddComponentParameter(104, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, e));
                                                __builder5.CloseComponent();
                                            }
                                        }, $VOWFuf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                                    }, $WKxjZd ??= {"r":6881395,"p":[{"n":"e","p":1863683}],"n":"","d":678346,"h":0,"f":17825794}), null, true));
                                }, $VqAfrf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                            }), $jdHoHd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $TgBJdd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":678346,"h":0,"f":17825794});
                    }), $TgJejj ??= {"r":6881395,"p":[{"n":"box","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.BoxSize).$h}],"n":"","d":678346,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $VGGqfb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":678346,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(30065449418)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475514826)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475514826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475514826)
            
            //--TRIMMABLE-BOUNDARY-START(21475514826)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475514826)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655384010)
                this.CampaignBotService = null;
                //--TRIMMABLE-BOUNDARY-END(38655384010)
                
                //--TRIMMABLE-BOUNDARY-START(34360416714)
                this.CampaignBotApplication = null;
                //--TRIMMABLE-BOUNDARY-END(34360416714)
                
                //--TRIMMABLE-BOUNDARY-START(42950351306)
                this.CoinIssuer = null;
                //--TRIMMABLE-BOUNDARY-END(42950351306)
                
                //--TRIMMABLE-BOUNDARY-START(94489958858)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(94489958858)
                
            }
            static $h = 678346;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655384010),
    {
      "p": 1071562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130220490,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259762634,
        "f": 83886081
      },
      "n": "CampaignBotService",
      "d": 678346,
      "h": 38655384010,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655384010),
//--TRIMMABLE-BOUNDARY-START(34360416714),
    {
      "p": 1006026,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540285898,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669828042,
        "f": 83886081
      },
      "n": "CampaignBotApplication",
      "d": 678346,
      "h": 34360416714,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360416714),
//--TRIMMABLE-BOUNDARY-START(42950351306),
    {
      "p": 4026371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720155082,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849697226,
        "f": 83886081
      },
      "n": "CoinIssuer",
      "d": 678346,
      "h": 42950351306,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950351306),
//--TRIMMABLE-BOUNDARY-START(94489958858),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310089674,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439631818,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 678346,
      "h": 94489958858,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489958858),
//--TRIMMABLE-BOUNDARY-START(98784926154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900024266,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 678346,
      "h": 98784926154,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98784926154)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770482122),
    {
      "r": 181338113,
      "p": [
        {
          "n": "job",
          "p": 1863683
        }
      ],
      "n": "Approve",
      "d": 678346,
      "h": 25770482122,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(25770482122),
//--TRIMMABLE-BOUNDARY-START(103079893450),
    {
      "r": 181338113,
      "p": [
        {
          "n": "job",
          "p": 1863683
        }
      ],
      "n": "Reject",
      "d": 678346,
      "h": 103079893450,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(103079893450),
//--TRIMMABLE-BOUNDARY-START(90194991562),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 678346,
      "h": 90194991562,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194991562),
//--TRIMMABLE-BOUNDARY-START(30065449418),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 678346,
      "h": 30065449418,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065449418)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475514826),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 678346,
      "h": 21475514826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475514826)
  ],
  "h": 678346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Pages.CommunityCampaignBotApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Pages${separator}CommunityCampaignBotApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(678346)
        
        

        //--TRIMMABLE-BOUNDARY-START(874954)
        $asm.$cls(`$tUzp.LCCCCP.Index`, ($self) => class Index extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42950547914)
            /*bool*/ hasBegin = false;
            //--TRIMMABLE-BOUNDARY-END(42950547914)
            
            //--TRIMMABLE-BOUNDARY-START(47245515210)
            /*bool?*/ Launch = null;
            //--TRIMMABLE-BOUNDARY-END(47245515210)
            
            //--TRIMMABLE-BOUNDARY-START(12885776842)
            /*void */ Begin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885776842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.hasBegin = true;
            }
            //--TRIMMABLE-BOUNDARY-END(12885776842)
            
            //--TRIMMABLE-BOUNDARY-START(21475711434)
            /*void */ End()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475711434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.hasBegin = false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475711434)
            
            //--TRIMMABLE-BOUNDARY-START(51540482506)
            /*Task */ OnAfterRenderAsync(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540482506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender && this.Launch === true)
                {
                    this.Begin();
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor\\Index.razor.cs", "OnAfterRenderAsync", 38);
                }
                return super.OnAfterRenderAsync(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(51540482506)
            
            //--TRIMMABLE-BOUNDARY-START(55835449802)
            /*string */ get OptimizedComponentName()
            {
                return "index";
            }
            //--TRIMMABLE-BOUNDARY-END(55835449802)
            
            //--TRIMMABLE-BOUNDARY-START(68720351690)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720351690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Launch":
                    this.Launch = $.$cast(parameter.Value, $.$$.S.Nullable$$($.$$.S.Boolean));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(68720351690)
            
            //--TRIMMABLE-BOUNDARY-START(17180744138)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180744138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "bg-fill");
                __builder.AddAttribute$5(2, "style", $.$strNN($.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("img/banner.jpg", true, true, false)))) + ");background-position:") + " center;");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "bg-dark-03 ");
                __builder.OpenElement(5, "div");
                __builder.AddAttribute$5(6, "class", "flex pd cl-white mgx-a");
                __builder.AddAttribute$5(7, "style", "max-width: 1200px;");
                __builder.OpenElement(8, "div");
                __builder.AddAttribute$5(9, "class", "flex");
                __builder.OpenElement(10, "img");
                __builder.AddAttribute$5(11, "src", this.ResolvePath("img/icon.png", true, true, false));
                __builder.AddAttribute$5(12, "class", "mahx-05");
                __builder.CloseElement();
                __builder.AddMarkupContent(13, "\r\n                ");
                __builder.AddMarkupContent(14, "<h1 class=\"mgy-a mgl\">CampaignBot</h1>");
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n            ");
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", "mgl-a pos-rel");
                __builder.OpenElement(18, "popup");
                __builder.AddMarkupContent(19, "<button class=\"bg-transparent mdi mdi-account pdx-5 pdy fsz-25\"></button>\r\n                    ");
                __builder.OpenElement(20, "pop");
                __builder.AddAttribute$5(21, "class", "at righttoright toptobottom wx-2 bg-card pd-5 corner-5 shadow drop cl-text");
                __builder.AddContent$1(22, this.UnitOfWork.LCFCI$IClientUnitOfWork$ClientAuthentication.LCFCI$IClientAuthenticationService$ProfileView(null, null));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(23, "\r\n        ");
                __builder.OpenElement(24, "div");
                __builder.AddAttribute$5(25, "class", "row col-2 mgx-a");
                __builder.AddAttribute$5(26, "style", "max-width: 1200px;");
                __builder.OpenElement(27, "div");
                __builder.AddAttribute$5(28, "class", "cl-white pdx-10 pdb-10");
                __builder.AddMarkupContent(29, "<h1 class=\"mgb-0\">Reach Millions</h1>\r\n                ");
                __builder.AddMarkupContent(30, "<h1 class=\"mgt-0\">One Call at a time.</h1>\r\n                ");
                __builder.AddMarkupContent(31, "<h3>Deliver your message directly to your audience with automated voice calls.</h3>\r\n                ");
                __builder.OpenElement(32, "div");
                __builder.AddAttribute$5(33, "class", "flex");
                __builder.OpenElement(34, "button");
                __builder.AddAttribute$5(35, "class", "miwx-1 corner pd fw-bold fsz-16 cl-white");
                __builder.AddAttribute$5(36, "style", "background: linear-gradient(to bottom,#ef6848, #c33722)");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 37, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Begin)));
                __builder.AddMarkupContent(38, "\r\n                        Start Your Campaign\r\n                    ");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(39, "\r\n\r\n");
                __builder.OpenElement(40, "section");
                __builder.AddAttribute$5(41, "class", "pd-10");
                __builder.AddMarkupContent(42, "<div class=\"flex\"><div class=\"fill flex mgr-10\"><div class=\"fill bdt bdw-2 mgy-a\"></div></div>\r\n        <h1 class=\"cl-primary text-center\">How It Works</h1>\r\n        <div class=\"fill flex mgl-10\"><div class=\"fill bdt bdw-2 mgy-a\"></div></div></div>\r\n    ");
                __builder.OpenElement(43, "div");
                __builder.AddAttribute$5(44, "class", "flex flex-spacebetween flow mgx-a");
                __builder.AddAttribute$5(45, "style", "max-width: 1200px;");
                __builder.OpenElement(46, "div");
                __builder.AddAttribute$5(47, "class", "stack text-center miwx-2 mg");
                __builder.OpenElement(48, "img");
                __builder.AddAttribute$5(49, "src", this.ResolvePath("img/upload-jingle.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(50, "\r\n            ");
                __builder.AddMarkupContent(51, "<h3 class=\"mgx-a mgb-0 bdb bdw-2\" style=\"border-color:#acbfd2\">Upload Your Jingle</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(52, "\r\n        ");
                __builder.OpenElement(53, "div");
                __builder.AddAttribute$5(54, "class", "stack text-center mg");
                __builder.OpenElement(55, "img");
                __builder.AddAttribute$5(56, "class", "mgy-a");
                __builder.AddAttribute$5(57, "src", this.ResolvePath("img/arrow.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(58, "\r\n            ");
                __builder.AddMarkupContent(59, "<h3 class=\"mgx-a mgb-0\">&nbsp;</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(60, "\r\n        ");
                __builder.OpenElement(61, "div");
                __builder.AddAttribute$5(62, "class", "stack text-center miwx-2 mg");
                __builder.OpenElement(63, "img");
                __builder.AddAttribute$5(64, "src", this.ResolvePath("img/upload-contacts.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(65, "\r\n            ");
                __builder.AddMarkupContent(66, "<h3 class=\"mgx-a mgb-0 bdb bdw-2\" style=\"border-color:#115b3f\">Upload Contacts</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(67, "\r\n        ");
                __builder.OpenElement(68, "div");
                __builder.AddAttribute$5(69, "class", "stack text-center mg");
                __builder.OpenElement(70, "img");
                __builder.AddAttribute$5(71, "class", "mgy-a");
                __builder.AddAttribute$5(72, "src", this.ResolvePath("img/arrow.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(73, "\r\n            ");
                __builder.AddMarkupContent(74, "<h3 class=\"mgx-a mgb-0\">&nbsp;</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(75, "\r\n        ");
                __builder.OpenElement(76, "div");
                __builder.AddAttribute$5(77, "class", "stack text-center miwx-2 mg");
                __builder.OpenElement(78, "img");
                __builder.AddAttribute$5(79, "src", this.ResolvePath("img/make-calls.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(80, "\r\n            ");
                __builder.AddMarkupContent(81, "<h3 class=\"mgx-a mgb-0 bdb bdw-2\" style=\"border-color:#b29c53\">CampaignBot calls</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(82, "\r\n        ");
                __builder.OpenElement(83, "div");
                __builder.AddAttribute$5(84, "class", "stack text-center mg");
                __builder.OpenElement(85, "img");
                __builder.AddAttribute$5(86, "class", "mgy-a");
                __builder.AddAttribute$5(87, "src", this.ResolvePath("img/arrow.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(88, "\r\n            ");
                __builder.AddMarkupContent(89, "<h3 class=\"mgx-a mgb-0\">&nbsp;</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(90, "\r\n        ");
                __builder.OpenElement(91, "div");
                __builder.AddAttribute$5(92, "class", "stack text-center miwx-2 mg");
                __builder.OpenElement(93, "img");
                __builder.AddAttribute$5(94, "src", this.ResolvePath("img/track-results.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(95, "\r\n            ");
                __builder.AddMarkupContent(96, "<h3 class=\"mgx-a mgb-0 bdb bdw-2\" style=\"border-color:#70ab57\">Track Results</h3>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(97, "\r\n\r\n");
                __builder.OpenElement(98, "section");
                __builder.AddAttribute$5(99, "class", "pd-10 stack bg-fill");
                __builder.AddAttribute$5(100, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("img/banner-2.jpg", true, true, false)))) + ");");
                __builder.AddMarkupContent(101, "<div class=\"flex\"><div class=\"fill flex mgr-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #7db1a9;\"></div></div>\r\n        <h1 class=\"cl-primary text-center\">Built for High-Impact Campaigns</h1>\r\n        <div class=\"fill flex mgl-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #7db1a9;\"></div></div></div>\r\n    ");
                __builder.OpenElement(102, "div");
                __builder.AddAttribute$5(103, "class", "scroll");
                __builder.OpenElement(104, "div");
                __builder.AddAttribute$5(105, "class", "grid colm-25 gap-1 mgx-a");
                __builder.AddAttribute$5(106, "style", "max-width: 1200px;");
                __builder.OpenElement(107, "div");
                __builder.AddAttribute$5(108, "class", "bg-card corner sd miwx-2 stack");
                __builder.OpenElement(109, "div");
                __builder.AddAttribute$5(110, "class", "flex bdb pd");
                __builder.OpenElement(111, "img");
                __builder.AddAttribute$5(112, "src", this.ResolvePath("img/dart.jpg", true, true, false));
                __builder.AddAttribute$5(113, "class", "mgy-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(114, "\r\n                    ");
                __builder.AddMarkupContent(115, "<h3 class=\"mgy-a mgl\">One-on-One Engagement</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(116, "\r\n                ");
                __builder.AddMarkupContent(117, "<div class=\"mgt-a pd text-center\" style=\"background: linear-gradient(to bottom, #FFF, #e8efdb);\"><b class=\"mg-0 op-8\">Speak directly to your audience.</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(118, "\r\n            ");
                __builder.OpenElement(119, "div");
                __builder.AddAttribute$5(120, "class", "bg-card corner sd miwx-2 stack");
                __builder.OpenElement(121, "div");
                __builder.AddAttribute$5(122, "class", "flex bdb pd");
                __builder.OpenElement(123, "img");
                __builder.AddAttribute$5(124, "src", this.ResolvePath("img/trumpet.jpg", true, true, false));
                __builder.AddAttribute$5(125, "class", "mgy-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(126, "\r\n                    ");
                __builder.AddMarkupContent(127, "<h3 class=\"mgy-a mgl\">Guaranteed Message Delivery</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(128, "\r\n                ");
                __builder.AddMarkupContent(129, "<div class=\"mgt-a pd text-center\" style=\"background: linear-gradient(to bottom, #FFF, #f3eac8);\"><b class=\"mg-0 op-8\">Play your campaign message instantly.</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(130, "\r\n            ");
                __builder.OpenElement(131, "div");
                __builder.AddAttribute$5(132, "class", "bg-card corner sd miwx-2 stack");
                __builder.OpenElement(133, "div");
                __builder.AddAttribute$5(134, "class", "flex bdb pd");
                __builder.OpenElement(135, "img");
                __builder.AddAttribute$5(136, "src", this.ResolvePath("img/data.jpg", true, true, false));
                __builder.AddAttribute$5(137, "class", "mgy-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(138, "\r\n                    ");
                __builder.AddMarkupContent(139, "<h3 class=\"mgy-a mgl\">Data-Driven Insights</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(140, "\r\n                ");
                __builder.AddMarkupContent(141, "<div class=\"mgt-a pd text-center\" style=\"background: linear-gradient(to bottom, #FFF, #ccdeca);\"><b class=\"mg-0 op-8\">Track pickups, rejections and listen time.</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(142, "\r\n            ");
                __builder.OpenElement(143, "div");
                __builder.AddAttribute$5(144, "class", "bg-card corner sd miwx-2 stack");
                __builder.OpenElement(145, "div");
                __builder.AddAttribute$5(146, "class", "flex bdb pd");
                __builder.OpenElement(147, "img");
                __builder.AddAttribute$5(148, "src", this.ResolvePath("img/user.jpg", true, true, false));
                __builder.AddAttribute$5(149, "class", "mgy-a");
                __builder.CloseElement();
                __builder.AddMarkupContent(150, "\r\n                    ");
                __builder.AddMarkupContent(151, "<h3 class=\"mgy-a mgl\">Higher Conversions</h3>");
                __builder.CloseElement();
                __builder.AddMarkupContent(152, "\r\n                ");
                __builder.AddMarkupContent(153, "<div class=\"mgt-a pd text-center\" style=\"background: linear-gradient(to bottom, #FFF, #deebd9);\"><b class=\"mg-0 op-8\">Boost your sales and engagements.</b></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(154, "\r\n\r\n");
                __builder.OpenElement(155, "section");
                __builder.AddAttribute$5(156, "class", "pd-10");
                __builder.AddMarkupContent(157, "<div class=\"flex\"><div class=\"fill flex mgr-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #cfd1d2;\"></div></div>\r\n        <h1 class=\"cl-primary text-center\">Perfect for Every Industry</h1>\r\n        <div class=\"fill flex mgl-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #cfd1d2;\"></div></div></div>\r\n    ");
                __builder.OpenElement(158, "div");
                __builder.AddAttribute$5(159, "class", "scroll-x flex");
                __builder.OpenElement(160, "div");
                __builder.AddAttribute$5(161, "class", "flex mgx-a");
                __builder.OpenElement(162, "div");
                __builder.AddAttribute$5(163, "class", "stack miwx-2");
                __builder.OpenElement(164, "img");
                __builder.AddAttribute$5(165, "src", this.ResolvePath("img/political-campaign.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(166, "\r\n                ");
                __builder.AddMarkupContent(167, "<div class=\"pd text-center corner-b-5\" style=\"background-color:#eaeff3\"><b class=\"mg-0\">Political Campaigns</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(168, "\r\n            ");
                __builder.OpenElement(169, "div");
                __builder.AddAttribute$5(170, "class", "stack miwx-2");
                __builder.OpenElement(171, "img");
                __builder.AddAttribute$5(172, "src", this.ResolvePath("img/product-promotion.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(173, "\r\n                ");
                __builder.AddMarkupContent(174, "<div class=\"pd text-center corner-b-5\" style=\"background-color:#f1f3f2\"><b class=\"mg-0\">Product Promotion</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(175, "\r\n            ");
                __builder.OpenElement(176, "div");
                __builder.AddAttribute$5(177, "class", "stack miwx-2");
                __builder.OpenElement(178, "img");
                __builder.AddAttribute$5(179, "src", this.ResolvePath("img/corporate-announcement.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(180, "\r\n                ");
                __builder.AddMarkupContent(181, "<div class=\"pd text-center corner-b-5\" style=\"background-color:#faf3e1\"><b class=\"mg-0\">Corporate Announcements</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(182, "\r\n            ");
                __builder.OpenElement(183, "div");
                __builder.AddAttribute$5(184, "class", "stack miwx-2");
                __builder.OpenElement(185, "img");
                __builder.AddAttribute$5(186, "src", this.ResolvePath("img/event-notification.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(187, "\r\n                ");
                __builder.AddMarkupContent(188, "<div class=\"pd text-center corner-b-5\" style=\"background-color:#f6f4e9\"><b class=\"mg-0\">Event Notifications</b></div>");
                __builder.CloseElement();
                __builder.AddMarkupContent(189, "\r\n            ");
                __builder.OpenElement(190, "div");
                __builder.AddAttribute$5(191, "class", "stack miwx-2");
                __builder.OpenElement(192, "img");
                __builder.AddAttribute$5(193, "src", this.ResolvePath("img/public-awareness.jpg", true, true, false));
                __builder.CloseElement();
                __builder.AddMarkupContent(194, "\r\n                ");
                __builder.AddMarkupContent(195, "<div class=\"pd text-center corner-b-5\" style=\"background-color:#dfebed\"><b class=\"mg-0\">Public Awareness</b></div>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(196, "\r\n    \r\n");
                __builder.OpenElement(197, "section");
                __builder.AddAttribute$5(198, "class", "pd-10 bg-fill");
                __builder.AddAttribute$5(199, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("img/banner-3.jpg", true, true, false)))) + ")");
                __builder.AddMarkupContent(200, "<div class=\"flex\"><div class=\"fill flex mgr-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #a6c7c4;\"></div></div>\r\n        <h1 class=\"cl-primary text-center\">Real-Time Campaign Analytics</h1>\r\n        <div class=\"fill flex mgl-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #a6c7c4;\"></div></div></div>\r\n    ");
                __builder.OpenElement(201, "img");
                __builder.AddAttribute$5(202, "src", this.ResolvePath("img/analytics.jpg", true, true, false));
                __builder.AddAttribute$5(203, "class", "d-block mgx-a mawf");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(204, "\r\n\r\n");
                __builder.OpenElement(205, "section");
                __builder.AddAttribute$5(206, "class", "pd-10 bg-fill stack");
                __builder.AddAttribute$5(207, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("img/banner-4.jpg", true, true, false)))) + ");");
                __builder.AddMarkupContent(208, "<div class=\"flex\"><div class=\"fill flex mgr-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #cfd1d2;\"></div></div>\r\n        <h1 class=\"cl-white text-center\">Ready to Reach Your Audience Like Never Before?</h1>\r\n        <div class=\"fill flex mgl-10\"><div class=\"fill bdt bdw-2 mgy-a\" style=\"border-color: #cfd1d2;\"></div></div></div>\r\n    ");
                __builder.OpenElement(209, "div");
                __builder.AddAttribute$5(210, "class", "flex mgx-a");
                __builder.OpenElement(211, "button");
                __builder.AddAttribute$5(212, "class", "miwx-1  corner pd fw-bold fsz-16 cl-white");
                __builder.AddAttribute$5(213, "style", "background: linear-gradient(to bottom,#ef6848, #c33722)");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 214, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Begin)));
                __builder.AddMarkupContent(215, "\r\n            Start Your Campaign\r\n        ");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(216, "\r\n\r\n");
                __builder.AddMarkupContent(217, "<section class=\"pd-10 bg-fill flex\"><h3 class=\"mg-a cl-primary text-center\">\r\n        SAKE INNOVATIONS AND TECHNOLOGIES, 2026\r\n    </h3></section>");
                if (this.hasBegin)
                {
                    __builder.OpenElement(218, "div");
                    __builder.AddAttribute$5(219, "class", "pos-fix t-0 b-0 l-0 r-0 bg-dark-05 flex scroll");
                    __builder.OpenComponent$1($.$tUzp.LCCCCS$1.Dashboard, 220);
                    __builder.AddComponentParameter(221, "OnClose", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback, $.$mac.MAC.EventCallback.Factory.Create$1(this, new $.$$.S.Action().$ctor(this, this.End))));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180744138)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590809546)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590809546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590809546)
            
            //--TRIMMABLE-BOUNDARY-START(8590809546)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590809546)
            
            static $h = 874954;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245515210),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065646026,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425384394,
        "f": 83886081
      },
      "n": "Launch",
      "d": 874954,
      "h": 47245515210,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 12386419,
          "c": 8602321011,
          "n": [
            {
              "n": "Name",
              "v": "launch",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245515210),
//--TRIMMABLE-BOUNDARY-START(55835449802),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655580618,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 874954,
      "h": 55835449802,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835449802)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885776842),
    {
      "r": 65537,
      "n": "Begin",
      "d": 874954,
      "h": 12885776842,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885776842),
//--TRIMMABLE-BOUNDARY-START(21475711434),
    {
      "r": 65537,
      "n": "End",
      "d": 874954,
      "h": 21475711434,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475711434),
//--TRIMMABLE-BOUNDARY-START(51540482506),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 874954,
      "h": 51540482506,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540482506),
//--TRIMMABLE-BOUNDARY-START(68720351690),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 874954,
      "h": 68720351690,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720351690),
//--TRIMMABLE-BOUNDARY-START(17180744138),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 874954,
      "h": 17180744138,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180744138)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950547914),
    {
      "t": 262145,
      "n": "hasBegin",
      "d": 874954,
      "h": 42950547914,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950547914)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590809546),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 874954,
      "h": 8590809546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590809546)
  ],
  "h": 874954,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "Campaign Bot",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Deliver your message directly to your audience with automated voice calls.",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "CampaignBot",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.Community.CampaignBot.Resources/img/icon.png",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/CampaignBot",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Pages.Index`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Pages${separator}Index`; }
        });
        //--TRIMMABLE-BOUNDARY-END(874954)
        
        

        //--TRIMMABLE-BOUNDARY-START(1202634)
        $asm.$cls(`$tUzp.LCCCCS$1.CommunityCampaignBotsView`, ($self) => class CommunityCampaignBotsView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(51540810186)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaignbotsview";
            }
            //--TRIMMABLE-BOUNDARY-END(51540810186)
            
            //--TRIMMABLE-BOUNDARY-START(42950875594)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950875594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.PipeFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(42950875594)
            
            //--TRIMMABLE-BOUNDARY-START(60130744778)
            /*IMessagePipeFactory*/ PipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(60130744778)
            
            //--TRIMMABLE-BOUNDARY-START(12886104522)
            /*Dictionary<string, CommunityCampaignBotDeviceStateModel>*/ bots = null;
            //--TRIMMABLE-BOUNDARY-END(12886104522)
            
            //--TRIMMABLE-BOUNDARY-START(55835777482)
            /*IMessagePipe?*/ pipe = null;
            //--TRIMMABLE-BOUNDARY-END(55835777482)
            
            //--TRIMMABLE-BOUNDARY-START(47245842890)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245842890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pipe = ($t1 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.PipeFactory, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("CampaignBotsStatus"), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.pipe.LCFCM$IMessagePipe$Subscribe($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, new ($.$$.S.Action$$($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel))().$ctor(this,  (/*stat*/ stat) =>
                    {
                        this.bots.set_Item(stat.Id, $.$clone(stat));
                        let $en2 = $.$sl.SL.Enumerable.ToList($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel), this.bots).GetEnumerator();
                        while ($en2.MoveNext())
                        {
                            let bot = $en2.Current;
                            {
                                if ($.$$.S.TimeSpan.op_GreaterThan($.$$.S.DateTime.UtcNow - bot.Value.LastSeenOnline, $.$$.S.TimeSpan.FromMinutes$2(5n)))
                                {
                                    this.bots.Remove$1(bot.Value.Id);
                                }
                            }
                        }
                        _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor\\CommunityCampaignBotsView.razor.cs", "OnInitializedAsync", 31);
                    }, $NKVjfc ??= {"r":65537,"p":[{"n":"stat","p":1339395}],"n":"","d":1202634,"h":0,"f":17825794}));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245842890)
            
            //--TRIMMABLE-BOUNDARY-START(21476039114)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476039114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.pipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(21476039114)
            
            //--TRIMMABLE-BOUNDARY-START(17181071818)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181071818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.bots.Count === 0)
                {
                    __builder.AddMarkupContent(0, "<div class=\"stack bg-card pd\"><i class=\"mdi mdi-robot d-block mgx-a fsz-100 cl-success\"></i>\r\n        <h3 class=\"mg-0 text-center\">No CampaignBot is online at the moment</h3></div>");
                }
                else 
                {
                    __builder.OpenElement(1, "div");
                    __builder.AddAttribute$5(2, "class", "grid gap-1 colm-25");
                    let $en4 = this.bots.GetEnumerator();
                    while ($en4.MoveNext())
                    {
                        let bot = $en4.Current;
                        {
                            __builder.AddMarkupContent(3, "<div class=\"bg-card pd\"></div>");
                        }
                    }
                    __builder.CloseElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181071818)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591137226)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591137226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591137226)
            
            //--TRIMMABLE-BOUNDARY-START(8591137226)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591137226)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130744778)
                this.PipeFactory = null;
                //--TRIMMABLE-BOUNDARY-END(60130744778)
                
                //--TRIMMABLE-BOUNDARY-START(12886104522)
                this.bots = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12886104522)
                
            }
            static $h = 1202634;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540810186),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065973706,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1202634,
      "h": 51540810186,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540810186),
//--TRIMMABLE-BOUNDARY-START(60130744778),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655908298,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720679370,
        "f": 83886081
      },
      "n": "PipeFactory",
      "d": 1202634,
      "h": 60130744778,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130744778)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950875594),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1202634,
      "h": 42950875594,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950875594),
//--TRIMMABLE-BOUNDARY-START(47245842890),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1202634,
      "h": 47245842890,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(47245842890),
//--TRIMMABLE-BOUNDARY-START(21476039114),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1202634,
      "h": 21476039114,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476039114),
//--TRIMMABLE-BOUNDARY-START(17181071818),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1202634,
      "h": 17181071818,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181071818)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886104522),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel).$h,
      "n": "bots",
      "d": 1202634,
      "h": 12886104522,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886104522),
//--TRIMMABLE-BOUNDARY-START(55835777482),
    {
      "t": 341468,
      "n": "pipe",
      "d": 1202634,
      "h": 55835777482,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835777482)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591137226),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1202634,
      "h": 8591137226,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591137226)
  ],
  "h": 1202634
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.CommunityCampaignBotsView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CommunityCampaignBotsView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1202634)
        
        

        //--TRIMMABLE-BOUNDARY-START(1333706)
        $asm.$cls(`$tUzp.LCCCCS$1.CommunityCampaignHome`, ($self) => class CommunityCampaignHome extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(107375516106)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaignhome";
            }
            //--TRIMMABLE-BOUNDARY-END(107375516106)
            
            //--TRIMMABLE-BOUNDARY-START(85900679626)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900679626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotService, serviceProvider);
                this.CampaignCoin = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$bTOs.LCCCCS.CommunityCampaignBotWalletProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(85900679626)
            
            //--TRIMMABLE-BOUNDARY-START(124555385290)
            /*CommunityCampaignBotService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(124555385290)
            
            //--TRIMMABLE-BOUNDARY-START(38656039370)
            /*CommunityCampaignBotWalletProvider*/ CampaignCoin = null;
            //--TRIMMABLE-BOUNDARY-END(38656039370)
            
            //--TRIMMABLE-BOUNDARY-START(98785581514)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(98785581514)
            
            //--TRIMMABLE-BOUNDARY-START(94490614218)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94490614218)
            
            //--TRIMMABLE-BOUNDARY-START(111670483402)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(111670483402)
            
            //--TRIMMABLE-BOUNDARY-START(111670483402)
            //--TRIMMABLE-BOUNDARY-START(30066104778)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066104778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066104778)
            
            //--TRIMMABLE-BOUNDARY-START(120260417994)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260417994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(120260417994)
            
            //--TRIMMABLE-BOUNDARY-END(111670483402)
            
            //--TRIMMABLE-BOUNDARY-START(90195646922)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195646922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90195646922)
            
            //--TRIMMABLE-BOUNDARY-START(103080548810)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080548810);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        try
                        {
                            let $t1, $r1;
                            /*var*/ let coinIssued = ($t1 = $.$OJJQ.LCFCW.CommunityCoinsRemoteServiceExtension.IssueCoinIfNoneExists(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(this.CampaignCoin, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.CampaignCoin.CoinDescriptors)), 5/*CommunityCampaignBotApplication.NewUserFreeMinutes*/, "Free Welcome Coin"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            if (coinIssued)
                            {
                                let $t2, $r2;
                                /*CancellationTokenSource*/ let src = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                                src.CancelAfter(7000);
                                ($t2 = this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCC$IUIService$Prompt.LCFCC$IUIPromptService$Toast(`You have been awarded 10 units of free CampaignBot Coin. Use it to jumpstart your product/service campaign!`, src.Token), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            }
                        }
                        catch($e)
                        {
                        }
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080548810)
            
            //--TRIMMABLE-BOUNDARY-START(163210090954)
            /*ValueTask */ Topup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210090954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t4, $r4;
                        ($t4 = this.Service.Topup(null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    });
                }, $qylYSd ??= {"r":181338113,"n":"","d":1333706,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                {
                    return (this.PropertyChanged?.Invoke(this, pn) ?? null);
                }, $qzkTck ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1333706,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(163210090954)
            
            //--TRIMMABLE-BOUNDARY-START(34361072074)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361072074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<h2 class=\"mgt mgb\">CampaignBot Dashboard</h2>\r\n");
                __builder.OpenElement(1, "div");
                __builder.AddAttribute$5(2, "class", "bg-card pd");
                __builder.OpenElement(3, "div");
                __builder.AddAttribute$5(4, "class", "flex");
                __builder.AddMarkupContent(5, "<h3 class=\"mgy-a fill\">\r\n            Wallet Balance:\r\n        </h3>\r\n        ");
                __builder.OpenElement(6, "h2");
                __builder.AddAttribute$5(7, "class", "cl-success mgy-a");
                __builder.AddMarkupContent(8, "\u20A6");
                /*LivingThing.Core.Wallet.Client.Services.WalletSystem?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>?*/ let __ca2__;
                /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel?*/ let __ca3__;
                __builder.AddContent$3(9, $.$box(($.$box((__ca1__ = this.Service.Wallet.System) !== null ? ((__ca2__ = __ca1__.Coins) !== null ? ((__ca3__ = $.$sl.SL.Enumerable.FirstOrDefault$3($.$OJJQ.LCFCW.UserWalletDataModel, __ca2__)) !== null ? __ca3__.Amount : null) : null) : null, $.$$.S.Double)), $.$$.S.Double));
                __builder.CloseElement();
                __builder.AddMarkupContent(10, "\r\n        ");
                __builder.OpenElement(11, "button");
                __builder.AddAttribute$5(12, "class", "cl-primary bg-transparent mgl mgy-a");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Topup)));
                __builder.AddContent$4(14, "Topup");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(15, "\r\n");
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", "mgt-10 mgb flex");
                __builder.AddMarkupContent(18, "<h2 class=\"mg-0 fill\">Recent Campaigns</h2>\r\n    ");
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 19);
                __builder.AddComponentParameter(20, "href", "Edit");
                __builder.AddComponentParameter(21, "Class", "bg-primary cl-white corner pdx-3 pdy-2 fw-bold");
                __builder.AddAttribute$3(22, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(23, "Create Campaign");
                }), $aZllFa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1333706,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.AddMarkupContent(24, "\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 25);
                __builder.AddComponentParameter(26, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(27, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n | 2251799813685248n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                __builder.AddComponentParameter(28, "li-class", "pd mgb-5 bg-card");
                __builder.AddAttribute$3(29, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*campaign*/ campaign) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(30, $.$tUzp.LCCCCS$1.CampaignView.ListView(campaign.Data, null, null));
                    }, $nhIARa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1333706,"h":0,"f":17825794});
                }), $wKrLJg ??= {"r":6881395,"p":[{"n":"campaign","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1333706,"h":0,"f":17825794}));
                __builder.AddAttribute$3(31, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(32, "div");
                    __builder2.AddAttribute$5(33, "class", "mg-a stack pd-10 corner mawx-5 bg-card");
                    __builder2.AddMarkupContent(34, "<h2 class=\"mg-0 text-center\">You have no campaign yet</h2>\r\n            ");
                    __builder2.OpenElement(35, "p");
                    __builder2.AddAttribute$5(36, "class", "text-center");
                    __builder2.AddMarkupContent(37, "\r\n                As a new user, we have given you free ");
                    __builder2.AddContent$3(38, $.$box(5/*CommunityCampaignBotApplication.NewUserFreeMinutes*/, $.$$.S.Int32));
                    __builder2.AddMarkupContent(39, " minutes of campaign.\r\n                Use it to promote your products or services\r\n            ");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(40, "\r\n            ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 41);
                    __builder2.AddComponentParameter(42, "href", "Edit");
                    __builder2.AddComponentParameter(43, "Class", "mgx-a fsz-18 miwx-15 bg-success pdx-5 pdy-3 corner");
                    __builder2.AddAttribute$3(44, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddContent$4(45, "Create your first Campaign");
                    }), $PNPOKg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1333706,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }), $DVVdyd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1333706,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34361072074)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21476170186)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476170186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476170186)
            
            //--TRIMMABLE-BOUNDARY-START(21476170186)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476170186)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(124555385290)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(124555385290)
                
                //--TRIMMABLE-BOUNDARY-START(38656039370)
                this.CampaignCoin = null;
                //--TRIMMABLE-BOUNDARY-END(38656039370)
                
                //--TRIMMABLE-BOUNDARY-START(98785581514)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(98785581514)
                
            }
            static $h = 1333706;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375516106),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015777738,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1333706,
      "h": 107375516106,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107375516106),
//--TRIMMABLE-BOUNDARY-START(124555385290),
    {
      "p": 1071562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605712330,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915123658,
        "f": 83886081
      },
      "n": "Service",
      "d": 1333706,
      "h": 124555385290,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555385290),
//--TRIMMABLE-BOUNDARY-START(38656039370),
    {
      "p": 4026371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245973962,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145319882,
        "f": 83886081
      },
      "n": "CampaignCoin",
      "d": 1333706,
      "h": 38656039370,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656039370),
//--TRIMMABLE-BOUNDARY-START(98785581514),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425843146,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325189066,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1333706,
      "h": 98785581514,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785581514),
//--TRIMMABLE-BOUNDARY-START(94490614218),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835908554,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735254474,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1333706,
      "h": 94490614218,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490614218)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900679626),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1333706,
      "h": 85900679626,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900679626),
//--TRIMMABLE-BOUNDARY-START(90195646922),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1333706,
      "h": 90195646922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195646922),
//--TRIMMABLE-BOUNDARY-START(103080548810),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1333706,
      "h": 103080548810,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(103080548810),
//--TRIMMABLE-BOUNDARY-START(163210090954),
    {
      "r": 181338113,
      "n": "Topup",
      "d": 1333706,
      "h": 163210090954,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163210090954),
//--TRIMMABLE-BOUNDARY-START(34361072074),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1333706,
      "h": 34361072074,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361072074)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476170186),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1333706,
      "h": 21476170186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476170186)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(111670483402),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1333706,
        "h": 30066104778,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1333706,
        "h": 120260417994,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 1333706,
      "h": 111670483402,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(111670483402)
  ],
  "h": 1333706
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.CommunityCampaignHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CommunityCampaignHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1333706)
        
        

        //--TRIMMABLE-BOUNDARY-START(612810)
        $asm.$cls(`$tUzp.LCCCCP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(12885514698)
            /*CommunityCampaignBotPostModel?*/ current = null;
            //--TRIMMABLE-BOUNDARY-END(12885514698)
            
            //--TRIMMABLE-BOUNDARY-START(25770416586)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<CommunityCampaignBotPostModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770416586);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.current = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    ($t1 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor\\Admin.razor.cs", "OnSelected", 17), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770416586)
            
            //--TRIMMABLE-BOUNDARY-START(42950285770)
            /*Task *//*async*/  Run(/*CommunityCampaignBotPostModel*/ c)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950285770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    c.State = 3/*CommunityCampaignBotState.Running*/;
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ c ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.NotifySuccess(null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950285770)
            
            //--TRIMMABLE-BOUNDARY-START(38655318474)
            /*Task *//*async*/  Reject(/*CommunityCampaignBotPostModel*/ c)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655318474);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    c.State = 5/*CommunityCampaignBotState.Rejected*/;
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ c ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.NotifySuccess(null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655318474)
            
            //--TRIMMABLE-BOUNDARY-START(34360351178)
            /*Task *//*async*/  Pause(/*CommunityCampaignBotPostModel*/ c)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360351178);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    c.State = 2/*CommunityCampaignBotState.Paused*/;
                    ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ c ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.NotifySuccess(null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360351178)
            
            //--TRIMMABLE-BOUNDARY-START(30065383882)
            /*string */ get OptimizedComponentName()
            {
                return "admin";
            }
            //--TRIMMABLE-BOUNDARY-END(30065383882)
            
            //--TRIMMABLE-BOUNDARY-START(8590547402)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590547402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.OpenElement(2, "div");
                __builder.AddAttribute$5(3, "class", "mgx-a mawx-9 bg-card pd bd");
                __builder.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 4);
                __builder.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n | 70368744177664n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(6, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                __builder.AddComponentParameter(7, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 2251799813685248n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                __builder.AddComponentParameter(8, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ & ~2048/*DashboardTableFeatures.TableFromSchema*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                __builder.AddAttribute$3(9, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*____*/ ____) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 10);
                        __builder2.AddAttribute$3(11, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(12, "Name");
                            }, $ZCxvAe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $qJGOoh ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(13, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                __builder3.AddContent$4(14, context.Data.Title);
                            }, $coNwGh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $VGGdbd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(15, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 16);
                        __builder2.AddAttribute$3(17, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(18, "Status");
                            }, $rhTvdh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $vteTJi ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                            {
                                /*var*/ let bg = (() =>
                                {
                                    let $switch5 = context.Data.State;
                                    if ($switch5 === 0/*CommunityCampaignBotState.Draft*/)
                                    {
                                        return "dark";
                                    }
                                    if ($switch5 === 1/*CommunityCampaignBotState.Published*/)
                                    {
                                        return "primary";
                                    }
                                    if ($switch5 === 2/*CommunityCampaignBotState.Paused*/)
                                    {
                                        return "warning";
                                    }
                                    if ($switch5 === 5/*CommunityCampaignBotState.Rejected*/)
                                    {
                                        return "error";
                                    }
                                    if ($switch5 === 3/*CommunityCampaignBotState.Running*/)
                                    {
                                        return "success";
                                    }
                                    if ($switch5 === 4/*CommunityCampaignBotState.Finished*/)
                                    {
                                        return "success";
                                    }
                                    return "transparent";
                                })();
                                __builder3.OpenElement(20, "small");
                                __builder3.AddAttribute$5(21, "class", $.$strNN($.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((bg))) + " pdy-1") + " pdx") + " corner") + " ");
                                __builder3.AddContent$3(22, $.$box(context.Data.State, $.$bTOs.LCCCCM.CommunityCampaignBotState));
                                __builder3.CloseElement();
                            }, $fpbqeg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $HSlzff ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(23, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 24);
                        __builder2.AddAttribute$3(25, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(26, "Contacts");
                            }, $yABLEh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $iasACa ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(27, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$3(28, $.$box(context.Data.TotalContacts, $.$$.S.Int32));
                            }, $pswuuk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $Cpwiec ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(29, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 30);
                        __builder2.AddAttribute$3(31, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(32, "Engagements");
                            }, $eIbcij ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $HylOMh ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(34, context.Data.TotalEngagements + "s");
                            }, $nAnzHe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $uNNTCd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(35, "\r\n                ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 36);
                        __builder2.AddAttribute$3(37, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(38, "Actions");
                            }, $bqNkHe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $LUdoQh ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(39, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenElement(40, "div");
                                __builder3.AddAttribute$5(41, "class", "flex");
                                $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder3, 42, "onclick", true);
                                __builder3.OpenElement(43, "button");
                                __builder3.AddAttribute$5(44, "title", "Approve");
                                __builder3.AddAttribute$5(45, "class", "mdi mdi-check cl-primary bg-transparent");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 46, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Run(context.Data);
                                }, $YaIzQc ??= {"r":178454529,"n":"","d":612810,"h":0,"f":17825794})));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(47, "\r\n                            ");
                                __builder3.OpenElement(48, "button");
                                __builder3.AddAttribute$5(49, "title", "Reject");
                                __builder3.AddAttribute$5(50, "class", "mdi mdi-close cl-error bg-transparent");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 51, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Reject(context.Data);
                                }, $iQrhzf ??= {"r":178454529,"n":"","d":612810,"h":0,"f":17825794})));
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(52, "\r\n                            ");
                                __builder3.OpenElement(53, "button");
                                __builder3.AddAttribute$5(54, "title", "Pause");
                                __builder3.AddAttribute$5(55, "class", "mdi mdi-pause cl-info bg-transparent");
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 56, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Pause(context.Data);
                                }, $UMYYSi ??= {"r":178454529,"n":"","d":612810,"h":0,"f":17825794})));
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $OoRrKi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                        }), $xmkgVa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $IqZGBh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                }), $JppZse ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                __builder.AddAttribute$3(57, "Details", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*item*/ item) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(58, "div");
                        __builder2.AddAttribute$5(59, "class", "wx-9");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 60);
                        __builder2.AddComponentParameter(61, "head-class", "bg-card bdb");
                        __builder2.AddAttribute$3(62, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 63);
                            __builder3.AddAttribute$3(64, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(65, "<b>View</b>");
                                }, $wBzNll ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                            }), $eiXPHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(66, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(67, "div");
                                    __builder4.AddAttribute$5(68, "class", "pd");
                                    __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignView, 69);
                                    __builder4.AddComponentParameter(70, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, item.Data));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                }, $Ashqck ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                            }), $WiOhlb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(71, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 72);
                            __builder3.AddAttribute$3(73, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(74, "<b>Edit</b>");
                                }, $vknCLj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                            }), $lMCqYg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(75, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(76, "div");
                                    __builder4.AddAttribute$5(77, "class", "pd");
                                    __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignEditor, 78);
                                    __builder4.AddComponentParameter(79, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, item.Data));
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                }, $wjNOTe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                            }), $SsJifi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $fChWii ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":612810,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }, $CSnEKk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":612810,"h":0,"f":17825794});
                }), $xHnRai ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":612810,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(8590547402)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295580106)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295580106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295580106)
            
            //--TRIMMABLE-BOUNDARY-START(4295580106)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295580106)
            
            static $h = 612810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065383882),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475449290,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 612810,
      "h": 30065383882,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065383882)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770416586),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 612810,
      "h": 25770416586,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770416586),
//--TRIMMABLE-BOUNDARY-START(42950285770),
    {
      "r": 178454529,
      "p": [
        {
          "n": "c",
          "p": 1863683
        }
      ],
      "n": "Run",
      "d": 612810,
      "h": 42950285770,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42950285770),
//--TRIMMABLE-BOUNDARY-START(38655318474),
    {
      "r": 178454529,
      "p": [
        {
          "n": "c",
          "p": 1863683
        }
      ],
      "n": "Reject",
      "d": 612810,
      "h": 38655318474,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38655318474),
//--TRIMMABLE-BOUNDARY-START(34360351178),
    {
      "r": 178454529,
      "p": [
        {
          "n": "c",
          "p": 1863683
        }
      ],
      "n": "Pause",
      "d": 612810,
      "h": 34360351178,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360351178),
//--TRIMMABLE-BOUNDARY-START(8590547402),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 612810,
      "h": 8590547402,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590547402)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885514698),
    {
      "t": 1863683,
      "n": "current",
      "d": 612810,
      "h": 12885514698,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885514698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295580106),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 612810,
      "h": 4295580106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295580106)
  ],
  "h": 612810,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/CampaignBot/Admin",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(612810)
        
        

        //--TRIMMABLE-BOUNDARY-START(1464778)
        $asm.$cls(`$tUzp.LCCCCS$1.Dashboard`, ($self) => class Dashboard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(124555516362)
            /*string */ get OptimizedComponentName()
            {
                return "dashboard";
            }
            //--TRIMMABLE-BOUNDARY-END(124555516362)
            
            //--TRIMMABLE-BOUNDARY-START(176095123914)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095123914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "OnClose":
                    this.OnClose = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176095123914)
            
            //--TRIMMABLE-BOUNDARY-START(90195777994)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195777994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90195777994)
            
            //--TRIMMABLE-BOUNDARY-START(98785712586)
            /*SignupMode*/ mode = 3;
            //--TRIMMABLE-BOUNDARY-END(98785712586)
            
            //--TRIMMABLE-BOUNDARY-START(42951137738)
            /*string?*/ email = null;
            //--TRIMMABLE-BOUNDARY-END(42951137738)
            
            //--TRIMMABLE-BOUNDARY-START(128850483658)
            /*string?*/ password = null;
            //--TRIMMABLE-BOUNDARY-END(128850483658)
            
            //--TRIMMABLE-BOUNDARY-START(30066235850)
            /*string?*/ confirmPassword = null;
            //--TRIMMABLE-BOUNDARY-END(30066235850)
            
            //--TRIMMABLE-BOUNDARY-START(171800156618)
            /*string?*/ token = null;
            //--TRIMMABLE-BOUNDARY-END(171800156618)
            
            //--TRIMMABLE-BOUNDARY-START(47246105034)
            /*string?*/ errorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(47246105034)
            
            //--TRIMMABLE-BOUNDARY-START(103080679882)
            /*string?*/ mpage = null;
            //--TRIMMABLE-BOUNDARY-END(103080679882)
            
            //--TRIMMABLE-BOUNDARY-START(34361203146)
            /*CommunityCampaignBotPostModel?*/ current = null;
            //--TRIMMABLE-BOUNDARY-END(34361203146)
            
            //--TRIMMABLE-BOUNDARY-START(107375647178)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(107375647178)
            
            //--TRIMMABLE-BOUNDARY-START(141735385546)
            /*CommunityCampaignBotService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(141735385546)
            
            //--TRIMMABLE-BOUNDARY-START(111670614474)
            /*EventCallback*/ OnClose;
            //--TRIMMABLE-BOUNDARY-END(111670614474)
            
            //--TRIMMABLE-BOUNDARY-START(115965581770)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965581770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965581770)
            
            //--TRIMMABLE-BOUNDARY-START(38656170442)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656170442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$add_BoxChanged(new ($.$fPer.LCFC.AsyncEventHandler$$($.$vWqU.LCFCC.BoxSize))().$ctor(this, this.UI_BoxChanged));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(38656170442)
            
            //--TRIMMABLE-BOUNDARY-START(180390091210)
            /*Task *//*async*/  UI_BoxChanged(/*object*/ sender, /*BoxSize?*/ e)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180390091210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor\\Dashboard.razor.cs", "UI_BoxChanged", 50), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180390091210)
            
            //--TRIMMABLE-BOUNDARY-START(94490745290)
            /*Task *//*async*/  LogOut()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490745290);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogOut(null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490745290)
            
            //--TRIMMABLE-BOUNDARY-START(51541072330)
            /*Task *//*async*/  FundAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541072330);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.Service.Wallet.System.FundAsync(), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541072330)
            
            //--TRIMMABLE-BOUNDARY-START(133145450954)
            /*Task *//*async*/  PauseCurrent()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133145450954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.current !== null)
                    {
                        let $t7, $r7;
                        this.current.State = 2/*CommunityCampaignBotState.Paused*/;
                        ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ this.current ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133145450954)
            
            //--TRIMMABLE-BOUNDARY-START(137440418250)
            /*Task *//*async*/  RunCurrent()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440418250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.current !== null)
                    {
                        let $t8, $r8;
                        this.current.State = 3/*CommunityCampaignBotState.Running*/;
                        ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ this.current ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137440418250)
            
            //--TRIMMABLE-BOUNDARY-START(184685058506)
            /*bool*/ working = false;
            //--TRIMMABLE-BOUNDARY-END(184685058506)
            
            //--TRIMMABLE-BOUNDARY-START(21476301258)
            /*Task *//*async*/  Authenticate()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476301258);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.errorMessage = null;
                    this.working = true;
                    try
                    {
                        let $t10, $r10;
                        let $t11, $r11;
                        let $t12, $r12;
                        let $t13, $r13;
                        let $t14, $r14;
                        let $t15, $r15;
                        switch(this.mode)
                        {
                            case 3/*SignupMode.Login*/:
                            if ($.$$.S.String.IsNullOrEmpty(this.email) || $.$$.S.String.IsNullOrEmpty(this.password))
                            {
                                this.errorMessage = "Email and password are required.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            ($t10 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogIn(this.email, this.password, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                            this.Navigation.NavigateTo$2($.$strNN($.$strNN(this.Navigation.Uri) + $.$strNN(($.$$.S.String.Contains$1.call(this.Navigation.Uri, /*?*/ 63) ? "&" : "?"))) + "launch=true", true);
                            break;
                            case 1/*SignupMode.SignupBegin*/:
                            if ($.$$.S.String.IsNullOrEmpty(this.email) || $.$$.S.String.IsNullOrEmpty(this.password) || $.$$.S.String.IsNullOrEmpty(this.confirmPassword))
                            {
                                this.errorMessage = "Email and password are required.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            if (this.password !== this.confirmPassword)
                            {
                                this.errorMessage = "Passwords do not match.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            ($t11 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$BeginRegistration(this.email), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            this.mode++;
                            break;
                            case 2/*SignupMode.SignupToken*/:
                            if ($.$$.S.String.IsNullOrEmpty(this.token))
                            {
                                this.errorMessage = "Token is required.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            ($t12 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$CreateUser(this.email, this.password, this.email, this.token, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                            ($t13 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$LogIn(this.email, this.password, null), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                            this.Navigation.NavigateTo$2($.$strNN($.$strNN(this.Navigation.Uri) + $.$strNN(($.$$.S.String.Contains$1.call(this.Navigation.Uri, /*?*/ 63) ? "&" : "?"))) + "launch=true", true);
                            break;
                            case 4/*SignupMode.ForgotPasswordBegin*/:
                            if ($.$$.S.String.IsNullOrEmpty(this.email))
                            {
                                this.errorMessage = "Email is required.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            ($t14 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$BeginPasswordReset(this.email), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            this.mode++;
                            break;
                            case 5/*SignupMode.ForgotPasswordToken*/:
                            if ($.$$.S.String.IsNullOrEmpty(this.token) || $.$$.S.String.IsNullOrEmpty(this.password) || $.$$.S.String.IsNullOrEmpty(this.confirmPassword))
                            {
                                this.errorMessage = "Token is required.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            if (this.password !== this.confirmPassword)
                            {
                                this.errorMessage = "Passwords do not match.";
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            ($t15 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Authentication.LCFCA$IAuthenticationService$CompletePasswordReset(this.email, this.token, this.password, this.confirmPassword), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            break;
                        }
                    }
                    catch(ex)
                    {
                        this.errorMessage = ex.Message;
                    }
                    finally
                    {
                        {
                            this.working = false;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476301258)
            
            //--TRIMMABLE-BOUNDARY-START(120260549066)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<CommunityCampaignBotPostModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260549066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.current = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    this.mpage = "ViewCampaign";
                    ($t16 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Client.Blazor\\Dashboard.razor.cs", "OnSelected", 161), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120260549066)
            
            //--TRIMMABLE-BOUNDARY-START(25771268554)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771268554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$maca.MACA.AuthorizeView, 0);
                __builder.AddAttribute$3(1, "NotAuthorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$macw.MACF.EditForm, 2);
                        __builder2.AddComponentParameter(3, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                        __builder2.AddComponentParameter(4, "class", `bg-card sd mg-a corner ${$.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "pd wv-10 mihv-10" : "pd-10 miwx-7 mawx-7"))} stack pos-rel animated slideInUp`);
                        __builder2.AddAttribute$3(5, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*_*/ _0) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                if (this.OnClose.HasDelegate)
                                {
                                    __builder3.OpenElement(6, "button");
                                    __builder3.AddAttribute$5(7, "class", "mdi mdi-close bg-error wx-03 hx-03 round pos-abs r-0 t-0 mgr--2 mgt--2");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 8, "onclick", $.$mac.MAC.EventCallback.Factory.Create$5($.$macw.MACW.MouseEventArgs, this, this.OnClose));
                                    __builder3.AddAttribute$5(9, "type", "button");
                                    __builder3.CloseElement();
                                }
                                __builder3.OpenElement(10, "div");
                                __builder3.AddAttribute$5(11, "class", "flex mgx-a");
                                __builder3.OpenElement(12, "img");
                                __builder3.AddAttribute$5(13, "src", this.ResolvePath("img/icon.png", true, true, false));
                                __builder3.AddAttribute$5(14, "class", "mahx-05 mgy-a");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(15, "\r\n                ");
                                __builder3.AddMarkupContent(16, "<h1 class=\"mgy-a mgl\">Campaign<span class=\"cl-primary\">Bot</span></h1>");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(17, "\r\n            ");
                                __builder3.OpenElement(18, "div");
                                __builder3.AddAttribute$5(19, "class", $.$strNN(" corner" + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "mgt pdy mgy-a" : "bd pd-10 mg-10")));
                                /*var*/ let title = (() =>
                                {
                                    if (this.mode === 3/*SignupMode.Login*/)
                                    {
                                        return "Login to Your Account";
                                    }
                                    if (this.mode === 1/*SignupMode.SignupBegin*/)
                                    {
                                        return "Signup";
                                    }
                                    if (this.mode === 2/*SignupMode.SignupToken*/)
                                    {
                                        return "Signup";
                                    }
                                    if (this.mode === 4/*SignupMode.ForgotPasswordBegin*/)
                                    {
                                        return "Forgot Password";
                                    }
                                    if (this.mode === 5/*SignupMode.ForgotPasswordToken*/)
                                    {
                                        return "Forgot Password";
                                    }
                                    return null;
                                })();
                                __builder3.OpenElement(20, "h3");
                                __builder3.AddAttribute$5(21, "class", "text-center mgt-0");
                                __builder3.AddContent$4(22, title);
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(23, "\r\n                ");
                                __builder3.OpenElement(24, "div");
                                __builder3.AddAttribute$5(25, "class", "stack");
                                if (this.mode === 1/*SignupMode.SignupBegin*/ || this.mode === 3/*SignupMode.Login*/ || this.mode === 4/*SignupMode.ForgotPasswordBegin*/)
                                {
                                    __builder3.AddMarkupContent(26, "<b class=\" mgb-1\">Email</b>\r\n                        ");
                                    __builder3.OpenElement(27, "input");
                                    __builder3.AddAttribute$5(28, "type", "email");
                                    __builder3.AddAttribute$5(29, "class", "pd bd corner");
                                    __builder3.AddAttribute$5(30, "placeholder", "Enter your email");
                                    __builder3.AddAttribute$5(31, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.email, null));
                                    __builder3.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 32, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return this.email = __value;
                                    }, $tpXNbi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1464778,"h":0,"f":17825794}), this.email, null));
                                    __builder3.SetUpdatesAttributeName("value");
                                    __builder3.CloseElement();
                                }
                                if (this.mode === 2/*SignupMode.SignupToken*/ || this.mode === 5/*SignupMode.ForgotPasswordToken*/)
                                {
                                    __builder3.OpenElement(33, "h3");
                                    __builder3.AddContent$4(34, "We sent a token to your email ");
                                    __builder3.OpenElement(35, "b");
                                    __builder3.AddContent$4(36, this.email);
                                    __builder3.CloseElement();
                                    __builder3.AddContent$4(37, ". Provide the token and continue.");
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(38, "\r\n                        ");
                                    __builder3.AddMarkupContent(39, "<b class=\" mgb-1\">Token</b>\r\n                        ");
                                    $.$tUzp._LCCCCSD.TypeInference.CreateInputEditor_0($.$$.S.String, __builder3, 40, 41, 79n, 42, this.token, 43, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return this.token = __value;
                                    }, $qGryVd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1464778,"h":0,"f":17825794}), this.token)), 44, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                    {
                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "token"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                    }, $OygALa ??= {"r":38797349,"n":"","d":1464778,"h":0,"f":17825794})).Invoke()));
                                    __builder3.AddMarkupContent(45, "\r\n                        ");
                                    __builder3.OpenElement(46, "small");
                                    __builder3.AddContent$4(47, "Enter the token sent to ");
                                    __builder3.OpenElement(48, "b");
                                    __builder3.AddContent$4(49, this.email);
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                                if (this.mode === 3/*SignupMode.Login*/ || this.mode === 1/*SignupMode.SignupBegin*/ || this.mode === 5/*SignupMode.ForgotPasswordToken*/)
                                {
                                    __builder3.OpenElement(50, "b");
                                    __builder3.AddAttribute$5(51, "class", "mgt-10 mgb-1");
                                    __builder3.AddContent$4(52, this.mode === 5/*SignupMode.ForgotPasswordToken*/ ? "New" : "");
                                    __builder3.AddContent$4(53, " Password");
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(54, "\r\n                        ");
                                    __builder3.OpenElement(55, "input");
                                    __builder3.AddAttribute$5(56, "type", "password");
                                    __builder3.AddAttribute$5(57, "class", "pd bd corner");
                                    __builder3.AddAttribute$5(58, "placeholder", "Enter your password");
                                    __builder3.AddAttribute$5(59, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.password, null));
                                    __builder3.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 60, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                                    {
                                        return this.password = __value;
                                    }, $wAGede ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1464778,"h":0,"f":17825794}), this.password, null));
                                    __builder3.SetUpdatesAttributeName("value");
                                    __builder3.CloseElement();
                                }
                                if (this.mode === 5/*SignupMode.ForgotPasswordToken*/ || this.mode === 1/*SignupMode.SignupBegin*/)
                                {
                                    __builder3.AddMarkupContent(61, "<b class=\"mgt-10 mgb-1\">Confirm Password</b>\r\n                        ");
                                    __builder3.OpenElement(62, "input");
                                    __builder3.AddAttribute$5(63, "type", "password");
                                    __builder3.AddAttribute$5(64, "class", "pd bd corner");
                                    __builder3.AddAttribute$5(65, "placeholder", "Confirm your password");
                                    __builder3.AddAttribute$5(66, "value", $.$mac.MAC.BindConverter.FormatValue$28(this.confirmPassword, null));
                                    __builder3.AddAttribute$7($.$mac.MAC.ChangeEventArgs, 67, "onchange", $.$mac.MAC.EventCallbackFactoryBinderExtensions.CreateBinder$28($.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return this.confirmPassword = __value;
                                    }, $kspxBd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1464778,"h":0,"f":17825794}), this.confirmPassword, null));
                                    __builder3.SetUpdatesAttributeName("value");
                                    __builder3.CloseElement();
                                }
                                __builder3.OpenElement(68, "div");
                                __builder3.AddAttribute$5(69, "class", "flex mgt");
                                if (this.mode === 3/*SignupMode.Login*/)
                                {
                                    __builder3.OpenElement(70, "b");
                                    __builder3.AddAttribute$5(71, "class", "clickable cl-primary fw-bold mgl-a");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 72, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.mode = 4/*SignupMode.ForgotPasswordBegin*/;
                                    }, $kUuQWg ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                    __builder3.AddContent$4(73, "Forgot Password?");
                                    __builder3.CloseElement();
                                }
                                __builder3.CloseElement();
                                if (!$.$$.S.String.IsNullOrEmpty(this.errorMessage))
                                {
                                    __builder3.OpenElement(74, "div");
                                    __builder3.AddAttribute$5(75, "class", "bg-error mgt cl-white pd corner mgx-a");
                                    __builder3.AddContent$4(76, this.errorMessage);
                                    __builder3.CloseElement();
                                }
                                __builder3.OpenElement(77, "button");
                                __builder3.AddAttribute$5(78, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-primary" + " miwx-1") + " corner") + " pd") + " fw-bold") + " fsz-16") + " cl-white") + " mgt-10") + " ") + $.$strNN((this.working ? "mdi mdi-loading mdi-spin" : "")));
                                __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 79, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Authenticate)));
                                __builder3.AddAttribute$5(80, "type", "button");
                                __builder3.AddContent$4(81, this.working ? "" : this.mode === 3/*SignupMode.Login*/ ? "Login" : this.mode === 1/*SignupMode.SignupBegin*/ ? "Continue" : "Continue");
                                __builder3.CloseElement();
                                __builder3.AddMarkupContent(82, "\r\n                    ");
                                __builder3.OpenElement(83, "div");
                                __builder3.AddAttribute$5(84, "class", "pdt bdt mgt");
                                if (this.mode === 3/*SignupMode.Login*/ || this.mode === 4/*SignupMode.ForgotPasswordBegin*/ || this.mode === 5/*SignupMode.ForgotPasswordToken*/)
                                {
                                    __builder3.OpenElement(85, "p");
                                    __builder3.AddAttribute$5(86, "class", "text-center mg-0");
                                    __builder3.AddContent$4(87, "Don't have an account? ");
                                    __builder3.OpenElement(88, "b");
                                    __builder3.AddAttribute$5(89, "class", "clickable cl-primary fw-bold");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 90, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.mode = 1/*SignupMode.SignupBegin*/;
                                    }, $DlCcid ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                    __builder3.AddContent$4(91, "Sign Up");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                                else if (this.mode !== 3/*SignupMode.Login*/)
                                {
                                    __builder3.OpenElement(92, "p");
                                    __builder3.AddAttribute$5(93, "class", "text-center mg-0");
                                    __builder3.AddContent$4(94, "Have an account? ");
                                    __builder3.OpenElement(95, "b");
                                    __builder3.AddAttribute$5(96, "class", "clickable cl-primary fw-bold");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 97, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        return this.mode = 3/*SignupMode.Login*/;
                                    }, $BpcTOj ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                    __builder3.AddContent$4(98, "Login");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }, $Vtncbl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                        }), $wufBWa ??= {"r":6881395,"p":[{"n":"_","p":131188}],"n":"","d":1464778,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $sEbEsa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                }), $SIVqmd ??= {"r":6881395,"p":[{"n":"context","p":131193}],"n":"","d":1464778,"h":0,"f":17825794}));
                __builder.AddAttribute$3(99, "Authorized", new ($.$mac.MAC.RenderFragment$$($.$maca.MACA.AuthenticationState))().$ctor(this, ( (/*user*/ user) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(100, "div");
                        __builder2.AddAttribute$5(101, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("bg-card" + " sd") + " pd") + " mg-a") + " corner") + " mihx-5") + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "wv-10 mihv-10" : "miwx-7 mawx-7"))) + "  stack") + " pos-rel") + " animated") + " slideInUp");
                        if (this.OnClose.HasDelegate)
                        {
                            __builder2.OpenElement(102, "button");
                            __builder2.AddAttribute$5(103, "class", "mdi mdi-close bg-error wx-03 hx-03 round pos-abs r-0 t-0 mgr--2 mgt--2");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 104, "onclick", $.$mac.MAC.EventCallback.Factory.Create$5($.$macw.MACW.MouseEventArgs, this, this.OnClose));
                            __builder2.AddAttribute$5(105, "type", "button");
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(106, "div");
                        __builder2.AddAttribute$5(107, "class", ((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "stack" : "flex");
                        __builder2.OpenElement(108, "div");
                        __builder2.AddAttribute$5(109, "class", "stack");
                        __builder2.OpenElement(110, "div");
                        __builder2.AddAttribute$5(111, "class", "flex mgb-2 bg-primary-01 pd-1");
                        __builder2.OpenElement(112, "img");
                        __builder2.AddAttribute$5(113, "src", this.ResolvePath("img/icon.png", true, true, false));
                        __builder2.AddAttribute$5(114, "class", "mahx-03 mgy-a");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(115, "\r\n                        ");
                        __builder2.AddMarkupContent(116, "<h4 class=\"mgy-a mgl\">Campaign<span class=\"cl-primary\">Bot</span></h4>");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(117, "\r\n                    ");
                        __builder2.OpenElement(118, "div");
                        __builder2.AddAttribute$5(119, "class", $.$strNN($.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "flex scroll pdy" : "stack pd")) + " bdr") + " bdw-2");
                        if (this.mpage !== "Dashboard" && this.mpage !== "Campaigns")
                        {
                            __builder2.OpenElement(120, "button");
                            __builder2.AddAttribute$5(121, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("text-left" + " pdx") + " pdy-2") + " bg-primary") + " corner") + " fw-bold") + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? " nobreak" : "")));
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 122, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                            {
                                return this.mpage = "Dashboard";
                            }, $XBvZpa ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                            __builder2.AddMarkupContent(123, "<i class=\"mdi mdi-chevron-left\"></i>\r\n                                Back\r\n                            ");
                            __builder2.CloseElement();
                        }
                        __builder2.OpenElement(124, "button");
                        __builder2.AddAttribute$5(125, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("text-left" + " pdx-3") + " pdy-2") + " bg-") + $.$strNN((this.mpage === "Dashboard" ? "primary" : "transparent"))) + " corner") + " fw-bold") + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? " nobreak" : "")));
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 126, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.mpage = "Dashboard";
                        }, $UZttcl ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                        __builder2.AddMarkupContent(127, "<i class=\"mdi mdi-monitor-dashboard\"></i>\r\n                            Dashboard\r\n                        ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(128, "\r\n                        ");
                        __builder2.OpenElement(129, "button");
                        __builder2.AddAttribute$5(130, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("text-left" + " pdx-3") + " pdy-2") + " bg-") + $.$strNN((this.mpage === "Campaigns" ? "primary" : "transparent"))) + " corner") + " fw-bold") + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? " nobreak" : "")));
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 131, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.mpage = "Campaigns";
                        }, $wrQYme ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                        __builder2.AddMarkupContent(132, "<i class=\"mdi mdi-bullhorn\"></i>\r\n                            Campaigns\r\n                        ");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(133, "\r\n                        ");
                        __builder2.OpenElement(134, "button");
                        __builder2.AddAttribute$5(135, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("text-left" + " pdx-3") + " pdy-2") + " corner") + " fw-bold") + " bg-transparent") + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? " nobreak" : "")));
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 136, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.LogOut)));
                        __builder2.AddMarkupContent(137, "<i class=\"mdi mdi-logout\"></i>\r\n                            Logout\r\n                        ");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(138, "\r\n                ");
                        __builder2.OpenElement(139, "div");
                        __builder2.AddAttribute$5(140, "class", $.$strNN("fill" + " ") + $.$strNN((((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? "" : "mahx-5 scroll pd ")));
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$6.MultiView, 141);
                        __builder2.AddComponentParameter(142, "CurrentViewName", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.mpage));
                        __builder2.AddAttribute$3(143, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 144);
                            __builder3.AddComponentParameter(145, "Name", "Dashboard");
                            __builder3.AddAttribute$3(146, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(147, "h3");
                                    __builder4.AddAttribute$5(148, "class", "mgt-0");
                                    __builder4.AddContent$4(149, "Welcome Back, ");
                                    __builder4.AddContent$4(150, (user.User.Identity?.SSP$1$IIdentity$Name ?? null));
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(151, "\r\n                            ");
                                    __builder4.OpenElement(152, "div");
                                    __builder4.AddAttribute$5(153, "class", "flex cl-white pd corner clip bg-fill");
                                    __builder4.AddAttribute$5(154, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath("img/balance-banner.jpg", true, true, false)))) + ");");
                                    __builder4.OpenElement(155, "div");
                                    __builder4.AddAttribute$5(156, "class", "fill");
                                    __builder4.AddMarkupContent(157, "<span>Wallet Balance</span>\r\n                                    ");
                                    __builder4.OpenElement(158, "h1");
                                    __builder4.AddAttribute$5(159, "class", "mg-0");
                                    __builder4.AddContent$4(160, "\u20A6"/*Money.NairaSymbol*/);
                                    /*LivingThing.Core.Wallet.Client.Services.WalletSystem?*/ let __ca1__;
                                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>?*/ let __ca2__;
                                    __builder4.AddContent$4(161, ((__ca1__ = this.Service.Wallet.System) !== null ? ((__ca2__ = __ca1__.Coins) !== null ? $.$$.S.Double.ToString$3.call($.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.UserWalletDataModel, __ca2__).Amount, "0.##") : null) : null));
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(162, "\r\n                                ");
                                    __builder4.OpenElement(163, "button");
                                    __builder4.AddAttribute$5(164, "class", "bg-primary miwx-1 corner pd fw-bold cl-white mgb-a");
                                    __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 165, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.FundAsync)));
                                    __builder4.AddContent$4(166, "Add Fund");
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(167, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 168);
                                    __builder4.AddComponentParameter(169, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder4.AddComponentParameter(170, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder4.AddComponentParameter(171, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n | 2251799813685248n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                                    __builder4.AddAttribute$3(172, "CustomRenderer", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*render*/ render) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel, LivingThing.Core.Frameworks.Client.Components.DataTable.DataTableColumn<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>>>?*/ let __ca3__;
                                            /*var*/ let cps = ((__ca3__ = render.Data) !== null ? $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)), $.$bTOs.LCCCCM.CommunityCampaignBotPostModel, __ca3__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)), $.$bTOs.LCCCCM.CommunityCampaignBotPostModel))().$ctor(this,  (/*d*/ d) =>
                                            {
                                                return d.Data;
                                            }, $FDhDij ??= {"r":1863683,"p":[{"n":"d","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794})) : null);
                                            if (cps !== null)
                                            {
                                                __builder5.OpenElement(173, "div");
                                                __builder5.AddAttribute$5(174, "class", "grid colm-15 gap-1 mgt");
                                                __builder5.OpenElement(175, "div");
                                                __builder5.AddAttribute$5(176, "class", "bd pd corner bg-chart1-01 flex");
                                                __builder5.AddMarkupContent(177, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart1-06 round flex\"><i class=\"mdi mdi-phone fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(178, "div");
                                                __builder5.AddAttribute$5(179, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(180, "<b>Contacts</b>\r\n                                                    ");
                                                __builder5.OpenElement(181, "h1");
                                                __builder5.AddAttribute$5(182, "class", "mg-0 cl-primary");
                                                __builder5.AddContent$3(183, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalContacts;
                                                }, $kupLuk ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(184, "\r\n                                            ");
                                                __builder5.OpenElement(185, "div");
                                                __builder5.AddAttribute$5(186, "class", "bd pd corner bg-chart2-01 flex");
                                                __builder5.AddMarkupContent(187, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart2-06 round flex\"><i class=\"mdi mdi-phone-forward fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(188, "div");
                                                __builder5.AddAttribute$5(189, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(190, "<b>Called</b>\r\n                                                    ");
                                                __builder5.OpenElement(191, "h1");
                                                __builder5.AddAttribute$5(192, "class", "mg-0 cl-primary");
                                                __builder5.AddContent$3(193, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalDialed;
                                                }, $qQPPZf ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(194, "\r\n                                            ");
                                                __builder5.OpenElement(195, "div");
                                                __builder5.AddAttribute$5(196, "class", "bd pd corner bg-chart3-01 flex");
                                                __builder5.AddMarkupContent(197, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart3-06 round flex\"><i class=\"mdi mdi-phone-check fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(198, "div");
                                                __builder5.AddAttribute$5(199, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(200, "<b>Picked</b>\r\n                                                    ");
                                                __builder5.OpenElement(201, "h1");
                                                __builder5.AddAttribute$5(202, "class", "mg-0 cl-success");
                                                __builder5.AddContent$3(203, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalPicked;
                                                }, $qyabyk ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(204, "\r\n                                            ");
                                                __builder5.OpenElement(205, "div");
                                                __builder5.AddAttribute$5(206, "class", "bd pd corner bg-chart4-01 flex");
                                                __builder5.AddMarkupContent(207, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart4-06 round flex\"><i class=\"mdi mdi-cancel cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(208, "div");
                                                __builder5.AddAttribute$5(209, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(210, "<b>Rejected</b>\r\n                                                    ");
                                                __builder5.OpenElement(211, "h1");
                                                __builder5.AddAttribute$5(212, "class", "mg-0 cl-error");
                                                __builder5.AddContent$3(213, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalRejected;
                                                }, $ezJkbj ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(214, "\r\n                                            ");
                                                __builder5.OpenElement(215, "div");
                                                __builder5.AddAttribute$5(216, "class", "bd pd corner bg-chart5-01 flex");
                                                __builder5.AddMarkupContent(217, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart5-06 round flex\"><i class=\"mdi mdi-phone-remove cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(218, "div");
                                                __builder5.AddAttribute$5(219, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(220, "<b>Unreached</b>\r\n                                                    ");
                                                __builder5.OpenElement(221, "h1");
                                                __builder5.AddAttribute$5(222, "class", "mg-0 cl-warning");
                                                __builder5.AddContent$3(223, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalUnreachable;
                                                }, $iMlcMj ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(224, "\r\n                                            ");
                                                __builder5.OpenElement(225, "div");
                                                __builder5.AddAttribute$5(226, "class", "bd pd corner bg-chart6-01 flex");
                                                __builder5.AddMarkupContent(227, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart6-06 round flex\"><i class=\"mdi mdi-timer cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(228, "div");
                                                __builder5.AddAttribute$5(229, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(230, "<b>Duration</b>\r\n                                                    ");
                                                __builder5.OpenElement(231, "h1");
                                                __builder5.AddAttribute$5(232, "class", "mg-0 cl-chart6");
                                                __builder5.AddContent$3(233, $.$box($.$sl.SL.Enumerable.Sum$17($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.TotalEngagements;
                                                }, $Guhmfk ??= {"r":655361,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), $.$$.S.Int32));
                                                __builder5.AddContent$4(234, "s");
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.AddMarkupContent(235, "\r\n                                            ");
                                                __builder5.OpenElement(236, "div");
                                                __builder5.AddAttribute$5(237, "class", "bd pd corner bg-chart8-01 flex");
                                                __builder5.AddMarkupContent(238, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart8-06 round flex\"><i class=\"mdi mdi-currency-ngn cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n                                                ");
                                                __builder5.OpenElement(239, "div");
                                                __builder5.AddAttribute$5(240, "class", "mgl-a text-right");
                                                __builder5.AddMarkupContent(241, "<b>Spent</b>\r\n                                                    ");
                                                __builder5.OpenElement(242, "h2");
                                                __builder5.AddAttribute$5(243, "class", "mg-0 cl-primary");
                                                __builder5.AddContent$4(244, "\u20A6"/*Money.NairaSymbol*/);
                                                __builder5.AddContent$4(245, $.$fPer.LCFCS$6.NumberExtension.FormatScientific($.$sl.SL.Enumerable.Sum$16($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, cps, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                                                {
                                                    return c.Spent;
                                                }, $YDgmzf ??= {"r":1179649,"p":[{"n":"c","p":1863683}],"n":"","d":1464778,"h":0,"f":17825794})), "0.##", false));
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                                __builder5.CloseElement();
                                            }
                                            __builder5.OpenElement(246, "div");
                                            __builder5.AddAttribute$5(247, "class", "flex mgb-1");
                                            __builder5.AddMarkupContent(248, "<h4 class=\"mg-0\">Recent Campaigns</h4>\r\n                                        ");
                                            __builder5.OpenElement(249, "button");
                                            __builder5.AddAttribute$5(250, "class", "mgl-a bg-primary pdy-1 pdx-2 corner-5 mdi mdi-plus fw-bold");
                                            __builder5.AddAttribute$7($.$macw.MACW.MouseEventArgs, 251, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                            {
                                                this.current = new $.$bTOs.LCCCCM.CommunityCampaignBotPostModel().$ctor$6();
                                                this.mpage = "EditCampaign";
                                            }, $MGZXCk ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                            __builder5.AddContent$4(252, "Create Campaign");
                                            __builder5.CloseElement();
                                            __builder5.CloseElement();
                                            __builder5.AddMarkupContent(253, "\r\n                                    ");
                                            __builder5.AddContent$1(254, render.DefaultRenderer.Invoke(render.DataList, render.Data, render.RootAttributes));
                                        }, $ePVYFj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                    }), $yYrXck ??= {"r":6881395,"p":[{"n":"render","p":$.$hDPm.LCFCCD$1.DataListRenderContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(255, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 256);
                                            __builder5.AddAttribute$3(257, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(258, "Name");
                                                }, $mmRRLh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $alWHVc ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(259, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(260, context.Data.Title);
                                                }, $jHxFCa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $AboDXb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(261, "\r\n                                    ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 262);
                                            __builder5.AddAttribute$3(263, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(264, "Status");
                                                }, $aebAQe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $eFrhee ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(265, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    /*var*/ let bg = (() =>
                                                    {
                                                        let $switch17 = context.Data.State;
                                                        if ($switch17 === 0/*CommunityCampaignBotState.Draft*/)
                                                        {
                                                            return "dark";
                                                        }
                                                        if ($switch17 === 1/*CommunityCampaignBotState.Published*/)
                                                        {
                                                            return "primary";
                                                        }
                                                        if ($switch17 === 2/*CommunityCampaignBotState.Paused*/)
                                                        {
                                                            return "warning";
                                                        }
                                                        if ($switch17 === 5/*CommunityCampaignBotState.Rejected*/)
                                                        {
                                                            return "error";
                                                        }
                                                        if ($switch17 === 3/*CommunityCampaignBotState.Running*/)
                                                        {
                                                            return "success";
                                                        }
                                                        if ($switch17 === 4/*CommunityCampaignBotState.Finished*/)
                                                        {
                                                            return "success";
                                                        }
                                                        return "transparent";
                                                    })();
                                                    __builder6.OpenElement(266, "small");
                                                    __builder6.AddAttribute$5(267, "class", $.$strNN($.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((bg))) + " pdy-1") + " pdx") + " corner") + " ");
                                                    __builder6.AddContent$3(268, $.$box(context.Data.State, $.$bTOs.LCCCCM.CommunityCampaignBotState));
                                                    __builder6.CloseElement();
                                                }, $EXFllj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $iiZAye ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(269, "\r\n                                    ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 270);
                                            __builder5.AddAttribute$3(271, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(272, "Contacts");
                                                }, $hwHElk ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $WjsLhe ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(273, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$3(274, $.$box(context.Data.TotalContacts, $.$$.S.Int32));
                                                }, $vaQwUi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $YCansf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(275, "\r\n                                    ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 276);
                                            __builder5.AddAttribute$3(277, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(278, "Pickups");
                                                }, $lzASek ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $pYAOib ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(279, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$3(280, $.$box(context.Data.TotalPicked, $.$$.S.Int32));
                                                }, $OXjlcd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $Bxwyug ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(281, "\r\n                                    ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 282);
                                            __builder5.AddAttribute$3(283, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(284, "Actions");
                                                }, $lyIzQh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $ETxxRj ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(285, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenElement(286, "div");
                                                    __builder6.AddAttribute$5(287, "class", "flex");
                                                    __builder6.OpenElement(288, "button");
                                                    __builder6.AddAttribute$5(289, "title", "Edit");
                                                    __builder6.AddAttribute$5(290, "class", "mdi mdi-pencil cl-error bg-transparent");
                                                    __builder6.AddAttribute$7($.$macw.MACW.MouseEventArgs, 291, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                    {
                                                        this.current = context.Data;
                                                        this.mpage = "EditCampaign";
                                                    }, $oKuJOh ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(292, "\r\n                                                ");
                                                    __builder6.OpenElement(293, "button");
                                                    __builder6.AddAttribute$5(294, "title", "Open");
                                                    __builder6.AddAttribute$5(295, "class", "mdi mdi-book-open cl-primary bg-transparent");
                                                    __builder6.AddAttribute$7($.$macw.MACW.MouseEventArgs, 296, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                    {
                                                        this.current = context.Data;
                                                        this.mpage = "ViewCampaign";
                                                    }, $Uigvpj ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                                    __builder6.CloseElement();
                                                    __builder6.CloseElement();
                                                }, $UEwqBa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $RmSkij ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }, $gZTtoh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                    }), $gIxJpk ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $BTEnIi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                            }), $AInnSi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(297, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 298);
                            __builder3.AddComponentParameter(299, "Name", "Campaigns");
                            __builder3.AddAttribute$3(300, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(301, "div");
                                    __builder4.AddAttribute$5(302, "class", "flex mgb");
                                    __builder4.AddMarkupContent(303, "<h3 class=\"mgt-a mgb-0\">Campaigns</h3>\r\n                                ");
                                    __builder4.OpenElement(304, "button");
                                    __builder4.AddAttribute$5(305, "class", "mgl-a bg-primary pdy-1 pdx-2 corner-5 mdi mdi-plus fw-bold");
                                    __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 306, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                    {
                                        this.current = new $.$bTOs.LCCCCM.CommunityCampaignBotPostModel().$ctor$6();
                                        this.mpage = "EditCampaign";
                                    }, $tJtsnd ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                    __builder4.AddContent$4(307, "Create Campaign");
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(308, "\r\n                            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 309);
                                    __builder4.AddComponentParameter(310, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                    __builder4.AddComponentParameter(311, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                                    __builder4.AddComponentParameter(312, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n | 2251799813685248n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                                    __builder4.AddAttribute$3(313, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*____*/ ____) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 314);
                                            __builder5.AddAttribute$3(315, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(316, "Name");
                                                }, $CFefUj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $QEHoBe ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(317, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(318, context.Data.Title);
                                                }, $EFOPXj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $NmSmEa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(319, "\r\n                                ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 320);
                                            __builder5.AddAttribute$3(321, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(322, "Status");
                                                }, $pQMGil ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $irSPxi ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(323, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    /*var*/ let bg = (() =>
                                                    {
                                                        let $switch18 = context.Data.State;
                                                        if ($switch18 === 0/*CommunityCampaignBotState.Draft*/)
                                                        {
                                                            return "dark";
                                                        }
                                                        if ($switch18 === 1/*CommunityCampaignBotState.Published*/)
                                                        {
                                                            return "primary";
                                                        }
                                                        if ($switch18 === 2/*CommunityCampaignBotState.Paused*/)
                                                        {
                                                            return "warning";
                                                        }
                                                        if ($switch18 === 5/*CommunityCampaignBotState.Rejected*/)
                                                        {
                                                            return "error";
                                                        }
                                                        if ($switch18 === 3/*CommunityCampaignBotState.Running*/)
                                                        {
                                                            return "success";
                                                        }
                                                        if ($switch18 === 4/*CommunityCampaignBotState.Finished*/)
                                                        {
                                                            return "success";
                                                        }
                                                        return "transparent";
                                                    })();
                                                    __builder6.OpenElement(324, "small");
                                                    __builder6.AddAttribute$5(325, "class", $.$strNN($.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((bg))) + " pdy-1") + " pdx") + " corner") + " ");
                                                    __builder6.AddContent$3(326, $.$box(context.Data.State, $.$bTOs.LCCCCM.CommunityCampaignBotState));
                                                    __builder6.CloseElement();
                                                }, $MVbsPe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $Etjoje ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(327, "\r\n                                ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 328);
                                            __builder5.AddAttribute$3(329, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(330, "Contacts");
                                                }, $XmzrNh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $pFhlpl ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(331, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$3(332, $.$box(context.Data.TotalContacts, $.$$.S.Int32));
                                                }, $EnmrEf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $fBXSQd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(333, "\r\n                                ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 334);
                                            __builder5.AddAttribute$3(335, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(336, "Pickups");
                                                }, $HJzYff ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $cfQIgj ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(337, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$3(338, $.$box(context.Data.TotalPicked, $.$$.S.Int32));
                                                }, $eNmMbl ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $lEYkZi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                            __builder5.AddMarkupContent(339, "\r\n                                ");
                                            __builder5.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 340);
                                            __builder5.AddAttribute$3(341, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.AddContent$4(342, "Actions");
                                                }, $AgbIFc ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $xcYcUf ??= {"r":6881395,"p":[{"n":"context","p":$.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.AddAttribute$3(343, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel))))().$ctor(this, ( (/*context*/ context) =>
                                            {
                                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                                {
                                                    __builder6.OpenElement(344, "div");
                                                    __builder6.AddAttribute$5(345, "class", "flex");
                                                    __builder6.OpenElement(346, "button");
                                                    __builder6.AddAttribute$5(347, "title", "Edit");
                                                    __builder6.AddAttribute$5(348, "class", "mdi mdi-pencil cl-error bg-transparent");
                                                    __builder6.AddAttribute$7($.$macw.MACW.MouseEventArgs, 349, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                    {
                                                        this.current = context.Data;
                                                        this.mpage = "EditCampaign";
                                                    }, $rgKMTh ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                                    __builder6.CloseElement();
                                                    __builder6.AddMarkupContent(350, "\r\n                                            ");
                                                    __builder6.OpenElement(351, "button");
                                                    __builder6.AddAttribute$5(352, "title", "Open");
                                                    __builder6.AddAttribute$5(353, "class", "mdi mdi-book-open cl-primary bg-transparent");
                                                    __builder6.AddAttribute$7($.$macw.MACW.MouseEventArgs, 354, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                                    {
                                                        this.current = context.Data;
                                                        this.mpage = "ViewCampaign";
                                                    }, $BOfyOe ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                                    __builder6.CloseElement();
                                                    __builder6.CloseElement();
                                                }, $fTZqce ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                            }), $FISsSa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                            __builder5.CloseComponent();
                                        }, $YxZjJj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                                    }), $HCWrah ??= {"r":6881395,"p":[{"n":"____","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $wsAgIa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                            }), $zWzOBi ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(355, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 356);
                            __builder3.AddComponentParameter(357, "Name", "EditCampaign");
                            __builder3.AddAttribute$3(358, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (this.current !== null)
                                    {
                                        __builder4.AddMarkupContent(359, "<h3 class=\"mgt-0\">New Camapaign</h3>\r\n                                ");
                                        __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignEditor, 360);
                                        __builder4.AddComponentParameter(361, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.current));
                                        __builder4.CloseComponent();
                                    }
                                }, $bCcrOc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                            }), $ZfHOpb ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.AddMarkupContent(362, "\r\n                        ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$6.View, 363);
                            __builder3.AddComponentParameter(364, "Name", "ViewCampaign");
                            __builder3.AddAttribute$3(365, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*__*/ __) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (this.current !== null)
                                    {
                                        __builder4.OpenElement(366, "div");
                                        __builder4.AddAttribute$5(367, "class", "flex mgb");
                                        __builder4.OpenElement(368, "h4");
                                        __builder4.AddAttribute$5(369, "class", "mgy-a");
                                        __builder4.AddContent$4(370, this.current.Title);
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(371, "\r\n                                    ");
                                        __builder4.OpenElement(372, "button");
                                        __builder4.AddAttribute$5(373, "class", "mgl-a bg-primary pd-2 corner mdi mdi-pencil");
                                        __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 374, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                        {
                                            this.mpage = "EditCampaign";
                                        }, $phcErb ??= {"r":65537,"n":"","d":1464778,"h":0,"f":17825794})));
                                        __builder4.AddContent$4(375, "Edit");
                                        __builder4.CloseElement();
                                        if (this.current.State === 3/*CommunityCampaignBotState.Running*/)
                                        {
                                            __builder4.OpenElement(376, "button");
                                            __builder4.AddAttribute$5(377, "class", "mgl bg-error pd-2 corner mdi mdi-stop");
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 378, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.PauseCurrent)));
                                            __builder4.AddContent$4(379, "Pause");
                                            __builder4.CloseElement();
                                        }
                                        else if (this.current.State === 2/*CommunityCampaignBotState.Paused*/)
                                        {
                                            __builder4.OpenElement(380, "button");
                                            __builder4.AddAttribute$5(381, "class", "mgl bg-success pd-2 corner mdi mdi-play");
                                            __builder4.AddAttribute$7($.$macw.MACW.MouseEventArgs, 382, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.RunCurrent)));
                                            __builder4.AddContent$4(383, "Run");
                                            __builder4.CloseElement();
                                        }
                                        __builder4.CloseElement();
                                        __builder4.AddMarkupContent(384, "\r\n                                ");
                                        __builder4.OpenComponent$1($.$tUzp.LCCCCS$1.CommunityCampaignView, 385);
                                        __builder4.AddComponentParameter(386, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.current));
                                        __builder4.CloseComponent();
                                    }
                                }, $UJJkAh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                            }), $fDehmc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1464778,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $TjPoch ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }, $IQUCte ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1464778,"h":0,"f":17825794});
                }), $BWkSLh ??= {"r":6881395,"p":[{"n":"user","p":131193}],"n":"","d":1464778,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25771268554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(17181333962)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181333962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181333962)
            
            //--TRIMMABLE-BOUNDARY-START(17181333962)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17181333962)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103080679882)
                this.mpage = "Dashboard";
                //--TRIMMABLE-BOUNDARY-END(103080679882)
                
                //--TRIMMABLE-BOUNDARY-START(107375647178)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(107375647178)
                
                //--TRIMMABLE-BOUNDARY-START(141735385546)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(141735385546)
                
                //--TRIMMABLE-BOUNDARY-START(111670614474)
                this.OnClose = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(111670614474)
                
            }
            static $h = 1464778;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124555516362),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310876106,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1464778,
      "h": 124555516362,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124555516362),
//--TRIMMABLE-BOUNDARY-START(107375647178),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131006922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325320138,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1464778,
      "h": 107375647178,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375647178),
//--TRIMMABLE-BOUNDARY-START(141735385546),
    {
      "p": 1071562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900810698,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505189322,
        "f": 83886081
      },
      "n": "Service",
      "d": 1464778,
      "h": 141735385546,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735385546),
//--TRIMMABLE-BOUNDARY-START(111670614474),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720941514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915254730,
        "f": 83886081
      },
      "n": "OnClose",
      "d": 1464778,
      "h": 111670614474,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670614474)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176095123914),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1464778,
      "h": 176095123914,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176095123914),
//--TRIMMABLE-BOUNDARY-START(90195777994),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1464778,
      "h": 90195777994,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195777994),
//--TRIMMABLE-BOUNDARY-START(115965581770),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1464778,
      "h": 115965581770,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(115965581770),
//--TRIMMABLE-BOUNDARY-START(38656170442),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1464778,
      "h": 38656170442,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656170442),
//--TRIMMABLE-BOUNDARY-START(180390091210),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 417192
        }
      ],
      "n": "UI_BoxChanged",
      "d": 1464778,
      "h": 180390091210,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(180390091210),
//--TRIMMABLE-BOUNDARY-START(94490745290),
    {
      "r": 178454529,
      "n": "LogOut",
      "d": 1464778,
      "h": 94490745290,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(94490745290),
//--TRIMMABLE-BOUNDARY-START(51541072330),
    {
      "r": 178454529,
      "n": "FundAsync",
      "d": 1464778,
      "h": 51541072330,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(51541072330),
//--TRIMMABLE-BOUNDARY-START(133145450954),
    {
      "r": 178454529,
      "n": "PauseCurrent",
      "d": 1464778,
      "h": 133145450954,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(133145450954),
//--TRIMMABLE-BOUNDARY-START(137440418250),
    {
      "r": 178454529,
      "n": "RunCurrent",
      "d": 1464778,
      "h": 137440418250,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(137440418250),
//--TRIMMABLE-BOUNDARY-START(21476301258),
    {
      "r": 178454529,
      "n": "Authenticate",
      "d": 1464778,
      "h": 21476301258,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(21476301258),
//--TRIMMABLE-BOUNDARY-START(120260549066),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 1464778,
      "h": 120260549066,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(120260549066),
//--TRIMMABLE-BOUNDARY-START(25771268554),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1464778,
      "h": 25771268554,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771268554)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98785712586),
    {
      "t": 1530314,
      "n": "mode",
      "d": 1464778,
      "h": 98785712586,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785712586),
//--TRIMMABLE-BOUNDARY-START(42951137738),
    {
      "t": 1310721,
      "n": "email",
      "d": 1464778,
      "h": 42951137738,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951137738),
//--TRIMMABLE-BOUNDARY-START(128850483658),
    {
      "t": 1310721,
      "n": "password",
      "d": 1464778,
      "h": 128850483658,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128850483658),
//--TRIMMABLE-BOUNDARY-START(30066235850),
    {
      "t": 1310721,
      "n": "confirmPassword",
      "d": 1464778,
      "h": 30066235850,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066235850),
//--TRIMMABLE-BOUNDARY-START(171800156618),
    {
      "t": 1310721,
      "n": "token",
      "d": 1464778,
      "h": 171800156618,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(171800156618),
//--TRIMMABLE-BOUNDARY-START(47246105034),
    {
      "t": 1310721,
      "n": "errorMessage",
      "d": 1464778,
      "h": 47246105034,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246105034),
//--TRIMMABLE-BOUNDARY-START(103080679882),
    {
      "t": 1310721,
      "n": "mpage",
      "d": 1464778,
      "h": 103080679882,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103080679882),
//--TRIMMABLE-BOUNDARY-START(34361203146),
    {
      "t": 1863683,
      "n": "current",
      "d": 1464778,
      "h": 34361203146,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361203146),
//--TRIMMABLE-BOUNDARY-START(184685058506),
    {
      "t": 262145,
      "n": "working",
      "d": 1464778,
      "h": 184685058506,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184685058506)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181333962),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1464778,
      "h": 17181333962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181333962)
  ],
  "h": 1464778
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.Dashboard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}Dashboard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1464778)
        
        

        //--TRIMMABLE-BOUNDARY-START(1399242)
        $asm.$cls(`$tUzp.LCCCCS$1.CommunityCampaignView`, ($self) => class CommunityCampaignView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(34361137610)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaignview";
            }
            //--TRIMMABLE-BOUNDARY-END(34361137610)
            
            //--TRIMMABLE-BOUNDARY-START(8591333834)
            /*bool */ get Active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476235722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ViewModel.State !== 2/*CommunityCampaignBotState.Paused*/;
            }
            /*bool */ set Active(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541006794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value)
                {
                    this.ViewModel.State = 1/*CommunityCampaignBotState.Published*/;
                }
                else 
                {
                    this.ViewModel.State = 2/*CommunityCampaignBotState.Paused*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591333834)
            
            //--TRIMMABLE-BOUNDARY-START(42951072202)
            /*Task *//*async*/  Save()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951072202);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.NotifySuccess(null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42951072202)
            
            //--TRIMMABLE-BOUNDARY-START(38656104906)
            /*Task *//*async*/  Requeue(/*CommunityCampaignBotContactModel*/ ct)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656104906);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ct.CallProgress = null;
                    this.ViewModel.Contacts = this.ViewModel.Contacts;
                    if (this.ViewModel.State === 4/*CommunityCampaignBotState.Finished*/)
                    {
                        this.ViewModel.State = 3/*CommunityCampaignBotState.Running*/;
                    }
                    ($t2 = this.Save(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656104906)
            
            //--TRIMMABLE-BOUNDARY-START(12886301130)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886301130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "hf pos-rel scroll-y");
                if (this.ViewModel.MediaUrl === null)
                {
                    __builder.AddMarkupContent(2, "<div class=\"mgb-5 bg-error-01 pd bdl bd-error bdw-2\"><p class=\"mg-0\">Your campaign is missing a jingle file. A jingle file is an audio that your user hear when we call then on your behalf. Edit and add one, then publish to review.</p></div>");
                }
                if (this.ViewModel.State === 2/*CommunityCampaignBotState.Paused*/ || this.ViewModel.State === 1/*CommunityCampaignBotState.Published*/ || this.ViewModel.State === 5/*CommunityCampaignBotState.Rejected*/)
                {
                    __builder.OpenElement(3, "div");
                    __builder.AddAttribute$5(4, "class", "mgb-5 bg-error-01 pd bdl bd-error bdw-2");
                    let $switch3 = this.ViewModel.State;
                    switch($switch3)
                    {
                        case 2/*CommunityCampaignBotState.Paused*/:
                        __builder.AddMarkupContent(5, "<p class=\"mg-0\">Your campaign is not currently running as it is paused by you. To run this campaign mark it as active</p>");
                        break;
                        case 1/*CommunityCampaignBotState.Published*/:
                        __builder.AddMarkupContent(6, "<p class=\"mg-0\">Your campaign is not currently running as it is under review. We will let you know when approved.</p>");
                        break;
                        case 5/*CommunityCampaignBotState.Rejected*/:
                        __builder.AddMarkupContent(7, "<p class=\"mg-0\">Your campaign is not currently running as it is rejected.</p>\r\n                    ");
                        __builder.OpenElement(8, "p");
                        __builder.AddAttribute$5(9, "class", "mgb-0");
                        __builder.AddContent$4(10, "Reason: ");
                        __builder.OpenElement(11, "b");
                        __builder.AddAttribute$5(12, "class", "cl-error");
                        __builder.AddContent$4(13, this.ViewModel.StateReason);
                        __builder.CloseElement();
                        __builder.AddContent$4(14, ". Edit the campaign and submit again for review.");
                        __builder.CloseElement();
                        break;
                    }
                    __builder.CloseElement();
                }
                __builder.OpenElement(15, "div");
                __builder.AddAttribute$5(16, "class", "grid colm-15 gap-1");
                __builder.OpenElement(17, "div");
                __builder.AddAttribute$5(18, "class", "bd pd corner bg-chart1-01 flex");
                __builder.AddMarkupContent(19, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart1-06 round flex\"><i class=\"mdi mdi-phone fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n            ");
                __builder.OpenElement(20, "div");
                __builder.AddAttribute$5(21, "class", "mgl-a text-right");
                __builder.AddMarkupContent(22, "<b>Contacts</b>\r\n                ");
                __builder.OpenElement(23, "h1");
                __builder.AddAttribute$5(24, "class", "mg-0 cl-primary");
                __builder.AddContent$3(25, $.$box(this.ViewModel.TotalContacts, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(26, "\r\n        ");
                __builder.OpenElement(27, "div");
                __builder.AddAttribute$5(28, "class", "bd pd corner bg-chart2-01 flex");
                __builder.AddMarkupContent(29, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart2-06 round flex\"><i class=\"mdi mdi-phone-forward fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n            ");
                __builder.OpenElement(30, "div");
                __builder.AddAttribute$5(31, "class", "mgl-a text-right");
                __builder.AddMarkupContent(32, "<b>Called</b>\r\n                ");
                __builder.OpenElement(33, "h1");
                __builder.AddAttribute$5(34, "class", "mg-0 cl-primary");
                __builder.AddContent$3(35, $.$box(this.ViewModel.TotalDialed, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(36, "\r\n        ");
                __builder.OpenElement(37, "div");
                __builder.AddAttribute$5(38, "class", "bd pd corner bg-chart3-01 flex");
                __builder.AddMarkupContent(39, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart3-06 round flex\"><i class=\"mdi mdi-phone-check fsz-30 mg-a flex mgc-a cl-white\"></i></div>\r\n            ");
                __builder.OpenElement(40, "div");
                __builder.AddAttribute$5(41, "class", "mgl-a text-right");
                __builder.AddMarkupContent(42, "<b>Picked</b>\r\n                ");
                __builder.OpenElement(43, "h1");
                __builder.AddAttribute$5(44, "class", "mg-0 cl-success");
                __builder.AddContent$3(45, $.$box(this.ViewModel.TotalPicked, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(46, "\r\n        ");
                __builder.OpenElement(47, "div");
                __builder.AddAttribute$5(48, "class", "bd pd corner bg-chart4-01 flex");
                __builder.AddMarkupContent(49, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart4-06 round flex\"><i class=\"mdi mdi-cancel cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n            ");
                __builder.OpenElement(50, "div");
                __builder.AddAttribute$5(51, "class", "mgl-a text-right");
                __builder.AddMarkupContent(52, "<b>Rejected</b>\r\n                ");
                __builder.OpenElement(53, "h1");
                __builder.AddAttribute$5(54, "class", "mg-0 cl-error");
                __builder.AddContent$3(55, $.$box(this.ViewModel.TotalRejected, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(56, "\r\n        ");
                __builder.OpenElement(57, "div");
                __builder.AddAttribute$5(58, "class", "bd pd corner bg-chart5-01 flex");
                __builder.AddMarkupContent(59, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart5-06 round flex\"><i class=\"mdi mdi-phone-remove cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n            ");
                __builder.OpenElement(60, "div");
                __builder.AddAttribute$5(61, "class", "mgl-a text-right");
                __builder.AddMarkupContent(62, "<b>Unreached</b>\r\n                ");
                __builder.OpenElement(63, "h1");
                __builder.AddAttribute$5(64, "class", "mg-0 cl-warning");
                __builder.AddContent$3(65, $.$box(this.ViewModel.TotalUnreachable, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(66, "\r\n        ");
                __builder.OpenElement(67, "div");
                __builder.AddAttribute$5(68, "class", "bd pd corner bg-chart6-01 flex");
                __builder.AddMarkupContent(69, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart6-06 round flex\"><i class=\"mdi mdi-timer cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n            ");
                __builder.OpenElement(70, "div");
                __builder.AddAttribute$5(71, "class", "mgl-a text-right");
                __builder.AddMarkupContent(72, "<b>Duration</b>\r\n                ");
                __builder.OpenElement(73, "h1");
                __builder.AddAttribute$5(74, "class", "mg-0 cl-chart6");
                __builder.AddContent$3(75, $.$box(this.ViewModel.TotalEngagements, $.$$.S.Int32));
                __builder.AddContent$4(76, "s");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(77, "\r\n        ");
                __builder.OpenElement(78, "div");
                __builder.AddAttribute$5(79, "class", "bd pd corner bg-chart8-01 flex");
                __builder.AddMarkupContent(80, "<div class=\"miwx-05 mawx-05 hx-05 bg-chart8-06 round flex\"><i class=\"mdi mdi-currency-ngn cl-white fsz-30 mg-a flex mgc-a\"></i></div>\r\n            ");
                __builder.OpenElement(81, "div");
                __builder.AddAttribute$5(82, "class", "mgl-a text-right");
                __builder.AddMarkupContent(83, "<b>Spent</b>\r\n                ");
                __builder.OpenElement(84, "h2");
                __builder.AddAttribute$5(85, "class", "mg-0 cl-primary");
                __builder.AddContent$4(86, "\u20A6"/*Money.NairaSymbol*/);
                __builder.AddContent$4(87, $.$fPer.LCFCS$6.NumberExtension.FormatScientific(this.ViewModel.Spent, "0.##", false));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(88, "\r\n    \r\n    ");
                __builder.AddMarkupContent(89, "<h4 class=\"mgb-1\">Call details</h4>\r\n    ");
                __builder.OpenElement(90, "div");
                __builder.AddAttribute$5(91, "class", "scroll-x");
                __builder.OpenElement(92, "table");
                __builder.AddAttribute$5(93, "class", "miwf");
                __builder.AddAttribute$5(94, "style", "border-collapse: collapse;");
                __builder.AddMarkupContent(95, "<thead><tr class=\"bg-primary-01 text-left\"><th class=\"pd-2\">Phone</th>\r\n                    <th class=\"pd-2\">Date</th>\r\n                    <th class=\"pd-2\">Status</th>\r\n                    <th class=\"pd-2\">Cost</th>\r\n                    <th class=\"pd-2\"></th></tr></thead>\r\n            ");
                __builder.OpenElement(96, "tbody");
                if (this.ViewModel.Contacts !== null)
                {
                    let $en4 = this.ViewModel.Contacts.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let ct = $en4.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let theme = ct.CallProgress === 3/*CallResultState.Completed*/ ? "success" : ct.CallProgress === 6/*CallResultState.NoAnswer*/ ? "error" : ct.CallProgress === 7/*CallResultState.NotReachable*/ ? "fatal" : "gray";
                            __builder.OpenElement(97, "tr");
                            __builder.OpenElement(98, "td");
                            __builder.AddAttribute$5(99, "class", "pd-2 bdb");
                            __builder.AddContent$4(100, ct.Number);
                            __builder.CloseElement();
                            __builder.AddMarkupContent(101, "\r\n                            ");
                            __builder.OpenElement(102, "td");
                            __builder.AddAttribute$5(103, "class", "pd-2 bdb");
                            __builder.AddContent$4(104, (ct.QueueingTime?.ToString$3("yyyy/MM/dd HH:mm:ss"/*DataConverter.DateTimeFormat*/) ?? null));
                            __builder.CloseElement();
                            __builder.AddMarkupContent(105, "\r\n                            ");
                            __builder.OpenElement(106, "td");
                            __builder.AddAttribute$5(107, "class", "pd-2 bdb");
                            __builder.OpenElement(108, "small");
                            __builder.AddAttribute$5(109, "class", $.$strNN($.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((theme))) + " pdy-1") + " pdx") + " corner") + " nobreak");
                            /*LivingThing.Core.Frameworks.Common.Messaging.CallResultState?*/ let __ca1__;
                            __builder.AddContent$4(110, ((__ca1__ = ct.CallProgress) !== null ? ($.$$.S.Enum.ToStringT($.$fPer.LCFCM.CallResultState, $.$$.S.UInt32, $.$$.S.Nullable$$($.$fPer.LCFCM.CallResultState).Value$get.call(__ca1__)) ?? "Pending") : "Pending"));
                            if ($.$$.S.Int32.op_GreaterThan(ct.CallEngagementTime, 0))
                            {
                                __builder.OpenElement(111, "i");
                                __builder.AddContent$4(112, $.$strNN(" - " + $.$strNN($.$$.S.Nullable$$($.$$.S.Int32).ToString.call(ct.CallEngagementTime))) + "s");
                                __builder.CloseElement();
                            }
                            __builder.CloseElement();
                            __builder.CloseElement();
                            __builder.AddMarkupContent(113, "\r\n                            ");
                            __builder.OpenElement(114, "td");
                            __builder.AddAttribute$5(115, "class", "pd-2 bdb fw-bold");
                            if (ct.CallCost !== null)
                            {
                                __builder.AddContent$4(116, "\u20A6"/*Money.NairaSymbol*/);
                                __builder.AddContent$3(117, $.$box(ct.CallCost, $.$$.S.Double));
                            }
                            __builder.CloseElement();
                            __builder.AddMarkupContent(118, "\r\n                            ");
                            __builder.OpenElement(119, "td");
                            __builder.AddAttribute$5(120, "class", "pd-2 bdb");
                            if (ct.CallProgress > 2/*CallResultState.Queued*/ && (this.ViewModel.State === 4/*CommunityCampaignBotState.Finished*/ || this.ViewModel.State === 1/*CommunityCampaignBotState.Published*/ || this.ViewModel.State === 3/*CommunityCampaignBotState.Running*/))
                            {
                                __builder.OpenElement(121, "button");
                                __builder.AddAttribute$5(122, "title", "Requeue");
                                __builder.AddAttribute$5(123, "class", "mdi mdi-refresh cl-warning bg-transparent");
                                __builder.AddAttribute$5(124, "type", "button");
                                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 125, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Requeue(ct);
                                }, $DJvege ??= {"r":178454529,"n":"","d":1399242,"h":0,"f":17825794})));
                                __builder.CloseElement();
                            }
                            __builder.CloseElement();
                            __builder.CloseElement();
                        }
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(12886301130)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4296366538)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296366538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296366538)
            
            //--TRIMMABLE-BOUNDARY-START(4296366538)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296366538)
            
            static $h = 1399242;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361137610),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066170314,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1399242,
      "h": 34361137610,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361137610),
//--TRIMMABLE-BOUNDARY-START(8591333834),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476235722,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541006794,
        "f": 83886082
      },
      "n": "Active",
      "d": 1399242,
      "h": 8591333834,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8591333834)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951072202),
    {
      "r": 178454529,
      "n": "Save",
      "d": 1399242,
      "h": 42951072202,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42951072202),
//--TRIMMABLE-BOUNDARY-START(38656104906),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ct",
          "p": 552963
        }
      ],
      "n": "Requeue",
      "d": 1399242,
      "h": 38656104906,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38656104906),
//--TRIMMABLE-BOUNDARY-START(12886301130),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1399242,
      "h": 12886301130,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886301130)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296366538),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1399242,
      "h": 4296366538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296366538)
  ],
  "h": 1399242
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.CommunityCampaignView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CommunityCampaignView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1399242)
        
        

        //--TRIMMABLE-BOUNDARY-START(1268170)
        $asm.$cls(`$tUzp.LCCCCS$1.CommunityCampaignEditor`, ($self) => class CommunityCampaignEditor extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(180389894602)
            /*string */ get OptimizedComponentName()
            {
                return "communitycampaigneditor";
            }
            //--TRIMMABLE-BOUNDARY-END(180389894602)
            
            //--TRIMMABLE-BOUNDARY-START(154620090826)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620090826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Http = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$snh.SNH.HttpClient, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$tUzp.LCCCCS.CommunityCampaignBotService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(154620090826)
            
            //--TRIMMABLE-BOUNDARY-START(42950941130)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950941130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 4);
                    __builder2.AddComponentParameter(5, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.target));
                    __builder2.AddComponentParameter(6, "class", "grid colm-3 gap-2 mgb-15");
                    __builder2.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(8, "div");
                            __builder3.AddAttribute$5(9, "class", "bg-card pd-5 shadow");
                            __builder3.AddMarkupContent(10, "<h3 class=\"mgt-0 mdi mdi-cog mgrc-1\">Campaign Settings</h3>\r\n            ");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), 11);
                            __builder3.AddComponentParameter(12, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.target));
                            __builder3.AddComponentParameter(13, "Filter", new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor(this, (this.FormFilter)));
                            __builder3.AddComponentParameter(14, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCF$2.FormBuilderFeatures, 0/*FormBuilderFeatures.Default*/ | 256/*FormBuilderFeatures.ComplexFieldsAsOverlay*/), $.$hDPm.LCFCCF$2.FormBuilderFeatures));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(15, "\r\n        ");
                            __builder3.OpenElement(16, "div");
                            __builder3.AddAttribute$5(17, "class", "bg-card pd-5 shadow corner");
                            __builder3.OpenElement(18, "div");
                            __builder3.AddAttribute$5(19, "class", "flex mgb");
                            __builder3.AddMarkupContent(20, "<h3 class=\"fill mgy-a mdi mdi-contacts mgrc-2\">Target Contacts</h3>\r\n                ");
                            __builder3.OpenElement(21, "div");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCF.FileUpload, 22);
                            __builder3.AddComponentParameter(23, "OnFileSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo)), $.$hDPm.LCFCC$1.ComponentExtension.Create$3($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), $.$$.STT.ValueTask))().$ctor(this, this.FileSelected))));
                            __builder3.AddAttribute$3(24, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(25, "<a class=\"d-block mdi mdi-plus bd pdy-2 pdx-3 corner text-center bg-success-02\"><b>Upload</b></a>");
                            }), $FrmGUc ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1268170,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(26, "\r\n            ");
                            $.$tUzp._LCCCCSC.TypeInference.CreateInputEditor_0($.$$.S.String, __builder3, 27, 28, 16n, 29, "Enter one contact per line", 30, "10", 31, "wf", 32, this.Contacts, 33, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                            {
                                return this.Contacts = __value;
                            }, $CyUZob ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1268170,"h":0,"f":17825794}), this.Contacts)), 34, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Contacts"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $pIJdbf ??= {"r":38797349,"n":"","d":1268170,"h":0,"f":17825794})).Invoke()));
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(35, "\r\n        ");
                            __builder3.OpenElement(36, "div");
                            __builder3.AddAttribute$5(37, "class", "bg-card pd-5 shadow corner");
                            __builder3.AddMarkupContent(38, "<h3 class=\"mgt-0 mgb-5 mdi mdi-audio-video mgrc-1\">Jingle</h3>\r\n            ");
                            __builder3.AddMarkupContent(39, "<p class=\"fsz-small\">This is the audio file that will be played to the contacts when the Bot call them.</p>\r\n            ");
                            __builder3.AddMarkupContent(40, "<p class=\"fsz-12\">\r\n                CampaignBot recommends you keep your jingle within 30s period to maintain user's attention.\r\n            </p>\r\n                        ");
                            $.$tUzp._LCCCCSC.TypeInference.CreateInputEditor_1($.$$.S.String, __builder3, 41, 42, "mgt-10", 43, 14n, 44, this.target.MediaUrl, 45, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.target.MediaUrl = __value;
                                return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.AudioSelected));
                            }, $YWJGmb ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":1268170,"h":0,"f":17825794}), this.target.MediaUrl), this.target.MediaUrl)), 46, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "target"), "MediaUrl"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $iwVByk ??= {"r":38797349,"n":"","d":1268170,"h":0,"f":17825794})).Invoke()));
                            __builder3.AddMarkupContent(47, "\r\n            ");
                            __builder3.AddMarkupContent(48, "<h3 class=\"mgt-10 mgb-1\">Audio Playback</h3>\r\n            ");
                            __builder3.AddContent$1(49, $.$tUzp.LCCCCS$1.CampaignView.AudioPlayer(this.target, "mgt wf"));
                            if ($.$$.S.Int32.op_GreaterThan(this.target.MediaPeriod, 30))
                            {
                                __builder3.OpenElement(50, "p");
                                __builder3.AddAttribute$5(51, "class", "cl-fatal fsz-small");
                                __builder3.AddMarkupContent(52, "\r\n                    Your media file is ");
                                __builder3.AddContent$4(53, $.$strNN($.$$.S.Nullable$$($.$$.S.Int32).ToString.call(this.target.MediaPeriod)) + "s");
                                __builder3.AddMarkupContent(54, " long.\r\n                    Research indicates that long and elaborous media doesnt perform well for advertisement as they quickly loose user attention.\r\n                    Get straight to the point in your campaign jingle.\r\n                ");
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(55, "\r\n        ");
                            __builder3.AddMarkupContent(56, "<div class=\"bg-card pd shadow corner\"><h3 class=\"mg-0\">Follow-ups / Tier-2 funnels</h3>\r\n            <h1 class=\"text-center cl-error\">Coming Soon</h1></div>\r\n        ");
                            __builder3.OpenElement(57, "div");
                            __builder3.AddAttribute$5(58, "class", "pos-abs b-0 l-0 r-0 pd bg-card flex");
                            __builder3.OpenElement(59, "div");
                            __builder3.AddAttribute$5(60, "class", "fill text-center cl-error");
                            __builder3.AddContent$4(61, this.LoadErrorMessage);
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(62, "\r\n            ");
                            __builder3.OpenElement(63, "button");
                            __builder3.AddAttribute$5(64, "class", "bg-secondary corner pd miwx-1");
                            __builder3.AddAttribute$5(65, "type", "button");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 66, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.SaveDraft)));
                            __builder3.AddContent$4(67, "SAVE DRAFT");
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(68, "\r\n            ");
                            __builder3.OpenElement(69, "button");
                            __builder3.AddAttribute$5(70, "class", "mgl bg-primary corner pd miwx-1");
                            __builder3.AddAttribute$5(71, "type", "button");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 72, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Publish)));
                            __builder3.AddContent$4(73, "PUBLISH");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $kJFWJg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1268170,"h":0,"f":17825794});
                    }), $QgJfIi ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":1268170,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $QqlQij ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1268170,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(42950941130)
            
            //--TRIMMABLE-BOUNDARY-START(146030156234)
            /*RenderFragment? */ GetMusics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030156234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Settings.CampaignBotBackgroundMusic>?*/ let __ca2__;
                if ((__ca1__ = this.settings) !== null ? ((__ca2__ = __ca1__.BackgroundMusics) !== null ? $.$sl.SL.Enumerable.Any$1($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, __ca2__) : false) : false)
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings*/ let __ca3__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Settings.CampaignBotBackgroundMusic>*/ let __ca4__;
                        /*var*/ let useIcon = ((__ca3__ = this.settings) !== null ? ((__ca4__ = __ca3__.BackgroundMusics) !== null ? $.$sl.SL.Enumerable.Any($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, __ca4__, new ($.$$.S.Func$$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, $.$$.S.Boolean))().$ctor(this,  (/**/ m) =>
                        {
                            return !$.$$.S.String.IsNullOrEmpty(m.Icon);
                        }, $ypjIKa ??= {"r":262145,"p":[{"n":"m","p":4354051}],"n":"","d":1268170,"h":0,"f":17825794})) : false) : false);
                        let $en1 = this.settings.BackgroundMusics.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let music = $en1.SCG$IEnumerator$$$Current;
                            {
                                __builder2.OpenElement(74, "div");
                                __builder2.AddAttribute$5(75, "class", "pd flex");
                                if (useIcon)
                                {
                                    __builder2.OpenElement(76, "div");
                                    __builder2.AddAttribute$5(77, "class", "wx-05");
                                    __builder2.OpenElement(78, "img");
                                    __builder2.AddAttribute$5(79, "src", music.Icon);
                                    __builder2.AddAttribute$5(80, "class", "wf");
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                }
                                __builder2.OpenElement(81, "div");
                                __builder2.AddAttribute$5(82, "class", "stack fill mgl");
                                __builder2.OpenElement(83, "h4");
                                __builder2.AddAttribute$5(84, "class", "mg-0");
                                __builder2.AddContent$4(85, music.Title);
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(86, "\r\n                    ");
                                __builder2.OpenElement(87, "audio");
                                __builder2.AddAttribute$6(88, "controls");
                                __builder2.AddAttribute$5(89, "class", "wf");
                                __builder2.AddAttribute$5(90, "src", music.File);
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(91, "\r\n                ");
                                __builder2.OpenElement(92, "div");
                                __builder2.AddAttribute$5(93, "class", "mgy-a mgl");
                                __builder2.OpenElement(94, "i");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 95, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.ToggleBgMusic($.$clone(music));
                                }, $brMTRa ??= {"r":65537,"n":"","d":1268170,"h":0,"f":17825794})));
                                __builder2.AddAttribute$5(96, "class", $.$strNN($.$strNN($.$strNN("mdi" + " mdi-checkbox-marked-outline") + " fsz-30") + " ") + $.$strNN(((this.target?.SpeechBgMusic ?? null) === music.File ? "cl-success" : "")));
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                    }, $QSpzMd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1268170,"h":0,"f":17825794});
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146030156234)
            
            //--TRIMMABLE-BOUNDARY-START(150325123530)
            /*HttpClient*/ Http = null;
            //--TRIMMABLE-BOUNDARY-END(150325123530)
            
            //--TRIMMABLE-BOUNDARY-START(223339567562)
            /*CommunityCampaignBotService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(223339567562)
            
            //--TRIMMABLE-BOUNDARY-START(167504992714)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(167504992714)
            
            //--TRIMMABLE-BOUNDARY-START(163210025418)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210025418)
            
            //--TRIMMABLE-BOUNDARY-START(317828848074)
            /*IEnumerable<CommunityCampaignBotVoiceLocaleModel>?*/ voices = null;
            //--TRIMMABLE-BOUNDARY-END(317828848074)
            
            //--TRIMMABLE-BOUNDARY-START(270584207818)
            /*CommunityCampaignBotGlobalSettings?*/ settings = null;
            //--TRIMMABLE-BOUNDARY-END(270584207818)
            
            //--TRIMMABLE-BOUNDARY-START(296354011594)
            /*CommunityCampaignBotPostModel*/ target = null;
            //--TRIMMABLE-BOUNDARY-END(296354011594)
            
            //--TRIMMABLE-BOUNDARY-START(322123815370)
            /*int*/ wallet = 0;
            //--TRIMMABLE-BOUNDARY-END(322123815370)
            
            //--TRIMMABLE-BOUNDARY-START(60130810314)
            /*bool */ FormFilter(/*SchemaContext*/ schema, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130810314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Category")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "NamedLocation")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Wallet")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Icon")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Summary")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Post")
                {
                    return false;
                }
                if (property.LCFCD$1$IPropertyDescriptor$Name === "Targeting")
                {
                    return false;
                }
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(60130810314)
            
            //--TRIMMABLE-BOUNDARY-START(47245908426)
            /*string? */ get Contacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015712202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.target.Contacts !== null ? $.$$.S.String.Join$5("\r\n", $.$sl.SL.Enumerable.Select$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, this.target.Contacts, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return !$.$$.S.String.IsNullOrEmpty(c.Number);
                }, $fcYWre ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.ToUIString();
                }, $AegTIe ??= {"r":1310721,"p":[{"n":"c","p":552963}],"n":"","d":1268170,"h":0,"f":17825794}))) : null;
            }
            /*string? */ set Contacts(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929502154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cts = $.$$.S.String.Split$4.call(value, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Char.$type, [ /*\r*/ 13, /*\n*/ 10 ], null, null), 1/*StringSplitOptions.RemoveEmptyEntries*/);
                /*List<CommunityCampaignBotContactModel>*/ let contacts = new ($.$$.SCG.List$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor$1();
                let $i2 = 0;
                let $arr2 = cts;
                while ($i2 < $arr2.length)
                {
                    let ct = $arr2[$i2++];
                    /*var*/ let contact = $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.FromString(ct);
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca1__;
                    /*var*/ let existingContact = ((__ca1__ = this.target.Contacts) !== null ? ($.$sl.SL.Enumerable.SingleOrDefault$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca1__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.Number === contact.Number;
                    }, $LCLNWb ??= {"r":262145,"p":[{"n":"s","p":552963}],"n":"","d":1268170,"h":0,"f":17825794})) ?? null) : null);
                    if ((existingContact?.Number ?? null) === null)
                    {
                        existingContact = contact;
                    }
                    else 
                    {
                        existingContact.Age = contact.Age ?? existingContact.Age;
                        existingContact.Gender = contact.Gender ?? existingContact.Gender;
                        existingContact.Locale = contact.Locale ?? existingContact.Locale;
                    }
                    contacts.Add(existingContact);
                }
                this.target.Contacts = contacts;
            }
            //--TRIMMABLE-BOUNDARY-END(47245908426)
            
            //--TRIMMABLE-BOUNDARY-START(274879175114)
            /*double? */ get SetupAmounts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145254346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca2__;
                return (((__ca2__ = this.target.Contacts) !== null ? $.$sl.SL.Enumerable.Count$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca2__) : 0)) * (this.settings?.TokenPerCall ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(274879175114)
            
            //--TRIMMABLE-BOUNDARY-START(313533880778)
            /*int? */ get TotalEngatementTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735188938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca3__;
                return $.$$.S.Int32.op_Multiply$1((((__ca3__ = this.target.Contacts) !== null ? $.$sl.SL.Enumerable.Count$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca3__) : 0)), this.target.MediaPeriod);
            }
            //--TRIMMABLE-BOUNDARY-END(313533880778)
            
            //--TRIMMABLE-BOUNDARY-START(51540875722)
            /*double? */ get EngagementAmounts()
            {
                return this.TotalEngatementTime * (this.settings?.TokenPerEngagementSeconds ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(51540875722)
            
            //--TRIMMABLE-BOUNDARY-START(188979829194)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(188979829194)
            
            //--TRIMMABLE-BOUNDARY-START(188979829194)
            //--TRIMMABLE-BOUNDARY-START(30066039242)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066039242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066039242)
            
            //--TRIMMABLE-BOUNDARY-START(201864731082)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864731082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(201864731082)
            
            //--TRIMMABLE-BOUNDARY-END(188979829194)
            
            //--TRIMMABLE-BOUNDARY-START(171799960010)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799960010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.target = this.ViewModel ?? new $.$bTOs.LCCCCM.CommunityCampaignBotPostModel().$ctor$6();
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(171799960010)
            
            //--TRIMMABLE-BOUNDARY-START(176094927306)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094927306);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let path = $.$fPer.LCFC.PathUtility.ToUrl("https", this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost, this.ResolvePath("voices.json", true, true, false));
                    /*var*/ let json = ($t4 = $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$6($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleJsonFile, this.Http, path, (() =>
                    {
                        //new $.$stj.STJ.JsonSerializerOptions()
                        const $t5 = $.$stj.STJ.JsonSerializerOptions;
                        const $i5 = new $t5();
                        $i5.$ctor$1();
                        $i5.PropertyNameCaseInsensitive = true;
                        $i5.NumberHandling = 1/*JsonNumberHandling.AllowReadingFromString*/;
                        $i5.Converters.SCG$ICollection$$$Add(new $.$stj.STJS$1.JsonStringEnumConverter().$ctor$4($.$stj.STJ.JsonNamingPolicy.CamelCase, true));
                        return $i5;
                    })(), new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this.voices = json.Voices;
                    this.settings = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$bTOs.LCCCCS.IComunityCampaignBotRemoteService, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bTOs.LCCCCS.IComunityCampaignBotRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCCCCS$IComunityCampaignBotRemoteService$GetGlobalSettings();
                    }, $tRwyki ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).$h,"p":[{"n":"server","p":4222979}],"n":"","d":1268170,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))) ?? new $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings().$ctor$3();
                    ($t7 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094927306)
            
            //--TRIMMABLE-BOUNDARY-START(34361006538)
            /*Task *//*async*/  AudioSelected()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361006538);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t9, $r9;
                            this.target.State = 0/*CommunityCampaignBotState.Draft*/;
                            /*var*/ let timeSpan = ($t9 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$vWqU.LCFCCR.IMediaRemoteService, $.$$.S.TimeSpan, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.IMediaRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.TimeSpan)))().$ctor(this,  (/*server*/ server) =>
                            {
                                return server.LCFCCR$IMediaRemoteService$GetMediaDuration(this.target.MediaUrl);
                            }, $pQSgJa ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.TimeSpan)).$h,"p":[{"n":"server","p":7691688}],"n":"","d":1268170,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                            this.target.MediaPeriod = $.$cast((timeSpan.TotalSeconds + 2), $.$$.S.Int32);
                        });
                    }, $HCAtPe ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                    }, $WONZNc ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361006538)
            
            //--TRIMMABLE-BOUNDARY-START(287764077002)
            /*IChildrenHierachy?*/ speechVoice = null;
            //--TRIMMABLE-BOUNDARY-END(287764077002)
            
            //--TRIMMABLE-BOUNDARY-START(283469109706)
            /*Gender?*/ speechGender = null;
            //--TRIMMABLE-BOUNDARY-END(283469109706)
            
            //--TRIMMABLE-BOUNDARY-START(279174142410)
            /*int?*/ speechAge = null;
            //--TRIMMABLE-BOUNDARY-END(279174142410)
            
            //--TRIMMABLE-BOUNDARY-START(292059044298)
            /*int*/ speechVolume = 80;
            //--TRIMMABLE-BOUNDARY-END(292059044298)
            
            //--TRIMMABLE-BOUNDARY-START(38655973834)
            /*int*/ bgMusicVolume = 20;
            //--TRIMMABLE-BOUNDARY-END(38655973834)
            
            //--TRIMMABLE-BOUNDARY-START(184684861898)
            /*ValueTask *//*async*/  PayForJingle()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    let $t11, $r11;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684861898);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel*/ let __ca4__;
                    /*object?*/ let __ca5__;
                    /*var*/ let paymentResult = ($t10 = this.Service.Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment(new $.$fPer.LCFCDM.Money().$ctor$3(this.settings.TextToSpeechCost, 1/*MoneyUnitTypes.Naira*/), `${$.$strNN(this.target.Title)} Text to Speech`, $.$strNN(((__ca4__ = this.target) !== null ? ((__ca5__ = __ca4__.Identifier.Id) !== null ? $.$dspc(__ca5__, $.$$.S.Object, ($t) => $t.ToString) : null) : null)) + "/TTS", null, null, "CampaignBot/TTS", null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    this.target.SpeechPaymentReference = paymentResult.Reference;
                    ($t11 = this.SaveTarget(), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(184684861898)
            
            //--TRIMMABLE-BOUNDARY-START(206159698378)
            /*void */ RemoveBgMusic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159698378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.target.SpeechBgMusic = null;
            }
            //--TRIMMABLE-BOUNDARY-END(206159698378)
            
            //--TRIMMABLE-BOUNDARY-START(304943946186)
            /*void */ ToggleBgMusic(/*CampaignBotBackgroundMusic*/ music)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943946186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.target.SpeechBgMusic === music.File)
                {
                    this.target.SpeechBgMusic = null;
                }
                else 
                {
                    this.target.SpeechBgMusic = music.File;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943946186)
            
            //--TRIMMABLE-BOUNDARY-START(219044600266)
            /*ValueTask *//*async*/  SelectBgMusic()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219044600266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t12 = $.$hDPm.LCFCI.ViewPresenterExtensions.View$1($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this,  (/*v*/ v) =>
                    {
                        return this.GetMusics();
                    }, $IFSurg ??= {"r":6881395,"p":[{"n":"v","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1268170,"h":0,"f":17825794}), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Select Background music", false), null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t13 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.ViewFeatures = 5632/*ViewFeatures.Default*/ | 128/*ViewFeatures.Closable*/;
                        $i13.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                        return $i13;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(219044600266)
            
            //--TRIMMABLE-BOUNDARY-START(300648978890)
            /*Task *//*async*/  TextToSpeech()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648978890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.target.SpeechText !== null)
                    {
                        let $t14, $r14;
                        ($t14 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t15, $r15;
                                /*var*/ let tts = ($t15 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$vWqU.LCFCCR.ITextSpeechRemoteService, $.$vWqU.LCFCCR.TextToSpeechResponse, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$vWqU.LCFCCR.ITextSpeechRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$vWqU.LCFCCR.TextToSpeechResponse)))().$ctor(this,  (/*server*/ server) =>
                                {
                                    return server.LCFCCR$ITextSpeechRemoteService$TextToSpeech((() =>
                                    {
                                        //new $.$vWqU.LCFCCR.TextToSpeechRequest()
                                        const $t16 = $.$vWqU.LCFCCR.TextToSpeechRequest;
                                        const $i16 = new $t16();
                                        $i16.$ctor$2();
                                        $i16.Text = this.target.SpeechText;
                                        $i16.VoiceGender = this.speechGender;
                                        $i16.VoiceAge = this.speechAge;
                                        $i16.Voice = (($.$cast(this.speechVoice, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel))?.VoiceCode ?? null);
                                        $i16.VoiceVolume = this.speechVolume;
                                        $i16.BackgroundMusic = this.target.SpeechBgMusic;
                                        $i16.BackgroundMusicVolume = this.bgMusicVolume;
                                        return $i16;
                                    })());
                                }, $HZNdgh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$vWqU.LCFCCR.TextToSpeechResponse)).$h,"p":[{"n":"server","p":8740264}],"n":"","d":1268170,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                                this.target.MediaPeriod = $.$cast(((tts.Duration?.Add($.$$.S.TimeSpan.FromSeconds$2(2n)).TotalSeconds ?? null)), $.$$.S.Nullable$$($.$$.S.Int32));
                                this.target.SpeechBinary = tts.Data;
                            });
                        }, $onUcre ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                        {
                            return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                        }, $sgCdve ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(300648978890)
            
            //--TRIMMABLE-BOUNDARY-START(55835843018)
            /*ValueTask */ FileSelected(/*IEnumerable<PickedFileInfo>*/ files)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835843018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        /*List<CommunityCampaignBotContactModel>*/ let contactss = new ($.$$.SCG.List$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor$1();
                        let $en17 = files.SCG$IEnumerable$$$GetEnumerator();
                        while ($en17.SC$1$IEnumerator$MoveNext())
                        {
                            let file = $en17.SCG$IEnumerator$$$Current;
                            {
                                let f = null;
                                try
                                {
                                    let $t18, $r18;
                                    let $t19, $r19;
                                    f = ($t18 = file.ReadAsync(), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                                    /*var*/ let mem = new $.$$.SI.MemoryStream().$ctor$3();
                                    ($t19 = f.LCFCC$IFileStreamProvider$Stream.CopyToAsync$3(mem), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                                    mem.Position = 0n;
                                    /*var*/ let reader = new $.$$.SI.StreamReader().$ctor$9(mem);
                                    /*var*/ let csv = $.$fPer.LCFCD.CSVExtension.ParseCSV(reader, true);
                                    const $t20 = () => csv.Header;
                                    /*int*/ let numberColumn = $.$ifnn($t20, ($t) => $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $t, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*h*/ h, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(h, i);
                                    }, $sfKlAd ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"h","p":1310721},{"n":"i","p":655361}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return $.$$.S.String.Contains$2.call(v.Item1, "number", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                                    }, $FgnLmi ??= {"r":262145,"p":[{"n":"v","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1268170,"h":0,"f":17825794})).Item2) ?? 0;
                                    const $t21 = () => csv.Header;
                                    /*int*/ let dobColumn = $.$ifnn($t21, ($t) => $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $t, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*h*/ h, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(h, i);
                                    }, $nXCZli ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"h","p":1310721},{"n":"i","p":655361}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return $.$$.S.String.Contains$2.call(v.Item1, "dob", 3/*StringComparison.InvariantCultureIgnoreCase*/) || $.$$.S.String.Contains$2.call(v.Item1, "date", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                                    }, $nHnWtg ??= {"r":262145,"p":[{"n":"v","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1268170,"h":0,"f":17825794})).Item2) ?? -1;
                                    const $t22 = () => csv.Header;
                                    /*int*/ let localeColumn = $.$ifnn($t22, ($t) => $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $t, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*h*/ h, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(h, i);
                                    }, $pzORab ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"h","p":1310721},{"n":"i","p":655361}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return $.$$.S.String.Contains$2.call(v.Item1, "location", 3/*StringComparison.InvariantCultureIgnoreCase*/) || $.$$.S.String.Contains$2.call(v.Item1, "lga", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                                    }, $UTJoGf ??= {"r":262145,"p":[{"n":"v","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1268170,"h":0,"f":17825794})).Item2) ?? -1;
                                    const $t23 = () => csv.Header;
                                    /*int*/ let genderColumn = $.$ifnn($t23, ($t) => $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $t, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*h*/ h, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(h, i);
                                    }, $XSRBOj ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"h","p":1310721},{"n":"i","p":655361}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return $.$$.S.String.Contains$2.call(v.Item1, "gender", 3/*StringComparison.InvariantCultureIgnoreCase*/);
                                    }, $jsikfe ??= {"r":262145,"p":[{"n":"v","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1268170,"h":0,"f":17825794})).Item2) ?? -1;
                                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca6__;
                                    if ($.$$.S.Int32.op_GreaterThan(((__ca6__ = csv.Header) !== null ? $.$sl.SL.Enumerable.Count$1($.$$.S.String, __ca6__) : null), 1) && numberColumn < 0)
                                    {
                                        let $t24, $r24;
                                        numberColumn = (($t24 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select$2($.$hDPm.LCFCI.ViewConfiguration, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, "Select Number Column", "Please select a column that correspond to phone numbers", new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                                        {
                                            return s.Item1;
                                        }, $oKFosc ??= {"r":1310721,"p":[{"n":"s","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1268170,"h":0,"f":17825794}), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), csv.Header, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*h*/ h, /*i*/ i) =>
                                        {
                                            return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(h, i);
                                        }, $Wqcjnc ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"h","p":1310721},{"n":"i","p":655361}],"n":"","d":1268170,"h":0,"f":17825794})), null), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)))).Item2;
                                    }
                                    contactss.AddRange($.$sl.SL.Enumerable.Where($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, csv.Data, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor(this,  (/*d*/ d) =>
                                    {
                                        /*var*/ let number = $.$fPer.LCFCD.PhoneNumber.Normalize(d.Value.get_Item(numberColumn), false);
                                        /*var*/ let dob = dobColumn >= 0 ? d.Value.get_Item(dobColumn) : null;
                                        /*var*/ let locale = localeColumn >= 0 ? d.Value.get_Item(localeColumn) : null;
                                        /*var*/ let gender = genderColumn >= 0 ? d.Value.get_Item(genderColumn) : null;
                                        /*int?*/ let age = null;
                                        try
                                        {
                                            age = $.$cast(($.$$.S.DateTime.UtcNow.Subtract$1($.$$.S.DateTime.Parse$4(dob)).TotalDays / 365), $.$$.S.Int32);
                                        }
                                        catch($e)
                                        {
                                        }
                                        return (() =>
                                        {
                                            //new $.$bTOs.LCCCCM.CommunityCampaignBotContactModel()
                                            const $t25 = $.$bTOs.LCCCCM.CommunityCampaignBotContactModel;
                                            const $i25 = new $t25();
                                            $i25.$ctor$1();
                                            $i25.Number = number;
                                            $i25.Age = age;
                                            $i25.Gender = gender !== null ? $.$$.S.Enum.Parse$7($.$fPer.LCFCD.Gender, gender) : null;
                                            return $i25;
                                        })();
                                    }, $TMxuMg ??= {"r":552963,"p":[{"n":"d","p":$.$$.SCG.KeyValuePair$$$($.$$.S.Int32, $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.String)).$h}],"n":"","d":1268170,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                                    {
                                        return !$.$$.S.String.IsNullOrEmpty(s.Number);
                                    }, $VeLYAe ??= {"r":262145,"p":[{"n":"s","p":552963}],"n":"","d":1268170,"h":0,"f":17825794})));
                                }
                                finally
                                {
                                    f?.S$IDisposable$Dispose();
                                }
                            }
                        }
                        this.target.Contacts = $.$sl.SL.Enumerable.Distinct$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, contactss);
                    });
                }, $ktPqAa ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $lDzINh ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(55835843018)
            
            //--TRIMMABLE-BOUNDARY-START(214749632970)
            /*ValueTask */ SaveTarget()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749632970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        if (this.target.Identifier.HasValue)
                        {
                            let $t26, $r26;
                            ($t26 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ this.target ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                        }
                        else 
                        {
                            let $t27, $r27;
                            /*var*/ let t = $.$sl.SL.Enumerable.First$1($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, (($t27 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), [ this.target ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)))).AsEnumerable());
                            this.target.Identifier = t.Identifier;
                        }
                    });
                }, $HlQfPd ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $cxDyAj ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(214749632970)
            
            //--TRIMMABLE-BOUNDARY-START(210454665674)
            /*ValueTask *//*async*/  SaveDraft()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t28, $r28;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210454665674);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.target.State = 0/*CommunityCampaignBotState.Draft*/;
                    ($t28 = this.SaveTarget(), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                    this.NotifySuccess(null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210454665674)
            
            //--TRIMMABLE-BOUNDARY-START(309238913482)
            /*ValueTask */ Topup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238913482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t29, $r29;
                        let $t30, $r30;
                        ($t29 = this.SaveTarget(), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                        ($t30 = this.Service.Topup(this.target), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                    });
                }, $eukOoa ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $BnBrXd ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(309238913482)
            
            //--TRIMMABLE-BOUNDARY-START(64425777610)
            /*ValueTask */ FundCampaign()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425777610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t31, $r31;
                        let $t32, $r32;
                        let $t33, $r33;
                        ($t31 = this.SaveTarget(), ($.$$.N.AsyncResolver.IsCompleted($t31, { set $v($v) { $r31 = $v; } }) ? $r31 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t31)));
                        /*var*/ let transaction = ($t32 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.UserWalletTransactionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)))().$ctor(this,  (/*service*/ service) =>
                        {
                            return service.LCFCW$IWalletRemoteService$DeductCoins($.$OJJQ.LCFCW.WalletIssuerExtension.GetCoinId(this.Service.CoinProvider, $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.Service.CoinProvider.CoinDescriptors)), new $.$fPer.LCFCD.DataId().$ctor$2(), this.wallet, $.$strNN($.$dspc(this.target.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)) + "/" + this.wallet, new $.$fPer.LCFCD.DataId().$ctor$2(), "Fund CampaignBot", null, false, 1, 0, null);
                        }, $gfWlLf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,"p":[{"n":"service","p":1029325}],"n":"","d":1268170,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32)));
                        ($t33 = this.Service.Wallet.Reload(), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33)));
                        this.target.Wallet += this.wallet;
                    });
                }, $ojJagd ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $XaTNPk ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64425777610)
            
            //--TRIMMABLE-BOUNDARY-START(193274796490)
            /*ValueTask */ Publish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274796490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t34, $r34;
                        if (this.target.State < 3/*CommunityCampaignBotState.Running*/)
                        {
                            this.target.State = 1/*CommunityCampaignBotState.Published*/;
                        }
                        ($t34 = this.SaveTarget(), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                        this.NotifySuccess(null, null);
                    });
                }, $nOTyhg ??= {"r":181338113,"n":"","d":1268170,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                {
                    return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                }, $sZLwJj ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1268170,"h":0,"f":17825794}), null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(193274796490)
            
            //--TRIMMABLE-BOUNDARY-START(158915058122)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915058122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(158915058122)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21476104650)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476104650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476104650)
            
            //--TRIMMABLE-BOUNDARY-START(21476104650)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(21476104650)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(150325123530)
                this.Http = null;
                //--TRIMMABLE-BOUNDARY-END(150325123530)
                
                //--TRIMMABLE-BOUNDARY-START(223339567562)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(223339567562)
                
                //--TRIMMABLE-BOUNDARY-START(167504992714)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(167504992714)
                
                //--TRIMMABLE-BOUNDARY-START(296354011594)
                this.target = null;
                //--TRIMMABLE-BOUNDARY-END(296354011594)
                
            }
            static $h = 1268170;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(180389894602),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965385162,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1268170,
      "h": 180389894602,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389894602),
//--TRIMMABLE-BOUNDARY-START(150325123530),
    {
      "p": 6488117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195581386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519436746,
        "f": 83886081
      },
      "n": "Http",
      "d": 1268170,
      "h": 150325123530,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150325123530),
//--TRIMMABLE-BOUNDARY-START(223339567562),
    {
      "p": 1071562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555319754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289240522,
        "f": 83886081
      },
      "n": "Service",
      "d": 1268170,
      "h": 223339567562,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223339567562),
//--TRIMMABLE-BOUNDARY-START(167504992714),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375450570,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699305930,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1268170,
      "h": 167504992714,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504992714),
//--TRIMMABLE-BOUNDARY-START(163210025418),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785515978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109371338,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1268170,
      "h": 163210025418,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163210025418),
//--TRIMMABLE-BOUNDARY-START(47245908426),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015712202,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929502154,
        "f": 83886082
      },
      "n": "Contacts",
      "d": 1268170,
      "h": 47245908426,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245908426),
//--TRIMMABLE-BOUNDARY-START(274879175114),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145254346,
        "f": 50331650
      },
      "n": "SetupAmounts",
      "d": 1268170,
      "h": 274879175114,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(274879175114),
//--TRIMMABLE-BOUNDARY-START(313533880778),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735188938,
        "f": 50331650
      },
      "n": "TotalEngatementTime",
      "d": 1268170,
      "h": 313533880778,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(313533880778),
//--TRIMMABLE-BOUNDARY-START(51540875722),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605646794,
        "f": 50331650
      },
      "n": "EngagementAmounts",
      "d": 1268170,
      "h": 51540875722,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51540875722)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(154620090826),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1268170,
      "h": 154620090826,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620090826),
//--TRIMMABLE-BOUNDARY-START(42950941130),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1268170,
      "h": 42950941130,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950941130),
//--TRIMMABLE-BOUNDARY-START(146030156234),
    {
      "r": 6881395,
      "n": "GetMusics",
      "d": 1268170,
      "h": 146030156234,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146030156234),
//--TRIMMABLE-BOUNDARY-START(60130810314),
    {
      "r": 262145,
      "p": [
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "FormFilter",
      "d": 1268170,
      "h": 60130810314,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130810314),
//--TRIMMABLE-BOUNDARY-START(171799960010),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1268170,
      "h": 171799960010,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(171799960010),
//--TRIMMABLE-BOUNDARY-START(176094927306),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1268170,
      "h": 176094927306,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(176094927306),
//--TRIMMABLE-BOUNDARY-START(34361006538),
    {
      "r": 178454529,
      "n": "AudioSelected",
      "d": 1268170,
      "h": 34361006538,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34361006538),
//--TRIMMABLE-BOUNDARY-START(184684861898),
    {
      "r": 181338113,
      "n": "PayForJingle",
      "d": 1268170,
      "h": 184684861898,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(184684861898),
//--TRIMMABLE-BOUNDARY-START(206159698378),
    {
      "r": 65537,
      "n": "RemoveBgMusic",
      "d": 1268170,
      "h": 206159698378,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159698378),
//--TRIMMABLE-BOUNDARY-START(304943946186),
    {
      "r": 65537,
      "p": [
        {
          "n": "music",
          "p": 4354051
        }
      ],
      "n": "ToggleBgMusic",
      "d": 1268170,
      "h": 304943946186,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304943946186),
//--TRIMMABLE-BOUNDARY-START(219044600266),
    {
      "r": 181338113,
      "n": "SelectBgMusic",
      "d": 1268170,
      "h": 219044600266,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(219044600266),
//--TRIMMABLE-BOUNDARY-START(300648978890),
    {
      "r": 178454529,
      "n": "TextToSpeech",
      "d": 1268170,
      "h": 300648978890,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(300648978890),
//--TRIMMABLE-BOUNDARY-START(55835843018),
    {
      "r": 181338113,
      "p": [
        {
          "n": "files",
          "p": $.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo).$h
        }
      ],
      "n": "FileSelected",
      "d": 1268170,
      "h": 55835843018,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835843018),
//--TRIMMABLE-BOUNDARY-START(214749632970),
    {
      "r": 181338113,
      "n": "SaveTarget",
      "d": 1268170,
      "h": 214749632970,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214749632970),
//--TRIMMABLE-BOUNDARY-START(210454665674),
    {
      "r": 181338113,
      "n": "SaveDraft",
      "d": 1268170,
      "h": 210454665674,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(210454665674),
//--TRIMMABLE-BOUNDARY-START(309238913482),
    {
      "r": 181338113,
      "n": "Topup",
      "d": 1268170,
      "h": 309238913482,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(309238913482),
//--TRIMMABLE-BOUNDARY-START(64425777610),
    {
      "r": 181338113,
      "n": "FundCampaign",
      "d": 1268170,
      "h": 64425777610,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425777610),
//--TRIMMABLE-BOUNDARY-START(193274796490),
    {
      "r": 181338113,
      "n": "Publish",
      "d": 1268170,
      "h": 193274796490,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274796490),
//--TRIMMABLE-BOUNDARY-START(158915058122),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1268170,
      "h": 158915058122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915058122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(317828848074),
    {
      "t": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel).$h,
      "n": "voices",
      "d": 1268170,
      "h": 317828848074,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(317828848074),
//--TRIMMABLE-BOUNDARY-START(270584207818),
    {
      "t": 4419587,
      "n": "settings",
      "d": 1268170,
      "h": 270584207818,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(270584207818),
//--TRIMMABLE-BOUNDARY-START(296354011594),
    {
      "t": 1863683,
      "n": "target",
      "d": 1268170,
      "h": 296354011594,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(296354011594),
//--TRIMMABLE-BOUNDARY-START(322123815370),
    {
      "t": 655361,
      "n": "wallet",
      "d": 1268170,
      "h": 322123815370,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(322123815370),
//--TRIMMABLE-BOUNDARY-START(287764077002),
    {
      "t": 15960406,
      "n": "speechVoice",
      "d": 1268170,
      "h": 287764077002,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(287764077002),
//--TRIMMABLE-BOUNDARY-START(283469109706),
    {
      "t": $.$typeNullable($.$fPer.LCFCD.Gender).$h,
      "n": "speechGender",
      "d": 1268170,
      "h": 283469109706,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(283469109706),
//--TRIMMABLE-BOUNDARY-START(279174142410),
    {
      "t": $.$typeNullable($.$$.S.Int32).$h,
      "n": "speechAge",
      "d": 1268170,
      "h": 279174142410,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(279174142410),
//--TRIMMABLE-BOUNDARY-START(292059044298),
    {
      "t": 655361,
      "n": "speechVolume",
      "d": 1268170,
      "h": 292059044298,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(292059044298),
//--TRIMMABLE-BOUNDARY-START(38655973834),
    {
      "t": 655361,
      "n": "bgMusicVolume",
      "d": 1268170,
      "h": 38655973834,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655973834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476104650),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1268170,
      "h": 21476104650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476104650)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(188979829194),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1268170,
        "h": 30066039242,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1268170,
        "h": 201864731082,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 1268170,
      "h": 188979829194,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(188979829194)
  ],
  "h": 1268170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Shared.CommunityCampaignEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Shared${separator}CommunityCampaignEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1268170)
        
        

        //--TRIMMABLE-BOUNDARY-START(1006026)
        $asm.$cls(`$tUzp.LCCCCS.CommunityCampaignBotApplication`, ($self) => class CommunityCampaignBotApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(184684599754)
            /*int*/ static NewUserFreeMinutes = 5;
            //--TRIMMABLE-BOUNDARY-END(184684599754)
            
            //--TRIMMABLE-BOUNDARY-START(12885907914)
            $ctor$5(/*CommunityCampaignBotService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885907914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885907914)
            
            //--TRIMMABLE-BOUNDARY-START(180389632458)
            /*string */ get Name()
            {
                return "CampaignBot";
            }
            //--TRIMMABLE-BOUNDARY-END(180389632458)
            
            //--TRIMMABLE-BOUNDARY-START(227634272714)
            /*string */ get Title()
            {
                return "Campaign Bot";
            }
            //--TRIMMABLE-BOUNDARY-END(227634272714)
            
            //--TRIMMABLE-BOUNDARY-START(21475842506)
            /*string */ get Description()
            {
                return "Bring your product or service campaign to the grassroot with one to one CampaignBot";
            }
            //--TRIMMABLE-BOUNDARY-END(21475842506)
            
            //--TRIMMABLE-BOUNDARY-START(176094665162)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-call-split"/*MaterialDesignIconNames.CallSplit*/);
            }
            //--TRIMMABLE-BOUNDARY-END(176094665162)
            
            //--TRIMMABLE-BOUNDARY-START(223339305418)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(223339305418)
            
            //--TRIMMABLE-BOUNDARY-START(30065777098)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065777098)
            
            //--TRIMMABLE-BOUNDARY-START(17180875210)
            /*Type? */ get ApplicationViewType()
            {
                return $.$tUzp.LCCCCP.CommunityCampaignBotApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180875210)
            
            //--TRIMMABLE-BOUNDARY-START(171799697866)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799697866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$tUzp.LCCCCP.CommunityCampaignBotApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(171799697866)
            
            //--TRIMMABLE-BOUNDARY-START(25770809802)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770809802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770809802)
            
            //--TRIMMABLE-BOUNDARY-START(214749370826)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749370826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(214749370826)
            
            //--TRIMMABLE-BOUNDARY-START(210454403530)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(210454403530)
            
            //--TRIMMABLE-BOUNDARY-START(4295973322)
            /*CommunityCampaignBotService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295973322)
            
            //--TRIMMABLE-BOUNDARY-START(219044338122)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(219044338122)
            
            //--TRIMMABLE-BOUNDARY-START(231929240010)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(8448/*PostTypes.CampaignBot*/, 8451/*PostTypes.CampaignBotEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(231929240010)
            
            //--TRIMMABLE-BOUNDARY-START(201864468938)
            /*string? */ get OpenGraphTitle()
            {
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(201864468938)
            
            //--TRIMMABLE-BOUNDARY-START(188979567050)
            /*string? */ get OpenGraphDescription()
            {
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(188979567050)
            
            //--TRIMMABLE-BOUNDARY-START(197569501642)
            /*string? */ get OpenGraphPath()
            {
                return "CampaignBot";
            }
            //--TRIMMABLE-BOUNDARY-END(197569501642)
            
            //--TRIMMABLE-BOUNDARY-START(193274534346)
            /*string? */ get OpenGraphImage()
            {
                return "img/icon.png";
            }
            //--TRIMMABLE-BOUNDARY-END(193274534346)
            
            //--TRIMMABLE-BOUNDARY-START(206159436234)
            /*OpenGraphType */ get OpenGraphType()
            {
                return 2/*OpenGraphType.Website*/;
            }
            //--TRIMMABLE-BOUNDARY-END(206159436234)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            //--TRIMMABLE-BOUNDARY-START(34379958614)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphTitle.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60149762390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphTitle;
            }
            //--TRIMMABLE-BOUNDARY-END(34379958614)
            
            //--TRIMMABLE-BOUNDARY-START(8610154838)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphDescription.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47264860502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(8610154838)
            
            //--TRIMMABLE-BOUNDARY-START(25790024022)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphPath.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55854795094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphPath;
            }
            //--TRIMMABLE-BOUNDARY-END(25790024022)
            
            //--TRIMMABLE-BOUNDARY-START(17200089430)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphImage.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51559827798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphImage;
            }
            //--TRIMMABLE-BOUNDARY-END(17200089430)
            
            //--TRIMMABLE-BOUNDARY-START(42969893206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphType.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64444729686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphType;
            }
            //--TRIMMABLE-BOUNDARY-END(42969893206)
            
            static $h = 1006026;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(180389632458),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605384650,
        "f": 50364417
      },
      "n": "Name",
      "d": 1006026,
      "h": 180389632458,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389632458),
//--TRIMMABLE-BOUNDARY-START(227634272714),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914795978,
        "f": 50364417
      },
      "n": "Title",
      "d": 1006026,
      "h": 227634272714,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(227634272714),
//--TRIMMABLE-BOUNDARY-START(21475842506),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835580874,
        "f": 50364417
      },
      "n": "Description",
      "d": 1006026,
      "h": 21475842506,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475842506),
//--TRIMMABLE-BOUNDARY-START(176094665162),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015450058,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1006026,
      "h": 176094665162,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094665162),
//--TRIMMABLE-BOUNDARY-START(223339305418),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324861386,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1006026,
      "h": 223339305418,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223339305418),
//--TRIMMABLE-BOUNDARY-START(30065777098),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425515466,
        "f": 50364417
      },
      "n": "Features",
      "d": 1006026,
      "h": 30065777098,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065777098),
//--TRIMMABLE-BOUNDARY-START(17180875210),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245646282,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 1006026,
      "h": 17180875210,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180875210),
//--TRIMMABLE-BOUNDARY-START(210454403530),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144992202,
        "f": 50364417
      },
      "n": "Order",
      "d": 1006026,
      "h": 210454403530,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210454403530),
//--TRIMMABLE-BOUNDARY-START(4295973322),
    {
      "p": 1071562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655711690,
        "f": 50331650
      },
      "n": "_Service",
      "d": 1006026,
      "h": 4295973322,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295973322),
//--TRIMMABLE-BOUNDARY-START(219044338122),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734926794,
        "f": 50364417
      },
      "n": "Service",
      "d": 1006026,
      "h": 219044338122,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(219044338122),
//--TRIMMABLE-BOUNDARY-START(231929240010),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504730570,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 1006026,
      "h": 231929240010,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231929240010),
//--TRIMMABLE-BOUNDARY-START(201864468938),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965123018,
        "f": 50331649
      },
      "n": "OpenGraphTitle",
      "d": 1006026,
      "h": 201864468938,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864468938),
//--TRIMMABLE-BOUNDARY-START(188979567050),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195319242,
        "f": 50331649
      },
      "n": "OpenGraphDescription",
      "d": 1006026,
      "h": 188979567050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979567050),
//--TRIMMABLE-BOUNDARY-START(197569501642),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375188426,
        "f": 50331649
      },
      "n": "OpenGraphPath",
      "d": 1006026,
      "h": 197569501642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569501642),
//--TRIMMABLE-BOUNDARY-START(193274534346),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785253834,
        "f": 50331649
      },
      "n": "OpenGraphImage",
      "d": 1006026,
      "h": 193274534346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274534346),
//--TRIMMABLE-BOUNDARY-START(206159436234),
    {
      "p": 30902614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555057610,
        "f": 50331649
      },
      "n": "OpenGraphType",
      "d": 1006026,
      "h": 206159436234,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159436234)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171799697866),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 1006026,
      "h": 171799697866,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(171799697866),
//--TRIMMABLE-BOUNDARY-START(25770809802),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 1006026,
      "h": 25770809802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770809802),
//--TRIMMABLE-BOUNDARY-START(214749370826),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 1006026,
      "h": 214749370826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749370826)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(184684599754),
    {
      "t": 655361,
      "n": "NewUserFreeMinutes",
      "d": 1006026,
      "h": 184684599754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684599754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885907914),
    {
      "p": [
        {
          "n": "service",
          "p": 1071562
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1006026,
      "h": 12885907914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885907914)
  ],
  "h": 1006026
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication, $.$fPer.LCFCD.IOpenGraphDataProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Services.CommunityCampaignBotApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Services${separator}CommunityCampaignBotApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1006026)
        
        

        //--TRIMMABLE-BOUNDARY-START(1071562)
        $asm.$cls(`$tUzp.LCCCCS.CommunityCampaignBotService`, ($self) => class CommunityCampaignBotService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180940746)
            $ctor$6(/*IUIPaymentProcessorProvider*/ payment, /*CommunityCampaignBotWalletProvider*/ coinProvider, /*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180940746);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Payment = payment;
                    this.CoinProvider = coinProvider;
                    this.Wallet = new $.$SeJP.LCWCS.WalletService().$ctor$5(service.UnitOfWork, $.$$.SRC.RuntimeHelpers.CreateArray($.$bTOs.LCCCCS.CommunityCampaignBotWalletProvider.$type, [ coinProvider ], null, null));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180940746)
            
            //--TRIMMABLE-BOUNDARY-START(55835646410)
            /*IUIPaymentProcessorProvider*/ Payment = null;
            //--TRIMMABLE-BOUNDARY-END(55835646410)
            
            //--TRIMMABLE-BOUNDARY-START(64425581002)
            /*WalletService*/ Wallet = null;
            //--TRIMMABLE-BOUNDARY-END(64425581002)
            
            //--TRIMMABLE-BOUNDARY-START(21475908042)
            /*CommunityCampaignBotWalletProvider*/ CoinProvider = null;
            //--TRIMMABLE-BOUNDARY-END(21475908042)
            
            //--TRIMMABLE-BOUNDARY-START(60130613706)
            /*ValueTask */ Topup(/*CommunityCampaignBotPostModel?*/ $from)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130613706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        /*var*/ let amount = ($t1 = this.Wallet.FundAsync(this.Wallet.System, this.CoinProvider, $.$sl.SL.Enumerable.Single$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.CoinProvider.CoinDescriptors)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    });
                }, $DzESfd ??= {"r":181338113,"n":"","d":1071562,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(60130613706)
            
            //--TRIMMABLE-BOUNDARY-START(51540679114)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540679114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load$1(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        ($t2 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        ($t3 = this.Wallet.Load(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    });
                }, $GSYhUa ??= {"r":181338113,"n":"","d":1071562,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(51540679114)
            
            static $h = 1071562;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835646410),
    {
      "p": 65689258,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655777226,
        "f": 50331649
      },
      "n": "Payment",
      "d": 1071562,
      "h": 55835646410,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835646410),
//--TRIMMABLE-BOUNDARY-START(64425581002),
    {
      "p": 1558279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245711818,
        "f": 50331649
      },
      "n": "Wallet",
      "d": 1071562,
      "h": 64425581002,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425581002),
//--TRIMMABLE-BOUNDARY-START(21475908042),
    {
      "p": 4026371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065842634,
        "f": 50331649
      },
      "n": "CoinProvider",
      "d": 1071562,
      "h": 21475908042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475908042)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130613706),
    {
      "r": 181338113,
      "p": [
        {
          "n": "from",
          "p": 1863683
        }
      ],
      "n": "Topup",
      "d": 1071562,
      "h": 60130613706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130613706),
//--TRIMMABLE-BOUNDARY-START(51540679114),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1071562,
      "h": 51540679114,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540679114)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180940746),
    {
      "p": [
        {
          "n": "payment",
          "p": 65689258
        },
        {
          "n": "coinProvider",
          "p": 4026371
        },
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1071562,
      "h": 17180940746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180940746)
  ],
  "h": 1071562
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Client.Services.CommunityCampaignBotService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Client${separator}Services${separator}CommunityCampaignBotService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1071562)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.CampaignBot.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(22986)
