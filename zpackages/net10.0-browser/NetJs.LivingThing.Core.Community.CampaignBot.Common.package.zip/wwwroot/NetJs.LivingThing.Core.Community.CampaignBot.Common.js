
//--TRIMMABLE-BOUNDARY-START(28675)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $PuoaCd;
    let $VTBXcd;
    let $hSiJqd;
    let $RUHRed;
    let $XsTjze;
    let $QJYLDd;
    let $RGILRj;
    let $scSFGg;
    let $WxeRob;
    let $SAwbwb;
    let $sWhwCi;
    let $VUIIxb;
    let $LFEpTd;
    let $KxLhwe;
    let $aSPykj;
    let $LNYSQg;
    let $WyiZta;
    let $ykbVee;
    let $iWAQDh;
    let $RgLpSg;
    let $EObcYi;
    let $jbLOsf;
    let $FSTtqc;
    let $OXHvmd;
    let $HSmesi;
    let $UNWAwd;
    let $WPzdLh;
    let $Cikvdh;
    let $ZnlSZd;
    let $fweFNd;
    let $Vxmdjl;
    let $VevJvc;
    let $GtZKAe;
    let $hZuRPi;
    let $sqNjsa;
    let $jhXxjk;
    let $tfCdla;
    let $iAiage;
    let $NIrOfk;
    let $ysnJNd;
    let $ilzkkl;
    let $ERlAff;
    let $dyJjbh;
    let $TXvuci;
    let $eCPEkc;
    let $BvkQfg;
    let $sBiRhi;
    let $RCDKkj;
    let $WQmOne;
    let $yAbyai;
    let $WRnVRj;
    let $nTmBka;
    let $Okcuqf;
    let $QesZsi;
    let $nBwAAf;
    let $QhZUyb;
    let $fonzWb;
    let $PlKVAh;
    let $XXzsxd;
    let $KoHUId;
    let $DVsrtf;
    let $gGofZg;
    let $drBRXf;
    let $ImOpBb;
    let $gbMIQd;
    let $ylthPa;
    let $qguGij;
    let $LOHCfc;
    let $QEMCdh;
    let $MZLYWj;
    let $EHPiMg;
    let $vucxUf;
    let $whrhXe;
    let $gnIvcf;
    let $DFBBZb;
    let $vvBnta;
    let $wvxlZb;
    let $nkHsYd;
    let $fbltEc;
    let $QYjDDg;
    let $CLNlDe;
    let $yveagf;
    let $ohPybg;
    let $Kuaftj;
    let $EtPndb;
    let $QzPCTh;
    let $BNpIQk;
    let $xmuRfa;
    let $EDHqqi;
    let $UHhYsf;
    let $VjNyPi;
    let $rTjDEj;
    let $UivdJe;
    let $aDwQjl;
    let $naujqc;
    let $OpZbof;
    let $JUwYPc;
    let $cKwDSa;
    let $pBEnyc;
    let $eCWYkh;
    let $uPRCYd;
    let $FMajDh;
    let $RXXkGi;
    let $fjtedg;
    let $sGMPyk;
    let $qFvyDh;
    let $RUfGcc;
    let $XUehZb;
    let $duPUNd;
    let $MfbLCa;
    let $NPlork;
    let $kGdJPi;
    let $ibHrAd;
    let $agJVoj;
    let $makgLe;
    let $bvgYVe;
    let $kzCCpb;
    let $XjFQha;
    let $bDFDdf;
    let $qLwFMi;
    let $URicTb;
    let $WLDIue;
    let $xXimgb;
    let $olpfYk;
    let $zbHiph;
    let $vrVzza;
    let $KsVfIk;
    let $pSGpXd;
    let $FNhAak;
    let $krggzk;
    let $xGeACk;
    let $rwkGTg;
    let $YgkfHd;
    let $niUGok;
    let $DIorHg;
    let $vCwpDg;
    let $ejueyj;
    let $mKwSrb;
    let $qHuTFf;
    let $wKnHQg;
    let $YDuuyb;
    let $nRNpyd;
    let $dINcue;
    let $ZWCBfa;
    let $RuiEPk;
    let $FubZZd;
    let $ZDXUxc;
    let $VGQtud;
    let $gZySla;
    let $jpXXqe;
    let $OQsGVb;
    let $YHTFDg;
    let $admmYf;
    let $OPjzVh;
    let $FkNSJb;
    let $NnUeEa;
    let $jTVzAd;
    let $ljiyef;
    let $NtlQUd;
    let $ILDmWg;
    let $QJlfqa;
    let $VUTCkl;
    let $JWqsIf;
    let $eHjKUc;
    let $ohBqtg;
    let $GdQTWj;
    let $IyGOna;
    let $WURbRc;
    let $GJcrhb;
    let $uHiFei;
    let $AVorJh;
    let $VUZUSg;
    let $OXORoa;
    let $jSEWjl;
    let $ZKfiqc;
    let $ajZBzh;
    let $jqxmni;
    let $oLWsJg;
    let $tqmRBa;
    let $wAACmc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.CampaignBot.Common", 
    {
  "h": 28675,
  "f": "LivingThing.Core.Community.CampaignBot.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.CampaignBot.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.CampaignBot.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(4222979)
        $asm.$cls(`$bTOs.LCCCCS.IComunityCampaignBotRemoteService`, ($self) => class IComunityCampaignBotRemoteService
        {
            static $h = 4222979;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299190275),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).$h,
      "n": "GetGlobalSettings",
      "o": "LCCCCS$IComunityCampaignBotRemoteService$GetGlobalSettings",
      "d": 4222979,
      "h": 4299190275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4299190275)
  ],
  "h": 4222979,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Services.IComunityCampaignBotRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Services${separator}IComunityCampaignBotRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4222979)
        
        

        //--TRIMMABLE-BOUNDARY-START(1142787)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactsModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotContactsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296110083)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296110083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296110083)
            
            static $h = 1142787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296110083),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1142787,
      "h": 4296110083,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296110083)
  ],
  "h": 1142787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1142787)
        
        

        //--TRIMMABLE-BOUNDARY-START(2781187)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotUserPreferenceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297748483)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297748483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yleQ.LCFCA.ApplicationBaseUserPreferenceCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297748483)
            
            static $h = 2781187;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297748483),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2781187,
      "h": 4297748483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297748483)
  ],
  "h": 2781187
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotUserPreferenceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2781187)
        
        

        //--TRIMMABLE-BOUNDARY-START(1404931)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotDeviceStateModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296372227)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296372227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296372227)
            
            static $h = 1404931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296372227),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1404931,
      "h": 4296372227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296372227)
  ],
  "h": 1404931
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotDeviceStateModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1404931)
        
        

        //--TRIMMABLE-BOUNDARY-START(4485123)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsCustomAttributesProvider`, ($self) => class CommunityCampaignBotGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299452419)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299452419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299452419)
            
            static $h = 4485123;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299452419),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4485123,
      "h": 4299452419,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299452419)
  ],
  "h": 4485123
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4485123)
        
        

        //--TRIMMABLE-BOUNDARY-START(3108867)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298076163)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298076163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298076163)
            
            static $h = 3108867;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298076163),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3108867,
      "h": 4298076163,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298076163)
  ],
  "h": 3108867
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3108867)
        
        

        //--TRIMMABLE-BOUNDARY-START(356355)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotCategoryModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295323651)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295323651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295323651)
            
            static $h = 356355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295323651),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 356355,
      "h": 4295323651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295323651)
  ],
  "h": 356355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(356355)
        
        

        //--TRIMMABLE-BOUNDARY-START(3371011)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotVoiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298338307)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298338307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298338307)
            
            static $h = 3371011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298338307),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3371011,
      "h": 4298338307,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298338307)
  ],
  "h": 3371011
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3371011)
        
        

        //--TRIMMABLE-BOUNDARY-START(2977795)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleJsonFile`, ($self) => class CommunityCampaignBotVoiceLocaleJsonFile extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067748867)
            /*IEnumerable<CommunityCampaignBotVoiceLocaleModel>*/ Voices = null;
            //--TRIMMABLE-BOUNDARY-END(30067748867)
            
            //--TRIMMABLE-BOUNDARY-START(8592912387)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592912387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592912387)
            
            //--TRIMMABLE-BOUNDARY-START(8592912387)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592912387)
            
            static $h = 2977795;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067748867),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182846979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25772781571,
        "f": 83886081
      },
      "n": "Voices",
      "d": 2977795,
      "h": 30067748867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067748867)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592912387),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2977795,
      "h": 8592912387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592912387)
  ],
  "h": 2977795
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleJsonFile`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceLocaleJsonFile`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2977795)
        
        

        //--TRIMMABLE-BOUNDARY-START(1667075)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296634371)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296634371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296634371)
            
            static $h = 1667075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296634371),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1667075,
      "h": 4296634371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296634371)
  ],
  "h": 1667075
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1667075)
        
        

        //--TRIMMABLE-BOUNDARY-START(2650115)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotTypeCustomAttributesProvider`, ($self) => class CommunityCampaignBotTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297617411)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297617411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297617411)
            
            static $h = 2650115;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297617411),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2650115,
      "h": 4297617411,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297617411)
  ],
  "h": 2650115
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2650115)
        
        

        //--TRIMMABLE-BOUNDARY-START(3633155)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerStateCustomAttributesProvider`, ($self) => class CommunityCampaingBotAudioPlayerStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298600451)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298600451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298600451)
            
            static $h = 3633155;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298600451),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3633155,
      "h": 4298600451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298600451)
  ],
  "h": 3633155
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotAudioPlayerStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotAudioPlayerStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3633155)
        
        

        //--TRIMMABLE-BOUNDARY-START(2256899)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotStateCustomAttributesProvider`, ($self) => class CommunityCampaignBotStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297224195)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297224195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297224195)
            
            static $h = 2256899;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297224195),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2256899,
      "h": 4297224195,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297224195)
  ],
  "h": 2256899
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2256899)
        
        

        //--TRIMMABLE-BOUNDARY-START(5009411)
        $asm.$cls(`$bTOs.LCCCCS$2.CommunityCampaignBotStatesCustomAttributesProvider`, ($self) => class CommunityCampaignBotStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299976707)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299976707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299976707)
            
            static $h = 5009411;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299976707),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5009411,
      "h": 4299976707,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299976707)
  ],
  "h": 5009411
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}States${separator}CommunityCampaignBotStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5009411)
        
        

        //--TRIMMABLE-BOUNDARY-START(94211)
        $asm.$cls(`$bTOs.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295061507)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295061507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotContactModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactsModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotStateCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTypeCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerStateCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaingBotJobState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaingBotJobStateCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaingBotJobStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatusCustomAttributesProvider, $.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatusCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsCustomAttributesProvider, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsCustomAttributesProvider, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$bTOs.LCCCCS$2.CommunityCampaignBotStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$bTOs.LCCCCS$2.CommunityCampaignBotStatesCustomAttributesProvider, $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295061507)
            
            static $h = 94211;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295061507),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 94211,
      "h": 4295061507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295061507)
  ],
  "h": 94211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(94211)
        
        

        //--TRIMMABLE-BOUNDARY-START(159747)
        $asm.$cls(`$bTOs.LCCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295127043)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295127043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295127043)
            
            static $h = 159747;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295127043),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 159747,
      "h": 4295127043,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295127043)
  ],
  "h": 159747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(159747)
        
        

        //--TRIMMABLE-BOUNDARY-START(3895299)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatusCustomAttributesProvider`, ($self) => class CommunityCampaingBotPhoneCallStatusCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298862595)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298862595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298862595)
            
            static $h = 3895299;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298862595),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3895299,
      "h": 4298862595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298862595)
  ],
  "h": 3895299
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotPhoneCallStatusCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotPhoneCallStatusCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3895299)
        
        

        //--TRIMMABLE-BOUNDARY-START(4878339)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594812931)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594812931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KxLhwe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4878339,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594812931)
            
            //--TRIMMABLE-BOUNDARY-START(4299845635)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299845635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299845635)
            
            //--TRIMMABLE-BOUNDARY-START(4299845635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299845635)
            
            static $h = 4878339;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594812931),
    {
      "r": 65537,
      "n": "Register",
      "d": 4878339,
      "h": 8594812931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594812931)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299845635),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4878339,
      "h": 4299845635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299845635)
  ],
  "h": 4878339
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4878339)
        
        

        //--TRIMMABLE-BOUNDARY-START(2912259)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592846851)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592846851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VUIIxb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2912259,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592846851)
            
            //--TRIMMABLE-BOUNDARY-START(4297879555)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297879555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297879555)
            
            //--TRIMMABLE-BOUNDARY-START(4297879555)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297879555)
            
            static $h = 2912259;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592846851),
    {
      "r": 65537,
      "n": "Register",
      "d": 2912259,
      "h": 8592846851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592846851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297879555),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2912259,
      "h": 4297879555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297879555)
  ],
  "h": 2912259
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2912259)
        
        

        //--TRIMMABLE-BOUNDARY-START(4747267)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotSettingsCustomAttributesProvider`, ($self) => class CommunityCampaignBotSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299714563)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299714563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299714563)
            
            static $h = 4747267;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299714563),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4747267,
      "h": 4299714563,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299714563)
  ],
  "h": 4747267
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4747267)
        
        

        //--TRIMMABLE-BOUNDARY-START(225283)
        $asm.$cls(`$bTOs.LCCCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295192579)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295192579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService, $.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService_Mocking().$ctor$3(impl);
                }, $VTBXcd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService_Mocking().$ctor$3(impl);
                }, $hSiJqd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$bTOs.LCCCCS.IComunityCampaignBotRemoteService, $.$bTOs.LCCCCS.IComunityCampaignBotRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCCCCS.IComunityCampaignBotRemoteService_Mocking().$ctor$3(impl);
                }, $RUHRed ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $XsTjze ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $QJYLDd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $RGILRj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $scSFGg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $WxeRob ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $SAwbwb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking().$ctor$3(impl);
                }, $sWhwCi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":225283,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295192579)
            
            static $h = 225283;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295192579),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 225283,
      "h": 4295192579,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295192579)
  ],
  "h": 225283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(225283)
        
        

        //--TRIMMABLE-BOUNDARY-START(618499)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotContactModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295585795)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295585795)
            
            //--TRIMMABLE-BOUNDARY-START(8590553091)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590553091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$bTOs.LCCCCM.CommunityCampaignBotContactModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(9, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Number", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("n");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Gender", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("g");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Age", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("a");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Locale", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("l");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CallProgress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("p");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CallEngagementTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("e");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CallCost", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t9 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$3("c");
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("QueueingTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t10 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$3("q");
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Bot", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t11 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$3("b");
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$bTOs.LCCCCM.CommunityCampaignBotContactModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $LNYSQg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":618499,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WyiZta ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":618499,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590553091)
            
            static $h = 618499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590553091),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 618499,
      "h": 8590553091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590553091)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295585795),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 618499,
      "h": 4295585795,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295585795)
  ],
  "h": 618499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(618499)
        
        

        //--TRIMMABLE-BOUNDARY-START(880643)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactResultModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotContactResultModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295847939)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295847939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataComplexPropertyModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295847939)
            
            static $h = 880643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295847939),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 880643,
      "h": 4295847939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295847939)
  ],
  "h": 880643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactResultModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(880643)
        
        

        //--TRIMMABLE-BOUNDARY-START(3764227)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaingBotJobStateCustomAttributesProvider`, ($self) => class CommunityCampaingBotJobStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298731523)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298731523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298731523)
            
            static $h = 3764227;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298731523),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3764227,
      "h": 4298731523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298731523)
  ],
  "h": 3764227
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotJobStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotJobStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3764227)
        
        

        //--TRIMMABLE-BOUNDARY-START(1273859)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotContactsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591208451)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591208451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HSmesi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1273859,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591208451)
            
            //--TRIMMABLE-BOUNDARY-START(4296241155)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296241155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296241155)
            
            //--TRIMMABLE-BOUNDARY-START(4296241155)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296241155)
            
            static $h = 1273859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591208451),
    {
      "r": 65537,
      "n": "Register",
      "d": 1273859,
      "h": 8591208451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591208451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296241155),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1273859,
      "h": 4296241155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296241155)
  ],
  "h": 1273859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1273859)
        
        

        //--TRIMMABLE-BOUNDARY-START(1798147)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591732739)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591732739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iWAQDh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1798147,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591732739)
            
            //--TRIMMABLE-BOUNDARY-START(4296765443)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296765443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296765443)
            
            //--TRIMMABLE-BOUNDARY-START(4296765443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296765443)
            
            static $h = 1798147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591732739),
    {
      "r": 65537,
      "n": "Register",
      "d": 1798147,
      "h": 8591732739,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591732739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296765443),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1798147,
      "h": 4296765443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296765443)
  ],
  "h": 1798147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1798147)
        
        

        //--TRIMMABLE-BOUNDARY-START(1929219)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotPostModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296896515)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296896515)
            
            //--TRIMMABLE-BOUNDARY-START(8591863811)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591863811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$bTOs.LCCCCM.CommunityCampaignBotPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(24, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.ExcludeFilter = ($.$bTOs.LCCCCM.CommunityCampaignBotPostPropertyFilter.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BotType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1024);
                            $i4.Exclude = $.$cast((16776190), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Targeting", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (1025);
                            $i5.Exclude = $.$cast((16777214), $.$fPer.LCFCA$1.SchemaType);
                            $i5.InputType = $.$cast(576460752303423488n, $.$fPer.LCFC.InputType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Wallet", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (1026);
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MediaUrl", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SpeechPaymentReference", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SpeechText", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SpeechBgMusic", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SpeechBinary", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MediaPeriod", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16776191), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StateReason", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Contacts", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            $i15.InputType = $.$cast(16n, $.$fPer.LCFC.InputType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalContacts", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalPending", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t17 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$4();
                            $i17.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HasGenderContactData", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t18 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$4();
                            $i18.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Males", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t19 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i19 = new $t19();
                            $i19.$ctor$4();
                            $i19.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i19;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Females", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t20 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i20 = new $t20();
                            $i20.$ctor$4();
                            $i20.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i20;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalDialed", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t21 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i21 = new $t21();
                            $i21.$ctor$4();
                            $i21.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i21;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalPicked", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t22 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i22 = new $t22();
                            $i22.$ctor$4();
                            $i22.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i22;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalRejected", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t23 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i23 = new $t23();
                            $i23.$ctor$4();
                            $i23.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i23;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalUnreachable", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t24 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i24 = new $t24();
                            $i24.$ctor$4();
                            $i24.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i24;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalEngagements", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t25 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i25 = new $t25();
                            $i25.$ctor$4();
                            $i25.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i25;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Spent", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t26 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i26 = new $t26();
                            $i26.$ctor$4();
                            $i26.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i26;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$bTOs.LCCCCM.CommunityCampaignBotPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ysnJNd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1929219,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ilzkkl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1929219,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591863811)
            
            static $h = 1929219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591863811),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1929219,
      "h": 8591863811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591863811)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296896515),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1929219,
      "h": 4296896515,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296896515)
  ],
  "h": 1929219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1929219)
        
        

        //--TRIMMABLE-BOUNDARY-START(2387971)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotTargetingModelCustomAttributesProvider`, ($self) => class CommunityCampaignBotTargetingModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297355267)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297355267)
            
            //--TRIMMABLE-BOUNDARY-START(8592322563)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592322563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Locations", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.InputType = $.$cast(576460752303423488n, $.$fPer.LCFC.InputType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $EObcYi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2387971,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $jbLOsf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2387971,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592322563)
            
            static $h = 2387971;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592322563),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2387971,
      "h": 8592322563,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592322563)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297355267),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2387971,
      "h": 4297355267,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297355267)
  ],
  "h": 2387971
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotTargetingModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2387971)
        
        

        //--TRIMMABLE-BOUNDARY-START(1011715)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotContactResultModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590946307)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590946307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ERlAff ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1011715,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590946307)
            
            //--TRIMMABLE-BOUNDARY-START(4295979011)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295979011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295979011)
            
            //--TRIMMABLE-BOUNDARY-START(4295979011)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295979011)
            
            static $h = 1011715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590946307),
    {
      "r": 65537,
      "n": "Register",
      "d": 1011715,
      "h": 8590946307,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590946307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295979011),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1011715,
      "h": 4295979011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295979011)
  ],
  "h": 1011715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactResultModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1011715)
        
        

        //--TRIMMABLE-BOUNDARY-START(5140483)
        $asm.$cls(`$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595075075)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595075075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FSTtqc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5140483,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCS$2.CommunityCampaignBotStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595075075)
            
            //--TRIMMABLE-BOUNDARY-START(4300107779)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300107779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300107779)
            
            //--TRIMMABLE-BOUNDARY-START(4300107779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300107779)
            
            static $h = 5140483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595075075),
    {
      "r": 65537,
      "n": "Register",
      "d": 5140483,
      "h": 8595075075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595075075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300107779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5140483,
      "h": 4300107779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300107779)
  ],
  "h": 5140483
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}States${separator}CommunityCampaignBotStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5140483)
        
        

        //--TRIMMABLE-BOUNDARY-START(5206019)
        $asm.$cls(`$bTOs.LCCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300173315)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300173315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptorBuilder.Register();
                $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4300173315)
            
            static $h = 5206019;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300173315),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5206019,
      "h": 4300173315,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300173315)
  ],
  "h": 5206019
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5206019)
        
        

        //--TRIMMABLE-BOUNDARY-START(487427)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotCategoryModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590422019)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590422019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tfCdla ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":487427,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590422019)
            
            //--TRIMMABLE-BOUNDARY-START(4295454723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295454723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295454723)
            
            //--TRIMMABLE-BOUNDARY-START(4295454723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295454723)
            
            static $h = 487427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590422019),
    {
      "r": 65537,
      "n": "Register",
      "d": 487427,
      "h": 8590422019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590422019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295454723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 487427,
      "h": 4295454723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295454723)
  ],
  "h": 487427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotCategoryModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(487427)
        
        

        //--TRIMMABLE-BOUNDARY-START(2519043)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotTargetingModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592453635)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592453635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nTmBka ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2519043,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592453635)
            
            //--TRIMMABLE-BOUNDARY-START(4297486339)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297486339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297486339)
            
            //--TRIMMABLE-BOUNDARY-START(4297486339)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297486339)
            
            static $h = 2519043;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592453635),
    {
      "r": 65537,
      "n": "Register",
      "d": 2519043,
      "h": 8592453635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592453635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297486339),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2519043,
      "h": 4297486339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297486339)
  ],
  "h": 2519043
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotTargetingModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2519043)
        
        

        //--TRIMMABLE-BOUNDARY-START(749571)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotContactModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590684163)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590684163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nkHsYd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":749571,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590684163)
            
            //--TRIMMABLE-BOUNDARY-START(4295716867)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295716867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295716867)
            
            //--TRIMMABLE-BOUNDARY-START(4295716867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295716867)
            
            static $h = 749571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590684163),
    {
      "r": 65537,
      "n": "Register",
      "d": 749571,
      "h": 8590684163,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590684163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295716867),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 749571,
      "h": 4295716867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295716867)
  ],
  "h": 749571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(749571)
        
        

        //--TRIMMABLE-BOUNDARY-START(1536003)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591470595)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591470595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cKwDSa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1536003,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591470595)
            
            //--TRIMMABLE-BOUNDARY-START(4296503299)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296503299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296503299)
            
            //--TRIMMABLE-BOUNDARY-START(4296503299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296503299)
            
            static $h = 1536003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591470595),
    {
      "r": 65537,
      "n": "Register",
      "d": 1536003,
      "h": 8591470595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591470595)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296503299),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1536003,
      "h": 4296503299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296503299)
  ],
  "h": 1536003
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1536003)
        
        

        //--TRIMMABLE-BOUNDARY-START(3502083)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotVoiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593436675)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593436675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KoHUId ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3502083,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593436675)
            
            //--TRIMMABLE-BOUNDARY-START(4298469379)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298469379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298469379)
            
            //--TRIMMABLE-BOUNDARY-START(4298469379)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298469379)
            
            static $h = 3502083;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593436675),
    {
      "r": 65537,
      "n": "Register",
      "d": 3502083,
      "h": 8593436675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593436675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298469379),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3502083,
      "h": 4298469379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298469379)
  ],
  "h": 3502083
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3502083)
        
        

        //--TRIMMABLE-BOUNDARY-START(4616195)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594550787)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594550787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LOHCfc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4616195,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594550787)
            
            //--TRIMMABLE-BOUNDARY-START(4299583491)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299583491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299583491)
            
            //--TRIMMABLE-BOUNDARY-START(4299583491)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299583491)
            
            static $h = 4616195;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594550787),
    {
      "r": 65537,
      "n": "Register",
      "d": 4616195,
      "h": 8594550787,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594550787)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299583491),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4616195,
      "h": 4299583491,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299583491)
  ],
  "h": 4616195
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4616195)
        
        

        //--TRIMMABLE-BOUNDARY-START(3239939)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593174531)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593174531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $niUGok ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3239939,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593174531)
            
            //--TRIMMABLE-BOUNDARY-START(4298207235)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298207235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298207235)
            
            //--TRIMMABLE-BOUNDARY-START(4298207235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298207235)
            
            static $h = 3239939;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593174531),
    {
      "r": 65537,
      "n": "Register",
      "d": 3239939,
      "h": 8593174531,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593174531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298207235),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3239939,
      "h": 4298207235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298207235)
  ],
  "h": 3239939
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3239939)
        
        

        //--TRIMMABLE-BOUNDARY-START(2060291)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptorBuilder`, ($self) => class CommunityCampaignBotPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591994883)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591994883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor()
                        const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nRNpyd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2060291,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591994883)
            
            //--TRIMMABLE-BOUNDARY-START(4297027587)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297027587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297027587)
            
            //--TRIMMABLE-BOUNDARY-START(4297027587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297027587)
            
            static $h = 2060291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591994883),
    {
      "r": 65537,
      "n": "Register",
      "d": 2060291,
      "h": 8591994883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591994883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297027587),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2060291,
      "h": 4297027587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297027587)
  ],
  "h": 2060291
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2060291)
        
        

        //--TRIMMABLE-BOUNDARY-START(2125827)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotPostPropertyFilter`, ($self) => class CommunityCampaignBotPostPropertyFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592060419)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592060419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let propertyName = typeOrProperty.IsT1 ? typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name : null;
                return propertyName === "Name" || propertyName === "BotType" || propertyName === "Category" || propertyName === "Targeting" || propertyName === "Wallet";
            }
            //--TRIMMABLE-BOUNDARY-END(8592060419)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4297093123)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297093123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297093123)
            
            //--TRIMMABLE-BOUNDARY-START(4297093123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297093123)
            
            static $h = 2125827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592060419),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 2125827,
      "h": 8592060419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592060419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297093123),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2125827,
      "h": 4297093123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297093123)
  ],
  "h": 2125827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostPropertyFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotPostPropertyFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2125827)
        
        

        //--TRIMMABLE-BOUNDARY-START(2322435)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotTargetingModel`, ($self) => class CommunityCampaignBotTargetingModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772126211)
            /*Gender?*/ Gender = null;
            //--TRIMMABLE-BOUNDARY-END(25772126211)
            
            //--TRIMMABLE-BOUNDARY-START(21477158915)
            /*ValueRange<double?>*/ AgeRange;
            //--TRIMMABLE-BOUNDARY-END(21477158915)
            
            //--TRIMMABLE-BOUNDARY-START(55836897283)
            /*IEnumerable<INamedLocation>?*/ Locations = null;
            //--TRIMMABLE-BOUNDARY-END(55836897283)
            
            //--TRIMMABLE-BOUNDARY-START(85901668355)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901668355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.Geographic.INamedLocation>?*/ let __ca1__;
                return `Gender: ${$.$strNN(this.Gender)}, Age: ${$.$strNN(this.AgeRange.ToString())}, Location: ${$.$strNN($.$$.S.String.Join$5(",", ((__ca1__ = this.Locations) !== null ? ($.$sl.SL.Enumerable.Select$1($.$fPer.LCFCDG.INamedLocation, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$fPer.LCFCDG.INamedLocation, $.$$.S.String))().$ctor(this,  (/*l*/ l) =>
                {
                    return l.LCFC$INamed$Name;
                }, $PuoaCd ??= {"r":1310721,"p":[{"n":"l","p":15108438}],"n":"","d":2322435,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String))))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(85901668355)
            
            //--TRIMMABLE-BOUNDARY-START(17182191619)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182191619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182191619)
            
            //--TRIMMABLE-BOUNDARY-START(17182191619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182191619)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477158915)
                this.AgeRange = $.$default($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)));
                //--TRIMMABLE-BOUNDARY-END(21477158915)
                
            }
            static $h = 2322435;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772126211),
    {
      "p": $.$typeNullable($.$fPer.LCFCD.Gender).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951995395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016766467,
        "f": 83886081
      },
      "n": "Gender",
      "d": 2322435,
      "h": 25772126211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772126211),
//--TRIMMABLE-BOUNDARY-START(21477158915),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362060803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426831875,
        "f": 83886081
      },
      "n": "AgeRange",
      "d": 2322435,
      "h": 21477158915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477158915),
//--TRIMMABLE-BOUNDARY-START(55836897283),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541929987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606701059,
        "f": 83886081
      },
      "n": "Locations",
      "d": 2322435,
      "h": 55836897283,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 576460752303423488,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836897283)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901668355),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2322435,
      "h": 85901668355,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901668355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182191619),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2322435,
      "h": 17182191619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182191619)
  ],
  "h": 2322435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotTargetingModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2322435)
        
        

        //--TRIMMABLE-BOUNDARY-START(3960835)
        $asm.$cls(`$bTOs.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593895427)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593895427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, 8449/*PostTypes.CampaignBotCategory*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, 8450/*PostTypes.CampaignBotPost*/);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$OJJQ.LCFCW.IWalletIssuer, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$bTOs.LCCCCS.CommunityCampaignBotWalletProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$OJJQ.LCFCW.IWalletIssuer))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$bTOs.LCCCCS.CommunityCampaignBotWalletProvider, x);
                }, $ykbVee ??= {"r":636109,"p":[{"n":"x","p":327718}],"n":"","d":3960835,"h":0,"f":17825794}));
                $.$bTOs.LCCCC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$bTOs.LCCCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$bTOs.LCCCC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593895427)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298928131)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298928131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298928131)
            
            //--TRIMMABLE-BOUNDARY-START(4298928131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298928131)
            
            static $h = 3960835;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593895427),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3960835,
      "h": 8593895427,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593895427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298928131),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3960835,
      "h": 4298928131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298928131)
  ],
  "h": 3960835
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3960835)
        
        

        //--TRIMMABLE-BOUNDARY-START(3305475)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceModel`, ($self) => class CommunityCampaignBotVoiceModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55837880323)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55837880323)
            
            //--TRIMMABLE-BOUNDARY-START(21478141955)
            /*Gender*/ Gender = 0;
            //--TRIMMABLE-BOUNDARY-END(21478141955)
            
            //--TRIMMABLE-BOUNDARY-START(85902651395)
            /*string*/ VoiceCode = null;
            //--TRIMMABLE-BOUNDARY-END(85902651395)
            
            //--TRIMMABLE-BOUNDARY-START(51542913027)
            /*ValueTask<IEnumerable<IChildrenHierachy>?> */ GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542913027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy), null);
            }
            //--TRIMMABLE-BOUNDARY-END(51542913027)
            
            //--TRIMMABLE-BOUNDARY-START(4310927702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IChildrenHierachy.GetChildren()
            LCFCD$IChildrenHierachy$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4310927702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4310927702)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17183174659)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183174659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183174659)
            
            //--TRIMMABLE-BOUNDARY-START(17183174659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17183174659)
            
            static $h = 3305475;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837880323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658011139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017749507,
        "f": 83886081
      },
      "n": "Name",
      "d": 3305475,
      "h": 55837880323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837880323),
//--TRIMMABLE-BOUNDARY-START(21478141955),
    {
      "p": 13601110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068076547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427814915,
        "f": 83886081
      },
      "n": "Gender",
      "d": 3305475,
      "h": 21478141955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478141955),
//--TRIMMABLE-BOUNDARY-START(85902651395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247945731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607684099,
        "f": 83886081
      },
      "n": "VoiceCode",
      "d": 3305475,
      "h": 85902651395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85902651395)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51542913027),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "GetChildren",
      "d": 3305475,
      "h": 51542913027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542913027)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183174659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3305475,
      "h": 17183174659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183174659)
  ],
  "h": 3305475
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3305475)
        
        

        //--TRIMMABLE-BOUNDARY-START(552963)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactModel`, ($self) => class CommunityCampaignBotContactModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(188979113987)
            /*string?*/ number = null;
            //--TRIMMABLE-BOUNDARY-END(188979113987)
            
            //--TRIMMABLE-BOUNDARY-START(193274081283)
            /*string? */ get Number()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504277507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.number;
            }
            /*string? */ set Number(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468394499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.number = $.$fPer.LCFCD.PhoneNumber.Normalize(value, true);
            }
            //--TRIMMABLE-BOUNDARY-END(193274081283)
            
            //--TRIMMABLE-BOUNDARY-START(90194866179)
            /*Gender?*/ Gender = null;
            //--TRIMMABLE-BOUNDARY-END(90194866179)
            
            //--TRIMMABLE-BOUNDARY-START(51540160515)
            /*int?*/ Age = null;
            //--TRIMMABLE-BOUNDARY-END(51540160515)
            
            //--TRIMMABLE-BOUNDARY-START(184684146691)
            /*string?*/ Locale = null;
            //--TRIMMABLE-BOUNDARY-END(184684146691)
            
            //--TRIMMABLE-BOUNDARY-START(68720029699)
            /*CallResultState?*/ CallProgress = null;
            //--TRIMMABLE-BOUNDARY-END(68720029699)
            
            //--TRIMMABLE-BOUNDARY-START(64425062403)
            /*int?*/ CallEngagementTime = null;
            //--TRIMMABLE-BOUNDARY-END(64425062403)
            
            //--TRIMMABLE-BOUNDARY-START(60130095107)
            /*double?*/ CallCost = null;
            //--TRIMMABLE-BOUNDARY-END(60130095107)
            
            //--TRIMMABLE-BOUNDARY-START(214748917763)
            /*DateTime?*/ QueueingTime = null;
            //--TRIMMABLE-BOUNDARY-END(214748917763)
            
            //--TRIMMABLE-BOUNDARY-START(55835127811)
            /*string?*/ Bot = null;
            //--TRIMMABLE-BOUNDARY-END(55835127811)
            
            //--TRIMMABLE-BOUNDARY-START(85899898883)
            static /*CommunityCampaignBotContactModel? */ FromString(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899898883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(s))
                {
                    return null;
                }
                /*var*/ let split = $.$$.S.String.Split$6.call(s, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*-*/ 45, /*,*/ 44 ]));
                return (() =>
                {
                    //new $.$bTOs.LCCCCM.CommunityCampaignBotContactModel()
                    const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotContactModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Number = $.$$.System.Array.$ReadT1.call(split, 0);
                    $i1.Gender = split.length > 1 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 1)) ? ($.$$.S.String.ToLower.call($.$$.System.Array.$ReadT1.call(split, 1)) === "m" ? 1/*Frameworks.Common.Data.Gender.Male*/ : $.$$.S.String.ToLower.call($.$$.System.Array.$ReadT1.call(split, 1)) === "f" ? 2/*Frameworks.Common.Data.Gender.Female*/ : $.$$.S.Enum.Parse$7($.$fPer.LCFCD.Gender, $.$$.System.Array.$ReadT1.call(split, 1))) : null;
                    $i1.Age = split.length > 2 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 2)) ? $.$$.S.Int32.Parse$7($.$$.System.Array.$ReadT1.call(split, 2)) : null;
                    $i1.Locale = split.length > 3 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 3)) ? $.$$.System.Array.$ReadT1.call(split, 3) : null;
                    $i1.CallProgress = split.length > 4 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 4)) ? $.$$.S.Enum.Parse$7($.$fPer.LCFCM.CallResultState, $.$$.System.Array.$ReadT1.call(split, 4)) : null;
                    $i1.CallEngagementTime = split.length > 5 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 5)) ? $.$$.S.Int32.Parse$7($.$$.System.Array.$ReadT1.call(split, 5)) : null;
                    $i1.CallCost = split.length > 6 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 6)) ? $.$$.S.Double.Parse$7($.$$.System.Array.$ReadT1.call(split, 6)) : null;
                    $i1.QueueingTime = split.length > 7 && !$.$$.S.String.IsNullOrEmpty($.$$.System.Array.$ReadT1.call(split, 7)) ? $.$$.S.DateTime.Parse$4($.$$.System.Array.$ReadT1.call(split, 7)) : null;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(85899898883)
            
            //--TRIMMABLE-BOUNDARY-START(296353296387)
            static /*string? */ op_Implicit(/*CommunityCampaignBotContactModel*/ c)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(296353296387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return c.Number;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(296353296387)
            
            //--TRIMMABLE-BOUNDARY-START(300648263683)
            static /*CommunityCampaignBotContactModel? */ op_Implicit$1(/*string?*/ s)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648263683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.FromString(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300648263683)
            
            //--TRIMMABLE-BOUNDARY-START(304943230979)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943230979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Number)},${$.$strNN(this.Gender)},${$.$strNN(this.Age)},${$.$strNN(this.Locale)},${$.$strNN(this.CallProgress)},${$.$strNN(this.CallEngagementTime)},${$.$strNN(this.CallCost)},${$.$strNN(this.QueueingTime.ToString())}`;
            }
            //--TRIMMABLE-BOUNDARY-END(304943230979)
            
            //--TRIMMABLE-BOUNDARY-START(309238198275)
            /*string? */ ToUIString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238198275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Number)},${$.$strNN(this.Gender)},${$.$strNN(this.Age)},${$.$strNN(this.Locale)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(309238198275)
            
            //--TRIMMABLE-BOUNDARY-START(206158983171)
            static /*CommunityCampaignBotContactModel? */ Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158983171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.FromString(s);
            }
            //--TRIMMABLE-BOUNDARY-END(206158983171)
            
            //--TRIMMABLE-BOUNDARY-START(313533165571)
            static /*bool */ TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out CommunityCampaignBotContactModel?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533165571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s === null)
                {
                    result.$v = null;
                    return false;
                }
                result.$v = $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.FromString(s);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(313533165571)
            
            //--TRIMMABLE-BOUNDARY-START(180389179395)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389179395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return ((__ca1__ = this.Number) !== null ? $.$$.S.String.GetHashCode.call(__ca1__) : $.$$.S.Object.GetHashCode.call(this));
            }
            //--TRIMMABLE-BOUNDARY-END(180389179395)
            
            //--TRIMMABLE-BOUNDARY-START(4392222721)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel?>.Parse(string, System.IFormatProvider?)
            static S$IParsable$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotContactModel$Parse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392222721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.Parse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392222721)
            
            //--TRIMMABLE-BOUNDARY-START(8687190017)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel?>.TryParse(string?, System.IFormatProvider?, out LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel?)
            static S$IParsable$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotContactModel$TryParse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687190017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.TryParse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687190017)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>.Equals(LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel?)
            S$IEquatable$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotContactModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(42950225923)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950225923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950225923)
            
            //--TRIMMABLE-BOUNDARY-START(42950225923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(42950225923)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.number = this.number;
                copy.Gender = this.Gender;
                copy.Age = this.Age;
                copy.Locale = this.Locale;
                copy.CallProgress = this.CallProgress;
                copy.CallEngagementTime = this.CallEngagementTime;
                copy.CallCost = this.CallCost;
                copy.QueueingTime = this.QueueingTime?.$clone() ?? null;
                copy.Bot = this.Bot;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(214748917763)
                this.QueueingTime = null;
                //--TRIMMABLE-BOUNDARY-END(214748917763)
                
            }
            //Begin generated record members
            /*Type*/ get EqualityContract() { return $.$typeOf($.$bTOs.LCCCCM.CommunityCampaignBotContactModel); }
            /*string*/ ToString()
            {
                let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                stringBuilder.Append$21("CommunityCampaignBotContactModel");
                stringBuilder.Append$21("{");
                if (this.PrintMembers(stringBuilder))
                {
                    stringBuilder.Append$21(" ");
                }
                stringBuilder.Append$21("}");
                return stringBuilder.ToString();
            }
            /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
            {
                stringBuilder.Append$21("Number = ");
                stringBuilder.Append$21(this.Number);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Gender = ");
                stringBuilder.Append$21(this.Gender.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Age = ");
                stringBuilder.Append$21(this.Age.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Locale = ");
                stringBuilder.Append$21(this.Locale);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CallProgress = ");
                stringBuilder.Append$21(this.CallProgress.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CallEngagementTime = ");
                stringBuilder.Append$21(this.CallEngagementTime.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CallCost = ");
                stringBuilder.Append$21(this.CallCost.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("QueueingTime = ");
                stringBuilder.Append$21(this.QueueingTime.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Bot = ");
                stringBuilder.Append$21(this.Bot);
                return true;
            }
            /*bool*/ Equals$2(/*CommunityCampaignBotContactModel*/ other)
            {
                return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$$.S.String.op_Equality(this.Number, other.Number) && this.Gender === other.Gender && this.Age === other.Age && $.$$.S.String.op_Equality(this.Locale, other.Locale) && this.CallProgress === other.CallProgress && this.CallEngagementTime === other.CallEngagementTime && this.CallCost === other.CallCost && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.Equals$2(this.QueueingTime, other.QueueingTime) && $.$$.S.String.op_Equality(this.Bot, other.Bot));
            }
            /*int*/ GetHashCode()
            {
                return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Number) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$fPer.LCFCD.Gender)).Default.GetHashCode$1(this.Gender) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.Age) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Locale) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$fPer.LCFCM.CallResultState)).Default.GetHashCode$1(this.CallProgress) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.CallEngagementTime) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Double)).Default.GetHashCode$1(this.CallCost) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.GetHashCode$1(this.QueueingTime) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Bot) * -1521134295;
            }
            static /*bool*/ op_Inequality(/*CommunityCampaignBotContactModel*/ left, /*CommunityCampaignBotContactModel*/ right)
            {
                return !(this.op_Equality(left, right));
            }
            static /*bool*/ op_Equality(/*CommunityCampaignBotContactModel*/ left, /*CommunityCampaignBotContactModel*/ right)
            {
                return left === right || (left !== null && left.Equals$2(right));
            }
            Deconstruct(/*out string?*/ $Number, /*out LivingThing.Core.Frameworks.Common.Data.Gender?*/ $Gender, /*out int?*/ $Age, /*out string?*/ $Locale, /*out LivingThing.Core.Frameworks.Common.Messaging.CallResultState?*/ $CallProgress, /*out int?*/ $CallEngagementTime, /*out double?*/ $CallCost, /*out System.DateTime?*/ $QueueingTime, /*out string?*/ $Bot)
            {
                $Number.$v = this.Number;
                $Gender.$v = this.Gender;
                $Age.$v = this.Age;
                $Locale.$v = this.Locale;
                $CallProgress.$v = this.CallProgress;
                $CallEngagementTime.$v = this.CallEngagementTime;
                $CallCost.$v = this.CallCost;
                $QueueingTime.$v = this.QueueingTime;
                $Bot.$v = this.Bot;
            }
            //End generated record member3s
            static $h = 552963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014996995),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734473731,
        "f": 50331780
      },
      "n": "EqualityContract",
      "d": 552963,
      "h": 73014996995,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(73014996995),
//--TRIMMABLE-BOUNDARY-START(193274081283),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504277507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468394499,
        "f": 83886081
      },
      "n": "Number",
      "d": 552963,
      "h": 193274081283,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "n",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274081283),
//--TRIMMABLE-BOUNDARY-START(90194866179),
    {
      "p": $.$typeNullable($.$fPer.LCFCD.Gender).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324408323,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288525315,
        "f": 83886081
      },
      "n": "Gender",
      "d": 552963,
      "h": 90194866179,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "g",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194866179),
//--TRIMMABLE-BOUNDARY-START(51540160515),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784800771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338852355,
        "f": 83886081
      },
      "n": "Age",
      "d": 552963,
      "h": 51540160515,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540160515),
//--TRIMMABLE-BOUNDARY-START(184684146691),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914342915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878459907,
        "f": 83886081
      },
      "n": "Locale",
      "d": 552963,
      "h": 184684146691,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "l",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684146691),
//--TRIMMABLE-BOUNDARY-START(68720029699),
    {
      "p": $.$typeNullable($.$fPer.LCFCM.CallResultState).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144539139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698590723,
        "f": 83886081
      },
      "n": "CallProgress",
      "d": 552963,
      "h": 68720029699,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "p",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720029699),
//--TRIMMABLE-BOUNDARY-START(64425062403),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554604547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108656131,
        "f": 83886081
      },
      "n": "CallEngagementTime",
      "d": 552963,
      "h": 64425062403,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "e",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425062403),
//--TRIMMABLE-BOUNDARY-START(60130095107),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964669955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518721539,
        "f": 83886081
      },
      "n": "CallCost",
      "d": 552963,
      "h": 60130095107,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "c",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130095107),
//--TRIMMABLE-BOUNDARY-START(214748917763),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094212099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058329091,
        "f": 83886081
      },
      "n": "QueueingTime",
      "d": 552963,
      "h": 214748917763,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "q",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748917763),
//--TRIMMABLE-BOUNDARY-START(55835127811),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374735363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928786947,
        "f": 83886081
      },
      "n": "Bot",
      "d": 552963,
      "h": 55835127811,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "b",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835127811)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899898883),
    {
      "r": 552963,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "FromString",
      "d": 552963,
      "h": 85899898883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899898883),
//--TRIMMABLE-BOUNDARY-START(304943230979),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 552963,
      "h": 304943230979,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304943230979),
//--TRIMMABLE-BOUNDARY-START(309238198275),
    {
      "r": 1310721,
      "n": "ToUIString",
      "d": 552963,
      "h": 309238198275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238198275),
//--TRIMMABLE-BOUNDARY-START(206158983171),
    {
      "r": 552963,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        }
      ],
      "n": "Parse",
      "d": 552963,
      "h": 206158983171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206158983171),
//--TRIMMABLE-BOUNDARY-START(313533165571),
    {
      "r": 262145,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        },
        {
          "n": "result",
          "p": 552963,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 552963,
      "h": 313533165571,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313533165571),
//--TRIMMABLE-BOUNDARY-START(180389179395),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 552963,
      "h": 180389179395,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389179395),
//--TRIMMABLE-BOUNDARY-START(210453950467),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": 552963,
      "h": 210453950467,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(210453950467),
//--TRIMMABLE-BOUNDARY-START(77309964291),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 552963,
      "h": 77309964291,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309964291),
//--TRIMMABLE-BOUNDARY-START(81604931587),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 552963
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 552963,
      "h": 81604931587,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604931587),
//--TRIMMABLE-BOUNDARY-START(25770356739),
    {
      "r": 552963,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": 552963,
      "h": 25770356739,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770356739)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(188979113987),
    {
      "t": 1310721,
      "n": "number",
      "d": 552963,
      "h": 188979113987,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188979113987)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245193219),
    {
      "p": [
        {
          "n": "original",
          "p": 552963
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 552963,
      "h": 47245193219,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47245193219),
//--TRIMMABLE-BOUNDARY-START(42950225923),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 552963,
      "h": 42950225923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950225923)
  ],
  "h": 552963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IParsable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$$.S.IEquatable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(552963)
        
        

        //--TRIMMABLE-BOUNDARY-START(815107)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactResultModel`, ($self) => class CommunityCampaignBotContactResultModel extends $.$Iaui.LCFCM.DataComplexPropertyModel
        {
            //--TRIMMABLE-BOUNDARY-START(21475651587)
            /*CommunityCampaignBotContactsModel */ get Contact()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835389955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, "Contact", new $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel());
            }
            /*CommunityCampaignBotContactsModel */ set Contact(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195128323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, $.$clone(value), "Contact");
            }
            //--TRIMMABLE-BOUNDARY-END(21475651587)
            
            //--TRIMMABLE-BOUNDARY-START(17180684291)
            /*CallResultState */ get CallResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245455363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCM.CallResultState, "CallResult", 0);
            }
            /*CallResultState */ set CallResult(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605193731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCM.CallResultState, value, "CallResult");
            }
            //--TRIMMABLE-BOUNDARY-END(17180684291)
            
            //--TRIMMABLE-BOUNDARY-START(12885716995)
            /*int */ get CallEngagementTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655520771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, "CallEngagementTime", 0);
            }
            /*int */ set CallEngagementTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015259139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "CallEngagementTime");
            }
            //--TRIMMABLE-BOUNDARY-END(12885716995)
            
            //--TRIMMABLE-BOUNDARY-START(8590749699)
            /*double */ get CallCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065586179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Double, "CallCost", 0);
            }
            /*double */ set CallCost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425324547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Double, value, "CallCost");
            }
            //--TRIMMABLE-BOUNDARY-END(8590749699)
            
            //--TRIMMABLE-BOUNDARY-START(4295782403)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295782403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295782403)
            
            //--TRIMMABLE-BOUNDARY-START(4295782403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295782403)
            
            static $h = 815107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataComplexPropertyModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475651587),
    {
      "p": 1077251,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835389955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195128323,
        "f": 83886081
      },
      "n": "Contact",
      "d": 815107,
      "h": 21475651587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475651587),
//--TRIMMABLE-BOUNDARY-START(17180684291),
    {
      "p": 48859478,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245455363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605193731,
        "f": 83886081
      },
      "n": "CallResult",
      "d": 815107,
      "h": 17180684291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180684291),
//--TRIMMABLE-BOUNDARY-START(12885716995),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655520771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015259139,
        "f": 83886081
      },
      "n": "CallEngagementTime",
      "d": 815107,
      "h": 12885716995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885716995),
//--TRIMMABLE-BOUNDARY-START(8590749699),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065586179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425324547,
        "f": 83886081
      },
      "n": "CallCost",
      "d": 815107,
      "h": 8590749699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590749699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295782403),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 815107,
      "h": 4295782403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295782403)
  ],
  "h": 815107
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactResultModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(815107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1339395)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel`, ($self) => class CommunityCampaignBotDeviceStateModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(193274867715)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(193274867715)
            
            //--TRIMMABLE-BOUNDARY-START(73015783427)
            /*CommunityCampaingBotPhoneCallStatus*/ CallStatus = 0;
            //--TRIMMABLE-BOUNDARY-END(73015783427)
            
            //--TRIMMABLE-BOUNDARY-START(206159769603)
            /*CommunityCampaingBotAudioPlayerState*/ PlayerState = 0;
            //--TRIMMABLE-BOUNDARY-END(206159769603)
            
            //--TRIMMABLE-BOUNDARY-START(85900685315)
            /*Guid*/ CurrentJob;
            //--TRIMMABLE-BOUNDARY-END(85900685315)
            
            //--TRIMMABLE-BOUNDARY-START(81605718019)
            /*string[]?*/ CurrentContacts = null;
            //--TRIMMABLE-BOUNDARY-END(81605718019)
            
            //--TRIMMABLE-BOUNDARY-START(68720816131)
            /*int*/ CallIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(68720816131)
            
            //--TRIMMABLE-BOUNDARY-START(77310750723)
            /*string?*/ CurrentContact = null;
            //--TRIMMABLE-BOUNDARY-END(77310750723)
            
            //--TRIMMABLE-BOUNDARY-START(313533952003)
            /*CommunityCampaingBotJobState*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(313533952003)
            
            //--TRIMMABLE-BOUNDARY-START(197569835011)
            /*CommunityCampaignBotContactModel*/ LastCallSummary = null;
            //--TRIMMABLE-BOUNDARY-END(197569835011)
            
            //--TRIMMABLE-BOUNDARY-START(201864802307)
            /*DateTime?*/ LastSeenOnline = null;
            //--TRIMMABLE-BOUNDARY-END(201864802307)
            
            //--TRIMMABLE-BOUNDARY-START(60130881539)
            /*int*/ AudioDownloadProgress = 0;
            //--TRIMMABLE-BOUNDARY-END(60130881539)
            
            //--TRIMMABLE-BOUNDARY-START(64425848835)
            /*int*/ AudioDownloadSize = 0;
            //--TRIMMABLE-BOUNDARY-END(64425848835)
            
            //--TRIMMABLE-BOUNDARY-START(55835914243)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835914243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835914243)
            
            //--TRIMMABLE-BOUNDARY-START(55835914243)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(55835914243)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Id = this.Id;
                copy.CallStatus = this.CallStatus;
                copy.PlayerState = this.PlayerState;
                copy.CurrentJob = this.CurrentJob.$clone();
                copy.CurrentContacts = this.CurrentContacts;
                copy.CallIndex = this.CallIndex;
                copy.CurrentContact = this.CurrentContact;
                copy.State = this.State;
                copy.LastCallSummary = this.LastCallSummary;
                copy.LastSeenOnline = this.LastSeenOnline?.$clone() ?? null;
                copy.AudioDownloadProgress = this.AudioDownloadProgress;
                copy.AudioDownloadSize = this.AudioDownloadSize;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85900685315)
                this.CurrentJob = $.$default($.$$.S.Guid);
                //--TRIMMABLE-BOUNDARY-END(85900685315)
                
                //--TRIMMABLE-BOUNDARY-START(201864802307)
                this.LastSeenOnline = null;
                //--TRIMMABLE-BOUNDARY-END(201864802307)
                
            }
            static $h = 1339395;
            static $z = 56;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193274867715),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620162051,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879246339,
        "f": 83886081
      },
      "n": "Id",
      "d": 1339395,
      "h": 193274867715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274867715),
//--TRIMMABLE-BOUNDARY-START(73015783427),
    {
      "p": 3829763,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260423683,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519507971,
        "f": 83886081
      },
      "n": "CallStatus",
      "d": 1339395,
      "h": 73015783427,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015783427),
//--TRIMMABLE-BOUNDARY-START(206159769603),
    {
      "p": 3567619,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389965827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649050115,
        "f": 83886081
      },
      "n": "PlayerState",
      "d": 1339395,
      "h": 206159769603,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159769603),
//--TRIMMABLE-BOUNDARY-START(85900685315),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030227459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289311747,
        "f": 83886081
      },
      "n": "CurrentJob",
      "d": 1339395,
      "h": 85900685315,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900685315),
//--TRIMMABLE-BOUNDARY-START(81605718019),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440292867,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699377155,
        "f": 83886081
      },
      "n": "CurrentContacts",
      "d": 1339395,
      "h": 81605718019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605718019),
//--TRIMMABLE-BOUNDARY-START(68720816131),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670489091,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929573379,
        "f": 83886081
      },
      "n": "CallIndex",
      "d": 1339395,
      "h": 68720816131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720816131),
//--TRIMMABLE-BOUNDARY-START(77310750723),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850358275,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109442563,
        "f": 83886081
      },
      "n": "CurrentContact",
      "d": 1339395,
      "h": 77310750723,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310750723),
//--TRIMMABLE-BOUNDARY-START(313533952003),
    {
      "p": 3698691,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979900419,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238984707,
        "f": 83886081
      },
      "n": "State",
      "d": 1339395,
      "h": 313533952003,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313533952003),
//--TRIMMABLE-BOUNDARY-START(197569835011),
    {
      "p": 552963,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210096643,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469180931,
        "f": 83886081
      },
      "n": "LastCallSummary",
      "d": 1339395,
      "h": 197569835011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569835011),
//--TRIMMABLE-BOUNDARY-START(201864802307),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800031235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059115523,
        "f": 83886081
      },
      "n": "LastSeenOnline",
      "d": 1339395,
      "h": 201864802307,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864802307),
//--TRIMMABLE-BOUNDARY-START(60130881539),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490619907,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749704195,
        "f": 83886081
      },
      "n": "AudioDownloadProgress",
      "d": 1339395,
      "h": 60130881539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130881539),
//--TRIMMABLE-BOUNDARY-START(64425848835),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080554499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339638787,
        "f": 83886081
      },
      "n": "AudioDownloadSize",
      "d": 1339395,
      "h": 64425848835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425848835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835914243),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1339395,
      "h": 55835914243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835914243)
  ],
  "h": 1339395
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotDeviceStateModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1339395)
        
        

        //--TRIMMABLE-BOUNDARY-START(4354051)
        $asm.$str(`$bTOs.LCCCCS$1.CampaignBotBackgroundMusic`, ($self) => class CampaignBotBackgroundMusic extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81608732675)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(81608732675)
            
            //--TRIMMABLE-BOUNDARY-START(51543961603)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(51543961603)
            
            //--TRIMMABLE-BOUNDARY-START(21479190531)
            /*string*/ File = null;
            //--TRIMMABLE-BOUNDARY-END(21479190531)
            
            //--TRIMMABLE-BOUNDARY-START(85903699971)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903699971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title ?? this.File ?? super.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(85903699971)
            
            //--TRIMMABLE-BOUNDARY-START(17184223235)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184223235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17184223235)
            
            //--TRIMMABLE-BOUNDARY-START(17184223235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17184223235)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Title = this.Title;
                copy.Icon = this.Icon;
                copy.File = this.File;
                return copy;
            }
            static $h = 4354051;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81608732675),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248994307,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313765379,
        "f": 83886081
      },
      "n": "Title",
      "d": 4354051,
      "h": 81608732675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81608732675),
//--TRIMMABLE-BOUNDARY-START(51543961603),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659059715,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723830787,
        "f": 83886081
      },
      "n": "Icon",
      "d": 4354051,
      "h": 51543961603,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 14,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543961603),
//--TRIMMABLE-BOUNDARY-START(21479190531),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069125123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133896195,
        "f": 83886081
      },
      "n": "File",
      "d": 4354051,
      "h": 21479190531,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 14,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479190531)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85903699971),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 4354051,
      "h": 85903699971,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85903699971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184223235),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4354051,
      "h": 17184223235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184223235)
  ],
  "h": 4354051
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CampaignBotBackgroundMusic`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CampaignBotBackgroundMusic`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4354051)
        
        

        //--TRIMMABLE-BOUNDARY-START(1077251)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaignBotContactsModel`, ($self) => class CommunityCampaignBotContactsModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885979139)
            /*IEnumerable<CommunityCampaignBotContactModel>?*/ Contacts = null;
            //--TRIMMABLE-BOUNDARY-END(12885979139)
            
            //--TRIMMABLE-BOUNDARY-START(47245717507)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245717507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contacts !== null ? $.$$.S.String.Join$5("\r\n", $.$sl.SL.Enumerable.Select$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, this.Contacts, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return !$.$$.S.String.IsNullOrEmpty(c.Number);
                }, $ZnlSZd ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1077251,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.ToString();
                }, $fweFNd ??= {"r":1310721,"p":[{"n":"c","p":552963}],"n":"","d":1077251,"h":0,"f":17825794}))) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(47245717507)
            
            //--TRIMMABLE-BOUNDARY-START(38655782915)
            static /*string? */ op_Implicit(/*CommunityCampaignBotContactsModel*/ c)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655782915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return c.ToString();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655782915)
            
            //--TRIMMABLE-BOUNDARY-START(42950750211)
            static /*CommunityCampaignBotContactsModel */ op_Implicit$1(/*string?*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950750211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*string[]*/ let __ca2__;
                /*System.Collections.Generic.IEnumerable<string>*/ let __ca3__;
                return (() =>
                {
                    //new $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel()
                    const $t1 = $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Contacts = ((__ca1__ = c) !== null ? ((__ca2__ = $.$$.S.String.Split$6.call(__ca1__, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*\r*/ 13, /*\n*/ 10 ]))) !== null ? ((__ca3__ = $.$sl.SL.Enumerable.Where($.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(c);
                    }, $Vxmdjl ??= {"r":262145,"p":[{"n":"c","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca3__, new ($.$$.S.Func$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.op_Implicit$1(s);
                    }, $VevJvc ??= {"r":552963,"p":[{"n":"s","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794})) : null) : null) : null);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(42950750211)
            
            //--TRIMMABLE-BOUNDARY-START(25770881027)
            static /*CommunityCampaignBotContactsModel */ Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770881027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let __ca4__;
                /*string[]*/ let __ca5__;
                /*System.Collections.Generic.IEnumerable<string>*/ let __ca6__;
                return (() =>
                {
                    //new $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel()
                    const $t2 = $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Contacts = ((__ca4__ = s) !== null ? ((__ca5__ = $.$$.S.String.Split$6.call(__ca4__, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*\r*/ 13, /*\n*/ 10 ]))) !== null ? ((__ca6__ = $.$sl.SL.Enumerable.Where($.$$.S.String, __ca5__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(c);
                    }, $GtZKAe ??= {"r":262145,"p":[{"n":"c","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca6__, new ($.$$.S.Func$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.op_Implicit$1(s);
                    }, $hZuRPi ??= {"r":552963,"p":[{"n":"s","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794})) : null) : null) : null);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(25770881027)
            
            //--TRIMMABLE-BOUNDARY-START(51540684803)
            static /*bool */ TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out CommunityCampaignBotContactsModel*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540684803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca7__;
                /*string[]*/ let __ca8__;
                /*System.Collections.Generic.IEnumerable<string>*/ let __ca9__;
                result.$v = (() =>
                {
                    //new $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel()
                    const $t3 = $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Contacts = ((__ca7__ = s) !== null ? ((__ca8__ = $.$$.S.String.Split$6.call(__ca7__, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*\r*/ 13, /*\n*/ 10 ]))) !== null ? ((__ca9__ = $.$sl.SL.Enumerable.Where($.$$.S.String, __ca8__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return !$.$$.S.String.IsNullOrEmpty(c);
                    }, $sqNjsa ??= {"r":262145,"p":[{"n":"c","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca9__, new ($.$$.S.Func$$$($.$$.S.String, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel))().$ctor(this,  (/**/ s) =>
                    {
                        return $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.op_Implicit$1(s);
                    }, $jhXxjk ??= {"r":552963,"p":[{"n":"s","p":1310721}],"n":"","d":1077251,"h":0,"f":17825794})) : null) : null) : null);
                    return $i3;
                })();
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540684803)
            
            //--TRIMMABLE-BOUNDARY-START(4392222721)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel>.Parse(string, System.IFormatProvider?)
            static S$IParsable$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotContactsModel$Parse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392222721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel.Parse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392222721)
            
            //--TRIMMABLE-BOUNDARY-START(8687190017)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel>.TryParse(string?, System.IFormatProvider?, out LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel)
            static S$IParsable$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotContactsModel$TryParse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687190017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel.TryParse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687190017)
            
            //--TRIMMABLE-BOUNDARY-START(8591011843)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591011843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591011843)
            
            //--TRIMMABLE-BOUNDARY-START(8591011843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591011843)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Contacts = this.Contacts;
                return copy;
            }
            static $h = 1077251;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885979139),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475913731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360815619,
        "f": 83886081
      },
      "n": "Contacts",
      "d": 1077251,
      "h": 12885979139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885979139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245717507),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1077251,
      "h": 47245717507,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245717507),
//--TRIMMABLE-BOUNDARY-START(25770881027),
    {
      "r": 1077251,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        }
      ],
      "n": "Parse",
      "d": 1077251,
      "h": 25770881027,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770881027),
//--TRIMMABLE-BOUNDARY-START(51540684803),
    {
      "r": 262145,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        },
        {
          "n": "result",
          "p": 1077251,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1077251,
      "h": 51540684803,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540684803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591011843),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1077251,
      "h": 8591011843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591011843)
  ],
  "h": 1077251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IParsable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1077251)
        
        

        //--TRIMMABLE-BOUNDARY-START(4288515)
        $asm.$cls(`$bTOs.LCCCCS.IComunityCampaignBotRemoteService_Mocking`, ($self) => class IComunityCampaignBotRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299255811)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299255811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299255811)
            
            //--TRIMMABLE-BOUNDARY-START(8594223107)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings>> */ LCCCCS$IComunityCampaignBotRemoteService$GetGlobalSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594223107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$bTOs.LCCCCS.IComunityCampaignBotRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings).$type;
                    $i1.MethodName = "GetGlobalSettings";
                    return $i1;
                })();
                return this.InvokeAsync($.$bTOs.LCCCCS.IComunityCampaignBotRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8594223107)
            
            static $h = 4288515;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299255811),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4288515,
      "h": 4299255811,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299255811)
  ],
  "h": 4288515
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$bTOs.LCCCCS.IComunityCampaignBotRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Services.IComunityCampaignBotRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Services${separator}IComunityCampaignBotRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4288515)
        
        

        //--TRIMMABLE-BOUNDARY-START(2191363)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaignBotState`, ($self) => class CommunityCampaignBotState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Draft = 0;
            static Published = 1;
            static Paused = 2;
            static Running = 3;
            static Finished = 4;
            static Rejected = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2191363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Draft": 0n,
                    "Published": 1n,
                    "Paused": 2n,
                    "Running": 3n,
                    "Finished": 4n,
                    "Rejected": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297158659)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297158659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297158659)
            
            //--TRIMMABLE-BOUNDARY-START(4297158659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297158659)
            
            static $h = 2191363;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592125955),
    {
      "t": 2191363,
      "n": "Draft",
      "d": 2191363,
      "h": 8592125955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592125955),
//--TRIMMABLE-BOUNDARY-START(21477027843),
    {
      "t": 2191363,
      "n": "Published",
      "d": 2191363,
      "h": 21477027843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477027843),
//--TRIMMABLE-BOUNDARY-START(17182060547),
    {
      "t": 2191363,
      "n": "Paused",
      "d": 2191363,
      "h": 17182060547,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182060547),
//--TRIMMABLE-BOUNDARY-START(30066962435),
    {
      "t": 2191363,
      "n": "Running",
      "d": 2191363,
      "h": 30066962435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066962435),
//--TRIMMABLE-BOUNDARY-START(12887093251),
    {
      "t": 2191363,
      "n": "Finished",
      "d": 2191363,
      "h": 12887093251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887093251),
//--TRIMMABLE-BOUNDARY-START(25771995139),
    {
      "t": 2191363,
      "n": "Rejected",
      "d": 2191363,
      "h": 25771995139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771995139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297158659),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2191363,
      "h": 4297158659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297158659)
  ],
  "h": 2191363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2191363)
        
        

        //--TRIMMABLE-BOUNDARY-START(3698691)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaingBotJobState`, ($self) => class CommunityCampaingBotJobState extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static JobStateNone = 0;
            static JobStateGettingAudio = 1;
            static JobReceived = 2;
            static JobStarted = 3;
            static JobStateDone = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3698691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "JobStateNone": 0n,
                    "JobStateGettingAudio": 1n,
                    "JobReceived": 2n,
                    "JobStarted": 3n,
                    "JobStateDone": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298665987)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298665987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298665987)
            
            //--TRIMMABLE-BOUNDARY-START(4298665987)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298665987)
            
            static $h = 3698691;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25773502467),
    {
      "t": 3698691,
      "n": "JobStateNone",
      "d": 3698691,
      "h": 25773502467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773502467),
//--TRIMMABLE-BOUNDARY-START(21478535171),
    {
      "t": 3698691,
      "n": "JobStateGettingAudio",
      "d": 3698691,
      "h": 21478535171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478535171),
//--TRIMMABLE-BOUNDARY-START(8593633283),
    {
      "t": 3698691,
      "n": "JobReceived",
      "d": 3698691,
      "h": 8593633283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593633283),
//--TRIMMABLE-BOUNDARY-START(12888600579),
    {
      "t": 3698691,
      "n": "JobStarted",
      "d": 3698691,
      "h": 12888600579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888600579),
//--TRIMMABLE-BOUNDARY-START(17183567875),
    {
      "t": 3698691,
      "n": "JobStateDone",
      "d": 3698691,
      "h": 17183567875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183567875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298665987),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3698691,
      "h": 4298665987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298665987)
  ],
  "h": 3698691
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotJobState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotJobState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3698691)
        
        

        //--TRIMMABLE-BOUNDARY-START(3829763)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus`, ($self) => class CommunityCampaingBotPhoneCallStatus extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static CallStatusReady = 0;
            static CallStatusDialing = 1;
            static CallStatusRinging = 2;
            static CallStatusInProgress = 3;
            static CallStatusHeld = 4;
            static CallStatusIncoming = 5;
            static CallStatusWaiting = 6;
            static CallStatusDisconnect = 7;
            static CallStatusUnknown = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3829763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "CallStatusReady": 0n,
                    "CallStatusDialing": 1n,
                    "CallStatusRinging": 2n,
                    "CallStatusInProgress": 3n,
                    "CallStatusHeld": 4n,
                    "CallStatusIncoming": 5n,
                    "CallStatusWaiting": 6n,
                    "CallStatusDisconnect": 7n,
                    "CallStatusUnknown": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298797059)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298797059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298797059)
            
            //--TRIMMABLE-BOUNDARY-START(4298797059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298797059)
            
            static $h = 3829763;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30068600835),
    {
      "t": 3829763,
      "n": "CallStatusReady",
      "d": 3829763,
      "h": 30068600835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068600835),
//--TRIMMABLE-BOUNDARY-START(8593764355),
    {
      "t": 3829763,
      "n": "CallStatusDialing",
      "d": 3829763,
      "h": 8593764355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593764355),
//--TRIMMABLE-BOUNDARY-START(34363568131),
    {
      "t": 3829763,
      "n": "CallStatusRinging",
      "d": 3829763,
      "h": 34363568131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363568131),
//--TRIMMABLE-BOUNDARY-START(25773633539),
    {
      "t": 3829763,
      "n": "CallStatusInProgress",
      "d": 3829763,
      "h": 25773633539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773633539),
//--TRIMMABLE-BOUNDARY-START(17183698947),
    {
      "t": 3829763,
      "n": "CallStatusHeld",
      "d": 3829763,
      "h": 17183698947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183698947),
//--TRIMMABLE-BOUNDARY-START(21478666243),
    {
      "t": 3829763,
      "n": "CallStatusIncoming",
      "d": 3829763,
      "h": 21478666243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478666243),
//--TRIMMABLE-BOUNDARY-START(42953502723),
    {
      "t": 3829763,
      "n": "CallStatusWaiting",
      "d": 3829763,
      "h": 42953502723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953502723),
//--TRIMMABLE-BOUNDARY-START(12888731651),
    {
      "t": 3829763,
      "n": "CallStatusDisconnect",
      "d": 3829763,
      "h": 12888731651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888731651),
//--TRIMMABLE-BOUNDARY-START(38658535427),
    {
      "t": 3829763,
      "n": "CallStatusUnknown",
      "d": 3829763,
      "h": 38658535427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658535427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298797059),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3829763,
      "h": 4298797059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298797059)
  ],
  "h": 3829763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotPhoneCallStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotPhoneCallStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3829763)
        
        

        //--TRIMMABLE-BOUNDARY-START(2584579)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaignBotType`, ($self) => class CommunityCampaignBotType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Voice = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2584579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Voice": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297551875)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297551875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297551875)
            
            //--TRIMMABLE-BOUNDARY-START(4297551875)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297551875)
            
            static $h = 2584579;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592519171),
    {
      "t": 2584579,
      "n": "Voice",
      "d": 2584579,
      "h": 8592519171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592519171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297551875),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2584579,
      "h": 4297551875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297551875)
  ],
  "h": 2584579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2584579)
        
        

        //--TRIMMABLE-BOUNDARY-START(3567619)
        $asm.$str(`$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState`, ($self) => class CommunityCampaingBotAudioPlayerState extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static STOPPED = 0;
            static PLAYING = 1;
            static PAUSED = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3567619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "STOPPED": 0n,
                    "PLAYING": 1n,
                    "PAUSED": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298534915)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298534915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298534915)
            
            //--TRIMMABLE-BOUNDARY-START(4298534915)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298534915)
            
            static $h = 3567619;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183436803),
    {
      "t": 3567619,
      "n": "STOPPED",
      "d": 3567619,
      "h": 17183436803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183436803),
//--TRIMMABLE-BOUNDARY-START(12888469507),
    {
      "t": 3567619,
      "n": "PLAYING",
      "d": 3567619,
      "h": 12888469507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888469507),
//--TRIMMABLE-BOUNDARY-START(8593502211),
    {
      "t": 3567619,
      "n": "PAUSED",
      "d": 3567619,
      "h": 8593502211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593502211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298534915),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3567619,
      "h": 4298534915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298534915)
  ],
  "h": 3567619
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaingBotAudioPlayerState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaingBotAudioPlayerState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3567619)
        
        

        //--TRIMMABLE-BOUNDARY-START(3043331)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel`, ($self) => class CommunityCampaignBotVoiceLocaleModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60132585475)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(60132585475)
            
            //--TRIMMABLE-BOUNDARY-START(21477879811)
            /*string*/ Code = null;
            //--TRIMMABLE-BOUNDARY-END(21477879811)
            
            //--TRIMMABLE-BOUNDARY-START(90197356547)
            /*IEnumerable<CommunityCampaignBotVoiceModel>*/ Voices = null;
            //--TRIMMABLE-BOUNDARY-END(90197356547)
            
            //--TRIMMABLE-BOUNDARY-START(51542650883)
            /*ValueTask<IEnumerable<CommunityCampaignBotVoiceModel>?> */ GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542650883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), this.Voices);
            }
            //--TRIMMABLE-BOUNDARY-END(51542650883)
            
            //--TRIMMABLE-BOUNDARY-START(55837618179)
            /*ValueTask<IEnumerable<IChildrenHierachy>?> */ LCFCD$IChildrenHierachy$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837618179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy), $.$$.N.InterfaceVarianceStubHandler.Create(this.Voices, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)));
            }
            //--TRIMMABLE-BOUNDARY-END(55837618179)
            
            //--TRIMMABLE-BOUNDARY-START(4310993238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IChildrenHierachy<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel>.GetChildren()
            LCFCD$IChildrenHierachy$$$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4310993238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4310993238)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17182912515)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182912515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182912515)
            
            //--TRIMMABLE-BOUNDARY-START(17182912515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182912515)
            
            static $h = 3043331;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60132585475),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657748995,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312454659,
        "f": 83886081
      },
      "n": "Name",
      "d": 3043331,
      "h": 60132585475,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132585475),
//--TRIMMABLE-BOUNDARY-START(21477879811),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067814403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722520067,
        "f": 83886081
      },
      "n": "Code",
      "d": 3043331,
      "h": 21477879811,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477879811),
//--TRIMMABLE-BOUNDARY-START(90197356547),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247683587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902389251,
        "f": 83886081
      },
      "n": "Voices",
      "d": 3043331,
      "h": 90197356547,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90197356547)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51542650883),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)).$h,
      "n": "GetChildren",
      "d": 3043331,
      "h": 51542650883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542650883)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182912515),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3043331,
      "h": 17182912515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182912515)
  ],
  "h": 3043331
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IChildrenHierachy$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceLocaleModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3043331)
        
        

        //--TRIMMABLE-BOUNDARY-START(2715651)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel`, ($self) => class CommunityCampaignBotUserPreferenceModel extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4297682947)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297682947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297682947)
            
            //--TRIMMABLE-BOUNDARY-START(4297682947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297682947)
            
            static $h = 2715651;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297682947),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2715651,
      "h": 4297682947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297682947)
  ],
  "h": 2715651
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotUserPreferenceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2715651)
        
        

        //--TRIMMABLE-BOUNDARY-START(4419587)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings`, ($self) => class CommunityCampaignBotGlobalSettings extends $.$Iaui.LCFCMS.ComponentGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(103083634691)
            /*double*/ TokenPerCall = 0;
            //--TRIMMABLE-BOUNDARY-END(103083634691)
            
            //--TRIMMABLE-BOUNDARY-START(107378601987)
            /*double*/ TokenPerEngagementSeconds = 0;
            //--TRIMMABLE-BOUNDARY-END(107378601987)
            
            //--TRIMMABLE-BOUNDARY-START(98788667395)
            /*double*/ TextToSpeechCost = 0;
            //--TRIMMABLE-BOUNDARY-END(98788667395)
            
            //--TRIMMABLE-BOUNDARY-START(25774223363)
            /*IEnumerable<CampaignBotBackgroundMusic>?*/ BackgroundMusics = null;
            //--TRIMMABLE-BOUNDARY-END(25774223363)
            
            //--TRIMMABLE-BOUNDARY-START(21479256067)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479256067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21479256067)
            
            //--TRIMMABLE-BOUNDARY-START(21479256067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21479256067)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103083634691)
                this.TokenPerCall = 0;
                //--TRIMMABLE-BOUNDARY-END(103083634691)
                
                //--TRIMMABLE-BOUNDARY-START(107378601987)
                this.TokenPerEngagementSeconds = 0.75;
                //--TRIMMABLE-BOUNDARY-END(107378601987)
                
                //--TRIMMABLE-BOUNDARY-START(98788667395)
                this.TextToSpeechCost = 1000;
                //--TRIMMABLE-BOUNDARY-END(98788667395)
                
            }
            static $h = 4419587;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103083634691),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51544027139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85903765507,
        "f": 83886081
      },
      "n": "TokenPerCall",
      "d": 4419587,
      "h": 103083634691,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103083634691),
//--TRIMMABLE-BOUNDARY-START(107378601987),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133961731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94493700099,
        "f": 83886081
      },
      "n": "TokenPerEngagementSeconds",
      "d": 4419587,
      "h": 107378601987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107378601987),
//--TRIMMABLE-BOUNDARY-START(98788667395),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954092547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313830915,
        "f": 83886081
      },
      "n": "TextToSpeechCost",
      "d": 4419587,
      "h": 98788667395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98788667395),
//--TRIMMABLE-BOUNDARY-START(25774223363),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364157955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723896323,
        "f": 83886081
      },
      "n": "BackgroundMusics",
      "d": 4419587,
      "h": 25774223363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774223363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21479256067),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4419587,
      "h": 21479256067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21479256067)
  ],
  "h": 4419587
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4419587)
        
        

        //--TRIMMABLE-BOUNDARY-START(4943875)
        $asm.$cls(`$bTOs.LCCCCS$2.CommunityCampaignBotStates`, ($self) => class CommunityCampaignBotStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4299911171)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299911171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299911171)
            
            //--TRIMMABLE-BOUNDARY-START(4299911171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299911171)
            
            static $h = 4943875;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299911171),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4943875,
      "h": 4299911171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299911171)
  ],
  "h": 4943875
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}States${separator}CommunityCampaignBotStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4943875)
        
        

        //--TRIMMABLE-BOUNDARY-START(4681731)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotSettings`, ($self) => class CommunityCampaignBotSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299649027)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299649027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299649027)
            
            //--TRIMMABLE-BOUNDARY-START(4299649027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299649027)
            
            static $h = 4681731;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299649027),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4681731,
      "h": 4299649027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299649027)
  ],
  "h": 4681731
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4681731)
        
        

        //--TRIMMABLE-BOUNDARY-START(2453507)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor`, ($self) => class CommunityCampaignBotTargetingModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297420803)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297420803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, this, factory);
                    }, $Okcuqf ??= {"r":65537,"n":"","d":2453507,"h":0,"f":17825794}), 0, "CommunityCampaignBotTargetingModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotTargetingModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotTargetingModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297420803)
            
            //--TRIMMABLE-BOUNDARY-START(12887355395)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887355395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel.$type, $.$discardRef(), "Gender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCD.Gender), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Gender";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCD.Gender, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)).Gender);
                        }, $QesZsi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2453507,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Gender = value.AsNullableValue($.$fPer.LCFCD.Gender);
                        }, $nBwAAf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2453507,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AgeRange"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel.$type, $.$discardRef(), "AgeRange", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AgeRange")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "AgeRange";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)).AgeRange);
                        }, $QhZUyb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2453507,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.AgeRange = value.AsValue($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)));
                        }, $fonzWb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2453507,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Locations"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel.$type, $.$discardRef(), "Locations", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Locations")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Locations";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)).Locations);
                        }, $PlKVAh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2453507,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Locations = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation));
                        }, $XXzsxd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2453507,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887355395)
            
            //--TRIMMABLE-BOUNDARY-START(17182322691)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182322691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Gender = _target.Gender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCD.Gender)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCD.Gender), () => _Gender, ($v) => _Gender = $v, null, true)))
                    {
                        _target.Gender = _Gender;
                    }
                }
                {
                    /*var*/ let _AgeRange = _target.AgeRange;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AgeRange"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double))));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.ValueRange$$($.$$.S.Nullable$$($.$$.S.Double)), () => _AgeRange, ($v) => _AgeRange = $v, null, true)))
                    {
                        _target.AgeRange = $.$clone(_AgeRange);
                    }
                }
                {
                    /*var*/ let _Locations = _target.Locations;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Locations"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation), $.$fPer.LCFCDG.INamedLocation));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation), $.$fPer.LCFCDG.INamedLocation, property, $.$ref(() => _Locations, ($v) => _Locations = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation))))
                    {
                        _target.Locations = _Locations;
                        if (_Locations !== null)
                        {
                            let $en12 = _Locations.SCG$IEnumerable$$$GetEnumerator();
                            while ($en12.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en12.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$fPer.LCFCDG.INamedLocation)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation), $.$fPer.LCFCDG.INamedLocation, property, $.$ref(() => _Locations, ($v) => _Locations = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.INamedLocation)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182322691)
            
            //--TRIMMABLE-BOUNDARY-START(8592388099)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592388099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592388099)
            
            static $h = 2453507;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887355395),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2453507,
      "h": 12887355395,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887355395),
//--TRIMMABLE-BOUNDARY-START(17182322691),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2322435,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2453507,
      "h": 17182322691,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182322691),
//--TRIMMABLE-BOUNDARY-START(8592388099),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2322435,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2453507,
      "h": 8592388099,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592388099)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297420803),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2453507,
      "h": 4297420803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297420803)
  ],
  "h": 2453507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotTargetingModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotTargetingModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2453507)
        
        

        //--TRIMMABLE-BOUNDARY-START(684035)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor`, ($self) => class CommunityCampaignBotContactModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295651331)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295651331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, this, factory);
                    }, $fbltEc ??= {"r":65537,"n":"","d":684035,"h":0,"f":17825794}), 0, "CommunityCampaignBotContactModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotContactModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotContactModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295651331)
            
            //--TRIMMABLE-BOUNDARY-START(12885585923)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885585923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Number"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "Number", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Number")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Number";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).Number);
                        }, $QYjDDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Number = value.AsReference($.$$.S.String);
                        }, $CLNlDe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "Gender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCD.Gender), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Gender";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCD.Gender, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).Gender);
                        }, $yveagf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Gender = value.AsNullableValue($.$fPer.LCFCD.Gender);
                        }, $ohPybg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Age"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "Age", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Age")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Age";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).Age);
                        }, $Kuaftj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Age = value.AsNullableValue($.$$.S.Int32);
                        }, $EtPndb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Locale"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "Locale", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Locale")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Locale";
                        $i7.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).Locale);
                        }, $QzPCTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Locale = value.AsReference($.$$.S.String);
                        }, $BNpIQk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallProgress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "CallProgress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallProgress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCM.CallResultState), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "CallProgress";
                        $i9.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCM.CallResultState, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).CallProgress);
                        }, $xmuRfa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CallProgress = value.AsNullableValue($.$fPer.LCFCM.CallResultState);
                        }, $EDHqqi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallEngagementTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "CallEngagementTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallEngagementTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "CallEngagementTime";
                        $i11.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).CallEngagementTime);
                        }, $UHhYsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CallEngagementTime = value.AsNullableValue($.$$.S.Int32);
                        }, $VjNyPi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "CallCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "CallCost";
                        $i13.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Double, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).CallCost);
                        }, $rTjDEj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CallCost = value.AsNullableValue($.$$.S.Double);
                        }, $UivdJe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("QueueingTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "QueueingTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("QueueingTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "QueueingTime";
                        $i15.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).QueueingTime);
                        }, $aDwQjl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.QueueingTime = value.AsNullableValue($.$$.S.DateTime);
                        }, $naujqc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bot"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel.$type, $.$discardRef(), "Bot", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bot")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Bot";
                        $i17.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)).Bot);
                        }, $OpZbof ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":684035,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Bot = value.AsReference($.$$.S.String);
                        }, $JUwYPc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":684035,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885585923)
            
            //--TRIMMABLE-BOUNDARY-START(17180553219)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180553219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Number = _target.Number;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Number"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Number, ($v) => _Number = $v, $.$$.S.String)))
                    {
                        _target.Number = _Number;
                    }
                }
                {
                    /*var*/ let _Gender = _target.Gender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCD.Gender)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCD.Gender), () => _Gender, ($v) => _Gender = $v, null, true)))
                    {
                        _target.Gender = _Gender;
                    }
                }
                {
                    /*var*/ let _Age = _target.Age;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Age"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _Age, ($v) => _Age = $v, null, true)))
                    {
                        _target.Age = _Age;
                    }
                }
                {
                    /*var*/ let _Locale = _target.Locale;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Locale"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Locale, ($v) => _Locale = $v, $.$$.S.String)))
                    {
                        _target.Locale = _Locale;
                    }
                }
                {
                    /*var*/ let _CallProgress = _target.CallProgress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallProgress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCM.CallResultState)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCM.CallResultState), () => _CallProgress, ($v) => _CallProgress = $v, null, true)))
                    {
                        _target.CallProgress = _CallProgress;
                    }
                }
                {
                    /*var*/ let _CallEngagementTime = _target.CallEngagementTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallEngagementTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _CallEngagementTime, ($v) => _CallEngagementTime = $v, null, true)))
                    {
                        _target.CallEngagementTime = _CallEngagementTime;
                    }
                }
                {
                    /*var*/ let _CallCost = _target.CallCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Double), () => _CallCost, ($v) => _CallCost = $v, null, true)))
                    {
                        _target.CallCost = _CallCost;
                    }
                }
                {
                    /*var*/ let _QueueingTime = _target.QueueingTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("QueueingTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _QueueingTime, ($v) => _QueueingTime = $v, null, true)))
                    {
                        _target.QueueingTime = $.$clone(_QueueingTime);
                    }
                }
                {
                    /*var*/ let _Bot = _target.Bot;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bot"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Bot, ($v) => _Bot = $v, $.$$.S.String)))
                    {
                        _target.Bot = _Bot;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180553219)
            
            //--TRIMMABLE-BOUNDARY-START(8590618627)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590618627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotContactModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotContactModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590618627)
            
            static $h = 684035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885585923),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 684035,
      "h": 12885585923,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885585923),
//--TRIMMABLE-BOUNDARY-START(17180553219),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 552963,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 684035,
      "h": 17180553219,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180553219),
//--TRIMMABLE-BOUNDARY-START(8590618627),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 552963,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 684035,
      "h": 8590618627,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590618627)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295651331),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 684035,
      "h": 4295651331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295651331)
  ],
  "h": 684035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(684035)
        
        

        //--TRIMMABLE-BOUNDARY-START(3436547)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor`, ($self) => class CommunityCampaignBotVoiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298403843)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298403843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel, this, factory);
                    }, $DVsrtf ??= {"r":65537,"n":"","d":3436547,"h":0,"f":17825794}), 0, "CommunityCampaignBotVoiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotVoiceModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotVoiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298403843)
            
            //--TRIMMABLE-BOUNDARY-START(12888338435)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888338435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)).Name);
                        }, $gGofZg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3436547,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $drBRXf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3436547,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel.$type, $.$discardRef(), "Gender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.Gender, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Gender";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fPer.LCFCD.Gender, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)).Gender);
                        }, $ImOpBb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3436547,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Gender = value.AsEnumValue($.$fPer.LCFCD.Gender);
                        }, $gbMIQd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3436547,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("VoiceCode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel.$type, $.$discardRef(), "VoiceCode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("VoiceCode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "VoiceCode";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)).VoiceCode);
                        }, $ylthPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3436547,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.VoiceCode = value.AsReference($.$$.S.String);
                        }, $qguGij ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3436547,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888338435)
            
            //--TRIMMABLE-BOUNDARY-START(17183305731)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183305731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Gender = _target.Gender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.Gender));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.Gender, () => _Gender, ($v) => _Gender = $v, null, true)))
                    {
                        _target.Gender = _Gender;
                    }
                }
                {
                    /*var*/ let _VoiceCode = _target.VoiceCode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("VoiceCode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _VoiceCode, ($v) => _VoiceCode = $v, $.$$.S.String)))
                    {
                        _target.VoiceCode = _VoiceCode;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183305731)
            
            //--TRIMMABLE-BOUNDARY-START(8593371139)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593371139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593371139)
            
            static $h = 3436547;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888338435),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3436547,
      "h": 12888338435,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888338435),
//--TRIMMABLE-BOUNDARY-START(17183305731),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3305475,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3436547,
      "h": 17183305731,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183305731),
//--TRIMMABLE-BOUNDARY-START(8593371139),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3305475,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3436547,
      "h": 8593371139,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593371139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298403843),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3436547,
      "h": 4298403843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298403843)
  ],
  "h": 3436547
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3436547)
        
        

        //--TRIMMABLE-BOUNDARY-START(946179)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor`, ($self) => class CommunityCampaignBotContactResultModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295913475)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295913475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel, this, factory);
                    }, $dyJjbh ??= {"r":65537,"n":"","d":946179,"h":0,"f":17825794}), 0, "CommunityCampaignBotContactResultModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotContactResultModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotContactResultModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295913475)
            
            //--TRIMMABLE-BOUNDARY-START(12885848067)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885848067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Contact"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, $.$discardRef(), "Contact", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Contact")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Contact";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)).Contact);
                        }, $TXvuci ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946179,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Contact = value.AsValue($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel);
                        }, $eCPEkc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":946179,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallResult"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, $.$discardRef(), "CallResult", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallResult")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCM.CallResultState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CallResult";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fPer.LCFCM.CallResultState, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)).CallResult);
                        }, $BvkQfg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946179,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CallResult = value.AsEnumValue($.$fPer.LCFCM.CallResultState);
                        }, $sBiRhi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":946179,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallEngagementTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, $.$discardRef(), "CallEngagementTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallEngagementTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "CallEngagementTime";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)).CallEngagementTime);
                        }, $RCDKkj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946179,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CallEngagementTime = value.AsInt();
                        }, $WQmOne ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":946179,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel.$type, $.$discardRef(), "CallCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CallCost";
                        $i7.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)).CallCost);
                        }, $yAbyai ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":946179,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CallCost = value.AsDouble();
                        }, $WRnVRj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":946179,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.DataComplexPropertyModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885848067)
            
            //--TRIMMABLE-BOUNDARY-START(17180815363)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180815363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataComplexPropertyModel?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataComplexPropertyModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataComplexPropertyModel));
                {
                    /*var*/ let _Contact = _target.Contact;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Contact"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, () => _Contact, ($v) => _Contact = $v, null, true)))
                    {
                        _target.Contact = $.$clone(_Contact);
                    }
                }
                {
                    /*var*/ let _CallResult = _target.CallResult;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallResult"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCM.CallResultState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCM.CallResultState, () => _CallResult, ($v) => _CallResult = $v, null, true)))
                    {
                        _target.CallResult = _CallResult;
                    }
                }
                {
                    /*var*/ let _CallEngagementTime = _target.CallEngagementTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallEngagementTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CallEngagementTime, ($v) => _CallEngagementTime = $v, $.$$.S.Int32)))
                    {
                        _target.CallEngagementTime = _CallEngagementTime;
                    }
                }
                {
                    /*var*/ let _CallCost = _target.CallCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _CallCost, ($v) => _CallCost = $v, $.$$.S.Double)))
                    {
                        _target.CallCost = _CallCost;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180815363)
            
            //--TRIMMABLE-BOUNDARY-START(8590880771)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590880771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590880771)
            
            static $h = 946179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885848067),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 946179,
      "h": 12885848067,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885848067),
//--TRIMMABLE-BOUNDARY-START(17180815363),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 815107,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 946179,
      "h": 17180815363,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180815363),
//--TRIMMABLE-BOUNDARY-START(8590880771),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 815107,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 946179,
      "h": 8590880771,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590880771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295913475),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 946179,
      "h": 4295913475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295913475)
  ],
  "h": 946179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactResultModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactResultModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactResultModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(946179)
        
        

        //--TRIMMABLE-BOUNDARY-START(1470467)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor`, ($self) => class CommunityCampaignBotDeviceStateModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296437763)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296437763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, this, factory);
                    }, $pBEnyc ??= {"r":65537,"n":"","d":1470467,"h":0,"f":17825794}), 0, "CommunityCampaignBotDeviceStateModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotDeviceStateModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotDeviceStateModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296437763)
            
            //--TRIMMABLE-BOUNDARY-START(12886372355)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886372355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).Id);
                        }, $eCWYkh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.Id = value.AsReference($.$$.S.String);
                        }, $uPRCYd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallStatus"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "CallStatus", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallStatus")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CallStatus";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).CallStatus);
                        }, $FMajDh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.CallStatus = value.AsEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus);
                        }, $RXXkGi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PlayerState"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "PlayerState", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PlayerState")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PlayerState";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).PlayerState);
                        }, $fjtedg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.PlayerState = value.AsEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState);
                        }, $sGMPyk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentJob"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "CurrentJob", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentJob")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Guid, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CurrentJob";
                        $i7.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$$.S.Guid, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).CurrentJob);
                        }, $qFvyDh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.CurrentJob = value.AsValue($.$$.S.Guid);
                        }, $RUfGcc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentContacts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "CurrentContacts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentContacts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "CurrentContacts";
                        $i9.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).CurrentContacts);
                        }, $XUehZb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.CurrentContacts = value.AsReference($.$typeArray($.$$.S.String));
                        }, $duPUNd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CallIndex"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "CallIndex", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CallIndex")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "CallIndex";
                        $i11.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).CallIndex);
                        }, $MfbLCa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.CallIndex = value.AsInt();
                        }, $NPlork ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentContact"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "CurrentContact", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentContact")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "CurrentContact";
                        $i13.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).CurrentContact);
                        }, $kGdJPi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.CurrentContact = value.AsReference($.$$.S.String);
                        }, $ibHrAd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaingBotJobState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "State";
                        $i15.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotJobState, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).State);
                        }, $agJVoj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.State = value.AsEnumValue($.$bTOs.LCCCCM.CommunityCampaingBotJobState);
                        }, $makgLe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastCallSummary"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "LastCallSummary", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastCallSummary")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "LastCallSummary";
                        $i17.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).LastCallSummary);
                        }, $bvgYVe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.LastCallSummary = value.AsReference($.$bTOs.LCCCCM.CommunityCampaignBotContactModel);
                        }, $kzCCpb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastSeenOnline"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "LastSeenOnline", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastSeenOnline")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "LastSeenOnline";
                        $i19.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).LastSeenOnline);
                        }, $XjFQha ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.LastSeenOnline = value.AsNullableValue($.$$.S.DateTime);
                        }, $bDFDdf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AudioDownloadProgress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "AudioDownloadProgress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AudioDownloadProgress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "AudioDownloadProgress";
                        $i21.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).AudioDownloadProgress);
                        }, $qLwFMi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.AudioDownloadProgress = value.AsInt();
                        }, $URicTb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AudioDownloadSize"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel.$type, $.$discardRef(), "AudioDownloadSize", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AudioDownloadSize")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "AudioDownloadSize";
                        $i23.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel)).AudioDownloadSize);
                        }, $WLDIue ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1470467,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, target).$v.AudioDownloadSize = value.AsInt();
                        }, $xXimgb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1470467,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886372355)
            
            //--TRIMMABLE-BOUNDARY-START(17181339651)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181339651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _CallStatus = _target.CallStatus;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallStatus"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaingBotPhoneCallStatus, () => _CallStatus, ($v) => _CallStatus = $v, null, true)))
                    {
                        _target.CallStatus = _CallStatus;
                    }
                }
                {
                    /*var*/ let _PlayerState = _target.PlayerState;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PlayerState"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaingBotAudioPlayerState, () => _PlayerState, ($v) => _PlayerState = $v, null, true)))
                    {
                        _target.PlayerState = _PlayerState;
                    }
                }
                {
                    /*var*/ let _CurrentJob = _target.CurrentJob;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentJob"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Guid));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Guid, () => _CurrentJob, ($v) => _CurrentJob = $v, null, true)))
                    {
                        _target.CurrentJob = _CurrentJob;
                    }
                }
                {
                    /*var*/ let _CurrentContacts = _target.CurrentContacts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentContacts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _CurrentContacts, ($v) => _CurrentContacts = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.CurrentContacts = _CurrentContacts;
                        if (_CurrentContacts !== null)
                        {
                            let $i33 = 0;
                            let $arr33 = _CurrentContacts;
                            while ($i33 < $arr33.length)
                            {
                                let item = $arr33[$i33++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _CurrentContacts, ($v) => _CurrentContacts = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _CallIndex = _target.CallIndex;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CallIndex"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CallIndex, ($v) => _CallIndex = $v, $.$$.S.Int32)))
                    {
                        _target.CallIndex = _CallIndex;
                    }
                }
                {
                    /*var*/ let _CurrentContact = _target.CurrentContact;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentContact"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CurrentContact, ($v) => _CurrentContact = $v, $.$$.S.String)))
                    {
                        _target.CurrentContact = _CurrentContact;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaingBotJobState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaingBotJobState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _LastCallSummary = _target.LastCallSummary;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastCallSummary"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _LastCallSummary, ($v) => _LastCallSummary = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)))
                    {
                        _target.LastCallSummary = _LastCallSummary;
                    }
                }
                {
                    /*var*/ let _LastSeenOnline = _target.LastSeenOnline;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastSeenOnline"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _LastSeenOnline, ($v) => _LastSeenOnline = $v, null, true)))
                    {
                        _target.LastSeenOnline = $.$clone(_LastSeenOnline);
                    }
                }
                {
                    /*var*/ let _AudioDownloadProgress = _target.AudioDownloadProgress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AudioDownloadProgress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _AudioDownloadProgress, ($v) => _AudioDownloadProgress = $v, $.$$.S.Int32)))
                    {
                        _target.AudioDownloadProgress = _AudioDownloadProgress;
                    }
                }
                {
                    /*var*/ let _AudioDownloadSize = _target.AudioDownloadSize;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AudioDownloadSize"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _AudioDownloadSize, ($v) => _AudioDownloadSize = $v, $.$$.S.Int32)))
                    {
                        _target.AudioDownloadSize = _AudioDownloadSize;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181339651)
            
            //--TRIMMABLE-BOUNDARY-START(8591405059)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591405059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591405059)
            
            static $h = 1470467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886372355),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1470467,
      "h": 12886372355,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886372355),
//--TRIMMABLE-BOUNDARY-START(17181339651),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1339395,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1470467,
      "h": 17181339651,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181339651),
//--TRIMMABLE-BOUNDARY-START(8591405059),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1339395,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1470467,
      "h": 8591405059,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591405059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296437763),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1470467,
      "h": 4296437763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296437763)
  ],
  "h": 1470467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotDeviceStateModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotDeviceStateModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotDeviceStateModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1470467)
        
        

        //--TRIMMABLE-BOUNDARY-START(1208323)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor`, ($self) => class CommunityCampaignBotContactsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296175619)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296175619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, this, factory);
                    }, $UNWAwd ??= {"r":65537,"n":"","d":1208323,"h":0,"f":17825794}), 0, "CommunityCampaignBotContactsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotContactsModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotContactsModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296175619)
            
            //--TRIMMABLE-BOUNDARY-START(12886110211)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886110211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Contacts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel.$type, $.$discardRef(), "Contacts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Contacts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Contacts";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel)).Contacts);
                        }, $WPzdLh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1208323,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, target).$v.Contacts = value.AsReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                        }, $Cikvdh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1208323,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886110211)
            
            //--TRIMMABLE-BOUNDARY-START(17181077507)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181077507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Contacts = _target.Contacts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Contacts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, property, $.$ref(() => _Contacts, ($v) => _Contacts = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel))))
                    {
                        _target.Contacts = _Contacts;
                        if (_Contacts !== null)
                        {
                            let $en4 = _Contacts.SCG$IEnumerable$$$GetEnumerator();
                            while ($en4.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en4.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, property, $.$ref(() => _Contacts, ($v) => _Contacts = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181077507)
            
            //--TRIMMABLE-BOUNDARY-START(8591142915)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591142915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotContactsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591142915)
            
            static $h = 1208323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886110211),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1208323,
      "h": 12886110211,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886110211),
//--TRIMMABLE-BOUNDARY-START(17181077507),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1077251,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1208323,
      "h": 17181077507,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181077507),
//--TRIMMABLE-BOUNDARY-START(8591142915),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1077251,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1208323,
      "h": 8591142915,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591142915)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296175619),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1208323,
      "h": 4296175619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296175619)
  ],
  "h": 1208323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotContactsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotContactsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1208323)
        
        

        //--TRIMMABLE-BOUNDARY-START(3174403)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor`, ($self) => class CommunityCampaignBotVoiceLocaleModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298141699)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298141699);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel, this, factory);
                    }, $DIorHg ??= {"r":65537,"n":"","d":3174403,"h":0,"f":17825794}), 0, "CommunityCampaignBotVoiceLocaleModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotVoiceLocaleModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotVoiceLocaleModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298141699)
            
            //--TRIMMABLE-BOUNDARY-START(12888076291)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888076291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel)).Name);
                        }, $vCwpDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3174403,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $ejueyj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3174403,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Code"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel.$type, $.$discardRef(), "Code", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Code")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Code";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel)).Code);
                        }, $mKwSrb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3174403,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Code = value.AsReference($.$$.S.String);
                        }, $qHuTFf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3174403,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Voices"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel.$type, $.$discardRef(), "Voices", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Voices")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Voices";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel)).Voices);
                        }, $wKnHQg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3174403,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Voices = value.AsReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel));
                        }, $YDuuyb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3174403,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888076291)
            
            //--TRIMMABLE-BOUNDARY-START(17183043587)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183043587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Code = _target.Code;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Code"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Code, ($v) => _Code = $v, $.$$.S.String)))
                    {
                        _target.Code = _Code;
                    }
                }
                {
                    /*var*/ let _Voices = _target.Voices;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Voices"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel, property, $.$ref(() => _Voices, ($v) => _Voices = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel))))
                    {
                        _target.Voices = _Voices;
                        if (_Voices !== null)
                        {
                            let $en10 = _Voices.SCG$IEnumerable$$$GetEnumerator();
                            while ($en10.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en10.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel), $.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel, property, $.$ref(() => _Voices, ($v) => _Voices = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183043587)
            
            //--TRIMMABLE-BOUNDARY-START(8593108995)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593108995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593108995)
            
            static $h = 3174403;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888076291),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3174403,
      "h": 12888076291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888076291),
//--TRIMMABLE-BOUNDARY-START(17183043587),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3043331,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3174403,
      "h": 17183043587,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183043587),
//--TRIMMABLE-BOUNDARY-START(8593108995),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3043331,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3174403,
      "h": 8593108995,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593108995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298141699),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3174403,
      "h": 4298141699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298141699)
  ],
  "h": 3174403
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotVoiceLocaleModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotVoiceLocaleModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotVoiceLocaleModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3174403)
        
        

        //--TRIMMABLE-BOUNDARY-START(2846723)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptor`, ($self) => class CommunityCampaignBotUserPreferenceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297814019)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297814019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel, this, factory);
                    }, $LFEpTd ??= {"r":65537,"n":"","d":2846723,"h":0,"f":17825794}), 0, "CommunityCampaignBotUserPreferenceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotUserPreferenceModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotUserPreferenceModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297814019)
            
            //--TRIMMABLE-BOUNDARY-START(12887748611)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887748611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887748611)
            
            //--TRIMMABLE-BOUNDARY-START(17182715907)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182715907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference?*/ let targetBase = _target;
                $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$yleQ.LCFCA.ApplicationBaseUserPreference));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182715907)
            
            //--TRIMMABLE-BOUNDARY-START(8592781315)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592781315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592781315)
            
            static $h = 2846723;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887748611),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2846723,
      "h": 12887748611,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887748611),
//--TRIMMABLE-BOUNDARY-START(17182715907),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2715651,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2846723,
      "h": 17182715907,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182715907),
//--TRIMMABLE-BOUNDARY-START(8592781315),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2715651,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2846723,
      "h": 8592781315,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592781315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297814019),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2846723,
      "h": 4297814019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297814019)
  ],
  "h": 2846723
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotUserPreferenceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotUserPreferenceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotUserPreferenceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2846723)
        
        

        //--TRIMMABLE-BOUNDARY-START(4026371)
        $asm.$cls(`$bTOs.LCCCCS.CommunityCampaignBotWalletProvider`, ($self) => class CommunityCampaignBotWalletProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124558077955)
            /*string? */ get Title()
            {
                return "CpBot Coin";
            }
            //--TRIMMABLE-BOUNDARY-END(124558077955)
            
            //--TRIMMABLE-BOUNDARY-START(34363764739)
            /*string? */ get Description()
            {
                return "A wallet token for storing CampaingBot Credits";
            }
            //--TRIMMABLE-BOUNDARY-END(34363764739)
            
            //--TRIMMABLE-BOUNDARY-START(111673176067)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-microphone"/*MaterialDesignIconNames.Microphone*/);
            }
            //--TRIMMABLE-BOUNDARY-END(111673176067)
            
            //--TRIMMABLE-BOUNDARY-START(115968143363)
            /*string? */ get Name()
            {
                return "CpBot";
            }
            //--TRIMMABLE-BOUNDARY-END(115968143363)
            
            //--TRIMMABLE-BOUNDARY-START(120263110659)
            /*ThemePack*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(120263110659)
            
            //--TRIMMABLE-BOUNDARY-START(38658732035)
            /*WalletFeatures */ get Features()
            {
                return 1/*WalletFeatures.Purchasable*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38658732035)
            
            //--TRIMMABLE-BOUNDARY-START(30068797443)
            /*string */ get CurrencyUnit()
            {
                return `${$.$strNN("\u20A6"/*Money.NairaSymbol*/)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(30068797443)
            
            //--TRIMMABLE-BOUNDARY-START(17183895555)
            /*IEnumerable<WalletTokenDescriptor> */ get CoinDescriptors()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OJJQ.LCFCW.WalletTokenDescriptor), [(() =>
                {
                    //new $.$OJJQ.LCFCW.WalletTokenDescriptor()
                    const $t1 = $.$OJJQ.LCFCW.WalletTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Name = "CpBot";
                    return $i1;
                })()], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17183895555)
            
            //--TRIMMABLE-BOUNDARY-START(12888928259)
            /*bool */ CanPayForService(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888928259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return serviceName === "CampaignBot/TTS";
            }
            //--TRIMMABLE-BOUNDARY-END(12888928259)
            
            //--TRIMMABLE-BOUNDARY-START(25773830147)
            /*Money */ Convert$1(/*WalletToken*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773830147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fPer.LCFCDM.Money().$ctor$3(input.Amount, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25773830147)
            
            //--TRIMMABLE-BOUNDARY-START(21478862851)
            /*WalletToken */ Convert(/*Money*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478862851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t2 = $.$OJJQ.LCFCW.WalletToken;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Amount = input.Value;
                    $i2.Descriptor = $.$sl.SL.Enumerable.First$1($.$OJJQ.LCFCW.WalletTokenDescriptor, this.CoinDescriptors);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(21478862851)
            
            //--TRIMMABLE-BOUNDARY-START(34360374477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CurrencyUnit.get
            get LCFCW$IWalletIssuer$CurrencyUnit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrencyUnit;
            }
            //--TRIMMABLE-BOUNDARY-END(34360374477)
            
            //--TRIMMABLE-BOUNDARY-START(25770439885)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CoinDescriptors.get
            get LCFCW$IWalletIssuer$CoinDescriptors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(25770439885)
            
            //--TRIMMABLE-BOUNDARY-START(4295603405)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CanPayForService(string?)
            LCFCW$IWalletIssuer$CanPayForService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295603405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayForService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295603405)
            
            //--TRIMMABLE-BOUNDARY-START(42950309069)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.Features.get
            get LCFCW$IWalletIssuer$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180505293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(42950309069)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Wallet.WalletToken, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>.Convert(LivingThing.Core.Frameworks.Common.Wallet.WalletToken, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Wallet.WalletToken>.Convert(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(8593960963)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593960963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593960963)
            
            //--TRIMMABLE-BOUNDARY-START(8593960963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593960963)
            
            static $h = 4026371;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124558077955),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107378208771,
        "f": 50331649
      },
      "n": "Title",
      "d": 4026371,
      "h": 124558077955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124558077955),
//--TRIMMABLE-BOUNDARY-START(34363764739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428535811,
        "f": 50331649
      },
      "n": "Description",
      "d": 4026371,
      "h": 34363764739,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363764739),
//--TRIMMABLE-BOUNDARY-START(111673176067),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608404995,
        "f": 50331649
      },
      "n": "Icon",
      "d": 4026371,
      "h": 111673176067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111673176067),
//--TRIMMABLE-BOUNDARY-START(115968143363),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198339587,
        "f": 50331649
      },
      "n": "Name",
      "d": 4026371,
      "h": 115968143363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115968143363),
//--TRIMMABLE-BOUNDARY-START(120263110659),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98788274179,
        "f": 50331649
      },
      "n": "Theme",
      "d": 4026371,
      "h": 120263110659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120263110659),
//--TRIMMABLE-BOUNDARY-START(38658732035),
    {
      "p": 2667725,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018470403,
        "f": 50331649
      },
      "n": "Features",
      "d": 4026371,
      "h": 38658732035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658732035),
//--TRIMMABLE-BOUNDARY-START(30068797443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838601219,
        "f": 50331649
      },
      "n": "CurrencyUnit",
      "d": 4026371,
      "h": 30068797443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068797443),
//--TRIMMABLE-BOUNDARY-START(17183895555),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248666627,
        "f": 50331649
      },
      "n": "CoinDescriptors",
      "d": 4026371,
      "h": 17183895555,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183895555)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888928259),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayForService",
      "d": 4026371,
      "h": 12888928259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888928259),
//--TRIMMABLE-BOUNDARY-START(25773830147),
    {
      "r": 27822422,
      "p": [
        {
          "n": "input",
          "p": 3192013
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 4026371,
      "h": 25773830147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773830147),
//--TRIMMABLE-BOUNDARY-START(21478862851),
    {
      "r": 3192013,
      "p": [
        {
          "n": "input",
          "p": 27822422
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "d": 4026371,
      "h": 21478862851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478862851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593960963),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4026371,
      "h": 8593960963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593960963)
  ],
  "h": 4026371
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletIssuer, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataConverter$$$($.$OJJQ.LCFCW.WalletToken, $.$fPer.LCFCDM.Money), $.$fPer.LCFCD.IDataConverter$$$($.$fPer.LCFCDM.Money, $.$OJJQ.LCFCW.WalletToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Services.CommunityCampaignBotWalletProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Services${separator}CommunityCampaignBotWalletProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4026371)
        
        

        //--TRIMMABLE-BOUNDARY-START(4550659)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor`, ($self) => class CommunityCampaignBotGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299517955)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299517955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor.GenerateProperties($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings, this, factory);
                    }, $QEMCdh ??= {"r":65537,"n":"","d":4550659,"h":0,"f":17825794}), 0, "CommunityCampaignBotGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Settings_CommunityCampaignBotGlobalSettings_LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettingsTypeDescriptorBuilder.g.cs", "CommunityCampaignBotGlobalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299517955)
            
            //--TRIMMABLE-BOUNDARY-START(12889452547)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889452547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TokenPerCall"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, $.$discardRef(), "TokenPerCall", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TokenPerCall")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "TokenPerCall";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).TokenPerCall);
                        }, $MZLYWj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4550659,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TokenPerCall = value.AsDouble();
                        }, $EHPiMg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4550659,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TokenPerEngagementSeconds"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, $.$discardRef(), "TokenPerEngagementSeconds", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TokenPerEngagementSeconds")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TokenPerEngagementSeconds";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).TokenPerEngagementSeconds);
                        }, $vucxUf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4550659,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TokenPerEngagementSeconds = value.AsDouble();
                        }, $whrhXe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4550659,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TextToSpeechCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, $.$discardRef(), "TextToSpeechCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TextToSpeechCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "TextToSpeechCost";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).TextToSpeechCost);
                        }, $gnIvcf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4550659,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.TextToSpeechCost = value.AsDouble();
                        }, $DFBBZb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4550659,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BackgroundMusics"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings.$type, $.$discardRef(), "BackgroundMusics", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BackgroundMusics")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "BackgroundMusics";
                        $i7.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic), ($.$cast(target, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)).BackgroundMusics);
                        }, $vvBnta ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4550659,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BackgroundMusics = value.AsReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic));
                        }, $wvxlZb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4550659,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889452547)
            
            //--TRIMMABLE-BOUNDARY-START(17184419843)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184419843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentGlobalSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentGlobalSettings));
                {
                    /*var*/ let _TokenPerCall = _target.TokenPerCall;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TokenPerCall"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TokenPerCall, ($v) => _TokenPerCall = $v, $.$$.S.Double)))
                    {
                        _target.TokenPerCall = _TokenPerCall;
                    }
                }
                {
                    /*var*/ let _TokenPerEngagementSeconds = _target.TokenPerEngagementSeconds;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TokenPerEngagementSeconds"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TokenPerEngagementSeconds, ($v) => _TokenPerEngagementSeconds = $v, $.$$.S.Double)))
                    {
                        _target.TokenPerEngagementSeconds = _TokenPerEngagementSeconds;
                    }
                }
                {
                    /*var*/ let _TextToSpeechCost = _target.TextToSpeechCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TextToSpeechCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TextToSpeechCost, ($v) => _TextToSpeechCost = $v, $.$$.S.Double)))
                    {
                        _target.TextToSpeechCost = _TextToSpeechCost;
                    }
                }
                {
                    /*var*/ let _BackgroundMusics = _target.BackgroundMusics;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BackgroundMusics"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic), $.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic), $.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, property, $.$ref(() => _BackgroundMusics, ($v) => _BackgroundMusics = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic))))
                    {
                        _target.BackgroundMusics = _BackgroundMusics;
                        if (_BackgroundMusics !== null)
                        {
                            let $en15 = _BackgroundMusics.SCG$IEnumerable$$$GetEnumerator();
                            while ($en15.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en15.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic), $.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic, property, $.$ref(() => _BackgroundMusics, ($v) => _BackgroundMusics = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCS$1.CampaignBotBackgroundMusic)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184419843)
            
            //--TRIMMABLE-BOUNDARY-START(8594485251)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594485251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594485251)
            
            static $h = 4550659;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889452547),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4550659,
      "h": 12889452547,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889452547),
//--TRIMMABLE-BOUNDARY-START(17184419843),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4419587,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4550659,
      "h": 17184419843,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184419843),
//--TRIMMABLE-BOUNDARY-START(8594485251),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4419587,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4550659,
      "h": 8594485251,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594485251)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299517955),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4550659,
      "h": 4299517955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299517955)
  ],
  "h": 4550659
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4550659)
        
        

        //--TRIMMABLE-BOUNDARY-START(4812803)
        $asm.$cls(`$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptor`, ($self) => class CommunityCampaignBotSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299780099)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299780099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptor.GenerateProperties($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, this, factory);
                    }, $aSPykj ??= {"r":65537,"n":"","d":4812803,"h":0,"f":17825794}), 0, "CommunityCampaignBotSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Settings_CommunityCampaignBotSettings_LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettingsTypeDescriptorBuilder.g.cs", "CommunityCampaignBotSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299780099)
            
            //--TRIMMABLE-BOUNDARY-START(12889714691)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889714691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889714691)
            
            //--TRIMMABLE-BOUNDARY-START(17184681987)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184681987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184681987)
            
            //--TRIMMABLE-BOUNDARY-START(8594747395)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594747395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCS$1.CommunityCampaignBotSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$1.CommunityCampaignBotSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594747395)
            
            static $h = 4812803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889714691),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4812803,
      "h": 12889714691,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889714691),
//--TRIMMABLE-BOUNDARY-START(17184681987),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4681731,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4812803,
      "h": 17184681987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184681987),
//--TRIMMABLE-BOUNDARY-START(8594747395),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4681731,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4812803,
      "h": 8594747395,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594747395)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299780099),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4812803,
      "h": 4299780099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299780099)
  ],
  "h": 4812803
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Settings${separator}CommunityCampaignBotSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4812803)
        
        

        //--TRIMMABLE-BOUNDARY-START(5074947)
        $asm.$cls(`$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptor`, ($self) => class CommunityCampaignBotStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$2.CommunityCampaignBotStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4300042243)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300042243);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptor.GenerateProperties($.$bTOs.LCCCCS$2.CommunityCampaignBotStates, this, factory);
                    }, $OXHvmd ??= {"r":65537,"n":"","d":5074947,"h":0,"f":17825794}), 0, "CommunityCampaignBotStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\States_CommunityCampaignBotStates_LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStatesTypeDescriptorBuilder.g.cs", "CommunityCampaignBotStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300042243)
            
            //--TRIMMABLE-BOUNDARY-START(12889976835)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889976835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889976835)
            
            //--TRIMMABLE-BOUNDARY-START(17184944131)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184944131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184944131)
            
            //--TRIMMABLE-BOUNDARY-START(8595009539)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595009539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCS$2.CommunityCampaignBotStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCS$2.CommunityCampaignBotStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595009539)
            
            static $h = 5074947;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCS$2.CommunityCampaignBotStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889976835),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5074947,
      "h": 12889976835,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889976835),
//--TRIMMABLE-BOUNDARY-START(17184944131),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4943875,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5074947,
      "h": 17184944131,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184944131),
//--TRIMMABLE-BOUNDARY-START(8595009539),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4943875,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5074947,
      "h": 8595009539,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595009539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300042243),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5074947,
      "h": 4300042243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300042243)
  ],
  "h": 5074947
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCS$2.CommunityCampaignBotStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}States${separator}CommunityCampaignBotStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5074947)
        
        

        $asm.$typeProxy("$bTOs.LCCCCM.CommunityCampaignBotPostModel", "$bTOs.LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel");
        //--TRIMMABLE-BOUNDARY-START(290819)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotCategoryModel`, ($self) => class CommunityCampaignBotCategoryModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($self, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(42949963779)
            /*PostTypes */ get Type()
            {
                return 8449/*PostTypes.CampaignBotCategory*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42949963779)
            
            //--TRIMMABLE-BOUNDARY-START(25770094595)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770094595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770094595)
            
            //--TRIMMABLE-BOUNDARY-START(21475127299)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475127299);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475127299)
            
            //--TRIMMABLE-BOUNDARY-START(17180160003)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180160003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180160003)
            
            //--TRIMMABLE-BOUNDARY-START(38654996483)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654996483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654996483)
            
            //--TRIMMABLE-BOUNDARY-START(34360029187)
            /*bool */ ShouldEditPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360029187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360029187)
            
            //--TRIMMABLE-BOUNDARY-START(30065061891)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065061891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065061891)
            
            //--TRIMMABLE-BOUNDARY-START(4295258115)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295258115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295258115)
            
            //--TRIMMABLE-BOUNDARY-START(4295258115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295258115)
            
            static $h = 290819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949963779),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885192707,
        "f": 50364417
      },
      "n": "Type",
      "d": 290819,
      "h": 42949963779,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42949963779)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770094595),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 290819,
      "h": 25770094595,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770094595),
//--TRIMMABLE-BOUNDARY-START(21475127299),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 290819,
      "h": 21475127299,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475127299),
//--TRIMMABLE-BOUNDARY-START(17180160003),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 290819,
      "h": 17180160003,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180160003),
//--TRIMMABLE-BOUNDARY-START(38654996483),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 290819,
      "h": 38654996483,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654996483),
//--TRIMMABLE-BOUNDARY-START(34360029187),
    {
      "r": 262145,
      "n": "ShouldEditPost",
      "d": 290819,
      "h": 34360029187,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360029187),
//--TRIMMABLE-BOUNDARY-START(30065061891),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 290819,
      "h": 30065061891,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065061891)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295258115),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 290819,
      "h": 4295258115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295258115)
  ],
  "h": 290819
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(290819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1863683)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotPostModel`, ($self) => class CommunityCampaignBotPostModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(438088527875)
            /*PostTypes */ get Type()
            {
                return 8450/*PostTypes.CampaignBotPost*/;
            }
            //--TRIMMABLE-BOUNDARY-END(438088527875)
            
            //--TRIMMABLE-BOUNDARY-START(266289836035)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266289836035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289836035)
            
            //--TRIMMABLE-BOUNDARY-START(261994868739)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994868739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994868739)
            
            //--TRIMMABLE-BOUNDARY-START(257699901443)
            /*bool */ RequiresIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257699901443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699901443)
            
            //--TRIMMABLE-BOUNDARY-START(240520032259)
            /*string */ get Link()
            {
                return $.$LCOv.LCFCP.PostUtility.GetLink$2(this, null, "CampaignBot/Post", null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(240520032259)
            
            //--TRIMMABLE-BOUNDARY-START(8591798275)
            /*CommunityCampaignBotType */ get BotType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771667459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$bTOs.LCCCCM.CommunityCampaignBotType, 0, "BotType", null);
            }
            /*CommunityCampaignBotType */ set BotType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879770627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$bTOs.LCCCCM.CommunityCampaignBotType, value, "BotType");
            }
            //--TRIMMABLE-BOUNDARY-END(8591798275)
            
            //--TRIMMABLE-BOUNDARY-START(403728789507)
            /*CommunityCampaignBotTargetingModel? */ get Targeting()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620686339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, null, "Targeting", null);
            }
            /*CommunityCampaignBotTargetingModel? */ set Targeting(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360779116547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, value, "Targeting");
            }
            //--TRIMMABLE-BOUNDARY-END(403728789507)
            
            //--TRIMMABLE-BOUNDARY-START(442383495171)
            /*double */ get Wallet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930097667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Double, 0, "Wallet", null);
            }
            /*double */ set Wallet(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369369051139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Double, value, "Wallet");
            }
            //--TRIMMABLE-BOUNDARY-END(442383495171)
            
            //--TRIMMABLE-BOUNDARY-START(253404934147)
            /*string? */ get MediaUrl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901209603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "MediaUrl", null);
            }
            /*string? */ set MediaUrl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649574403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "MediaUrl");
            }
            //--TRIMMABLE-BOUNDARY-END(253404934147)
            
            //--TRIMMABLE-BOUNDARY-START(382253953027)
            /*string? */ get SpeechPaymentReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671013379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "SpeechPaymentReference", null);
            }
            /*string? */ set SpeechPaymentReference(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419378179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "SpeechPaymentReference");
            }
            //--TRIMMABLE-BOUNDARY-END(382253953027)
            
            //--TRIMMABLE-BOUNDARY-START(386548920323)
            /*string? */ get SpeechText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260947971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "SpeechText", null);
            }
            /*string? */ set SpeechText(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009312771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "SpeechText");
            }
            //--TRIMMABLE-BOUNDARY-END(386548920323)
            
            //--TRIMMABLE-BOUNDARY-START(373664018435)
            /*string? */ get SpeechBgMusic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491144195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "SpeechBgMusic", null);
            }
            /*string? */ set SpeechBgMusic(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239508995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "SpeechBgMusic");
            }
            //--TRIMMABLE-BOUNDARY-END(373664018435)
            
            //--TRIMMABLE-BOUNDARY-START(377958985731)
            /*byte[]? */ get SpeechBinary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081078787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeArray($.$$.S.Byte), null, "SpeechBinary", null);
            }
            /*byte[]? */ set SpeechBinary(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829443587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeArray($.$$.S.Byte), value, "SpeechBinary");
            }
            //--TRIMMABLE-BOUNDARY-END(377958985731)
            
            //--TRIMMABLE-BOUNDARY-START(249109966851)
            /*int? */ get MediaPeriod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311275011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$typeNullable($.$$.S.Int32), null, "MediaPeriod", null);
            }
            /*int? */ set MediaPeriod(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059639811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$typeNullable($.$$.S.Int32), value, "MediaPeriod");
            }
            //--TRIMMABLE-BOUNDARY-END(249109966851)
            
            //--TRIMMABLE-BOUNDARY-START(395138854915)
            /*CommunityCampaignBotState */ get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440817155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$bTOs.LCCCCM.CommunityCampaignBotState, 0, "State", null);
            }
            /*CommunityCampaignBotState */ set State(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599247363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$bTOs.LCCCCM.CommunityCampaignBotState, value, "State");
            }
            //--TRIMMABLE-BOUNDARY-END(395138854915)
            
            //--TRIMMABLE-BOUNDARY-START(399433822211)
            /*string? */ get StateReason()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030751747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "StateReason", null);
            }
            /*string? */ set StateReason(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189181955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "StateReason");
            }
            //--TRIMMABLE-BOUNDARY-END(399433822211)
            
            //--TRIMMABLE-BOUNDARY-START(12886765571)
            /*IEnumerable<CommunityCampaignBotContactModel>? */ get Contacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361602051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, "Contacts");
            }
            /*IEnumerable<CommunityCampaignBotContactModel>? */ set Contacts(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469705219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, value, "Contacts");
            }
            //--TRIMMABLE-BOUNDARY-END(12886765571)
            
            //--TRIMMABLE-BOUNDARY-START(408023756803)
            /*int */ get TotalContacts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210620931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca1__;
                return ((__ca1__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count$1($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca1__) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(408023756803)
            
            //--TRIMMABLE-BOUNDARY-START(420908658691)
            /*int */ get TotalPending()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980424707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca2__;
                return ((__ca2__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca2__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.CallProgress === null || c.CallProgress === 0/*CallResultState.Pending*/;
                }, $olpfYk ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(420908658691)
            
            //--TRIMMABLE-BOUNDARY-START(236225064963)
            /*bool */ get HasGenderContactData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541471235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca3__;
                return ((__ca3__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Any($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca3__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Gender !== 0/*Gender.None*/;
                }, $zbHiph ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(236225064963)
            
            //--TRIMMABLE-BOUNDARY-START(244814999555)
            /*int */ get Males()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721340419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca4__;
                return ((__ca4__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca4__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Gender === 1/*Gender.Male*/;
                }, $vrVzza ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(244814999555)
            
            //--TRIMMABLE-BOUNDARY-START(17181732867)
            /*int */ get Females()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951536643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca5__;
                return ((__ca5__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca5__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Gender === 2/*Gender.Female*/;
                }, $KsVfIk ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17181732867)
            
            //--TRIMMABLE-BOUNDARY-START(412318724099)
            /*int */ get TotalDialed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800555523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca6__;
                return ((__ca6__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca6__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.CallProgress !== null && c.CallProgress !== 0/*CallResultState.Pending*/;
                }, $pSGpXd ??= {"r":262145,"p":[{"n":"c","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(412318724099)
            
            //--TRIMMABLE-BOUNDARY-START(425203625987)
            /*int */ get TotalPicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570359299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca7__;
                return ((__ca7__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca7__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/**/ r) =>
                {
                    return r.CallProgress === 3/*CallResultState.Completed*/;
                }, $FNhAak ??= {"r":262145,"p":[{"n":"r","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(425203625987)
            
            //--TRIMMABLE-BOUNDARY-START(429498593283)
            /*int */ get TotalRejected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160293891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca8__;
                return ((__ca8__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca8__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    return r.CallProgress === 6/*CallResultState.NoAnswer*/;
                }, $krggzk ??= {"r":262145,"p":[{"n":"r","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(429498593283)
            
            //--TRIMMABLE-BOUNDARY-START(433793560579)
            /*int */ get TotalUnreachable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750228483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca9__;
                return ((__ca9__ = this.Contacts) !== null ? $.$sl.SL.Enumerable.Count($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca9__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    return r.CallProgress === 7/*CallResultState.NotReachable*/;
                }, $xGeACk ??= {"r":262145,"p":[{"n":"r","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(433793560579)
            
            //--TRIMMABLE-BOUNDARY-START(416613691395)
            /*int */ get TotalEngagements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390490115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca10__;
                return ((__ca10__ = this.Contacts) !== null ? ($.$sl.SL.Enumerable.Sum$21($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca10__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.CallEngagementTime;
                }, $rwkGTg ??= {"r":$.$typeNullable($.$$.S.Int32).$h,"p":[{"n":"s","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) ?? 0) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(416613691395)
            
            //--TRIMMABLE-BOUNDARY-START(390843887619)
            /*double */ get Spent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850882563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotContactModel>?*/ let __ca11__;
                return (((__ca11__ = this.Contacts) !== null ? ($.$sl.SL.Enumerable.Sum$20($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, __ca11__, new ($.$$.S.Func$$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel, $.$$.S.Nullable$$($.$$.S.Double)))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.CallCost;
                }, $YgkfHd ??= {"r":$.$typeNullable($.$$.S.Double).$h,"p":[{"n":"s","p":552963}],"n":"","d":1863683,"h":0,"f":17825794})) ?? 0) : 0));
            }
            //--TRIMMABLE-BOUNDARY-END(390843887619)
            
            //--TRIMMABLE-BOUNDARY-START(4296830979)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296830979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296830979)
            
            //--TRIMMABLE-BOUNDARY-START(4296830979)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296830979)
            
            static $h = 1863683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(438088527875),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223340163075,
        "f": 50364417
      },
      "n": "Type",
      "d": 1863683,
      "h": 438088527875,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(438088527875),
//--TRIMMABLE-BOUNDARY-START(240520032259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131405827,
        "f": 50364417
      },
      "n": "Link",
      "d": 1863683,
      "h": 240520032259,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240520032259),
//--TRIMMABLE-BOUNDARY-START(8591798275),
    {
      "p": 2584579,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771667459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879770627,
        "f": 83886081
      },
      "n": "BotType",
      "d": 1863683,
      "h": 8591798275,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16776190,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591798275),
//--TRIMMABLE-BOUNDARY-START(403728789507),
    {
      "p": 2322435,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620686339,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360779116547,
        "f": 83886081
      },
      "n": "Targeting",
      "d": 1863683,
      "h": 403728789507,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1025,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777214,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 576460752303423488,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403728789507),
//--TRIMMABLE-BOUNDARY-START(442383495171),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231930097667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369369051139,
        "f": 83886081
      },
      "n": "Wallet",
      "d": 1863683,
      "h": 442383495171,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1026,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(442383495171),
//--TRIMMABLE-BOUNDARY-START(253404934147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901209603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649574403,
        "f": 83886081
      },
      "n": "MediaUrl",
      "d": 1863683,
      "h": 253404934147,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404934147),
//--TRIMMABLE-BOUNDARY-START(382253953027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671013379,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326419378179,
        "f": 83886081
      },
      "n": "SpeechPaymentReference",
      "d": 1863683,
      "h": 382253953027,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(382253953027),
//--TRIMMABLE-BOUNDARY-START(386548920323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260947971,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335009312771,
        "f": 83886081
      },
      "n": "SpeechText",
      "d": 1863683,
      "h": 386548920323,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(386548920323),
//--TRIMMABLE-BOUNDARY-START(373664018435),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491144195,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309239508995,
        "f": 83886081
      },
      "n": "SpeechBgMusic",
      "d": 1863683,
      "h": 373664018435,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(373664018435),
//--TRIMMABLE-BOUNDARY-START(377958985731),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081078787,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317829443587,
        "f": 83886081
      },
      "n": "SpeechBinary",
      "d": 1863683,
      "h": 377958985731,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377958985731),
//--TRIMMABLE-BOUNDARY-START(249109966851),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311275011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059639811,
        "f": 83886081
      },
      "n": "MediaPeriod",
      "d": 1863683,
      "h": 249109966851,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109966851),
//--TRIMMABLE-BOUNDARY-START(395138854915),
    {
      "p": 2191363,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440817155,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343599247363,
        "f": 83886081
      },
      "n": "State",
      "d": 1863683,
      "h": 395138854915,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16776191,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395138854915),
//--TRIMMABLE-BOUNDARY-START(399433822211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030751747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352189181955,
        "f": 83886081
      },
      "n": "StateReason",
      "d": 1863683,
      "h": 399433822211,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(399433822211),
//--TRIMMABLE-BOUNDARY-START(12886765571),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361602051,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469705219,
        "f": 83886081
      },
      "n": "Contacts",
      "d": 1863683,
      "h": 12886765571,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 16,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886765571),
//--TRIMMABLE-BOUNDARY-START(408023756803),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210620931,
        "f": 50331649
      },
      "n": "TotalContacts",
      "d": 1863683,
      "h": 408023756803,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408023756803),
//--TRIMMABLE-BOUNDARY-START(420908658691),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980424707,
        "f": 50331649
      },
      "n": "TotalPending",
      "d": 1863683,
      "h": 420908658691,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(420908658691),
//--TRIMMABLE-BOUNDARY-START(236225064963),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541471235,
        "f": 50331649
      },
      "n": "HasGenderContactData",
      "d": 1863683,
      "h": 236225064963,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236225064963),
//--TRIMMABLE-BOUNDARY-START(244814999555),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721340419,
        "f": 50331649
      },
      "n": "Males",
      "d": 1863683,
      "h": 244814999555,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244814999555),
//--TRIMMABLE-BOUNDARY-START(17181732867),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951536643,
        "f": 50331649
      },
      "n": "Females",
      "d": 1863683,
      "h": 17181732867,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181732867),
//--TRIMMABLE-BOUNDARY-START(412318724099),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800555523,
        "f": 50331649
      },
      "n": "TotalDialed",
      "d": 1863683,
      "h": 412318724099,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(412318724099),
//--TRIMMABLE-BOUNDARY-START(425203625987),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570359299,
        "f": 50331649
      },
      "n": "TotalPicked",
      "d": 1863683,
      "h": 425203625987,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(425203625987),
//--TRIMMABLE-BOUNDARY-START(429498593283),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160293891,
        "f": 50331649
      },
      "n": "TotalRejected",
      "d": 1863683,
      "h": 429498593283,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(429498593283),
//--TRIMMABLE-BOUNDARY-START(433793560579),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750228483,
        "f": 50331649
      },
      "n": "TotalUnreachable",
      "d": 1863683,
      "h": 433793560579,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(433793560579),
//--TRIMMABLE-BOUNDARY-START(416613691395),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390490115,
        "f": 50331649
      },
      "n": "TotalEngagements",
      "d": 1863683,
      "h": 416613691395,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(416613691395),
//--TRIMMABLE-BOUNDARY-START(390843887619),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850882563,
        "f": 50331649
      },
      "n": "Spent",
      "d": 1863683,
      "h": 390843887619,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(390843887619)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(266289836035),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1863683,
      "h": 266289836035,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266289836035),
//--TRIMMABLE-BOUNDARY-START(261994868739),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 1863683,
      "h": 261994868739,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261994868739),
//--TRIMMABLE-BOUNDARY-START(257699901443),
    {
      "r": 262145,
      "n": "RequiresIcon",
      "d": 1863683,
      "h": 257699901443,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257699901443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296830979),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1863683,
      "h": 4296830979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296830979)
  ],
  "h": 1863683,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "ExcludeFilter",
          "v": 2125827,
          "t": 188547073
        }
      ]
    },
    {
      "t": 786472,
      "c": 17180655656,
      "a": [
        {
          "v": "Campaign",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1863683)
        
        

        //--TRIMMABLE-BOUNDARY-START(4091907)
        $asm.$cls(`$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService`, ($self) => class ICommunityCampaignBotFeedRemoteService
        {
            static $h = 4091907;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4091907,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Services.ICommunityCampaignBotFeedRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Services${separator}ICommunityCampaignBotFeedRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4091907)
        
        

        //--TRIMMABLE-BOUNDARY-START(4157443)
        $asm.$cls(`$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService_Mocking`, ($self) => class ICommunityCampaignBotFeedRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299124739)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299124739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299124739)
            
            //--TRIMMABLE-BOUNDARY-START(8594092035)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>> */ LCFCPS$IPostFeedRemoteService$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$GetFeeds(/*System.DateTime*/ start, /*int*/ count, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594092035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i1.MethodName = "GetFeeds";
                    return $i1;
                })();
                return this.InvokeAsync($.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.DateTime.$type, start), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(count, $.$$.S.Int32)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(source)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8594092035)
            
            static $h = 4157443;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299124739),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4157443,
      "h": 4299124739,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299124739)
  ],
  "h": 4157443
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$bTOs.LCCCCS.ICommunityCampaignBotFeedRemoteService, $.$LCOv.LCFCPS.IPostFeedRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Services.ICommunityCampaignBotFeedRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Services${separator}ICommunityCampaignBotFeedRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4157443)
        
        

        //--TRIMMABLE-BOUNDARY-START(5271555)
        $asm.$cls(`$bTOs.LCFCR.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4300238851)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300238851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300238851)
            
            //--TRIMMABLE-BOUNDARY-START(8595206147)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595206147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8595206147)
            
            //--TRIMMABLE-BOUNDARY-START(17185140739)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185140739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17185140739)
            
            //--TRIMMABLE-BOUNDARY-START(21480108035)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21480108035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21480108035)
            
            //--TRIMMABLE-BOUNDARY-START(25775075331)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$CampaignBot$Common$Models$CommunityCampaignBotPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775075331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25775075331)
            
            //--TRIMMABLE-BOUNDARY-START(12890173443)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890173443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$bTOs.LCCCCM.CommunityCampaignBotPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12890173443)
            
            static $h = 5271555;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300238851),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5271555,
      "h": 4300238851,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4300238851)
  ],
  "h": 5271555
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.IReadDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityCampaignBotPostModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5271555)
        
        

        //--TRIMMABLE-BOUNDARY-START(421891)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor`, ($self) => class CommunityCampaignBotCategoryModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295389187)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295389187);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, this, factory);
                    }, $iAiage ??= {"r":65537,"n":"","d":421891,"h":0,"f":17825794}), 0, "CommunityCampaignBotCategoryModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotCategoryModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotCategoryModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295389187)
            
            //--TRIMMABLE-BOUNDARY-START(12885323779)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885323779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel)).Type);
                        }, $NIrOfk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":421891,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885323779)
            
            //--TRIMMABLE-BOUNDARY-START(17180291075)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180291075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel, LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180291075)
            
            //--TRIMMABLE-BOUNDARY-START(8590356483)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590356483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590356483)
            
            static $h = 421891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885323779),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 421891,
      "h": 12885323779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885323779),
//--TRIMMABLE-BOUNDARY-START(17180291075),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 290819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 421891,
      "h": 17180291075,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180291075),
//--TRIMMABLE-BOUNDARY-START(8590356483),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 290819,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 421891,
      "h": 8590356483,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590356483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295389187),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 421891,
      "h": 4295389187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295389187)
  ],
  "h": 421891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotCategoryModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(421891)
        
        

        //--TRIMMABLE-BOUNDARY-START(1994755)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor`, ($self) => class CommunityCampaignBotPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296962051)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296962051);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotPostModel, this, factory);
                    }, $dINcue ??= {"r":65537,"n":"","d":1994755,"h":0,"f":17825794}), 0, "CommunityCampaignBotPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotPostModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotPostModelTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296962051)
            
            //--TRIMMABLE-BOUNDARY-START(12886896643)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886896643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BotType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "BotType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BotType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaignBotType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "BotType";
                        $i1.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$bTOs.LCCCCM.CommunityCampaignBotType, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).BotType);
                        }, $ZWCBfa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BotType = value.AsEnumValue($.$bTOs.LCCCCM.CommunityCampaignBotType);
                        }, $RuiEPk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Targeting"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Targeting", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Targeting")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Targeting";
                        $i3.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Targeting);
                        }, $FubZZd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Targeting = value.AsReference($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel);
                        }, $ZDXUxc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Wallet"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Wallet", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Wallet")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Wallet";
                        $i5.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Wallet);
                        }, $VGQtud ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Wallet = value.AsDouble();
                        }, $gZySla ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Type";
                        $i7.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Type);
                        }, $jpXXqe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Link"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Link", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Link")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Link";
                        $i9.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Link);
                        }, $OQsGVb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MediaUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "MediaUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MediaUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "MediaUrl";
                        $i11.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).MediaUrl);
                        }, $YHTFDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MediaUrl = value.AsReference($.$$.S.String);
                        }, $admmYf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SpeechPaymentReference"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "SpeechPaymentReference", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SpeechPaymentReference")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "SpeechPaymentReference";
                        $i13.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).SpeechPaymentReference);
                        }, $OPjzVh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SpeechPaymentReference = value.AsReference($.$$.S.String);
                        }, $FkNSJb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SpeechText"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "SpeechText", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SpeechText")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "SpeechText";
                        $i15.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).SpeechText);
                        }, $NnUeEa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SpeechText = value.AsReference($.$$.S.String);
                        }, $jTVzAd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SpeechBgMusic"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "SpeechBgMusic", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SpeechBgMusic")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "SpeechBgMusic";
                        $i17.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).SpeechBgMusic);
                        }, $ljiyef ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SpeechBgMusic = value.AsReference($.$$.S.String);
                        }, $NtlQUd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SpeechBinary"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "SpeechBinary", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SpeechBinary")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "SpeechBinary";
                        $i19.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.Byte), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).SpeechBinary);
                        }, $ILDmWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SpeechBinary = value.AsReference($.$typeArray($.$$.S.Byte));
                        }, $QJlfqa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MediaPeriod"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "MediaPeriod", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MediaPeriod")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "MediaPeriod";
                        $i21.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).MediaPeriod);
                        }, $VUTCkl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MediaPeriod = value.AsNullableValue($.$$.S.Int32);
                        }, $JWqsIf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$bTOs.LCCCCM.CommunityCampaignBotState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "State";
                        $i23.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$bTOs.LCCCCM.CommunityCampaignBotState, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).State);
                        }, $eHjKUc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$bTOs.LCCCCM.CommunityCampaignBotState);
                        }, $ohBqtg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StateReason"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "StateReason", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StateReason")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "StateReason";
                        $i25.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).StateReason);
                        }, $GdQTWj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StateReason = value.AsReference($.$$.S.String);
                        }, $IyGOna ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Contacts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Contacts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Contacts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Contacts";
                        $i27.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), ($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Contacts);
                        }, $WURbRc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        $i27.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Contacts = value.AsReference($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                        }, $GJcrhb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalContacts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalContacts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalContacts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "TotalContacts";
                        $i29.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalContacts);
                        }, $uHiFei ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalPending"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalPending", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalPending")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "TotalPending";
                        $i31.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalPending);
                        }, $AVorJh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HasGenderContactData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "HasGenderContactData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HasGenderContactData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t33 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Name = "HasGenderContactData";
                        $i33.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i33.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).HasGenderContactData);
                        }, $VUZUSg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i33;
                    })()), schemas, null, factory);
                    let $en34 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en34.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Males"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Males", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Males")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t35 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i35 = new $t35();
                        $i35.$ctor$2();
                        $i35.Name = "Males";
                        $i35.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i35.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Males);
                        }, $OXORoa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i35;
                    })()), schemas, null, factory);
                    let $en36 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en36.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en36.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Females"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Females", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Females")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t37 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i37 = new $t37();
                        $i37.$ctor$2();
                        $i37.Name = "Females";
                        $i37.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i37.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Females);
                        }, $jSEWjl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i37;
                    })()), schemas, null, factory);
                    let $en38 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en38.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalDialed"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalDialed", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalDialed")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t39 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i39 = new $t39();
                        $i39.$ctor$2();
                        $i39.Name = "TotalDialed";
                        $i39.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i39.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalDialed);
                        }, $ZKfiqc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i39;
                    })()), schemas, null, factory);
                    let $en40 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en40.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en40.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalPicked"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalPicked", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalPicked")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t41 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i41 = new $t41();
                        $i41.$ctor$2();
                        $i41.Name = "TotalPicked";
                        $i41.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i41.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalPicked);
                        }, $ajZBzh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i41;
                    })()), schemas, null, factory);
                    let $en42 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en42.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en42.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalRejected"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalRejected", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalRejected")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t43 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i43 = new $t43();
                        $i43.$ctor$2();
                        $i43.Name = "TotalRejected";
                        $i43.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i43.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalRejected);
                        }, $jqxmni ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i43;
                    })()), schemas, null, factory);
                    let $en44 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en44.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en44.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalUnreachable"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalUnreachable", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalUnreachable")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t45 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i45 = new $t45();
                        $i45.$ctor$2();
                        $i45.Name = "TotalUnreachable";
                        $i45.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i45.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalUnreachable);
                        }, $oLWsJg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i45;
                    })()), schemas, null, factory);
                    let $en46 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en46.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en46.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalEngagements"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "TotalEngagements", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalEngagements")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t47 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i47 = new $t47();
                        $i47.$ctor$2();
                        $i47.Name = "TotalEngagements";
                        $i47.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i47.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).TotalEngagements);
                        }, $tqmRBa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i47;
                    })()), schemas, null, factory);
                    let $en48 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en48.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en48.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Spent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel.$type, $.$discardRef(), "Spent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Spent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t49 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i49 = new $t49();
                        $i49.$ctor$2();
                        $i49.Name = "Spent";
                        $i49.DelaredOn = "LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel";
                        $i49.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)).Spent);
                        }, $wAACmc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1994755,"h":0,"f":17825826});
                        return $i49;
                    })()), schemas, null, factory);
                    let $en50 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en50.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en50.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886896643)
            
            //--TRIMMABLE-BOUNDARY-START(17181863939)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181863939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotCategoryModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$bTOs.LCCCCM.CommunityCampaignBotCategoryModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _BotType = _target.BotType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BotType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotType, () => _BotType, ($v) => _BotType = $v, null, true)))
                    {
                        _target.BotType = _BotType;
                    }
                }
                {
                    /*var*/ let _Targeting = _target.Targeting;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Targeting"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Targeting, ($v) => _Targeting = $v, $.$bTOs.LCCCCM.CommunityCampaignBotTargetingModel)))
                    {
                        _target.Targeting = _Targeting;
                    }
                }
                {
                    /*var*/ let _Wallet = _target.Wallet;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Wallet"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Wallet, ($v) => _Wallet = $v, $.$$.S.Double)))
                    {
                        _target.Wallet = _Wallet;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Link = _target.Link;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Link"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Link, ($v) => _Link = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _MediaUrl = _target.MediaUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MediaUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _MediaUrl, ($v) => _MediaUrl = $v, $.$$.S.String)))
                    {
                        _target.MediaUrl = _MediaUrl;
                    }
                }
                {
                    /*var*/ let _SpeechPaymentReference = _target.SpeechPaymentReference;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SpeechPaymentReference"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SpeechPaymentReference, ($v) => _SpeechPaymentReference = $v, $.$$.S.String)))
                    {
                        _target.SpeechPaymentReference = _SpeechPaymentReference;
                    }
                }
                {
                    /*var*/ let _SpeechText = _target.SpeechText;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SpeechText"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SpeechText, ($v) => _SpeechText = $v, $.$$.S.String)))
                    {
                        _target.SpeechText = _SpeechText;
                    }
                }
                {
                    /*var*/ let _SpeechBgMusic = _target.SpeechBgMusic;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SpeechBgMusic"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SpeechBgMusic, ($v) => _SpeechBgMusic = $v, $.$$.S.String)))
                    {
                        _target.SpeechBgMusic = _SpeechBgMusic;
                    }
                }
                {
                    /*var*/ let _SpeechBinary = _target.SpeechBinary;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SpeechBinary"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.Byte)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.Byte), $.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _SpeechBinary, ($v) => _SpeechBinary = $v, $.$typeArray($.$$.S.Byte))))
                    {
                        _target.SpeechBinary = _SpeechBinary;
                        if (_SpeechBinary !== null)
                        {
                            let $i66 = 0;
                            let $arr66 = _SpeechBinary;
                            while ($i66 < $arr66.length)
                            {
                                let item = $arr66[$i66++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.Byte)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.Byte), $.$$.S.Byte, property, $.$ref(() => _SpeechBinary, ($v) => _SpeechBinary = $v, $.$typeArray($.$$.S.Byte)));
                    }
                }
                {
                    /*var*/ let _MediaPeriod = _target.MediaPeriod;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MediaPeriod"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _MediaPeriod, ($v) => _MediaPeriod = $v, null, true)))
                    {
                        _target.MediaPeriod = _MediaPeriod;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$bTOs.LCCCCM.CommunityCampaignBotState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _StateReason = _target.StateReason;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StateReason"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _StateReason, ($v) => _StateReason = $v, $.$$.S.String)))
                    {
                        _target.StateReason = _StateReason;
                    }
                }
                {
                    /*var*/ let _Contacts = _target.Contacts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Contacts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, property, $.$ref(() => _Contacts, ($v) => _Contacts = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel))))
                    {
                        _target.Contacts = _Contacts;
                        if (_Contacts !== null)
                        {
                            let $en76 = _Contacts.SCG$IEnumerable$$$GetEnumerator();
                            while ($en76.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en76.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$bTOs.LCCCCM.CommunityCampaignBotContactModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel), $.$bTOs.LCCCCM.CommunityCampaignBotContactModel, property, $.$ref(() => _Contacts, ($v) => _Contacts = $v, $.$$.SCG.IEnumerable$$($.$bTOs.LCCCCM.CommunityCampaignBotContactModel)));
                    }
                }
                {
                    /*var*/ let _TotalContacts = _target.TotalContacts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalContacts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalContacts, ($v) => _TotalContacts = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalPending = _target.TotalPending;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalPending"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalPending, ($v) => _TotalPending = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _HasGenderContactData = _target.HasGenderContactData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HasGenderContactData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _HasGenderContactData, ($v) => _HasGenderContactData = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Males = _target.Males;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Males"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Males, ($v) => _Males = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Females = _target.Females;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Females"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Females, ($v) => _Females = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalDialed = _target.TotalDialed;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalDialed"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalDialed, ($v) => _TotalDialed = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalPicked = _target.TotalPicked;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalPicked"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalPicked, ($v) => _TotalPicked = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalRejected = _target.TotalRejected;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalRejected"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalRejected, ($v) => _TotalRejected = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalUnreachable = _target.TotalUnreachable;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalUnreachable"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalUnreachable, ($v) => _TotalUnreachable = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalEngagements = _target.TotalEngagements;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalEngagements"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalEngagements, ($v) => _TotalEngagements = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Spent = _target.Spent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Spent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Spent, ($v) => _Spent = $v, $.$$.S.Double)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181863939)
            
            //--TRIMMABLE-BOUNDARY-START(8591929347)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591929347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotPostModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591929347)
            
            static $h = 1994755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886896643),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1994755,
      "h": 12886896643,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886896643),
//--TRIMMABLE-BOUNDARY-START(17181863939),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1863683,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1994755,
      "h": 17181863939,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181863939),
//--TRIMMABLE-BOUNDARY-START(8591929347),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1863683,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1994755,
      "h": 8591929347,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591929347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296962051),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1994755,
      "h": 4296962051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296962051)
  ],
  "h": 1994755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1994755)
        
        

        //--TRIMMABLE-BOUNDARY-START(1601539)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotModel`, ($self) => class CommunityCampaignBotModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4296568835)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296568835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296568835)
            
            //--TRIMMABLE-BOUNDARY-START(4296568835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296568835)
            
            static $h = 1601539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296568835),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1601539,
      "h": 4296568835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296568835)
  ],
  "h": 1601539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1601539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1732611)
        $asm.$cls(`$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptor`, ($self) => class CommunityCampaignBotModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296699907)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296699907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptor.GenerateProperties($.$bTOs.LCCCCM.CommunityCampaignBotModel, this, factory);
                    }, $RgLpSg ??= {"r":65537,"n":"","d":1732611,"h":0,"f":17825794}), 0, "CommunityCampaignBotModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.CampaignBot.Common\\Models_CommunityCampaignBotModel_LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModelTypeDescriptorBuilder.g.cs", "CommunityCampaignBotModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296699907)
            
            //--TRIMMABLE-BOUNDARY-START(12886634499)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886634499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886634499)
            
            //--TRIMMABLE-BOUNDARY-START(17181601795)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181601795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.CampaignBot.Common.Settings.CommunityCampaignBotSettings, LivingThing.Core.Community.CampaignBot.Common.States.CommunityCampaignBotStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$bTOs.LCCCCS$1.CommunityCampaignBotSettings, $.$bTOs.LCCCCS$2.CommunityCampaignBotStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181601795)
            
            //--TRIMMABLE-BOUNDARY-START(8591667203)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591667203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$bTOs.LCCCCM.CommunityCampaignBotModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotModel)))
                {
                    /*var*/ let result = $.$bTOs.LCCCCM.CommunityCampaignBotModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$bTOs.LCCCCM.CommunityCampaignBotModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$bTOs.LCCCCM.CommunityCampaignBotModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591667203)
            
            static $h = 1732611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886634499),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1732611,
      "h": 12886634499,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886634499),
//--TRIMMABLE-BOUNDARY-START(17181601795),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1601539,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1732611,
      "h": 17181601795,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181601795),
//--TRIMMABLE-BOUNDARY-START(8591667203),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1601539,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1732611,
      "h": 8591667203,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591667203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296699907),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1732611,
      "h": 4296699907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296699907)
  ],
  "h": 1732611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$bTOs.LCCCCM.CommunityCampaignBotModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.CampaignBot.Common.Models.CommunityCampaignBotModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}CampaignBot${separator}Common${separator}Models${separator}CommunityCampaignBotModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1732611)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(28675)
