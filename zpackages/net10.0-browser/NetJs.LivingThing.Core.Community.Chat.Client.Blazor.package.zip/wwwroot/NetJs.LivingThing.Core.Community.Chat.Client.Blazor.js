
//--TRIMMABLE-BOUNDARY-START(32489)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $Bykq, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $VUYxXa;
    let $zDTMva;
    let $dpfuAd;
    let $KIRYqj;
    let $qMfaEd;
    let $AaTFea;
    let $KcdKDd;
    let $eYgwOf;
    let $FhvXVe;
    let $vFlGIb;
    let $wrROjc;
    let $XlsLje;
    let $nBHuTb;
    let $kFPUDh;
    let $qHjAgd;
    let $ioyhck;
    let $vJLKol;
    let $suMWgd;
    let $pfzDah;
    let $MnEewe;
    let $kijShf;
    let $illtOf;
    let $Lwznea;
    let $ciahvj;
    let $GYECNi;
    let $arNPli;
    let $PPKImg;
    let $viFAXi;
    let $rdvhRf;
    let $KQkGpf;
    let $rNUDuf;
    let $EwetZj;
    let $XCxddk;
    let $KUDCNf;
    let $WolPsc;
    let $MlMNOd;
    let $DDYNHf;
    let $AqBCXf;
    let $LLakdl;
    let $ufnATe;
    let $kwttPh;
    let $oIbsQb;
    let $CQkiBi;
    let $JVoavb;
    let $gYCZSh;
    let $BqwZpb;
    let $MEfCBk;
    let $sqXorf;
    let $dSpmlj;
    let $bEePgh;
    let $CHYDxf;
    let $xAuopg;
    let $TqAGqf;
    let $runndd;
    let $xiCQhe;
    let $JNZxaa;
    let $aOseNd;
    let $JsvAWc;
    let $JlFvje;
    let $wkkIPh;
    let $raIBxe;
    let $Qiakfb;
    let $yIIqai;
    let $thCAPg;
    let $NEXfIg;
    let $qThnJd;
    let $OhSpwd;
    let $ljfDLj;
    let $ILMLwa;
    let $fXoitf;
    let $UIIYQk;
    let $LMbueh;
    let $cWoucg;
    let $HSLfme;
    let $yfGLxd;
    let $eJhFCf;
    let $LZQLQk;
    let $OcIdHg;
    let $pUEpMg;
    let $yidJza;
    let $iUiogi;
    let $vmafXh;
    let $CROFcl;
    let $bciCNh;
    let $dqEpgd;
    let $eSCYAg;
    let $HVcxOf;
    let $YpzEKb;
    let $AXBJTe;
    let $WeYBlf;
    let $aIxzHg;
    let $rrcMZa;
    let $bXXWve;
    let $rkqzvc;
    let $FVblwj;
    let $LoxOKg;
    let $pvgNbj;
    let $VUkYHi;
    let $byyQtb;
    let $mZylOc;
    let $Xfykre;
    let $nRfesg;
    let $AeAUcg;
    let $gRDfoe;
    let $rzjkif;
    let $eivZLh;
    let $DxCcLh;
    let $MZQakf;
    let $alIxLf;
    let $FLjtHg;
    let $rVvlla;
    let $LMNUsj;
    let $TteCde;
    let $Lcxghc;
    let $eesvhg;
    let $kmzBte;
    let $fIUZqh;
    let $stDzNc;
    let $xJvHKd;
    let $AshmUa;
    let $oOdKAj;
    let $xebGYj;
    let $qJjFUd;
    let $nxxLIg;
    let $gaEIJg;
    let $GClzdg;
    let $wGSrMa;
    let $HBOZlh;
    let $ECzCZj;
    let $rjCbth;
    let $oCybAk;
    let $DyEgJf;
    let $pffgFk;
    let $lHKXEi;
    let $CGcyTc;
    let $ZwXyge;
    let $pceHcd;
    let $AToUfl;
    let $qjOsCi;
    let $XGTLTk;
    let $ZQzIif;
    let $SlkWUa;
    let $jnRcKk;
    let $epMWMd;
    let $LdojCg;
    let $UmTIqe;
    let $VgqAQi;
    let $znFzik;
    let $DWlrNb;
    let $dzMJli;
    let $klPbFc;
    let $kQzQJf;
    let $QVjLVe;
    let $iAEllf;
    let $mCIHrc;
    let $nmGCFb;
    let $CmxhQj;
    let $cNzrQa;
    let $EKvgPf;
    let $PFhOqj;
    let $ywkLdc;
    let $agAaQb;
    let $ReQbVa;
    let $twAISg;
    let $uwueXk;
    let $iZtVGh;
    let $dWMdMg;
    let $Kewbbh;
    let $fdtRVj;
    let $XDptQh;
    let $uaZWLa;
    let $kkxFuj;
    let $ZvQgWk;
    let $trkdda;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Chat.Client.Blazor", 
    {
  "h": 32489,
  "f": "LivingThing.Core.Community.Chat.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Chat.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Chat.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2326249)
        $asm.$cls(`$qbhX.LCCCCSE.IChatEditorCandidate`, ($self) => class IChatEditorCandidate
        {
            //--TRIMMABLE-BOUNDARY-START(8592260841)
            /*RenderFragment? */ LCCCCSE$IChatEditorCandidate$GetView(/*ChatThread*/ cthread)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592260841);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592260841)
            
            static $h = 2326249;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297293545),
    {
      "r": 181338113,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "Clicked",
      "o": "LCCCCSE$IChatEditorCandidate$Clicked",
      "d": 2326249,
      "h": 4297293545,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297293545),
//--TRIMMABLE-BOUNDARY-START(8592260841),
    {
      "r": 6881395,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "GetView",
      "o": "LCCCCSE$IChatEditorCandidate$GetView",
      "d": 2326249,
      "h": 8592260841,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8592260841)
  ],
  "h": 2326249
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.Editor.IChatEditorCandidate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}Editor${separator}IChatEditorCandidate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2326249)
        
        

        //--TRIMMABLE-BOUNDARY-START(360169)
        $asm.$cls(`$qbhX.LCCCC.ChatUtility`, ($self) => class ChatUtility extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295327465)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295327465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295327465)
            
            //--TRIMMABLE-BOUNDARY-START(4295327465)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295327465)
            
            static $h = 360169;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295327465),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 360169,
      "h": 4295327465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295327465)
  ],
  "h": 360169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.ChatUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}ChatUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(360169)
        
        

        //--TRIMMABLE-BOUNDARY-START(425705)
        $asm.$cls(`$qbhX.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295393001)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295393001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$qbhX.LCCCCP.AccountChatSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$qbhX.LCCCCP.AccountChatSettingsCustomAttributesProvider, $.$qbhX.LCCCCP.AccountChatSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$qbhX.LCCCCP.ChatSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$qbhX.LCCCCP.ChatSettingsCustomAttributesProvider, $.$qbhX.LCCCCP.ChatSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295393001)
            
            static $h = 425705;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295393001),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 425705,
      "h": 4295393001,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295393001)
  ],
  "h": 425705
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(425705)
        
        

        //--TRIMMABLE-BOUNDARY-START(294633)
        $asm.$cls(`$qbhX.LCCCC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295261929)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295261929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$qbhX.LCCCC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295261929)
            
            static $h = 294633;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295261929),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 294633,
      "h": 4295261929,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295261929)
  ],
  "h": 294633
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294633)
        
        

        //--TRIMMABLE-BOUNDARY-START(2522857)
        $asm.$cls(`$qbhX.LCCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297490153)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297490153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptorBuilder.Register();
                $.$qbhX.LCCCCP.ChatSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297490153)
            
            static $h = 2522857;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297490153),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2522857,
      "h": 4297490153,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297490153)
  ],
  "h": 2522857
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2522857)
        
        

        //--TRIMMABLE-BOUNDARY-START(491241)
        $asm.$cls(`$qbhX.LCCCC.ModuleComponentFluentBuilderGeneratedExtension`, ($self) => class ModuleComponentFluentBuilderGeneratedExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295458537)
            static /*ChatMessageFluentBuilder */ ChatMessageBuilder(/*this ComponentBase?*/ component, /*IServiceProvider?*/ provider, /*bool*/ stateless, /*object?*/ key)
            {
                /*var*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295458537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                provider = provider ?? $.$firstOf((($.$as(component, $.$hDPm.LCFCG.IComponentHasServiceProvider))?.LCFCG$IComponentHasServiceProvider$ServiceProvider ?? null), () => { throw new $.$$.S.NullReferenceException().$ctor$12("provider") });
                $.$hDPm.LCFCG.ComponentFluentBuilderExtensions.GetOrCreate($.$qbhX.LCCCCS$1.ChatMessageFluentBuilder, $.$qbhX.LCCCCS$1._ChatMessage, component, provider, stateless, key, new ($.$$.S.Func$$$$$($.$mac.MAC.ComponentBase, $.$scm.S.IServiceProvider, $.$$.S.Boolean, $.$qbhX.LCCCCS$1.ChatMessageFluentBuilder))().$ctor($.$qbhX.LCCCCS$1.ChatMessageFluentBuilder, $.$hDPm.LCFCG.ComponentBaseFluentBuilder$$$($.$qbhX.LCCCCS$1.ChatMessageFluentBuilder, $.$qbhX.LCCCCS$1._ChatMessage).Create), $.$ref(() => result, ($v) => result = $v, $.$qbhX.LCCCCS$1.ChatMessageFluentBuilder));
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(4295458537)
            
            static $h = 491241;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295458537),
    {
      "r": 1933033,
      "p": [
        {
          "n": "component",
          "p": 1245299
        },
        {
          "n": "provider",
          "p": 327718,
          "f": 65
        },
        {
          "n": "stateless",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "key",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "ChatMessageBuilder",
      "d": 491241,
      "h": 4295458537,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295458537)
  ],
  "h": 491241
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.ModuleComponentFluentBuilderGeneratedExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}ModuleComponentFluentBuilderGeneratedExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491241)
        
        

        //--TRIMMABLE-BOUNDARY-START(1146601)
        $asm.$cls(`$qbhX.LCCCCP.ChatSettingsCustomAttributesProvider`, ($self) => class ChatSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296113897)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296113897)
            
            //--TRIMMABLE-BOUNDARY-START(8591081193)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591081193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$qbhX.LCCCCP.ChatSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$hDPm.LCFCC$1.ServiceInjectAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t3 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Navigation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t4 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$2();
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$qbhX.LCCCCP.ChatSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $qMfaEd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1146601,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $AaTFea ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1146601,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591081193)
            
            static $h = 1146601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591081193),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1146601,
      "h": 8591081193,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591081193)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296113897),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1146601,
      "h": 4296113897,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296113897)
  ],
  "h": 1146601
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1146601)
        
        

        //--TRIMMABLE-BOUNDARY-START(753385)
        $asm.$cls(`$qbhX.LCCCCP.AccountChatSettingsCustomAttributesProvider`, ($self) => class AccountChatSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295720681)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295720681)
            
            //--TRIMMABLE-BOUNDARY-START(8590687977)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590687977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$qbhX.LCCCCP.AccountChatSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$hDPm.LCFCC$1.ServiceInjectAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t3 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Navigation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$hDPm.LCFCC$1.ServiceInjectAttribute), [(() =>
                        {
                            //new $.$hDPm.LCFCC$1.ServiceInjectAttribute()
                            const $t4 = $.$hDPm.LCFCC$1.ServiceInjectAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$2();
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$hDPm.LCFCC$1.ServiceInjectAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$qbhX.LCCCCP.AccountChatSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $pfzDah ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":753385,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MnEewe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":753385,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590687977)
            
            static $h = 753385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590687977),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 753385,
      "h": 8590687977,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590687977)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295720681),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 753385,
      "h": 4295720681,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295720681)
  ],
  "h": 753385
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}AccountChatSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(753385)
        
        

        //--TRIMMABLE-BOUNDARY-START(622313)
        $asm.$cls(`$qbhX.LCCCC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590556905)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590556905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.AccountChatSettings, "LivingThing.Core.Community.Chat.Client", "Pages\\AccountChatSettings", "Account Chat Settings", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat/Settings" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 2, "ChatSettings", "Chat Settings", "mdi mdi-cog"/*MaterialDesignIconNames.Cog*/, 8659143824n & ~1024n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.ChatAdd, "LivingThing.Core.Community.Chat.Client", "Pages\\ChatAdd", "Chat Add", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat/Add" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 0, "ChatAdd", "Add Chat", "mdi mdi-message"/*MaterialDesignIconNames.Message*/, (8659143824n & ~1024n), "card", null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.ChatPage, "LivingThing.Core.Community.Chat.Client", "Pages\\ChatPage", "Chat Page", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 0, "Chat", "Chat", "mdi mdi-message"/*MaterialDesignIconNames.Message*/, (8659143824n), "card", null, null, null, null, null, null, null, null, null, null, "Default", null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.ChatSettings, "LivingThing.Core.Community.Chat.Client", "Pages\\ChatSettings", "Chat Settings", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat/Settings/{ParameterKey}/{*catchAll}" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 1, "ChatSettings", "Chat Settings", "mdi mdi-message"/*MaterialDesignIconNames.Message*/, 8659143824n & ~1024n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.ChatThreadPage, "LivingThing.Core.Community.Chat.Client", "Pages\\ChatThreadPage", "Chat Thread Page", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat/Thread/{ParameterKey}/{*catchAll}" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 1, "Chat", "Chat", "mdi mdi-message"/*MaterialDesignIconNames.Message*/, 8659143824n | 17179869184n, null, null, null, null, null, null, null, null, null, null, null, null, null));
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$qbhX.LCCCCP.NewChatRoom, "LivingThing.Core.Community.Chat.Client", "Pages\\NewChatRoom", "New Chat Room", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Chat/New/Room" ], null, null), new $.$hDPm.LCFCL.NavigationMenuAttribute().$ctor$3("Zoey", 0, "ChatNewRoom", "New Chat Room", "mdi mdi-message"/*MaterialDesignIconNames.Message*/, (8659143824n & ~1024n) | 786432n | 33554432n, null, null, null, null, null, null, null, null, null, null, null, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590556905)
            
            //--TRIMMABLE-BOUNDARY-START(4295589609)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295589609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295589609)
            
            //--TRIMMABLE-BOUNDARY-START(4295589609)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295589609)
            
            static $h = 622313;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590556905),
    {
      "r": 65537,
      "n": "Build",
      "d": 622313,
      "h": 8590556905,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590556905)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295589609),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 622313,
      "h": 4295589609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295589609)
  ],
  "h": 622313
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622313)
        
        

        //--TRIMMABLE-BOUNDARY-START(884457)
        $asm.$cls(`$qbhX.LCCCCP.AccountChatSettingsTypeDescriptorBuilder`, ($self) => class AccountChatSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590819049)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590819049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor()
                        const $t1 = $.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pUEpMg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":884457,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$qbhX.LCCCCP.AccountChatSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590819049)
            
            //--TRIMMABLE-BOUNDARY-START(4295851753)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295851753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295851753)
            
            //--TRIMMABLE-BOUNDARY-START(4295851753)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295851753)
            
            static $h = 884457;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590819049),
    {
      "r": 65537,
      "n": "Register",
      "d": 884457,
      "h": 8590819049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590819049)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295851753),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 884457,
      "h": 4295851753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295851753)
  ],
  "h": 884457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}AccountChatSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(884457)
        
        

        //--TRIMMABLE-BOUNDARY-START(1277673)
        $asm.$cls(`$qbhX.LCCCCP.ChatSettingsTypeDescriptorBuilder`, ($self) => class ChatSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591212265)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591212265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$qbhX.LCCCCP.ChatSettingsTypeDescriptor()
                        const $t1 = $.$qbhX.LCCCCP.ChatSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Client.Pages.ChatSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WeYBlf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1277673,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$qbhX.LCCCCP.ChatSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591212265)
            
            //--TRIMMABLE-BOUNDARY-START(4296244969)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296244969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296244969)
            
            //--TRIMMABLE-BOUNDARY-START(4296244969)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296244969)
            
            static $h = 1277673;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591212265),
    {
      "r": 65537,
      "n": "Register",
      "d": 1277673,
      "h": 8591212265,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591212265)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296244969),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1277673,
      "h": 4296244969,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296244969)
  ],
  "h": 1277673
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1277673)
        
        

        //--TRIMMABLE-BOUNDARY-START(98025)
        $asm.$cls(`$qbhX._LCCCCPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295065321)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "li-class", __arg2);
                __builder.AddComponentParameter(__seq3, "ChildContent", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065321)
            
            static $h = 98025;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295065321),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 98025,
      "h": 4295065321,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295065321)
  ],
  "h": 98025
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Chat.Client.Pages.ChatSettings.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatSettings${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(98025)
        
        

        //--TRIMMABLE-BOUNDARY-START(163561)
        $asm.$cls(`$qbhX._LCCCCSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295130857)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.InputType*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.String*/ __arg2, /*int*/ __seq3, /*global::LivingThing.Core.Frameworks.Client.Components.Input.InputEditorFeatures*/ __arg3, /*int*/ __seq4, /*global::LivingThing.Core.Frameworks.Client.Components.Input.Types.InlineInputFeatures*/ __arg4, /*int*/ __seq5, /*TValue*/ __arg5, /*int*/ __seq6, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg6, /*int*/ __seq7, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg7)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295130857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Type", $.$box(__arg0, $.$fPer.LCFC.InputType));
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Class", __arg2);
                __builder.AddComponentParameter(__seq3, "Features", $.$box(__arg3, $.$hDPm.LCFCCI$1.InputEditorFeatures));
                __builder.AddComponentParameter(__seq4, "InlineInputFeatures", $.$box(__arg4, $.$hDPm.LCFCCIT.InlineInputFeatures));
                __builder.AddComponentParameter(__seq5, "Value", $.$box(__arg5, TValue));
                __builder.AddComponentParameter(__seq6, "ValueChanged", __arg6);
                __builder.AddComponentParameter(__seq7, "ValueExpression", __arg7);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295130857)
            
            static $h = 163561;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295130857),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 47614294
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 1310721
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 27612842
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": 28202666
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq6",
          "p": 655361
        },
        {
          "n": "__arg6",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq7",
          "p": 655361
        },
        {
          "n": "__arg7",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 163561,
      "h": 4295130857,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295130857)
  ],
  "h": 163561
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Chat.Client.Shared.ChatThread.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatThread${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163561)
        
        

        //--TRIMMABLE-BOUNDARY-START(1539817)
        $asm.$cls(`$qbhX.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591474409)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591474409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$qbhX.LCCCC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityChatProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IChatProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$qbhX.LCCCCS.ChatProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IChatProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.ChatProvider, x);
                }, $kijShf ??= {"r":63526570,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityChatProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.ChatProvider, x);
                }, $illtOf ??= {"r":17405376,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794}));
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$qbhX.LCCCCS.CommunityChatService, $.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatMessageModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$qbhX.LCCCCS.CommunityChatApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, x);
                }, $Lwznea ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, x);
                }, $ciahvj ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794}));
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$Bykq.LCCCCM.CommunityChatThreadModel, services, null);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$qbhX.LCCCCSE.IChatEditorCandidate, $.$qbhX.LCCCCSE.VoiceNoteCandidate, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$qbhX.LCCCCSE.IChatEditorCandidate, $.$qbhX.LCCCCSE.AttachFileCandidate, services);
                $.$qbhX.LCCCC._Startup.AddGeneratedComponentOptimizers(services);
                $.$qbhX.LCCCC.NavigationMenuBuilder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(8591474409)
            
            //--TRIMMABLE-BOUNDARY-START(12886441705)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886441705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_ChatProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$qbhX.LCCCCS.ChatProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$qbhX.LCCCCS.CommunityChatApplication, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$qbhX.LCCCCS.ChatProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_ChatProvider, $GYECNi ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ChatProvider","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_IChatProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.ChatProvider, x);
                    }), $arNPli ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.IChatProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_IChatProvider, $PPKImg ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IChatProvider","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityChatProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.ChatProvider, x);
                    }), $viFAXi ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityChatProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_ICommunityChatProvider, $rdvhRf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityChatProvider","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_CommunityChatApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$qbhX.LCCCCS.CommunityChatApplication().$ctor$5(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$qbhX.LCCCCS.CommunityChatService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$qbhX.LCCCCS.CommunityChatApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_CommunityChatApplication, $KQkGpf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityChatApplication","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_IClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, x);
                    }), $rNUDuf ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$sZVd.LCFCA.IClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_IClientApplication, $EwetZj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientApplication","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_ICommunityClientApplication(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, x);
                    }), $XCxddk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1539817,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$ahDc.LCCCS.ICommunityClientApplication.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_ICommunityClientApplication, $KUDCNf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_ICommunityClientApplication","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_VoiceNoteCandidate(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$qbhX.LCCCCSE.VoiceNoteCandidate().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$qbhX.LCCCCSE.IChatEditorCandidate.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_VoiceNoteCandidate, $WolPsc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_VoiceNoteCandidate","d":1539817,"h":0,"f":16777250})));
                /*static object*/  function Get_AttachFileCandidate(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$qbhX.LCCCCSE.AttachFileCandidate().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientUnitOfWork, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$qbhX.LCCCCSE.IChatEditorCandidate.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$qbhX.LCCCC.ServiceRegistrar, Get_AttachFileCandidate, $MlMNOd ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_AttachFileCandidate","d":1539817,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886441705)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$qbhX.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296507113)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296507113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296507113)
            
            //--TRIMMABLE-BOUNDARY-START(4296507113)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296507113)
            
            static $h = 1539817;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591474409),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1539817,
      "h": 8591474409,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591474409),
//--TRIMMABLE-BOUNDARY-START(12886441705),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1539817,
      "h": 12886441705,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886441705)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296507113),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1539817,
      "h": 4296507113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296507113)
  ],
  "h": 1539817
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1539817)
        
        

        //--TRIMMABLE-BOUNDARY-START(556777)
        $asm.$cls(`$qbhX.LCCCC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180425961)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.AccountChatSettings.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.AccountChatSettings().$ctor$4();
                    }, $AqBCXf ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.ChatAdd.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.ChatAdd().$ctor$4();
                    }, $LLakdl ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.ChatPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.ChatPage().$ctor$4();
                    }, $ufnATe ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.ChatSettings.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.ChatSettings().$ctor$5();
                    }, $kwttPh ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.ChatThreadPage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.ChatThreadPage().$ctor$5();
                    }, $oIbsQb ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.CommunityChatApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.CommunityChatApp().$ctor$3();
                    }, $CQkiBi ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCP.NewChatRoom.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCP.NewChatRoom().$ctor$4();
                    }, $JVoavb ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCS$1.ChatMessage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCS$1.ChatMessage().$ctor$5();
                    }, $gYCZSh ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCS$1.Chats.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCS$1.Chats().$ctor$3();
                    }, $BqwZpb ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCS$1.ChatThread.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCS$1.ChatThread().$ctor$5();
                    }, $MEfCBk ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCS$1.ChatThreadListItem.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCS$1.ChatThreadListItem().$ctor$5();
                    }, $sqXorf ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$qbhX.LCCCCSE.VoiceNoteRecordingView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$qbhX.LCCCCSE.VoiceNoteRecordingView().$ctor$3();
                    }, $dSpmlj ??= {"r":2752627,"n":"","d":556777,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180425961)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295524073)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295524073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295524073)
            
            //--TRIMMABLE-BOUNDARY-START(4295524073)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295524073)
            
            static $h = 556777;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180425961),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885458665,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 556777,
      "h": 17180425961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180425961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295524073),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 556777,
      "h": 4295524073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295524073)
  ],
  "h": 556777
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(556777)
        
        

        //--TRIMMABLE-BOUNDARY-START(1605353)
        $asm.$cls(`$qbhX.LCCCCS.ChatProvider`, ($self) => class ChatProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591539945)
            /*CommunityChatApplication*/ application = null;
            //--TRIMMABLE-BOUNDARY-END(8591539945)
            
            //--TRIMMABLE-BOUNDARY-START(4296572649)
            $ctor$1(/*CommunityChatApplication*/ application)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296572649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.application = application;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296572649)
            
            //--TRIMMABLE-BOUNDARY-START(21476441833)
            /*RenderFragment */ GetChats$1(/*params string[]*/ tags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476441833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$qbhX.LCCCCS$1.Chats, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.set_Item("Tags", tags);
                    return $i1;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21476441833)
            
            //--TRIMMABLE-BOUNDARY-START(17181474537)
            /*RenderFragment */ GetChats(/*PostBaseModel*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181474537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ builder) =>
                {
                    builder.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$ahDc.LCCCS.ICommunityClientApplication), 1);
                    builder.AddAttribute$4(2, "Value", this.application);
                    builder.AddAttribute$3(3, "ChildContent", $.$hDPm.LCFC.FragmentView.From$1($.$sZVd.LCFCA.ApplicationLoader, (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.set_Item("Descriptor", $.$fPer.LCFCO.OneOf$$$($.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy).FromT0(this.application));
                        $i2.set_Item("ApplyTheme", $.$box(false, $.$$.S.Boolean));
                        $i2.set_Item("ApplicationParameter", (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                            const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                            const $i3 = new $t3();
                            $i3.$ctor$1();
                            $i3.set_Item("ParentScope", parent);
                            return $i3;
                        })());
                        return $i2;
                    })(), null, null));
                    builder.CloseComponent();
                }, $DDYNHf ??= {"r":65537,"p":[{"n":"builder","p":7536755}],"n":"","d":1605353,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17181474537)
            
            //--TRIMMABLE-BOUNDARY-START(12886507241)
            /*RenderFragment */ GetChat(/*AccountBaseModel*/ me, /*AccountBaseModel*/ friend, /*ChatThreadFeatures*/ features)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886507241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$qbhX.LCCCCS$1.ChatThread, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.set_Item("Me", me);
                    $i4.set_Item("Friend", friend);
                    $i4.set_Item("Features", $.$box(features, $.$hDPm.LCFCI.ChatThreadFeatures));
                    return $i4;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12886507241)
            
            //--TRIMMABLE-BOUNDARY-START(25771409129)
            /*RenderFragment */ GetChatThread(/*DataId*/ referenceId, /*string?*/ title, /*DataId*/ thirdPartyId, /*RenderFragment?*/ initialChart, /*ChatThreadFeatures*/ features, /*IEnumerable<KeyValuePair<Stringy, object?>>?*/ attributes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771409129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
                return $.$hDPm.LCFC.FragmentView.From$1($.$qbhX.LCCCCS$1.ChatThread, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t5 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.set_Item("ReferenceId", $.$clone(referenceId));
                    $i5.set_Item("ThirdPartyId", $.$clone(thirdPartyId));
                    $i5.set_Item("Title", title);
                    $i5.set_Item("InitialChat", initialChart);
                    $i5.set_Item("Features", $.$box(features, $.$hDPm.LCFCI.ChatThreadFeatures));
                    $i5.set_Item("SetAttributes", attributes);
                    return $i5;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25771409129)
            
            //--TRIMMABLE-BOUNDARY-START(12902307264)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityChatProvider.GetChats(LivingThing.Core.Frameworks.Common.Posts.Models.PostBaseModel)
            LCCCS$ICommunityChatProvider$GetChats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12902307264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChats(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12902307264)
            
            //--TRIMMABLE-BOUNDARY-START(8607339968)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityChatProvider.GetChat(LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel, LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel, LivingThing.Core.Frameworks.Client.Interface.ChatThreadFeatures)
            LCCCS$ICommunityChatProvider$GetChat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607339968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChat(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607339968)
            
            //--TRIMMABLE-BOUNDARY-START(4358493866)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IChatProvider.GetChats(params string[])
            LCFCI$IChatProvider$GetChats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358493866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChats$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358493866)
            
            //--TRIMMABLE-BOUNDARY-START(8653461162)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IChatProvider.GetChatThread(LivingThing.Core.Frameworks.Common.Data.DataId, string?, LivingThing.Core.Frameworks.Common.Data.DataId, Microsoft.AspNetCore.Components.RenderFragment?, LivingThing.Core.Frameworks.Client.Interface.ChatThreadFeatures, System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<LivingThing.Core.Frameworks.Common.Stringy, object?>>?)
            LCFCI$IChatProvider$GetChatThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653461162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChatThread(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653461162)
            
            static $h = 1605353;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476441833),
    {
      "r": 6881395,
      "p": [
        {
          "n": "tags",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetChats",
      "o": "@$1",
      "d": 1605353,
      "h": 21476441833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476441833),
//--TRIMMABLE-BOUNDARY-START(17181474537),
    {
      "r": 6881395,
      "p": [
        {
          "n": "parent",
          "p": 16771508
        }
      ],
      "n": "GetChats",
      "d": 1605353,
      "h": 17181474537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181474537),
//--TRIMMABLE-BOUNDARY-START(12886507241),
    {
      "r": 6881395,
      "p": [
        {
          "n": "me",
          "p": 6220212
        },
        {
          "n": "friend",
          "p": 6220212
        },
        {
          "n": "features",
          "p": 62477994
        }
      ],
      "n": "GetChat",
      "d": 1605353,
      "h": 12886507241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886507241),
//--TRIMMABLE-BOUNDARY-START(25771409129),
    {
      "r": 6881395,
      "p": [
        {
          "n": "referenceId",
          "p": 10455382
        },
        {
          "n": "title",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "thirdPartyId",
          "p": 10455382,
          "f": 65
        },
        {
          "n": "initialChart",
          "p": 6881395,
          "f": 65
        },
        {
          "n": "features",
          "p": 62477994,
          "f": 65,
          "v": 0
        },
        {
          "n": "attributes",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)).$h,
          "f": 65
        }
      ],
      "n": "GetChatThread",
      "d": 1605353,
      "h": 25771409129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771409129)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591539945),
    {
      "t": 1670889,
      "n": "application",
      "d": 1605353,
      "h": 8591539945,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591539945)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296572649),
    {
      "p": [
        {
          "n": "application",
          "p": 1670889
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1605353,
      "h": 4296572649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296572649)
  ],
  "h": 1605353
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityChatProvider, $.$hDPm.LCFCI.IChatProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Services.ChatProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Services${separator}ChatProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1605353)
        
        

        //--TRIMMABLE-BOUNDARY-START(2391785)
        $asm.$cls(`$qbhX.LCCCCSE.VoiceNoteCandidate`, ($self) => class VoiceNoteCandidate extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64426901225)
            /*IJavaScriptRunner*/ javaScript = null;
            //--TRIMMABLE-BOUNDARY-END(64426901225)
            
            //--TRIMMABLE-BOUNDARY-START(8592326377)
            $ctor$1(/*IJavaScriptRunner*/ javaScript)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592326377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.javaScript = javaScript;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592326377)
            
            //--TRIMMABLE-BOUNDARY-START(60131933929)
            /*bool*/ isRecording = false;
            //--TRIMMABLE-BOUNDARY-END(60131933929)
            
            //--TRIMMABLE-BOUNDARY-START(77311803113)
            /*string? */ get Title()
            {
                return "Voice Note";
            }
            //--TRIMMABLE-BOUNDARY-END(77311803113)
            
            //--TRIMMABLE-BOUNDARY-START(55836966633)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.isRecording ? "mdi mdi-microphone-off"/*MaterialDesignIconNames.MicrophoneOff*/ : "mdi mdi-microphone"/*MaterialDesignIconNames.Microphone*/);
            }
            //--TRIMMABLE-BOUNDARY-END(55836966633)
            
            //--TRIMMABLE-BOUNDARY-START(21477228265)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(21477228265)
            
            //--TRIMMABLE-BOUNDARY-START(68721868521)
            /*Task *//*async*/  StartRecording()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721868521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let started = ($t1 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.BeginRecordAudio(this.javaScript), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (started)
                    {
                        this.isRecording = true;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68721868521)
            
            //--TRIMMABLE-BOUNDARY-START(73016835817)
            /*Task *//*async*/  StopRecording(/*ChatThread*/ cthread)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016835817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t2, $r2;
                        /*var*/ let name = `voice_${$.$strNN($.$$.S.DateTime.UtcNow.Ticks)}.webm`;
                        /*var*/ let data = $.$with(($t2 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.EndRecordAudio(this.javaScript), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))), ($clone) =>
                        {
                            $clone.Name = name;
                        });
                        /*var*/ let resource = (() =>
                        {
                            //new $.$Iaui.LCFCM.ResourceModel()
                            const $t3 = $.$Iaui.LCFCM.ResourceModel;
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            $i3.Name = `voice_${$.$strNN($.$$.S.DateTime.UtcNow.Ticks)}.webm`;
                            $i3.Data = $.$clone(data);
                            return $i3;
                        })();
                        this.AddResourceToChat(cthread.NewMessage, $.$$.SRC.RuntimeHelpers.CreateArray($.$Iaui.LCFCM.ResourceModel.$type, [ resource ], null, null));
                        cthread.Complete(this);
                    }
                    finally
                    {
                        {
                            this.isRecording = false;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016835817)
            
            //--TRIMMABLE-BOUNDARY-START(12887293673)
            /*void */ AddResourceToChat(/*CommunityChatMessageModel?*/ message, /*IEnumerable<ResourceModel>*/ resources)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887293673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let l;
                /*var*/ let list = $.$is(message.Resources, $.$$.SCG.IList$$($.$Iaui.LCFCM.ResourceModel), { set $v($v){ l = $v; } }) ? l : (message.Resources !== null ? $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ResourceModel, message.Resources) : new ($.$$.SCG.List$$($.$Iaui.LCFCM.ResourceModel))().$ctor$1());
                let $en4 = resources.SCG$IEnumerable$$$GetEnumerator();
                while ($en4.SC$1$IEnumerator$MoveNext())
                {
                    let resource = $en4.SCG$IEnumerator$$$Current;
                    {
                        if (!list.SCG$ICollection$$$Contains(resource))
                        {
                            list.SCG$ICollection$$$Add(resource);
                        }
                    }
                }
                message.Resources = list;
            }
            //--TRIMMABLE-BOUNDARY-END(12887293673)
            
            //--TRIMMABLE-BOUNDARY-START(17182260969)
            /*ValueTask *//*async*/  Clicked(/*ChatThread*/ cthread)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182260969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.isRecording)
                    {
                        let $t5, $r5;
                        ($t5 = this.StartRecording(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    else 
                    {
                        let $t6, $r6;
                        ($t6 = this.StopRecording(cthread), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182260969)
            
            //--TRIMMABLE-BOUNDARY-START(51541999337)
            /*RenderFragment? */ GetView(/*ChatThread*/ cthread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541999337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.isRecording ? $.$hDPm.LCFC.FragmentView.From$1($.$qbhX.LCCCCSE.VoiceNoteRecordingView, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t7 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.set_Item("Thread", cthread);
                    $i7.set_Item("Candidate", this);
                    return $i7;
                })(), null, null) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(51541999337)
            
            //--TRIMMABLE-BOUNDARY-START(4297293545)
            //Generated interface implemetation for LivingThing.Core.Community.Chat.Client.Shared.Editor.IChatEditorCandidate.Clicked(LivingThing.Core.Community.Chat.Client.Shared.ChatThread)
            LCCCCSE$IChatEditorCandidate$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297293545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297293545)
            
            //--TRIMMABLE-BOUNDARY-START(8592260841)
            //Generated interface implemetation for LivingThing.Core.Community.Chat.Client.Shared.Editor.IChatEditorCandidate.GetView(LivingThing.Core.Community.Chat.Client.Shared.ChatThread)
            LCCCCSE$IChatEditorCandidate$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592260841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592260841)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 2391785;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311803113),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247032041,
        "f": 50331649
      },
      "n": "Title",
      "d": 2391785,
      "h": 77311803113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311803113),
//--TRIMMABLE-BOUNDARY-START(55836966633),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657097449,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2391785,
      "h": 55836966633,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836966633),
//--TRIMMABLE-BOUNDARY-START(21477228265),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067162857,
        "f": 50331649
      },
      "n": "Description",
      "d": 2391785,
      "h": 21477228265,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477228265)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721868521),
    {
      "r": 178454529,
      "n": "StartRecording",
      "d": 2391785,
      "h": 68721868521,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(68721868521),
//--TRIMMABLE-BOUNDARY-START(73016835817),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "StopRecording",
      "d": 2391785,
      "h": 73016835817,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(73016835817),
//--TRIMMABLE-BOUNDARY-START(12887293673),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 560891
        },
        {
          "n": "resources",
          "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h
        }
      ],
      "n": "AddResourceToChat",
      "d": 2391785,
      "h": 12887293673,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887293673),
//--TRIMMABLE-BOUNDARY-START(17182260969),
    {
      "r": 181338113,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "Clicked",
      "d": 2391785,
      "h": 17182260969,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17182260969),
//--TRIMMABLE-BOUNDARY-START(51541999337),
    {
      "r": 6881395,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "GetView",
      "d": 2391785,
      "h": 51541999337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541999337)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426901225),
    {
      "t": 64509610,
      "n": "javaScript",
      "d": 2391785,
      "h": 64426901225,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426901225),
//--TRIMMABLE-BOUNDARY-START(60131933929),
    {
      "t": 262145,
      "n": "isRecording",
      "d": 2391785,
      "h": 60131933929,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60131933929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592326377),
    {
      "p": [
        {
          "n": "javaScript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2391785,
      "h": 8592326377,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592326377)
  ],
  "h": 2391785
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$qbhX.LCCCCSE.IChatEditorCandidate, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.Editor.VoiceNoteCandidate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}Editor${separator}VoiceNoteCandidate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2391785)
        
        

        //--TRIMMABLE-BOUNDARY-START(2260713)
        $asm.$cls(`$qbhX.LCCCCSE.AttachFileCandidate`, ($self) => class AttachFileCandidate extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297228009)
            /*IClientUnitOfWork*/ _unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(4297228009)
            
            //--TRIMMABLE-BOUNDARY-START(12887162601)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887162601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._unitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887162601)
            
            //--TRIMMABLE-BOUNDARY-START(60131802857)
            /*string? */ get Title()
            {
                return "Attach";
            }
            //--TRIMMABLE-BOUNDARY-END(60131802857)
            
            //--TRIMMABLE-BOUNDARY-START(55836835561)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-attachment"/*MaterialDesignIconNames.Attachment*/);
            }
            //--TRIMMABLE-BOUNDARY-END(55836835561)
            
            //--TRIMMABLE-BOUNDARY-START(25772064489)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25772064489)
            
            //--TRIMMABLE-BOUNDARY-START(17182129897)
            /*void */ AddResourceToChat(/*CommunityChatMessageModel?*/ message, /*IEnumerable<ResourceModel>*/ resources)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182129897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let l;
                /*var*/ let list = $.$is(message.Resources, $.$$.SCG.IList$$($.$Iaui.LCFCM.ResourceModel), { set $v($v){ l = $v; } }) ? l : (message.Resources !== null ? $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ResourceModel, message.Resources) : new ($.$$.SCG.List$$($.$Iaui.LCFCM.ResourceModel))().$ctor$1());
                let $en1 = resources.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let resource = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (!list.SCG$ICollection$$$Contains(resource))
                        {
                            list.SCG$ICollection$$$Add(resource);
                        }
                    }
                }
                message.Resources = list;
            }
            //--TRIMMABLE-BOUNDARY-END(17182129897)
            
            //--TRIMMABLE-BOUNDARY-START(21477097193)
            /*ValueTask *//*async*/  Clicked(/*ChatThread*/ cthread)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477097193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ResourceBrowser?*/ let browser = null;
                    ($t2 = $.$hDPm.LCFCI.ViewPresenterExtensions.View($.$hDPm.LCFCI.ViewConfiguration, $.$hDPm.LCFCCR$2.ResourceBrowser, this._unitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, null, null, new ($.$$.S.Action$$$($.$mac.MACR$1.RenderTreeBuilder, $.$$.S.Int32))().$ctor(this,  (/*builder*/ builder, /*i*/ i) =>
                    {
                        builder.AddAttribute$4(i++, "Features", $.$box(7/*ResourceBrowserFeatures.Default*/ & ~1/*ResourceBrowserFeatures.Prompt*/, $.$hDPm.LCFCCR$2.ResourceBrowserFeatures));
                        builder.AddAttribute$4(i++, "MaximumSelections", $.$box(2147483647/*int.MaxValue*/, $.$$.S.Int32));
                        builder.AddComponentReferenceCapture(i++, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*c*/ c) =>
                        {
                            return browser = $.$cast(c, $.$hDPm.LCFCCR$2.ResourceBrowser);
                        }, $vJLKol ??= {"r":65537,"p":[{"n":"c","p":131073}],"n":"","d":2260713,"h":0,"f":17825794}));
                    }, $suMWgd ??= {"r":65537,"p":[{"n":"builder","p":7536755},{"n":"i","p":655361}],"n":"","d":2260713,"h":0,"f":17825794}), null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t3 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.ViewFeatures = 63203/*ViewFeatures.DrawerDefault*/;
                        return $i3;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if ((browser?.Selections ?? null) !== null)
                    {
                        this.AddResourceToChat(cthread.NewMessage, browser.Selections);
                    }
                    cthread.Complete(this);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21477097193)
            
            //--TRIMMABLE-BOUNDARY-START(4297293545)
            //Generated interface implemetation for LivingThing.Core.Community.Chat.Client.Shared.Editor.IChatEditorCandidate.Clicked(LivingThing.Core.Community.Chat.Client.Shared.ChatThread)
            LCCCCSE$IChatEditorCandidate$Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297293545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clicked(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297293545)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 2260713;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131802857),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541868265,
        "f": 50331649
      },
      "n": "Title",
      "d": 2260713,
      "h": 60131802857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131802857),
//--TRIMMABLE-BOUNDARY-START(55836835561),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951933673,
        "f": 50331649
      },
      "n": "Icon",
      "d": 2260713,
      "h": 55836835561,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836835561),
//--TRIMMABLE-BOUNDARY-START(25772064489),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361999081,
        "f": 50331649
      },
      "n": "Description",
      "d": 2260713,
      "h": 25772064489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772064489)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182129897),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 560891
        },
        {
          "n": "resources",
          "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel).$h
        }
      ],
      "n": "AddResourceToChat",
      "d": 2260713,
      "h": 17182129897,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17182129897),
//--TRIMMABLE-BOUNDARY-START(21477097193),
    {
      "r": 181338113,
      "p": [
        {
          "n": "cthread",
          "p": 2129641
        }
      ],
      "n": "Clicked",
      "d": 2260713,
      "h": 21477097193,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21477097193)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297228009),
    {
      "t": 63657642,
      "n": "_unitOfWork",
      "d": 2260713,
      "h": 4297228009,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297228009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887162601),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2260713,
      "h": 12887162601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887162601)
  ],
  "h": 2260713
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$qbhX.LCCCCSE.IChatEditorCandidate, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.Editor.AttachFileCandidate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}Editor${separator}AttachFileCandidate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2260713)
        
        

        //--TRIMMABLE-BOUNDARY-START(2588393)
        $asm.$cls(`$qbhX.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297555689)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297555689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297555689)
            
            //--TRIMMABLE-BOUNDARY-START(4297555689)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297555689)
            
            static $h = 2588393;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297555689),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2588393,
      "h": 4297555689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297555689)
  ],
  "h": 2588393
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2588393)
        
        

        //--TRIMMABLE-BOUNDARY-START(2653929)
        $asm.$cls(`$qbhX.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297621225)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297621225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297621225)
            
            //--TRIMMABLE-BOUNDARY-START(4297621225)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297621225)
            
            static $h = 2653929;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297621225),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2653929,
      "h": 4297621225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297621225)
  ],
  "h": 2653929,
  "a": [
    {
      "t": 2588393,
      "c": 4297555689
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2653929)
        
        

        //--TRIMMABLE-BOUNDARY-START(229097)
        $asm.$cls(`$qbhX.LCCCC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590163689)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590163689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590163689)
            
            //--TRIMMABLE-BOUNDARY-START(4295196393)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295196393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295196393)
            
            //--TRIMMABLE-BOUNDARY-START(4295196393)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295196393)
            
            static $h = 229097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590163689),
    {
      "r": 65537,
      "n": "Execute",
      "d": 229097,
      "h": 8590163689,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590163689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295196393),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 229097,
      "h": 4295196393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295196393)
  ],
  "h": 229097
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(229097)
        
        

        //--TRIMMABLE-BOUNDARY-START(2457321)
        $asm.$cls(`$qbhX.LCCCCSE.VoiceNoteRecordingView`, ($self) => class VoiceNoteRecordingView extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21477293801)
            /*VoiceNoteCandidate*/ Candidate = null;
            //--TRIMMABLE-BOUNDARY-END(21477293801)
            
            //--TRIMMABLE-BOUNDARY-START(77311868649)
            /*ChatThread*/ Thread = null;
            //--TRIMMABLE-BOUNDARY-END(77311868649)
            
            //--TRIMMABLE-BOUNDARY-START(73016901353)
            /*Task */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016901353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Candidate.StopRecording(this.Thread);
            }
            //--TRIMMABLE-BOUNDARY-END(73016901353)
            
            //--TRIMMABLE-BOUNDARY-START(51542064873)
            /*string */ get OptimizedComponentName()
            {
                return "voicenoterecordingview";
            }
            //--TRIMMABLE-BOUNDARY-END(51542064873)
            
            //--TRIMMABLE-BOUNDARY-START(81606835945)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606835945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Candidate":
                    this.Candidate = $.$cast(parameter.Value, $.$qbhX.LCCCCSE.VoiceNoteCandidate);
                    return true;
                    case "Thread":
                    this.Thread = $.$cast(parameter.Value, $.$qbhX.LCCCCS$1.ChatThread);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(81606835945)
            
            //--TRIMMABLE-BOUNDARY-START(17182326505)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182326505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pd-1 bg-success-01 flex mgb");
                __builder.AddMarkupContent(2, "<i class=\"mdi mdi-record cl-error\"></i>\r\n    Recording Voice Note...\r\n    ");
                __builder.OpenElement(3, "button");
                __builder.AddAttribute$5(4, "class", "mgl-a mdi mdi-stop bg-transparent cl-error");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 5, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Stop)));
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17182326505)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12887359209)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887359209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887359209)
            
            //--TRIMMABLE-BOUNDARY-START(12887359209)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887359209)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477293801)
                this.Candidate = null;
                //--TRIMMABLE-BOUNDARY-END(21477293801)
                
                //--TRIMMABLE-BOUNDARY-START(77311868649)
                this.Thread = null;
                //--TRIMMABLE-BOUNDARY-END(77311868649)
                
            }
            static $h = 2457321;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477293801),
    {
      "p": 2391785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067228393,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131999465,
        "f": 83886081
      },
      "n": "Candidate",
      "d": 2457321,
      "h": 21477293801,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477293801),
//--TRIMMABLE-BOUNDARY-START(77311868649),
    {
      "p": 2129641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247097577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721934057,
        "f": 83886081
      },
      "n": "Thread",
      "d": 2457321,
      "h": 77311868649,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311868649),
//--TRIMMABLE-BOUNDARY-START(51542064873),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657162985,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2457321,
      "h": 51542064873,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542064873)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016901353),
    {
      "r": 178454529,
      "n": "Stop",
      "d": 2457321,
      "h": 73016901353,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016901353),
//--TRIMMABLE-BOUNDARY-START(81606835945),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2457321,
      "h": 81606835945,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606835945),
//--TRIMMABLE-BOUNDARY-START(17182326505),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2457321,
      "h": 17182326505,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182326505)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887359209),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2457321,
      "h": 12887359209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887359209)
  ],
  "h": 2457321
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.Editor.VoiceNoteRecordingView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}Editor${separator}VoiceNoteRecordingView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2457321)
        
        

        //--TRIMMABLE-BOUNDARY-START(1408745)
        $asm.$cls(`$qbhX.LCCCCP.CommunityChatApp`, ($self) => class CommunityChatApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34361147113)
            /*CommunityChatApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(34361147113)
            
            //--TRIMMABLE-BOUNDARY-START(128850427625)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(128850427625)
            
            //--TRIMMABLE-BOUNDARY-START(124555460329)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(124555460329)
            
            //--TRIMMABLE-BOUNDARY-START(111670558441)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(111670558441)
            
            //--TRIMMABLE-BOUNDARY-START(188979969769)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(188979969769)
            
            //--TRIMMABLE-BOUNDARY-START(120260493033)
            /*PostBaseModel?*/ ParentScope = null;
            //--TRIMMABLE-BOUNDARY-END(120260493033)
            
            //--TRIMMABLE-BOUNDARY-START(107375591145)
            /*ValueTask *//*async*/  NavigateBack()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.UI.LCFCC$IUIService$Page.LCFCC$IUIPageService$NavigateBack(null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375591145)
            
            //--TRIMMABLE-BOUNDARY-START(115965525737)
            /*string */ get OptimizedComponentName()
            {
                return "communitychatapp";
            }
            //--TRIMMABLE-BOUNDARY-END(115965525737)
            
            //--TRIMMABLE-BOUNDARY-START(184685002473)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685002473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch2 = parameter.Name;
                switch($switch2)
                {
                    case "ParentScope":
                    this.ParentScope = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(184685002473)
            
            //--TRIMMABLE-BOUNDARY-START(103080623849)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080623849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Rendering = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IUIRenderingProvider, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.UI = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(103080623849)
            
            //--TRIMMABLE-BOUNDARY-START(38656114409)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656114409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.Application, 0);
                __builder.AddComponentParameter(1, "Name", "Chat");
                __builder.AddComponentParameter(2, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$ahDc.LCCCS.ApplicationExtension.GetBasePath(this.Application, this.Navigation)));
                __builder.AddComponentParameter(3, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                __builder.AddComponentParameter(4, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 2/*ApplicationFeatures.Authorization*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddAttribute$3(5, "PageWrapper", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.PageContext))().$ctor(this, ( (/*wrap*/ wrap) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        if (this.ParentScope === null)
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCSL.CommunityLayout, 6);
                            __builder2.AddComponentParameter(7, "PageContext", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.IApplicationPageContext, wrap.Context));
                            __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$1(9, wrap.View);
                            }), $Xfykre ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                        else 
                        {
                            __builder2.AddContent$1(10, wrap.View);
                        }
                    }, $nRfesg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                }), $AeAUcg ??= {"r":6881395,"p":[{"n":"wrap","p":5386313}],"n":"","d":1408745,"h":0,"f":17825794}));
                __builder.AddAttribute$3(11, "SplashScreenView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.SplashScreenContext))().$ctor(this, ( (/**/ splash) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySplashScreen, 12);
                        __builder2.AddComponentParameter(13, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, splash.ViewModel));
                        __builder2.AddComponentParameter(14, "Message", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, splash.Message));
                        __builder2.CloseComponent();
                    }, $gRDfoe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                }), $rzjkif ??= {"r":6881395,"p":[{"n":"splash","p":6303817}],"n":"","d":1408745,"h":0,"f":17825794}));
                __builder.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 16);
                    __builder2.AddComponentParameter(17, "Name", "");
                    __builder2.AddComponentParameter(18, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                    __builder2.AddComponentParameter(19, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(20, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $eivZLh ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(21, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(22, "Chats");
                        }, $DxCcLh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $MZQakf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(23, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddMarkupContent(24, "<i class=\"mdi mdi-book\"></i>");
                        }, $alIxLf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $FLjtHg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(25, "FloatingButtons", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (this.ParentScope === null)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 26);
                                __builder3.AddComponentParameter(27, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                                __builder3.AddComponentParameter(28, "PageLink", "AddChat");
                                __builder3.AddComponentParameter(29, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 1024/*ButtonFeatures.Large*/ | 64/*ButtonFeatures.Round*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                __builder3.AddComponentParameter(30, "Class", "mdi mdi-plus");
                                __builder3.CloseComponent();
                            }
                        }, $rVvlla ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $LMNUsj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$qbhX.LCCCCS$1.Chats, 32);
                            let account;
                            __builder3.AddComponentParameter(33, "Filter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, (this.ParentScope !== null ? ($.$is(this.ParentScope, $.$LCOv.LCFCPM$1.AccountBaseModel, { set $v($v){ account = $v; } }) ? new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ParentScope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741827/*PostFilterTypes.Subscriptions*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ParentScope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))) : null)));
                            __builder3.CloseComponent();
                        }, $TteCde ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $Lcxghc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    if (this.ParentScope === null)
                    {
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactory, 34);
                        __builder2.AddComponentParameter(35, "Name", "AddChat");
                        __builder2.AddComponentParameter(36, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                        __builder2.AddComponentParameter(37, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/*e*/ e) =>
                        {
                            return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                        }), $eesvhg ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(38, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddContent$4(39, "Add Chat");
                            }, $kmzBte ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                        }), $fIUZqh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(40, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(41, "<i class=\"mdi mdi-plus\"></i>");
                            }, $stDzNc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                        }), $xJvHKd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 43);
                                __builder3.AddComponentParameter(44, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741828/*PostFilterTypes.Subscribers*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                                __builder3.AddComponentParameter(45, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder3.AddComponentParameter(46, "li-class", "pd");
                                __builder3.AddAttribute$3(47, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/**/ friend) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        /*var*/ let chat = (() =>
                                        {
                                            //new $.$Bykq.LCCCCM.CommunityChatThreadModel()
                                            const $t3 = $.$Bykq.LCCCCM.CommunityChatThreadModel;
                                            const $i3 = new $t3();
                                            $i3.$ctor$7();
                                            $i3.Subscribers = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [friend.Model, this.Service.CommunityService.Account], null, null);
                                            $i3.ThirdPartyId = friend.Model.Identifier;
                                            $i3.UniqueId = $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ friend.Model.Identifier, this.Service.CommunityService.Account.Identifier ], null, null));
                                            return $i3;
                                        })();
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 48);
                                        __builder4.AddComponentParameter(49, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, friend.Model.Title));
                                        __builder4.AddComponentParameter(50, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(friend.Model.IconDescriptor.Icon ?? $.$ahDc.LCCCS$1.CommunityUtility.UserIcon(this.ResourcePathResolver))));
                                        __builder4.AddComponentParameter(51, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, friend.Model.Icon));
                                        __builder4.AddComponentParameter(52, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, friend.Model.Summary));
                                        __builder4.AddComponentParameter(53, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                                        __builder4.AddComponentParameter(54, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `Thread/${$.$strNN($.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ friend.Model.Identifier, this.Service.CommunityService.Account.Identifier ], null, null)))}`));
                                        __builder4.AddComponentParameter(55, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, chat));
                                        __builder4.CloseComponent();
                                    }, $AshmUa ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                                }), $oOdKAj ??= {"r":6881395,"p":[{"n":"friend","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(56, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 57);
                                    __builder4.AddComponentParameter(58, "Message", "No Follower");
                                    __builder4.CloseComponent();
                                }), $xebGYj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $qJjFUd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                        }), $nxxLIg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$Bykq.LCCCCM.CommunityChatThreadModel), 59);
                    __builder2.AddComponentParameter(60, "Name", "Thread");
                    __builder2.AddComponentParameter(61, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3("Thread/" + $.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)))));
                    __builder2.AddComponentParameter(62, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 0/*ApplicationPageAccessibility.None*/), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                    __builder2.AddComponentParameter(63, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/ | 8/*ApplicationPageFeatures.TopToolBarIcon*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(64, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $gaEIJg ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(65, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(66, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                /*var*/ let respondent = e.GetRespondent(this.Service.CommunityService.Account);
                                return respondent?.Title ?? null;
                            }, $GClzdg ??= {"r":131073,"p":[{"n":"e","p":1085179}],"n":"","d":1408745,"h":0,"f":17825794}), true));
                        }, $wGSrMa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $HBOZlh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(67, "ToolBarControls", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(68, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                if (this.Service.CommunityService.IsOwnedByCurrentUser(e))
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(69, "menuitem");
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.ServerButton$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel)), 70);
                                        __builder4.AddComponentParameter(71, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceMethod$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel)))().$ctor(this, ( (/*s*/ s) =>
                                        {
                                            return s.LCFCD$IDeleteDataService$$$Delete(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [ e ], null, null));
                                        }), $ECzCZj ??= {"r":178454529,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                                        __builder4.AddComponentParameter(72, "Class", "mdi mdi-delete");
                                        __builder4.AddComponentParameter(73, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder4.AddComponentParameter(74, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                                        __builder4.AddComponentParameter(75, "Confirm", "Delete Chat");
                                        __builder4.AddComponentParameter(76, "ConfirmMessage", "This will delete this chat and its messages for you and all subscribers");
                                        __builder4.AddComponentParameter(77, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.NavigateBack))));
                                        __builder4.CloseComponent();
                                        __builder4.CloseElement();
                                    }, $rjCbth ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                                }
                                return null;
                            }, $oCybAk ??= {"r":6881395,"p":[{"n":"e","p":1085179}],"n":"","d":1408745,"h":0,"f":17825794}), null, true));
                        }, $DyEgJf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $pffgFk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(78, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.AddContent$1(79, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/*e*/ e) =>
                            {
                                if (this.Service.CommunityService.IsOwnedByCurrentUser(e))
                                {
                                    /*var*/ let respondent = e.GetRespondent(this.Service.CommunityService.Account);
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 80);
                                        __builder4.AddComponentParameter(81, "Class", "hx-05 wx-05");
                                        __builder4.AddComponentParameter(82, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 50), $.$$.S.Int32));
                                        __builder4.AddComponentParameter(83, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, respondent));
                                        __builder4.CloseComponent();
                                    }, $lHKXEi ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                                }
                                return null;
                            }, $CGcyTc ??= {"r":6881395,"p":[{"n":"e","p":1085179}],"n":"","d":1408745,"h":0,"f":17825794}), null, true));
                        }, $ZwXyge ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $pceHcd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(84, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(85, $.$hDPm.LCFC.FragmentView.ToViewAsync($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$mac.MAC.RenderFragment))().$ctor(this,  (/**/ e) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$qbhX.LCCCCS$1.ChatThread, 86);
                                    __builder4.AddComponentParameter(87, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, e.Identifier.HasValue ? e : null));
                                    __builder4.AddComponentParameter(88, "ThirdPartyId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, e.ThirdPartyId));
                                    __builder4.AddComponentParameter(89, "ReferenceId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, $.$fPer.LCFCD.DataId.op_Implicit$1($.$fPer.LCFC.Stringy.FirstOf(context.Data.LCFCS$IApplicationPageContext$RouteMatch.Variable, $.$fPer.LCFC.Stringy.op_Implicit$3(e.UniqueId)).ToString())));
                                    __builder4.CloseComponent();
                                }, $AToUfl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                            }, $qjOsCi ??= {"r":6881395,"p":[{"n":"e","p":1085179}],"n":"","d":1408745,"h":0,"f":17825794}), null, true));
                        }, $XGTLTk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794});
                    }), $ZQzIif ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":1408745,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $SlkWUa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1408745,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38656114409)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(30066179817)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066179817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066179817)
            
            //--TRIMMABLE-BOUNDARY-START(30066179817)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(30066179817)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361147113)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(34361147113)
                
                //--TRIMMABLE-BOUNDARY-START(128850427625)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(128850427625)
                
                //--TRIMMABLE-BOUNDARY-START(124555460329)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(124555460329)
                
                //--TRIMMABLE-BOUNDARY-START(111670558441)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(111670558441)
                
                //--TRIMMABLE-BOUNDARY-START(188979969769)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(188979969769)
                
            }
            static $h = 1408745;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361147113),
    {
      "p": 1670889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246049001,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440362217,
        "f": 83886081
      },
      "n": "Application",
      "d": 1408745,
      "h": 34361147113,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361147113),
//--TRIMMABLE-BOUNDARY-START(128850427625),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195721961,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800100585,
        "f": 83886081
      },
      "n": "Service",
      "d": 1408745,
      "h": 128850427625,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850427625),
//--TRIMMABLE-BOUNDARY-START(124555460329),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605787369,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210165993,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 1408745,
      "h": 124555460329,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555460329),
//--TRIMMABLE-BOUNDARY-START(111670558441),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835983593,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030296809,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1408745,
      "h": 111670558441,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670558441),
//--TRIMMABLE-BOUNDARY-START(188979969769),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785656553,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390035177,
        "f": 83886081
      },
      "n": "UI",
      "d": 1408745,
      "h": 188979969769,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979969769),
//--TRIMMABLE-BOUNDARY-START(120260493033),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015852777,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620231401,
        "f": 83886081
      },
      "n": "ParentScope",
      "d": 1408745,
      "h": 120260493033,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260493033),
//--TRIMMABLE-BOUNDARY-START(115965525737),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425918185,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1408745,
      "h": 115965525737,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965525737)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375591145),
    {
      "r": 181338113,
      "n": "NavigateBack",
      "d": 1408745,
      "h": 107375591145,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107375591145),
//--TRIMMABLE-BOUNDARY-START(184685002473),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1408745,
      "h": 184685002473,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184685002473),
//--TRIMMABLE-BOUNDARY-START(103080623849),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1408745,
      "h": 103080623849,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080623849),
//--TRIMMABLE-BOUNDARY-START(38656114409),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1408745,
      "h": 38656114409,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38656114409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066179817),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1408745,
      "h": 30066179817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066179817)
  ],
  "h": 1408745
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.CommunityChatApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}CommunityChatApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1408745)
        
        

        //--TRIMMABLE-BOUNDARY-START(1015529)
        $asm.$cls(`$qbhX.LCCCCP.ChatPage`, ($self) => class ChatPage extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(51540623081)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(51540623081)
            
            //--TRIMMABLE-BOUNDARY-START(38655721193)
            /*bool*/ loaded = false;
            //--TRIMMABLE-BOUNDARY-END(38655721193)
            
            //--TRIMMABLE-BOUNDARY-START(42950688489)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950688489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.loaded = true;
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950688489)
            
            //--TRIMMABLE-BOUNDARY-START(47245655785)
            /*string */ get OptimizedComponentName()
            {
                return "chatpage applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(47245655785)
            
            //--TRIMMABLE-BOUNDARY-START(34360753897)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360753897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(34360753897)
            
            //--TRIMMABLE-BOUNDARY-START(12885917417)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885917417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.FloatingButtonSectionId));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 3);
                    __builder2.AddComponentParameter(4, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 131634/*ButtonFeatures.Default*/ | 64/*ButtonFeatures.Round*/ | 1024/*ButtonFeatures.Large*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(6, "Class", "mdi mdi-plus");
                    __builder2.AddComponentParameter(7, "PageLink", "Chat/Add");
                    __builder2.AddComponentParameter(8, "title", "Add Chat");
                    __builder2.CloseComponent();
                }), $VUYxXa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1015529,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(9, "\r\n\r\n");
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 10);
                __builder.AddComponentParameter(11, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.ToolBarControlsSectionId));
                __builder.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.AddMarkupContent(13, "<li class=\"menuitem\"><a href=\"Chat/Settings\" class=\"mdi mdi-cogs\"></a></li>");
                }), $zDTMva ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1015529,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (this.loaded)
                {
                    __builder.OpenComponent$1($.$qbhX.LCCCCS$1.Chats, 14);
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 15);
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885917417)
            
            //--TRIMMABLE-BOUNDARY-START(8590950121)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590950121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590950121)
            
            //--TRIMMABLE-BOUNDARY-START(8590950121)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590950121)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540623081)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(51540623081)
                
            }
            static $h = 1015529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540623081),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065786601,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130557673,
        "f": 83886081
      },
      "n": "Service",
      "d": 1015529,
      "h": 51540623081,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540623081),
//--TRIMMABLE-BOUNDARY-START(47245655785),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475852009,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1015529,
      "h": 47245655785,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245655785)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950688489),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1015529,
      "h": 42950688489,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(42950688489),
//--TRIMMABLE-BOUNDARY-START(34360753897),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1015529,
      "h": 34360753897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360753897),
//--TRIMMABLE-BOUNDARY-START(12885917417),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1015529,
      "h": 12885917417,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885917417)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655721193),
    {
      "t": 262145,
      "n": "loaded",
      "d": 1015529,
      "h": 38655721193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655721193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590950121),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1015529,
      "h": 8590950121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590950121)
  ],
  "h": 1015529,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 0,
          "t": 655361
        },
        {
          "v": "Chat",
          "t": 1310721
        },
        {
          "v": "Chat",
          "t": 1310721
        },
        {
          "v": "mdi mdi-message",
          "t": 1310721
        },
        {
          "v": 8659143824,
          "t": 67786410
        },
        {
          "v": "card",
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "v": "Default",
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1015529)
        
        

        //--TRIMMABLE-BOUNDARY-START(1474281)
        $asm.$cls(`$qbhX.LCCCCP.NewChatRoom`, ($self) => class NewChatRoom extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(51541081833)
            /*string */ get OptimizedComponentName()
            {
                return "newchatroom applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(51541081833)
            
            //--TRIMMABLE-BOUNDARY-START(38656179945)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656179945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(38656179945)
            
            //--TRIMMABLE-BOUNDARY-START(42951147241)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(42951147241)
            
            //--TRIMMABLE-BOUNDARY-START(64425983721)
            /*CommunityChatThreadModel?*/ thread = null;
            //--TRIMMABLE-BOUNDARY-END(64425983721)
            
            //--TRIMMABLE-BOUNDARY-START(47246114537)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246114537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.thread = (() =>
                {
                    //new $.$Bykq.LCCCCM.CommunityChatThreadModel()
                    const $t1 = $.$Bykq.LCCCCM.CommunityChatThreadModel;
                    const $i1 = new $t1();
                    $i1.$ctor$7();
                    $i1.IsPublicRoom = true;
                    return $i1;
                })();
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(47246114537)
            
            //--TRIMMABLE-BOUNDARY-START(17181343465)
            /*void */ ChatRoomCreated(/*CommunityChatThreadModel*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181343465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation.NavigateTo$1(`Chat/Thread/${$.$strNN($.$dspc(thread.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(thread.Title)}`, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17181343465)
            
            //--TRIMMABLE-BOUNDARY-START(12886376169)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886376169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCS$1.CommunityCreate$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatThreadModel), 0);
                __builder.AddComponentParameter(1, "Target", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, this.thread));
                __builder.AddComponentParameter(2, "OnCreated", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$Bykq.LCCCCM.CommunityChatThreadModel, this, new ($.$$.S.Action$$($.$Bykq.LCCCCM.CommunityChatThreadModel))().$ctor(this, this.ChatRoomCreated))));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886376169)
            
            //--TRIMMABLE-BOUNDARY-START(8591408873)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591408873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591408873)
            
            //--TRIMMABLE-BOUNDARY-START(8591408873)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591408873)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951147241)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(42951147241)
                
            }
            static $h = 1474281;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541081833),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361212649,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1474281,
      "h": 51541081833,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51541081833),
//--TRIMMABLE-BOUNDARY-START(42951147241),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771278057,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131016425,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1474281,
      "h": 42951147241,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951147241)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656179945),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1474281,
      "h": 38656179945,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656179945),
//--TRIMMABLE-BOUNDARY-START(47246114537),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1474281,
      "h": 47246114537,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246114537),
//--TRIMMABLE-BOUNDARY-START(17181343465),
    {
      "r": 65537,
      "p": [
        {
          "n": "thread",
          "p": 1085179
        }
      ],
      "n": "ChatRoomCreated",
      "d": 1474281,
      "h": 17181343465,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181343465),
//--TRIMMABLE-BOUNDARY-START(12886376169),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1474281,
      "h": 12886376169,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886376169)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425983721),
    {
      "t": 1085179,
      "n": "thread",
      "d": 1474281,
      "h": 64425983721,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425983721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591408873),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1474281,
      "h": 8591408873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591408873)
  ],
  "h": 1474281,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 0,
          "t": 655361
        },
        {
          "v": "ChatNewRoom",
          "t": 1310721
        },
        {
          "v": "New Chat Room",
          "t": 1310721
        },
        {
          "v": "mdi mdi-message",
          "t": 1310721
        },
        {
          "v": 8693483664,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat/New/Room",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.NewChatRoom`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}NewChatRoom`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1474281)
        
        

        //--TRIMMABLE-BOUNDARY-START(687849)
        $asm.$cls(`$qbhX.LCCCCP.AccountChatSettings`, ($self) => class AccountChatSettings extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(81605066473)
            /*string */ get OptimizedComponentName()
            {
                return "accountchatsettings applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(81605066473)
            
            //--TRIMMABLE-BOUNDARY-START(60130229993)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130229993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60130229993)
            
            //--TRIMMABLE-BOUNDARY-START(85900033769)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(85900033769)
            
            //--TRIMMABLE-BOUNDARY-START(73015131881)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(73015131881)
            
            //--TRIMMABLE-BOUNDARY-START(21475524329)
            /*AccountChatFeatureModel?*/ chatFeature = null;
            //--TRIMMABLE-BOUNDARY-END(21475524329)
            
            //--TRIMMABLE-BOUNDARY-START(77310099177)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310099177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountBaseModel, this.Service.CommunityService.Account, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.chatFeature = $.$Bykq.LCCCCM.AccountChatFeatureModel.From(this.Service.CommunityService.Account, null, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77310099177)
            
            //--TRIMMABLE-BOUNDARY-START(64425197289)
            /*bool */ get IsGlobalRemoteActionNotificationsDisabled()
            {
                return (this.chatFeature?.GlobalRemoteActionNotificationsDisabled ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(64425197289)
            
            //--TRIMMABLE-BOUNDARY-START(107374870249)
            /*Task *//*async*/  ToggleGlobalRemoteActionNotifications()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374870249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.chatFeature !== null)
                    {
                        let $t4, $r4;
                        let $t5, $r5;
                        this.chatFeature.GlobalRemoteActionNotificationsDisabled = !this.chatFeature.GlobalRemoteActionNotificationsDisabled;
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [ this.Service.CommunityService.Account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        ($t5 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\AccountChatSettings.razor.cs", "ToggleGlobalRemoteActionNotifications", 38), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107374870249)
            
            //--TRIMMABLE-BOUNDARY-START(68720164585)
            /*void */ NavigateBack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720164585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation?.NavigateTo$1("Chat", false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(68720164585)
            
            //--TRIMMABLE-BOUNDARY-START(17180557033)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180557033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.TitleSectionId));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(3, "\r\n    Chat Settings\r\n");
                }), $dpfuAd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":687849,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(4, "\r\n\r\n");
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 5);
                __builder.AddComponentParameter(6, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.IconSectionId));
                __builder.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(8, "<div class=\"hx-03 wx-03 pos-rel round bd bd-info bdw-1\"><div class=\"lt media round clip flex mgc-a bg-dark hf wf bg-fill bg-no-repeat mdi mdi-cog\"></div></div>");
                }), $KIRYqj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":687849,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(9, "\r\n\r\n\r\n");
                __builder.OpenElement(10, "div");
                __builder.AddAttribute$5(11, "class", "bg-card pd mgt");
                __builder.AddMarkupContent(12, "<h3 class=\"mg-0 mgb fw-bold\">Privacy Settings</h3>\r\n    ");
                __builder.AddMarkupContent(13, "<p class=\"tx-sm cl-secondary mgb\">Manage global privacy settings that apply to all chats</p>\r\n    \r\n    ");
                __builder.OpenElement(14, "button");
                __builder.AddAttribute$5(15, "class", "text-left wf bg-transparent pd");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 16, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ToggleGlobalRemoteActionNotifications)));
                __builder.AddAttribute$5(17, "title", this.IsGlobalRemoteActionNotificationsDisabled ? "Enable remote actions globally" : "Disable remote actions globally");
                __builder.OpenElement(18, "div");
                __builder.AddAttribute$5(19, "class", "flex");
                __builder.OpenElement(20, "span");
                __builder.AddAttribute$5(21, "class", $.$strNN($.$strNN("mgr-1" + " mdi") + " ") + $.$strNN((this.IsGlobalRemoteActionNotificationsDisabled ? "mdi-eye-off" : "mdi-eye")));
                __builder.CloseElement();
                __builder.AddMarkupContent(22, "\r\n            ");
                __builder.AddMarkupContent(23, "<div class=\"fw-bold\">Disable remote actions</div>");
                if (this.IsGlobalRemoteActionNotificationsDisabled)
                {
                    __builder.AddMarkupContent(24, "<i class=\"mdi mdi-check-circle mgl-a cl-secondary\"></i>");
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(25, "\r\n        ");
                __builder.AddMarkupContent(26, "<small class=\"fsz-small op-8 fw-normal\">Controls typing indicators, recording notifications, and other remote action indicators across all chats</small>");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(27, "\r\n\r\n");
                __builder.OpenElement(28, "div");
                __builder.AddAttribute$5(29, "class", "bg-card pd mgt mgb");
                __builder.OpenElement(30, "button");
                __builder.AddAttribute$5(31, "class", "text-left wf bg-transparent pd flex cl-primary");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 32, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NavigateBack)));
                __builder.AddAttribute$5(33, "title", "Go back to chat");
                __builder.AddMarkupContent(34, "<span class=\"mgr-1 mdi mdi-arrow-left\"></span>\r\n        ");
                __builder.AddMarkupContent(35, "<span>Back to Chat</span>");
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180557033)
            
            //--TRIMMABLE-BOUNDARY-START(12885589737)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885589737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885589737)
            
            //--TRIMMABLE-BOUNDARY-START(12885589737)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12885589737)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85900033769)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(85900033769)
                
                //--TRIMMABLE-BOUNDARY-START(73015131881)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(73015131881)
                
            }
            static $h = 687849;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605066473),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245328105,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 687849,
      "h": 81605066473,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81605066473),
//--TRIMMABLE-BOUNDARY-START(85900033769),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835262697,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079902953,
        "f": 83886081
      },
      "n": "Service",
      "d": 687849,
      "h": 85900033769,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900033769),
//--TRIMMABLE-BOUNDARY-START(73015131881),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655393513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489968361,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 687849,
      "h": 73015131881,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015131881),
//--TRIMMABLE-BOUNDARY-START(64425197289),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065458921,
        "f": 50331650
      },
      "n": "IsGlobalRemoteActionNotificationsDisabled",
      "d": 687849,
      "h": 64425197289,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425197289)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130229993),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 687849,
      "h": 60130229993,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130229993),
//--TRIMMABLE-BOUNDARY-START(77310099177),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 687849,
      "h": 77310099177,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(77310099177),
//--TRIMMABLE-BOUNDARY-START(107374870249),
    {
      "r": 178454529,
      "n": "ToggleGlobalRemoteActionNotifications",
      "d": 687849,
      "h": 107374870249,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107374870249),
//--TRIMMABLE-BOUNDARY-START(68720164585),
    {
      "r": 65537,
      "n": "NavigateBack",
      "d": 687849,
      "h": 68720164585,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720164585),
//--TRIMMABLE-BOUNDARY-START(17180557033),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 687849,
      "h": 17180557033,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180557033)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475524329),
    {
      "t": 298747,
      "n": "chatFeature",
      "d": 687849,
      "h": 21475524329,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475524329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885589737),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 687849,
      "h": 12885589737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885589737)
  ],
  "h": 687849,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 2,
          "t": 655361
        },
        {
          "v": "ChatSettings",
          "t": 1310721
        },
        {
          "v": "Chat Settings",
          "t": 1310721
        },
        {
          "v": "mdi mdi-cog",
          "t": 1310721
        },
        {
          "v": 8659142800,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat/Settings",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}AccountChatSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(687849)
        
        

        //--TRIMMABLE-BOUNDARY-START(818921)
        $asm.$cls(`$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor`, ($self) => class AccountChatSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$qbhX.LCCCCP.AccountChatSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4295786217)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295786217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor.GenerateProperties($.$qbhX.LCCCCP.AccountChatSettings, this, factory);
                    }, $yidJza ??= {"r":65537,"n":"","d":818921,"h":0,"f":17825794}), 0, "AccountChatSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\Pages_AccountChatSettings_LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettingsTypeDescriptorBuilder.g.cs", "AccountChatSettingsTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295786217)
            
            //--TRIMMABLE-BOUNDARY-START(12885720809)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885720809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$qbhX.LCCCCP.AccountChatSettings.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$qbhX.LCCCCS.CommunityChatService, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Service";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$qbhX.LCCCCS.CommunityChatService, ($.$cast(target, $.$qbhX.LCCCCP.AccountChatSettings)).Service);
                        }, $iUiogi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":818921,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Service = value.AsReference($.$qbhX.LCCCCS.CommunityChatService);
                        }, $vmafXh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":818921,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Navigation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$qbhX.LCCCCP.AccountChatSettings.$type, $.$discardRef(), "Navigation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Navigation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mac.MAC.NavigationManager, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Navigation";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$mac.MAC.NavigationManager, ($.$cast(target, $.$qbhX.LCCCCP.AccountChatSettings)).Navigation);
                        }, $CROFcl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":818921,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Navigation = value.AsReference($.$mac.MAC.NavigationManager);
                        }, $bciCNh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":818921,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885720809)
            
            //--TRIMMABLE-BOUNDARY-START(17180688105)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180688105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$qbhX.LCCCCS.CommunityChatService));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$qbhX.LCCCCS.CommunityChatService)))
                    {
                        _target.Service = _Service;
                    }
                }
                {
                    /*var*/ let _Navigation = _target.Navigation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Navigation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mac.MAC.NavigationManager));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Navigation, ($v) => _Navigation = $v, $.$mac.MAC.NavigationManager)))
                    {
                        _target.Navigation = _Navigation;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180688105)
            
            //--TRIMMABLE-BOUNDARY-START(8590753513)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590753513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$qbhX.LCCCCP.AccountChatSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$qbhX.LCCCCP.AccountChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.AccountChatSettings)))
                {
                    /*var*/ let result = $.$qbhX.LCCCCP.AccountChatSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.AccountChatSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$qbhX.LCCCCP.AccountChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.AccountChatSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590753513)
            
            static $h = 818921;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$qbhX.LCCCCP.AccountChatSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885720809),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 818921,
      "h": 12885720809,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885720809),
//--TRIMMABLE-BOUNDARY-START(17180688105),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 687849,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 818921,
      "h": 17180688105,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180688105),
//--TRIMMABLE-BOUNDARY-START(8590753513),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 687849,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 818921,
      "h": 8590753513,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590753513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295786217),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 818921,
      "h": 4295786217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295786217)
  ],
  "h": 818921
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$qbhX.LCCCCP.AccountChatSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.AccountChatSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}AccountChatSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(818921)
        
        

        //--TRIMMABLE-BOUNDARY-START(1867497)
        $asm.$cls(`$qbhX.LCCCCS$1.ChatMessage`, ($self) => class ChatMessage extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68721344233)
            /*string */ get OptimizedComponentName()
            {
                return "chatmessage";
            }
            //--TRIMMABLE-BOUNDARY-END(68721344233)
            
            //--TRIMMABLE-BOUNDARY-START(98786115305)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786115305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Thread":
                    this.Thread = $.$cast(parameter.Value, $.$qbhX.LCCCCS$1.ChatThread);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(98786115305)
            
            //--TRIMMABLE-BOUNDARY-START(51541475049)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541475049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(51541475049)
            
            //--TRIMMABLE-BOUNDARY-START(73016311529)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73016311529)
            
            //--TRIMMABLE-BOUNDARY-START(94491148009)
            /*ChatThread*/ Thread = null;
            //--TRIMMABLE-BOUNDARY-END(94491148009)
            
            //--TRIMMABLE-BOUNDARY-START(60131409641)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131409641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ViewModel.Identifier.HasValue && !((this.ViewModel.PostFlags & (16n)) == (16n)) && !this.Service.CommunityService.Account.Equals$1(this.ViewModel.Account))
                    {
                        let $t2, $r2;
                        ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$LCOv.LCFCPS.IPostInteractionRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server.LCFCPS$IPostInteractionRemoteService$MarkRead(this.ViewModel.Identifier);
                        }, $bEePgh ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":26536372}],"n":"","d":1867497,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.ViewModel.PostFlags |= 16n;
                    }
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60131409641)
            
            //--TRIMMABLE-BOUNDARY-START(55836442345)
            /*CommunityChatMessageModel?*/ oldVM = null;
            //--TRIMMABLE-BOUNDARY-END(55836442345)
            
            //--TRIMMABLE-BOUNDARY-START(64426376937)
            /*void */ OnParametersSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426376937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.oldVM !== this.ViewModel)
                {
                    if (this.oldVM !== null)
                    {
                        this.oldVM.remove_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this, this.ViewModel_PropertyChanged));
                    }
                    this.ViewModel.add_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this, this.ViewModel_PropertyChanged));
                    this.oldVM = this.ViewModel;
                }
                super.OnParametersSet();
            }
            //--TRIMMABLE-BOUNDARY-END(64426376937)
            
            //--TRIMMABLE-BOUNDARY-START(103081082601)
            /*void */ ViewModel_PropertyChanged(/*object?*/ sender, /*System.ComponentModel.PropertyChangedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081082601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatMessage.razor.cs", "ViewModel_PropertyChanged", 46);
            }
            //--TRIMMABLE-BOUNDARY-END(103081082601)
            
            //--TRIMMABLE-BOUNDARY-START(21476703977)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476703977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ViewModel.remove_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this, this.ViewModel_PropertyChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(21476703977)
            
            //--TRIMMABLE-BOUNDARY-START(17181736681)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181736681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Service.CommunityService.IsOwnedByCurrentUser(this.ViewModel) || (this.ViewModel.Account === null && this.ViewModel.Identifier.Empty))
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "row mgl-20");
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$5(3, "class", "mg-a pdl stack");
                    __builder.OpenElement(4, "div");
                    __builder.AddAttribute$5(5, "class", "mgl-a corner-1 shadow bd-1 bg-card tipright lh-15");
                    __builder.OpenElement(6, "div");
                    __builder.AddAttribute$5(7, "class", "pd bg-primary-01");
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                    if ((__ca1__ = this.ViewModel.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca1__) : false)
                    {
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$3.MediaTiles, 8);
                        __builder.AddComponentParameter(9, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this.ViewModel.Resources));
                        __builder.AddComponentParameter(10, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 200), $.$$.S.Int32));
                        __builder.CloseComponent();
                    }
                    __builder.AddContent$1(11, $.$ahDc.LCCC.ModuleComponentFluentBuilderGeneratedExtension.CommunityPostBuilder($.$Bykq.LCCCCM.CommunityChatMessageModel, this, this.UnitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider, true, null).ViewModel(this.ViewModel).Features(7/*CommunityPostFeatures.Default*/ & ~4/*CommunityPostFeatures.Header*/ & ~1/*CommunityPostFeatures.Related*/ & ~2/*CommunityPostFeatures.ToolBar*/ & ~8/*CommunityPostFeatures.IsMainContent*/).Build());
                    __builder.AddMarkupContent(12, "\r\n                    ");
                    __builder.OpenElement(13, "small");
                    __builder.AddAttribute$5(14, "class", "text-left d-block op-7 mgt-1");
                    if (((this.ViewModel.PostFlags & (16n)) == (16n)))
                    {
                        __builder.AddMarkupContent(15, "<i class=\"mdi mdi-check-all cl-primary\"></i>");
                    }
                    else if (this.ViewModel.Identifier.HasValue)
                    {
                        __builder.AddMarkupContent(16, "<i class=\"mdi mdi-check-bold cl-primary\"></i>");
                    }
                    else 
                    {
                        __builder.AddMarkupContent(17, "<i class=\"mdi mdi-loading mdi-spin\"></i>");
                    }
                    __builder.OpenElement(18, "b");
                    __builder.AddContent$4(19, (this.ViewModel.Account ?? this.Service.CommunityService.Account).Title);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(20, "\r\n                        -\r\n                        ");
                    __builder.AddContent$4(21, (this.ViewModel.DateCreated?.ToLocalTime().ToShortTimeString() ?? null));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(22, "\r\n        ");
                    __builder.OpenElement(23, "div");
                    __builder.AddAttribute$5(24, "class", "pdr col-a flex");
                    __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 25);
                    __builder.AddComponentParameter(26, "Class", "hx-03 wx-03 mgy-a");
                    __builder.AddComponentParameter(27, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 30), $.$$.S.Int32));
                    __builder.AddComponentParameter(28, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), false), $.$$.S.Boolean));
                    __builder.AddComponentParameter(29, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.ViewModel.Account ?? this.Service.CommunityService.Account));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$5(31, "class", "row mgr-20");
                    __builder.OpenElement(32, "div");
                    __builder.AddAttribute$5(33, "class", "pdl col-a flex");
                    __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 34);
                    __builder.AddComponentParameter(35, "Class", "hx-03 wx-03 mgy-a");
                    __builder.AddComponentParameter(36, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 30), $.$$.S.Int32));
                    __builder.AddComponentParameter(37, "Editable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), false), $.$$.S.Boolean));
                    __builder.AddComponentParameter(38, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, this.ViewModel.Account ?? this.Service.CommunityService.Account));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(39, "\r\n        ");
                    __builder.OpenElement(40, "div");
                    __builder.AddAttribute$5(41, "class", "mg-a pdr stack");
                    __builder.OpenElement(42, "div");
                    __builder.AddAttribute$5(43, "class", "mgr-a corner-1 shadow bd-1 bg-card tipleft pd lh-15");
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca2__;
                    if ((__ca2__ = this.ViewModel.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca2__) : false)
                    {
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$3.MediaTiles, 44);
                        __builder.AddComponentParameter(45, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this.ViewModel.Resources));
                        __builder.AddComponentParameter(46, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 200), $.$$.S.Int32));
                        __builder.CloseComponent();
                    }
                    __builder.AddContent$1(47, $.$ahDc.LCCC.ModuleComponentFluentBuilderGeneratedExtension.CommunityPostBuilder($.$Bykq.LCCCCM.CommunityChatMessageModel, this, this.UnitOfWork.LCFCI$IClientUnitOfWork$ServiceProvider, true, null).ViewModel(this.ViewModel).Features(7/*CommunityPostFeatures.Default*/ & ~4/*CommunityPostFeatures.Header*/ & ~1/*CommunityPostFeatures.Related*/ & ~2/*CommunityPostFeatures.ToolBar*/ & ~8/*CommunityPostFeatures.IsMainContent*/).Build());
                    __builder.AddMarkupContent(48, "\r\n                ");
                    __builder.OpenElement(49, "small");
                    __builder.AddAttribute$5(50, "class", "text-right d-block op-7 mgt-1");
                    __builder.OpenElement(51, "b");
                    __builder.AddContent$4(52, (this.ViewModel.Account ?? this.Service.CommunityService.Account).Title);
                    __builder.CloseElement();
                    __builder.AddMarkupContent(53, "\r\n                    -\r\n                    ");
                    __builder.AddContent$4(54, (this.ViewModel.DateCreated?.ToLocalTime().ToShortTimeString() ?? null));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if (((this.Thread.Features & (2/*ChatThreadFeatures.ToolBar*/)) == (2/*ChatThreadFeatures.ToolBar*/)))
                {
                    __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostToolBar, 55);
                    __builder.AddComponentParameter(56, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IPost, this.ViewModel));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181736681)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886769385)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886769385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886769385)
            
            //--TRIMMABLE-BOUNDARY-START(12886769385)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12886769385)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73016311529)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73016311529)
                
                //--TRIMMABLE-BOUNDARY-START(94491148009)
                this.Thread = null;
                //--TRIMMABLE-BOUNDARY-END(94491148009)
                
            }
            static $h = 1867497;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721344233),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066638569,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1867497,
      "h": 68721344233,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721344233),
//--TRIMMABLE-BOUNDARY-START(73016311529),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656573161,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606246121,
        "f": 83886081
      },
      "n": "Service",
      "d": 1867497,
      "h": 73016311529,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016311529),
//--TRIMMABLE-BOUNDARY-START(94491148009),
    {
      "p": 2129641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246507753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196180713,
        "f": 83886081
      },
      "n": "Thread",
      "d": 1867497,
      "h": 94491148009,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94491148009)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98786115305),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1867497,
      "h": 98786115305,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786115305),
//--TRIMMABLE-BOUNDARY-START(51541475049),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1867497,
      "h": 51541475049,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541475049),
//--TRIMMABLE-BOUNDARY-START(60131409641),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1867497,
      "h": 60131409641,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(60131409641),
//--TRIMMABLE-BOUNDARY-START(64426376937),
    {
      "r": 65537,
      "n": "OnParametersSet",
      "d": 1867497,
      "h": 64426376937,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64426376937),
//--TRIMMABLE-BOUNDARY-START(103081082601),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310738
        }
      ],
      "n": "ViewModel_PropertyChanged",
      "d": 1867497,
      "h": 103081082601,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103081082601),
//--TRIMMABLE-BOUNDARY-START(21476703977),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1867497,
      "h": 21476703977,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476703977),
//--TRIMMABLE-BOUNDARY-START(17181736681),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1867497,
      "h": 17181736681,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181736681)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836442345),
    {
      "t": 560891,
      "n": "oldVM",
      "d": 1867497,
      "h": 55836442345,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55836442345)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886769385),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1867497,
      "h": 12886769385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886769385)
  ],
  "h": 1867497,
  "a": [
    {
      "t": 61429418,
      "c": 8651364010
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.ChatMessage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1867497)
        
        

        //--TRIMMABLE-BOUNDARY-START(1670889)
        $asm.$cls(`$qbhX.LCCCCS.CommunityChatApplication`, ($self) => class CommunityChatApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12886572777)
            $ctor$5(/*CommunityChatService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886572777);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886572777)
            
            //--TRIMMABLE-BOUNDARY-START(137440624361)
            /*string */ get Name()
            {
                return "Chat";
            }
            //--TRIMMABLE-BOUNDARY-END(137440624361)
            
            //--TRIMMABLE-BOUNDARY-START(154620493545)
            /*string */ get Title()
            {
                return "Chat";
            }
            //--TRIMMABLE-BOUNDARY-END(154620493545)
            
            //--TRIMMABLE-BOUNDARY-START(21476507369)
            /*string */ get Description()
            {
                return "Chat with friends";
            }
            //--TRIMMABLE-BOUNDARY-END(21476507369)
            
            //--TRIMMABLE-BOUNDARY-START(133145657065)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-chat"/*MaterialDesignIconNames.Chat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133145657065)
            
            //--TRIMMABLE-BOUNDARY-START(150325526249)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#9E964B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(150325526249)
            
            //--TRIMMABLE-BOUNDARY-START(30066441961)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/ | 4/*ApplicationServiceFeatures.Recommended*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30066441961)
            
            //--TRIMMABLE-BOUNDARY-START(17181540073)
            /*Type? */ get ApplicationViewType()
            {
                return $.$qbhX.LCCCCP.CommunityChatApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17181540073)
            
            //--TRIMMABLE-BOUNDARY-START(128850689769)
            /*RenderFragment? */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850689769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(128850689769)
            
            //--TRIMMABLE-BOUNDARY-START(25771474665)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771474665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25771474665)
            
            //--TRIMMABLE-BOUNDARY-START(141735591657)
            /*int */ get Order()
            {
                return 4000;
            }
            //--TRIMMABLE-BOUNDARY-END(141735591657)
            
            //--TRIMMABLE-BOUNDARY-START(4296638185)
            /*CommunityChatService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4296638185)
            
            //--TRIMMABLE-BOUNDARY-START(146030558953)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(146030558953)
            
            //--TRIMMABLE-BOUNDARY-START(158915460841)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(768/*PostTypes.Chat*/, 771/*PostTypes.ChatEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158915460841)
            
            static $h = 1670889;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137440624361),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606049513,
        "f": 50364417
      },
      "n": "Name",
      "d": 1670889,
      "h": 137440624361,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440624361),
//--TRIMMABLE-BOUNDARY-START(154620493545),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965787881,
        "f": 50364417
      },
      "n": "Title",
      "d": 1670889,
      "h": 154620493545,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154620493545),
//--TRIMMABLE-BOUNDARY-START(21476507369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836245737,
        "f": 50364417
      },
      "n": "Description",
      "d": 1670889,
      "h": 21476507369,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476507369),
//--TRIMMABLE-BOUNDARY-START(133145657065),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016114921,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1670889,
      "h": 133145657065,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145657065),
//--TRIMMABLE-BOUNDARY-START(150325526249),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375853289,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1670889,
      "h": 150325526249,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325526249),
//--TRIMMABLE-BOUNDARY-START(30066441961),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426180329,
        "f": 50364417
      },
      "n": "Features",
      "d": 1670889,
      "h": 30066441961,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066441961),
//--TRIMMABLE-BOUNDARY-START(17181540073),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246311145,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 1670889,
      "h": 17181540073,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181540073),
//--TRIMMABLE-BOUNDARY-START(141735591657),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195984105,
        "f": 50364417
      },
      "n": "Order",
      "d": 1670889,
      "h": 141735591657,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735591657),
//--TRIMMABLE-BOUNDARY-START(4296638185),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656376553,
        "f": 50331650
      },
      "n": "_Service",
      "d": 1670889,
      "h": 4296638185,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296638185),
//--TRIMMABLE-BOUNDARY-START(146030558953),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785918697,
        "f": 50364417
      },
      "n": "Service",
      "d": 1670889,
      "h": 146030558953,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146030558953),
//--TRIMMABLE-BOUNDARY-START(158915460841),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555722473,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 1670889,
      "h": 158915460841,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158915460841)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850689769),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 1670889,
      "h": 128850689769,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128850689769),
//--TRIMMABLE-BOUNDARY-START(25771474665),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 1670889,
      "h": 25771474665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771474665)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886572777),
    {
      "p": [
        {
          "n": "service",
          "p": 1736425
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1670889,
      "h": 12886572777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886572777)
  ],
  "h": 1670889
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Services.CommunityChatApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Services${separator}CommunityChatApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1670889)
        
        

        //--TRIMMABLE-BOUNDARY-START(1801961)
        $asm.$cls(`$qbhX.LCCCCS$1._ChatMessage`, ($self) => class _ChatMessage extends $.$qbhX.LCCCCS$1.ChatMessage
        {
            //--TRIMMABLE-BOUNDARY-START(4296769257)
            /*bool*/ _hasInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(4296769257)
            
            //--TRIMMABLE-BOUNDARY-START(8591736553)
            /*bool*/ _stateless = false;
            //--TRIMMABLE-BOUNDARY-END(8591736553)
            
            //--TRIMMABLE-BOUNDARY-START(30066573033)
            /*bool */ get LCFCG$IFluentComponent$IsStateless()
            {
                return this._stateless;
            }
            //--TRIMMABLE-BOUNDARY-END(30066573033)
            
            //--TRIMMABLE-BOUNDARY-START(17181671145)
            /*RenderFragment */ Build(/*bool*/ stateless)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181671145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stateless = stateless;
                this.OnParametersSet();
                _ = this.OnParametersSetAsync();
                if (!this._hasInitialized || stateless)
                {
                    this.OnInitialized();
                    _ = this.OnInitializedAsync();
                    this._hasInitialized = true;
                }
                return new $.$mac.MAC.RenderFragment().$ctor(this, this.BuildRenderTree);
            }
            //--TRIMMABLE-BOUNDARY-END(17181671145)
            
            //--TRIMMABLE-BOUNDARY-START(4355741354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IFluentComponent.Build(bool)
            LCFCG$IFluentComponent$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355741354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355741354)
            
            //--TRIMMABLE-BOUNDARY-START(12886703849)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886703849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886703849)
            
            //--TRIMMABLE-BOUNDARY-START(12886703849)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12886703849)
            
            static $h = 1801961;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$qbhX.LCCCCS$1.ChatMessage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066573033),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771605737,
        "f": 50331650
      },
      "n": "{60774058}.IsStateless",
      "o": "LCFCG$IFluentComponent$IsStateless",
      "d": 1801961,
      "h": 30066573033,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30066573033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181671145),
    {
      "r": 6881395,
      "p": [
        {
          "n": "stateless",
          "p": 262145
        }
      ],
      "n": "Build",
      "d": 1801961,
      "h": 17181671145,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181671145)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296769257),
    {
      "t": 262145,
      "n": "_hasInitialized",
      "d": 1801961,
      "h": 4296769257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296769257),
//--TRIMMABLE-BOUNDARY-START(8591736553),
    {
      "t": 262145,
      "n": "_stateless",
      "d": 1801961,
      "h": 8591736553,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591736553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886703849),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1801961,
      "h": 12886703849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886703849)
  ],
  "h": 1801961
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCG.IFluentComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared._ChatMessage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}_ChatMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1801961)
        
        

        //--TRIMMABLE-BOUNDARY-START(2064105)
        $asm.$cls(`$qbhX.LCCCCS$1.Chats`, ($self) => class Chats extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(120261148393)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(120261148393)
            
            //--TRIMMABLE-BOUNDARY-START(107376246505)
            /*IMessagePipeFactory*/ MessagePipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(107376246505)
            
            //--TRIMMABLE-BOUNDARY-START(163210821353)
            /*string[]?*/ Tags = null;
            //--TRIMMABLE-BOUNDARY-END(163210821353)
            
            //--TRIMMABLE-BOUNDARY-START(34361802473)
            /*DataFilter?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(34361802473)
            
            //--TRIMMABLE-BOUNDARY-START(94491344617)
            /*DataListBase<CommunityChatThreadModel, DefaultDataListItem<CommunityChatThreadModel>>?*/ list = null;
            //--TRIMMABLE-BOUNDARY-END(94491344617)
            
            //--TRIMMABLE-BOUNDARY-START(98786311913)
            /*DataListBase<CommunityChatThreadModel, DefaultDataListItem<CommunityChatThreadModel>>? */ get List()
            {
                return this.list;
            }
            //--TRIMMABLE-BOUNDARY-END(98786311913)
            
            //--TRIMMABLE-BOUNDARY-START(103081279209)
            /*IMessagePipe?*/ messagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(103081279209)
            
            //--TRIMMABLE-BOUNDARY-START(111671213801)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671213801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.messagePipe = ($t1 = this.MessagePipeFactory.LCFCM$IMessagePipeFactory$Join($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCR$3.RoutePath), [$.$fPer.LCFCR$3.RoutePath.op_Implicit$2($.$dspc(this.Service.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))], [-1], null), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.messagePipe.LCFCM$IMessagePipe$Subscribe($.$Bykq.LCCCCM.CommunityChatThreadModel, new ($.$$.S.Action$$($.$Bykq.LCCCCM.CommunityChatThreadModel))().$ctor(this, /*async*/  (/*message*/ message) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                        {
                        });
                    }, $CHYDxf ??= {"r":65537,"p":[{"n":"message","p":1085179}],"n":"","d":2064105,"h":0,"f":17829890}));
                    this.messagePipe.LCFCM$IMessagePipe$Subscribe($.$Bykq.LCCCCM.CommunityChatMessageModel, new ($.$$.S.Action$$($.$Bykq.LCCCCM.CommunityChatMessageModel))().$ctor(this, /*async*/  (/**/ message) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                        {
                        });
                    }, $xAuopg ??= {"r":65537,"p":[{"n":"message","p":560891}],"n":"","d":2064105,"h":0,"f":17829890}));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111671213801)
            
            //--TRIMMABLE-BOUNDARY-START(30066835177)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066835177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.messagePipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(30066835177)
            
            //--TRIMMABLE-BOUNDARY-START(158915854057)
            /*IEnumerable<IDataListItemContext<CommunityChatThreadModel>> */ Sort(/*IEnumerable<IDataListItemContext<CommunityChatThreadModel>>*/ models, /*Sorting*/ sorting)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915854057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.OrderByDescending$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$typeNullable($.$$.S.DateTime), models, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$$.S.Nullable$$($.$$.S.DateTime)))().$ctor(this,  (/*o*/ o) =>
                {
                    return (o.LCFCCD$1$IDataListItemContext$$$Data.LastPost?.DateCreated ?? null) ?? o.LCFCCD$1$IDataListItemContext$$$Data.DateCreated;
                }, $TqAGqf ??= {"r":$.$typeNullable($.$$.S.DateTime).$h,"p":[{"n":"o","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h}],"n":"","d":2064105,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(158915854057)
            
            //--TRIMMABLE-BOUNDARY-START(115966181097)
            /*string */ get OptimizedComponentName()
            {
                return "chats";
            }
            //--TRIMMABLE-BOUNDARY-END(115966181097)
            
            //--TRIMMABLE-BOUNDARY-START(167505788649)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505788649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "Tags":
                    this.Tags = $.$cast(parameter.Value, $.$typeArray($.$$.S.String));
                    return true;
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD.DataFilter);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(167505788649)
            
            //--TRIMMABLE-BOUNDARY-START(90196377321)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196377321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.MessagePipeFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90196377321)
            
            //--TRIMMABLE-BOUNDARY-START(25771867881)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771867881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCD.DataFilter.op_Inequality(this.Filter, null) || this.Tags !== null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatThreadModel), 0);
                    __builder.AddComponentParameter(1, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder.AddComponentParameter(2, "Class", "bdt");
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 8192n | 32768n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(4, "_Features", "DataListFeatures.Default|DataListFeatures.Delete|DataListFeatures.ServerDelete)");
                    __builder.AddComponentParameter(5, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.Filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$24("tags", $.$$.S.String.Join$10(",", this.Tags))));
                    __builder.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$qbhX.LCCCCS$1.ChatThreadListItem, 7);
                            __builder2.AddComponentParameter(8, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data));
                            __builder2.CloseComponent();
                        }, $runndd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2064105,"h":0,"f":17825794});
                    }), $xiCQhe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(9, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 10);
                        __builder2.AddComponentParameter(11, "Message", "No chats yet");
                        __builder2.AddComponentParameter(12, "Class", "mg");
                        __builder2.CloseComponent();
                    }), $JNZxaa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.AddComponentReferenceCapture(13, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.list = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatThreadModel));
                    }, $aOseNd ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$Bykq.LCCCCM.CommunityChatThreadModel), 14);
                    __builder.AddComponentParameter(15, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder.AddComponentParameter(16, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Bykq.LCCCCM.CommunityChatThreadModel), this.Service.Categories));
                    __builder.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 8192n | 32768n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(18, "Class", "bdt");
                    __builder.AddAttribute$3(19, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$qbhX.LCCCCS$1.ChatThreadListItem, 20);
                            __builder2.AddComponentParameter(21, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, context.Data));
                            __builder2.CloseComponent();
                        }, $JsvAWc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2064105,"h":0,"f":17825794});
                    }), $JlFvje ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.AddAttribute$3(22, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 23);
                        __builder2.AddComponentParameter(24, "Message", "No chats yet");
                        __builder2.AddComponentParameter(25, "Class", "mg");
                        __builder2.CloseComponent();
                    }), $wkkIPh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.AddComponentReferenceCapture(26, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.list = $.$cast(__value, $.$hDPm.LCFCCD$1.DataList$$($.$Bykq.LCCCCM.CommunityChatThreadModel));
                    }, $raIBxe ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":2064105,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771867881)
            
            //--TRIMMABLE-BOUNDARY-START(4313274026)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSortableController<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>.Sort(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.IDataListItemContext<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>>, LivingThing.Core.Frameworks.Common.Data.Sorting)
            LCFCCD$1$IDataListSortableController$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$Sort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313274026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sort(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313274026)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476900585)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476900585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476900585)
            
            //--TRIMMABLE-BOUNDARY-START(21476900585)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476900585)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120261148393)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(120261148393)
                
                //--TRIMMABLE-BOUNDARY-START(107376246505)
                this.MessagePipeFactory = null;
                //--TRIMMABLE-BOUNDARY-END(107376246505)
                
            }
            static $h = 2064105;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261148393),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311475433,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030952169,
        "f": 83886081
      },
      "n": "Service",
      "d": 2064105,
      "h": 120261148393,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261148393),
//--TRIMMABLE-BOUNDARY-START(107376246505),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131606249,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441017577,
        "f": 83886081
      },
      "n": "MessagePipeFactory",
      "d": 2064105,
      "h": 107376246505,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107376246505),
//--TRIMMABLE-BOUNDARY-START(163210821353),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901410025,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620886761,
        "f": 83886081
      },
      "n": "Tags",
      "d": 2064105,
      "h": 163210821353,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210821353),
//--TRIMMABLE-BOUNDARY-START(34361802473),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951737065,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851082985,
        "f": 83886081
      },
      "n": "Filter",
      "d": 2064105,
      "h": 34361802473,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361802473),
//--TRIMMABLE-BOUNDARY-START(98786311913),
    {
      "p": $.$hDPm.LCFCCD$1.DataListBase$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541671657,
        "f": 50331649
      },
      "n": "List",
      "d": 2064105,
      "h": 98786311913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786311913),
//--TRIMMABLE-BOUNDARY-START(115966181097),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721540841,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2064105,
      "h": 115966181097,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115966181097)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671213801),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2064105,
      "h": 111671213801,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(111671213801),
//--TRIMMABLE-BOUNDARY-START(30066835177),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2064105,
      "h": 30066835177,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066835177),
//--TRIMMABLE-BOUNDARY-START(158915854057),
    {
      "r": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h,
      "p": [
        {
          "n": "models",
          "p": $.$$.SCG.IEnumerable$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h
        },
        {
          "n": "sorting",
          "p": 36997462
        }
      ],
      "n": "Sort",
      "d": 2064105,
      "h": 158915854057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915854057),
//--TRIMMABLE-BOUNDARY-START(167505788649),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2064105,
      "h": 167505788649,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167505788649),
//--TRIMMABLE-BOUNDARY-START(90196377321),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2064105,
      "h": 90196377321,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196377321),
//--TRIMMABLE-BOUNDARY-START(25771867881),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2064105,
      "h": 25771867881,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771867881)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94491344617),
    {
      "t": $.$hDPm.LCFCCD$1.DataListBase$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h,
      "n": "list",
      "d": 2064105,
      "h": 94491344617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94491344617),
//--TRIMMABLE-BOUNDARY-START(103081279209),
    {
      "t": 341468,
      "n": "messagePipe",
      "d": 2064105,
      "h": 103081279209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103081279209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476900585),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2064105,
      "h": 21476900585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476900585)
  ],
  "h": 2064105
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD$1.IDataListSortableController$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.Chats`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}Chats`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2064105)
        
        

        //--TRIMMABLE-BOUNDARY-START(2195177)
        $asm.$cls(`$qbhX.LCCCCS$1.ChatThreadListItem`, ($self) => class ChatThreadListItem extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(77311606505)
            /*string */ get OptimizedComponentName()
            {
                return "chatthreadlistitem";
            }
            //--TRIMMABLE-BOUNDARY-END(77311606505)
            
            //--TRIMMABLE-BOUNDARY-START(64426704617)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426704617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64426704617)
            
            //--TRIMMABLE-BOUNDARY-START(81606573801)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81606573801)
            
            //--TRIMMABLE-BOUNDARY-START(12887097065)
            /*Dictionary<DataId, (CommunityChatThreadNotificationModel Notification, DateTime ExpiresAt)>*/ activeNotifications = null;
            //--TRIMMABLE-BOUNDARY-END(12887097065)
            
            //--TRIMMABLE-BOUNDARY-START(68721671913)
            /*int*/ static NotificationDurationSeconds = 15;
            //--TRIMMABLE-BOUNDARY-END(68721671913)
            
            //--TRIMMABLE-BOUNDARY-START(21477031657)
            /*AccountChatFeatureModel?*/ chatFeature = null;
            //--TRIMMABLE-BOUNDARY-END(21477031657)
            
            //--TRIMMABLE-BOUNDARY-START(73016639209)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016639209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.chatFeature = $.$Bykq.LCCCCM.AccountChatFeatureModel.From(this.Service.CommunityService.Account, null, true);
                    if (!this.chatFeature.AreRemoteActionNotificationsDisabled(this.ViewModel.Identifier))
                    {
                        this.Service.add_OnThreadNotification(new ($.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel))().$ctor(this, this.HandleThreadNotification));
                    }
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73016639209)
            
            //--TRIMMABLE-BOUNDARY-START(60131737321)
            /*void */ HandleThreadNotification(/*object?*/ sender, /*CommunityChatThreadNotificationModel*/ notification)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131737321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!notification.ThreadId.Equals$2(this.ViewModel.Identifier))
                {
                    return;
                }
                /*var*/ let expiresAt = $.$$.S.DateTime.UtcNow.AddSeconds(15/*NotificationDurationSeconds*/);
                this.activeNotifications.set_Item(notification.AccountId, new ($.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime))().$ctor$3(notification, expiresAt));
                _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        ($t2 = $.$$.STT.Task.Delay$1(((15/*NotificationDurationSeconds*/ * 1000) | 0)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.activeNotifications.Remove$1(notification.AccountId);
                        ($t3 = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatThreadListItem.razor.cs", "HandleThreadNotification", 49), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    });
                }, $KcdKDd ??= {"r":178454529,"n":"","d":2195177,"h":0,"f":17829890}));
                _ = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatThreadListItem.razor.cs", "HandleThreadNotification", 52);
            }
            //--TRIMMABLE-BOUNDARY-END(60131737321)
            
            //--TRIMMABLE-BOUNDARY-START(42951868137)
            /*IEnumerable<(DataId AccountId, CommunityChatThreadNotificationModel Notification)> */ GetActiveNotifications()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951868137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let now = $.$$.S.DateTime.UtcNow;
                /*var*/ let expired = $.$sl.SL.Enumerable.ToList($.$fPer.LCFCD.DataId, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), $.$fPer.LCFCD.DataId, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), this.activeNotifications, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), $.$$.S.Boolean))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return $.$$.S.DateTime.op_LessThanOrEqual(kvp.Value.Item2, now);
                }, $eYgwOf ??= {"r":262145,"p":[{"n":"kvp","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)).$h}],"n":"","d":2195177,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), $.$fPer.LCFCD.DataId))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return kvp.Key;
                }, $FhvXVe ??= {"r":10455382,"p":[{"n":"kvp","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)).$h}],"n":"","d":2195177,"h":0,"f":17825794})));
                let $en4 = expired.GetEnumerator();
                while ($en4.MoveNext())
                {
                    let key = $en4.Current;
                    {
                        this.activeNotifications.Remove$1($.$clone(key));
                    }
                }
                return $.$sl.SL.Enumerable.ToList($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), $.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), this.activeNotifications, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)), $.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel))().$ctor$3(kvp.Key, kvp.Value.Item1);
                }, $vFlGIb ??= {"r":$.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel).$h,"p":[{"n":"kvp","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)).$h}],"n":"","d":2195177,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(42951868137)
            
            //--TRIMMABLE-BOUNDARY-START(51541802729)
            /*string */ GetNotificationText(/*CommunityChatThreadNotificationModel*/ notification)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541802729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel>?*/ let __ca1__;
                /*var*/ let account = ((__ca1__ = this.ViewModel.Subscribers) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$LCOv.LCFCPM$1.AccountBaseModel, __ca1__, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Identifier.Equals$2(notification.AccountId);
                }, $wrROjc ??= {"r":262145,"p":[{"n":"s","p":6220212}],"n":"","d":2195177,"h":0,"f":17825794})) : null);
                /*var*/ let accountName = (account?.Name ?? null) ?? "User";
                return (() =>
                {
                    let $switch5 = notification.NotificationType;
                    if ($switch5 === 2/*CommunityChatThreadNotificationModel.Type.Typing*/)
                    {
                        return `${$.$strNN(accountName)} is typing...`;
                    }
                    if ($switch5 === 3/*CommunityChatThreadNotificationModel.Type.Recording*/)
                    {
                        return `${$.$strNN(accountName)} is recording...`;
                    }
                    if ($switch5 === 1/*CommunityChatThreadNotificationModel.Type.Open*/)
                    {
                        return `${$.$strNN(accountName)} opened chat`;
                    }
                    return $.$$.S.String.Empty;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(51541802729)
            
            //--TRIMMABLE-BOUNDARY-START(94491475689)
            /*ValueTask *//*async*/  S$IAsyncDisposable$DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491475689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Service.remove_OnThreadNotification(new ($.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel))().$ctor(this, this.HandleThreadNotification));
                    this.activeNotifications.Clear();
                    ($t6 = $.$$.STT.ValueTask.CompletedTask, ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94491475689)
            
            //--TRIMMABLE-BOUNDARY-START(17182064361)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182064361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let respondent = this.ViewModel.GetRespondent(this.Service.CommunityService.Account);
                /*var*/ let activeNotifications = $.$sl.SL.Enumerable.ToList($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), this.GetActiveNotifications());
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 0);
                __builder.AddComponentParameter(1, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.IsPublicRoom ? this.ViewModel.Title : respondent.Title));
                __builder.AddComponentParameter(2, "Class", "pd");
                __builder.AddComponentParameter(3, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.GetSubTitle()));
                __builder.AddComponentParameter(4, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, this.ViewModel.IsPublicRoom ? this.ViewModel.Icon : respondent.Icon));
                __builder.AddComponentParameter(5, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(this.ViewModel.IsPublicRoom ? this.ViewModel.IconDescriptor.Icon : (respondent.IconDescriptor.Icon ?? $.$ahDc.LCCCS$1.CommunityUtility.UserIcon(this.UnitOfWork.LCFCI$IClientUnitOfWork$ResourcePathResolver)))));
                __builder.AddComponentParameter(6, "DescriptionTemplate", (this.GetDescription()));
                __builder.AddComponentParameter(7, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Link));
                __builder.AddComponentParameter(8, "LinkParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.ViewModel));
                __builder.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                __builder.AddComponentParameter(10, "description-class", !this.Service.CommunityService.IsOwnedByCurrentUser(this.ViewModel) && !((this.ViewModel.PostFlags & (16n)) == (16n)) ? "fw-bold" : "");
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17182064361)
            
            //--TRIMMABLE-BOUNDARY-START(55836770025)
            /*string */ GetSubTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836770025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let activeNotifications = $.$sl.SL.Enumerable.ToList($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), this.GetActiveNotifications());
                if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), activeNotifications))
                {
                    /*var*/ let notification = $.$sl.SL.Enumerable.First$1($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), activeNotifications).Item2;
                    return this.GetNotificationText(notification);
                }
                /*System.DateTime?*/ let __ca1__;
                return ((__ca1__ = ((this.ViewModel.LastPost?.DateCreated ?? null) ?? this.ViewModel.DateCreated)) !== null ? ($.$fPer.LCFCDC.DateTimeExtension.Ago($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(__ca1__), 1/*DateTimeMask.Any*/) ?? $.$$.S.String.Empty) : $.$$.S.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(55836770025)
            
            //--TRIMMABLE-BOUNDARY-START(47246835433)
            /*RenderFragment */ GetDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246835433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let activeNotifications = $.$sl.SL.Enumerable.ToList($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), this.GetActiveNotifications());
                if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), activeNotifications))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(11, "<b class=\"cl-primary\">string.Join(\", \", activeNotifications.Select(n => GetNotificationText(n.Notification)))</b>");
                    }, $XlsLje ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2195177,"h":0,"f":17825794});
                }
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(($.$fPer.LCFCS$6.StringExtension.LimitLength($.$ljzt.LCFCWM.MarkdownProcessor.ToText((this.ViewModel.LastPost?.Post ?? null), null), 64, true) ?? "No chat message yet"), false);
            }
            //--TRIMMABLE-BOUNDARY-END(47246835433)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8592129769)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592129769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592129769)
            
            //--TRIMMABLE-BOUNDARY-START(8592129769)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592129769)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81606573801)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81606573801)
                
                //--TRIMMABLE-BOUNDARY-START(12887097065)
                this.activeNotifications = new ($.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12887097065)
                
            }
            static $h = 2195177;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311606505),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066966249,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2195177,
      "h": 77311606505,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77311606505),
//--TRIMMABLE-BOUNDARY-START(81606573801),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656900841,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196508393,
        "f": 83886081
      },
      "n": "Service",
      "d": 2195177,
      "h": 81606573801,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606573801)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426704617),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2195177,
      "h": 64426704617,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426704617),
//--TRIMMABLE-BOUNDARY-START(73016639209),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2195177,
      "h": 73016639209,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(73016639209),
//--TRIMMABLE-BOUNDARY-START(60131737321),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "notification",
          "p": 1347323
        }
      ],
      "n": "HandleThreadNotification",
      "d": 2195177,
      "h": 60131737321,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60131737321),
//--TRIMMABLE-BOUNDARY-START(42951868137),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$fPer.LCFCD.DataId, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)).$h,
      "n": "GetActiveNotifications",
      "d": 2195177,
      "h": 42951868137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951868137),
//--TRIMMABLE-BOUNDARY-START(51541802729),
    {
      "r": 1310721,
      "p": [
        {
          "n": "notification",
          "p": 1347323
        }
      ],
      "n": "GetNotificationText",
      "d": 2195177,
      "h": 51541802729,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541802729),
//--TRIMMABLE-BOUNDARY-START(17182064361),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2195177,
      "h": 17182064361,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17182064361),
//--TRIMMABLE-BOUNDARY-START(55836770025),
    {
      "r": 1310721,
      "n": "GetSubTitle",
      "d": 2195177,
      "h": 55836770025,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836770025),
//--TRIMMABLE-BOUNDARY-START(47246835433),
    {
      "r": 6881395,
      "n": "GetDescription",
      "d": 2195177,
      "h": 47246835433,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246835433)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887097065),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.S.ValueTuple$$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, $.$$.S.DateTime)).$h,
      "n": "activeNotifications",
      "d": 2195177,
      "h": 12887097065,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887097065),
//--TRIMMABLE-BOUNDARY-START(68721671913),
    {
      "t": 655361,
      "n": "NotificationDurationSeconds",
      "d": 2195177,
      "h": 68721671913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68721671913),
//--TRIMMABLE-BOUNDARY-START(21477031657),
    {
      "t": 298747,
      "n": "chatFeature",
      "d": 2195177,
      "h": 21477031657,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477031657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592129769),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2195177,
      "h": 8592129769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592129769)
  ],
  "h": 2195177
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.ChatThreadListItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatThreadListItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2195177)
        
        

        //--TRIMMABLE-BOUNDARY-START(2129641)
        $asm.$cls(`$qbhX.LCCCCS$1.ChatThread`, ($self) => class ChatThread extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(365074349801)
            /*string */ get OptimizedComponentName()
            {
                return "chatthread";
            }
            //--TRIMMABLE-BOUNDARY-END(365074349801)
            
            //--TRIMMABLE-BOUNDARY-START(575527747305)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575527747305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Layout":
                    this.Layout = $.$cast(parameter.Value, $.$lJUR.LCFCS.ApplicationLayout);
                    return true;
                    case "Me":
                    this.Me = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.AccountBaseModel);
                    return true;
                    case "Friend":
                    this.Friend = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.AccountBaseModel);
                    return true;
                    case "ThirdPartyId":
                    this.ThirdPartyId = $.$cast(parameter.Value, $.$fPer.LCFCD.DataId);
                    return true;
                    case "ReferenceId":
                    this.ReferenceId = $.$cast(parameter.Value, $.$fPer.LCFCD.DataId);
                    return true;
                    case "Title":
                    this.Title = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "Features":
                    this.Features = $.$cast(parameter.Value, $.$hDPm.LCFCI.ChatThreadFeatures);
                    return true;
                    case "InitialChat":
                    this.InitialChat = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "InitialMessage":
                    this.InitialMessage = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(575527747305)
            
            //--TRIMMABLE-BOUNDARY-START(292059905769)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059905769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Editors = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$qbhX.LCCCCSE.IChatEditorCandidate), serviceProvider);
                this.JavaScript = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(292059905769)
            
            //--TRIMMABLE-BOUNDARY-START(313534742249)
            /*ApplicationLayout?*/ Layout = null;
            //--TRIMMABLE-BOUNDARY-END(313534742249)
            
            //--TRIMMABLE-BOUNDARY-START(339304546025)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(339304546025)
            
            //--TRIMMABLE-BOUNDARY-START(412318990057)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(412318990057)
            
            //--TRIMMABLE-BOUNDARY-START(408024022761)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(408024022761)
            
            //--TRIMMABLE-BOUNDARY-START(115966246633)
            /*IEnumerable<IChatEditorCandidate>*/ Editors = null;
            //--TRIMMABLE-BOUNDARY-END(115966246633)
            
            //--TRIMMABLE-BOUNDARY-START(300649840361)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(300649840361)
            
            //--TRIMMABLE-BOUNDARY-START(326419644137)
            /*AccountBaseModel?*/ Me = null;
            //--TRIMMABLE-BOUNDARY-END(326419644137)
            
            //--TRIMMABLE-BOUNDARY-START(133146115817)
            /*AccountBaseModel?*/ Friend = null;
            //--TRIMMABLE-BOUNDARY-END(133146115817)
            
            //--TRIMMABLE-BOUNDARY-START(558347878121)
            /*DataId*/ ThirdPartyId;
            //--TRIMMABLE-BOUNDARY-END(558347878121)
            
            //--TRIMMABLE-BOUNDARY-START(382254218985)
            /*DataId*/ ReferenceId;
            //--TRIMMABLE-BOUNDARY-END(382254218985)
            
            //--TRIMMABLE-BOUNDARY-START(566937812713)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(566937812713)
            
            //--TRIMMABLE-BOUNDARY-START(124556181225)
            /*ChatThreadFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(124556181225)
            
            //--TRIMMABLE-BOUNDARY-START(283469971177)
            /*RenderFragment?*/ InitialChat = null;
            //--TRIMMABLE-BOUNDARY-END(283469971177)
            
            //--TRIMMABLE-BOUNDARY-START(287764938473)
            /*string?*/ InitialMessage = null;
            //--TRIMMABLE-BOUNDARY-END(287764938473)
            
            //--TRIMMABLE-BOUNDARY-START(81606508265)
            /*AccountChatFeatureModel?*/ chatFeature = null;
            //--TRIMMABLE-BOUNDARY-END(81606508265)
            
            //--TRIMMABLE-BOUNDARY-START(98786377449)
            /*IChatEditorCandidate?*/ currentCandidate = null;
            //--TRIMMABLE-BOUNDARY-END(98786377449)
            
            //--TRIMMABLE-BOUNDARY-START(579822714601)
            /*ElementReference*/ unreadMarker;
            //--TRIMMABLE-BOUNDARY-END(579822714601)
            
            //--TRIMMABLE-BOUNDARY-START(128851148521)
            /*CommunityChatMessageModel?*/ firstUnRead = null;
            //--TRIMMABLE-BOUNDARY-END(128851148521)
            
            //--TRIMMABLE-BOUNDARY-START(352189447913)
            /*int*/ newMessages = 0;
            //--TRIMMABLE-BOUNDARY-END(352189447913)
            
            //--TRIMMABLE-BOUNDARY-START(85901475561)
            /*string*/ chatId = null;
            //--TRIMMABLE-BOUNDARY-END(85901475561)
            
            //--TRIMMABLE-BOUNDARY-START(562642845417)
            /*CommunityChatThreadModel?*/ thread = null;
            //--TRIMMABLE-BOUNDARY-END(562642845417)
            
            //--TRIMMABLE-BOUNDARY-START(554052910825)
            /*bool*/ subscribed = false;
            //--TRIMMABLE-BOUNDARY-END(554052910825)
            
            //--TRIMMABLE-BOUNDARY-START(373664284393)
            /*bool*/ readMore = false;
            //--TRIMMABLE-BOUNDARY-END(373664284393)
            
            //--TRIMMABLE-BOUNDARY-START(377959251689)
            /*void */ ReadMore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377959251689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.readMore = !this.readMore;
            }
            //--TRIMMABLE-BOUNDARY-END(377959251689)
            
            //--TRIMMABLE-BOUNDARY-START(360779382505)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(360779382505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.Service.LoadErrorMessage = null;
                    ($t3 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountBaseModel, this.Service.CommunityService.Account, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.chatFeature = $.$Bykq.LCCCCM.AccountChatFeatureModel.From(this.Service.CommunityService.Account, null, true);
                    if (this.ViewModel === null && this.ReferenceId.Empty && (this.Me === null || this.Friend === null))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("A chat thread must have either the thread or its reference id or its users");
                    }
                    this.thread = this.ViewModel;
                    /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel?*/ let __ca1__;
                    /*object?*/ let __ca2__;
                    /*object?*/ let __ca3__;
                    this.chatId = ((__ca3__ = this.ReferenceId.Id) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? ((__ca1__ = this.thread) !== null ? (((__ca2__ = __ca1__.Identifier.Id) !== null ? ($.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) ?? $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) : $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) ?? $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) : $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null)))) : ((__ca1__ = this.thread) !== null ? (((__ca2__ = __ca1__.Identifier.Id) !== null ? ($.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) ?? $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) : $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) ?? $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))) : $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.Friend.Identifier, this.Me.Identifier ], null, null))));
                    if (this.thread === null && this.Me !== null && this.Friend !== null)
                    {
                        let $t4, $r4;
                        this.thread = ($t4 = this.Service.InitializePrivateChat(this.Me, this.Friend, this.chatId, false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel?*/ let __ca4__;
                    if ((__ca4__ = this.thread) !== null ? ((__ca4__.PostFlags & (1n)) == (1n)) : false)
                    {
                        let $t5, $r5;
                        this.subscribed = ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$$.S.Boolean, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean)))().$ctor(this,  (/**/ s) =>
                        {
                            return s.LCFCPS$IPostInteractionRemoteService$IsSubscribed(this.thread.Identifier);
                        }, $jnRcKk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean)).$h,"p":[{"n":"s","p":26536372}],"n":"","d":2129641,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    else 
                    {
                        this.subscribed = true;
                    }
                    this.newMessage = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatMessageModel()
                        const $t6 = $.$Bykq.LCCCCM.CommunityChatMessageModel;
                        const $i6 = new $t6();
                        $i6.$ctor$6();
                        $i6.Name = "_";
                        $i6.ThirdPartyId = $.$clone(this.ThirdPartyId);
                        return $i6;
                    })();
                    this.Service.add_OnNewChat(new ($.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatMessageModel))().$ctor(this, this.Service_OnNewChat));
                    this.Service.add_OnReadNotification(new ($.$$.S.EventHandler$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel))().$ctor(this, this.Service_OnReadNotification));
                    ($t7 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(360779382505)
            
            //--TRIMMABLE-BOUNDARY-START(420908924649)
            /*void *//*async*/  Service_OnReadNotification(/*object?*/ sender, /*PostIsReadNotificationModel*/ notification)
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(420908924649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!notification.AccountId.Equals$2(this.Service.CommunityService.Account.Identifier))
                    {
                        /*LivingThing.Core.Frameworks.Client.Components.DataList.RemoteDataList<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>?*/ let __ca5__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel, LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>>>?*/ let __ca6__;
                        /*var*/ let targetMessage = ((__ca5__ = this.dataList) !== null ? ((__ca6__ = __ca5__.ViewDataModels) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$1($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), __ca6__, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                        {
                            return f.Data.Identifier.Equals$2(notification.PostId);
                        }, $epMWMd ??= {"r":262145,"p":[{"n":"f","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).$h}],"n":"","d":2129641,"h":0,"f":17825794})) : null) : null);
                        if (targetMessage !== null)
                        {
                            let $t8, $r8;
                            targetMessage.Data.PostFlags |= 16n;
                            ($t8 = targetMessage.StateChanged(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(420908924649)
            
            //--TRIMMABLE-BOUNDARY-START(416613957353)
            /*void *//*async*/  Service_OnNewChat(/*object?*/ sender, /*CommunityChatMessageModel*/ message)
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(416613957353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (message.Account !== null && !message.Account.Equals$1(this.Service.CommunityService.Account) && message.ParentId.Equals$2(this.thread.Identifier))
                    {
                        let $t9, $r9;
                        let $t10, $r10;
                        ($t9 = this.dataList.Prepend$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatMessageModel), [ message ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        this.newMessages++;
                        if (this.firstUnRead === null)
                        {
                            this.firstUnRead = message;
                        }
                        ($t10 = this.StateChanged(true, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatThread.razor.cs", "Service_OnNewChat", 138), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(416613957353)
            
            //--TRIMMABLE-BOUNDARY-START(304944807657)
            /*Task *//*async*/  Join()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t11, $r11;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304944807657);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t11 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$LCOv.LCFCPS.IPostInteractionRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCFCPS$IPostInteractionRemoteService$Subscribe(this.thread.Identifier);
                    }, $LdojCg ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":26536372}],"n":"","d":2129641,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    this.subscribed = true;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(304944807657)
            
            //--TRIMMABLE-BOUNDARY-START(317829709545)
            /*Task *//*async*/  Leave()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317829709545);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$LCOv.LCFCPS.IPostInteractionRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCFCPS$IPostInteractionRemoteService$UnSubscribe(this.thread.Identifier);
                    }, $UmTIqe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":26536372}],"n":"","d":2129641,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    this.subscribed = false;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(317829709545)
            
            //--TRIMMABLE-BOUNDARY-START(403729055465)
            /*ValueTask */ ScrollToUnRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403729055465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCI.JavaScriptRunnerExtension.ScrollTo(this.JavaScript, this.unreadMarker, false);
            }
            //--TRIMMABLE-BOUNDARY-END(403729055465)
            
            //--TRIMMABLE-BOUNDARY-START(395139120873)
            /*void */ ScrolledToBottom(/*bool*/ bottom)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139120873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bottom)
                {
                    this.newMessages = 0;
                    this.firstUnRead = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(395139120873)
            
            //--TRIMMABLE-BOUNDARY-START(103081344745)
            /*RemoteDataList<CommunityChatMessageModel>?*/ dataList = null;
            //--TRIMMABLE-BOUNDARY-END(103081344745)
            
            //--TRIMMABLE-BOUNDARY-START(343599513321)
            /*CommunityChatMessageModel*/ newMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343599513321)
            
            //--TRIMMABLE-BOUNDARY-START(347894480617)
            /*CommunityChatMessageModel */ get NewMessage()
            {
                return this.newMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(347894480617)
            
            //--TRIMMABLE-BOUNDARY-START(73016573673)
            /*bool */ get CanSubmit()
            {
                return !$.$$.S.String.IsNullOrEmpty(this.newMessage.Post) && $.$$.S.String.Trim.call(this.newMessage.Post).length > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(73016573673)
            
            //--TRIMMABLE-BOUNDARY-START(386549186281)
            /*Task *//*async*/  RemoteNotifySubscribers(/*CommunityChatThreadNotificationModel.Type*/ type)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t14, $r14;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(386549186281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.chatFeature === null || this.chatFeature.AreRemoteActionNotificationsDisabled(this.thread.Identifier) || this.thread.Subscribers === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*var*/ let _event = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel()
                        const $t13 = $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel;
                        const $i13 = new $t13();
                        $i13.$ctor$1();
                        $i13.NotificationType = type;
                        $i13.ThreadId = this.thread.Identifier;
                        $i13.AccountId = this.Service.CommunityService.Account.Identifier;
                        $i13.Date = $.$$.S.DateTime.UtcNow;
                        return $i13;
                    })();
                    ($t14 = this.Service.MessagePipeFactory.LCFCM$IMessagePipeFactory$FeedAsync($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, _event, $.$sl.SL.Enumerable.Select$1($.$LCOv.LCFCPM$1.AccountBaseModel, $.$fPer.LCFCR$3.RoutePath, this.thread.Subscribers, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$fPer.LCFCR$3.RoutePath))().$ctor(this,  (/*s*/ s) =>
                    {
                        return new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3($.$dspc(s.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)));
                    }, $VgqAQi ??= {"r":56789334,"p":[{"n":"s","p":6220212}],"n":"","d":2129641,"h":0,"f":17825794})), null, false, 0), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(386549186281)
            
            //--TRIMMABLE-BOUNDARY-START(309239774953)
            /*DateTime*/ lastTypingNotificationTime;
            //--TRIMMABLE-BOUNDARY-END(309239774953)
            
            //--TRIMMABLE-BOUNDARY-START(369369317097)
            /*Task *//*async*/  PostChanged()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t15, $r15;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(369369317097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((this.thread?.Subscribers ?? null) === null || $.$$.S.TimeSpan.op_LessThan($.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, this.lastTypingNotificationTime), $.$$.S.TimeSpan.FromSeconds$2(15n)))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this.lastTypingNotificationTime = $.$$.S.DateTime.UtcNow;
                    ($t15 = this.RemoteNotifySubscribers(2/*CommunityChatThreadNotificationModel.Type.Typing*/), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(369369317097)
            
            //--TRIMMABLE-BOUNDARY-START(549757943529)
            /*Task *//*async*/  SubmitChat()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(549757943529);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca7__;
                    if ($.$$.S.String.IsNullOrEmpty(this.newMessage.Post) && (((__ca7__ = this.newMessage.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca7__) : false)))
                    {
                        this.newMessage.Post = "_";
                    }
                    if (!this.CanSubmit)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (this.thread === null || this.thread.Identifier.Empty)
                    {
                        if (this.Me !== null && this.Friend !== null)
                        {
                            let $t16, $r16;
                            this.thread = ($t16 = this.Service.InitializePrivateChat(this.Me, this.Friend, this.chatId, true), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                        }
                        else 
                        {
                            let $t17, $r17;
                            this.thread = $.$sl.SL.Enumerable.First$1($.$Bykq.LCCCCM.CommunityChatThreadModel, (($t17 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Bykq.LCCCCM.CommunityChatThreadModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [ (() =>
                            {
                                //new $.$Bykq.LCCCCM.CommunityChatThreadModel()
                                const $t18 = $.$Bykq.LCCCCM.CommunityChatThreadModel;
                                const $i18 = new $t18();
                                $i18.$ctor$7();
                                $i18.Name = this.Title ?? this.chatId;
                                $i18.UniqueId = this.chatId;
                                $i18.ParentId = $.$clone(this.ReferenceId);
                                $i18.Summary = this.newMessage.Summary;
                                $i18.Post = this.newMessage.Post;
                                $i18.ThirdPartyId = this.ThirdPartyId.HasValue ? this.ThirdPartyId : ((this.thread?.ThirdPartyId ?? null) ?? new $.$fPer.LCFCD.DataId().$ctor$2());
                                $i18.Subscribers = $.$$.SRC.RuntimeHelpers.CreateArray($.$LCOv.LCFCPM$1.AccountBaseModel.$type, [ this.Service.CommunityService.Account ], null, null);
                                return $i18;
                            })() ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)))).AsEnumerable());
                        }
                        this.thread.Subscribers ??= (this.ViewModel?.Subscribers ?? null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>?*/ let __ca8__;
                        this.Service.Categories = ((__ca8__ = this.Service.Categories) !== null ? ($.$sl.SL.Enumerable.Concat($.$Bykq.LCCCCM.CommunityChatThreadModel, __ca8__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [this.thread], null, null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [this.thread], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [this.thread], null, null));
                    }
                    this.newMessage.Account = this.Service.CommunityService.Account;
                    this.Service.AddMessage(this.thread, this.newMessage);
                    if (this.dataList === null)
                    {
                        let $t19, $r19;
                        ($t19 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatThread.razor.cs", "SubmitChat", 258), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                    }
                    if (this.dataList !== null)
                    {
                        let $t20, $r20;
                        let $t21, $r21;
                        ($t20 = this.dataList.Prepend$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatMessageModel), [ this.newMessage ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                        ($t21 = this.dataList.ScrollTo(this.newMessage), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                    }
                    this.newMessage = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatMessageModel()
                        const $t22 = $.$Bykq.LCCCCM.CommunityChatMessageModel;
                        const $i22 = new $t22();
                        $i22.$ctor$6();
                        $i22.Name = this.newMessage.Name === "_" ? $.$strNN(this.newMessage.Name) + "_" : "_";
                        $i22.ThirdPartyId = $.$clone(this.ThirdPartyId);
                        return $i22;
                    })();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(549757943529)
            
            //--TRIMMABLE-BOUNDARY-START(545462976233)
            /*ElementReference*/ startMarker;
            //--TRIMMABLE-BOUNDARY-END(545462976233)
            
            //--TRIMMABLE-BOUNDARY-START(120261213929)
            /*ElementReference*/ endMarker;
            //--TRIMMABLE-BOUNDARY-END(120261213929)
            
            //--TRIMMABLE-BOUNDARY-START(399434088169)
            /*Task *//*async*/  ScrollToEnd()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t23, $r23;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399434088169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t23 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.ScrollTo(this.JavaScript, this.endMarker, false), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(399434088169)
            
            //--TRIMMABLE-BOUNDARY-START(90196442857)
            /*Task *//*async*/  Clicked(/*IChatEditorCandidate*/ candidate)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t24, $r24;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90196442857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t24 = candidate.LCCCCSE$IChatEditorCandidate$Clicked(this), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                    this.currentCandidate = candidate;
                    this.moreEditorControls = false;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90196442857)
            
            //--TRIMMABLE-BOUNDARY-START(94491410153)
            /*void */ Complete(/*IChatEditorCandidate*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491410153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.currentCandidate === candidate)
                {
                    this.currentCandidate = null;
                    _ = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatThread.razor.cs", "Complete", 299);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491410153)
            
            //--TRIMMABLE-BOUNDARY-START(335009578729)
            /*bool*/ moreEditorControls = false;
            //--TRIMMABLE-BOUNDARY-END(335009578729)
            
            //--TRIMMABLE-BOUNDARY-START(571232780009)
            /*void */ ToggleMoreEditorControls()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571232780009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.moreEditorControls = !this.moreEditorControls;
            }
            //--TRIMMABLE-BOUNDARY-END(571232780009)
            
            //--TRIMMABLE-BOUNDARY-START(390844153577)
            /*void */ RemoveResource(/*ResourceModel*/ r)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844153577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca9__;
                this.newMessage.Resources = ((__ca9__ = this.newMessage.Resources) !== null ? $.$sl.SL.Enumerable.ToList($.$Iaui.LCFCM.ResourceModel, $.$sl.SL.Enumerable.Where($.$Iaui.LCFCM.ResourceModel, __ca9__, new ($.$$.S.Func$$$($.$Iaui.LCFCM.ResourceModel, $.$$.S.Boolean))().$ctor(this,  (/*res*/ res) =>
                {
                    return !res.Equals$2(r);
                }, $znFzik ??= {"r":262145,"p":[{"n":"res","p":15279446}],"n":"","d":2129641,"h":0,"f":17825794}))) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(390844153577)
            
            //--TRIMMABLE-BOUNDARY-START(356484415209)
            /*Task *//*async*/  OnAfterRenderAsync(/*bool*/ firstRender)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t27, $r27;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(356484415209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (firstRender)
                    {
                        if (this.unreadMarker.Id !== null)
                        {
                            let $t25, $r25;
                            ($t25 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.ScrollTo(this.JavaScript, this.unreadMarker, true), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                        }
                        else if (this.endMarker.Id !== null)
                        {
                            let $t26, $r26;
                            ($t26 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.ScrollTo(this.JavaScript, this.endMarker, true), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                        }
                    }
                    ($t27 = super.OnAfterRenderAsync(firstRender), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(356484415209)
            
            //--TRIMMABLE-BOUNDARY-START(111671279337)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671279337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Service.remove_OnNewChat(new ($.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatMessageModel))().$ctor(this, this.Service_OnNewChat));
                this.Service.remove_OnReadNotification(new ($.$$.S.EventHandler$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel))().$ctor(this, this.Service_OnReadNotification));
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(111671279337)
            
            //--TRIMMABLE-BOUNDARY-START(322124676841)
            /*Task */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124676841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(322124676841)
            
            //--TRIMMABLE-BOUNDARY-START(296354873065)
            /*ValueTask<WireTransportModel<CommunityChatThreadModel>> */ InterceptResponse(/*WireTransportModel<CommunityChatThreadModel>*/ value, /*DataFilter*/ filter, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354873065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!value.Success && value.Message === "Not found")
                {
                    return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), (() =>
                    {
                        //new $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel)()
                        const $t28 = $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel);
                        const $i28 = new $t28();
                        $i28.$ctor$2();
                        $i28.Success = true;
                        $i28.Data = (() =>
                        {
                            //new $.$Bykq.LCCCCM.CommunityChatThreadModel()
                            const $t29 = $.$Bykq.LCCCCM.CommunityChatThreadModel;
                            const $i29 = new $t29();
                            $i29.$ctor$7();
                            return $i29;
                        })();
                        return $i28;
                    })());
                }
                return $.$$.STT.ValueTask.FromResult($.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(296354873065)
            
            //--TRIMMABLE-BOUNDARY-START(330714611433)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714611433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Edit($.$fPer.LCFC.InputType, new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p, /*s*/ s) =>
                {
                    return p.LCFCD$1$IPropertyDescriptor$Name === "Post";
                }, $DWlrNb ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":2129641,"h":0,"f":17825794}), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    /*var*/ let param_o = $.$sle.SLE.Expression.Parameter($.$fPer.LCFCD$1.IPropertyDescriptor.$type, "o");
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5(param_o, "InputType"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ param_o ], null, null));
                }, $dzMJli ??= {"r":38797349,"n":"","d":2129641,"h":0,"f":17825794})).Invoke()), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFC.InputType))().$ctor(this,  (/*o*/ o) =>
                {
                    return o.LCFCD$1$IPropertyDescriptor$InputType;
                }, $klPbFc ??= {"r":47614294,"p":[{"n":"o","p":40733014}],"n":"","d":2129641,"h":0,"f":17825794}));
                propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Edit($.$$.S.String, new ($.$$.S.Func$$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$fPer.LCFCA$1.SchemaType, $.$$.S.Boolean))().$ctor(this,  (/**/ p, /*s*/ s) =>
                {
                    return p.LCFCD$1$IPropertyDescriptor$Name === "Post";
                }, $kQzQJf ??= {"r":262145,"p":[{"n":"p","p":40733014},{"n":"s","p":2722134}],"n":"","d":2129641,"h":0,"f":17825794}), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    /*var*/ let param_o = $.$sle.SLE.Expression.Parameter($.$fPer.LCFCD$1.IPropertyDescriptor.$type, "o");
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5(param_o, "Description"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ param_o ], null, null));
                }, $QVjLVe ??= {"r":38797349,"n":"","d":2129641,"h":0,"f":17825794})).Invoke()), new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.String))().$ctor(this,  (/*o*/ o) =>
                {
                    return "Enter message";
                }, $iAEllf ??= {"r":1310721,"p":[{"n":"o","p":40733014}],"n":"","d":2129641,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(330714611433)
            
            //--TRIMMABLE-BOUNDARY-START(68721606377)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721606377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.thread !== null && this.thread.IsPublicRoom && !$.$$.S.String.IsNullOrEmpty(this.thread.Post))
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "bg-card pd bdt");
                    __builder.AddContent$1(2, $.$ahDc.LCCCS$1.CommunityUtility.PostText(this, this.thread, new $.$$.S.Action().$ctor(this, this.ReadMore), this.readMore, this.Service.CommunityService.IsOwnedByCurrentUser(this.thread), false, false, false, null));
                    __builder.CloseElement();
                }
                __builder.OpenComponent$1($.$hDPm.LCFCCR$1.RemoteDataDetail$$($.$Bykq.LCCCCM.CommunityChatThreadModel), 3);
                __builder.AddComponentParameter(4, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, this.thread));
                __builder.AddComponentParameter(5, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$19(this.chatId, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741857/*PostFilterTypes.UniqueId*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)).WithResponseInterceptor(this, null)));
                __builder.AddComponentParameter(6, "RemoteFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCR$1.RemoteFeatures, 34/*RemoteFeatures.Default*/ | 8/*RemoteFeatures.ResultCaching*/), $.$hDPm.LCFCCR$1.RemoteFeatures));
                __builder.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel)))().$ctor(this, ( (/*_thread*/ _thread) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        this.thread ??= _thread.Data;
                        if ((this.thread?.Identifier.HasValue ?? null) ?? false)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatMessageModel), 8);
                            __builder2.AddComponentParameter(9, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                            __builder2.AddComponentParameter(10, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.thread.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                            __builder2.AddComponentParameter(11, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8192n | 1073741824n | 17592186044416n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder2.AddComponentParameter(12, "RemoteFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCR$1.RemoteFeatures, 34/*RemoteFeatures.Default*/ | 8/*RemoteFeatures.ResultCaching*/), $.$hDPm.LCFCCR$1.RemoteFeatures));
                            __builder2.AddComponentParameter(13, "ul-style", "display:flex;flex-direction:column-reverse;");
                            __builder2.AddComponentParameter(14, "li-class", "pdy");
                            __builder2.AddAttribute$3(15, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel))))().$ctor(this, ( (/*message*/ message) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$qbhX.LCCCCS$1.ChatMessage, 16);
                                    __builder3.AddComponentParameter(17, "Thread", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$qbhX.LCCCCS$1.ChatThread, this));
                                    __builder3.AddComponentParameter(18, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).op_Implicit$1(message)));
                                    __builder3.CloseComponent();
                                }, $mCIHrc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
                            }), $nmGCFb ??= {"r":6881395,"p":[{"n":"message","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).$h}],"n":"","d":2129641,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(19, "MetadataInsertion", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListMetadataInsertContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel))))().$ctor(this, ( (/*insert*/ insert) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    if (insert.After !== null && insert.After.Data === this.firstUnRead)
                                    {
                                        __builder3.AddContent$1(20, insert.Wrapper.Invoke(new ($.$$.S.ValueTuple$$$($.$hDPm.LCFCCD$1.DataListMetadataInsertContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), $.$mac.MAC.RenderFragment))().$ctor$3($.$clone(insert), this.UnreadMarker())));
                                    }
                                    if (insert.After !== null)
                                    {
                                        /*var*/ let after = insert.After.Next;
                                        if (insert.After.Data.DateCreated !== null && (after === null || (after.Data.DateCreated?.Date ?? null) !== (insert.After.Data.DateCreated?.Date ?? null)))
                                        {
                                            __builder3.AddContent$1(21, insert.Wrapper.Invoke(new ($.$$.S.ValueTuple$$$($.$hDPm.LCFCCD$1.DataListMetadataInsertContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), $.$mac.MAC.RenderFragment))().$ctor$3($.$clone(insert), this.DateSeparator($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(insert.After.Data.DateCreated)))));
                                        }
                                    }
                                }, $CmxhQj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
                            }), $cNzrQa ??= {"r":6881395,"p":[{"n":"insert","p":$.$hDPm.LCFCCD$1.DataListMetadataInsertContext$$$($.$Bykq.LCCCCM.CommunityChatMessageModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).$h}],"n":"","d":2129641,"h":0,"f":17825794}));
                            __builder2.AddAttribute$3(22, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 23);
                                __builder3.AddComponentParameter(24, "Message", "No chat messages yet");
                                __builder3.AddComponentParameter(25, "Class", "mg");
                                __builder3.CloseComponent();
                            }), $EKvgPf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794}));
                            __builder2.AddComponentReferenceCapture(26, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.dataList = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatMessageModel));
                            }, $PFhOqj ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":2129641,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                            __builder2.AddMarkupContent(27, "\r\n        ");
                            __builder2.OpenComponent$1($.$hDPm.LCFCCV$1.VisibilityObserver, 28);
                            __builder2.AddComponentParameter(29, "VisibilityChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Boolean), $.$mac.MAC.EventCallback.Factory.Create$8($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this, this.ScrolledToBottom))));
                            __builder2.CloseComponent();
                        }
                        else 
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 30);
                            __builder2.AddComponentParameter(31, "Message", "No chat messages yet");
                            __builder2.AddComponentParameter(32, "Class", "mg");
                            __builder2.CloseComponent();
                        }
                        if (this.Service.LoadErrorMessage !== null)
                        {
                            __builder2.OpenElement(33, "span");
                            __builder2.AddAttribute$5(34, "class", "cl-error text-center");
                            __builder2.AddContent$4(35, this.Service.LoadErrorMessage);
                            __builder2.CloseElement();
                        }
                        if (((this.Features & (4/*ChatThreadFeatures.InDrawer*/)) == (4/*ChatThreadFeatures.InDrawer*/)) || this.Layout === null)
                        {
                            if (this.subscribed)
                            {
                                __builder2.AddContent$1(36, this.ChatEditor());
                            }
                            else 
                            {
                                __builder2.OpenElement(37, "button");
                                __builder2.AddAttribute$5(38, "class", "pd mgx-a bg-highlight wf");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 39, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Join)));
                                __builder2.AddContent$4(40, "Join room to participate");
                                __builder2.CloseElement();
                            }
                        }
                        else 
                        {
                            __builder2.OpenComponent$1($.$mac.MACS.SectionContent, 41);
                            __builder2.AddComponentParameter(42, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.SnapBottomSectionId));
                            __builder2.AddAttribute$3(43, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                            {
                                if (this.subscribed)
                                {
                                    __builder3.AddContent$1(44, this.ChatEditor());
                                }
                                else 
                                {
                                    __builder3.OpenElement(45, "button");
                                    __builder3.AddAttribute$5(46, "class", "pd mgx-a bg-highlight wf");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 47, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Join)));
                                    __builder3.AddContent$4(48, "Join room to participate");
                                    __builder3.CloseElement();
                                }
                            }), $ywkLdc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }
                    }, $agAaQb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
                }), $ReQbVa ??= {"r":6881395,"p":[{"n":"_thread","p":$.$hDPm.LCFCI.ContainerContext$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h}],"n":"","d":2129641,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(49, "\r\n\r\n");
                __builder.OpenElement(50, "div");
                __builder.AddElementReferenceCapture(51, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.endMarker = __value;
                }, $twAISg ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2129641,"h":0,"f":17825794}));
                __builder.CloseElement();
                if (this.Layout !== null)
                {
                    __builder.OpenComponent$1($.$mac.MACS.SectionContent, 52);
                    __builder.AddComponentParameter(53, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.FloatingButtonSectionId));
                    __builder.AddAttribute$3(54, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        if (!this.moreEditorControls && this.currentCandidate === null)
                        {
                            if (this.newMessages > 0)
                            {
                                __builder2.OpenElement(55, "div");
                                __builder2.AddAttribute$5(56, "class", "pos-rel");
                                __builder2.OpenElement(57, "button");
                                __builder2.AddAttribute$5(58, "class", "mdi mdi-chevron-down wx-03 hx-03 round bg-card bd");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 59, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.ScrollToUnRead)));
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(60, "\r\n                    ");
                                __builder2.OpenElement(61, "small");
                                __builder2.AddAttribute$5(62, "class", "mgl--3 mgt--2 bg-primary round pos-abs l-0 t-0 wx-02 hx-02 flex fsz-10");
                                __builder2.OpenElement(63, "span");
                                __builder2.AddAttribute$5(64, "class", "mg-a");
                                __builder2.AddContent$3(65, $.$box(this.newMessages, $.$$.S.Int32));
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                            else 
                            {
                                __builder2.OpenElement(66, "button");
                                __builder2.AddAttribute$5(67, "class", "mdi mdi-chevron-down bg-primary round fsz-20 hx-05 wx-05");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 68, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ScrollToEnd)));
                                __builder2.CloseElement();
                            }
                        }
                    }), $uwueXk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721606377)
            
            //--TRIMMABLE-BOUNDARY-START(107376312041)
            /*RenderFragment */ DateSeparator(/*DateTime*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376312041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(69, "div");
                    __builder2.AddAttribute$5(70, "class", "flex");
                    __builder2.AddMarkupContent(71, "<div class=\"mgy-a fill\"></div>\r\n                ");
                    __builder2.OpenElement(72, "small");
                    __builder2.AddAttribute$5(73, "class", "corner-5 pd-2 bg-primary-01");
                    __builder2.AddContent$4(74, $.$fPer.LCFCDC.DateTimeExtension.Pronounce$1(this.ToLocalTime(date)));
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(75, "\r\n                <div class=\"mgy-a fill\"></div>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(76, "\r\n");
                }, $iZtVGh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(107376312041)
            
            //--TRIMMABLE-BOUNDARY-START(584117681897)
            /*RenderFragment */ UnreadMarker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584117681897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(77, "div");
                    __builder2.AddAttribute$5(78, "class", "flex");
                    __builder2.AddElementReferenceCapture(79, new ($.$$.S.Action$$($.$mac.MAC.ElementReference))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        this.unreadMarker = __value;
                    }, $dWMdMg ??= {"r":65537,"p":[{"n":"__value","p":1900659}],"n":"","d":2129641,"h":0,"f":17825794}));
                    __builder2.AddMarkupContent(80, "<div class=\"mgy-a fill\"></div>\r\n        ");
                    __builder2.OpenElement(81, "small");
                    __builder2.AddAttribute$5(82, "class", "corner-5 pd-2 bg-primary-01");
                    __builder2.AddContent$3(83, $.$box(this.newMessages, $.$$.S.Int32));
                    __builder2.AddContent$4(84, " Unread");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(85, "\r\n        <div class=\"mgy-a fill\"></div>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(86, "\r\n");
                }, $Kewbbh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(584117681897)
            
            //--TRIMMABLE-BOUNDARY-START(77311540969)
            /*RenderFragment */ ChatEditor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311540969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$macw.MACF.EditForm, 87);
                    __builder2.AddComponentParameter(88, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.newMessage));
                    __builder2.AddComponentParameter(89, "class", "stack right pd bg-card");
                    __builder2.AddComponentParameter(90, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macf.MACF.EditContext), $.$mac.MAC.EventCallback.Factory.Create$9($.$macf.MACF.EditContext, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.SubmitChat))));
                    __builder2.AddAttribute$3(91, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            if (this.moreEditorControls)
                            {
                                /*int*/ let i = 1;
                                __builder3.OpenElement(92, "div");
                                __builder3.AddAttribute$5(93, "class", "grid gap-1 colm-1 mgb");
                                let $en30 = this.Editors.SCG$IEnumerable$$$GetEnumerator();
                                while ($en30.SC$1$IEnumerator$MoveNext())
                                {
                                    let c = $en30.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let candidate = c;
                                        __builder3.OpenElement(94, "button");
                                        __builder3.AddAttribute$5(95, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("text-center" + " pd") + " stack") + " bg-transparent") + " bd") + " corner") + " cl-chart" + ($.$box(i, $.$$.S.Int32)));
                                        __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 96, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                        {
                                            return this.Clicked(candidate);
                                        }, $fdtRVj ??= {"r":178454529,"n":"","d":2129641,"h":0,"f":17825794})));
                                        __builder3.OpenElement(97, "span");
                                        __builder3.AddAttribute$5(98, "class", $.$strNN($.$strNN((candidate.LCFC$IDisplayable$Icon).ToString()) + " fsz-40") + " mgx-a");
                                        __builder3.CloseElement();
                                        __builder3.AddMarkupContent(99, "\r\n                    ");
                                        __builder3.OpenElement(100, "span");
                                        __builder3.AddContent$4(101, candidate.LCFC$IDisplayable$Title);
                                        __builder3.CloseElement();
                                        __builder3.CloseElement();
                                        i++;
                                    }
                                }
                                __builder3.CloseElement();
                            }
                            __builder3.AddContent$1(102, (this.currentCandidate?.LCCCCSE$IChatEditorCandidate$GetView(this) ?? null));
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca1__;
                            if ((__ca1__ = this.newMessage.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca1__) : false)
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.MediaTiles, 103);
                                __builder3.AddComponentParameter(104, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), this.newMessage.Resources));
                                __builder3.AddComponentParameter(105, "Class", "mgb");
                                __builder3.CloseComponent();
                            }
                            __builder3.OpenElement(106, "div");
                            __builder3.AddAttribute$5(107, "class", "flex");
                            __builder3.OpenElement(108, "div");
                            __builder3.AddAttribute$5(109, "class", "flex fill pos-rel");
                            $.$qbhX._LCCCCSC.TypeInference.CreateInputEditor_0($.$$.S.String, __builder3, 110, 111, 11n, 112, "Add Reply", 113, "mahx-1 scroll bg-primary-01 corner-5", 114, 4131/*InputEditorFeatures.Default*/ | 2048/*InputEditorFeatures.EventOnKeyInput*/, 115, (1688849860263934n & ~1688849860263932n) | -9223372036854775808n | 8n | 4294967296n | 35184372088832n | 1099511627776n | 2251799813685248n, 116, this.newMessage.Post, 117, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$2($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredBindSetter$1($.$$.S.String, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.newMessage.Post = __value;
                                return $.$mac.MACC.RuntimeHelpers.InvokeAsynchronousDelegate$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.PostChanged));
                            }, $XDptQh ??= {"r":178454529,"p":[{"n":"__value","p":1310721}],"n":"","d":2129641,"h":0,"f":17825794}), this.newMessage.Post), this.newMessage.Post)), 118, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "newMessage"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $uaZWLa ??= {"r":38797349,"n":"","d":2129641,"h":0,"f":17825794})).Invoke()));
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>?*/ let __ca2__;
                            if (!this.moreEditorControls && (((__ca2__ = this.newMessage.Resources) !== null ? $.$sl.SL.Enumerable.Any$1($.$Iaui.LCFCM.ResourceModel, __ca2__) : false)))
                            {
                                __builder3.OpenElement(119, "div");
                                __builder3.AddAttribute$5(120, "class", "pos-abs t-0 r-0 b-0 flex");
                                let $en31 = $.$sl.SL.Enumerable.Take($.$Iaui.LCFCM.ResourceModel, this.newMessage.Resources, 1).SCG$IEnumerable$$$GetEnumerator();
                                while ($en31.SC$1$IEnumerator$MoveNext())
                                {
                                    let resource = $en31.SCG$IEnumerator$$$Current;
                                    {
                                        __builder3.OpenElement(121, "div");
                                        __builder3.AddAttribute$5(122, "class", "bg-card bd stack clip pos-rel animate round");
                                        __builder3.AddAttribute$5(123, "style", "width:40px");
                                        __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 124, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleMoreEditorControls)));
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCB$4.ButtonCommand$$($.$Iaui.LCFCM.ResourceModel), 125);
                                        __builder3.AddComponentParameter(126, "Class", "pos-abs r-0 t-0 fade-in-hover mdi mdi-close");
                                        __builder3.AddComponentParameter(127, "CommandParameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, resource));
                                        __builder3.AddComponentParameter(128, "Command", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$Iaui.LCFCM.ResourceModel), $.$mac.MAC.EventCallback.Factory.Create$8($.$Iaui.LCFCM.ResourceModel, this, new ($.$$.S.Action$$($.$Iaui.LCFCM.ResourceModel))().$ctor(this, this.RemoveResource))));
                                        __builder3.AddComponentParameter(129, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                                        __builder3.AddComponentParameter(130, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                                        __builder3.CloseComponent();
                                        __builder3.AddMarkupContent(131, "\r\n                                ");
                                        __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 132);
                                        __builder3.AddComponentParameter(133, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, resource));
                                        __builder3.AddComponentParameter(134, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 40), $.$$.S.Int32));
                                        __builder3.AddComponentParameter(135, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                        __builder3.CloseComponent();
                                        __builder3.CloseElement();
                                    }
                                }
                                __builder3.CloseElement();
                            }
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(136, "\r\n            ");
                            __builder3.OpenElement(137, "div");
                            __builder3.AddAttribute$5(138, "class", "flex side ");
                            __builder3.OpenElement(139, "button");
                            __builder3.AddAttribute$5(140, "title", "More");
                            __builder3.AddAttribute$5(141, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN("lt" + " button") + " theme-primary") + " fsz-30") + " mdi") + " mdi-") + $.$strNN((!this.moreEditorControls ? "plus-circle" : "close"))) + " mgx-a") + " bd-0") + " bd-primary") + " cl-primary") + " bg-transparent") + " bg-accessible") + " mgt-a");
                            __builder3.AddAttribute$5(142, "type", "button");
                            __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 143, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ToggleMoreEditorControls)));
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(144, "\r\n                <button title=\"Send\" class=\"lt button theme-primary fsz-30 mdi mdi-send mgx-a bd-0 bd-primary cl-primary bg-transparent bg-accessible mgt-a\" type=\"submit\"></button>");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $kkxFuj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
                    }), $ZvQgWk ??= {"r":6881395,"p":[{"n":"context","p":131188}],"n":"","d":2129641,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }, $trkdda ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":2129641,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(77311540969)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4335831382)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifier.ModifyDescriptor(LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptorModifierBuilder)
            LCFCD$1$IPropertyDescriptorModifier$ModifyDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4335831382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ModifyDescriptor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4335831382)
            
            //--TRIMMABLE-BOUNDARY-START(4312303958)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFilterResponseInterceptor<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>>.InterceptResponse(LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>, LivingThing.Core.Frameworks.Common.Data.DataFilter, object?)
            [`LCFCD$IDataFilterResponseInterceptor$LivingThing$Core$Frameworks$Common$Data$WireTransportModel$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$$InterceptResponse`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312303958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InterceptResponse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312303958)
            
            //--TRIMMABLE-BOUNDARY-START(64426639081)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426639081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426639081)
            
            //--TRIMMABLE-BOUNDARY-START(64426639081)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(64426639081)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(313534742249)
                this.Layout = null;
                //--TRIMMABLE-BOUNDARY-END(313534742249)
                
                //--TRIMMABLE-BOUNDARY-START(339304546025)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(339304546025)
                
                //--TRIMMABLE-BOUNDARY-START(412318990057)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(412318990057)
                
                //--TRIMMABLE-BOUNDARY-START(408024022761)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(408024022761)
                
                //--TRIMMABLE-BOUNDARY-START(115966246633)
                this.Editors = null;
                //--TRIMMABLE-BOUNDARY-END(115966246633)
                
                //--TRIMMABLE-BOUNDARY-START(300649840361)
                this.JavaScript = null;
                //--TRIMMABLE-BOUNDARY-END(300649840361)
                
                //--TRIMMABLE-BOUNDARY-START(558347878121)
                this.ThirdPartyId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(558347878121)
                
                //--TRIMMABLE-BOUNDARY-START(382254218985)
                this.ReferenceId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(382254218985)
                
                //--TRIMMABLE-BOUNDARY-START(124556181225)
                this.Features = 0;
                //--TRIMMABLE-BOUNDARY-END(124556181225)
                
                //--TRIMMABLE-BOUNDARY-START(579822714601)
                this.unreadMarker = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(579822714601)
                
                //--TRIMMABLE-BOUNDARY-START(85901475561)
                this.chatId = null;
                //--TRIMMABLE-BOUNDARY-END(85901475561)
                
                //--TRIMMABLE-BOUNDARY-START(343599513321)
                this.newMessage = null;
                //--TRIMMABLE-BOUNDARY-END(343599513321)
                
                //--TRIMMABLE-BOUNDARY-START(309239774953)
                this.lastTypingNotificationTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(309239774953)
                
                //--TRIMMABLE-BOUNDARY-START(545462976233)
                this.startMarker = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(545462976233)
                
                //--TRIMMABLE-BOUNDARY-START(120261213929)
                this.endMarker = $.$default($.$mac.MAC.ElementReference);
                //--TRIMMABLE-BOUNDARY-END(120261213929)
                
            }
            static $h = 2129641;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$Bykq.LCCCCM.CommunityChatThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(365074349801),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236225330921,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 2129641,
      "h": 365074349801,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365074349801),
//--TRIMMABLE-BOUNDARY-START(313534742249),
    {
      "p": 1257545,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865592553,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481038466793,
        "f": 83886081
      },
      "n": "Layout",
      "d": 2129641,
      "h": 313534742249,
      "f": 2097153,
      "a": [
        {
          "t": 524403,
          "c": 8590458995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(313534742249),
//--TRIMMABLE-BOUNDARY-START(339304546025),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045461737,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 498218335977,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 2129641,
      "h": 339304546025,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339304546025),
//--TRIMMABLE-BOUNDARY-START(412318990057),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261995134697,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 523988139753,
        "f": 83886081
      },
      "n": "Service",
      "d": 2129641,
      "h": 412318990057,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(412318990057),
//--TRIMMABLE-BOUNDARY-START(408024022761),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253405200105,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 515398205161,
        "f": 83886081
      },
      "n": "Server",
      "d": 2129641,
      "h": 408024022761,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408024022761),
//--TRIMMABLE-BOUNDARY-START(115966246633),
    {
      "p": $.$$.SCG.IEnumerable$$($.$qbhX.LCCCCSE.IChatEditorCandidate).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325985001,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429498859241,
        "f": 83886081
      },
      "n": "Editors",
      "d": 2129641,
      "h": 115966246633,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115966246633),
//--TRIMMABLE-BOUNDARY-START(300649840361),
    {
      "p": 64509610,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275657961,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472448532201,
        "f": 83886081
      },
      "n": "JavaScript",
      "d": 2129641,
      "h": 300649840361,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(300649840361),
//--TRIMMABLE-BOUNDARY-START(326419644137),
    {
      "p": 6220212,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455527145,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 489628401385,
        "f": 83886081
      },
      "n": "Me",
      "d": 2129641,
      "h": 326419644137,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(326419644137),
//--TRIMMABLE-BOUNDARY-START(133146115817),
    {
      "p": 6220212,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505854185,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446678728425,
        "f": 83886081
      },
      "n": "Friend",
      "d": 2129641,
      "h": 133146115817,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133146115817),
//--TRIMMABLE-BOUNDARY-START(558347878121),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270585069289,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 532578074345,
        "f": 83886081
      },
      "n": "ThirdPartyId",
      "d": 2129641,
      "h": 558347878121,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(558347878121),
//--TRIMMABLE-BOUNDARY-START(382254218985),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244815265513,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 506808270569,
        "f": 83886081
      },
      "n": "ReferenceId",
      "d": 2129641,
      "h": 382254218985,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(382254218985),
//--TRIMMABLE-BOUNDARY-START(566937812713),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279175003881,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 541168008937,
        "f": 83886081
      },
      "n": "Title",
      "d": 2129641,
      "h": 566937812713,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(566937812713),
//--TRIMMABLE-BOUNDARY-START(124556181225),
    {
      "p": 62477994,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915919593,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438088793833,
        "f": 83886081
      },
      "n": "Features",
      "d": 2129641,
      "h": 124556181225,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124556181225),
//--TRIMMABLE-BOUNDARY-START(283469971177),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095788777,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455268663017,
        "f": 83886081
      },
      "n": "InitialChat",
      "d": 2129641,
      "h": 283469971177,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283469971177),
//--TRIMMABLE-BOUNDARY-START(287764938473),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685723369,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463858597609,
        "f": 83886081
      },
      "n": "InitialMessage",
      "d": 2129641,
      "h": 287764938473,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287764938473),
//--TRIMMABLE-BOUNDARY-START(347894480617),
    {
      "p": 560891,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227635396329,
        "f": 50331656
      },
      "n": "NewMessage",
      "d": 2129641,
      "h": 347894480617,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(347894480617),
//--TRIMMABLE-BOUNDARY-START(73016573673),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736050409,
        "f": 50331650
      },
      "n": "CanSubmit",
      "d": 2129641,
      "h": 73016573673,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(73016573673)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(575527747305),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 2129641,
      "h": 575527747305,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(575527747305),
//--TRIMMABLE-BOUNDARY-START(292059905769),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 2129641,
      "h": 292059905769,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(292059905769),
//--TRIMMABLE-BOUNDARY-START(377959251689),
    {
      "r": 65537,
      "n": "ReadMore",
      "d": 2129641,
      "h": 377959251689,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(377959251689),
//--TRIMMABLE-BOUNDARY-START(360779382505),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 2129641,
      "h": 360779382505,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(360779382505),
//--TRIMMABLE-BOUNDARY-START(420908924649),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "notification",
          "p": 17951156
        }
      ],
      "n": "Service_OnReadNotification",
      "d": 2129641,
      "h": 420908924649,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(420908924649),
//--TRIMMABLE-BOUNDARY-START(416613957353),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "message",
          "p": 560891
        }
      ],
      "n": "Service_OnNewChat",
      "d": 2129641,
      "h": 416613957353,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(416613957353),
//--TRIMMABLE-BOUNDARY-START(304944807657),
    {
      "r": 178454529,
      "n": "Join",
      "d": 2129641,
      "h": 304944807657,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(304944807657),
//--TRIMMABLE-BOUNDARY-START(317829709545),
    {
      "r": 178454529,
      "n": "Leave",
      "d": 2129641,
      "h": 317829709545,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(317829709545),
//--TRIMMABLE-BOUNDARY-START(403729055465),
    {
      "r": 181338113,
      "n": "ScrollToUnRead",
      "d": 2129641,
      "h": 403729055465,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(403729055465),
//--TRIMMABLE-BOUNDARY-START(395139120873),
    {
      "r": 65537,
      "p": [
        {
          "n": "bottom",
          "p": 262145
        }
      ],
      "n": "ScrolledToBottom",
      "d": 2129641,
      "h": 395139120873,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395139120873),
//--TRIMMABLE-BOUNDARY-START(386549186281),
    {
      "r": 178454529,
      "p": [
        {
          "n": "type",
          "p": 1412859
        }
      ],
      "n": "RemoteNotifySubscribers",
      "d": 2129641,
      "h": 386549186281,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(386549186281),
//--TRIMMABLE-BOUNDARY-START(369369317097),
    {
      "r": 178454529,
      "n": "PostChanged",
      "d": 2129641,
      "h": 369369317097,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(369369317097),
//--TRIMMABLE-BOUNDARY-START(549757943529),
    {
      "r": 178454529,
      "n": "SubmitChat",
      "d": 2129641,
      "h": 549757943529,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(549757943529),
//--TRIMMABLE-BOUNDARY-START(399434088169),
    {
      "r": 178454529,
      "n": "ScrollToEnd",
      "d": 2129641,
      "h": 399434088169,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(399434088169),
//--TRIMMABLE-BOUNDARY-START(90196442857),
    {
      "r": 178454529,
      "p": [
        {
          "n": "candidate",
          "p": 2326249
        }
      ],
      "n": "Clicked",
      "d": 2129641,
      "h": 90196442857,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90196442857),
//--TRIMMABLE-BOUNDARY-START(94491410153),
    {
      "r": 65537,
      "p": [
        {
          "n": "candidate",
          "p": 2326249
        }
      ],
      "n": "Complete",
      "d": 2129641,
      "h": 94491410153,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94491410153),
//--TRIMMABLE-BOUNDARY-START(571232780009),
    {
      "r": 65537,
      "n": "ToggleMoreEditorControls",
      "d": 2129641,
      "h": 571232780009,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(571232780009),
//--TRIMMABLE-BOUNDARY-START(390844153577),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 15279446
        }
      ],
      "n": "RemoveResource",
      "d": 2129641,
      "h": 390844153577,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390844153577),
//--TRIMMABLE-BOUNDARY-START(356484415209),
    {
      "r": 178454529,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRenderAsync",
      "d": 2129641,
      "h": 356484415209,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(356484415209),
//--TRIMMABLE-BOUNDARY-START(111671279337),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2129641,
      "h": 111671279337,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111671279337),
//--TRIMMABLE-BOUNDARY-START(322124676841),
    {
      "r": 178454529,
      "n": "Load",
      "d": 2129641,
      "h": 322124676841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322124676841),
//--TRIMMABLE-BOUNDARY-START(296354873065),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "InterceptResponse",
      "d": 2129641,
      "h": 296354873065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296354873065),
//--TRIMMABLE-BOUNDARY-START(330714611433),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 2129641,
      "h": 330714611433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330714611433),
//--TRIMMABLE-BOUNDARY-START(68721606377),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 2129641,
      "h": 68721606377,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68721606377),
//--TRIMMABLE-BOUNDARY-START(107376312041),
    {
      "r": 6881395,
      "p": [
        {
          "n": "date",
          "p": 65994753
        }
      ],
      "n": "DateSeparator",
      "d": 2129641,
      "h": 107376312041,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107376312041),
//--TRIMMABLE-BOUNDARY-START(584117681897),
    {
      "r": 6881395,
      "n": "UnreadMarker",
      "d": 2129641,
      "h": 584117681897,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(584117681897),
//--TRIMMABLE-BOUNDARY-START(77311540969),
    {
      "r": 6881395,
      "n": "ChatEditor",
      "d": 2129641,
      "h": 77311540969,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77311540969)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81606508265),
    {
      "t": 298747,
      "n": "chatFeature",
      "d": 2129641,
      "h": 81606508265,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81606508265),
//--TRIMMABLE-BOUNDARY-START(98786377449),
    {
      "t": 2326249,
      "n": "currentCandidate",
      "d": 2129641,
      "h": 98786377449,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786377449),
//--TRIMMABLE-BOUNDARY-START(579822714601),
    {
      "t": 1900659,
      "n": "unreadMarker",
      "d": 2129641,
      "h": 579822714601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(579822714601),
//--TRIMMABLE-BOUNDARY-START(128851148521),
    {
      "t": 560891,
      "n": "firstUnRead",
      "d": 2129641,
      "h": 128851148521,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128851148521),
//--TRIMMABLE-BOUNDARY-START(352189447913),
    {
      "t": 655361,
      "n": "newMessages",
      "d": 2129641,
      "h": 352189447913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(352189447913),
//--TRIMMABLE-BOUNDARY-START(85901475561),
    {
      "t": 1310721,
      "n": "chatId",
      "d": 2129641,
      "h": 85901475561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85901475561),
//--TRIMMABLE-BOUNDARY-START(562642845417),
    {
      "t": 1085179,
      "n": "thread",
      "d": 2129641,
      "h": 562642845417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(562642845417),
//--TRIMMABLE-BOUNDARY-START(554052910825),
    {
      "t": 262145,
      "n": "subscribed",
      "d": 2129641,
      "h": 554052910825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(554052910825),
//--TRIMMABLE-BOUNDARY-START(373664284393),
    {
      "t": 262145,
      "n": "readMore",
      "d": 2129641,
      "h": 373664284393,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(373664284393),
//--TRIMMABLE-BOUNDARY-START(103081344745),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$h,
      "n": "dataList",
      "d": 2129641,
      "h": 103081344745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103081344745),
//--TRIMMABLE-BOUNDARY-START(343599513321),
    {
      "t": 560891,
      "n": "newMessage",
      "d": 2129641,
      "h": 343599513321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(343599513321),
//--TRIMMABLE-BOUNDARY-START(309239774953),
    {
      "t": 65994753,
      "n": "lastTypingNotificationTime",
      "d": 2129641,
      "h": 309239774953,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(309239774953),
//--TRIMMABLE-BOUNDARY-START(545462976233),
    {
      "t": 1900659,
      "n": "startMarker",
      "d": 2129641,
      "h": 545462976233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(545462976233),
//--TRIMMABLE-BOUNDARY-START(120261213929),
    {
      "t": 1900659,
      "n": "endMarker",
      "d": 2129641,
      "h": 120261213929,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120261213929),
//--TRIMMABLE-BOUNDARY-START(335009578729),
    {
      "t": 262145,
      "n": "moreEditorControls",
      "d": 2129641,
      "h": 335009578729,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(335009578729)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64426639081),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2129641,
      "h": 64426639081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426639081)
  ],
  "h": 2129641
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$hDPm.LCFCCF$2.IFormFieldEditPropertyController, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$hDPm.LCFCCF$2.IFormController, $.$fPer.LCFCD.IDataFilterResponseInterceptor$$($.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel)), $.$fPer.LCFCD.IDataFilterResponseInterceptor, $.$hDPm.LCFCCI$1.IInputController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.ChatThread`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatThread`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2129641)
        
        

        //--TRIMMABLE-BOUNDARY-START(1998569)
        $asm.$cls(`$qbhX.LCCCCS$1.ChatMessageFluentBuilder<,>`, (TBuilder, TComponent) => $asm.$gt(`$qbhX.LCCCCS$1.ChatMessageFluentBuilder<,>`, [TBuilder, TComponent], ($self) => class ChatMessageFluentBuilder$$$ extends $.$hDPm.LCFCC$1.BaseParameterizedComponentFluentBuilder$$$$(TBuilder, TComponent, $.$Bykq.LCCCCM.CommunityChatMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17181867753)
            /*TBuilder */ Thread(/*LivingThing.Core.Community.Chat.Client.Shared.ChatThread*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181867753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._target.Thread = value;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181867753)
            
            //--TRIMMABLE-BOUNDARY-START(12886900457)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886900457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.Reset();
                this._target.Thread = null;
            }
            //--TRIMMABLE-BOUNDARY-END(12886900457)
            
            //--TRIMMABLE-BOUNDARY-START(8591933161)
            /*TBuilder */ Initialize(/*ComponentBase?*/ caller, /*IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591933161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._target.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, provider);
                return super.Initialize(caller, provider);
            }
            //--TRIMMABLE-BOUNDARY-END(8591933161)
            
            //--TRIMMABLE-BOUNDARY-START(4296965865)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296965865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296965865)
            
            //--TRIMMABLE-BOUNDARY-START(4296965865)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4296965865)
            
            static $H = 1998569;
            static $h = 1998569;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponentFluentBuilder$$$$(TBuilder, TComponent, $.$Bykq.LCCCCM.CommunityChatMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181867753),
    {
      "r": TBuilder?.$h??1572864,
      "p": [
        {
          "n": "value",
          "p": 2129641
        }
      ],
      "n": "Thread",
      "d": this.$h,
      "H": 17181867753,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181867753),
//--TRIMMABLE-BOUNDARY-START(12886900457),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "H": 12886900457,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886900457),
//--TRIMMABLE-BOUNDARY-START(8591933161),
    {
      "r": TBuilder?.$h??1572864,
      "p": [
        {
          "n": "caller",
          "p": 1245299
        },
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "Initialize",
      "d": this.$h,
      "H": 8591933161,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591933161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296965865),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296965865,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296965865)
  ],
  "s": [
    {
      "h": TBuilder?.$h??1572864,
      "n": "TBuilder",
      "f": 4,
      "c": [this.$h
      ]
    },
    {
      "h": TComponent?.$h??1638400,
      "n": "TComponent",
      "f": 4,
      "c": [1867497,60774058
      ]
    }
  ],
  "r": 2,
  "H": 1998569,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IFluentComponentBuilder$$(TComponent) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.ChatMessageFluentBuilder<${TBuilder?.$fullName},${TComponent?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatMessageFluentBuilder$${TBuilder?.$getFullName(separator)}$${TComponent?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1998569)
        
        

        //--TRIMMABLE-BOUNDARY-START(1343209)
        $asm.$cls(`$qbhX.LCCCCP.ChatThreadPage`, ($self) => class ChatThreadPage extends $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$Bykq.LCCCCM.CommunityChatThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(73015787241)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73015787241)
            
            //--TRIMMABLE-BOUNDARY-START(55835918057)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(55835918057)
            
            //--TRIMMABLE-BOUNDARY-START(60130885353)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130885353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130885353)
            
            //--TRIMMABLE-BOUNDARY-START(68720819945)
            /*void */ ProfileClicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720819945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation.NavigateTo$1(`Chat/Settings/${$.$strNN($.$dspc(this.Parameter.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(this.Parameter.Title)}`, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(68720819945)
            
            //--TRIMMABLE-BOUNDARY-START(51540950761)
            /*void */ NavigateBack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540950761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation.NavigateTo$1("Chat", false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(51540950761)
            
            //--TRIMMABLE-BOUNDARY-START(64425852649)
            /*string */ get OptimizedComponentName()
            {
                return "chatthreadpage applicationlayoutpage applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(64425852649)
            
            //--TRIMMABLE-BOUNDARY-START(47245983465)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245983465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47245983465)
            
            //--TRIMMABLE-BOUNDARY-START(17181212393)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181212393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let respondent = this.Parameter.GetRespondent(this.Service.CommunityService.Account);
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.TitleSectionId));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(3, this.Parameter.IsPublicRoom ? this.Parameter.Title : (respondent?.Title ?? null));
                }), $nBHuTb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343209,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (respondent !== null || this.Parameter.IsPublicRoom)
                {
                    __builder.OpenComponent$1($.$mac.MACS.SectionContent, 4);
                    __builder.AddComponentParameter(5, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.IconSectionId));
                    __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        if (this.Parameter.IsPublicRoom)
                        {
                            __builder2.OpenElement(7, "div");
                            __builder2.AddAttribute$5(8, "class", "hx-03 wx-03 hx-03 wx-03 pos-rel round bd bd-success bdw-1");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 9, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.ProfileClicked)));
                            __builder2.OpenElement(10, "div");
                            __builder2.AddAttribute$5(11, "style", $.$strNN("background-image:url('" + $.$strNN(((this.Parameter.Icon?.FullPath ?? null)))) + "');");
                            __builder2.AddAttribute$5(12, "class", "lt media round clip flex mgc-a bg-dark hf wf bg-fill bg-no-repeat");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        else if (respondent !== null)
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 13);
                            __builder2.AddComponentParameter(14, "Class", "hx-03 wx-03");
                            __builder2.AddComponentParameter(15, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 30), $.$$.S.Int32));
                            __builder2.AddComponentParameter(16, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, respondent));
                            __builder2.AddComponentParameter(17, "OnClicked", new $.$$.S.Action().$ctor(this, (this.ProfileClicked)));
                            __builder2.CloseComponent();
                        }
                    }), $kFPUDh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343209,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 18);
                __builder.AddComponentParameter(19, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.ToolBarControlsSectionId));
                __builder.AddAttribute$3(20, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(21, "li");
                    __builder2.AddAttribute$5(22, "class", "menuitem");
                    __builder2.OpenElement(23, "a");
                    __builder2.AddAttribute$5(24, "href", $.$strNN($.$strNN("Chat/Settings/" + $.$strNN($.$dspc((this.Parameter.Identifier.Id), $.$$.S.Object, ($t) => $t.ToString))) + "/") + $.$strNN((this.Parameter.Title)));
                    __builder2.AddAttribute$5(25, "class", "mdi mdi-cogs");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (!this.Parameter.IsPublicRoom && this.Service.CommunityService.IsOwnedByCurrentUser(this.Parameter))
                    {
                        __builder2.OpenElement(26, "li");
                        __builder2.AddAttribute$5(27, "class", "menuitem");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.ServerButton$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel)), 28);
                        __builder2.AddComponentParameter(29, "ServiceMethod", new ($.$uvJL.LCFCR.ServiceMethod$$($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel)))().$ctor(this, ( (/**/ s) =>
                        {
                            return s.LCFCD$IDeleteDataService$$$Delete($.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [ this.Parameter ], null, null));
                        }), $qHjAgd ??= {"r":178454529,"p":[{"n":"s","p":$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h}],"n":"","d":1343209,"h":0,"f":17825794}));
                        __builder2.AddComponentParameter(30, "Class", "mdi mdi-delete");
                        __builder2.AddComponentParameter(31, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 8192/*ButtonFeatures.LoadingOnClick*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(32, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Error));
                        __builder2.AddComponentParameter(33, "Confirm", "Delete Chat");
                        __builder2.AddComponentParameter(34, "ConfirmMessage", "This will delete this chat and its messages for you and all subscribers");
                        __builder2.AddComponentParameter(35, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.NavigateBack))));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                }), $ioyhck ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343209,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(36, "\r\n\r\n\r\n");
                __builder.OpenComponent$1($.$qbhX.LCCCCS$1.ChatThread, 37);
                __builder.AddComponentParameter(38, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Bykq.LCCCCM.CommunityChatThreadModel, this.Parameter));
                __builder.AddComponentParameter(39, "ThirdPartyId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataId, this.Parameter.ThirdPartyId));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17181212393)
            
            //--TRIMMABLE-BOUNDARY-START(12886245097)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886245097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886245097)
            
            //--TRIMMABLE-BOUNDARY-START(12886245097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12886245097)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015787241)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73015787241)
                
                //--TRIMMABLE-BOUNDARY-START(55835918057)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(55835918057)
                
            }
            static $h = 1343209;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$Bykq.LCCCCM.CommunityChatThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015787241),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951016169,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195656425,
        "f": 83886081
      },
      "n": "Service",
      "d": 1343209,
      "h": 73015787241,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015787241),
//--TRIMMABLE-BOUNDARY-START(55835918057),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771146985,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605721833,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1343209,
      "h": 55835918057,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835918057),
//--TRIMMABLE-BOUNDARY-START(64425852649),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361081577,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1343209,
      "h": 64425852649,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425852649)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130885353),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1343209,
      "h": 60130885353,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(60130885353),
//--TRIMMABLE-BOUNDARY-START(68720819945),
    {
      "r": 65537,
      "n": "ProfileClicked",
      "d": 1343209,
      "h": 68720819945,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720819945),
//--TRIMMABLE-BOUNDARY-START(51540950761),
    {
      "r": 65537,
      "n": "NavigateBack",
      "d": 1343209,
      "h": 51540950761,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540950761),
//--TRIMMABLE-BOUNDARY-START(47245983465),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1343209,
      "h": 47245983465,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245983465),
//--TRIMMABLE-BOUNDARY-START(17181212393),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1343209,
      "h": 17181212393,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181212393)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886245097),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1343209,
      "h": 12886245097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886245097)
  ],
  "h": 1343209,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 1,
          "t": 655361
        },
        {
          "v": "Chat",
          "t": 1310721
        },
        {
          "v": "Chat",
          "t": 1310721
        },
        {
          "v": "mdi mdi-message",
          "t": 1310721
        },
        {
          "v": 25839013008,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat/Thread/{ParameterKey}/{*catchAll}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$fPer.LCFCD.IOpenGraphDataProviderFactory, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatThreadPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatThreadPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1343209)
        
        

        //--TRIMMABLE-BOUNDARY-START(1081065)
        $asm.$cls(`$qbhX.LCCCCP.ChatSettings`, ($self) => class ChatSettings extends $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$Bykq.LCCCCM.CommunityChatThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(133145067241)
            /*string */ get OptimizedComponentName()
            {
                return "chatsettings applicationlayoutpage applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(133145067241)
            
            //--TRIMMABLE-BOUNDARY-START(98785328873)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785328873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(98785328873)
            
            //--TRIMMABLE-BOUNDARY-START(141735001833)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(141735001833)
            
            //--TRIMMABLE-BOUNDARY-START(124555132649)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(124555132649)
            
            //--TRIMMABLE-BOUNDARY-START(25770884841)
            /*AccountChatFeatureModel?*/ chatFeature = null;
            //--TRIMMABLE-BOUNDARY-END(25770884841)
            
            //--TRIMMABLE-BOUNDARY-START(128850099945)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850099945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountBaseModel, this.Service.CommunityService.Account, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.chatFeature = $.$Bykq.LCCCCM.AccountChatFeatureModel.From(this.Service.CommunityService.Account, null, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128850099945)
            
            //--TRIMMABLE-BOUNDARY-START(111670230761)
            /*bool */ get IsMuted()
            {
                return (this.chatFeature?.IsChartMuted(this.Parameter.Identifier) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(111670230761)
            
            //--TRIMMABLE-BOUNDARY-START(115965198057)
            /*bool */ get IsPinned()
            {
                return (this.chatFeature?.IsChatPinned(this.Parameter.Identifier) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(115965198057)
            
            //--TRIMMABLE-BOUNDARY-START(107375263465)
            /*bool */ get IsHidden()
            {
                return (this.chatFeature?.IsChatHidden(this.Parameter.Identifier) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(107375263465)
            
            //--TRIMMABLE-BOUNDARY-START(17180950249)
            /*bool */ get AreRemoteActionNotificationsDisabled()
            {
                return (this.chatFeature?.AreRemoteActionNotificationsDisabled(this.Parameter.Identifier) ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180950249)
            
            //--TRIMMABLE-BOUNDARY-START(103080296169)
            /*bool */ get IsGlobalRemoteActionNotificationsDisabled()
            {
                return (this.chatFeature?.GlobalRemoteActionNotificationsDisabled ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(103080296169)
            
            //--TRIMMABLE-BOUNDARY-START(163209838313)
            /*Task *//*async*/  ToggleMute()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209838313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.chatFeature !== null)
                    {
                        let $t4, $r4;
                        let $t5, $r5;
                        this.chatFeature.ToggleChatMute(this.Parameter.Identifier);
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [ this.Service.CommunityService.Account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        ($t5 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatSettings.razor.cs", "ToggleMute", 45), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209838313)
            
            //--TRIMMABLE-BOUNDARY-START(167504805609)
            /*Task *//*async*/  TogglePin()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504805609);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.chatFeature !== null)
                    {
                        let $t6, $r6;
                        let $t7, $r7;
                        this.chatFeature.ToggleChatPin(this.Parameter.Identifier);
                        ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [ this.Service.CommunityService.Account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        ($t7 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatSettings.razor.cs", "TogglePin", 55), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504805609)
            
            //--TRIMMABLE-BOUNDARY-START(171799772905)
            /*Task *//*async*/  ToggleRemoteActionNotifications()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799772905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.chatFeature !== null)
                    {
                        let $t8, $r8;
                        let $t9, $r9;
                        this.chatFeature.ToggleRemoteActionNotifications(this.Parameter.Identifier);
                        ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.AccountBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [ this.Service.CommunityService.Account ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        ($t9 = this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\ChatSettings.razor.cs", "ToggleRemoteActionNotifications", 65), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799772905)
            
            //--TRIMMABLE-BOUNDARY-START(137440034537)
            /*Task */ SearchChat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440034537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.WriteLine$4("Search chat initiated");
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(137440034537)
            
            //--TRIMMABLE-BOUNDARY-START(120260165353)
            /*Task *//*async*/  Leave()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260165353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Parameter.IsPublicRoom)
                    {
                        let $t10, $r10;
                        ($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$LCOv.LCFCPS.IPostInteractionRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$LCOv.LCFCPS.IPostInteractionRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCFCPS$IPostInteractionRemoteService$UnSubscribe(this.Parameter.Identifier);
                        }, $dqEpgd ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":26536372}],"n":"","d":1081065,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        this.Navigation.NavigateTo$1("Chat", false, false);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120260165353)
            
            //--TRIMMABLE-BOUNDARY-START(21475917545)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475917545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let respondent = this.Parameter.GetRespondent(this.Service.CommunityService.Account);
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 0);
                __builder.AddComponentParameter(1, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.TitleSectionId));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(3, this.Parameter.IsPublicRoom ? this.Parameter.Title : (respondent?.Title ?? null));
                }), $eSCYAg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1081065,"h":0,"f":17825794}));
                __builder.CloseComponent();
                if (respondent !== null || this.Parameter.IsPublicRoom)
                {
                    __builder.OpenComponent$1($.$mac.MACS.SectionContent, 4);
                    __builder.AddComponentParameter(5, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.IconSectionId));
                    __builder.AddAttribute$3(6, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        if (this.Parameter.IsPublicRoom)
                        {
                            __builder2.OpenElement(7, "div");
                            __builder2.AddAttribute$5(8, "class", "hx-03 wx-03 pos-rel round bd bd-success bdw-1");
                            __builder2.OpenElement(9, "div");
                            __builder2.AddAttribute$5(10, "style", $.$strNN("background-image:url('" + $.$strNN(((this.Parameter.Icon?.FullPath ?? null)))) + "');");
                            __builder2.AddAttribute$5(11, "class", "lt media round clip flex mgc-a bg-dark hf wf bg-fill bg-no-repeat");
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }
                        else if (respondent !== null)
                        {
                            __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityUserAvatar, 12);
                            __builder2.AddComponentParameter(13, "Class", "hx-03 wx-03");
                            __builder2.AddComponentParameter(14, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 30), $.$$.S.Int32));
                            __builder2.AddComponentParameter(15, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCP.IUserAccountModel, respondent));
                            __builder2.CloseComponent();
                        }
                    }), $HVcxOf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1081065,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
                __builder.OpenElement(16, "div");
                __builder.AddAttribute$5(17, "class", "bg-card pd mgt");
                __builder.AddMarkupContent(18, "<h3 class=\"mgt-0 mgb fw-bold\">Chat Information</h3>");
                if (!this.Parameter.IsPublicRoom && respondent !== null)
                {
                    __builder.OpenElement(19, "div");
                    __builder.AddAttribute$5(20, "class", "mgb");
                    __builder.OpenElement(21, "p");
                    __builder.AddAttribute$5(22, "class", "mg-0");
                    __builder.AddMarkupContent(23, "<b>Status:</b> ");
                    __builder.AddContent$4(24, respondent.Online ? "Online" : "Offline");
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this.Parameter.DateCreated))
                {
                    __builder.OpenElement(25, "div");
                    __builder.AddAttribute$5(26, "class", "mgb");
                    __builder.OpenElement(27, "p");
                    __builder.AddAttribute$5(28, "class", "mg-0");
                    __builder.AddMarkupContent(29, "<b>Created:</b> ");
                    __builder.AddContent$4(30, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Parameter.DateCreated).ToString$3("yyyy/MM/dd"/*DataConverter.DateOnlyFormat*/));
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if (!this.Parameter.IsPublicRoom && respondent !== null)
                {
                    __builder.OpenElement(31, "div");
                    __builder.AddAttribute$5(32, "class", "mgb");
                    __builder.OpenElement(33, "p");
                    __builder.AddAttribute$5(34, "class", "mg-0");
                    __builder.AddMarkupContent(35, "<b>Peer:</b> ");
                    __builder.AddContent$4(36, respondent.Title);
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this.Parameter.DateModified))
                {
                    __builder.OpenElement(37, "div");
                    __builder.AddAttribute$5(38, "class", "mgb");
                    __builder.OpenElement(39, "p");
                    __builder.AddAttribute$5(40, "class", "mg-0");
                    __builder.AddMarkupContent(41, "<b>Last Activity:</b> ");
                    __builder.AddContent$4(42, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Parameter.DateModified).ToString$3("MMM dd, yyyy HH:mm"));
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                if (!$.$$.S.String.IsNullOrWhiteSpace(this.Parameter.Summary))
                {
                    __builder.OpenElement(43, "div");
                    __builder.AddAttribute$5(44, "class", "mgb");
                    __builder.OpenElement(45, "p");
                    __builder.AddAttribute$5(46, "class", "mg-0");
                    __builder.AddMarkupContent(47, "<b>About:</b> ");
                    __builder.AddContent$4(48, this.Parameter.Summary);
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(49, "\r\n\r\n\r\n");
                __builder.OpenElement(50, "div");
                __builder.AddAttribute$5(51, "class", "bg-card pd mgt");
                __builder.AddMarkupContent(52, "<h3 class=\"mg-0 mgb fw-bold\">Chat Controls</h3>\r\n        ");
                __builder.OpenElement(53, "button");
                __builder.AddAttribute$5(54, "class", "text-left wf bg-transparent pd flex");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 55, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ToggleMute)));
                __builder.AddAttribute$5(56, "title", this.IsMuted ? "Unmute notifications" : "Mute notifications");
                __builder.OpenElement(57, "span");
                __builder.AddAttribute$5(58, "class", $.$strNN($.$strNN("mgr-1" + " mdi") + " ") + $.$strNN((this.IsMuted ? "mdi-bell-off" : "mdi-bell")));
                __builder.CloseElement();
                __builder.AddMarkupContent(59, "\r\n            ");
                __builder.AddMarkupContent(60, "<span>Mute Notifications</span>");
                if (this.IsMuted)
                {
                    __builder.AddMarkupContent(61, "<i class=\"mdi mdi-check-circle mgl-a cl-secondary\"></i>");
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(62, "\r\n\r\n        ");
                __builder.OpenElement(63, "button");
                __builder.AddAttribute$5(64, "class", "text-left wf bg-transparent pd flex");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 65, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.TogglePin)));
                __builder.AddAttribute$5(66, "title", this.IsPinned ? "Unpin chat" : "Pin chat");
                __builder.OpenElement(67, "span");
                __builder.AddAttribute$5(68, "class", $.$strNN($.$strNN("mgr-1" + " mdi") + " ") + $.$strNN((this.IsPinned ? "mdi-pin-off" : "mdi-pin")));
                __builder.CloseElement();
                __builder.AddMarkupContent(69, "\r\n            ");
                __builder.AddMarkupContent(70, "<span>Pin Chat</span>");
                if (this.IsPinned)
                {
                    __builder.AddMarkupContent(71, "<i class=\"mdi mdi-check-circle mgl-a cl-secondary\"></i>");
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(72, "\r\n\r\n\r\n");
                __builder.OpenElement(73, "div");
                __builder.AddAttribute$5(74, "class", "bg-card pd mgt");
                __builder.AddMarkupContent(75, "<h3 class=\"mg-0 mgb fw-bold\">Privacy Settings</h3>  \r\n        ");
                __builder.OpenElement(76, "button");
                __builder.AddAttribute$5(77, "class", "text-left wf bg-transparent pd flex");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 78, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.ToggleRemoteActionNotifications)));
                __builder.AddAttribute$5(79, "title", this.AreRemoteActionNotificationsDisabled ? "Enable remote actions for this chat" : "Disable remote actions for this chat");
                __builder.OpenElement(80, "span");
                __builder.AddAttribute$5(81, "class", $.$strNN($.$strNN("mgr-1" + " mdi") + " ") + $.$strNN((this.AreRemoteActionNotificationsDisabled ? "mdi-eye-off" : "mdi-eye")));
                __builder.CloseElement();
                __builder.AddMarkupContent(82, "\r\n            ");
                __builder.AddMarkupContent(83, "<span>Disable Remote Actions</span>");
                if (this.AreRemoteActionNotificationsDisabled)
                {
                    __builder.AddMarkupContent(84, "<i class=\"mdi mdi-check-circle mgl-a cl-secondary\"></i>");
                }
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(85, "\r\n\r\n\r\n");
                __builder.OpenElement(86, "div");
                __builder.AddAttribute$5(87, "class", "bg-card pd mgt mgb");
                __builder.AddMarkupContent(88, "<h3 class=\"mg-0 mgb fw-bold\">Danger Zone</h3>");
                if (this.Parameter.IsPublicRoom)
                {
                    __builder.OpenElement(89, "button");
                    __builder.AddAttribute$5(90, "class", "text-left wf bg-transparent pd");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 91, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Leave)));
                    __builder.AddAttribute$5(92, "title", "Leave this chat room");
                    __builder.AddMarkupContent(93, "<span class=\"mgr-1 mdi mdi-logout cl-error\"></span>\r\n                ");
                    __builder.AddMarkupContent(94, "<span>Leave Room</span>");
                    __builder.CloseElement();
                }
                __builder.CloseElement();
                __builder.AddMarkupContent(95, "\r\n\r\n\r\n");
                __builder.OpenElement(96, "div");
                __builder.AddAttribute$5(97, "class", "bg-card pd mgt");
                __builder.OpenElement(98, "h3");
                __builder.AddAttribute$5(99, "class", "mg-0 fw-bold");
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel>?*/ let __ca1__;
                __builder.AddContent$3(100, $.$box(($.$box((__ca1__ = this.Parameter.Subscribers) !== null ? $.$sl.SL.Enumerable.Count$1($.$LCOv.LCFCPM$1.AccountBaseModel, __ca1__) : null, $.$$.S.Int32)), $.$$.S.Int32));
                __builder.AddContent$4(101, " Members");
                __builder.CloseElement();
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel>?*/ let __ca2__;
                if (((__ca2__ = this.Parameter.Subscribers) !== null ? $.$sl.SL.Enumerable.Any$1($.$LCOv.LCFCPM$1.AccountBaseModel, __ca2__) : false) === true)
                {
                    $.$qbhX._LCCCCPC.TypeInference.CreateDataList_0($.$LCOv.LCFCPM$1.AccountBaseModel, __builder, 102, 103, this.Parameter.Subscribers, 104, 35184372092928n | 8388608n | 8192n, 105, "pdy", 106, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountBaseModel))))().$ctor(this,  (/*member*/ member) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 107);
                            __builder2.AddComponentParameter(108, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, member.Model.Title));
                            __builder2.AddComponentParameter(109, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(member.Model.IconDescriptor.Icon ?? $.$ahDc.LCCCS$1.CommunityUtility.UserIcon(this.ResourcePathResolver))));
                            __builder2.AddComponentParameter(110, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, member.Model.Icon));
                            __builder2.AddComponentParameter(111, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, member.Model.Summary));
                            __builder2.AddComponentParameter(112, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                            __builder2.AddComponentParameter(113, "Link", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, member.Data.Link));
                            __builder2.CloseComponent();
                        }, $YpzEKb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1081065,"h":0,"f":17825794});
                    }, $AXBJTe ??= {"r":6881395,"p":[{"n":"member","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountBaseModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountBaseModel)).$h}],"n":"","d":1081065,"h":0,"f":17825794}));
                }
                else 
                {
                    __builder.AddMarkupContent(114, "<p class=\"tx-sm cl-secondary tx-center pdy\">No members yet</p>");
                }
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(21475917545)
            
            //--TRIMMABLE-BOUNDARY-START(12885982953)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885982953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885982953)
            
            //--TRIMMABLE-BOUNDARY-START(12885982953)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(12885982953)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(141735001833)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(141735001833)
                
                //--TRIMMABLE-BOUNDARY-START(124555132649)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(124555132649)
                
            }
            static $h = 1081065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage$$($.$Bykq.LCCCCM.CommunityChatThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145067241),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900426985,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1081065,
      "h": 133145067241,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145067241),
//--TRIMMABLE-BOUNDARY-START(141735001833),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490361577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914871017,
        "f": 83886081
      },
      "n": "Service",
      "d": 1081065,
      "h": 141735001833,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735001833),
//--TRIMMABLE-BOUNDARY-START(124555132649),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310492393,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324936425,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 1081065,
      "h": 124555132649,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555132649),
//--TRIMMABLE-BOUNDARY-START(111670230761),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130623209,
        "f": 50331650
      },
      "n": "IsMuted",
      "d": 1081065,
      "h": 111670230761,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111670230761),
//--TRIMMABLE-BOUNDARY-START(115965198057),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720557801,
        "f": 50331650
      },
      "n": "IsPinned",
      "d": 1081065,
      "h": 115965198057,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(115965198057),
//--TRIMMABLE-BOUNDARY-START(107375263465),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540688617,
        "f": 50331650
      },
      "n": "IsHidden",
      "d": 1081065,
      "h": 107375263465,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(107375263465),
//--TRIMMABLE-BOUNDARY-START(17180950249),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360819433,
        "f": 50331650
      },
      "n": "AreRemoteActionNotificationsDisabled",
      "d": 1081065,
      "h": 17180950249,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180950249),
//--TRIMMABLE-BOUNDARY-START(103080296169),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950754025,
        "f": 50331650
      },
      "n": "IsGlobalRemoteActionNotificationsDisabled",
      "d": 1081065,
      "h": 103080296169,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103080296169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785328873),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1081065,
      "h": 98785328873,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785328873),
//--TRIMMABLE-BOUNDARY-START(128850099945),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1081065,
      "h": 128850099945,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(128850099945),
//--TRIMMABLE-BOUNDARY-START(163209838313),
    {
      "r": 178454529,
      "n": "ToggleMute",
      "d": 1081065,
      "h": 163209838313,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(163209838313),
//--TRIMMABLE-BOUNDARY-START(167504805609),
    {
      "r": 178454529,
      "n": "TogglePin",
      "d": 1081065,
      "h": 167504805609,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(167504805609),
//--TRIMMABLE-BOUNDARY-START(171799772905),
    {
      "r": 178454529,
      "n": "ToggleRemoteActionNotifications",
      "d": 1081065,
      "h": 171799772905,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799772905),
//--TRIMMABLE-BOUNDARY-START(137440034537),
    {
      "r": 178454529,
      "n": "SearchChat",
      "d": 1081065,
      "h": 137440034537,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440034537),
//--TRIMMABLE-BOUNDARY-START(120260165353),
    {
      "r": 178454529,
      "n": "Leave",
      "d": 1081065,
      "h": 120260165353,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(120260165353),
//--TRIMMABLE-BOUNDARY-START(21475917545),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1081065,
      "h": 21475917545,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475917545)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770884841),
    {
      "t": 298747,
      "n": "chatFeature",
      "d": 1081065,
      "h": 25770884841,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770884841)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885982953),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1081065,
      "h": 12885982953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885982953)
  ],
  "h": 1081065,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 1,
          "t": 655361
        },
        {
          "v": "ChatSettings",
          "t": 1310721
        },
        {
          "v": "Chat Settings",
          "t": 1310721
        },
        {
          "v": "mdi mdi-message",
          "t": 1310721
        },
        {
          "v": 8659142800,
          "t": 67786410
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat/Settings/{ParameterKey}/{*catchAll}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCC$1.IManagedBaseComponent, $.$fPer.LCFCD.IOpenGraphDataProviderFactory, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1081065)
        
        

        //--TRIMMABLE-BOUNDARY-START(1736425)
        $asm.$cls(`$qbhX.LCCCCS.CommunityChatService`, ($self) => class CommunityChatService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(133145722601)
            /*IMessagePipeFactory*/ MessagePipeFactory = null;
            //--TRIMMABLE-BOUNDARY-END(133145722601)
            
            //--TRIMMABLE-BOUNDARY-START(128850755305)
            /*IMessagePipe?*/ messagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(128850755305)
            
            //--TRIMMABLE-BOUNDARY-START(12886638313)
            $ctor$6(/*CommunityRootService*/ service, /*IMessagePipeFactory*/ messagePipeFactory)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886638313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MessagePipeFactory = messagePipeFactory;
                    _ = $.$$.STT.Task.Run$1(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return this.DraftProcessor();
                    }, $LoxOKg ??= {"r":65537,"n":"","d":1736425,"h":0,"f":17825794}));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886638313)
            
            //--TRIMMABLE-BOUNDARY-START(68721213161)
            /*AccountChatFeatureModel*/ Feature = null;
            //--TRIMMABLE-BOUNDARY-END(68721213161)
            
            //--TRIMMABLE-BOUNDARY-START(137440689897)
            /*EventHandler<CommunityChatMessageModel>?*/ OnNewChat = null;
            //--TRIMMABLE-BOUNDARY-END(137440689897)
            
            //--TRIMMABLE-BOUNDARY-START(137440689897)
            //--TRIMMABLE-BOUNDARY-START(21476572905)
            add_OnNewChat(/*EventHandler<CommunityChatMessageModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476572905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnNewChat = $.$$.S.Delegate.Combine$2(this.OnNewChat, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476572905)
            
            //--TRIMMABLE-BOUNDARY-START(158915526377)
            remove_OnNewChat(/*EventHandler<CommunityChatMessageModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915526377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnNewChat = $.$$.S.Delegate.Remove(this.OnNewChat, value);
            }
            //--TRIMMABLE-BOUNDARY-END(158915526377)
            
            //--TRIMMABLE-BOUNDARY-END(137440689897)
            
            //--TRIMMABLE-BOUNDARY-START(141735657193)
            /*EventHandler<PostIsReadNotificationModel>?*/ OnReadNotification = null;
            //--TRIMMABLE-BOUNDARY-END(141735657193)
            
            //--TRIMMABLE-BOUNDARY-START(141735657193)
            //--TRIMMABLE-BOUNDARY-START(30066507497)
            add_OnReadNotification(/*EventHandler<PostIsReadNotificationModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066507497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnReadNotification = $.$$.S.Delegate.Combine$2(this.OnReadNotification, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066507497)
            
            //--TRIMMABLE-BOUNDARY-START(167505460969)
            remove_OnReadNotification(/*EventHandler<PostIsReadNotificationModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505460969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnReadNotification = $.$$.S.Delegate.Remove(this.OnReadNotification, value);
            }
            //--TRIMMABLE-BOUNDARY-END(167505460969)
            
            //--TRIMMABLE-BOUNDARY-END(141735657193)
            
            //--TRIMMABLE-BOUNDARY-START(146030624489)
            /*EventHandler<CommunityChatThreadNotificationModel>?*/ OnThreadNotification = null;
            //--TRIMMABLE-BOUNDARY-END(146030624489)
            
            //--TRIMMABLE-BOUNDARY-START(146030624489)
            //--TRIMMABLE-BOUNDARY-START(38656442089)
            add_OnThreadNotification(/*EventHandler<CommunityChatThreadNotificationModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656442089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnThreadNotification = $.$$.S.Delegate.Combine$2(this.OnThreadNotification, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38656442089)
            
            //--TRIMMABLE-BOUNDARY-START(176095395561)
            remove_OnThreadNotification(/*EventHandler<CommunityChatThreadNotificationModel>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095395561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnThreadNotification = $.$$.S.Delegate.Remove(this.OnThreadNotification, value);
            }
            //--TRIMMABLE-BOUNDARY-END(176095395561)
            
            //--TRIMMABLE-BOUNDARY-END(146030624489)
            
            //--TRIMMABLE-BOUNDARY-START(120260820713)
            /*bool */ get LoadCategories()
            {
                return this.CommunityService.UserAuthenticationTicket.IsValid();
            }
            //--TRIMMABLE-BOUNDARY-END(120260820713)
            
            //--TRIMMABLE-BOUNDARY-START(124555788009)
            /*DataFilter */ get LoadCategoriesFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.CommunityService.Account.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741827/*PostFilterTypes.Subscriptions*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 1099511627776n | 137438953472n | 274877906944n | 549755813888n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(124555788009)
            
            //--TRIMMABLE-BOUNDARY-START(115965853417)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965853417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadOnce(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        let $t3, $r3;
                        let $t4, $r4;
                        ($t1 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.AccountBaseModel, this.CommunityService.Account, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(null) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.Feature = $.$Bykq.LCCCCM.AccountChatFeatureModel.From(this.CommunityService.Account, null, true);
                        this.drafts = (($t3 = $.$fPer.LCFCS$5.LocalStorageExtension.GetItem($.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "ChatDrafts"), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))) ?? new ($.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)))().$ctor$1();
                        this.messagePipe = ($t4 = this.MessagePipeFactory.LCFCM$IMessagePipeFactory$Join($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCR$3.RoutePath), [$.$fPer.LCFCR$3.RoutePath.op_Implicit$2($.$dspc(this.CommunityService.Account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))], [-1], null), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        this.messagePipe.LCFCM$IMessagePipe$Subscribe($.$Bykq.LCCCCM.CommunityChatMessageModel, new ($.$$.S.Action$$($.$Bykq.LCCCCM.CommunityChatMessageModel))().$ctor(this, /*async*/  (/*message*/ message) =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                            {
                                this.OnNewChat?.Invoke(this, message);
                            });
                        }, $pvgNbj ??= {"r":65537,"p":[{"n":"message","p":560891}],"n":"","d":1736425,"h":0,"f":17829890}));
                        this.messagePipe.LCFCM$IMessagePipe$Subscribe($.$LCOv.LCFCPM$1.PostIsReadNotificationModel, new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel))().$ctor(this,  (/*notification*/ notification) =>
                        {
                            this.OnReadNotification?.Invoke(this, notification);
                        }, $VUkYHi ??= {"r":65537,"p":[{"n":"notification","p":17951156}],"n":"","d":1736425,"h":0,"f":17825794}));
                        this.messagePipe.LCFCM$IMessagePipe$Subscribe($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, new ($.$$.S.Action$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel))().$ctor(this,  (/*notification*/ notification) =>
                        {
                            this.OnThreadNotification?.Invoke(this, notification);
                        }, $byyQtb ??= {"r":65537,"p":[{"n":"notification","p":1347323}],"n":"","d":1736425,"h":0,"f":17825794}));
                    });
                }, $mZylOc ??= {"r":181338113,"n":"","d":1736425,"h":0,"f":17829890}), false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115965853417)
            
            //--TRIMMABLE-BOUNDARY-START(64426245865)
            /*Dictionary<DataId, List<CommunityChatMessageModel>>*/ drafts = null;
            //--TRIMMABLE-BOUNDARY-END(64426245865)
            
            //--TRIMMABLE-BOUNDARY-START(107375918825)
            /*IEnumerable<CommunityChatMessageModel>? */ GetDrafts(/*CommunityChatThreadModel*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375918825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = thread.Identifier;
                return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel), this.drafts, $.$clone(id));
            }
            //--TRIMMABLE-BOUNDARY-END(107375918825)
            
            //--TRIMMABLE-BOUNDARY-START(42951409385)
            /*void */ AddMessage(/*CommunityChatThreadModel*/ thread, /*CommunityChatMessageModel*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951409385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = thread.Identifier;
                /*List<CommunityChatMessageModel>?*/ let dfs = null;
                if ((dfs = $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel), this.drafts, $.$clone(id))) === null)
                {
                    dfs = new ($.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel))().$ctor$1();
                    this.drafts.set_Item($.$clone(id), dfs);
                }
                dfs.Add(message);
                this.sync.Release();
            }
            //--TRIMMABLE-BOUNDARY-END(42951409385)
            
            //--TRIMMABLE-BOUNDARY-START(150325591785)
            /*Task *//*async*/  ProcessDraft(/*KeyValuePair<DataId, List<CommunityChatMessageModel>>*/ draft)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325591785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let firstDraft = $.$sl.SL.Enumerable.FirstOrDefault$3($.$Bykq.LCCCCM.CommunityChatMessageModel, draft.Value);
                    if (firstDraft !== null)
                    {
                        let $t5, $r5;
                        /*var*/ let _message = $.$sl.SL.Enumerable.First$1($.$Bykq.LCCCCM.CommunityChatMessageModel, (($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Bykq.LCCCCM.CommunityChatMessageModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(draft.Key), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatMessageModel), [ firstDraft ], null, null)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)))).AsEnumerable());
                        draft.Value.Remove(firstDraft);
                        firstDraft.Identifier = _message.Identifier;
                        firstDraft.DateCreated = _message.DateCreated;
                        firstDraft.Account = this.CommunityService.Account;
                        firstDraft.Post = _message.Post;
                        firstDraft.Summary = _message.Summary;
                        firstDraft.Properties = _message.Properties;
                        firstDraft.RaisePropertyChanged("Identifier");
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150325591785)
            
            //--TRIMMABLE-BOUNDARY-START(47246376681)
            /*CancellationTokenSource*/ cancelSync = null;
            //--TRIMMABLE-BOUNDARY-END(47246376681)
            
            //--TRIMMABLE-BOUNDARY-START(188980297449)
            /*SemaphoreSlim*/ sync = null;
            //--TRIMMABLE-BOUNDARY-END(188980297449)
            
            //--TRIMMABLE-BOUNDARY-START(60131278569)
            /*void *//*async*/  DraftProcessor()
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131278569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(!this.disposed)
                    {
                        /*bool*/ let hasChanges = false;
                        let $en6 = $.$sl.SL.Enumerable.ToList($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), this.drafts).GetEnumerator();
                        while ($en6.MoveNext())
                        {
                            let dfs = $en6.Current;
                            {
                                if (dfs.Value.Count > 0)
                                {
                                    try
                                    {
                                        let $t7, $r7;
                                        ($t7 = this.ProcessDraft(dfs).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                        hasChanges = true;
                                        if (dfs.Value.Count === 0)
                                        {
                                            this.drafts.Remove$1(dfs.Key);
                                        }
                                    }
                                    catch($e)
                                    {
                                    }
                                }
                            }
                        }
                        if (hasChanges)
                        {
                            try
                            {
                                let $t8, $r8;
                                ($t8 = $.$fPer.LCFCS$5.LocalStorageExtension.SetItem($.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)), this.UnitOfWork.LCFCI$IClientUnitOfWork$Storage, this, "ChatDrafts", this.drafts), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                            }
                            catch($e)
                            {
                            }
                        }
                        try
                        {
                            let $t9, $r9;
                            ($t9 = this.sync.WaitAsync$3(this.cancelSync.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        catch($e)
                        {
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60131278569)
            
            //--TRIMMABLE-BOUNDARY-START(111670886121)
            /*Task<CommunityChatThreadModel?> *//*async*/  InitializePrivateChat(/*AccountBaseModel*/ me, /*AccountBaseModel*/ friend, /*string?*/ id, /*bool?*/ create)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCCCCM.CommunityChatThreadModel, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670886121);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    id ??= $.$ahDc.LCCC.Utility.GetReferenceId($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ friend.Identifier, me.Identifier ], null, null));
                    /*var*/ let thread = ($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle($.$Bykq.LCCCCM.CommunityChatThreadModel, this.CommunityService.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12(new $.$fPer.LCFCD.DataId().$ctor$3(id, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    if (thread === null && create === true)
                    {
                        let $t12, $r12;
                        thread = (() =>
                        {
                            //new $.$Bykq.LCCCCM.CommunityChatThreadModel()
                            const $t11 = $.$Bykq.LCCCCM.CommunityChatThreadModel;
                            const $i11 = new $t11();
                            $i11.$ctor$7();
                            $i11.Name = `${$.$strNN(me.Name)}/${$.$strNN(friend.Name)}`;
                            $i11.UniqueId = id;
                            $i11.Account = me;
                            $i11.ThirdPartyId = friend.Identifier;
                            $i11.Subscribers = $.$$.SRC.RuntimeHelpers.CreateArray($.$LCOv.LCFCPM$1.AccountBaseModel.$type, [ me, friend ], null, null);
                            return $i11;
                        })();
                        /*var*/ let mthread = $.$sl.SL.Enumerable.Single$1($.$Bykq.LCCCCM.CommunityChatThreadModel, (($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$Bykq.LCCCCM.CommunityChatThreadModel, this.CommunityService.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [ thread ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)))).Data);
                        thread.Identifier = mthread.Identifier;
                        this.Categories = $.$sl.SL.Enumerable.ToList($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$sl.SL.Enumerable.Concat($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Bykq.LCCCCM.CommunityChatThreadModel), [thread], null, null), this.Categories ?? $.$sl.SL.Enumerable.Empty($.$Bykq.LCCCCM.CommunityChatThreadModel)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, thread);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670886121)
            
            //--TRIMMABLE-BOUNDARY-START(55836311273)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(55836311273)
            
            //--TRIMMABLE-BOUNDARY-START(51541343977)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541343977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
                this.cancelSync.Cancel();
                this.messagePipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(51541343977)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64426245865)
                this.drafts = new ($.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64426245865)
                
                //--TRIMMABLE-BOUNDARY-START(47246376681)
                this.cancelSync = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(47246376681)
                
                //--TRIMMABLE-BOUNDARY-START(188980297449)
                this.sync = new $.$$.ST$1.SemaphoreSlim().$ctor$2(1);
                //--TRIMMABLE-BOUNDARY-END(188980297449)
                
            }
            static $h = 1736425;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145722601),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080951529,
        "f": 50331649
      },
      "n": "MessagePipeFactory",
      "d": 1736425,
      "h": 133145722601,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145722601),
//--TRIMMABLE-BOUNDARY-START(68721213161),
    {
      "p": 298747,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311147753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685330153,
        "f": 83886082
      },
      "n": "Feature",
      "d": 1736425,
      "h": 68721213161,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721213161),
//--TRIMMABLE-BOUNDARY-START(120260820713),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901082345,
        "f": 50364417
      },
      "n": "LoadCategories",
      "d": 1736425,
      "h": 120260820713,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120260820713),
//--TRIMMABLE-BOUNDARY-START(124555788009),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491016937,
        "f": 50364420
      },
      "n": "LoadCategoriesFilter",
      "d": 1736425,
      "h": 124555788009,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(124555788009)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115965853417),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1736425,
      "h": 115965853417,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965853417),
//--TRIMMABLE-BOUNDARY-START(107375918825),
    {
      "r": $.$$.SCG.IEnumerable$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$h,
      "p": [
        {
          "n": "thread",
          "p": 1085179
        }
      ],
      "n": "GetDrafts",
      "d": 1736425,
      "h": 107375918825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375918825),
//--TRIMMABLE-BOUNDARY-START(42951409385),
    {
      "r": 65537,
      "p": [
        {
          "n": "thread",
          "p": 1085179
        },
        {
          "n": "message",
          "p": 560891
        }
      ],
      "n": "AddMessage",
      "d": 1736425,
      "h": 42951409385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951409385),
//--TRIMMABLE-BOUNDARY-START(150325591785),
    {
      "r": 178454529,
      "p": [
        {
          "n": "draft",
          "p": $.$$.SCG.KeyValuePair$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).$h
        }
      ],
      "n": "ProcessDraft",
      "d": 1736425,
      "h": 150325591785,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(150325591785),
//--TRIMMABLE-BOUNDARY-START(60131278569),
    {
      "r": 65537,
      "n": "DraftProcessor",
      "d": 1736425,
      "h": 60131278569,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(60131278569),
//--TRIMMABLE-BOUNDARY-START(111670886121),
    {
      "r": $.$$.STT.Task$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h,
      "p": [
        {
          "n": "me",
          "p": 6220212
        },
        {
          "n": "friend",
          "p": 6220212
        },
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "create",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65,
          "v": true
        }
      ],
      "n": "InitializePrivateChat",
      "d": 1736425,
      "h": 111670886121,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(111670886121),
//--TRIMMABLE-BOUNDARY-START(51541343977),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1736425,
      "h": 51541343977,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541343977)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128850755305),
    {
      "t": 341468,
      "n": "messagePipe",
      "d": 1736425,
      "h": 128850755305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128850755305),
//--TRIMMABLE-BOUNDARY-START(64426245865),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCD.DataId, $.$$.SCG.List$$($.$Bykq.LCCCCM.CommunityChatMessageModel)).$h,
      "n": "drafts",
      "d": 1736425,
      "h": 64426245865,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64426245865),
//--TRIMMABLE-BOUNDARY-START(47246376681),
    {
      "t": 170983425,
      "n": "cancelSync",
      "d": 1736425,
      "h": 47246376681,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246376681),
//--TRIMMABLE-BOUNDARY-START(188980297449),
    {
      "t": 175636481,
      "n": "sync",
      "d": 1736425,
      "h": 188980297449,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188980297449),
//--TRIMMABLE-BOUNDARY-START(55836311273),
    {
      "t": 262145,
      "n": "disposed",
      "d": 1736425,
      "h": 55836311273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55836311273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886638313),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        },
        {
          "n": "messagePipeFactory",
          "p": 407004
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1736425,
      "h": 12886638313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886638313)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(137440689897),
    {
      "e": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$h
          }
        ],
        "n": "add_OnNewChat",
        "d": 1736425,
        "h": 21476572905,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$h
          }
        ],
        "n": "remove_OnNewChat",
        "d": 1736425,
        "h": 158915526377,
        "f": 285212673
      },
      "n": "OnNewChat",
      "d": 1736425,
      "h": 137440689897,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(137440689897),
//--TRIMMABLE-BOUNDARY-START(141735657193),
    {
      "e": $.$$.S.EventHandler$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel).$h
          }
        ],
        "n": "add_OnReadNotification",
        "d": 1736425,
        "h": 30066507497,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$LCOv.LCFCPM$1.PostIsReadNotificationModel).$h
          }
        ],
        "n": "remove_OnReadNotification",
        "d": 1736425,
        "h": 167505460969,
        "f": 285212673
      },
      "n": "OnReadNotification",
      "d": 1736425,
      "h": 141735657193,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(141735657193),
//--TRIMMABLE-BOUNDARY-START(146030624489),
    {
      "e": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel).$h
          }
        ],
        "n": "add_OnThreadNotification",
        "d": 1736425,
        "h": 38656442089,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel).$h
          }
        ],
        "n": "remove_OnThreadNotification",
        "d": 1736425,
        "h": 176095395561,
        "f": 285212673
      },
      "n": "OnThreadNotification",
      "d": 1736425,
      "h": 146030624489,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(146030624489)
  ],
  "h": 1736425
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatMessageModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$Bykq.LCCCCM.CommunityChatMessageModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Services.CommunityChatService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Services${separator}CommunityChatService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1736425)
        
        

        //--TRIMMABLE-BOUNDARY-START(1212137)
        $asm.$cls(`$qbhX.LCCCCP.ChatSettingsTypeDescriptor`, ($self) => class ChatSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$qbhX.LCCCCP.ChatSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296179433)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296179433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$qbhX.LCCCCP.ChatSettingsTypeDescriptor.GenerateProperties($.$qbhX.LCCCCP.ChatSettings, this, factory);
                    }, $aIxzHg ??= {"r":65537,"n":"","d":1212137,"h":0,"f":17825794}), 0, "ChatSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Client.Blazor\\Pages_ChatSettings_LivingThing.Core.Community.Chat.Client.Pages.ChatSettingsTypeDescriptorBuilder.g.cs", "ChatSettingsTypeDescriptor", 45);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296179433)
            
            //--TRIMMABLE-BOUNDARY-START(12886114025)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886114025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$qbhX.LCCCCP.ChatSettings.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$qbhX.LCCCCS.CommunityChatService, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Service";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Client.Pages.ChatSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.ChatSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$qbhX.LCCCCS.CommunityChatService, ($.$cast(target, $.$qbhX.LCCCCP.ChatSettings)).Service);
                        }, $rrcMZa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1212137,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.ChatSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Service = value.AsReference($.$qbhX.LCCCCS.CommunityChatService);
                        }, $bXXWve ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1212137,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Navigation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$qbhX.LCCCCP.ChatSettings.$type, $.$discardRef(), "Navigation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Navigation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$mac.MAC.NavigationManager, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Navigation";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Client.Pages.ChatSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.ChatSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$mac.MAC.NavigationManager, ($.$cast(target, $.$qbhX.LCCCCP.ChatSettings)).Navigation);
                        }, $rkqzvc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1212137,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$qbhX.LCCCCP.ChatSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Navigation = value.AsReference($.$mac.MAC.NavigationManager);
                        }, $FVblwj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1212137,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886114025)
            
            //--TRIMMABLE-BOUNDARY-START(17181081321)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Client.Pages.ChatSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181081321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$qbhX.LCCCCS.CommunityChatService));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$qbhX.LCCCCS.CommunityChatService)))
                    {
                        _target.Service = _Service;
                    }
                }
                {
                    /*var*/ let _Navigation = _target.Navigation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Navigation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$mac.MAC.NavigationManager));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Navigation, ($v) => _Navigation = $v, $.$mac.MAC.NavigationManager)))
                    {
                        _target.Navigation = _Navigation;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181081321)
            
            //--TRIMMABLE-BOUNDARY-START(8591146729)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Client.Pages.ChatSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591146729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$qbhX.LCCCCP.ChatSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$qbhX.LCCCCP.ChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.ChatSettings)))
                {
                    /*var*/ let result = $.$qbhX.LCCCCP.ChatSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.ChatSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$qbhX.LCCCCP.ChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$qbhX.LCCCCP.ChatSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591146729)
            
            static $h = 1212137;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$qbhX.LCCCCP.ChatSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886114025),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1212137,
      "h": 12886114025,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886114025),
//--TRIMMABLE-BOUNDARY-START(17181081321),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1081065,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1212137,
      "h": 17181081321,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181081321),
//--TRIMMABLE-BOUNDARY-START(8591146729),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1081065,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1212137,
      "h": 8591146729,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591146729)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296179433),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1212137,
      "h": 4296179433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296179433)
  ],
  "h": 1212137
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$qbhX.LCCCCP.ChatSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1212137)
        
        

        //--TRIMMABLE-BOUNDARY-START(1933033)
        $asm.$cls(`$qbhX.LCCCCS$1.ChatMessageFluentBuilder`, ($self) => class ChatMessageFluentBuilder extends $.$qbhX.LCCCCS$1.ChatMessageFluentBuilder$$$($self, $.$qbhX.LCCCCS$1._ChatMessage)
        {
            //--TRIMMABLE-BOUNDARY-START(4296900329)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296900329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296900329)
            
            //--TRIMMABLE-BOUNDARY-START(4296900329)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296900329)
            
            static $h = 1933033;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$qbhX.LCCCCS$1.ChatMessageFluentBuilder$$$($.$qbhX.LCCCCS$1.ChatMessageFluentBuilder, $.$qbhX.LCCCCS$1._ChatMessage); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296900329),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1933033,
      "h": 4296900329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296900329)
  ],
  "h": 1933033
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IFluentComponentBuilder$$($.$qbhX.LCCCCS$1._ChatMessage) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Shared.ChatMessageFluentBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Shared${separator}ChatMessageFluentBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1933033)
        
        

        //--TRIMMABLE-BOUNDARY-START(949993)
        $asm.$cls(`$qbhX.LCCCCP.ChatAdd`, ($self) => class ChatAdd extends $.$lJUR.LCFCS.ApplicationLayoutPage
        {
            //--TRIMMABLE-BOUNDARY-START(68720426729)
            /*string */ get OptimizedComponentName()
            {
                return "chatadd applicationlayoutpage";
            }
            //--TRIMMABLE-BOUNDARY-END(68720426729)
            
            //--TRIMMABLE-BOUNDARY-START(47245590249)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245590249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$qbhX.LCCCCS.CommunityChatService, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47245590249)
            
            //--TRIMMABLE-BOUNDARY-START(73015394025)
            /*CommunityChatService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(73015394025)
            
            //--TRIMMABLE-BOUNDARY-START(51540557545)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(51540557545)
            
            //--TRIMMABLE-BOUNDARY-START(64425459433)
            /*ValueTask<bool> *//*async*/  OnSelected$1(/*DataListSelection<AccountModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425459433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let friend = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    /*var*/ let thread = ($t1 = this.Service.InitializePrivateChat(this.Service.CommunityService.Account, friend, null, true), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let link = `Chat/Thread/${$.$strNN($.$dspc(thread.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(thread.Title)}`;
                    this.Navigation.NavigateTo$1(link, false, false);
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425459433)
            
            //--TRIMMABLE-BOUNDARY-START(60130492137)
            /*ValueTask<bool> *//*async*/  OnSelected(/*DataListSelection<CommunityChatThreadModel>*/ selection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130492137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let thread = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data;
                    /*var*/ let link = `Chat/Thread/${$.$strNN($.$dspc(thread.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN(thread.Title)}`;
                    this.Navigation.NavigateTo$1(link, false, false);
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130492137)
            
            //--TRIMMABLE-BOUNDARY-START(55835524841)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835524841);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$vWqU.LCFCC.LoadingExtension.EnsureLoaded(this.Service, true), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835524841)
            
            //--TRIMMABLE-BOUNDARY-START(94490230505)
            /*bool*/ showCreateRoom = false;
            //--TRIMMABLE-BOUNDARY-END(94490230505)
            
            //--TRIMMABLE-BOUNDARY-START(98785197801)
            /*void */ ViewChanging(/*ViewChangingEventArgs*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785197801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.showCreateRoom = context.To === 1;
            }
            //--TRIMMABLE-BOUNDARY-END(98785197801)
            
            //--TRIMMABLE-BOUNDARY-START(17180819177)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180819177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACW.PageTitle, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$4(2, "Add Chat");
                }), $Qiakfb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":949993,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(3, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCT$1.Tabs, 4);
                __builder.AddComponentParameter(5, "head-class", "bg-highlight");
                __builder.AddComponentParameter(6, "OnViewChanging", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs), $.$mac.MAC.EventCallback.Factory.Create$8($.$hDPm.LCFCCM$6.ViewChangingEventArgs, this, new ($.$$.S.Action$$($.$hDPm.LCFCCM$6.ViewChangingEventArgs))().$ctor(this, this.ViewChanging))));
                __builder.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 8);
                    __builder2.AddAttribute$3(9, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ c) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenElement(10, "b");
                            __builder3.AddAttribute$5(11, "class", c.Data.Selected ? "cl-primary" : "");
                            __builder3.AddContent$4(12, "Privates");
                            __builder3.CloseElement();
                        }, $yIIqai ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                    }), $thCAPg ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(13, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$LCOv.LCFCPM$1.AccountModel), 14);
                            __builder3.AddComponentParameter(15, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741833/*PostFilterTypes.FollowerAccount*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                            __builder3.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(17, "RemoteFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCR$1.RemoteFeatures, 34/*RemoteFeatures.Default*/ | 8/*RemoteFeatures.ResultCaching*/), $.$hDPm.LCFCCR$1.RemoteFeatures));
                            __builder3.AddComponentParameter(18, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                            __builder3.AddComponentParameter(19, "li-class", "pd");
                            __builder3.AddAttribute$3(20, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel))))().$ctor(this, ( (/*friend*/ friend) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 21);
                                    __builder4.AddComponentParameter(22, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, friend.Model.Title));
                                    __builder4.AddComponentParameter(23, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(friend.Model.IconDescriptor.Icon ?? $.$ahDc.LCCCS$1.CommunityUtility.UserIcon(this.ResourcePathResolver))));
                                    __builder4.AddComponentParameter(24, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, friend.Model.Icon));
                                    __builder4.AddComponentParameter(25, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, friend.Model.Summary));
                                    __builder4.AddComponentParameter(26, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                                    __builder4.CloseComponent();
                                }, $NEXfIg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                            }), $qThnJd ??= {"r":6881395,"p":[{"n":"friend","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.AccountModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$LCOv.LCFCPM$1.AccountModel)).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(27, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 28);
                                __builder4.AddComponentParameter(29, "Message", "No Follower");
                                __builder4.CloseComponent();
                            }), $OhSpwd ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":949993,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $ljfDLj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                    }), $ILMLwa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(30, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 31);
                    __builder2.AddAttribute$3(32, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*c*/ c) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(33, "b");
                            __builder3.AddAttribute$5(34, "class", c.Data.Selected ? "cl-primary" : "");
                            __builder3.AddContent$4(35, "Join Rooms");
                            __builder3.CloseElement();
                        }, $fXoitf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                    }), $UIIYQk ??= {"r":6881395,"p":[{"n":"c","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(36, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/**/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$Bykq.LCCCCM.CommunityChatThreadModel), 37);
                            __builder3.AddComponentParameter(38, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741841/*PostFilterTypes.Featured*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 16384n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                            __builder3.AddComponentParameter(39, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 65536n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(40, "RemoteFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCR$1.RemoteFeatures, 34/*RemoteFeatures.Default*/ | 8/*RemoteFeatures.ResultCaching*/), $.$hDPm.LCFCCR$1.RemoteFeatures));
                            __builder3.AddComponentParameter(41, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                            __builder3.AddComponentParameter(42, "li-class", "pd");
                            __builder3.AddAttribute$3(43, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel))))().$ctor(this, ( (/**/ thread) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 44);
                                    __builder4.AddComponentParameter(45, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, thread.Model.Title));
                                    __builder4.AddComponentParameter(46, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `${$.$strNN(thread.Data.SubscribersCount)}`));
                                    __builder4.AddComponentParameter(47, "IconDescriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.IconDescriptor, $.$fPer.LCFC.IconDescriptor.op_Implicit(thread.Model.IconDescriptor.Icon)));
                                    __builder4.AddComponentParameter(48, "ResourceImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, thread.Model.Icon));
                                    __builder4.AddComponentParameter(49, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, thread.Model.Summary));
                                    __builder4.AddComponentParameter(50, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures, 0/*DataListDefaultItemTemplateFeatures.Default*/ | 1/*DataListDefaultItemTemplateFeatures.RoundedImage*/), $.$hDPm.LCFCCD$1.DataListDefaultItemTemplateFeatures));
                                    __builder4.CloseComponent();
                                }, $LMbueh ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                            }), $cWoucg ??= {"r":6881395,"p":[{"n":"thread","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Bykq.LCCCCM.CommunityChatThreadModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Bykq.LCCCCM.CommunityChatThreadModel)).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(51, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 52);
                                __builder4.AddComponentParameter(53, "Message", "No rooms");
                                __builder4.CloseComponent();
                            }), $HSLfme ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":949993,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }, $yfGLxd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":949993,"h":0,"f":17825794});
                    }), $eJhFCf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":949993,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $LZQLQk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":949993,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(54, "\r\n\r\n");
                __builder.OpenComponent$1($.$mac.MACS.SectionContent, 55);
                __builder.AddComponentParameter(56, "SectionId", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.Layout.CentralSnapBottomSectionId));
                __builder.AddAttribute$3(57, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    if (this.showCreateRoom)
                    {
                        __builder2.AddMarkupContent(58, "<div class=\"flex bg-highlight\"><a href=\"Chat/New/Room\" class=\"pd mgx-a\">Create New Room</a></div>");
                    }
                }), $OcIdHg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":949993,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180819177)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Frameworks.Common.Posts.Models.AccountModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Frameworks$Common$Posts$Models$AccountModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(12885851881)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885851881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885851881)
            
            //--TRIMMABLE-BOUNDARY-START(12885851881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12885851881)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015394025)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(73015394025)
                
                //--TRIMMABLE-BOUNDARY-START(51540557545)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(51540557545)
                
            }
            static $h = 949993;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationLayoutPage; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720426729),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360688361,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 949993,
      "h": 68720426729,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720426729),
//--TRIMMABLE-BOUNDARY-START(73015394025),
    {
      "p": 1736425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950622953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195263209,
        "f": 83886081
      },
      "n": "Service",
      "d": 949993,
      "h": 73015394025,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015394025),
//--TRIMMABLE-BOUNDARY-START(51540557545),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770753769,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605328617,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 949993,
      "h": 51540557545,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540557545)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245590249),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 949993,
      "h": 47245590249,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245590249),
//--TRIMMABLE-BOUNDARY-START(64425459433),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$LCOv.LCFCPM$1.AccountModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$1",
      "d": 949993,
      "h": 64425459433,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64425459433),
//--TRIMMABLE-BOUNDARY-START(60130492137),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 949993,
      "h": 60130492137,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(60130492137),
//--TRIMMABLE-BOUNDARY-START(55835524841),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 949993,
      "h": 55835524841,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(55835524841),
//--TRIMMABLE-BOUNDARY-START(98785197801),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 38098602
        }
      ],
      "n": "ViewChanging",
      "d": 949993,
      "h": 98785197801,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785197801),
//--TRIMMABLE-BOUNDARY-START(17180819177),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 949993,
      "h": 17180819177,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180819177)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94490230505),
    {
      "t": 262145,
      "n": "showCreateRoom",
      "d": 949993,
      "h": 94490230505,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94490230505)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885851881),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 949993,
      "h": 12885851881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885851881)
  ],
  "h": 949993,
  "a": [
    {
      "t": 917616,
      "c": 17180786800
    },
    {
      "t": 68114090,
      "c": 90262427306,
      "a": [
        {
          "v": "Zoey",
          "t": 1310721
        },
        {
          "v": 0,
          "t": 655361
        },
        {
          "v": "ChatAdd",
          "t": 1310721
        },
        {
          "v": "Add Chat",
          "t": 1310721
        },
        {
          "v": "mdi mdi-message",
          "t": 1310721
        },
        {
          "v": 8659142800,
          "t": 67786410
        },
        {
          "v": "card",
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        },
        {
          "t": 1310721
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 7640512,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Chat/Add",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$lJUR.LCFCS.IApplicationLayoutPage, $.$lJUR.LCFCS.IApplicationLayoutConfiguration, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$LCOv.LCFCPM$1.AccountModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Client.Pages.ChatAdd`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Client${separator}Pages${separator}ChatAdd`; }
        });
        //--TRIMMABLE-BOUNDARY-END(949993)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Chat.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(32489)
