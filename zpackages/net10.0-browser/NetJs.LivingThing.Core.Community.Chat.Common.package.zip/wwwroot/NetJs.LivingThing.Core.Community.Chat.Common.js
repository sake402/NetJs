
//--TRIMMABLE-BOUNDARY-START(36603)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm) {
    "use strict";
    let _;
    let $OwCRHk;
    let $uVsRGh;
    let $QULrGi;
    let $kxeMGk;
    let $NmDFJb;
    let $wQAHie;
    let $kcRbob;
    let $Nqcawe;
    let $eJYegd;
    let $nJOuUb;
    let $gCWLFk;
    let $wwzwQc;
    let $RbFvpa;
    let $LnHJWf;
    let $qUnQdc;
    let $ZhIEwa;
    let $zVXMec;
    let $ywCLxg;
    let $CarPpi;
    let $kasQle;
    let $uIjGQe;
    let $TqDdsc;
    let $kNfeGj;
    let $VcWjqc;
    let $iIlVfg;
    let $xefcLg;
    let $BydhLi;
    let $slyUzd;
    let $itBOkj;
    let $thHIfi;
    let $wvhJga;
    let $mRrCQa;
    let $xJsVzd;
    let $bvxSJh;
    let $SDnDFc;
    let $OvruWj;
    let $RHMuAj;
    let $sNWAGe;
    let $VAviNg;
    let $lmnYve;
    let $TbWhTb;
    let $BQxbNc;
    let $cbzDha;
    let $iRwJsd;
    let $lCiAwb;
    let $QEtSxf;
    let $IDZRAa;
    let $DFHJca;
    let $LgCyHg;
    let $msZYXd;
    let $ykxuBh;
    let $WWODPd;
    let $qLHfEg;
    let $cPWAkf;
    let $ZcfyBh;
    let $HWdAme;
    let $Ewpnyc;
    let $nscJFa;
    let $FVLEFc;
    let $MjGNxj;
    let $PEdcmk;
    let $WpshZa;
    let $WFKrjh;
    let $NUyzGf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Chat.Common", 
    {
  "h": 36603,
  "f": "LivingThing.Core.Community.Chat.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Chat.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Chat.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1347323)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadNotificationModel`, ($self) => class CommunityChatThreadNotificationModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1412859)
            static $_Type;
            static get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1412859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel;
                return $cls.$_Type ??= $asm.$nstr(`$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type`, ($self) => class Type extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static None = 0;
                    static Open = 1;
                    static Typing = 2;
                    static Recording = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1412859);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Open": 1n,
                            "Typing": 2n,
                            "Recording": 3n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4296380155)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296380155);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296380155)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296380155)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296380155)
                    
                    static $h = 1412859;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591347451),
    {
      "t": 1412859,
      "n": "None",
      "d": 1412859,
      "h": 8591347451,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591347451),
//--TRIMMABLE-BOUNDARY-START(12886314747),
    {
      "t": 1412859,
      "n": "Open",
      "d": 1412859,
      "h": 12886314747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886314747),
//--TRIMMABLE-BOUNDARY-START(21476249339),
    {
      "t": 1412859,
      "n": "Typing",
      "d": 1412859,
      "h": 21476249339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476249339),
//--TRIMMABLE-BOUNDARY-START(17181282043),
    {
      "t": 1412859,
      "n": "Recording",
      "d": 1412859,
      "h": 17181282043,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181282043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296380155),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1412859,
      "h": 4296380155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296380155)
  ],
  "d": 1347323,
  "h": 1412859
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel+Type`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadNotificationModel${separator}Type`; }
                }, $cls, ($v) => $cls.$_Type = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1412859)
            
            //--TRIMMABLE-BOUNDARY-START(68720824059)
            /*Type*/ NotificationType = 0;
            //--TRIMMABLE-BOUNDARY-END(68720824059)
            
            //--TRIMMABLE-BOUNDARY-START(30066118395)
            /*DateTime*/ Date;
            //--TRIMMABLE-BOUNDARY-END(30066118395)
            
            //--TRIMMABLE-BOUNDARY-START(107375529723)
            /*DataId*/ ThreadId;
            //--TRIMMABLE-BOUNDARY-END(107375529723)
            
            //--TRIMMABLE-BOUNDARY-START(25771151099)
            /*DataId*/ AccountId;
            //--TRIMMABLE-BOUNDARY-END(25771151099)
            
            //--TRIMMABLE-BOUNDARY-START(21476183803)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476183803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476183803)
            
            //--TRIMMABLE-BOUNDARY-START(21476183803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476183803)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30066118395)
                this.Date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(30066118395)
                
                //--TRIMMABLE-BOUNDARY-START(107375529723)
                this.ThreadId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(107375529723)
                
                //--TRIMMABLE-BOUNDARY-START(25771151099)
                this.AccountId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(25771151099)
                
            }
            static $h = 1347323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720824059),
    {
      "p": 1412859,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835922171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490627835,
        "f": 83886081
      },
      "n": "NotificationType",
      "d": 1347323,
      "h": 68720824059,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720824059),
//--TRIMMABLE-BOUNDARY-START(30066118395),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245987579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900693243,
        "f": 83886081
      },
      "n": "Date",
      "d": 1347323,
      "h": 30066118395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066118395),
//--TRIMMABLE-BOUNDARY-START(107375529723),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425856763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080562427,
        "f": 83886081
      },
      "n": "ThreadId",
      "d": 1347323,
      "h": 107375529723,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375529723),
//--TRIMMABLE-BOUNDARY-START(25771151099),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656052987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310758651,
        "f": 83886081
      },
      "n": "AccountId",
      "d": 1347323,
      "h": 25771151099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771151099)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476183803),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1347323,
      "h": 21476183803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476183803)
  ],
  "h": 1347323
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadNotificationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1347323)
        
        

        //--TRIMMABLE-BOUNDARY-START(888571)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatModelCustomAttributesProvider`, ($self) => class CommunityChatModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295855867)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295855867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ComponentModelCustomAttributesProvider$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295855867)
            
            static $h = 888571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295855867),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 888571,
      "h": 4295855867,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295855867)
  ],
  "h": 888571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(888571)
        
        

        //--TRIMMABLE-BOUNDARY-START(167675)
        $asm.$cls(`$Bykq.LCCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295134971)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295134971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295134971)
            
            static $h = 167675;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295134971),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 167675,
      "h": 4295134971,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295134971)
  ],
  "h": 167675
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(167675)
        
        

        //--TRIMMABLE-BOUNDARY-START(2199291)
        $asm.$cls(`$Bykq.LCCCCS$2.ChatStatesCustomAttributesProvider`, ($self) => class ChatStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297166587)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297166587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS$1.ComponentStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297166587)
            
            static $h = 2199291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297166587),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2199291,
      "h": 4297166587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297166587)
  ],
  "h": 2199291
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.States.ChatStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}States${separator}ChatStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2199291)
        
        

        //--TRIMMABLE-BOUNDARY-START(364283)
        $asm.$cls(`$Bykq.LCCCCM.AccountChatFeatureModelCustomAttributesProvider`, ($self) => class AccountChatFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295331579)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295331579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.AccountFeatureModelCustomAttributesProvider$$($.$Bykq.LCCCCM.AccountChatFeatureModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295331579)
            
            static $h = 364283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295331579),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 364283,
      "h": 4295331579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295331579)
  ],
  "h": 364283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}AccountChatFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(364283)
        
        

        //--TRIMMABLE-BOUNDARY-START(1478395)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadNotificationModelCustomAttributesProvider`, ($self) => class CommunityChatThreadNotificationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296445691)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296445691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296445691)
            
            static $h = 1478395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296445691),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1478395,
      "h": 4296445691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296445691)
  ],
  "h": 1478395
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadNotificationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1478395)
        
        

        //--TRIMMABLE-BOUNDARY-START(1937147)
        $asm.$cls(`$Bykq.LCCCCS$1.ChatSettingsCustomAttributesProvider`, ($self) => class ChatSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296904443)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296904443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296904443)
            
            static $h = 1937147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296904443),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1937147,
      "h": 4296904443,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296904443)
  ],
  "h": 1937147
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Settings.ChatSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Settings${separator}ChatSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1937147)
        
        

        //--TRIMMABLE-BOUNDARY-START(102139)
        $asm.$cls(`$Bykq.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295069435)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295069435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCM.AccountChatFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelCustomAttributesProvider, $.$Bykq.LCCCCM.AccountChatFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCM.CommunityChatMessageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCM.CommunityChatMessageModelCustomAttributesProvider, $.$Bykq.LCCCCM.CommunityChatMessageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCM.CommunityChatModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCM.CommunityChatModelCustomAttributesProvider, $.$Bykq.LCCCCM.CommunityChatModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCM.CommunityChatThreadModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelCustomAttributesProvider, $.$Bykq.LCCCCM.CommunityChatThreadModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelCustomAttributesProvider, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCS$1.ChatSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCS$1.ChatSettingsCustomAttributesProvider, $.$Bykq.LCCCCS$1.ChatSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$Bykq.LCCCCS$2.ChatStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$Bykq.LCCCCS$2.ChatStatesCustomAttributesProvider, $.$Bykq.LCCCCS$2.ChatStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295069435)
            
            static $h = 102139;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295069435),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 102139,
      "h": 4295069435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295069435)
  ],
  "h": 102139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(102139)
        
        

        //--TRIMMABLE-BOUNDARY-START(2395899)
        $asm.$cls(`$Bykq.LCCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297363195)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297363195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCM.CommunityChatModelTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCS$1.ChatSettingsTypeDescriptorBuilder.Register();
                $.$Bykq.LCCCCS$2.ChatStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297363195)
            
            static $h = 2395899;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297363195),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2395899,
      "h": 4297363195,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297363195)
  ],
  "h": 2395899
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2395899)
        
        

        //--TRIMMABLE-BOUNDARY-START(233211)
        $asm.$cls(`$Bykq.LCCCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295200507)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295200507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$Bykq.LCCCCS.ICommunityChatRemoteService, $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $nJOuUb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $gCWLFk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $wwzwQc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $RbFvpa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $LnHJWf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $qUnQdc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $ZhIEwa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking().$ctor$3(impl);
                }, $zVXMec ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $ywCLxg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $CarPpi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $kasQle ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $uIjGQe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $TqDdsc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $kNfeGj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking().$ctor$3(impl);
                }, $VcWjqc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":233211,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295200507)
            
            static $h = 233211;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295200507),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 233211,
      "h": 4295200507,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295200507)
  ],
  "h": 233211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(233211)
        
        

        //--TRIMMABLE-BOUNDARY-START(2068219)
        $asm.$cls(`$Bykq.LCCCCS$1.ChatSettingsTypeDescriptorBuilder`, ($self) => class ChatSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592002811)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592002811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCS$1.ChatSettingsTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCS$1.ChatSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Settings.ChatSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $uVsRGh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2068219,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCS$1.ChatSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592002811)
            
            //--TRIMMABLE-BOUNDARY-START(4297035515)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297035515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297035515)
            
            //--TRIMMABLE-BOUNDARY-START(4297035515)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297035515)
            
            static $h = 2068219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592002811),
    {
      "r": 65537,
      "n": "Register",
      "d": 2068219,
      "h": 8592002811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592002811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297035515),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2068219,
      "h": 4297035515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297035515)
  ],
  "h": 2068219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Settings.ChatSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Settings${separator}ChatSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2068219)
        
        

        //--TRIMMABLE-BOUNDARY-START(1150715)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadModelCustomAttributesProvider`, ($self) => class CommunityChatThreadModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296118011)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296118011)
            
            //--TRIMMABLE-BOUNDARY-START(8591085307)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591085307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$Bykq.LCCCCM.CommunityChatThreadModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ThirdPartyId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IsPublicRoom", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$Bykq.LCCCCM.CommunityChatThreadModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Nqcawe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1150715,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $eJYegd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1150715,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMC.CategoryPostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591085307)
            
            static $h = 1150715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591085307),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1150715,
      "h": 8591085307,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591085307)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296118011),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1150715,
      "h": 4296118011,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296118011)
  ],
  "h": 1150715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1150715)
        
        

        //--TRIMMABLE-BOUNDARY-START(1019643)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatModelTypeDescriptorBuilder`, ($self) => class CommunityChatModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590954235)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590954235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatModelTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCM.CommunityChatModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Models.CommunityChatModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kxeMGk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1019643,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCM.CommunityChatModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590954235)
            
            //--TRIMMABLE-BOUNDARY-START(4295986939)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295986939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295986939)
            
            //--TRIMMABLE-BOUNDARY-START(4295986939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295986939)
            
            static $h = 1019643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590954235),
    {
      "r": 65537,
      "n": "Register",
      "d": 1019643,
      "h": 8590954235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590954235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295986939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1019643,
      "h": 4295986939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295986939)
  ],
  "h": 1019643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1019643)
        
        

        //--TRIMMABLE-BOUNDARY-START(757499)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptorBuilder`, ($self) => class CommunityChatMessageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590692091)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590692091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BydhLi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":757499,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCM.CommunityChatMessageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590692091)
            
            //--TRIMMABLE-BOUNDARY-START(4295724795)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295724795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295724795)
            
            //--TRIMMABLE-BOUNDARY-START(4295724795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295724795)
            
            static $h = 757499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590692091),
    {
      "r": 65537,
      "n": "Register",
      "d": 757499,
      "h": 8590692091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590692091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295724795),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 757499,
      "h": 4295724795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295724795)
  ],
  "h": 757499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatMessageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(757499)
        
        

        //--TRIMMABLE-BOUNDARY-START(626427)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatMessageModelCustomAttributesProvider`, ($self) => class CommunityChatMessageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295593723)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295593723)
            
            //--TRIMMABLE-BOUNDARY-START(8590561019)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590561019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$Bykq.LCCCCM.CommunityChatMessageModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ThirdPartyId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$Bykq.LCCCCM.CommunityChatMessageModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wQAHie ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":626427,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $kcRbob ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":626427,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.PostModelCustomAttributesProvider$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590561019)
            
            static $h = 626427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590561019),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 626427,
      "h": 8590561019,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590561019)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295593723),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 626427,
      "h": 4295593723,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295593723)
  ],
  "h": 626427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatMessageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(626427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1281787)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptorBuilder`, ($self) => class CommunityChatThreadModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591216379)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591216379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mRrCQa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1281787,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCM.CommunityChatThreadModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591216379)
            
            //--TRIMMABLE-BOUNDARY-START(4296249083)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296249083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296249083)
            
            //--TRIMMABLE-BOUNDARY-START(4296249083)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296249083)
            
            static $h = 1281787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591216379),
    {
      "r": 65537,
      "n": "Register",
      "d": 1281787,
      "h": 8591216379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591216379)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296249083),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1281787,
      "h": 4296249083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296249083)
  ],
  "h": 1281787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1281787)
        
        

        //--TRIMMABLE-BOUNDARY-START(1609467)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptorBuilder`, ($self) => class CommunityChatThreadNotificationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591544059)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591544059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VAviNg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1609467,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591544059)
            
            //--TRIMMABLE-BOUNDARY-START(4296576763)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296576763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296576763)
            
            //--TRIMMABLE-BOUNDARY-START(4296576763)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296576763)
            
            static $h = 1609467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591544059),
    {
      "r": 65537,
      "n": "Register",
      "d": 1609467,
      "h": 8591544059,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591544059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296576763),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1609467,
      "h": 4296576763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296576763)
  ],
  "h": 1609467
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadNotificationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1609467)
        
        

        //--TRIMMABLE-BOUNDARY-START(2330363)
        $asm.$cls(`$Bykq.LCCCCS$2.ChatStatesTypeDescriptorBuilder`, ($self) => class ChatStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592264955)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592264955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCS$2.ChatStatesTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCS$2.ChatStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.States.ChatStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iIlVfg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2330363,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCS$2.ChatStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592264955)
            
            //--TRIMMABLE-BOUNDARY-START(4297297659)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297297659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297297659)
            
            //--TRIMMABLE-BOUNDARY-START(4297297659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297297659)
            
            static $h = 2330363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592264955),
    {
      "r": 65537,
      "n": "Register",
      "d": 2330363,
      "h": 8592264955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592264955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297297659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2330363,
      "h": 4297297659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297297659)
  ],
  "h": 2330363
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.States.ChatStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}States${separator}ChatStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2330363)
        
        

        //--TRIMMABLE-BOUNDARY-START(495355)
        $asm.$cls(`$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptorBuilder`, ($self) => class AccountChatFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590429947)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590429947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor()
                        const $t1 = $.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LgCyHg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":495355,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$Bykq.LCCCCM.AccountChatFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590429947)
            
            //--TRIMMABLE-BOUNDARY-START(4295462651)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295462651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295462651)
            
            //--TRIMMABLE-BOUNDARY-START(4295462651)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295462651)
            
            static $h = 495355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590429947),
    {
      "r": 65537,
      "n": "Register",
      "d": 495355,
      "h": 8590429947,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590429947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295462651),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 495355,
      "h": 4295462651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295462651)
  ],
  "h": 495355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}AccountChatFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(495355)
        
        

        //--TRIMMABLE-BOUNDARY-START(1675003)
        $asm.$cls(`$Bykq.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886576891)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886576891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886576891)
            
            //--TRIMMABLE-BOUNDARY-START(8591609595)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591609595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Bykq.LCCCC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$Bykq.LCCCCM.CommunityChatThreadModel, 769/*PostTypes.ChatThread*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$Bykq.LCCCCM.CommunityChatMessageModel, 770/*PostTypes.ChatMessage*/);
                $.$Bykq.LCCCC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$Bykq.LCCCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$Bykq.LCCCC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591609595)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Bykq.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296642299)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296642299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296642299)
            
            //--TRIMMABLE-BOUNDARY-START(4296642299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296642299)
            
            static $h = 1675003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886576891),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1675003,
      "h": 12886576891,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886576891),
//--TRIMMABLE-BOUNDARY-START(8591609595),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1675003,
      "h": 8591609595,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591609595)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296642299),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1675003,
      "h": 4296642299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296642299)
  ],
  "h": 1675003
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1675003)
        
        

        //--TRIMMABLE-BOUNDARY-START(298747)
        $asm.$cls(`$Bykq.LCCCCM.AccountChatFeatureModel`, ($self) => class AccountChatFeatureModel extends $.$LCOv.LCFCPM$1.AccountFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(17180167931)
            static /*AccountChatFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180167931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$Bykq.LCCCCM.AccountChatFeatureModel, ($.$cast(target, $.$LCOv.LCFCPM$1.AccountBaseModel)), $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(17180167931)
            
            //--TRIMMABLE-BOUNDARY-START(81604677371)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604677371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("$"/*PrefixIdentifier*/)}Chat`;
            }
            //--TRIMMABLE-BOUNDARY-END(81604677371)
            
            //--TRIMMABLE-BOUNDARY-START(115964415739)
            /*IEnumerable<KeyValuePair<string, string>>? */ get PinnedMessages()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719775483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), "PinnedMessages");
            }
            /*IEnumerable<KeyValuePair<string, string>>? */ set PinnedMessages(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798990587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), value, "PinnedMessages");
            }
            //--TRIMMABLE-BOUNDARY-END(115964415739)
            
            //--TRIMMABLE-BOUNDARY-START(12885200635)
            /*IEnumerable<string>? */ get Favorites()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770102523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "Favorites");
            }
            /*IEnumerable<string>? */ set Favorites(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849317627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "Favorites");
            }
            //--TRIMMABLE-BOUNDARY-END(12885200635)
            
            //--TRIMMABLE-BOUNDARY-START(107374481147)
            /*IEnumerable<string>? */ get MutedChats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539906299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "MutedChats");
            }
            /*IEnumerable<string>? */ set MutedChats(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619121403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "MutedChats");
            }
            //--TRIMMABLE-BOUNDARY-END(107374481147)
            
            //--TRIMMABLE-BOUNDARY-START(111669448443)
            /*IEnumerable<string>? */ get PinnedChats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129840891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "PinnedChats");
            }
            /*IEnumerable<string>? */ set PinnedChats(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209055995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "PinnedChats");
            }
            //--TRIMMABLE-BOUNDARY-END(111669448443)
            
            //--TRIMMABLE-BOUNDARY-START(90194611963)
            /*IEnumerable<string>? */ get HiddenChats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949971707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "HiddenChats");
            }
            /*IEnumerable<string>? */ set HiddenChats(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029186811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "HiddenChats");
            }
            //--TRIMMABLE-BOUNDARY-END(90194611963)
            
            //--TRIMMABLE-BOUNDARY-START(85899644667)
            /*bool */ get GlobalRemoteActionNotificationsDisabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360037115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, "GlobalRemoteActionNotificationsDisabled", false);
            }
            /*bool */ set GlobalRemoteActionNotificationsDisabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439252219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "GlobalRemoteActionNotificationsDisabled");
            }
            //--TRIMMABLE-BOUNDARY-END(85899644667)
            
            //--TRIMMABLE-BOUNDARY-START(120259383035)
            /*IEnumerable<string>? */ get RemoteActionNotificationsDisabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309710075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$$.S.String, "RemoteActionNotificationsDisabled");
            }
            /*IEnumerable<string>? */ set RemoteActionNotificationsDisabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388925179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$$.S.String, value, "RemoteActionNotificationsDisabled");
            }
            //--TRIMMABLE-BOUNDARY-END(120259383035)
            
            //--TRIMMABLE-BOUNDARY-START(94489579259)
            /*bool */ IsChartMuted(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489579259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                /*object?*/ let __ca2__;
                return ((__ca1__ = this.MutedChats) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca1__, ((__ca2__ = chatId.Id) !== null ? ($.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "")) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(94489579259)
            
            //--TRIMMABLE-BOUNDARY-START(188978859771)
            /*void */ ToggleChatMute(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978859771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca3__;
                /*var*/ let chatIdStr = ((__ca3__ = chatId.Id) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "");
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                /*var*/ let mutedChats = ((__ca4__ = this.MutedChats) !== null ? ($.$sl.SL.Enumerable.ToList($.$$.S.String, __ca4__) ?? new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1()) : new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1());
                if (mutedChats.Contains(chatIdStr))
                {
                    mutedChats.Remove(chatIdStr);
                }
                else 
                {
                    mutedChats.Add(chatIdStr);
                }
                this.MutedChats = mutedChats;
            }
            //--TRIMMABLE-BOUNDARY-END(188978859771)
            
            //--TRIMMABLE-BOUNDARY-START(103079513851)
            /*bool */ IsChatPinned(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079513851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca5__;
                /*object?*/ let __ca6__;
                return ((__ca5__ = this.PinnedChats) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca5__, ((__ca6__ = chatId.Id) !== null ? ($.$dspc(__ca6__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "")) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(103079513851)
            
            //--TRIMMABLE-BOUNDARY-START(193273827067)
            /*void */ ToggleChatPin(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273827067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca7__;
                /*var*/ let chatIdStr = ((__ca7__ = chatId.Id) !== null ? ($.$dspc(__ca7__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "");
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca8__;
                /*var*/ let pinnedChats = ((__ca8__ = this.PinnedChats) !== null ? ($.$sl.SL.Enumerable.ToList($.$$.S.String, __ca8__) ?? new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1()) : new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1());
                if (pinnedChats.Contains(chatIdStr))
                {
                    pinnedChats.Remove(chatIdStr);
                }
                else 
                {
                    pinnedChats.Add(chatIdStr);
                }
                this.PinnedChats = pinnedChats;
            }
            //--TRIMMABLE-BOUNDARY-END(193273827067)
            
            //--TRIMMABLE-BOUNDARY-START(98784546555)
            /*bool */ IsChatHidden(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784546555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca10__;
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca9__;
                return ((__ca9__ = this.HiddenChats) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca9__, ((__ca10__ = chatId.Id) !== null ? ($.$dspc(__ca10__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "")) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(98784546555)
            
            //--TRIMMABLE-BOUNDARY-START(184683892475)
            /*void */ ToggleChatHidden(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683892475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca11__;
                /*var*/ let chatIdStr = ((__ca11__ = chatId.Id) !== null ? ($.$dspc(__ca11__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "");
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca12__;
                /*var*/ let hiddenChats = ((__ca12__ = this.HiddenChats) !== null ? ($.$sl.SL.Enumerable.ToList($.$$.S.String, __ca12__) ?? new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1()) : new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1());
                if (hiddenChats.Contains(chatIdStr))
                {
                    hiddenChats.Remove(chatIdStr);
                }
                else 
                {
                    hiddenChats.Add(chatIdStr);
                }
                this.HiddenChats = hiddenChats;
            }
            //--TRIMMABLE-BOUNDARY-END(184683892475)
            
            //--TRIMMABLE-BOUNDARY-START(8590233339)
            /*bool */ AreRemoteActionNotificationsDisabled(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590233339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca13__;
                /*object?*/ let __ca14__;
                return this.GlobalRemoteActionNotificationsDisabled || (((__ca13__ = this.RemoteActionNotificationsDisabled) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca13__, ((__ca14__ = chatId.Id) !== null ? ($.$dspc(__ca14__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "")) : false));
            }
            //--TRIMMABLE-BOUNDARY-END(8590233339)
            
            //--TRIMMABLE-BOUNDARY-START(197568794363)
            /*void */ ToggleRemoteActionNotifications(/*DataId*/ chatId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568794363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca15__;
                /*var*/ let chatIdStr = ((__ca15__ = chatId.Id) !== null ? ($.$dspc(__ca15__, $.$$.S.Object, ($t) => $t.ToString) ?? "") : "");
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca16__;
                /*var*/ let disabledChats = ((__ca16__ = this.RemoteActionNotificationsDisabled) !== null ? ($.$sl.SL.Enumerable.ToList($.$$.S.String, __ca16__) ?? new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1()) : new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1());
                if (disabledChats.Contains(chatIdStr))
                {
                    disabledChats.Remove(chatIdStr);
                }
                else 
                {
                    disabledChats.Add(chatIdStr);
                }
                this.RemoteActionNotificationsDisabled = disabledChats;
            }
            //--TRIMMABLE-BOUNDARY-END(197568794363)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Bykq.LCCCCM.AccountChatFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Bykq.LCCCCM.AccountChatFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4295266043)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295266043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295266043)
            
            //--TRIMMABLE-BOUNDARY-START(4295266043)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295266043)
            
            static $h = 298747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$Bykq.LCCCCM.AccountChatFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964415739),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719775483,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798990587,
        "f": 83886081
      },
      "n": "PinnedMessages",
      "d": 298747,
      "h": 115964415739,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964415739),
//--TRIMMABLE-BOUNDARY-START(12885200635),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770102523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849317627,
        "f": 83886081
      },
      "n": "Favorites",
      "d": 298747,
      "h": 12885200635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885200635),
//--TRIMMABLE-BOUNDARY-START(107374481147),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539906299,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619121403,
        "f": 83886081
      },
      "n": "MutedChats",
      "d": 298747,
      "h": 107374481147,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374481147),
//--TRIMMABLE-BOUNDARY-START(111669448443),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129840891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209055995,
        "f": 83886081
      },
      "n": "PinnedChats",
      "d": 298747,
      "h": 111669448443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669448443),
//--TRIMMABLE-BOUNDARY-START(90194611963),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949971707,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029186811,
        "f": 83886081
      },
      "n": "HiddenChats",
      "d": 298747,
      "h": 90194611963,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194611963),
//--TRIMMABLE-BOUNDARY-START(85899644667),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360037115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439252219,
        "f": 83886081
      },
      "n": "GlobalRemoteActionNotificationsDisabled",
      "d": 298747,
      "h": 85899644667,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899644667),
//--TRIMMABLE-BOUNDARY-START(120259383035),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309710075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388925179,
        "f": 83886081
      },
      "n": "RemoteActionNotificationsDisabled",
      "d": 298747,
      "h": 120259383035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259383035)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180167931),
    {
      "r": 298747,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 298747,
      "h": 17180167931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180167931),
//--TRIMMABLE-BOUNDARY-START(81604677371),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 298747,
      "h": 81604677371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604677371),
//--TRIMMABLE-BOUNDARY-START(94489579259),
    {
      "r": 262145,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "IsChartMuted",
      "d": 298747,
      "h": 94489579259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489579259),
//--TRIMMABLE-BOUNDARY-START(188978859771),
    {
      "r": 65537,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "ToggleChatMute",
      "d": 298747,
      "h": 188978859771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188978859771),
//--TRIMMABLE-BOUNDARY-START(103079513851),
    {
      "r": 262145,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "IsChatPinned",
      "d": 298747,
      "h": 103079513851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079513851),
//--TRIMMABLE-BOUNDARY-START(193273827067),
    {
      "r": 65537,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "ToggleChatPin",
      "d": 298747,
      "h": 193273827067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193273827067),
//--TRIMMABLE-BOUNDARY-START(98784546555),
    {
      "r": 262145,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "IsChatHidden",
      "d": 298747,
      "h": 98784546555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784546555),
//--TRIMMABLE-BOUNDARY-START(184683892475),
    {
      "r": 65537,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "ToggleChatHidden",
      "d": 298747,
      "h": 184683892475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184683892475),
//--TRIMMABLE-BOUNDARY-START(8590233339),
    {
      "r": 262145,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "AreRemoteActionNotificationsDisabled",
      "d": 298747,
      "h": 8590233339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590233339),
//--TRIMMABLE-BOUNDARY-START(197568794363),
    {
      "r": 65537,
      "p": [
        {
          "n": "chatId",
          "p": 10455382
        }
      ],
      "n": "ToggleRemoteActionNotifications",
      "d": 298747,
      "h": 197568794363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197568794363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295266043),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 298747,
      "h": 4295266043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295266043)
  ],
  "h": 298747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD.IDataFeatureModel$$($.$Bykq.LCCCCM.AccountChatFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}AccountChatFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(298747)
        
        

        //--TRIMMABLE-BOUNDARY-START(1871611)
        $asm.$cls(`$Bykq.LCCCCS$1.ChatSettings`, ($self) => class ChatSettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4296838907)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296838907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296838907)
            
            //--TRIMMABLE-BOUNDARY-START(4296838907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296838907)
            
            static $h = 1871611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296838907),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1871611,
      "h": 4296838907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296838907)
  ],
  "h": 1871611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Settings.ChatSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Settings${separator}ChatSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1871611)
        
        

        //--TRIMMABLE-BOUNDARY-START(2133755)
        $asm.$cls(`$Bykq.LCCCCS$2.ChatStates`, ($self) => class ChatStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4297101051)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297101051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297101051)
            
            //--TRIMMABLE-BOUNDARY-START(4297101051)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297101051)
            
            static $h = 2133755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297101051),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2133755,
      "h": 4297101051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297101051)
  ],
  "h": 2133755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.States.ChatStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}States${separator}ChatStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2133755)
        
        

        //--TRIMMABLE-BOUNDARY-START(1543931)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor`, ($self) => class CommunityChatThreadNotificationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296511227)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296511227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor.GenerateProperties($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, this, factory);
                    }, $lmnYve ??= {"r":65537,"n":"","d":1543931,"h":0,"f":17825794}), 0, "CommunityChatThreadNotificationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Models_CommunityChatThreadNotificationModel_LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModelTypeDescriptorBuilder.g.cs", "CommunityChatThreadNotificationModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296511227)
            
            //--TRIMMABLE-BOUNDARY-START(12886445819)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886445819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NotificationType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, $.$discardRef(), "NotificationType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NotificationType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "NotificationType";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)).NotificationType);
                        }, $TbWhTb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1543931,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NotificationType = value.AsEnumValue($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type);
                        }, $BQxbNc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1543931,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Date"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, $.$discardRef(), "Date", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Date")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Date";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)).Date);
                        }, $cbzDha ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1543931,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Date = value.AsDateTime();
                        }, $iRwJsd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1543931,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ThreadId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, $.$discardRef(), "ThreadId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ThreadId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ThreadId";
                        $i5.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)).ThreadId);
                        }, $lCiAwb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1543931,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ThreadId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $QEtSxf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1543931,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AccountId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.$type, $.$discardRef(), "AccountId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AccountId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "AccountId";
                        $i7.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)).AccountId);
                        }, $IDZRAa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1543931,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.AccountId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $DFHJca ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1543931,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886445819)
            
            //--TRIMMABLE-BOUNDARY-START(17181413115)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181413115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _NotificationType = _target.NotificationType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NotificationType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel.Type, () => _NotificationType, ($v) => _NotificationType = $v, null, true)))
                    {
                        _target.NotificationType = _NotificationType;
                    }
                }
                {
                    /*var*/ let _Date = _target.Date;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Date"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Date, ($v) => _Date = $v, null, true)))
                    {
                        _target.Date = _Date;
                    }
                }
                {
                    /*var*/ let _ThreadId = _target.ThreadId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ThreadId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _ThreadId, ($v) => _ThreadId = $v, null, true)))
                    {
                        _target.ThreadId = $.$clone(_ThreadId);
                    }
                }
                {
                    /*var*/ let _AccountId = _target.AccountId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AccountId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _AccountId, ($v) => _AccountId = $v, null, true)))
                    {
                        _target.AccountId = $.$clone(_AccountId);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181413115)
            
            //--TRIMMABLE-BOUNDARY-START(8591478523)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591478523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCM.CommunityChatThreadNotificationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadNotificationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591478523)
            
            static $h = 1543931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886445819),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1543931,
      "h": 12886445819,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886445819),
//--TRIMMABLE-BOUNDARY-START(17181413115),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1347323,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1543931,
      "h": 17181413115,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181413115),
//--TRIMMABLE-BOUNDARY-START(8591478523),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1347323,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1543931,
      "h": 8591478523,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591478523)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296511227),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1543931,
      "h": 4296511227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296511227)
  ],
  "h": 1543931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadNotificationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadNotificationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadNotificationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1543931)
        
        

        //--TRIMMABLE-BOUNDARY-START(429819)
        $asm.$cls(`$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor`, ($self) => class AccountChatFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.AccountChatFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295397115)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295397115);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor.GenerateProperties($.$Bykq.LCCCCM.AccountChatFeatureModel, this, factory);
                    }, $msZYXd ??= {"r":65537,"n":"","d":429819,"h":0,"f":17825794}), 0, "AccountChatFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Models_AccountChatFeatureModel_LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModelTypeDescriptorBuilder.g.cs", "AccountChatFeatureModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295397115)
            
            //--TRIMMABLE-BOUNDARY-START(12885331707)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885331707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PinnedMessages"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "PinnedMessages", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PinnedMessages")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PinnedMessages";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).PinnedMessages);
                        }, $ykxuBh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PinnedMessages = value.AsReference($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)));
                        }, $WWODPd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Favorites"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "Favorites", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Favorites")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Favorites";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).Favorites);
                        }, $qLHfEg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Favorites = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $cPWAkf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MutedChats"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "MutedChats", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MutedChats")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MutedChats";
                        $i5.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).MutedChats);
                        }, $ZcfyBh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MutedChats = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $HWdAme ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PinnedChats"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "PinnedChats", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PinnedChats")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "PinnedChats";
                        $i7.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).PinnedChats);
                        }, $Ewpnyc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PinnedChats = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $nscJFa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HiddenChats"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "HiddenChats", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HiddenChats")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "HiddenChats";
                        $i9.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).HiddenChats);
                        }, $FVLEFc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.HiddenChats = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $MjGNxj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GlobalRemoteActionNotificationsDisabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "GlobalRemoteActionNotificationsDisabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GlobalRemoteActionNotificationsDisabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "GlobalRemoteActionNotificationsDisabled";
                        $i11.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).GlobalRemoteActionNotificationsDisabled);
                        }, $PEdcmk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GlobalRemoteActionNotificationsDisabled = value.AsBool();
                        }, $WpshZa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RemoteActionNotificationsDisabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.AccountChatFeatureModel.$type, $.$discardRef(), "RemoteActionNotificationsDisabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RemoteActionNotificationsDisabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "RemoteActionNotificationsDisabled";
                        $i13.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$Bykq.LCCCCM.AccountChatFeatureModel)).RemoteActionNotificationsDisabled);
                        }, $WFKrjh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":429819,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RemoteActionNotificationsDisabled = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $NUyzGf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":429819,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$Bykq.LCCCCM.AccountChatFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885331707)
            
            //--TRIMMABLE-BOUNDARY-START(17180299003)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180299003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.AccountFeatureModel<LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$Bykq.LCCCCM.AccountChatFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$Bykq.LCCCCM.AccountChatFeatureModel)));
                {
                    /*var*/ let _PinnedMessages = _target.PinnedMessages;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PinnedMessages"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), property, $.$ref(() => _PinnedMessages, ($v) => _PinnedMessages = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)))))
                    {
                        _target.PinnedMessages = _PinnedMessages;
                        if (_PinnedMessages !== null)
                        {
                            let $en18 = _PinnedMessages.SCG$IEnumerable$$$GetEnumerator();
                            while ($en18.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en18.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), property, $.$ref(() => _PinnedMessages, ($v) => _PinnedMessages = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))));
                    }
                }
                {
                    /*var*/ let _Favorites = _target.Favorites;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Favorites"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Favorites, ($v) => _Favorites = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Favorites = _Favorites;
                        if (_Favorites !== null)
                        {
                            let $en23 = _Favorites.SCG$IEnumerable$$$GetEnumerator();
                            while ($en23.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en23.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Favorites, ($v) => _Favorites = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _MutedChats = _target.MutedChats;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MutedChats"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _MutedChats, ($v) => _MutedChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.MutedChats = _MutedChats;
                        if (_MutedChats !== null)
                        {
                            let $en28 = _MutedChats.SCG$IEnumerable$$$GetEnumerator();
                            while ($en28.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en28.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _MutedChats, ($v) => _MutedChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _PinnedChats = _target.PinnedChats;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PinnedChats"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _PinnedChats, ($v) => _PinnedChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.PinnedChats = _PinnedChats;
                        if (_PinnedChats !== null)
                        {
                            let $en33 = _PinnedChats.SCG$IEnumerable$$$GetEnumerator();
                            while ($en33.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en33.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _PinnedChats, ($v) => _PinnedChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _HiddenChats = _target.HiddenChats;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HiddenChats"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _HiddenChats, ($v) => _HiddenChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.HiddenChats = _HiddenChats;
                        if (_HiddenChats !== null)
                        {
                            let $en38 = _HiddenChats.SCG$IEnumerable$$$GetEnumerator();
                            while ($en38.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en38.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _HiddenChats, ($v) => _HiddenChats = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _GlobalRemoteActionNotificationsDisabled = _target.GlobalRemoteActionNotificationsDisabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GlobalRemoteActionNotificationsDisabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _GlobalRemoteActionNotificationsDisabled, ($v) => _GlobalRemoteActionNotificationsDisabled = $v, null, true)))
                    {
                        _target.GlobalRemoteActionNotificationsDisabled = _GlobalRemoteActionNotificationsDisabled;
                    }
                }
                {
                    /*var*/ let _RemoteActionNotificationsDisabled = _target.RemoteActionNotificationsDisabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RemoteActionNotificationsDisabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _RemoteActionNotificationsDisabled, ($v) => _RemoteActionNotificationsDisabled = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.RemoteActionNotificationsDisabled = _RemoteActionNotificationsDisabled;
                        if (_RemoteActionNotificationsDisabled !== null)
                        {
                            let $en44 = _RemoteActionNotificationsDisabled.SCG$IEnumerable$$$GetEnumerator();
                            while ($en44.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en44.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _RemoteActionNotificationsDisabled, ($v) => _RemoteActionNotificationsDisabled = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180299003)
            
            //--TRIMMABLE-BOUNDARY-START(8590364411)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590364411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCM.AccountChatFeatureModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCM.AccountChatFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.AccountChatFeatureModel)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCM.AccountChatFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.AccountChatFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCM.AccountChatFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.AccountChatFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590364411)
            
            static $h = 429819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.AccountChatFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885331707),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 429819,
      "h": 12885331707,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885331707),
//--TRIMMABLE-BOUNDARY-START(17180299003),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 298747,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 429819,
      "h": 17180299003,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180299003),
//--TRIMMABLE-BOUNDARY-START(8590364411),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 298747,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 429819,
      "h": 8590364411,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590364411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295397115),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 429819,
      "h": 4295397115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295397115)
  ],
  "h": 429819
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCM.AccountChatFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.AccountChatFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}AccountChatFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(429819)
        
        

        //--TRIMMABLE-BOUNDARY-START(2002683)
        $asm.$cls(`$Bykq.LCCCCS$1.ChatSettingsTypeDescriptor`, ($self) => class ChatSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCS$1.ChatSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296969979)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296969979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCS$1.ChatSettingsTypeDescriptor.GenerateProperties($.$Bykq.LCCCCS$1.ChatSettings, this, factory);
                    }, $QULrGi ??= {"r":65537,"n":"","d":2002683,"h":0,"f":17825794}), 0, "ChatSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Settings_ChatSettings_LivingThing.Core.Community.Chat.Common.Settings.ChatSettingsTypeDescriptorBuilder.g.cs", "ChatSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296969979)
            
            //--TRIMMABLE-BOUNDARY-START(12886904571)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886904571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886904571)
            
            //--TRIMMABLE-BOUNDARY-START(17181871867)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Settings.ChatSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181871867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181871867)
            
            //--TRIMMABLE-BOUNDARY-START(8591937275)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Settings.ChatSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591937275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCS$1.ChatSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCS$1.ChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$1.ChatSettings)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCS$1.ChatSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$1.ChatSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCS$1.ChatSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$1.ChatSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591937275)
            
            static $h = 2002683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCS$1.ChatSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886904571),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2002683,
      "h": 12886904571,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886904571),
//--TRIMMABLE-BOUNDARY-START(17181871867),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1871611,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2002683,
      "h": 17181871867,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181871867),
//--TRIMMABLE-BOUNDARY-START(8591937275),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1871611,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2002683,
      "h": 8591937275,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591937275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296969979),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2002683,
      "h": 4296969979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296969979)
  ],
  "h": 2002683
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCS$1.ChatSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Settings.ChatSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Settings${separator}ChatSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2002683)
        
        

        //--TRIMMABLE-BOUNDARY-START(2264827)
        $asm.$cls(`$Bykq.LCCCCS$2.ChatStatesTypeDescriptor`, ($self) => class ChatStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCS$2.ChatStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4297232123)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297232123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCS$2.ChatStatesTypeDescriptor.GenerateProperties($.$Bykq.LCCCCS$2.ChatStates, this, factory);
                    }, $xefcLg ??= {"r":65537,"n":"","d":2264827,"h":0,"f":17825794}), 0, "ChatStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\States_ChatStates_LivingThing.Core.Community.Chat.Common.States.ChatStatesTypeDescriptorBuilder.g.cs", "ChatStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297232123)
            
            //--TRIMMABLE-BOUNDARY-START(12887166715)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887166715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887166715)
            
            //--TRIMMABLE-BOUNDARY-START(17182134011)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.States.ChatStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182134011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.States.ComponentStates?*/ let targetBase = _target;
                $.$Iaui.LCFCMS$1.ComponentStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS$1.ComponentStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182134011)
            
            //--TRIMMABLE-BOUNDARY-START(8592199419)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.States.ChatStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592199419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCS$2.ChatStates().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCS$2.ChatStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$2.ChatStates)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCS$2.ChatStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$2.ChatStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCS$2.ChatStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCS$2.ChatStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592199419)
            
            static $h = 2264827;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCS$2.ChatStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887166715),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2264827,
      "h": 12887166715,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887166715),
//--TRIMMABLE-BOUNDARY-START(17182134011),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2133755,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2264827,
      "h": 17182134011,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182134011),
//--TRIMMABLE-BOUNDARY-START(8592199419),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2133755,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2264827,
      "h": 8592199419,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592199419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297232123),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2264827,
      "h": 4297232123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297232123)
  ],
  "h": 2264827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCS$2.ChatStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.States.ChatStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}States${separator}ChatStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2264827)
        
        

        //--TRIMMABLE-BOUNDARY-START(560891)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatMessageModel`, ($self) => class CommunityChatMessageModel extends $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(68720037627)
            /*DataId*/ ThirdPartyId;
            //--TRIMMABLE-BOUNDARY-END(68720037627)
            
            //--TRIMMABLE-BOUNDARY-START(73015004923)
            /*PostTypes */ get Type()
            {
                return 770/*PostTypes.ChatMessage*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73015004923)
            
            //--TRIMMABLE-BOUNDARY-START(55835135739)
            /*bool */ ShouldEditName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835135739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835135739)
            
            //--TRIMMABLE-BOUNDARY-START(51540168443)
            /*bool */ ShouldEditIcon()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540168443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540168443)
            
            //--TRIMMABLE-BOUNDARY-START(64425070331)
            /*bool */ ShouldEditTags()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425070331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425070331)
            
            //--TRIMMABLE-BOUNDARY-START(60130103035)
            /*bool */ ShouldEditSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130103035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130103035)
            
            //--TRIMMABLE-BOUNDARY-START(38655266555)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655266555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655266555)
            
            //--TRIMMABLE-BOUNDARY-START(34360299259)
            /*void */ ModifyDescriptor(/*IPropertyDescriptorModifierBuilder*/ propertyBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360299259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.ModifyDescriptor(propertyBuilder);
                if (propertyBuilder.LCFCD$1$IPropertyDescriptorModifierBuilder$Schema === 1/*SchemaType.Form*/)
                {
                    $.$LCOv.LCFCPM$1.PostBaseModel.Decorate(propertyBuilder, "Post", "", "Enter Chat Message", null, null, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360299259)
            
            //--TRIMMABLE-BOUNDARY-START(77309972219)
            /*IEnumerable<IPropertyDescriptor> */ UpdateDescriptors(/*IEnumerable<IPropertyDescriptor>*/ descriptors, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309972219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/)
                {
                    descriptors = $.$sl.SL.Enumerable.Where($.$fPer.LCFCD$1.IPropertyDescriptor, descriptors, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IPropertyDescriptor, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                    {
                        return d.LCFCD$1$IPropertyDescriptor$Name === "Post";
                    }, $OwCRHk ??= {"r":262145,"p":[{"n":"d","p":40733014}],"n":"","d":560891,"h":0,"f":17825794}));
                }
                return super.UpdateDescriptors(descriptors, $.$clone(schema));
            }
            //--TRIMMABLE-BOUNDARY-END(77309972219)
            
            //--TRIMMABLE-BOUNDARY-START(12885462779)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885462779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let chat;
                if (!$.$$.S.Object.ReferenceEquals(this, obj) && $.$is(obj, $.$Bykq.LCCCCM.CommunityChatMessageModel, { set $v($v){ chat = $v; } }) && this.Identifier.Empty && chat.Identifier.Empty)
                {
                    return false;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(12885462779)
            
            //--TRIMMABLE-BOUNDARY-START(8590495483)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590495483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590495483)
            
            //--TRIMMABLE-BOUNDARY-START(8590495483)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8590495483)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68720037627)
                this.ThirdPartyId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(68720037627)
                
            }
            static $h = 560891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720037627),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475397371,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245201147,
        "f": 83886081
      },
      "n": "ThirdPartyId",
      "d": 560891,
      "h": 68720037627,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720037627),
//--TRIMMABLE-BOUNDARY-START(73015004923),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065331963,
        "f": 50364417
      },
      "n": "Type",
      "d": 560891,
      "h": 73015004923,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73015004923)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835135739),
    {
      "r": 262145,
      "n": "ShouldEditName",
      "d": 560891,
      "h": 55835135739,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835135739),
//--TRIMMABLE-BOUNDARY-START(51540168443),
    {
      "r": 262145,
      "n": "ShouldEditIcon",
      "d": 560891,
      "h": 51540168443,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540168443),
//--TRIMMABLE-BOUNDARY-START(64425070331),
    {
      "r": 262145,
      "n": "ShouldEditTags",
      "d": 560891,
      "h": 64425070331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425070331),
//--TRIMMABLE-BOUNDARY-START(60130103035),
    {
      "r": 262145,
      "n": "ShouldEditSummary",
      "d": 560891,
      "h": 60130103035,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130103035),
//--TRIMMABLE-BOUNDARY-START(38655266555),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 560891,
      "h": 38655266555,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655266555),
//--TRIMMABLE-BOUNDARY-START(34360299259),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyBuilder",
          "p": 40929622
        }
      ],
      "n": "ModifyDescriptor",
      "d": 560891,
      "h": 34360299259,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360299259),
//--TRIMMABLE-BOUNDARY-START(77309972219),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "UpdateDescriptors",
      "d": 560891,
      "h": 77309972219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309972219),
//--TRIMMABLE-BOUNDARY-START(12885462779),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 560891,
      "h": 12885462779,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885462779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590495483),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 560891,
      "h": 8590495483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590495483)
  ],
  "h": 560891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatMessageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(560891)
        
        

        //--TRIMMABLE-BOUNDARY-START(1740539)
        $asm.$cls(`$Bykq.LCCCCS.ICommunityChatRemoteService`, ($self) => class ICommunityChatRemoteService
        {
            static $h = 1740539;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1740539,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Services.ICommunityChatRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Services${separator}ICommunityChatRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1740539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1806075)
        $asm.$cls(`$Bykq.LCCCCS.ICommunityChatRemoteService_Mocking`, ($self) => class ICommunityChatRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296773371)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296773371);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296773371)
            
            //--TRIMMABLE-BOUNDARY-START(8591740667)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatMessageModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591740667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatMessageModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591740667)
            
            //--TRIMMABLE-BOUNDARY-START(17181675259)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatMessageModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181675259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Bykq.LCCCCM.CommunityChatMessageModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181675259)
            
            //--TRIMMABLE-BOUNDARY-START(21476642555)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatMessageModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476642555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Bykq.LCCCCM.CommunityChatMessageModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476642555)
            
            //--TRIMMABLE-BOUNDARY-START(25771609851)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatMessageModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771609851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatMessageModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771609851)
            
            //--TRIMMABLE-BOUNDARY-START(12886707963)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886707963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatMessageModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886707963)
            
            static $h = 1806075;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296773371),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1806075,
      "h": 4296773371,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296773371)
  ],
  "h": 1806075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$Bykq.LCCCCS.ICommunityChatRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Services.ICommunityChatRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Services${separator}ICommunityChatRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1806075)
        
        

        //--TRIMMABLE-BOUNDARY-START(1085179)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadModel`, ($self) => class CommunityChatThreadModel extends $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(73015529211)
            /*DataId*/ ThirdPartyId;
            //--TRIMMABLE-BOUNDARY-END(73015529211)
            
            //--TRIMMABLE-BOUNDARY-START(77310496507)
            /*PostTypes */ get Type()
            {
                return 769/*PostTypes.ChatThread*/;
            }
            //--TRIMMABLE-BOUNDARY-END(77310496507)
            
            //--TRIMMABLE-BOUNDARY-START(42950758139)
            /*bool */ get IsPublicRoom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180954363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((this.PostFlags & (1n)) == (1n));
            }
            /*bool */ set IsPublicRoom(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130627323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value)
                {
                    this.PostFlags |= 1n;
                }
                else 
                {
                    this.PostFlags &= ~1n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950758139)
            
            //--TRIMMABLE-BOUNDARY-START(51540692731)
            /*bool */ RequiresSummary()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540692731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540692731)
            
            //--TRIMMABLE-BOUNDARY-START(47245725435)
            /*bool */ RequiresPost()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245725435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245725435)
            
            //--TRIMMABLE-BOUNDARY-START(38655790843)
            /*AccountBaseModel */ GetRespondent(/*AccountBaseModel*/ current)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655790843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel>?*/ let __ca1__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.AccountBaseModel>?*/ let __ca2__;
                if (((__ca1__ = this.Subscribers) !== null ? $.$sl.SL.Enumerable.Count$1($.$LCOv.LCFCPM$1.AccountBaseModel, __ca1__) : null) === 1)
                {
                    return current;
                }
                else if (((__ca2__ = this.Subscribers) !== null ? $.$sl.SL.Enumerable.Count$1($.$LCOv.LCFCPM$1.AccountBaseModel, __ca2__) : null) === 2)
                {
                    return $.$sl.SL.Enumerable.FirstOrDefault$3($.$LCOv.LCFCPM$1.AccountBaseModel, $.$sl.SL.Enumerable.Except$1($.$LCOv.LCFCPM$1.AccountBaseModel, this.Subscribers, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.AccountBaseModel), [current], null, null))) ?? this.Account ?? current;
                }
                return this.Account ?? current;
            }
            //--TRIMMABLE-BOUNDARY-END(38655790843)
            
            //--TRIMMABLE-BOUNDARY-START(8591019771)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591019771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591019771)
            
            //--TRIMMABLE-BOUNDARY-START(8591019771)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(8591019771)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015529211)
                this.ThirdPartyId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(73015529211)
                
            }
            static $h = 1085179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015529211),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770888955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720561915,
        "f": 83886081
      },
      "n": "ThirdPartyId",
      "d": 1085179,
      "h": 73015529211,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015529211),
//--TRIMMABLE-BOUNDARY-START(77310496507),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360823547,
        "f": 50364417
      },
      "n": "Type",
      "d": 1085179,
      "h": 77310496507,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310496507),
//--TRIMMABLE-BOUNDARY-START(42950758139),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180954363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130627323,
        "f": 83886081
      },
      "n": "IsPublicRoom",
      "d": 1085179,
      "h": 42950758139,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950758139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540692731),
    {
      "r": 262145,
      "n": "RequiresSummary",
      "d": 1085179,
      "h": 51540692731,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540692731),
//--TRIMMABLE-BOUNDARY-START(47245725435),
    {
      "r": 262145,
      "n": "RequiresPost",
      "d": 1085179,
      "h": 47245725435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245725435),
//--TRIMMABLE-BOUNDARY-START(38655790843),
    {
      "r": 6220212,
      "p": [
        {
          "n": "current",
          "p": 6220212
        }
      ],
      "n": "GetRespondent",
      "d": 1085179,
      "h": 38655790843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655790843)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591019771),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1085179,
      "h": 8591019771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591019771)
  ],
  "h": 1085179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$LCOv.LCFCP.IPostCategory, $.$LCOv.LCFCP.IPost ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1085179)
        
        

        //--TRIMMABLE-BOUNDARY-START(691963)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor`, ($self) => class CommunityChatMessageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295659259)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295659259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor.GenerateProperties($.$Bykq.LCCCCM.CommunityChatMessageModel, this, factory);
                    }, $slyUzd ??= {"r":65537,"n":"","d":691963,"h":0,"f":17825794}), 0, "CommunityChatMessageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Models_CommunityChatMessageModel_LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModelTypeDescriptorBuilder.g.cs", "CommunityChatMessageModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295659259)
            
            //--TRIMMABLE-BOUNDARY-START(12885593851)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885593851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ThirdPartyId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatMessageModel.$type, $.$discardRef(), "ThirdPartyId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ThirdPartyId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ThirdPartyId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatMessageModel)).ThirdPartyId);
                        }, $itBOkj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":691963,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.ThirdPartyId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $thHIfi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":691963,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatMessageModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatMessageModel)).Type);
                        }, $wvhJga ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":691963,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885593851)
            
            //--TRIMMABLE-BOUNDARY-START(17180561147)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180561147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.PostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Frameworks.Common.Posts.Models.GenericPostModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.PostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.PostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel)));
                {
                    /*var*/ let _ThirdPartyId = _target.ThirdPartyId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ThirdPartyId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _ThirdPartyId, ($v) => _ThirdPartyId = $v, null, true)))
                    {
                        _target.ThirdPartyId = $.$clone(_ThirdPartyId);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180561147)
            
            //--TRIMMABLE-BOUNDARY-START(8590626555)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590626555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCM.CommunityChatMessageModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCM.CommunityChatMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatMessageModel)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCM.CommunityChatMessageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatMessageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCM.CommunityChatMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatMessageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590626555)
            
            static $h = 691963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885593851),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 691963,
      "h": 12885593851,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885593851),
//--TRIMMABLE-BOUNDARY-START(17180561147),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 560891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 691963,
      "h": 17180561147,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180561147),
//--TRIMMABLE-BOUNDARY-START(8590626555),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 560891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 691963,
      "h": 8590626555,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590626555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295659259),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 691963,
      "h": 4295659259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295659259)
  ],
  "h": 691963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatMessageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatMessageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(691963)
        
        

        //--TRIMMABLE-BOUNDARY-START(2461435)
        $asm.$cls(`$Bykq.LCFCR.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityChatThreadModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297428731)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297428731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297428731)
            
            //--TRIMMABLE-BOUNDARY-START(8592396027)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592396027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592396027)
            
            //--TRIMMABLE-BOUNDARY-START(17182330619)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182330619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Bykq.LCCCCM.CommunityChatThreadModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182330619)
            
            //--TRIMMABLE-BOUNDARY-START(21477297915)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477297915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.WireTransportModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Bykq.LCCCCM.CommunityChatThreadModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477297915)
            
            //--TRIMMABLE-BOUNDARY-START(25772265211)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Chat$Common$Models$CommunityChatThreadModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772265211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772265211)
            
            //--TRIMMABLE-BOUNDARY-START(12887363323)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887363323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$Bykq.LCCCCM.CommunityChatThreadModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887363323)
            
            static $h = 2461435;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297428731),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2461435,
      "h": 4297428731,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297428731)
  ],
  "h": 2461435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.ICreateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.IReadDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.IReadManyDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.IUpdateDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD.IDeleteDataService$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityChatThreadModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityChatThreadModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2461435)
        
        

        //--TRIMMABLE-BOUNDARY-START(1216251)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor`, ($self) => class CommunityChatThreadModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296183547)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296183547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor.GenerateProperties($.$Bykq.LCCCCM.CommunityChatThreadModel, this, factory);
                    }, $xJsVzd ??= {"r":65537,"n":"","d":1216251,"h":0,"f":17825794}), 0, "CommunityChatThreadModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Models_CommunityChatThreadModel_LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModelTypeDescriptorBuilder.g.cs", "CommunityChatThreadModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296183547)
            
            //--TRIMMABLE-BOUNDARY-START(12886118139)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886118139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ThirdPartyId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadModel.$type, $.$discardRef(), "ThirdPartyId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ThirdPartyId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ThirdPartyId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadModel)).ThirdPartyId);
                        }, $bvxSJh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1216251,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.ThirdPartyId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $SDnDFc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1216251,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadModel)).Type);
                        }, $OvruWj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1216251,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsPublicRoom"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$Bykq.LCCCCM.CommunityChatThreadModel.$type, $.$discardRef(), "IsPublicRoom", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsPublicRoom")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "IsPublicRoom";
                        $i5.DelaredOn = "LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$Bykq.LCCCCM.CommunityChatThreadModel)).IsPublicRoom);
                        }, $RHMuAj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1216251,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.IsPublicRoom = value.AsBool();
                        }, $sNWAGe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1216251,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886118139)
            
            //--TRIMMABLE-BOUNDARY-START(17181085435)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181085435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Categories.CategoryPostModel<LivingThing.Core.Frameworks.Common.Posts.Models.Categories.NoCategoryPostModel, LivingThing.Core.Community.Chat.Common.Models.CommunityChatMessageModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMC.CategoryPostModelTypeDescriptor$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMC.CategoryPostModel$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$Bykq.LCCCCM.CommunityChatMessageModel)));
                {
                    /*var*/ let _ThirdPartyId = _target.ThirdPartyId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ThirdPartyId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _ThirdPartyId, ($v) => _ThirdPartyId = $v, null, true)))
                    {
                        _target.ThirdPartyId = $.$clone(_ThirdPartyId);
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _IsPublicRoom = _target.IsPublicRoom;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsPublicRoom"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsPublicRoom, ($v) => _IsPublicRoom = $v, null, true)))
                    {
                        _target.IsPublicRoom = _IsPublicRoom;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181085435)
            
            //--TRIMMABLE-BOUNDARY-START(8591150843)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591150843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCM.CommunityChatThreadModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCM.CommunityChatThreadModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadModel)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCM.CommunityChatThreadModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCM.CommunityChatThreadModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatThreadModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591150843)
            
            static $h = 1216251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886118139),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1216251,
      "h": 12886118139,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886118139),
//--TRIMMABLE-BOUNDARY-START(17181085435),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1085179,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1216251,
      "h": 17181085435,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181085435),
//--TRIMMABLE-BOUNDARY-START(8591150843),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1085179,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1216251,
      "h": 8591150843,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591150843)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296183547),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1216251,
      "h": 4296183547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296183547)
  ],
  "h": 1216251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatThreadModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatThreadModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatThreadModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1216251)
        
        

        //--TRIMMABLE-BOUNDARY-START(823035)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatModel`, ($self) => class CommunityChatModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295790331)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295790331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295790331)
            
            //--TRIMMABLE-BOUNDARY-START(4295790331)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295790331)
            
            static $h = 823035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295790331),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 823035,
      "h": 4295790331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295790331)
  ],
  "h": 823035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(823035)
        
        

        //--TRIMMABLE-BOUNDARY-START(954107)
        $asm.$cls(`$Bykq.LCCCCM.CommunityChatModelTypeDescriptor`, ($self) => class CommunityChatModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295921403)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295921403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$Bykq.LCCCCM.CommunityChatModelTypeDescriptor.GenerateProperties($.$Bykq.LCCCCM.CommunityChatModel, this, factory);
                    }, $NmDFJb ??= {"r":65537,"n":"","d":954107,"h":0,"f":17825794}), 0, "CommunityChatModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Chat.Common\\Models_CommunityChatModel_LivingThing.Core.Community.Chat.Common.Models.CommunityChatModelTypeDescriptorBuilder.g.cs", "CommunityChatModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295921403)
            
            //--TRIMMABLE-BOUNDARY-START(12885855995)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885855995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885855995)
            
            //--TRIMMABLE-BOUNDARY-START(17180823291)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180823291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ComponentModel<LivingThing.Core.Community.Chat.Common.Settings.ChatSettings, LivingThing.Core.Community.Chat.Common.States.ChatStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ComponentModelTypeDescriptor$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ComponentModel$$$($.$Bykq.LCCCCS$1.ChatSettings, $.$Bykq.LCCCCS$2.ChatStates)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180823291)
            
            //--TRIMMABLE-BOUNDARY-START(8590888699)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Chat.Common.Models.CommunityChatModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590888699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$Bykq.LCCCCM.CommunityChatModel().$ctor$7();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$Bykq.LCCCCM.CommunityChatModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatModel)))
                {
                    /*var*/ let result = $.$Bykq.LCCCCM.CommunityChatModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$Bykq.LCCCCM.CommunityChatModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$Bykq.LCCCCM.CommunityChatModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590888699)
            
            static $h = 954107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885855995),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 954107,
      "h": 12885855995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885855995),
//--TRIMMABLE-BOUNDARY-START(17180823291),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 823035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 954107,
      "h": 17180823291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180823291),
//--TRIMMABLE-BOUNDARY-START(8590888699),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 823035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 954107,
      "h": 8590888699,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590888699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295921403),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 954107,
      "h": 4295921403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295921403)
  ],
  "h": 954107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$Bykq.LCCCCM.CommunityChatModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Chat.Common.Models.CommunityChatModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Chat${separator}Common${separator}Models${separator}CommunityChatModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(954107)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(36603)
