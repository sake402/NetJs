
//--TRIMMABLE-BOUNDARY-START(32675)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $jlvo, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $GYJg, $PZCj, $yCMk, $PIIp, $cDXw) {
    "use strict";
    let _;
    let $yYBOIf;
    let $BrBVsb;
    let $ESIuTc;
    let $hyneld;
    let $uUcOAd;
    let $LtZENh;
    let $NVDioc;
    let $yPgVfa;
    let $SlPFeb;
    let $Ciwztc;
    let $kXBWKa;
    let $bdgnkl;
    let $lREzbg;
    let $cwFyeb;
    let $VrAxdh;
    let $hOPbCk;
    let $uiBvKi;
    let $kdvdqd;
    let $XVUTHg;
    let $FiVzbc;
    let $qgKVod;
    let $fWQRGc;
    let $ChXhad;
    let $YSXLWe;
    let $Nquxcb;
    let $ztDeQc;
    let $aJAHGg;
    let $uNlXEa;
    let $hQWyeh;
    let $wTzwqh;
    let $AkmoCk;
    let $QWFnYd;
    let $Iyktrf;
    let $qcdPjc;
    let $xJXmgi;
    let $kKgeng;
    let $gVBdPi;
    let $AeVoAe;
    let $SiRZgg;
    let $XlZEQa;
    let $AsDIkl;
    let $EcKska;
    let $uAHqJf;
    let $YNNArd;
    let $bVkzQg;
    let $qEHjVa;
    let $XOCEmk;
    let $ckkBzd;
    let $DlZhef;
    let $ufKZPg;
    let $NGrDed;
    let $Ylnmnj;
    let $WsYjIh;
    let $MLdhud;
    let $VJeBhh;
    let $ZiUMEh;
    let $jAJXpi;
    let $dgAwRj;
    let $MmvmFi;
    let $YOEmde;
    let $nXSoJc;
    let $ozFMub;
    let $mwfFoc;
    let $MTgEXc;
    let $hyDpZc;
    let $GnTMgj;
    let $aJsySc;
    let $gYiMic;
    let $Ynhspl;
    let $HVmNpg;
    let $qIvlGb;
    let $PpzeSf;
    let $cIIsAb;
    let $QdTuLf;
    let $MAiawb;
    let $vorDzk;
    let $JJORuk;
    let $eTvKBc;
    let $jLszsj;
    let $FwAmIj;
    let $KLXEYf;
    let $fdXhde;
    let $qcdMzk;
    let $whPEmh;
    let $JRQEEk;
    let $reZPja;
    let $hsmovg;
    let $oddUxj;
    let $NqUeua;
    let $yjfvgi;
    let $obTyMj;
    let $RHhXTb;
    let $ZgYMMf;
    let $uUhFYe;
    let $iTkBde;
    let $nibVkh;
    let $QeJNdh;
    let $gkLxAh;
    let $mjoJXb;
    let $fxHBib;
    let $WNrShh;
    let $KhCXck;
    let $HuRCte;
    let $KsVUJd;
    let $DPjJAe;
    let $mAbWAb;
    let $PBTMwb;
    let $XxYgJi;
    let $AyUTea;
    let $WKNkFe;
    let $aldJKe;
    let $UgHPkg;
    let $ipyptj;
    let $uBABqf;
    let $UBYpDe;
    let $jpfjoc;
    let $SqfSsf;
    let $PHiOzk;
    let $NCEnpb;
    let $TIvztk;
    let $yuqGlj;
    let $AXIoxf;
    let $LJYtQa;
    let $zWLrvf;
    let $BdSUoj;
    let $DbrNvi;
    let $rHAOYg;
    let $DAUyCa;
    let $dFjQBa;
    let $ZwfgTb;
    let $uhYhWi;
    let $YckFsb;
    let $DhvNDb;
    let $SWPYMf;
    let $DdiONd;
    let $kWITzh;
    let $CUMJla;
    let $YzafXc;
    let $iuPQIa;
    let $GVResh;
    let $IWDPPe;
    let $wijXij;
    let $vfTQvd;
    let $qkVplb;
    let $eeIKvf;
    let $mBmWVe;
    let $GoWVSg;
    let $NzXArb;
    let $RGiNli;
    let $sAxuAe;
    let $PCWxlh;
    let $YGfbtg;
    let $lgfEXf;
    let $upxHih;
    let $jYAVpi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Church.Client.Blazor", 
    {
  "h": 32675,
  "f": "LivingThing.Core.Community.Church.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Church.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Church.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(360355)
        $asm.$cls(`$pGPn.LCCCC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295327651)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295327651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$pGPn.LCCCC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295327651)
            
            static $h = 360355;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295327651),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 360355,
      "h": 4295327651,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295327651)
  ],
  "h": 360355
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(360355)
        
        

        //--TRIMMABLE-BOUNDARY-START(491427)
        $asm.$cls(`$pGPn.LCCCC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590426019)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590426019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$pGPn.LCCCCP.CommunityChurchPortalApp, "LivingThing.Core.Community.Church.Client", "Pages\\CommunityChurchPortalApp", "Community Church Portal App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/ChurchPortal/{*PageRoute}" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$pGPn.LCCCCP.CommunityChurchUserApp, "LivingThing.Core.Community.Church.Client", "Pages\\CommunityChurchUserApp", "Community Church User App", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Church/{*PageRoute}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590426019)
            
            //--TRIMMABLE-BOUNDARY-START(4295458723)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295458723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295458723)
            
            //--TRIMMABLE-BOUNDARY-START(4295458723)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295458723)
            
            static $h = 491427;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590426019),
    {
      "r": 65537,
      "n": "Build",
      "d": 491427,
      "h": 8590426019,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590426019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295458723),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 491427,
      "h": 4295458723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295458723)
  ],
  "h": 491427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(491427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1277859)
        $asm.$cls(`$pGPn.LCCCCS.Place`, ($self) => class Place extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77310689187)
            /*string?*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(77310689187)
            
            //--TRIMMABLE-BOUNDARY-START(133145264035)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(133145264035)
            
            //--TRIMMABLE-BOUNDARY-START(30066048931)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30066048931)
            
            //--TRIMMABLE-BOUNDARY-START(81605656483)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(81605656483)
            
            //--TRIMMABLE-BOUNDARY-START(85900623779)
            /*object?*/ LinkParameter = null;
            //--TRIMMABLE-BOUNDARY-END(85900623779)
            
            //--TRIMMABLE-BOUNDARY-START(25771081635)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771081635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771081635)
            
            //--TRIMMABLE-BOUNDARY-START(25771081635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25771081635)
            
            static $h = 1277859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310689187),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245918115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080492963,
        "f": 83886081
      },
      "n": "Icon",
      "d": 1277859,
      "h": 77310689187,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310689187),
//--TRIMMABLE-BOUNDARY-START(133145264035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015721891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850296739,
        "f": 83886081
      },
      "n": "Title",
      "d": 1277859,
      "h": 133145264035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145264035),
//--TRIMMABLE-BOUNDARY-START(30066048931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655983523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490558371,
        "f": 83886081
      },
      "n": "Description",
      "d": 1277859,
      "h": 30066048931,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066048931),
//--TRIMMABLE-BOUNDARY-START(81605656483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835852707,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670427555,
        "f": 83886081
      },
      "n": "Link",
      "d": 1277859,
      "h": 81605656483,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605656483),
//--TRIMMABLE-BOUNDARY-START(85900623779),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425787299,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260362147,
        "f": 83886081
      },
      "n": "LinkParameter",
      "d": 1277859,
      "h": 85900623779,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900623779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771081635),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1277859,
      "h": 25771081635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771081635)
  ],
  "h": 1277859
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.Place`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}Place`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1277859)
        
        

        //--TRIMMABLE-BOUNDARY-START(229283)
        $asm.$cls(`$pGPn._LCCCCPH.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295196579)
            static /*void */ CreateCommunityAccountBanner_0(TAccount, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TAccount*/ __arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295196579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountBanner$$(TAccount), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TAccount));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295196579)
            
            static $h = 229283;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295196579),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TAccount) => TAccount.$h
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "CreateCommunityAccountBanner_0",
      "d": 229283,
      "h": 4295196579,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295196579)
  ],
  "h": 229283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Church.Client.Pages.HomePage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}HomePage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(229283)
        
        

        //--TRIMMABLE-BOUNDARY-START(163747)
        $asm.$cls(`$pGPn._LCCCCPC$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295131043)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295131043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295131043)
            
            static $h = 163747;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295131043),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 163747,
      "h": 4295131043,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295131043)
  ],
  "h": 163747
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Church.Client.Pages.CommunityChurchUserApp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}CommunityChurchUserApp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(163747)
        
        

        //--TRIMMABLE-BOUNDARY-START(98211)
        $asm.$cls(`$pGPn._LCCCCPC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295065507)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::System.Boolean*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295065507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "IsFixed", $.$box(__arg1, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq2, "ChildContent", __arg2);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295065507)
            
            static $h = 98211;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295065507),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 262145
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 98211,
      "h": 4295065507,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295065507)
  ],
  "h": 98211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Church.Client.Pages.CommunityChurchPortalApp.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}CommunityChurchPortalApp${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(98211)
        
        

        //--TRIMMABLE-BOUNDARY-START(425891)
        $asm.$cls(`$pGPn.LCCCC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180295075)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pGPn.LCCCCP.CommunityChurchPortalApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pGPn.LCCCCP.CommunityChurchPortalApp().$ctor$3();
                    }, $yYBOIf ??= {"r":2752627,"n":"","d":425891,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pGPn.LCCCCP.CommunityChurchUserApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pGPn.LCCCCP.CommunityChurchUserApp().$ctor$3();
                    }, $BrBVsb ??= {"r":2752627,"n":"","d":425891,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pGPn.LCCCCP.HomePage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pGPn.LCCCCP.HomePage().$ctor$3();
                    }, $ESIuTc ??= {"r":2752627,"n":"","d":425891,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pGPn.LCCCCS$1.ChurchDashboard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pGPn.LCCCCS$1.ChurchDashboard().$ctor$3();
                    }, $hyneld ??= {"r":2752627,"n":"","d":425891,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$pGPn.LCCCCS$1.Synopsis.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$pGPn.LCCCCS$1.Synopsis().$ctor$3();
                    }, $uUcOAd ??= {"r":2752627,"n":"","d":425891,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180295075)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295393187)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295393187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295393187)
            
            //--TRIMMABLE-BOUNDARY-START(4295393187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295393187)
            
            static $h = 425891;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180295075),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885327779,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 425891,
      "h": 17180295075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180295075)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295393187),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 425891,
      "h": 4295393187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295393187)
  ],
  "h": 425891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(425891)
        
        

        //--TRIMMABLE-BOUNDARY-START(819107)
        $asm.$cls(`$pGPn.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590753699)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590753699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pGPn.LCCCCS.CommunityChurchService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchService, x);
                }, $LtZENh ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures).$h,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pGPn.LCCCCS.CommunityChurchPortalApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchPortalApplication, x);
                }, $NVDioc ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchPortalApplication, x);
                }, $yPgVfa ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pGPn.LCCCCS.CommunityChurchUserApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchUserApplication, x);
                }, $SlPFeb ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchUserApplication, x);
                }, $Ciwztc ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$LCOv.LCFCPM.IAccountMembershipIntegrationBase, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCSM.ICommunityMembershipProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, x);
                }, $kXBWKa ??= {"r":16815552,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, x);
                }, $bdgnkl ??= {"r":765342,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCSM.ICommunityMembershipProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, x);
                }, $lREzbg ??= {"r":29267392,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$LCOv.LCFCPM.IAccountMembershipIntegrationBase))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, x);
                }, $cwFyeb ??= {"r":6089140,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler, x);
                }, $VrAxdh ??= {"r":$.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":819107,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$pGPn.LCCCCS.CommunityChurchTabeProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590753699)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$pGPn.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295786403)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295786403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295786403)
            
            //--TRIMMABLE-BOUNDARY-START(4295786403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295786403)
            
            static $h = 819107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590753699),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 819107,
      "h": 8590753699,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590753699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295786403),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 819107,
      "h": 4295786403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295786403)
  ],
  "h": 819107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(819107)
        
        

        //--TRIMMABLE-BOUNDARY-START(1081251)
        $asm.$cls(`$pGPn.LCCCCS.CommunityChurchTabeProvider`, ($self) => class CommunityChurchTabeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245721507)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(47245721507)
            
            //--TRIMMABLE-BOUNDARY-START(8591015843)
            /*IDataCacheStorageService*/ cache = null;
            //--TRIMMABLE-BOUNDARY-END(8591015843)
            
            //--TRIMMABLE-BOUNDARY-START(51540688803)
            /*CommunityChurchService*/ service = null;
            //--TRIMMABLE-BOUNDARY-END(51540688803)
            
            //--TRIMMABLE-BOUNDARY-START(4296048547)
            $ctor$1(/*IServerRemoteService*/ server, /*IDataCacheStorageService*/ cache, /*CommunityChurchService*/ service)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296048547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                    this.cache = cache;
                    this.service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296048547)
            
            //--TRIMMABLE-BOUNDARY-START(12885983139)
            /*bool */ FilterProperties(/*IPropertyDescriptor*/ property, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885983139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12885983139)
            
            //--TRIMMABLE-BOUNDARY-START(38655786915)
            /*ValueTask<IObservableDataDescriptor<T>?> *//*async*/  ReadSingleAssociation(T, /*PostBaseModel*/ to, /*IObservableDataDescriptor<T>*/ target)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$(T)), $.$fPer.LCFCD$1.IObservableDataDescriptor$$(T), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655786915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let v = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.TryReadSingle(T, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$6(to.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1213860839096383n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (v !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$fPer.LCFCD$1.LiteralValueDataDescriptor$$(T)()
                            const $t2 = $.$fPer.LCFCD$1.LiteralValueDataDescriptor$$(T);
                            const $i2 = new $t2();
                            $i2.$ctor$7(v, target.LCFCD$1$IObservableDataDescriptor$ValueType, target.LCFCD$1$IObservableDataDescriptor$$$Property, target.LCFCD$1$IObservableDataDescriptor$Name, true);
                            $i2.Parent = target.LCFCD$1$IObservableDataDescriptor$Parent;
                            return $i2;
                        })());
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, target);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655786915)
            
            //--TRIMMABLE-BOUNDARY-START(17180950435)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ defaultValue)
            {
                /*var*/ let gType;
                /*var*/ let postType;
                /*var*/ let eType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180950435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let dlf;
                if ($.$is(defaultValue, $.$hDPm.LCFCCD$1.DataListFeatures, { set $v($v){ dlf = $v; } }))
                {
                    dlf |= 65536n | 131072n;
                    return $.$cast($.$box(dlf, $.$hDPm.LCFCCD$1.DataListFeatures), T);
                }
                /*T?*/ let __ca1__;
                /*System.Type[]*/ let __ca2__;
                /*System.Type*/ let __ca3__;
                let post;
                if ((target?.LCFCD$IValueProvider$Value ?? null) === null && $.$is((target?.LCFCD$1$IObservableDataDescriptor$Parent?.LCFCD$IValueProvider$Value ?? null), $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ post = $v; } }) && (((__ca1__ = defaultValue) !== null ? $.$fPer.LCFCT.TypesExtensions.ImplementsOpenGeneric($.$$.S.Object.GetType.call(__ca1__), $.$$.STT.ValueTask$$().$type, $.$ref(() => gType, ($v) => gType = $v, $.$$.SCG.List$$($.$typeArray($.$$.S.Type))), null) : false)) && (((__ca2__ = gType.get_Item(0)) !== null ? ((__ca3__ = $.$$.System.Array.$ReadT1.call(__ca2__, 0)) !== null ? $.$fPer.LCFCT.TypesExtensions.ImplementsOpenGeneric(__ca3__, $.$fPer.LCFCD$1.IObservableDataDescriptor$$().$type, $.$ref(() => postType, ($v) => postType = $v, $.$$.SCG.List$$($.$typeArray($.$$.S.Type))), null) : false) : false)) && (postType !== null && $.$LCOv.LCFCPM$1.PostBaseModel.$type.IsAssignableFrom($.$$.System.Array.$ReadT1.call(postType.get_Item(0), 0))))
                {
                    return this.ReadSingleAssociation(T, post, target);
                }
                /*System.Type?*/ let __ca4__;
                let post2;
                let filter;
                if ($.$is((target?.LCFCD$1$IObservableDataDescriptor$Parent?.LCFCD$IValueProvider$Value ?? null), $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ post2 = $v; } }) && (((__ca4__ = target.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType) !== null ? $.$fPer.LCFCT.TypesExtensions.IsEnumerable(__ca4__, $.$ref(() => eType, ($v) => eType = $v, $.$$.S.Type), null) : false)) && (eType !== null && $.$LCOv.LCFCPM$1.PostBaseModel.$type.IsAssignableFrom(eType)) && $.$is(defaultValue, $.$fPer.LCFCD.DataFilter, { set $v($v){ filter = $v; } }))
                {
                    filter = new $.$fPer.LCFCD.DataFilter().$ctor$6(post2.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1196268653051967n | 4194304n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).OverrideWith(filter);
                    return $.$cast(filter, T);
                }
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(17180950435)
            
            //--TRIMMABLE-BOUNDARY-START(21475917731)
            /*RenderFragment? */ GetUIRenderFragment(T, /*IObservableDataDescriptor?*/ target, /*T*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475917731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475917731)
            
            //--TRIMMABLE-BOUNDARY-START(25770885027)
            /*ValueTask */ PostItemSave(/*DataTableItemSavedContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770885027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let _created;
                let _item;
                if ($.$is(context.SavedItem, $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ _created = $v; } }) && $.$is(context.EdittedItem, $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ _item = $v; } }))
                {
                    _created.Properties ??= _item.Properties;
                    _created.Associations ??= _item.Associations;
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(25770885027)
            
            //--TRIMMABLE-BOUNDARY-START(30065852323)
            /*ValueTask<T?> *//*async*/  PrepareItemFor(T, /*T?*/ item, /*SchemaContext*/ schema)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065852323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let ided;
                    if ((schema.Type === 1/*SchemaType.Form*/ || schema.Type === 4096/*SchemaType.Details*/) && $.$is(item, $.$fPer.LCFCD.IIded, { set $v($v){ ided = $v; } }) && ided.LCFCD$IIded$Identifier.HasValue)
                    {
                        let $t6, $r6;
                        /*var*/ let val = ($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle(T, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$6(ided.LCFCD$IIded$Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1213860839096383n | 4194304n | 16777216n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        if (val !== null)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, val);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, item);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065852323)
            
            //--TRIMMABLE-BOUNDARY-START(34360819619)
            /*ValueTask */ PrepareNewItem(/*DataTableNewItemContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360819619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ppost;
                if ($.$is(context.Item$1, $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ ppost = $v; } }))
                {
                    ppost.ParentId = this.service.ServiceAccount.Identifier;
                }
                let post;
                if ($.$is((context.Table?.LCFCD$1$IObservableDataDescriptor$Parent?.LCFCD$IValueProvider$Value ?? null), $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ post = $v; } }))
                {
                    let pvalue;
                    if ($.$is(context.Item$1, $.$LCOv.LCFCPM$1.PostBaseModel, { set $v($v){ pvalue = $v; } }))
                    {
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.PostAssociationModel>?*/ let __ca5__;
                        pvalue.Associations = ((__ca5__ = pvalue.Associations) !== null ? ($.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostAssociationModel, __ca5__, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAssociationModel), [(() =>
                        {
                            //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                            const $t7 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                            const $i7 = new $t7();
                            $i7.$ctor$1();
                            $i7.Associated = post;
                            return $i7;
                        })()], null, null)) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAssociationModel), [(() =>
                        {
                            //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                            const $t8 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                            const $i8 = new $t8();
                            $i8.$ctor$1();
                            $i8.Associated = post;
                            return $i8;
                        })()], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostAssociationModel), [(() =>
                        {
                            //new $.$LCOv.LCFCPM$1.PostAssociationModel()
                            const $t9 = $.$LCOv.LCFCPM$1.PostAssociationModel;
                            const $i9 = new $t9();
                            $i9.$ctor$1();
                            $i9.Associated = post;
                            return $i9;
                        })()], null, null));
                    }
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(34360819619)
            
            //--TRIMMABLE-BOUNDARY-START(42950754211)
            /*Task<T?> *//*async*/  ResolveCSVProperty(T, /*IPropertyDescriptor*/ property, /*string?*/ cellData)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950754211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$LCOv.LCFCPM$1.PostBaseModel.$type.IsAssignableFrom(property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType) && !$.$$.S.String.IsNullOrEmpty(cellData))
                    {
                        let $t10, $r10;
                        /*var*/ let vals = (($t10 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                        {
                            //new $.$LCOv.LCFCPM$1.PostSearchModel()
                            const $t11 = $.$LCOv.LCFCPM$1.PostSearchModel;
                            const $i11 = new $t11();
                            $i11.$ctor$1();
                            $i11.Key = $.$$.S.String.Trim.call(cellData);
                            $i11.KeyFilter = 65536/*PostPropertyQueryFilterType.PropertyValueMatch*/;
                            return $i11;
                        })(), 0), (() =>
                        {
                            //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                            const $t12 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                            const $i12 = new $t12();
                            $i12.$ctor$1();
                            $i12.DataCache = this.cache;
                            return $i12;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)))).AsEnumerable();
                        /*System.Collections.Generic.IEnumerable<T>?*/ let __ca6__;
                        if ((__ca6__ = vals) !== null ? $.$sl.SL.Enumerable.Any$1(T, __ca6__) : false)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.First$1(T, vals));
                        }
                    }
                    else if (property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType === $.$Iaui.LCFCM.ResourceModel.$type && !$.$$.S.String.IsNullOrEmpty(cellData))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast($.$cast($.$Iaui.LCFCM.ResourceModel.Parse(cellData), $.$$.S.Object), T));
                    }
                    else if (property.LCFCD$1$IPropertyDescriptor$ValueType.LCFCD$1$ITypeDescriptor$SystemType === $.$fPer.LCFCD.Gender.$type && !$.$$.S.String.IsNullOrEmpty(cellData))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast($.$box(($.$$.S.String.get_Chars.call(cellData, 0) === /*f*/ 102 || $.$$.S.String.get_Chars.call(cellData, 0) === /*F*/ 70 ? 2/*Gender.Female*/ : $.$$.S.String.get_Chars.call(cellData, 0) === /*m*/ 109 || $.$$.S.String.get_Chars.call(cellData, 0) === /*M*/ 77 ? 1/*Gender.Male*/ : 0/*Gender.None*/), $.$fPer.LCFCD.Gender), T));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950754211)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(4312028842)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListCSVProvider.ResolveCSVProperty<T>(LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor, string?)
            LCFCCD$1$IDataListCSVProvider$ResolveCSVProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312028842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ResolveCSVProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312028842)
            
            static $h = 1081251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885983139),
    {
      "r": 262145,
      "p": [
        {
          "n": "property",
          "p": 40733014
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "FilterProperties",
      "d": 1081251,
      "h": 12885983139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885983139),
//--TRIMMABLE-BOUNDARY-START(38655786915),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$(T)).$h,
      "p": [
        {
          "n": "to",
          "p": 16771508
        },
        {
          "n": "target",
          "p": (T) => $.$fPer.LCFCD$1.IObservableDataDescriptor$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadSingleAssociation",
      "d": 1081251,
      "h": 38655786915,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(38655786915),
//--TRIMMABLE-BOUNDARY-START(17180950435),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "defaultValue",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 1081251,
      "h": 17180950435,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17180950435),
//--TRIMMABLE-BOUNDARY-START(21475917731),
    {
      "r": 6881395,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "context",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetUIRenderFragment",
      "d": 1081251,
      "h": 21475917731,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21475917731),
//--TRIMMABLE-BOUNDARY-START(25770885027),
    {
      "r": 181338113,
      "p": [
        {
          "n": "context",
          "p": 12670634
        }
      ],
      "n": "PostItemSave",
      "d": 1081251,
      "h": 25770885027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770885027),
//--TRIMMABLE-BOUNDARY-START(30065852323),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "item",
          "p": (T) => T.$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "g": [
        "T"
      ],
      "n": "PrepareItemFor",
      "d": 1081251,
      "h": 30065852323,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(30065852323),
//--TRIMMABLE-BOUNDARY-START(34360819619),
    {
      "r": 181338113,
      "p": [
        {
          "n": "context",
          "p": 12736170
        }
      ],
      "n": "PrepareNewItem",
      "d": 1081251,
      "h": 34360819619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360819619),
//--TRIMMABLE-BOUNDARY-START(42950754211),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "property",
          "p": 40733014
        },
        {
          "n": "cellData",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "ResolveCSVProperty",
      "d": 1081251,
      "h": 42950754211,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(42950754211)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245721507),
    {
      "t": 1309651,
      "n": "server",
      "d": 1081251,
      "h": 47245721507,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245721507),
//--TRIMMABLE-BOUNDARY-START(8591015843),
    {
      "t": 63867222,
      "n": "cache",
      "d": 1081251,
      "h": 8591015843,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591015843),
//--TRIMMABLE-BOUNDARY-START(51540688803),
    {
      "t": 1015715,
      "n": "service",
      "d": 1081251,
      "h": 51540688803,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540688803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296048547),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "cache",
          "p": 63867222
        },
        {
          "n": "service",
          "p": 1015715
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1081251,
      "h": 4296048547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296048547)
  ],
  "h": 1081251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$hDPm.LCFCCD.IDashboardTableCSVProvider, $.$hDPm.LCFCCD$1.IDataListCSVProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityChurchTabeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityChurchTabeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1081251)
        
        

        //--TRIMMABLE-BOUNDARY-START(1605539)
        $asm.$cls(`$pGPn.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296572835)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296572835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296572835)
            
            //--TRIMMABLE-BOUNDARY-START(4296572835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296572835)
            
            static $h = 1605539;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296572835),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1605539,
      "h": 4296572835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296572835)
  ],
  "h": 1605539,
  "a": [
    {
      "t": 1540003,
      "c": 4296507299
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1605539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1540003)
        $asm.$cls(`$pGPn.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296507299)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296507299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296507299)
            
            //--TRIMMABLE-BOUNDARY-START(4296507299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296507299)
            
            static $h = 1540003;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296507299),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1540003,
      "h": 4296507299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296507299)
  ],
  "h": 1540003
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1540003)
        
        

        //--TRIMMABLE-BOUNDARY-START(294819)
        $asm.$cls(`$pGPn.LCCCC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590229411)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590229411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590229411)
            
            //--TRIMMABLE-BOUNDARY-START(4295262115)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295262115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295262115)
            
            //--TRIMMABLE-BOUNDARY-START(4295262115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295262115)
            
            static $h = 294819;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590229411),
    {
      "r": 65537,
      "n": "Execute",
      "d": 294819,
      "h": 8590229411,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590229411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295262115),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 294819,
      "h": 4295262115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295262115)
  ],
  "h": 294819
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(294819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1474467)
        $asm.$cls(`$pGPn.LCCCCS$1.Views`, ($self) => class Views extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8591409059)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591409059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8591409059)
            
            //--TRIMMABLE-BOUNDARY-START(12886376355)
            static /*RenderFragment */ DashboardCard(/*string*/ title, /*string*/ icon, /*Theme*/ theme, /*object*/ value, /*string?*/ link)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886376355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFCCT$2.Tag.DynamicElement(link === null ? "div" : "a", $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddClass($.$hDPm.LCFCC$1.ComponentAttributeBuilder.Empty(), "bg-card corner shadow pd flex").AddProperty($.$fPer.LCFC.Stringy.op_Implicit$3("href"), link)), new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(0, "\r\n        ");
                    __builder2.OpenElement(1, "i");
                    __builder2.AddAttribute$5(2, "class", $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN((theme.ToString$1("bg-", null))) + " ") + $.$strNN((icon))) + " fsz-50") + " flex") + " mgc-a");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(3, "\r\n        ");
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "mgy-a mgl");
                    __builder2.OpenElement(6, "h3");
                    __builder2.AddAttribute$5(7, "class", "mg-0");
                    __builder2.AddContent$4(8, title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(9, "\r\n            ");
                    __builder2.OpenElement(10, "h2");
                    __builder2.AddAttribute$5(11, "class", "mg-0");
                    __builder2.AddContent$3(12, value);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(13, "\r\n    ");
                }, $SiRZgg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1474467,"h":0,"f":17825794}), null);
            }
            //--TRIMMABLE-BOUNDARY-END(12886376355)
            
            //--TRIMMABLE-BOUNDARY-START(17181343651)
            static /*RenderFragment */ DashboardProgressCard(/*string*/ title, /*string*/ icon, /*Theme*/ theme, /*double*/ progress, /*double*/ total)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181343651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let p = total === 0 ? progress : progress * 100 / total;
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder2) =>
                {
                    __builder2.OpenElement(14, "div");
                    __builder2.AddAttribute$5(15, "class", "bg-card pd");
                    __builder2.OpenElement(16, "div");
                    __builder2.AddAttribute$5(17, "class", "flex");
                    __builder2.OpenElement(18, "i");
                    __builder2.AddAttribute$5(19, "class", $.$strNN((icon)) + " mgr-2");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(20, "\r\n            ");
                    __builder2.OpenElement(21, "span");
                    __builder2.AddAttribute$5(22, "class", "fill");
                    __builder2.AddContent$4(23, title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(24, "\r\n            ");
                    __builder2.OpenElement(25, "span");
                    __builder2.AddContent$4(26, $.$$.S.Double.ToString$3.call(progress, "0.##"));
                    __builder2.AddContent$4(27, "/");
                    __builder2.AddContent$4(28, $.$$.S.Double.ToString$3.call(total, "0.##"));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(29, "\r\n        ");
                    __builder2.OpenElement(30, "div");
                    __builder2.AddAttribute$5(31, "class", "bg-gray hx-005 mgt");
                    __builder2.OpenElement(32, "div");
                    __builder2.AddAttribute$5(33, "class", $.$strNN("hf" + " ") + $.$strNN((theme.ToString$1("bg-", null))));
                    __builder2.AddAttribute$5(34, "style", $.$strNN("width:" + ($.$box(p, $.$$.S.Double))) + "%");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(35, "\r\n");
                }, $XlZEQa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1474467,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(17181343651)
            
            //--TRIMMABLE-BOUNDARY-START(4296441763)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296441763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296441763)
            
            //--TRIMMABLE-BOUNDARY-START(4296441763)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296441763)
            
            static $h = 1474467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591409059),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1474467,
      "h": 8591409059,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591409059),
//--TRIMMABLE-BOUNDARY-START(12886376355),
    {
      "r": 6881395,
      "p": [
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "icon",
          "p": 1310721
        },
        {
          "n": "theme",
          "p": 65309014
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "link",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "DashboardCard",
      "d": 1474467,
      "h": 12886376355,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886376355),
//--TRIMMABLE-BOUNDARY-START(17181343651),
    {
      "r": 6881395,
      "p": [
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "icon",
          "p": 1310721
        },
        {
          "n": "theme",
          "p": 65309014
        },
        {
          "n": "progress",
          "p": 1179649
        },
        {
          "n": "total",
          "p": 1179649
        }
      ],
      "n": "DashboardProgressCard",
      "d": 1474467,
      "h": 17181343651,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181343651)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296441763),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1474467,
      "h": 4296441763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296441763)
  ],
  "h": 1474467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Shared.Views`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Shared${separator}Views`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1474467)
        
        

        //--TRIMMABLE-BOUNDARY-START(753571)
        $asm.$cls(`$pGPn.LCCCCP.LibraryPage`, ($self) => class LibraryPage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590688163)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590688163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "Library");
                __builder.AddAttribute$3(2, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ __) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenElement(3, "div");
                        __builder2.AddAttribute$5(4, "class", "flex flex-spacebetween-x pd-5");
                        __builder2.OpenElement(5, "div");
                        __builder2.AddAttribute$5(6, "class", "text-center");
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 7);
                        __builder2.AddComponentParameter(8, "Class", "d-block button lt primary lt wx-05 hx-05 mdi mdi-harddisk round fsz-35 pd-1 mg-a");
                        __builder2.AddComponentParameter(9, "href", "UserLocal");
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(10, "\r\n                ");
                        __builder2.AddMarkupContent(11, "<h3 class=\"mgb-0 mgt-1\">Local</h3>");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(12, "\r\n\r\n            ");
                        __builder2.OpenElement(13, "div");
                        __builder2.AddAttribute$5(14, "class", "text-center");
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 15);
                        __builder2.AddComponentParameter(16, "Class", "d-block button lt primary lt wx-05 hx-05 mdi mdi-account-heart round fsz-35 pd-1 mg-a");
                        __builder2.AddComponentParameter(17, "href", "UserFavourites");
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(18, "\r\n                ");
                        __builder2.AddMarkupContent(19, "<h3 class=\"mgb-0 mgt-1\">Favorites</h3>");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(20, "\r\n\r\n            ");
                        __builder2.OpenElement(21, "div");
                        __builder2.AddAttribute$5(22, "class", "text-center");
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 23);
                        __builder2.AddComponentParameter(24, "Class", "d-block button lt primary lt wx-05 hx-05 mdi mdi-playlist-music round fsz-35 pd-1 mg-a");
                        __builder2.AddComponentParameter(25, "href", "UserPlaylists");
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(26, "\r\n                ");
                        __builder2.AddMarkupContent(27, "<h3 class=\"mgb-0 mgt-1\">Playlists</h3>");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(28, "\r\n\r\n            ");
                        __builder2.OpenElement(29, "div");
                        __builder2.AddAttribute$5(30, "class", "text-center");
                        __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 31);
                        __builder2.AddComponentParameter(32, "Class", "d-block button lt primary lt wx-05 hx-05 mdi mdi-calendar round fsz-35 pd-1 mg-a");
                        __builder2.AddComponentParameter(33, "href", "UserCalendar");
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(34, "\r\n                ");
                        __builder2.AddMarkupContent(35, "<h3 class=\"mgb-0 mgt-1\">Calendar</h3>");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(36, "\r\n        ");
                        __builder2.AddMarkupContent(37, "<p class=\"text-center\">This is not yet finished. Please check back</p>");
                    }, $AsDIkl ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":753571,"h":0,"f":17825794});
                }), $EcKska ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":753571,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590688163)
            
            //--TRIMMABLE-BOUNDARY-START(4295720867)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295720867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295720867)
            
            //--TRIMMABLE-BOUNDARY-START(4295720867)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295720867)
            
            static $h = 753571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590688163),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 753571,
      "h": 8590688163,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590688163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295720867),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 753571,
      "h": 4295720867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295720867)
  ],
  "h": 753571
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Pages.LibraryPage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}LibraryPage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(753571)
        
        

        //--TRIMMABLE-BOUNDARY-START(688035)
        $asm.$cls(`$pGPn.LCCCCP.HomePage`, ($self) => class HomePage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475524515)
            /*CommunityGroupApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(21475524515)
            
            //--TRIMMABLE-BOUNDARY-START(81605066659)
            /*CommunityChurchService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(81605066659)
            
            //--TRIMMABLE-BOUNDARY-START(68720164771)
            /*CommunityGroupChurchPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(68720164771)
            
            //--TRIMMABLE-BOUNDARY-START(77310099363)
            /*string */ get OptimizedComponentName()
            {
                return "homepage";
            }
            //--TRIMMABLE-BOUNDARY-END(77310099363)
            
            //--TRIMMABLE-BOUNDARY-START(111669837731)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669837731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111669837731)
            
            //--TRIMMABLE-BOUNDARY-START(73015132067)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015132067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Application = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$PIIp.LCCGCS.CommunityGroupApplication, serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(73015132067)
            
            //--TRIMMABLE-BOUNDARY-START(25770491811)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770491811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 0);
                __builder.AddComponentParameter(1, "Name", "");
                __builder.AddComponentParameter(2, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, -2147483648/*int.MinValue*/), $.$$.S.Int32));
                __builder.AddComponentParameter(3, "PageAccess", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageAccessibility, 2/*ApplicationPageAccessibility.Sidebar*/ | (((this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box?.IsMobile ?? null) ?? false) ? 4/*ApplicationPageAccessibility.Tab*/ : 0/*ApplicationPageAccessibility.None*/)), $.$lJUR.LCFCS.ApplicationPageAccessibility));
                __builder.AddComponentParameter(4, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8707/*ApplicationPageFeatures.Default*/ | 16/*ApplicationPageFeatures.TopToolBarOverlay*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                __builder.AddComponentParameter(5, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                __builder.AddComponentParameter(6, "RemoveApplicationFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 128/*ApplicationFeatures.ToolBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                __builder.AddComponentParameter(7, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)))().$ctor(this, ( (/**/ e) =>
                {
                    return $.$ahDc.LCCCSL.CommunityLayoutExtension.SetLayoutHeader($.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCS$IApplicationPageContext$Page.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~(12/*CommunityLayoutFeatures.PadX*/ | 1/*CommunityLayoutFeatures.PadT*/), null, null, true), this.GetBanner());
                }), $kdvdqd ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object).$h}],"n":"","d":688035,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$4(9, this.Group.Title);
                    }, $XVUTHg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":688035,"h":0,"f":17825794});
                }), $FiVzbc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":688035,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddContent$1(11, $.$ahDc.LCCCS$1.CommunityUtility.AppMenuIcon($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object), this, $.$clone(context), this.Application, $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-church"), false));
                    }, $qgKVod ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":688035,"h":0,"f":17825794});
                }), $fWQRGc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":688035,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ToolBarControls", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let ownsAccount = this.Service.CommunityService.IsOwnedByCurrentUser(this.Group);
                        if (ownsAccount)
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCM$4.MenuItem, 13);
                            __builder2.AddComponentParameter(14, "PageLink", "Settings");
                            __builder2.AddComponentParameter(15, "link-class", "mdi mdi-cog");
                            __builder2.CloseComponent();
                        }
                    }, $ChXhad ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":688035,"h":0,"f":17825794});
                }), $YSXLWe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":688035,"h":0,"f":17825794}));
                __builder.AddAttribute$3(16, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*__*/ __) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                    }, $Nquxcb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":688035,"h":0,"f":17825794});
                }), $ztDeQc ??= {"r":6881395,"p":[{"n":"__","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":688035,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(17, "\r\n\r\n}");
            }
            //--TRIMMABLE-BOUNDARY-END(25770491811)
            
            //--TRIMMABLE-BOUNDARY-START(64425197475)
            /*RenderFragment */ GetBanner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425197475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    $.$pGPn._LCCCCPH.TypeInference.CreateCommunityAccountBanner_0($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, __builder2, 18, 19, this.Group);
                }, $aJAHGg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":688035,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(64425197475)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180557219)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180557219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180557219)
            
            //--TRIMMABLE-BOUNDARY-START(17180557219)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180557219)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475524515)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(21475524515)
                
                //--TRIMMABLE-BOUNDARY-START(81605066659)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(81605066659)
                
            }
            static $h = 688035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475524515),
    {
      "p": 503198,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360426403,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195001251,
        "f": 83886081
      },
      "n": "Application",
      "d": 688035,
      "h": 21475524515,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475524515),
//--TRIMMABLE-BOUNDARY-START(81605066659),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130230179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374870435,
        "f": 83886081
      },
      "n": "Service",
      "d": 688035,
      "h": 81605066659,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605066659),
//--TRIMMABLE-BOUNDARY-START(68720164771),
    {
      "p": 2371927,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950360995,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784935843,
        "f": 83886081
      },
      "n": "Group",
      "d": 688035,
      "h": 68720164771,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720164771),
//--TRIMMABLE-BOUNDARY-START(77310099363),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540295587,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 688035,
      "h": 77310099363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310099363)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669837731),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 688035,
      "h": 111669837731,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669837731),
//--TRIMMABLE-BOUNDARY-START(73015132067),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 688035,
      "h": 73015132067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015132067),
//--TRIMMABLE-BOUNDARY-START(25770491811),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 688035,
      "h": 25770491811,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770491811),
//--TRIMMABLE-BOUNDARY-START(64425197475),
    {
      "r": 6881395,
      "n": "GetBanner",
      "d": 688035,
      "h": 64425197475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425197475)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180557219),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 688035,
      "h": 17180557219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180557219)
  ],
  "h": 688035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Pages.HomePage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}HomePage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(688035)
        
        

        //--TRIMMABLE-BOUNDARY-START(556963)
        $asm.$cls(`$pGPn.LCCCCP.CommunityChurchPortalApp`, ($self) => class CommunityChurchPortalApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(163209314211)
            /*string */ get OptimizedComponentName()
            {
                return "communitychurchportalapp";
            }
            //--TRIMMABLE-BOUNDARY-END(163209314211)
            
            //--TRIMMABLE-BOUNDARY-START(253403627427)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403627427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                    case "PageRoute":
                    this.PageRoute = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(253403627427)
            
            //--TRIMMABLE-BOUNDARY-START(146029445027)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029445027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ChurchService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchService, serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.MessagePipe = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$UrvY.LCFCM.IMessagePipeFactory, serviceProvider);
                this.TableProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchTabeProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(146029445027)
            
            //--TRIMMABLE-BOUNDARY-START(47245197219)
            /*string?*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(47245197219)
            
            //--TRIMMABLE-BOUNDARY-START(167504281507)
            /*string?*/ PageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(167504281507)
            
            //--TRIMMABLE-BOUNDARY-START(60130099107)
            /*CommunityChurchService*/ ChurchService = null;
            //--TRIMMABLE-BOUNDARY-END(60130099107)
            
            //--TRIMMABLE-BOUNDARY-START(42950229923)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(42950229923)
            
            //--TRIMMABLE-BOUNDARY-START(154619379619)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(154619379619)
            
            //--TRIMMABLE-BOUNDARY-START(150324412323)
            /*IMessagePipeFactory*/ MessagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(150324412323)
            
            //--TRIMMABLE-BOUNDARY-START(249108660131)
            /*CommunityChurchTabeProvider*/ TableProvider = null;
            //--TRIMMABLE-BOUNDARY-END(249108660131)
            
            //--TRIMMABLE-BOUNDARY-START(171799248803)
            /*IMessagePipe?*/ pipe = null;
            //--TRIMMABLE-BOUNDARY-END(171799248803)
            
            //--TRIMMABLE-BOUNDARY-START(184684150691)
            /*IEnumerable<ISelectOption<IChildrenHierachy>>?*/ sessionTermHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(184684150691)
            
            //--TRIMMABLE-BOUNDARY-START(180389183395)
            /*IChildrenHierachy?*/ selectedHierachy = null;
            //--TRIMMABLE-BOUNDARY-END(180389183395)
            
            //--TRIMMABLE-BOUNDARY-START(38655262627)
            /*int*/ applicationSequenceNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(38655262627)
            
            //--TRIMMABLE-BOUNDARY-START(68720033699)
            /*bool*/ edittingSessionTerm = false;
            //--TRIMMABLE-BOUNDARY-END(68720033699)
            
            //--TRIMMABLE-BOUNDARY-START(51540164515)
            /*void */ BeginEditSessionTerm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540164515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.edittingSessionTerm = true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540164515)
            
            //--TRIMMABLE-BOUNDARY-START(73015000995)
            /*Task *//*async*/  FinishLoadSchool()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015000995);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.UnitOfWork.LCFCI$IClientUnitOfWork$Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        if (this.ChurchService.ServiceAccount !== null)
                        {
                            try
                            {
                                let $t2, $r2;
                                this.pipe = ($t2 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.MessagePipe, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2($.$dspc(this.ChurchService.ServiceAccount.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString)), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                this.pipe.LCFCM$IMessagePipe$Subscribe($.$yCMk.LCCCCM.CommunityChurchCheckInModel, new ($.$$.S.Action$$($.$yCMk.LCCCCM.CommunityChurchCheckInModel))().$ctor(this,  (/**/ checkin) =>
                                {
                                    this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Toast(`${$.$strNN(checkin.Member.Title)} has checked ${$.$strNN((checkin.IsCheckinIn ? "in" : "out"))}`, null);
                                }, $MTgEXc ??= {"r":65537,"p":[{"n":"checkin","p":995671}],"n":"","d":556963,"h":0,"f":17825794}));
                            }
                            catch(e)
                            {
                                $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Client.Blazor\\CommunityChurchPortalApp.razor.cs", "FinishLoadSchool", 86);
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015000995)
            
            //--TRIMMABLE-BOUNDARY-START(158914346915)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914346915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ this.ResolvePath("LivingThing.Core.Community.Church.Client.Blazor.min.css", true, false, false) ], null, null));
                    this.ChurchService.add_OnLoaded(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.FinishLoadSchool));
                    ($t3 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914346915)
            
            //--TRIMMABLE-BOUNDARY-START(64425066403)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425066403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.pipe?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(64425066403)
            
            //--TRIMMABLE-BOUNDARY-START(176094216099)
            /*Task *//*async*/  SaveSettings(/*CommunityGroupChurchPostSettings*/ settings)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094216099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.UpdateSettings($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, this.ChurchService.Server, this.ChurchService.ServiceAccount.Identifier, settings), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094216099)
            
            //--TRIMMABLE-BOUNDARY-START(55835131811)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835131811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSS.CommunityAppServiceGuard$$$$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, $.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures), 0);
                __builder.AddComponentParameter(1, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSS.CommunityAppServiceGuardFeatures, 4/*CommunityAppServiceGuardFeatures.Default*/ | 1/*CommunityAppServiceGuardFeatures.UseHandleInPath*/ | 2/*CommunityAppServiceGuardFeatures.SelectServiceBeforeLogin*/), $.$ahDc.LCCCSS.CommunityAppServiceGuardFeatures));
                __builder.AddComponentParameter(2, "Service", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityServiceAccountViewModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), this.ChurchService));
                __builder.AddComponentParameter(3, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.BasePath));
                __builder.AddComponentParameter(4, "PageRoute", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.PageRoute));
                __builder.AddAttribute$3(5, "NotAuthorizedView", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAuthentication, 6);
                    /*string?*/ let __ca1__;
                    __builder2.AddComponentParameter(7, "AllowDemoLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((__ca1__ = this.ChurchService.ServiceHandle) !== null ? $.$$.S.String.Equals$2.call(__ca1__, "DemoChurch", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(8, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.ChurchService));
                    __builder2.AddComponentParameter(9, "Title", "ZOEY Church");
                    __builder2.AddComponentParameter(10, "BannerImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/banner.jpg", true, true, false)));
                    __builder2.CloseComponent();
                }), $hyDpZc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                __builder.AddAttribute$3(11, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$ahDc.LCCCSS.CommunityAppServiceGuardContext)))().$ctor(this, ( (/**/ guard) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        $.$pGPn._LCCCCPC.TypeInference.CreateCascadingValue_0($.$pGPn.LCCCCS.CommunityChurchService, __builder2, 12, 13, this.ChurchService, 14, true, 15, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$lJUR.LCFCS.Application, 16);
                            __builder3.AddComponentParameter(17, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.ChurchService));
                            __builder3.AddComponentParameter(18, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), new $.$fPer.LCFCR$3.RoutePath().$ctor$3($.$fPer.LCFC.Stringy.op_Implicit$3(guard.Data.AppBasePath))));
                            __builder3.AddComponentParameter(19, "ToolBarBackgroundTheme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Card));
                            __builder3.AddComponentParameter(20, "SideBarBackgroundTheme", "Theme.Card");
                            __builder3.AddComponentParameter(21, "MultiViewFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$6.MultiViewFeatures, (68/*MultiViewFeatures.Default*/ | 2/*MultiViewFeatures.Transition*/) & ~4/*MultiViewFeatures.ShowFirstViewOnBoot*/), $.$hDPm.LCFCCM$6.MultiViewFeatures));
                            __builder3.AddAttribute$3(22, "LeftSideBarPrologue", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$4.MenuFeatures))().$ctor(this, ( (/*menuFeatures*/ menuFeatures) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCS$1.CommunitySideBarPrologue, 23);
                                    __builder4.AddComponentParameter(24, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.AccountBaseModel, this.ChurchService.ServiceAccount));
                                    __builder4.AddComponentParameter(25, "MenuFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$4.MenuFeatures, menuFeatures), $.$hDPm.LCFCCM$4.MenuFeatures));
                                    __builder4.CloseComponent();
                                }, $GnTMgj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                            }), $aJsySc ??= {"r":6881395,"p":[{"n":"menuFeatures","p":36394666}],"n":"","d":556963,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(26, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.AddMarkupContent(27, "<i class=\"mdi mdi-Church\"></i>");
                                }, $gYiMic ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                            }), $Ynhspl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(28, "ToolBars", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    if (this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$Runtime.Type === 2/*RuntimeType.MobileApp*/)
                                    {
                                        __builder4.OpenElement(29, "a");
                                        __builder4.AddAttribute$5(30, "class", "menuitem mgy-a mdi mdi-desktop");
                                        __builder4.AddAttribute$5(31, "href", "https://zoey.africa/ChurchPortals/" + $.$strNN((this.ChurchService.ServiceAccount.Handle)));
                                        __builder4.CloseElement();
                                    }
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAccountsToolBar, 32);
                                    __builder4.AddComponentParameter(33, "Size", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 30), $.$$.S.Int32));
                                    __builder4.CloseComponent();
                                }, $HVmNpg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                            }), $qIvlGb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(34, "NotAuthorizedView", new ($.$mac.MAC.RenderFragment$$($.$lJUR.LCFCS.IApplicationPageComponent))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAuthentication, 35);
                                    /*string?*/ let __ca2__;
                                    __builder4.AddComponentParameter(36, "AllowDemoLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((__ca2__ = this.ChurchService.ServiceHandle) !== null ? $.$$.S.String.Equals$2.call(__ca2__, "DemoChurch", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)), $.$$.S.Boolean));
                                    __builder4.AddComponentParameter(37, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.ChurchService));
                                    __builder4.AddComponentParameter(38, "Title", "ZOEY Church");
                                    __builder4.AddComponentParameter(39, "BannerImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/banner-4.jpg", true, true, false)));
                                    __builder4.CloseComponent();
                                }, $PpzeSf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                            }), $cIIsAb ??= {"r":6881395,"p":[{"n":"context","p":4599881}],"n":"","d":556963,"h":0,"f":17825794}));
                            __builder3.AddAttribute$3(40, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 41);
                                __builder4.AddComponentParameter(42, "Name", "FrontDesk");
                                __builder4.AddComponentParameter(43, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`${$.$strNN("**"/*RoutePath.ZeroOrMorePathSegment*/)}`)));
                                __builder4.AddComponentParameter(44, "Class", "pd");
                                __builder4.AddAttribute$3(45, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(46, "i");
                                        __builder5.AddAttribute$5(47, "class", "mdi mdi-monitor-dashboard"/*MaterialDesignIconNames.MonitorDashboard*/);
                                        __builder5.CloseElement();
                                    }, $QdTuLf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $MAiawb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(48, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddContent$4(49, "Front Desk");
                                    }, $vorDzk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $JJORuk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(50, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenComponent$1($.$pGPn.LCCCCS$1.ChurchDashboard, 51);
                                        __builder5.AddComponentParameter(52, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, guard.Data.AppBasePath));
                                        __builder5.CloseComponent();
                                    }, $eTvKBc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $jLszsj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(53, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 54);
                                    __builder5.AddComponentParameter(55, "Name", "StudentAttendanceReport");
                                    __builder5.AddComponentParameter(56, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Dashboard/AttendanceReport`)));
                                    __builder5.AddComponentParameter(57, "Class", "pd");
                                    __builder5.AddAttribute$3(58, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(59, "i");
                                            __builder6.AddAttribute$5(60, "class", "mdi mdi-table-clock"/*MaterialDesignIconNames.TableClock*/);
                                            __builder6.CloseElement();
                                        }, $FwAmIj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $KLXEYf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(61, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(62, "Attendance Report");
                                        }, $fdXhde ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $qcdMzk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(63, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$ahDc.LCCCSA$3.AttendanceReport$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), 64);
                                            __builder6.AddComponentParameter(65, "Provider", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSA$3.ICommunityAttendanceProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), this.ChurchService));
                                            __builder6.CloseComponent();
                                        }, $whPEmh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $JRQEEk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $reZPja ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                                __builder4.AddMarkupContent(66, "\r\n                    ");
                                __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 67);
                                __builder4.AddComponentParameter(68, "Name", "Facilities");
                                __builder4.AddComponentParameter(69, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Facilities`)));
                                __builder4.AddComponentParameter(70, "Class", "pd");
                                __builder4.AddAttribute$3(71, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(72, "i");
                                        __builder5.AddAttribute$5(73, "class", "mdi mdi-tools"/*MaterialDesignIconNames.Tools*/);
                                        __builder5.CloseElement();
                                    }, $hsmovg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $oddUxj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(74, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddContent$4(75, "Facilities");
                                    }, $NqUeua ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $yjfvgi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(76, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                    }, $obTyMj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $RHhXTb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(77, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 78);
                                    __builder5.AddComponentParameter(79, "Name", "Branches");
                                    __builder5.AddComponentParameter(80, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Facilities/Branches`)));
                                    __builder5.AddComponentParameter(81, "Class", "pd");
                                    __builder5.AddAttribute$3(82, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(83, "i");
                                            __builder6.AddAttribute$5(84, "class", "mdi mdi-camera"/*MaterialDesignIconNames.Camera*/);
                                            __builder6.CloseElement();
                                        }, $ZgYMMf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $uUhFYe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(85, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(86, "Branches");
                                        }, $iTkBde ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $nibVkh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(87, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$yCMk.LCCCCM.CommunityChurchBranchModel), 88);
                                            __builder6.AddComponentParameter(89, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(90, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                            __builder6.AddComponentParameter(91, "ItemName", "Branch");
                                            __builder6.CloseComponent();
                                        }, $QeJNdh ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $gkLxAh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $mjoJXb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                                __builder4.AddMarkupContent(92, "\r\n                    ");
                                __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 93);
                                __builder4.AddComponentParameter(94, "Name", "HumanResources");
                                __builder4.AddAttribute$3(95, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(96, "i");
                                        __builder5.AddAttribute$5(97, "class", "mdi mdi-human"/*MaterialDesignIconNames.Human*/);
                                        __builder5.CloseElement();
                                    }, $fxHBib ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $WNrShh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(98, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddContent$4(99, "Human Resources");
                                    }, $KhCXck ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $HuRCte ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(100, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 101);
                                    __builder5.AddComponentParameter(102, "Name", "Members");
                                    __builder5.AddComponentParameter(103, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("HumanResources/Members")));
                                    __builder5.AddComponentParameter(104, "Class", "pd");
                                    __builder5.AddAttribute$3(105, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(106, "i");
                                            __builder6.AddAttribute$5(107, "class", "mdi mdi-account"/*MaterialDesignIconNames.Account*/);
                                            __builder6.CloseElement();
                                        }, $KsVUJd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $DPjJAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(108, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(109, "Members");
                                        }, $mAbWAb ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $PBTMwb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(110, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$ahDc.LCCCSM.MembershipMembers$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), 111);
                                            __builder6.AddComponentParameter(112, "Context", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.PostBaseModel, this.ChurchService.ServiceAccount));
                                            __builder6.CloseComponent();
                                        }, $XxYgJi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $AyUTea ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $WKNkFe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                                __builder4.AddMarkupContent(113, "\r\n                    ");
                                __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 114);
                                __builder4.AddComponentParameter(115, "Name", "Finance");
                                __builder4.AddAttribute$3(116, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.OpenElement(117, "i");
                                        __builder5.AddAttribute$5(118, "class", "mdi mdi-cash"/*MaterialDesignIconNames.Cash*/);
                                        __builder5.CloseElement();
                                    }, $aldJKe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $UgHPkg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(119, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                    {
                                        __builder5.AddContent$4(120, "Finance");
                                    }, $ipyptj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                }), $uBABqf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.AddAttribute$3(121, "ChildPages", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 122);
                                    __builder5.AddComponentParameter(123, "Name", "Fees");
                                    __builder5.AddComponentParameter(124, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/Fees")));
                                    __builder5.AddComponentParameter(125, "Class", "pd");
                                    __builder5.AddAttribute$3(126, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(127, "i");
                                            __builder6.AddAttribute$5(128, "class", "mdi mdi-cash-fast"/*MaterialDesignIconNames.CashFast*/);
                                            __builder6.CloseElement();
                                        }, $UBYpDe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $jpfjoc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(129, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(130, "Fees");
                                        }, $SqfSsf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $PHiOzk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(131, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.LevyPostModel), 132);
                                            __builder6.AddComponentParameter(133, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(134, "ItemName", "Fee");
                                            __builder6.CloseComponent();
                                        }, $NCEnpb ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $TIvztk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.AddMarkupContent(135, "\r\n                            ");
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 136);
                                    __builder5.AddComponentParameter(137, "Name", "Invoices");
                                    __builder5.AddComponentParameter(138, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/Invoices")));
                                    __builder5.AddComponentParameter(139, "Class", "pd");
                                    __builder5.AddAttribute$3(140, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(141, "i");
                                            __builder6.AddAttribute$5(142, "class", "mdi mdi-cash-check"/*MaterialDesignIconNames.CashCheck*/);
                                            __builder6.CloseElement();
                                        }, $yuqGlj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $AXIoxf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(143, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(144, "Invoices");
                                        }, $LJYtQa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $zWLrvf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(145, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.InvoicePostModel), 146);
                                            __builder6.AddComponentParameter(147, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(148, "ItemName", "Invoice");
                                            __builder6.CloseComponent();
                                        }, $BdSUoj ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $DbrNvi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.AddMarkupContent(149, "\r\n                            ");
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 150);
                                    __builder5.AddComponentParameter(151, "Name", "Income");
                                    __builder5.AddComponentParameter(152, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/Income")));
                                    __builder5.AddComponentParameter(153, "Class", "pd");
                                    __builder5.AddAttribute$3(154, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(155, "i");
                                            __builder6.AddAttribute$5(156, "class", "mdi mdi-cash-plus"/*MaterialDesignIconNames.CashPlus*/);
                                            __builder6.CloseElement();
                                        }, $rHAOYg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $DAUyCa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(157, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(158, "Income");
                                        }, $dFjQBa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $ZwfgTb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(159, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.IncomePostModel), 160);
                                            __builder6.AddComponentParameter(161, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(162, "ItemName", "Income");
                                            __builder6.CloseComponent();
                                        }, $uhYhWi ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $YckFsb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.AddMarkupContent(163, "\r\n                            ");
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 164);
                                    __builder5.AddComponentParameter(165, "Name", "Expenditure");
                                    __builder5.AddComponentParameter(166, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/Expenditure")));
                                    __builder5.AddComponentParameter(167, "Class", "pd");
                                    __builder5.AddAttribute$3(168, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(169, "i");
                                            __builder6.AddAttribute$5(170, "class", "mdi mdi-cash-minus"/*MaterialDesignIconNames.CashMinus*/);
                                            __builder6.CloseElement();
                                        }, $DhvNDb ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $SWPYMf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(171, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(172, "Expenditure");
                                        }, $DdiONd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $kWITzh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(173, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), 174);
                                            __builder6.AddComponentParameter(175, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(176, "ItemName", "Expenditure");
                                            __builder6.CloseComponent();
                                        }, $CUMJla ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $YzafXc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.AddMarkupContent(177, "\r\n                            ");
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 178);
                                    __builder5.AddComponentParameter(179, "Name", "IncomeClass");
                                    __builder5.AddComponentParameter(180, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/IncomeClass")));
                                    __builder5.AddComponentParameter(181, "Class", "pd");
                                    __builder5.AddAttribute$3(182, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(183, "i");
                                            __builder6.AddAttribute$5(184, "class", "mdi mdi-cash-register"/*MaterialDesignIconNames.CashRegister*/);
                                            __builder6.CloseElement();
                                        }, $iuPQIa ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $GVResh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(185, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(186, "Income Class");
                                        }, $IWDPPe ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $wijXij ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(187, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.IncomeClassPostModel), 188);
                                            __builder6.AddComponentParameter(189, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(190, "ItemName", "Income Class");
                                            __builder6.CloseComponent();
                                        }, $vfTQvd ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $qkVplb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                    __builder5.AddMarkupContent(191, "\r\n                            ");
                                    __builder5.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 192);
                                    __builder5.AddComponentParameter(193, "Name", "ExpenditureClass");
                                    __builder5.AddComponentParameter(194, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Finance/ExpenditureClass")));
                                    __builder5.AddComponentParameter(195, "Class", "pd");
                                    __builder5.AddAttribute$3(196, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenElement(197, "i");
                                            __builder6.AddAttribute$5(198, "class", "mdi mdi-cash-register"/*MaterialDesignIconNames.CashRegister*/);
                                            __builder6.CloseElement();
                                        }, $eeIKvf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $mBmWVe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(199, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.AddContent$4(200, "Expenditure Class");
                                        }, $GoWVSg ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $NzXArb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.AddAttribute$3(201, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                            __builder6.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMF$1.ExpenditureClassPostModel), 202);
                                            __builder6.AddComponentParameter(203, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this.TableProvider));
                                            __builder6.AddComponentParameter(204, "ItemName", "Expenditure Class");
                                            __builder6.CloseComponent();
                                        }, $RGiNli ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                                    }), $sAxuAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }), $PCWxlh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                                __builder4.CloseComponent();
                            }), $YGfbtg ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                            __builder3.SetKey($.$box($.$$.S.HashCode.Combine$6($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$$.S.Int32, this.ChurchService.ServiceAccount, this.applicationSequenceNumber), $.$$.S.Int32));
                            __builder3.CloseComponent();
                        }, $lgfEXf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":556963,"h":0,"f":17825794}));
                    }, $upxHih ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":556963,"h":0,"f":17825794});
                }), $jYAVpi ??= {"r":6881395,"p":[{"n":"guard","p":$.$hDPm.LCFCI.ContainerContext$$($.$ahDc.LCCCSS.CommunityAppServiceGuardContext).$h}],"n":"","d":556963,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(55835131811)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(34360295331)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360295331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360295331)
            
            //--TRIMMABLE-BOUNDARY-START(34360295331)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34360295331)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130099107)
                this.ChurchService = null;
                //--TRIMMABLE-BOUNDARY-END(60130099107)
                
                //--TRIMMABLE-BOUNDARY-START(42950229923)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(42950229923)
                
                //--TRIMMABLE-BOUNDARY-START(154619379619)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(154619379619)
                
                //--TRIMMABLE-BOUNDARY-START(150324412323)
                this.MessagePipe = null;
                //--TRIMMABLE-BOUNDARY-END(150324412323)
                
                //--TRIMMABLE-BOUNDARY-START(249108660131)
                this.TableProvider = null;
                //--TRIMMABLE-BOUNDARY-END(249108660131)
                
            }
            static $h = 556963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209314211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554608547,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 556963,
      "h": 163209314211,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209314211),
//--TRIMMABLE-BOUNDARY-START(47245197219),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194870179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864019875,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 556963,
      "h": 47245197219,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245197219),
//--TRIMMABLE-BOUNDARY-START(167504281507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144543139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223758243,
        "f": 83886081
      },
      "n": "PageRoute",
      "d": 556963,
      "h": 167504281507,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504281507),
//--TRIMMABLE-BOUNDARY-START(60130099107),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784804771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453954467,
        "f": 83886081
      },
      "n": "ChurchService",
      "d": 556963,
      "h": 60130099107,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130099107),
//--TRIMMABLE-BOUNDARY-START(42950229923),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604935587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274085283,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 556963,
      "h": 42950229923,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950229923),
//--TRIMMABLE-BOUNDARY-START(154619379619),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964673955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633823651,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 556963,
      "h": 154619379619,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619379619),
//--TRIMMABLE-BOUNDARY-START(150324412323),
    {
      "p": 407004,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374739363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043889059,
        "f": 83886081
      },
      "n": "MessagePipe",
      "d": 556963,
      "h": 150324412323,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324412323),
//--TRIMMABLE-BOUNDARY-START(249108660131),
    {
      "p": 1081251,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734477731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813692835,
        "f": 83886081
      },
      "n": "TableProvider",
      "d": 556963,
      "h": 249108660131,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249108660131)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(253403627427),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 556963,
      "h": 253403627427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253403627427),
//--TRIMMABLE-BOUNDARY-START(146029445027),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 556963,
      "h": 146029445027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029445027),
//--TRIMMABLE-BOUNDARY-START(51540164515),
    {
      "r": 65537,
      "n": "BeginEditSessionTerm",
      "d": 556963,
      "h": 51540164515,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540164515),
//--TRIMMABLE-BOUNDARY-START(73015000995),
    {
      "r": 178454529,
      "n": "FinishLoadSchool",
      "d": 556963,
      "h": 73015000995,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73015000995),
//--TRIMMABLE-BOUNDARY-START(158914346915),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 556963,
      "h": 158914346915,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(158914346915),
//--TRIMMABLE-BOUNDARY-START(64425066403),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 556963,
      "h": 64425066403,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425066403),
//--TRIMMABLE-BOUNDARY-START(176094216099),
    {
      "r": 178454529,
      "p": [
        {
          "n": "settings",
          "p": 3092823
        }
      ],
      "n": "SaveSettings",
      "d": 556963,
      "h": 176094216099,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(176094216099),
//--TRIMMABLE-BOUNDARY-START(55835131811),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 556963,
      "h": 55835131811,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835131811)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(171799248803),
    {
      "t": 341468,
      "n": "pipe",
      "d": 556963,
      "h": 171799248803,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(171799248803),
//--TRIMMABLE-BOUNDARY-START(184684150691),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fPer.LCFC.ISelectOption$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "sessionTermHierachy",
      "d": 556963,
      "h": 184684150691,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184684150691),
//--TRIMMABLE-BOUNDARY-START(180389183395),
    {
      "t": 15960406,
      "n": "selectedHierachy",
      "d": 556963,
      "h": 180389183395,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(180389183395),
//--TRIMMABLE-BOUNDARY-START(38655262627),
    {
      "t": 655361,
      "n": "applicationSequenceNumber",
      "d": 556963,
      "h": 38655262627,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655262627),
//--TRIMMABLE-BOUNDARY-START(68720033699),
    {
      "t": 262145,
      "n": "edittingSessionTerm",
      "d": 556963,
      "h": 68720033699,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720033699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360295331),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 556963,
      "h": 34360295331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360295331)
  ],
  "h": 556963,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/ChurchPortal/{*PageRoute}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Pages.CommunityChurchPortalApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}CommunityChurchPortalApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(556963)
        
        

        //--TRIMMABLE-BOUNDARY-START(1408931)
        $asm.$cls(`$pGPn.LCCCCS$1.Synopsis`, ($self) => class Synopsis extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(81605787555)
            /*ICommunityNuggetProvider*/ NuggetProvider = null;
            //--TRIMMABLE-BOUNDARY-END(81605787555)
            
            //--TRIMMABLE-BOUNDARY-START(30066180003)
            /*ICommunityCalendarProvider*/ EventProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30066180003)
            
            //--TRIMMABLE-BOUNDARY-START(85900754851)
            /*CommunityChurchService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(85900754851)
            
            //--TRIMMABLE-BOUNDARY-START(77310820259)
            /*CommunityGroupChurchPostModel*/ Group = null;
            //--TRIMMABLE-BOUNDARY-END(77310820259)
            
            //--TRIMMABLE-BOUNDARY-START(128850427811)
            /*DataFilter */ get TodayNuggetFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Group.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741847/*PostFilterTypes.FeaturedInParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1286/*PostTypes.ArticleNugget*/, $.$LCOv.LCFCPM$1.PostTypes) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(128850427811)
            
            //--TRIMMABLE-BOUNDARY-START(133145395107)
            /*bool */ TrySetParameter$1(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145395107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Group":
                    this.Group = $.$cast(parameter.Value, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(133145395107)
            
            //--TRIMMABLE-BOUNDARY-START(124555460515)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555460515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task*/ let beginTask = (this).LCFCC$1$IBaseComponent$BeginSetParametersAsync();
                $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                {
                    let $en2 = parameters.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let parameter = $en2.Current;
                        {
                            /*bool*/ let set = this.TrySetParameter$1(parameter);
                        }
                    }
                }, $hOPbCk ??= {"r":65537,"n":"","d":1408931,"h":0,"f":17825794}), 0, "SetParametersAsync " + $.$strNN(this.OptimizedComponentName), "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Client.Blazor\\Shared_Synopsis_SynopsisParametertSetter.g.cs", "SetParametersAsync", 37);
                /*Task*/ let endTask = super.SetParametersAsync(parameters);
                if (!beginTask.IsCompletedSuccessfully && !endTask.IsCompletedSuccessfully)
                {
                    return $.$$.STT.Task.WhenAll$1($.$$.S.ReadOnlySpan$$($.$$.STT.Task).op_Implicit$1([ beginTask, endTask ]));
                }
                if (!beginTask.IsCompletedSuccessfully)
                {
                    return beginTask;
                }
                if (!endTask.IsCompletedSuccessfully)
                {
                    return endTask;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(124555460515)
            
            //--TRIMMABLE-BOUNDARY-START(25771212707)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771212707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "pdx mgb-10");
                __builder.AddContent$1(2, this.NuggetProvider.LCCCS$ICommunityNuggetProvider$GetTodayNugget(this.TodayNuggetFilter));
                __builder.AddMarkupContent(3, "\r\n    ");
                __builder.AddContent$1(4, this.EventProvider.LCCCS$ICommunityCalendarProvider$GetUpcomingEvents(this.Group));
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "ul");
                __builder.AddAttribute$5(7, "class", "reset grid colm-1 gap-05");
                let $en3 = $.$sl.SL.Enumerable.Take($.$pGPn.LCCCCS.Place, this.Service.GetPlaces(this.Group), 9).SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let place = $en3.SCG$IEnumerator$$$Current;
                    {
                        __builder.OpenElement(8, "li");
                        __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 9);
                        __builder.AddComponentParameter(10, "href", place.Link);
                        __builder.AddComponentParameter(11, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, place.LinkParameter));
                        __builder.AddComponentParameter(12, "Class", "mg-a d-block text-center");
                        __builder.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(14, "div");
                            __builder2.AddAttribute$5(15, "class", "stack corner-2 pdx-1 pdy mg-1 bg-card bd-primary shadow clickable flex");
                            __builder2.OpenElement(16, "i");
                            __builder2.AddAttribute$5(17, "class", $.$strNN($.$strNN($.$strNN("mgx-a" + " mdi") + " fsz-35") + " ") + $.$strNN((place.Icon)));
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(18, "\r\n                        ");
                            __builder2.OpenElement(19, "h4");
                            __builder2.AddAttribute$5(20, "class", "mgx-a text-center mgt-1 mgb-0 nowrap");
                            __builder2.AddContent$4(21, place.Title);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }), $uiBvKi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1408931,"h":0,"f":17825794}));
                        __builder.CloseComponent();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(25771212707)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21476245411)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476245411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476245411)
            
            //--TRIMMABLE-BOUNDARY-START(21476245411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21476245411)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605787555)
                this.NuggetProvider = null;
                //--TRIMMABLE-BOUNDARY-END(81605787555)
                
                //--TRIMMABLE-BOUNDARY-START(30066180003)
                this.EventProvider = null;
                //--TRIMMABLE-BOUNDARY-END(30066180003)
                
                //--TRIMMABLE-BOUNDARY-START(85900754851)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(85900754851)
                
            }
            static $h = 1408931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605787555),
    {
      "p": 18060736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835983779,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670558627,
        "f": 83886081
      },
      "n": "NuggetProvider",
      "d": 1408931,
      "h": 81605787555,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605787555),
//--TRIMMABLE-BOUNDARY-START(30066180003),
    {
      "p": 17339840,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656114595,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490689443,
        "f": 83886081
      },
      "n": "EventProvider",
      "d": 1408931,
      "h": 30066180003,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066180003),
//--TRIMMABLE-BOUNDARY-START(85900754851),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425918371,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260493219,
        "f": 83886081
      },
      "n": "Service",
      "d": 1408931,
      "h": 85900754851,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900754851),
//--TRIMMABLE-BOUNDARY-START(77310820259),
    {
      "p": 2371927,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246049187,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080624035,
        "f": 83886081
      },
      "n": "Group",
      "d": 1408931,
      "h": 77310820259,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310820259),
//--TRIMMABLE-BOUNDARY-START(128850427811),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015852963,
        "f": 50331650
      },
      "n": "TodayNuggetFilter",
      "d": 1408931,
      "h": 128850427811,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128850427811)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133145395107),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "o": "@$1",
      "d": 1408931,
      "h": 133145395107,
      "f": 553648129
    },
//--TRIMMABLE-BOUNDARY-END(133145395107),
//--TRIMMABLE-BOUNDARY-START(124555460515),
    {
      "r": 178454529,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "SetParametersAsync",
      "d": 1408931,
      "h": 124555460515,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555460515),
//--TRIMMABLE-BOUNDARY-START(25771212707),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1408931,
      "h": 25771212707,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25771212707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476245411),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1408931,
      "h": 21476245411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476245411)
  ],
  "h": 1408931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Shared.Synopsis`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Shared${separator}Synopsis`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1408931)
        
        

        //--TRIMMABLE-BOUNDARY-START(1343395)
        $asm.$cls(`$pGPn.LCCCCS$1.ChurchDashboard`, ($self) => class ChurchDashboard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17181212579)
            /*string*/ BasePath = null;
            //--TRIMMABLE-BOUNDARY-END(17181212579)
            
            //--TRIMMABLE-BOUNDARY-START(55835918243)
            /*CommunityChurchService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(55835918243)
            
            //--TRIMMABLE-BOUNDARY-START(25771147171)
            /*CommunityChurchDashboardModel?*/ dashboard = null;
            //--TRIMMABLE-BOUNDARY-END(25771147171)
            
            //--TRIMMABLE-BOUNDARY-START(51540950947)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540950947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.dashboard = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$yCMk.LCCCCS.ICommunityChurchRemoteService, $.$yCMk.LCCCCM.CommunityChurchDashboardModel, this.Service.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$yCMk.LCCCCS.ICommunityChurchRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel)))().$ctor(this,  (/**/ server) =>
                    {
                        return server.LCCCCS$ICommunityChurchRemoteService$GetDashboard(new $.$fPer.LCFCD.DataFilter().$ctor$12(this.Service.ServiceAccount.Identifier));
                    }, $uAHqJf ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel)).$h,"p":[{"n":"server","p":2961751}],"n":"","d":1343395,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51540950947)
            
            //--TRIMMABLE-BOUNDARY-START(47245983651)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245983651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(47245983651)
            
            //--TRIMMABLE-BOUNDARY-START(81605722019)
            /*ValueTask */ Topup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605722019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.CommunityService.TopupSMSCredit($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, this.Service.ServiceAccount);
            }
            //--TRIMMABLE-BOUNDARY-END(81605722019)
            
            //--TRIMMABLE-BOUNDARY-START(85900689315)
            /*bool */ TrySetParameter$1(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900689315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "BasePath":
                    this.BasePath = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(85900689315)
            
            //--TRIMMABLE-BOUNDARY-START(77310754723)
            /*Task */ SetParametersAsync(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310754723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task*/ let beginTask = (this).LCFCC$1$IBaseComponent$BeginSetParametersAsync();
                $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                {
                    let $en4 = parameters.GetEnumerator();
                    while ($en4.MoveNext())
                    {
                        let parameter = $en4.Current;
                        {
                            /*bool*/ let set = this.TrySetParameter$1(parameter);
                        }
                    }
                }, $YNNArd ??= {"r":65537,"n":"","d":1343395,"h":0,"f":17825794}), 0, "SetParametersAsync " + $.$strNN(this.OptimizedComponentName), "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Client.Blazor\\Shared_ChurchDashboard_ChurchDashboardParametertSetter.g.cs", "SetParametersAsync", 40);
                /*Task*/ let endTask = super.SetParametersAsync(parameters);
                if (!beginTask.IsCompletedSuccessfully && !endTask.IsCompletedSuccessfully)
                {
                    return $.$$.STT.Task.WhenAll$1($.$$.S.ReadOnlySpan$$($.$$.STT.Task).op_Implicit$1([ beginTask, endTask ]));
                }
                if (!beginTask.IsCompletedSuccessfully)
                {
                    return beginTask;
                }
                if (!endTask.IsCompletedSuccessfully)
                {
                    return endTask;
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(77310754723)
            
            //--TRIMMABLE-BOUNDARY-START(21476179875)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476179875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex flow mgb-10 pd bg-card");
                __builder.AddMarkupContent(2, "<div class=\"fill\"></div>\r\n    ");
                __builder.OpenElement(3, "h3");
                __builder.AddAttribute$5(4, "class", "mgy-a");
                __builder.AddContent$4(5, "SMS Credit: ");
                __builder.OpenElement(6, "span");
                __builder.AddAttribute$5(7, "class", "cl-error");
                __builder.AddContent$3(8, $.$box(this.Service.ServiceAccount.SMSCredit, $.$$.S.Int32));
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.AddMarkupContent(9, "\r\n    ");
                __builder.OpenElement(10, "div");
                __builder.AddAttribute$5(11, "class", "flex mgl-a");
                __builder.AddMarkupContent(12, "<div class=\"fill\"></div>\r\n        ");
                __builder.OpenElement(13, "button");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 14, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Topup)));
                __builder.AddAttribute$5(15, "class", "bg-error corner pd fsz-18 mgl mdi mdi-plus");
                __builder.AddContent$4(16, "TopUp");
                __builder.CloseElement();
                __builder.CloseElement();
                __builder.CloseElement();
                if (this.dashboard !== null)
                {
                    __builder.OpenElement(17, "div");
                    __builder.AddAttribute$5(18, "class", "grid colm-25 gap-1");
                    __builder.AddContent$1(19, $.$pGPn.LCCCCS$1.Views.DashboardCard("Students", "mdi mdi-account"/*MaterialDesignIconNames.Account*/, $.$fPer.LCFC.Theme.Primary, $.$box(this.dashboard.TotalMembers, $.$$.S.Int32), $.$strNN(this.BasePath) + "/Members/Information"));
                    __builder.AddMarkupContent(20, "\r\n        ");
                    __builder.AddContent$1(21, $.$pGPn.LCCCCS$1.Views.DashboardCard("Income this month", "mdi mdi-cash-check"/*MaterialDesignIconNames.CashCheck*/, $.$fPer.LCFC.Theme.Message, $.$strNN("\u20A6"/*Money.NairaSymbol*/) + $.$strNN($.$$.S.Double.ToString$3.call(this.dashboard.TotalIncome, "N")), $.$strNN(this.BasePath) + "/Finance/Income"));
                    __builder.AddMarkupContent(22, "\r\n        ");
                    __builder.AddContent$1(23, $.$pGPn.LCCCCS$1.Views.DashboardCard("Expenditure this month", "mdi mdi-cash-lock"/*MaterialDesignIconNames.CashLock*/, $.$fPer.LCFC.Theme.Error, $.$strNN("\u20A6"/*Money.NairaSymbol*/) + $.$strNN($.$$.S.Double.ToString$3.call(this.dashboard.TotalExpenditure, "N")), $.$strNN(this.BasePath) + "/Finance/Expenditure"));
                    __builder.CloseElement();
                    __builder.OpenElement(24, "div");
                    __builder.AddAttribute$5(25, "class", "container mgt-10");
                    __builder.OpenElement(26, "div");
                    __builder.AddAttribute$5(27, "class", "row responsive");
                    __builder.OpenElement(28, "div");
                    __builder.AddAttribute$5(29, "class", "col-6 miwx-35");
                    __builder.OpenElement(30, "div");
                    __builder.AddAttribute$5(31, "class", "bg-card");
                    __builder.OpenElement(32, "div");
                    __builder.AddAttribute$5(33, "class", "bdb pd");
                    __builder.OpenElement(34, "h3");
                    __builder.AddAttribute$5(35, "class", "mg-0");
                    __builder.AddMarkupContent(36, "Collection & Expenses For ");
                    __builder.AddContent$4(37, $.$$.S.DateTime.UtcNow.ToString$3("MMMM, yyyy"));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(38, "\r\n                    ");
                    __builder.OpenElement(39, "div");
                    __builder.AddAttribute$5(40, "class", "pd");
                    __builder.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 41);
                    __builder.AddAttribute$3(42, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/**/ theme) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 43);
                            __builder2.AddComponentParameter(44, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), this.dashboard.CurrentMonthFinance));
                            __builder2.AddComponentParameter(45, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$18(1, 2147483647/*int.MaxValue*/)));
                            __builder2.AddComponentParameter(46, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.Key;
                            }), $bVkzQg ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(47, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                            __builder2.AddComponentParameter(48, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 1/*ChartType.Bar*/), $.$hDPm.LCFCCC$3.ChartType));
                            __builder2.AddComponentParameter(49, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                            __builder2.AddAttribute$3(50, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 51);
                                    __builder3.AddComponentParameter(52, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Value.Income, $.$$.S.Double);
                                    }), $qEHjVa ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(53, "Label", "Incomes");
                                    const $t5 = () => theme.Data;
                                    const $t6 = ($t) => $t.ChartColors;
                                    __builder3.AddComponentParameter(54, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$ifnn($t5, ($t) => $.$ifnn($t6($t), ($t) => $.$$.System.Array.$ReadT1.call($t, 0)))));
                                    const $t7 = () => theme.Data;
                                    const $t8 = ($t) => $t.ChartColors;
                                    __builder3.AddComponentParameter(55, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$ifnn($t7, ($t) => $.$ifnn($t8($t), ($t) => $.$$.System.Array.$ReadT1.call($t, 0)))) + "20"));
                                    __builder3.CloseComponent();
                                    __builder3.AddMarkupContent(56, "\r\n                                ");
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 57);
                                    __builder3.AddComponentParameter(58, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Value.Expense, $.$$.S.Double);
                                    }), $XOCEmk ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(59, "Label", "Expenditures");
                                    const $t9 = () => theme.Data;
                                    const $t10 = ($t) => $t.ChartColors;
                                    __builder3.AddComponentParameter(60, "BorderColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$ifnn($t9, ($t) => $.$ifnn($t10($t), ($t) => $.$$.System.Array.$ReadT1.call($t, 1)))));
                                    const $t11 = () => theme.Data;
                                    const $t12 = ($t) => $t.ChartColors;
                                    __builder3.AddComponentParameter(61, "BackgroundColor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$strNN($.$ifnn($t11, ($t) => $.$ifnn($t12($t), ($t) => $.$$.System.Array.$ReadT1.call($t, 1)))) + "20"));
                                    __builder3.CloseComponent();
                                }, $ckkBzd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                            }), $DlZhef ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $ufKZPg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                    }), $NGrDed ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(62, "\r\n            ");
                    __builder.OpenElement(63, "div");
                    __builder.AddAttribute$5(64, "class", "col-4 miwx-3");
                    __builder.OpenElement(65, "div");
                    __builder.AddAttribute$5(66, "class", "bg-card");
                    __builder.OpenElement(67, "div");
                    __builder.AddAttribute$5(68, "class", "bdb pd");
                    __builder.OpenElement(69, "h3");
                    __builder.AddAttribute$5(70, "class", "mg-0");
                    __builder.AddContent$4(71, "Income - ");
                    __builder.AddContent$4(72, $.$$.S.DateTime.UtcNow.ToString$3("MMMM, yyyy"));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(73, "\r\n                    ");
                    __builder.OpenElement(74, "div");
                    __builder.AddAttribute$5(75, "class", "pd");
                    __builder.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 76);
                    __builder.AddAttribute$3(77, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 78);
                            __builder2.AddComponentParameter(79, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), this.dashboard.CurrentMonthFinanceClass));
                            __builder2.AddComponentParameter(80, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$18(1, 2147483647/*int.MaxValue*/)));
                            __builder2.AddComponentParameter(81, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.Key;
                            }), $Ylnmnj ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(82, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                            __builder2.AddComponentParameter(83, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 3/*ChartType.Doughnut*/), $.$hDPm.LCFCCC$3.ChartType));
                            __builder2.AddComponentParameter(84, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                            __builder2.AddAttribute$3(85, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 86);
                                    __builder3.AddComponentParameter(87, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Value.Income, $.$$.S.Double);
                                    }), $WsYjIh ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(88, "Label", "Incomes");
                                    __builder3.AddComponentParameter(89, "BorderColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), (theme.Data?.ChartColors ?? null)));
                                    __builder3.AddComponentParameter(90, "BackgroundColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), (theme.Data?.ChartColors ?? null)));
                                    __builder3.CloseComponent();
                                }, $MLdhud ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                            }), $VJeBhh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $ZiUMEh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                    }), $jAJXpi ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(91, "\r\n    ");
                    __builder.OpenElement(92, "div");
                    __builder.AddAttribute$5(93, "class", "container mgt-10");
                    __builder.OpenElement(94, "div");
                    __builder.AddAttribute$5(95, "class", "row responsive");
                    __builder.OpenElement(96, "div");
                    __builder.AddAttribute$5(97, "class", "col-4 miwx-3");
                    __builder.OpenElement(98, "div");
                    __builder.AddAttribute$5(99, "class", "bg-card");
                    __builder.OpenElement(100, "div");
                    __builder.AddAttribute$5(101, "class", "bdb pd");
                    __builder.OpenElement(102, "h3");
                    __builder.AddAttribute$5(103, "class", "mg-0");
                    __builder.AddContent$4(104, "Expenses - ");
                    __builder.AddContent$4(105, $.$$.S.DateTime.UtcNow.ToString$3("MMMM, yyyy"));
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.AddMarkupContent(106, "\r\n                    ");
                    __builder.OpenElement(107, "div");
                    __builder.AddAttribute$5(108, "class", "pd");
                    __builder.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 109);
                    __builder.AddAttribute$3(110, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenComponent$1($.$hDPm.LCFCCC$3.Chart$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 111);
                            __builder2.AddComponentParameter(112, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), this.dashboard.CurrentMonthFinanceClass));
                            __builder2.AddComponentParameter(113, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$18(1, 2147483647/*int.MaxValue*/)));
                            __builder2.AddComponentParameter(114, "XAxis", new ($.$$.S.Func$$$$($.$$.S.Int32, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$$.S.String))().$ctor(this, ( (/*i*/ i, /*e*/ e) =>
                            {
                                return e.Key;
                            }), $dgAwRj ??= {"r":1310721,"p":[{"n":"i","p":655361},{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.AddComponentParameter(115, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 300), $.$$.S.Int32));
                            __builder2.AddComponentParameter(116, "Type", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartType, 3/*ChartType.Doughnut*/), $.$hDPm.LCFCCC$3.ChartType));
                            __builder2.AddComponentParameter(117, "ChartFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$3.ChartFeatures, 127/*ChartFeatures.Default*/ & ~4/*ChartFeatures.XGrid*/ & ~8/*ChartFeatures.YGrid*/ & ~8/*ChartFeatures.YGrid*/ & ~1/*ChartFeatures.XAxis*/ & ~2/*ChartFeatures.YAxis*/), $.$hDPm.LCFCCC$3.ChartFeatures));
                            __builder2.AddAttribute$3(118, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)), 119);
                                    __builder3.AddComponentParameter(120, "DataPoint", new ($.$hDPm.LCFCCC$3.ChartDataPoint$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)))().$ctor(this, ( (/*e*/ e) =>
                                    {
                                        return $.$box(e.LCFCCD$1$IDataListItemContext$$$Data.Value.Expense, $.$$.S.Double);
                                    }), $MmvmFi ??= {"r":131073,"p":[{"n":"e","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                                    __builder3.AddComponentParameter(121, "Label", "Incomes");
                                    __builder3.AddComponentParameter(122, "BorderColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), (theme.Data?.ChartColors ?? null)));
                                    __builder3.AddComponentParameter(123, "BackgroundColors", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.String), (theme.Data?.ChartColors ?? null)));
                                    __builder3.CloseComponent();
                                }, $YOEmde ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                            }), $nXSoJc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$hDPm.LCFCCC$3.ChartYAxis$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                            __builder2.CloseComponent();
                        }, $ozFMub ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1343395,"h":0,"f":17825794});
                    }), $mwfFoc ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":1343395,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 124);
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476179875)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886245283)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886245283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886245283)
            
            //--TRIMMABLE-BOUNDARY-START(12886245283)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12886245283)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55835918243)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(55835918243)
                
            }
            static $h = 1343395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181212579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361081763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425852835,
        "f": 83886081
      },
      "n": "BasePath",
      "d": 1343395,
      "h": 17181212579,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181212579),
//--TRIMMABLE-BOUNDARY-START(55835918243),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951016355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015787427,
        "f": 83886081
      },
      "n": "Service",
      "d": 1343395,
      "h": 55835918243,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835918243)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540950947),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1343395,
      "h": 51540950947,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(51540950947),
//--TRIMMABLE-BOUNDARY-START(47245983651),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1343395,
      "h": 47245983651,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245983651),
//--TRIMMABLE-BOUNDARY-START(81605722019),
    {
      "r": 181338113,
      "n": "Topup",
      "d": 1343395,
      "h": 81605722019,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605722019),
//--TRIMMABLE-BOUNDARY-START(85900689315),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "o": "@$1",
      "d": 1343395,
      "h": 85900689315,
      "f": 553648129
    },
//--TRIMMABLE-BOUNDARY-END(85900689315),
//--TRIMMABLE-BOUNDARY-START(77310754723),
    {
      "r": 178454529,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "SetParametersAsync",
      "d": 1343395,
      "h": 77310754723,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310754723),
//--TRIMMABLE-BOUNDARY-START(21476179875),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1343395,
      "h": 21476179875,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476179875)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771147171),
    {
      "t": 1519959,
      "n": "dashboard",
      "d": 1343395,
      "h": 25771147171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771147171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886245283),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1343395,
      "h": 12886245283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886245283)
  ],
  "h": 1343395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Shared.ChurchDashboard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Shared${separator}ChurchDashboard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1343395)
        
        

        //--TRIMMABLE-BOUNDARY-START(622499)
        $asm.$cls(`$pGPn.LCCCCP.CommunityChurchUserApp`, ($self) => class CommunityChurchUserApp extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(201864085411)
            /*string */ get OptimizedComponentName()
            {
                return "communitychurchuserapp";
            }
            //--TRIMMABLE-BOUNDARY-END(201864085411)
            
            //--TRIMMABLE-BOUNDARY-START(287763431331)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763431331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "PageRoute":
                    this.PageRoute = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(287763431331)
            
            //--TRIMMABLE-BOUNDARY-START(176094281635)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094281635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Navigation = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
                this.ChurchApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchUserApplication, serviceProvider);
                this.ChurchService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$pGPn.LCCCCS.CommunityChurchService, serviceProvider);
                this.Auth = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IClientAuthenticationService, serviceProvider);
                this.ChatProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IChatProvider, serviceProvider);
                this.ArticleProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.ICommunityArticleProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(176094281635)
            
            //--TRIMMABLE-BOUNDARY-START(180389248931)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(180389248931)
            
            //--TRIMMABLE-BOUNDARY-START(77310033827)
            /*CommunityChurchUserApplication*/ ChurchApplication = null;
            //--TRIMMABLE-BOUNDARY-END(77310033827)
            
            //--TRIMMABLE-BOUNDARY-START(81605001123)
            /*CommunityChurchService*/ ChurchService = null;
            //--TRIMMABLE-BOUNDARY-END(81605001123)
            
            //--TRIMMABLE-BOUNDARY-START(64425131939)
            /*IClientAuthenticationService*/ Auth = null;
            //--TRIMMABLE-BOUNDARY-END(64425131939)
            
            //--TRIMMABLE-BOUNDARY-START(73015066531)
            /*IChatProvider*/ ChatProvider = null;
            //--TRIMMABLE-BOUNDARY-END(73015066531)
            
            //--TRIMMABLE-BOUNDARY-START(60130164643)
            /*ICommunityArticleProvider*/ ArticleProvider = null;
            //--TRIMMABLE-BOUNDARY-END(60130164643)
            
            //--TRIMMABLE-BOUNDARY-START(206159052707)
            /*string?*/ PageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(206159052707)
            
            //--TRIMMABLE-BOUNDARY-START(51540230051)
            /*IApplication*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(51540230051)
            
            //--TRIMMABLE-BOUNDARY-START(55835197347)
            /*EventHandler*/ ApplicationRendered = null;
            //--TRIMMABLE-BOUNDARY-END(55835197347)
            
            //--TRIMMABLE-BOUNDARY-START(55835197347)
            //--TRIMMABLE-BOUNDARY-START(47245262755)
            add_ApplicationRendered(/*EventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245262755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Combine$2(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47245262755)
            
            //--TRIMMABLE-BOUNDARY-START(214748987299)
            remove_ApplicationRendered(/*EventHandler*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748987299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered = $.$$.S.Delegate.Remove(this.ApplicationRendered, value);
            }
            //--TRIMMABLE-BOUNDARY-END(214748987299)
            
            //--TRIMMABLE-BOUNDARY-END(55835197347)
            
            //--TRIMMABLE-BOUNDARY-START(85899968419)
            /*AuthenticationClientDescriptor */ get Descriptor()
            {
                return this.ChurchService.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(85899968419)
            
            //--TRIMMABLE-BOUNDARY-START(193274150819)
            /*ValueTask<bool> */ OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274150819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Navigation.NavigateTo$2(this.Navigation.Uri, true);
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(193274150819)
            
            //--TRIMMABLE-BOUNDARY-START(197569118115)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569118115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(197569118115)
            
            //--TRIMMABLE-BOUNDARY-START(188979183523)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979183523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(188979183523)
            
            //--TRIMMABLE-BOUNDARY-START(184684216227)
            /*void */ OnAfterRender(/*bool*/ firstRender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684216227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (firstRender)
                {
                    this.ApplicationRendered?.Invoke(this, $.$$.S.EventArgs.Empty);
                }
                super.OnAfterRender(firstRender);
            }
            //--TRIMMABLE-BOUNDARY-END(184684216227)
            
            //--TRIMMABLE-BOUNDARY-START(68720099235)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720099235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSS.CommunityAppServiceGuard$$$$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, $.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures), 0);
                __builder.AddComponentParameter(1, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCSS.CommunityAppServiceGuardFeatures, (4/*CommunityAppServiceGuardFeatures.Default*/ & ~4/*CommunityAppServiceGuardFeatures.Authorization*/) | 1/*CommunityAppServiceGuardFeatures.UseHandleInPath*/), $.$ahDc.LCCCSS.CommunityAppServiceGuardFeatures));
                __builder.AddComponentParameter(2, "Service", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ahDc.LCCCS.ICommunityServiceAccountViewModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), this.ChurchService));
                __builder.AddComponentParameter(3, "BasePath", "Church");
                __builder.AddComponentParameter(4, "PageRoute", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.PageRoute));
                __builder.AddComponentParameter(5, "CustomAuthentication", new ($.$$.S.Func$$($.$$.S.Boolean))().$ctor(this, ( () =>
                {
                    return true;
                }), $uNlXEa ??= {"r":262145,"n":"","d":622499,"h":0,"f":17825794}));
                __builder.AddAttribute$3(6, "NotAuthorizedView", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$ahDc.LCCCSA$1.CommunityAuthentication, 7);
                    /*string?*/ let __ca1__;
                    __builder2.AddComponentParameter(8, "AllowDemoLogin", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, ((__ca1__ = this.ChurchService.ServiceHandle) !== null ? $.$$.S.String.Equals$2.call(__ca1__, "DemoChurch", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(9, "Client", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$GfYa.LCFCA.IAuthenticationClient, this.ChurchService));
                    __builder2.AddComponentParameter(10, "Title", "ZOEY Church");
                    __builder2.AddComponentParameter(11, "BannerImage", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ResolvePath("img/banner-4.jpg", true, true, false)));
                    __builder2.CloseComponent();
                }), $hQWyeh ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":622499,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$ahDc.LCCCSS.CommunityAppServiceGuardContext)))().$ctor(this, ( (/*guard*/ guard) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        $.$pGPn._LCCCCPC$1.TypeInference.CreateCascadingValue_0($.$pGPn.LCCCCS.CommunityChurchService, __builder2, 13, 14, this.ChurchService, 15, true, 16, new $.$mac.MAC.RenderFragment().$ctor(this,  (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$PIIp.LCCGCS$1.CommunityGroupApplicationView$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates), 17);
                            __builder3.AddComponentParameter(18, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, this.ChurchService.ServiceAccount));
                            __builder3.CloseComponent();
                        }, $wTzwqh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":622499,"h":0,"f":17825794}));
                    }, $AkmoCk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":622499,"h":0,"f":17825794});
                }), $QWFnYd ??= {"r":6881395,"p":[{"n":"guard","p":$.$hDPm.LCFCI.ContainerContext$$($.$ahDc.LCCCSS.CommunityAppServiceGuardContext).$h}],"n":"","d":622499,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(68720099235)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //--TRIMMABLE-BOUNDARY-START(25774862409)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.Application.get
            get LCFCS$IApplicationShell$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889960521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(25774862409)
            
            //--TRIMMABLE-BOUNDARY-START(8594993225)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.add
            LCFCS$IApplicationShell$add_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594993225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8594993225)
            
            //--TRIMMABLE-BOUNDARY-START(34364797001)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered.remove
            LCFCS$IApplicationShell$remove_ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34364797001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_ApplicationRendered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34364797001)
            
            //--TRIMMABLE-BOUNDARY-START(17184927817)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.SPA.IApplicationShell.ApplicationRendered
            LivingThing$Core$Frameworks$Client$SPA$IApplicationShell$ApplicationRendered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184927817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ApplicationRendered;
            }
            //--TRIMMABLE-BOUNDARY-END(17184927817)
            
            //--TRIMMABLE-BOUNDARY-START(38655328163)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655328163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655328163)
            
            //--TRIMMABLE-BOUNDARY-START(38655328163)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(38655328163)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(180389248931)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(180389248931)
                
                //--TRIMMABLE-BOUNDARY-START(77310033827)
                this.ChurchApplication = null;
                //--TRIMMABLE-BOUNDARY-END(77310033827)
                
                //--TRIMMABLE-BOUNDARY-START(81605001123)
                this.ChurchService = null;
                //--TRIMMABLE-BOUNDARY-END(81605001123)
                
                //--TRIMMABLE-BOUNDARY-START(64425131939)
                this.Auth = null;
                //--TRIMMABLE-BOUNDARY-END(64425131939)
                
                //--TRIMMABLE-BOUNDARY-START(73015066531)
                this.ChatProvider = null;
                //--TRIMMABLE-BOUNDARY-END(73015066531)
                
                //--TRIMMABLE-BOUNDARY-START(60130164643)
                this.ArticleProvider = null;
                //--TRIMMABLE-BOUNDARY-END(60130164643)
                
            }
            static $h = 622499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(201864085411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209379747,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 622499,
      "h": 201864085411,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(201864085411),
//--TRIMMABLE-BOUNDARY-START(180389248931),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619445155,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878529443,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 622499,
      "h": 180389248931,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389248931),
//--TRIMMABLE-BOUNDARY-START(77310033827),
    {
      "p": 1146787,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849641379,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698660259,
        "f": 83886081
      },
      "n": "ChurchApplication",
      "d": 622499,
      "h": 77310033827,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310033827),
//--TRIMMABLE-BOUNDARY-START(81605001123),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439575971,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288594851,
        "f": 83886081
      },
      "n": "ChurchService",
      "d": 622499,
      "h": 81605001123,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605001123),
//--TRIMMABLE-BOUNDARY-START(64425131939),
    {
      "p": 63592106,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669772195,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518791075,
        "f": 83886081
      },
      "n": "Auth",
      "d": 622499,
      "h": 64425131939,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425131939),
//--TRIMMABLE-BOUNDARY-START(73015066531),
    {
      "p": 63526570,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259706787,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108725667,
        "f": 83886081
      },
      "n": "ChatProvider",
      "d": 622499,
      "h": 73015066531,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015066531),
//--TRIMMABLE-BOUNDARY-START(60130164643),
    {
      "p": 17274304,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079837603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928856483,
        "f": 83886081
      },
      "n": "ArticleProvider",
      "d": 622499,
      "h": 60130164643,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130164643),
//--TRIMMABLE-BOUNDARY-START(206159052707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799314339,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468464035,
        "f": 83886081
      },
      "n": "PageRoute",
      "d": 622499,
      "h": 206159052707,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159052707),
//--TRIMMABLE-BOUNDARY-START(51540230051),
    {
      "p": 4337737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489903011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338921891,
        "f": 83886081
      },
      "n": "Application",
      "d": 622499,
      "h": 51540230051,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540230051),
//--TRIMMABLE-BOUNDARY-START(85899968419),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029510563,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 622499,
      "h": 85899968419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899968419)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(287763431331),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 622499,
      "h": 287763431331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287763431331),
//--TRIMMABLE-BOUNDARY-START(176094281635),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 622499,
      "h": 176094281635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094281635),
//--TRIMMABLE-BOUNDARY-START(193274150819),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": 622499,
      "h": 193274150819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274150819),
//--TRIMMABLE-BOUNDARY-START(197569118115),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": 622499,
      "h": 197569118115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569118115),
//--TRIMMABLE-BOUNDARY-START(188979183523),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 622499,
      "h": 188979183523,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(188979183523),
//--TRIMMABLE-BOUNDARY-START(184684216227),
    {
      "r": 65537,
      "p": [
        {
          "n": "firstRender",
          "p": 262145
        }
      ],
      "n": "OnAfterRender",
      "d": 622499,
      "h": 184684216227,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(184684216227),
//--TRIMMABLE-BOUNDARY-START(68720099235),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 622499,
      "h": 68720099235,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68720099235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655328163),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 622499,
      "h": 38655328163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655328163)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835197347),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_ApplicationRendered",
        "d": 622499,
        "h": 47245262755,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_ApplicationRendered",
        "d": 622499,
        "h": 214748987299,
        "f": 285212673
      },
      "n": "ApplicationRendered",
      "d": 622499,
      "h": 55835197347,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835197347)
  ],
  "h": 622499,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Church/{*PageRoute}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$GfYa.LCFCA.IAuthenticationClient, $.$lJUR.LCFCS.IApplicationShell ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Pages.CommunityChurchUserApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Pages${separator}CommunityChurchUserApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(622499)
        
        

        //--TRIMMABLE-BOUNDARY-START(950179)
        $asm.$cls(`$pGPn.LCCCCS.CommunityChurchPortalApplication`, ($self) => class CommunityChurchPortalApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(17180819363)
            $ctor$5(/*CommunityChurchService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180819363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180819363)
            
            //--TRIMMABLE-BOUNDARY-START(197569445795)
            /*string */ get Name()
            {
                return "ChurchPortal";
            }
            //--TRIMMABLE-BOUNDARY-END(197569445795)
            
            //--TRIMMABLE-BOUNDARY-START(236224151459)
            /*string */ get Title()
            {
                return "Church Portal";
            }
            //--TRIMMABLE-BOUNDARY-END(236224151459)
            
            //--TRIMMABLE-BOUNDARY-START(30065721251)
            /*string */ get Description()
            {
                return "Church Administration";
            }
            //--TRIMMABLE-BOUNDARY-END(30065721251)
            
            //--TRIMMABLE-BOUNDARY-START(193274478499)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-church"/*MaterialDesignIconNames.Church*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193274478499)
            
            //--TRIMMABLE-BOUNDARY-START(231929184163)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#20DECF";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(231929184163)
            
            //--TRIMMABLE-BOUNDARY-START(38655655843)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/ | 512/*ApplicationServiceFeatures.FullScreen*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655655843)
            
            //--TRIMMABLE-BOUNDARY-START(25770753955)
            /*Type? */ get ApplicationViewType()
            {
                return $.$pGPn.LCCCCP.CommunityChurchPortalApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(25770753955)
            
            //--TRIMMABLE-BOUNDARY-START(188979511203)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979511203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$pGPn.LCCCCP.CommunityChurchPortalApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188979511203)
            
            //--TRIMMABLE-BOUNDARY-START(34360688547)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360688547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(34360688547)
            
            //--TRIMMABLE-BOUNDARY-START(223339249571)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(223339249571)
            
            //--TRIMMABLE-BOUNDARY-START(4295917475)
            /*CommunityChurchService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295917475)
            
            //--TRIMMABLE-BOUNDARY-START(227634216867)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(227634216867)
            
            //--TRIMMABLE-BOUNDARY-START(21475786659)
            /*string[]? */ get Aliases()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["ChurchPortal"], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475786659)
            
            //--TRIMMABLE-BOUNDARY-START(214749314979)
            /*string? */ get OpenGraphTitle()
            {
                return "Church Portal";
            }
            //--TRIMMABLE-BOUNDARY-END(214749314979)
            
            //--TRIMMABLE-BOUNDARY-START(201864413091)
            /*string? */ get OpenGraphDescription()
            {
                return "Manage your church end to end";
            }
            //--TRIMMABLE-BOUNDARY-END(201864413091)
            
            //--TRIMMABLE-BOUNDARY-START(210454347683)
            /*string?*/ OpenGraphPath = null;
            //--TRIMMABLE-BOUNDARY-END(210454347683)
            
            //--TRIMMABLE-BOUNDARY-START(206159380387)
            /*string? */ get OpenGraphImage()
            {
                return "_content/LivingThing.Core.Community.Church.Resources/img/og-banner.jpg";
            }
            //--TRIMMABLE-BOUNDARY-END(206159380387)
            
            //--TRIMMABLE-BOUNDARY-START(219044282275)
            /*OpenGraphType */ get OpenGraphType()
            {
                return 2/*OpenGraphType.Website*/;
            }
            //--TRIMMABLE-BOUNDARY-END(219044282275)
            
            //--TRIMMABLE-BOUNDARY-START(240519118755)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(2307/*PostTypes.GroupChurch*/, 2559/*PostTypes.GroupEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519118755)
            
            //--TRIMMABLE-BOUNDARY-START(12901979584)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityApplicationHasAlias.Aliases.get
            get LCCCS$ICommunityApplicationHasAlias$Aliases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312044992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Aliases;
            }
            //--TRIMMABLE-BOUNDARY-END(12901979584)
            
            //--TRIMMABLE-BOUNDARY-START(34379958614)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphTitle.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60149762390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphTitle;
            }
            //--TRIMMABLE-BOUNDARY-END(34379958614)
            
            //--TRIMMABLE-BOUNDARY-START(8610154838)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphDescription.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47264860502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(8610154838)
            
            //--TRIMMABLE-BOUNDARY-START(25790024022)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphPath.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55854795094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphPath;
            }
            //--TRIMMABLE-BOUNDARY-END(25790024022)
            
            //--TRIMMABLE-BOUNDARY-START(17200089430)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphImage.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51559827798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphImage;
            }
            //--TRIMMABLE-BOUNDARY-END(17200089430)
            
            //--TRIMMABLE-BOUNDARY-START(42969893206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphType.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64444729686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphType;
            }
            //--TRIMMABLE-BOUNDARY-END(42969893206)
            
            static $h = 950179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197569445795),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785197987,
        "f": 50364417
      },
      "n": "Name",
      "d": 950179,
      "h": 197569445795,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197569445795),
//--TRIMMABLE-BOUNDARY-START(236224151459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094609315,
        "f": 50364417
      },
      "n": "Title",
      "d": 950179,
      "h": 236224151459,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(236224151459),
//--TRIMMABLE-BOUNDARY-START(30065721251),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015394211,
        "f": 50364417
      },
      "n": "Description",
      "d": 950179,
      "h": 30065721251,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065721251),
//--TRIMMABLE-BOUNDARY-START(193274478499),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195263395,
        "f": 50364417
      },
      "n": "Icon",
      "d": 950179,
      "h": 193274478499,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(193274478499),
//--TRIMMABLE-BOUNDARY-START(231929184163),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504674723,
        "f": 50364417
      },
      "n": "Theme",
      "d": 950179,
      "h": 231929184163,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231929184163),
//--TRIMMABLE-BOUNDARY-START(38655655843),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605328803,
        "f": 50364417
      },
      "n": "Features",
      "d": 950179,
      "h": 38655655843,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655655843),
//--TRIMMABLE-BOUNDARY-START(25770753955),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425459619,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 950179,
      "h": 25770753955,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770753955),
//--TRIMMABLE-BOUNDARY-START(223339249571),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324805539,
        "f": 50364417
      },
      "n": "Order",
      "d": 950179,
      "h": 223339249571,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223339249571),
//--TRIMMABLE-BOUNDARY-START(4295917475),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245590435,
        "f": 50331650
      },
      "n": "_Service",
      "d": 950179,
      "h": 4295917475,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295917475),
//--TRIMMABLE-BOUNDARY-START(227634216867),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914740131,
        "f": 50364417
      },
      "n": "Service",
      "d": 950179,
      "h": 227634216867,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(227634216867),
//--TRIMMABLE-BOUNDARY-START(21475786659),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835525027,
        "f": 50331649
      },
      "n": "Aliases",
      "d": 950179,
      "h": 21475786659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475786659),
//--TRIMMABLE-BOUNDARY-START(214749314979),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144936355,
        "f": 50331649
      },
      "n": "OpenGraphTitle",
      "d": 950179,
      "h": 214749314979,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749314979),
//--TRIMMABLE-BOUNDARY-START(201864413091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375132579,
        "f": 50331649
      },
      "n": "OpenGraphDescription",
      "d": 950179,
      "h": 201864413091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864413091),
//--TRIMMABLE-BOUNDARY-START(210454347683),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555001763,
        "f": 50331649
      },
      "n": "OpenGraphPath",
      "d": 950179,
      "h": 210454347683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454347683),
//--TRIMMABLE-BOUNDARY-START(206159380387),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965067171,
        "f": 50331649
      },
      "n": "OpenGraphImage",
      "d": 950179,
      "h": 206159380387,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159380387),
//--TRIMMABLE-BOUNDARY-START(219044282275),
    {
      "p": 30902614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734870947,
        "f": 50331649
      },
      "n": "OpenGraphType",
      "d": 950179,
      "h": 219044282275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044282275),
//--TRIMMABLE-BOUNDARY-START(240519118755),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684543907,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 950179,
      "h": 240519118755,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240519118755)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(188979511203),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 950179,
      "h": 188979511203,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(188979511203),
//--TRIMMABLE-BOUNDARY-START(34360688547),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 950179,
      "h": 34360688547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360688547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180819363),
    {
      "p": [
        {
          "n": "service",
          "p": 1015715
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 950179,
      "h": 17180819363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180819363)
  ],
  "h": 950179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunityApplicationHasAlias, $.$fPer.LCFCD.IOpenGraphDataProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityChurchPortalApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityChurchPortalApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(950179)
        
        

        //--TRIMMABLE-BOUNDARY-START(1146787)
        $asm.$cls(`$pGPn.LCCCCS.CommunityChurchUserApplication`, ($self) => class CommunityChurchUserApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(17181015971)
            $ctor$5(/*CommunityChurchService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181015971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181015971)
            
            //--TRIMMABLE-BOUNDARY-START(197569642403)
            /*string */ get Name()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(197569642403)
            
            //--TRIMMABLE-BOUNDARY-START(236224348067)
            /*string */ get Title()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(236224348067)
            
            //--TRIMMABLE-BOUNDARY-START(30065917859)
            /*string */ get Description()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(30065917859)
            
            //--TRIMMABLE-BOUNDARY-START(193274675107)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-church"/*MaterialDesignIconNames.Church*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193274675107)
            
            //--TRIMMABLE-BOUNDARY-START(231929380771)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#20DECF";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(231929380771)
            
            //--TRIMMABLE-BOUNDARY-START(38655852451)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/ | 512/*ApplicationServiceFeatures.FullScreen*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655852451)
            
            //--TRIMMABLE-BOUNDARY-START(25770950563)
            /*Type? */ get ApplicationViewType()
            {
                return $.$pGPn.LCCCCP.CommunityChurchUserApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(25770950563)
            
            //--TRIMMABLE-BOUNDARY-START(188979707811)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979707811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$pGPn.LCCCCP.CommunityChurchUserApp, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188979707811)
            
            //--TRIMMABLE-BOUNDARY-START(34360885155)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360885155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(34360885155)
            
            //--TRIMMABLE-BOUNDARY-START(223339446179)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(223339446179)
            
            //--TRIMMABLE-BOUNDARY-START(4296114083)
            /*CommunityChurchService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4296114083)
            
            //--TRIMMABLE-BOUNDARY-START(227634413475)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(227634413475)
            
            //--TRIMMABLE-BOUNDARY-START(21475983267)
            /*string[]? */ get Aliases()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Church"], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475983267)
            
            //--TRIMMABLE-BOUNDARY-START(214749511587)
            /*string? */ get OpenGraphTitle()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(214749511587)
            
            //--TRIMMABLE-BOUNDARY-START(201864609699)
            /*string? */ get OpenGraphDescription()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(201864609699)
            
            //--TRIMMABLE-BOUNDARY-START(210454544291)
            /*string?*/ OpenGraphPath = null;
            //--TRIMMABLE-BOUNDARY-END(210454544291)
            
            //--TRIMMABLE-BOUNDARY-START(206159576995)
            /*string? */ get OpenGraphImage()
            {
                return "_content/LivingThing.Core.Community.Church.Resources/img/og-banner.jpg";
            }
            //--TRIMMABLE-BOUNDARY-END(206159576995)
            
            //--TRIMMABLE-BOUNDARY-START(219044478883)
            /*OpenGraphType */ get OpenGraphType()
            {
                return 2/*OpenGraphType.Website*/;
            }
            //--TRIMMABLE-BOUNDARY-END(219044478883)
            
            //--TRIMMABLE-BOUNDARY-START(240519315363)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(2307/*PostTypes.GroupChurch*/, 2559/*PostTypes.GroupEnds*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519315363)
            
            //--TRIMMABLE-BOUNDARY-START(12901979584)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityApplicationHasAlias.Aliases.get
            get LCCCS$ICommunityApplicationHasAlias$Aliases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312044992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Aliases;
            }
            //--TRIMMABLE-BOUNDARY-END(12901979584)
            
            //--TRIMMABLE-BOUNDARY-START(34379958614)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphTitle.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60149762390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphTitle;
            }
            //--TRIMMABLE-BOUNDARY-END(34379958614)
            
            //--TRIMMABLE-BOUNDARY-START(8610154838)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphDescription.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47264860502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(8610154838)
            
            //--TRIMMABLE-BOUNDARY-START(25790024022)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphPath.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55854795094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphPath;
            }
            //--TRIMMABLE-BOUNDARY-END(25790024022)
            
            //--TRIMMABLE-BOUNDARY-START(17200089430)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphImage.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51559827798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphImage;
            }
            //--TRIMMABLE-BOUNDARY-END(17200089430)
            
            //--TRIMMABLE-BOUNDARY-START(42969893206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOpenGraphDataProvider.OpenGraphType.get
            get LCFCD$IOpenGraphDataProvider$OpenGraphType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64444729686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OpenGraphType;
            }
            //--TRIMMABLE-BOUNDARY-END(42969893206)
            
            static $h = 1146787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197569642403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785394595,
        "f": 50364417
      },
      "n": "Name",
      "d": 1146787,
      "h": 197569642403,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197569642403),
//--TRIMMABLE-BOUNDARY-START(236224348067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094805923,
        "f": 50364417
      },
      "n": "Title",
      "d": 1146787,
      "h": 236224348067,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(236224348067),
//--TRIMMABLE-BOUNDARY-START(30065917859),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015590819,
        "f": 50364417
      },
      "n": "Description",
      "d": 1146787,
      "h": 30065917859,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065917859),
//--TRIMMABLE-BOUNDARY-START(193274675107),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195460003,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1146787,
      "h": 193274675107,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(193274675107),
//--TRIMMABLE-BOUNDARY-START(231929380771),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504871331,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1146787,
      "h": 231929380771,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231929380771),
//--TRIMMABLE-BOUNDARY-START(38655852451),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605525411,
        "f": 50364417
      },
      "n": "Features",
      "d": 1146787,
      "h": 38655852451,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655852451),
//--TRIMMABLE-BOUNDARY-START(25770950563),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425656227,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 1146787,
      "h": 25770950563,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770950563),
//--TRIMMABLE-BOUNDARY-START(223339446179),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325002147,
        "f": 50364417
      },
      "n": "Order",
      "d": 1146787,
      "h": 223339446179,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223339446179),
//--TRIMMABLE-BOUNDARY-START(4296114083),
    {
      "p": 1015715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245787043,
        "f": 50331650
      },
      "n": "_Service",
      "d": 1146787,
      "h": 4296114083,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4296114083),
//--TRIMMABLE-BOUNDARY-START(227634413475),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914936739,
        "f": 50364417
      },
      "n": "Service",
      "d": 1146787,
      "h": 227634413475,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(227634413475),
//--TRIMMABLE-BOUNDARY-START(21475983267),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835721635,
        "f": 50331649
      },
      "n": "Aliases",
      "d": 1146787,
      "h": 21475983267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475983267),
//--TRIMMABLE-BOUNDARY-START(214749511587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145132963,
        "f": 50331649
      },
      "n": "OpenGraphTitle",
      "d": 1146787,
      "h": 214749511587,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749511587),
//--TRIMMABLE-BOUNDARY-START(201864609699),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375329187,
        "f": 50331649
      },
      "n": "OpenGraphDescription",
      "d": 1146787,
      "h": 201864609699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864609699),
//--TRIMMABLE-BOUNDARY-START(210454544291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555198371,
        "f": 50331649
      },
      "n": "OpenGraphPath",
      "d": 1146787,
      "h": 210454544291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454544291),
//--TRIMMABLE-BOUNDARY-START(206159576995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965263779,
        "f": 50331649
      },
      "n": "OpenGraphImage",
      "d": 1146787,
      "h": 206159576995,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159576995),
//--TRIMMABLE-BOUNDARY-START(219044478883),
    {
      "p": 30902614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735067555,
        "f": 50331649
      },
      "n": "OpenGraphType",
      "d": 1146787,
      "h": 219044478883,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044478883),
//--TRIMMABLE-BOUNDARY-START(240519315363),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684740515,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 1146787,
      "h": 240519315363,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240519315363)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(188979707811),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 1146787,
      "h": 188979707811,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(188979707811),
//--TRIMMABLE-BOUNDARY-START(34360885155),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 1146787,
      "h": 34360885155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360885155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181015971),
    {
      "p": [
        {
          "n": "service",
          "p": 1015715
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1146787,
      "h": 17181015971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181015971)
  ],
  "h": 1146787
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunityApplicationHasAlias, $.$fPer.LCFCD.IOpenGraphDataProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityChurchUserApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityChurchUserApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1146787)
        
        

        //--TRIMMABLE-BOUNDARY-START(884643)
        $asm.$cls(`$pGPn.LCCCCS.CommunityChurchAdvisor`, ($self) => class CommunityChurchAdvisor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590819235)
            /*RenderFragment */ GetView(/*CommunityGroupChurchPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590819235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<RenderFragment>*/ let views = new ($.$$.SCG.List$$($.$mac.MAC.RenderFragment))().$ctor$1();
                return $.$hDPm.LCFC.FragmentView.Join$1(null, views);
            }
            //--TRIMMABLE-BOUNDARY-END(8590819235)
            
            //--TRIMMABLE-BOUNDARY-START(4360197802)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IUIAdvisor<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel>.GetView(LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel)
            LCFCI$IUIAdvisor$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchPostModel$GetView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360197802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360197802)
            
            //--TRIMMABLE-BOUNDARY-START(4295851939)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295851939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295851939)
            
            //--TRIMMABLE-BOUNDARY-START(4295851939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295851939)
            
            static $h = 884643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590819235),
    {
      "r": 6881395,
      "p": [
        {
          "n": "target",
          "p": 2371927
        }
      ],
      "n": "GetView",
      "d": 884643,
      "h": 8590819235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590819235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295851939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 884643,
      "h": 4295851939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295851939)
  ],
  "h": 884643
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IUIAdvisor$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityChurchAdvisor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityChurchAdvisor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(884643)
        
        

        //--TRIMMABLE-BOUNDARY-START(1212323)
        $asm.$cls(`$pGPn.LCCCCS.CommunityGroupChurchApplicationHandler`, ($self) => class CommunityGroupChurchApplicationHandler extends $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(167504936867)
            /*PostTypes */ get Type()
            {
                return 2307/*PostTypes.GroupChurch*/;
            }
            //--TRIMMABLE-BOUNDARY-END(167504936867)
            
            //--TRIMMABLE-BOUNDARY-START(4296179619)
            /*IEnumerable<string>?*/ _roles = null;
            //--TRIMMABLE-BOUNDARY-END(4296179619)
            
            //--TRIMMABLE-BOUNDARY-START(146030100387)
            /*IEnumerable<string> */ get Roles()
            {
                return this._roles ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minister", "GuestMinister"], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(146030100387)
            
            //--TRIMMABLE-BOUNDARY-START(154620034979)
            /*string */ get SubGroupTitle()
            {
                return "Department";
            }
            //--TRIMMABLE-BOUNDARY-END(154620034979)
            
            //--TRIMMABLE-BOUNDARY-START(133145198499)
            /*string */ get Id()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(133145198499)
            
            //--TRIMMABLE-BOUNDARY-START(141735133091)
            /*string */ get PostsName()
            {
                return "Churches";
            }
            //--TRIMMABLE-BOUNDARY-END(141735133091)
            
            //--TRIMMABLE-BOUNDARY-START(150325067683)
            /*IEnumerable<ICommunityApplicationServiceCategory>?*/ ServiceCategories = null;
            //--TRIMMABLE-BOUNDARY-END(150325067683)
            
            //--TRIMMABLE-BOUNDARY-START(163209969571)
            /*string? */ get Title()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(163209969571)
            
            //--TRIMMABLE-BOUNDARY-START(128850231203)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-church"/*MaterialDesignIconNames.Church*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128850231203)
            
            //--TRIMMABLE-BOUNDARY-START(137440165795)
            /*string? */ get Name()
            {
                return "Chruch";
            }
            //--TRIMMABLE-BOUNDARY-END(137440165795)
            
            //--TRIMMABLE-BOUNDARY-START(158915002275)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#8E9633";
                    $i1.ForegroundColor = "#FFFFFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(158915002275)
            
            //--TRIMMABLE-BOUNDARY-START(17181081507)
            /*IEnumerable<PostTypes> */ get AccountsType()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostTypes), [2307/*PostTypes.GroupChurch*/], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181081507)
            
            //--TRIMMABLE-BOUNDARY-START(115965329315)
            /*RenderFragment? */ GetAccountView(/*AccountBaseModel*/ account, /*string?*/ route)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965329315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$PIIp.LCCGCS$1.CommunityGroupApplicationView$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates), (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("ViewModel", $.$LCOv.LCFCPM$1.PostFactory.EnsureIsCorrectType$1($.$LCOv.LCFCPM$1.AccountBaseModel, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel, account));
                    $i2.set_Item("Route", route);
                    return $i2;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115965329315)
            
            //--TRIMMABLE-BOUNDARY-START(124555263907)
            /*RenderFragment? */ GetGroupSynopsis(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555263907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$pGPn.LCCCCS$1.Synopsis, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t3 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.set_Item("Group", group);
                    return $i3;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(124555263907)
            
            //--TRIMMABLE-BOUNDARY-START(120260296611)
            /*RenderFragment? */ GetGroupPages(/*AccountBaseModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260296611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
                return $.$hDPm.LCFC.FragmentView.Join(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mac.MAC.RenderFragment), [ $.$hDPm.LCFC.FragmentView.From$1($.$pGPn.LCCCCP.HomePage, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.set_Item("Group", group);
                    return $i4;
                })(), null, null), $.$hDPm.LCFC.FragmentView.From$1($.$pGPn.LCCCCP.LibraryPage, null, null, null) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(120260296611)
            
            //--TRIMMABLE-BOUNDARY-START(12886114211)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886114211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886114211)
            
            //--TRIMMABLE-BOUNDARY-START(12886114211)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886114211)
            
            static $h = 1212323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PIIp.LCCGCS.CommunityGroupTypeHandlerBase$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167504936867),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670362019,
        "f": 50364417
      },
      "n": "Type",
      "d": 1212323,
      "h": 167504936867,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504936867),
//--TRIMMABLE-BOUNDARY-START(146030100387),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720689059,
        "f": 50364417
      },
      "n": "Roles",
      "d": 1212323,
      "h": 146030100387,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146030100387),
//--TRIMMABLE-BOUNDARY-START(154620034979),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900558243,
        "f": 50364417
      },
      "n": "SubGroupTitle",
      "d": 1212323,
      "h": 154620034979,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154620034979),
//--TRIMMABLE-BOUNDARY-START(133145198499),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950885283,
        "f": 50364417
      },
      "n": "Id",
      "d": 1212323,
      "h": 133145198499,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145198499),
//--TRIMMABLE-BOUNDARY-START(141735133091),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130754467,
        "f": 50364417
      },
      "n": "PostsName",
      "d": 1212323,
      "h": 141735133091,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735133091),
//--TRIMMABLE-BOUNDARY-START(150325067683),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310623651,
        "f": 50364417
      },
      "n": "ServiceCategories",
      "d": 1212323,
      "h": 150325067683,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325067683),
//--TRIMMABLE-BOUNDARY-START(163209969571),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080427427,
        "f": 50364417
      },
      "n": "Title",
      "d": 1212323,
      "h": 163209969571,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209969571),
//--TRIMMABLE-BOUNDARY-START(128850231203),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360950691,
        "f": 50364417
      },
      "n": "Icon",
      "d": 1212323,
      "h": 128850231203,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128850231203),
//--TRIMMABLE-BOUNDARY-START(137440165795),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540819875,
        "f": 50364417
      },
      "n": "Name",
      "d": 1212323,
      "h": 137440165795,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440165795),
//--TRIMMABLE-BOUNDARY-START(158915002275),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490492835,
        "f": 50364417
      },
      "n": "Theme",
      "d": 1212323,
      "h": 158915002275,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158915002275),
//--TRIMMABLE-BOUNDARY-START(17181081507),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771016099,
        "f": 50364417
      },
      "n": "AccountsType",
      "d": 1212323,
      "h": 17181081507,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181081507)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115965329315),
    {
      "r": 6881395,
      "p": [
        {
          "n": "account",
          "p": 6220212
        },
        {
          "n": "route",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetAccountView",
      "d": 1212323,
      "h": 115965329315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965329315),
//--TRIMMABLE-BOUNDARY-START(124555263907),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupSynopsis",
      "d": 1212323,
      "h": 124555263907,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555263907),
//--TRIMMABLE-BOUNDARY-START(120260296611),
    {
      "r": 6881395,
      "p": [
        {
          "n": "group",
          "p": 6220212
        }
      ],
      "n": "GetGroupPages",
      "d": 1212323,
      "h": 120260296611,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260296611)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296179619),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "n": "_roles",
      "d": 1212323,
      "h": 4296179619,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296179619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886114211),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1212323,
      "h": 12886114211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886114211)
  ],
  "h": 1212323
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates), $.$PIIp.LCCGCS.ICommunityGroupApplicationTypeHandler, $.$ydCm.LCCCS.ICommunityApplicationSubService, $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$ahDc.LCCCS.ICommunityAccountApplicationViewProvider, $.$ahDc.LCCCSM.ICommunityMembershipFeatureProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), $.$ahDc.LCCCSM.ICommunityMembershipProvider, $.$LCOv.LCFCPM.IAccountMembershipIntegrationBase, $.$LCOv.LCFCPS.IPostFeatureProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), $.$LCOv.LCFCPS.IPostFeatureProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityGroupChurchApplicationHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityGroupChurchApplicationHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1212323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1015715)
        $asm.$cls(`$pGPn.LCCCCS.CommunityChurchService`, ($self) => class CommunityChurchService extends $.$ahDc.LCCCS.CommunityServiceAccountViewModel$$$$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCH.ICommunityChurchHubClient, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, $.$yCMk.LCCCCS.ICommunityChurchRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(30065786787)
            $ctor$6(/*CommunityRootService*/ communityService, /*IAuthenticationService*/ authManager, /*IServerRemoteService*/ server, /*IPersistentStorageService*/ localStorage)
            {
                super.$ctor$5(communityService, authManager, server, null, localStorage, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065786787);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065786787)
            
            //--TRIMMABLE-BOUNDARY-START(313533628323)
            /*string */ get ServiceAccountLabel()
            {
                return "Church";
            }
            //--TRIMMABLE-BOUNDARY-END(313533628323)
            
            //--TRIMMABLE-BOUNDARY-START(317828595619)
            /*PostTypes */ get ServiceAccountType()
            {
                return 2307/*PostTypes.GroupChurch*/;
            }
            //--TRIMMABLE-BOUNDARY-END(317828595619)
            
            //--TRIMMABLE-BOUNDARY-START(347893366691)
            /*bool */ get ThrowErrorOnNoSubscription()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(347893366691)
            
            //--TRIMMABLE-BOUNDARY-START(352188333987)
            /*string? */ get Title()
            {
                return "Zoey Church";
            }
            //--TRIMMABLE-BOUNDARY-END(352188333987)
            
            //--TRIMMABLE-BOUNDARY-START(64425525155)
            /*string? */ get Description()
            {
                return "Zoey Church Management system manages the operation and activities of a your Church from A-Z";
            }
            //--TRIMMABLE-BOUNDARY-END(64425525155)
            
            //--TRIMMABLE-BOUNDARY-START(279173889955)
            /*string? */ get Name()
            {
                return "ZoeyChurch";
            }
            //--TRIMMABLE-BOUNDARY-END(279173889955)
            
            //--TRIMMABLE-BOUNDARY-START(68720492451)
            /*Task<string> */ get DescriptionMarkup()
            {
                return $.$$.STT.Task.FromResult($.$$.S.String, "");
            }
            //--TRIMMABLE-BOUNDARY-END(68720492451)
            
            //--TRIMMABLE-BOUNDARY-START(343598399395)
            /*Task<string> */ get TermsAndConditionsMarkup()
            {
                return $.$$.STT.Task.FromResult($.$$.S.String, "");
            }
            //--TRIMMABLE-BOUNDARY-END(343598399395)
            
            //--TRIMMABLE-BOUNDARY-START(322123562915)
            /*Pager<ServiceTierModel<CommunityChurchServiceTier, CommunityChurchServiceFeatures>> */ get ServiceTiers()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures), this.TypedServiceTiers, null);
            }
            //--TRIMMABLE-BOUNDARY-END(322123562915)
            
            //--TRIMMABLE-BOUNDARY-START(356483301283)
            /*IEnumerable<ServiceTierModel<CommunityChurchServiceTier, CommunityChurchServiceFeatures>>*/ TypedServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(356483301283)
            
            //--TRIMMABLE-BOUNDARY-START(253404086179)
            /*IEnumerable<Place> */ GetPlaces(/*CommunityGroupChurchPostModel*/ group)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404086179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.ToArray($.$pGPn.LCCCCS.Place, $.$sl.SL.Enumerable.Where($.$pGPn.LCCCCS.Place, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$pGPn.LCCCCS.Place), [(group.Settings?.YoutubeStream?.ChannelId ?? null) !== null ? (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t1 = $.$pGPn.LCCCCS.Place;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Title = "Watch us Live";
                    $i1.Description = `Live Program`;
                    $i1.Icon = "mdi-youtube";
                    $i1.Link = "YoutubeLive";
                    $i1.LinkParameter = group;
                    return $i1;
                })() : null, (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t2 = $.$pGPn.LCCCCS.Place;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Title = "Media";
                    $i2.Icon = "mdi-message-video";
                    $i2.Link = "Media";
                    $i2.LinkParameter = group;
                    return $i2;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t3 = $.$pGPn.LCCCCS.Place;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.Title = "Publications";
                    $i3.Icon = "mdi-newspaper";
                    $i3.Link = "Article";
                    $i3.LinkParameter = group;
                    return $i3;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t4 = $.$pGPn.LCCCCS.Place;
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Title = "Activities";
                    $i4.Icon = "mdi-timeline";
                    $i4.Link = "Activities";
                    $i4.LinkParameter = group;
                    return $i4;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t5 = $.$pGPn.LCCCCS.Place;
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.Title = "Departments";
                    $i5.Icon = "mdi-source-branch";
                    $i5.Link = "Departments";
                    $i5.LinkParameter = group;
                    return $i5;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t6 = $.$pGPn.LCCCCS.Place;
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.Title = "Members";
                    $i6.Icon = "mdi-account-multiple-outline";
                    $i6.Link = "Members";
                    $i6.LinkParameter = group;
                    return $i6;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t7 = $.$pGPn.LCCCCS.Place;
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.Title = "Calendar";
                    $i7.Icon = "mdi-calendar";
                    $i7.Link = "Calendar";
                    $i7.LinkParameter = group;
                    return $i7;
                })(), (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t8 = $.$pGPn.LCCCCS.Place;
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.Title = "Chat Us";
                    $i8.Description = `Come. Let's discuss...`;
                    $i8.Icon = "mdi-message";
                    $i8.Link = "Chat";
                    $i8.LinkParameter = group;
                    return $i8;
                })(), (group.Settings?.YoutubeStream?.ChannelId ?? null) !== null ? (() =>
                {
                    //new $.$pGPn.LCCCCS.Place()
                    const $t9 = $.$pGPn.LCCCCS.Place;
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.Title = "Youtube Streams";
                    $i9.Description = `Live Program`;
                    $i9.Icon = "mdi-youtube-tv";
                    $i9.Link = "YoutubeStreams";
                    $i9.LinkParameter = group;
                    return $i9;
                })() : null], [-1], null), new ($.$$.S.Func$$$($.$pGPn.LCCCCS.Place, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                {
                    return p !== null;
                }, $Iyktrf ??= {"r":262145,"p":[{"n":"p","p":1277859}],"n":"","d":1015715,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(253404086179)
            
            //--TRIMMABLE-BOUNDARY-START(73015459747)
            /*AuthenticationClientDescriptor */ get Descriptor()
            {
                return (() =>
                {
                    //new $.$GfYa.LCFCA.AuthenticationClientDescriptor()
                    const $t10 = $.$GfYa.LCFCA.AuthenticationClientDescriptor;
                    const $i10 = new $t10();
                    $i10.$ctor$1();
                    $i10.ApplicationAccountServiceType = $.$yCMk.LCCCCS.ICommunityChurchRemoteService.$type.FullName;
                    $i10.ApplicationAccountServiceParameters = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                        const $t11 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                        const $i11 = new $t11();
                        $i11.$ctor$1();
                        $i11.set_Item("handle", this.ServiceHandle);
                        return $i11;
                    })();
                    return $i10;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(73015459747)
            
            //--TRIMMABLE-BOUNDARY-START(292058791843)
            /*ValueTask<bool> */ OnLoggedIn(/*DecodedAuthenticationTicket*/ ticket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058791843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, false);
            }
            //--TRIMMABLE-BOUNDARY-END(292058791843)
            
            //--TRIMMABLE-BOUNDARY-START(296353759139)
            /*ValueTask */ OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353759139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(296353759139)
            
            //--TRIMMABLE-BOUNDARY-START(42950688675)
            /*IEnumerable<CommunityChurchBranchModel>?*/ Branches = null;
            //--TRIMMABLE-BOUNDARY-END(42950688675)
            
            //--TRIMMABLE-BOUNDARY-START(51540623267)
            /*CommunityChurchBranchModel?*/ CurrentBranch = null;
            //--TRIMMABLE-BOUNDARY-END(51540623267)
            
            //--TRIMMABLE-BOUNDARY-START(47245655971)
            /*DataFilter? */ get CreateFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ServiceAccount.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47245655971)
            
            //--TRIMMABLE-BOUNDARY-START(300648726435)
            /*DataFilter? */ get ReadFilter()
            {
                return new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ServiceAccount.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(300648726435)
            
            //--TRIMMABLE-BOUNDARY-START(360778268579)
            /*DataFilter?*/ UpdateFilter = null;
            //--TRIMMABLE-BOUNDARY-END(360778268579)
            
            //--TRIMMABLE-BOUNDARY-START(60130557859)
            /*DataFilter?*/ DeleteFilter = null;
            //--TRIMMABLE-BOUNDARY-END(60130557859)
            
            //--TRIMMABLE-BOUNDARY-START(283468857251)
            /*void */ On(/*object*/ sender, /*DataEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468857251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let post;
                if (args.Event === 0/*DataEvent.Creating*/ && $.$is(args.Data, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel, { set $v($v){ post = $v; } }))
                {
                    post.ParentId = this.ServiceAccount.Identifier;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468857251)
            
            //--TRIMMABLE-BOUNDARY-START(55835590563)
            /*bool */ get CurrentUserHasSubscription()
            {
                return $.$sl.SL.Enumerable.Any($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), this.Subscriptions, new ($.$$.S.Func$$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$$.S.Boolean))().$ctor(this,  (/*subscription*/ subscription) =>
                {
                    return $.$dspc(subscription.Service.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString) === this.ServiceAccount.ServiceId;
                }, $qcdPjc ??= {"r":262145,"p":[{"n":"subscription","p":$.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$h}],"n":"","d":1015715,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(55835590563)
            
            //--TRIMMABLE-BOUNDARY-START(77310427043)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 1120/*ApplicationServiceFeatures.Default*/;
            }
            //--TRIMMABLE-BOUNDARY-END(77310427043)
            
            //--TRIMMABLE-BOUNDARY-START(287763824547)
            /*Func<Task>?*/ OnLoaded = null;
            //--TRIMMABLE-BOUNDARY-END(287763824547)
            
            //--TRIMMABLE-BOUNDARY-START(287763824547)
            //--TRIMMABLE-BOUNDARY-START(38655721379)
            add_OnLoaded(/*Func<Task>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655721379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnLoaded = $.$$.S.Delegate.Combine$2(this.OnLoaded, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655721379)
            
            //--TRIMMABLE-BOUNDARY-START(309238661027)
            remove_OnLoaded(/*Func<Task>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238661027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnLoaded = $.$$.S.Delegate.Remove(this.OnLoaded, value);
            }
            //--TRIMMABLE-BOUNDARY-END(309238661027)
            
            //--TRIMMABLE-BOUNDARY-END(287763824547)
            
            //--TRIMMABLE-BOUNDARY-START(270583955363)
            /*ValueTask *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270583955363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t12 = super.Load(), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    if ($.$$.S.String.IsNullOrEmpty((this.ServiceAccount?.ServiceId ?? null)))
                    {
                    }
                    else 
                    {
                        let $t13, $r13;
                        /*var*/ let brs = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$yCMk.LCCCCM.CommunityChurchBranchModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.ServiceAccount.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741840/*PostFilterTypes.InParent*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(1213860839096383n | 8n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null);
                        this.Branches = (($t13 = brs, ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)))).AsEnumerable();
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel>?*/ let __ca1__;
                        this.CurrentBranch = ((__ca1__ = this.Branches) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$yCMk.LCCCCM.CommunityChurchBranchModel, __ca1__) : null);
                        if (this.OnLoaded !== null)
                        {
                            let $t14, $r14;
                            ($t14 = this.OnLoaded.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(270583955363)
            
            //--TRIMMABLE-BOUNDARY-START(257699053475)
            /*bool */ IsHoliday(/*DateOnly*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699053475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(257699053475)
            
            //--TRIMMABLE-BOUNDARY-START(266288988067)
            /*bool */ LCCCSA$3$ICommunityAttendanceProvider$$$IsHoliday(/*DateOnly*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288988067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(266288988067)
            
            //--TRIMMABLE-BOUNDARY-START(4295983011)
            /*DataFilter?*/ _memberFilter = null;
            //--TRIMMABLE-BOUNDARY-END(4295983011)
            
            //--TRIMMABLE-BOUNDARY-START(274878922659)
            /*DataFilter */ get MemberFilter()
            {
                return this._memberFilter ??= $.$LCOv.LCFCP.PostUtility.DatabaseSearch(new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 2251799813685248n | 140737488355328n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.PostSearchModel))().$ctor(this,  (/*searchBuilder*/ searchBuilder) =>
                {
                    searchBuilder.HasAssociation(new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.PostSearchModel.CommunityPostSearchAssociationBuilder))().$ctor(this,  (/*associationBuilder*/ associationBuilder) =>
                    {
                        associationBuilder.With(this.ServiceAccount.Identifier);
                    }, $xJXmgi ??= {"r":65537,"p":[{"n":"associationBuilder","p":20244916}],"n":"","d":1015715,"h":0,"f":17825794}), 0, 0);
                    searchBuilder.HasAttributes(new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.PostSearchModel.CommunityPostSearchAttributeBuilder))().$ctor(this,  (/*attributeBuilder*/ attributeBuilder) =>
                    {
                        attributeBuilder.With(2/*PostPropertyQueryFilterType.PropertyKeyStartsWith*/, $.$strNN($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.GetFeatureKey(this.ServiceAccount)) + ".", null, null);
                    }, $kKgeng ??= {"r":65537,"p":[{"n":"attributeBuilder","p":20310452}],"n":"","d":1015715,"h":0,"f":17825794}), 0, 0);
                }, $gVBdPi ??= {"r":65537,"p":[{"n":"searchBuilder","p":20179380}],"n":"","d":1015715,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(274878922659)
            
            //--TRIMMABLE-BOUNDARY-START(261994020771)
            /*Pager<CommunityChurchMemberFeatureModel>? */ LCCCSA$3$ICommunityAttendanceProvider$$$GetAccounts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994020771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Select($.$LCOv.LCFCPM$1.AccountModel, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$LCOv.LCFCPM$1.AccountModel, this.Server, this.MemberFilter, null), new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.AccountModel, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel))().$ctor(this,  (/*account*/ account) =>
                {
                    return $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.From(account, this.ServiceAccount, true);
                }, $AeVoAe ??= {"r":1782103,"p":[{"n":"account","p":7858612}],"n":"","d":1015715,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(261994020771)
            
            //--TRIMMABLE-BOUNDARY-START(8592405440)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider<LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceTier, LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceFeatures>.ServiceTiers.get
            get LCFCP$ICatalogueProvider$$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196784064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(8592405440)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(12886711776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationService.Features.get
            get LCFCA$IApplicationService$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296777184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(12886711776)
            
            //--TRIMMABLE-BOUNDARY-START(12886491522)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.Descriptor.get
            get LCFCA$IAuthenticationClient$Descriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296556930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(12886491522)
            
            //--TRIMMABLE-BOUNDARY-START(17181458818)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoggedIn(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket)
            LCFCA$IAuthenticationClient$OnLoggedIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181458818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoggedIn(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181458818)
            
            //--TRIMMABLE-BOUNDARY-START(21476426114)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient.OnLoginAborted()
            LCFCA$IAuthenticationClient$OnLoginAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476426114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnLoginAborted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476426114)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(356483301283)
                this.TypedServiceTiers = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)), [(() =>
                {
                    //new $.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)()
                    const $t15 = $.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures);
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Name = "ZoeyChurch Trial";
                    $i15.ServiceType = 0/*CommunityChurchServiceTier.Trial*/;
                    $i15.ServiceFeatures = 0/*CommunityChurchServiceFeatures.Standard*/;
                    $i15.Description = "Trial, expires in one term (30 days)";
                    $i15.Cost = $.$fPer.LCFCDM.Money.op_Implicit$1(0);
                    $i15.AmountQualification = "/month";
                    $i15.Duration = $.$$.S.TimeSpan.FromDays$2(30);
                    return $i15;
                })(), (() =>
                {
                    //new $.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)()
                    const $t16 = $.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures);
                    const $i16 = new $t16();
                    $i16.$ctor$2();
                    $i16.Name = "ZoeyChurch Lite";
                    $i16.ServiceType = 1/*CommunityChurchServiceTier.Standard*/;
                    $i16.ServiceFeatures = 0/*CommunityChurchServiceFeatures.Standard*/;
                    $i16.Description = "Basic Church features";
                    $i16.Cost = new $.$fPer.LCFCDM.Money().$ctor$3(10000, 1/*MoneyUnitTypes.Naira*/);
                    $i16.AmountQualification = "/month";
                    $i16.Duration = $.$$.S.TimeSpan.FromDays$2(30);
                    return $i16;
                })()], [-1], null);
                //--TRIMMABLE-BOUNDARY-END(356483301283)
                
            }
            static $h = 1015715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityServiceAccountViewModel$$$$$$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, $.$yCMk.LCCCCH.ICommunityChurchHubClient, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, $.$yCMk.LCCCCS.ICommunityChurchRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(313533628323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979576739,
        "f": 50364417
      },
      "n": "ServiceAccountLabel",
      "d": 1015715,
      "h": 313533628323,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(313533628323),
//--TRIMMABLE-BOUNDARY-START(317828595619),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569511331,
        "f": 50364417
      },
      "n": "ServiceAccountType",
      "d": 1015715,
      "h": 317828595619,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(317828595619),
//--TRIMMABLE-BOUNDARY-START(347893366691),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339315107,
        "f": 50364420
      },
      "n": "ThrowErrorOnNoSubscription",
      "d": 1015715,
      "h": 347893366691,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(347893366691),
//--TRIMMABLE-BOUNDARY-START(352188333987),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929249699,
        "f": 50364417
      },
      "n": "Title",
      "d": 1015715,
      "h": 352188333987,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(352188333987),
//--TRIMMABLE-BOUNDARY-START(64425525155),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850034595,
        "f": 50364417
      },
      "n": "Description",
      "d": 1015715,
      "h": 64425525155,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425525155),
//--TRIMMABLE-BOUNDARY-START(279173889955),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799707555,
        "f": 50331649
      },
      "n": "Name",
      "d": 1015715,
      "h": 279173889955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173889955),
//--TRIMMABLE-BOUNDARY-START(68720492451),
    {
      "p": $.$$.STT.Task$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439969187,
        "f": 50331649
      },
      "n": "DescriptionMarkup",
      "d": 1015715,
      "h": 68720492451,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720492451),
//--TRIMMABLE-BOUNDARY-START(343598399395),
    {
      "p": $.$$.STT.Task$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749380515,
        "f": 50331649
      },
      "n": "TermsAndConditionsMarkup",
      "d": 1015715,
      "h": 343598399395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343598399395),
//--TRIMMABLE-BOUNDARY-START(322123562915),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159445923,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 1015715,
      "h": 322123562915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322123562915),
//--TRIMMABLE-BOUNDARY-START(356483301283),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519184291,
        "f": 50331649
      },
      "n": "TypedServiceTiers",
      "d": 1015715,
      "h": 356483301283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356483301283),
//--TRIMMABLE-BOUNDARY-START(73015459747),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029903779,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 1015715,
      "h": 73015459747,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015459747),
//--TRIMMABLE-BOUNDARY-START(42950688675),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yCMk.LCCCCM.CommunityChurchBranchModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900361635,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713497507,
        "f": 83886081
      },
      "n": "Branches",
      "d": 1015715,
      "h": 42950688675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950688675),
//--TRIMMABLE-BOUNDARY-START(51540623267),
    {
      "p": 667991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080230819,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303432099,
        "f": 83886081
      },
      "n": "CurrentBranch",
      "d": 1015715,
      "h": 51540623267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540623267),
//--TRIMMABLE-BOUNDARY-START(47245655971),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490296227,
        "f": 50331649
      },
      "n": "CreateFilter",
      "d": 1015715,
      "h": 47245655971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245655971),
//--TRIMMABLE-BOUNDARY-START(300648726435),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389642147,
        "f": 50331649
      },
      "n": "ReadFilter",
      "d": 1015715,
      "h": 300648726435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300648726435),
//--TRIMMABLE-BOUNDARY-START(360778268579),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109118883,
        "f": 50331649
      },
      "n": "UpdateFilter",
      "d": 1015715,
      "h": 360778268579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360778268579),
//--TRIMMABLE-BOUNDARY-START(60130557859),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260100003,
        "f": 50331649
      },
      "n": "DeleteFilter",
      "d": 1015715,
      "h": 60130557859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130557859),
//--TRIMMABLE-BOUNDARY-START(55835590563),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670165411,
        "f": 50331649
      },
      "n": "CurrentUserHasSubscription",
      "d": 1015715,
      "h": 55835590563,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835590563),
//--TRIMMABLE-BOUNDARY-START(77310427043),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619838371,
        "f": 50331649
      },
      "n": "Features",
      "d": 1015715,
      "h": 77310427043,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310427043),
//--TRIMMABLE-BOUNDARY-START(274878922659),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209772963,
        "f": 50331649
      },
      "n": "MemberFilter",
      "d": 1015715,
      "h": 274878922659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878922659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(253404086179),
    {
      "r": $.$$.SCG.IEnumerable$$($.$pGPn.LCCCCS.Place).$h,
      "p": [
        {
          "n": "group",
          "p": 2371927
        }
      ],
      "n": "GetPlaces",
      "d": 1015715,
      "h": 253404086179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253404086179),
//--TRIMMABLE-BOUNDARY-START(292058791843),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "d": 1015715,
      "h": 292058791843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292058791843),
//--TRIMMABLE-BOUNDARY-START(296353759139),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "d": 1015715,
      "h": 296353759139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353759139),
//--TRIMMABLE-BOUNDARY-START(283468857251),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "args",
          "p": 9603414
        }
      ],
      "n": "On",
      "d": 1015715,
      "h": 283468857251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283468857251),
//--TRIMMABLE-BOUNDARY-START(270583955363),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1015715,
      "h": 270583955363,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(270583955363),
//--TRIMMABLE-BOUNDARY-START(257699053475),
    {
      "r": 262145,
      "p": [
        {
          "n": "date",
          "p": 65929217
        }
      ],
      "n": "IsHoliday",
      "d": 1015715,
      "h": 257699053475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699053475)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295983011),
    {
      "t": 9734486,
      "n": "_memberFilter",
      "d": 1015715,
      "h": 4295983011,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295983011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065786787),
    {
      "p": [
        {
          "n": "communityService",
          "p": 16487872
        },
        {
          "n": "authManager",
          "p": 1655170
        },
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "localStorage",
          "p": 63932758
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1015715,
      "h": 30065786787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065786787)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(287763824547),
    {
      "e": $.$$.S.Func$$($.$$.STT.Task).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Func$$($.$$.STT.Task).$h
          }
        ],
        "n": "add_OnLoaded",
        "d": 1015715,
        "h": 38655721379,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Func$$($.$$.STT.Task).$h
          }
        ],
        "n": "remove_OnLoaded",
        "d": 1015715,
        "h": 309238661027,
        "f": 285212673
      },
      "n": "OnLoaded",
      "d": 1015715,
      "h": 287763824547,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(287763824547)
  ],
  "h": 1015715
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ahDc.LCCCS.ICommunityServiceAccountViewModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$ahDc.LCCCS.ICommunityServiceAccountViewModel, $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCM.CommunityChurchServiceFeatures), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCSA$3.ICommunityAttendanceProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Client.Services.CommunityChurchService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Client${separator}Services${separator}CommunityChurchService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1015715)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Account.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Account.Client.Blazor", "NetJs.LivingThing.Core.Community.Group.Common", "NetJs.LivingThing.Core.Community.Church.Common", "NetJs.LivingThing.Core.Community.Group.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Messaging.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(32675)
