
//--TRIMMABLE-BOUNDARY-START(12631)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv, $ydCm, $PZCj) {
    "use strict";
    let _;
    let $HMotCf;
    let $poMtle;
    let $sHFavb;
    let $FFotKd;
    let $fymMQc;
    let $DodhKi;
    let $zqwuaa;
    let $KQhmzb;
    let $Twsrfi;
    let $gxkKUd;
    let $KYcDyd;
    let $VhGfRi;
    let $aXCsHk;
    let $IhTgif;
    let $tstujd;
    let $uwnSZi;
    let $dJyNTd;
    let $nOZaya;
    let $WOtaXh;
    let $jhklBc;
    let $ITFvHk;
    let $nhjVIb;
    let $xFQeTd;
    let $oUuZJj;
    let $VrsnXe;
    let $oPlRRk;
    let $GlRKNh;
    let $Aicenk;
    let $wDcjyi;
    let $vScCqj;
    let $ZzQgdl;
    let $Lpiuoc;
    let $krohYc;
    let $OQIXfe;
    let $pHFYhg;
    let $WGIoGc;
    let $igBGHi;
    let $rCCyrd;
    let $rnxsQh;
    let $SdoKXd;
    let $YbfaCa;
    let $tfojLj;
    let $yxTnSg;
    let $lnslpc;
    let $LgxPCi;
    let $WPYdUe;
    let $HsPjhh;
    let $AGRNsg;
    let $VbQxrg;
    let $QclzBa;
    let $uCnSqb;
    let $knHBxa;
    let $jsTYwb;
    let $saGghj;
    let $IrTVMf;
    let $fKDFUh;
    let $yUxxLc;
    let $EqbgOk;
    let $uPHwYi;
    let $uZOrne;
    let $MQIpLg;
    let $RwZhPh;
    let $oWrFIa;
    let $sOeMae;
    let $jZpffa;
    let $XJsidj;
    let $DEfmfh;
    let $weqyPa;
    let $lADUyf;
    let $SjyIfe;
    let $fukBPf;
    let $HfGFWi;
    let $lpgOsa;
    let $gPnIol;
    let $vYjUff;
    let $fYTzzd;
    let $Ozafag;
    let $OyOSZi;
    let $mVLLBd;
    let $jfdHZf;
    let $RqEGxi;
    let $VMEpGf;
    let $QUbwzg;
    let $opZHef;
    let $ApNSjk;
    let $YQYHyj;
    let $RdlYTh;
    let $ZCQeAc;
    let $cMtbQg;
    let $fJFiAe;
    let $kYxzue;
    let $LMBAkg;
    let $XGwDWg;
    let $HJqUFb;
    let $jIHJYe;
    let $KTaEOb;
    let $cVahyc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Church.Common", 
    {
  "h": 12631,
  "f": "LivingThing.Core.Community.Church.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Church.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Church.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(209239)
        $asm.$cls(`$yCMk.LCCCCH.ICommunityChurchHubClient`, ($self) => class ICommunityChurchHubClient
        {
            static $h = 209239;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 209239
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Hubs.ICommunityChurchHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Hubs${separator}ICommunityChurchHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(209239)
        
        

        //--TRIMMABLE-BOUNDARY-START(274775)
        $asm.$cls(`$yCMk.LCCCCH.ICommunityChurchHubServer`, ($self) => class ICommunityChurchHubServer
        {
            static $h = 274775;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 274775
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Hubs.ICommunityChurchHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Hubs${separator}ICommunityChurchHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(274775)
        
        

        //--TRIMMABLE-BOUNDARY-START(1061207)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCheckInModelCustomAttributesProvider`, ($self) => class CommunityChurchCheckInModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296028503)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296028503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296028503)
            
            static $h = 1061207;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296028503),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1061207,
      "h": 4296028503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296028503)
  ],
  "h": 1061207
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCheckInModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1061207)
        
        

        //--TRIMMABLE-BOUNDARY-START(995671)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCheckInModel`, ($self) => class CommunityChurchCheckInModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655701335)
            /*AccountModel*/ Member = null;
            //--TRIMMABLE-BOUNDARY-END(38655701335)
            
            //--TRIMMABLE-BOUNDARY-START(34360734039)
            /*bool*/ IsCheckinIn = false;
            //--TRIMMABLE-BOUNDARY-END(34360734039)
            
            //--TRIMMABLE-BOUNDARY-START(12885897559)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885897559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885897559)
            
            //--TRIMMABLE-BOUNDARY-START(12885897559)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885897559)
            
            static $h = 995671;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655701335),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065766743,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835570519,
        "f": 83886081
      },
      "n": "Member",
      "d": 995671,
      "h": 38655701335,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655701335),
//--TRIMMABLE-BOUNDARY-START(34360734039),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475832151,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245635927,
        "f": 83886081
      },
      "n": "IsCheckinIn",
      "d": 995671,
      "h": 34360734039,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360734039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885897559),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 995671,
      "h": 12885897559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885897559)
  ],
  "h": 995671
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCheckInModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(995671)
        
        

        //--TRIMMABLE-BOUNDARY-START(3158359)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsCustomAttributesProvider`, ($self) => class CommunityGroupChurchPostSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298125655)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298125655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298125655)
            
            static $h = 3158359;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298125655),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3158359,
      "h": 4298125655,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298125655)
  ],
  "h": 3158359
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchPostSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3158359)
        
        

        //--TRIMMABLE-BOUNDARY-START(471383)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBaseDataModelCustomAttributesProvider`, ($self) => class CommunityChurchBaseDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295438679)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295438679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCPM$1.ServiceDataBasePostModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295438679)
            
            static $h = 471383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295438679),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 471383,
      "h": 4295438679,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295438679)
  ],
  "h": 471383
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBaseDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(471383)
        
        

        //--TRIMMABLE-BOUNDARY-START(1323351)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelCustomAttributesProvider`, ($self) => class CommunityChurchCollectionExpensesModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296290647)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296290647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296290647)
            
            static $h = 1323351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296290647),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1323351,
      "h": 4296290647,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296290647)
  ],
  "h": 1323351
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCollectionExpensesModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1323351)
        
        

        //--TRIMMABLE-BOUNDARY-START(3420503)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsCustomAttributesProvider`, ($self) => class CommunityGroupChurchServiceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298387799)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298387799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298387799)
            
            static $h = 3420503;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298387799),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3420503,
      "h": 4298387799,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298387799)
  ],
  "h": 3420503
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchServiceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3420503)
        
        

        //--TRIMMABLE-BOUNDARY-START(3944791)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesCustomAttributesProvider`, ($self) => class CommunityGroupChurchServiceStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298912087)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298912087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298912087)
            
            static $h = 3944791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298912087),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3944791,
      "h": 4298912087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298912087)
  ],
  "h": 3944791
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchServiceStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3944791)
        
        

        //--TRIMMABLE-BOUNDARY-START(2306391)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchServiceTierCustomAttributesProvider`, ($self) => class CommunityChurchServiceTierCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297273687)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297273687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297273687)
            
            static $h = 2306391;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297273687),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2306391,
      "h": 4297273687,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297273687)
  ],
  "h": 2306391
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceTierCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchServiceTierCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2306391)
        
        

        //--TRIMMABLE-BOUNDARY-START(2175319)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchServiceFeaturesCustomAttributesProvider`, ($self) => class CommunityChurchServiceFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297142615)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297142615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297142615)
            
            static $h = 2175319;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297142615),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2175319,
      "h": 4297142615,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297142615)
  ],
  "h": 2175319
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchServiceFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2175319)
        
        

        //--TRIMMABLE-BOUNDARY-START(3682647)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesCustomAttributesProvider`, ($self) => class CommunityGroupChurchPostStatesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298649943)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298649943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$PZCj.LCCGCS$2.CommunityGroupPostStatesCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298649943)
            
            static $h = 3682647;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298649943),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3682647,
      "h": 4298649943,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298649943)
  ],
  "h": 3682647
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStatesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchPostStatesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3682647)
        
        

        //--TRIMMABLE-BOUNDARY-START(78167)
        $asm.$cls(`$yCMk.LCCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295045463)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295045463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchBaseDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchBaseDataModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchBaseDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchBranchModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchBranchModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchBranchModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchCheckInModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchCheckInModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchCheckInModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchDashboardModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchServiceFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchServiceFeaturesCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchServiceFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityChurchServiceTier.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityChurchServiceTierCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityChurchServiceTierCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchPostModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityGroupChurchPostModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchServiceModelCustomAttributesProvider, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsCustomAttributesProvider, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsCustomAttributesProvider, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesCustomAttributesProvider, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesCustomAttributesProvider, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295045463)
            
            static $h = 78167;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295045463),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 78167,
      "h": 4295045463,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295045463)
  ],
  "h": 78167
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(78167)
        
        

        //--TRIMMABLE-BOUNDARY-START(4141399)
        $asm.$cls(`$yCMk.LCCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299108695)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299108695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptorBuilder.Register();
                $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299108695)
            
            static $h = 4141399;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299108695),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4141399,
      "h": 4299108695,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299108695)
  ],
  "h": 4141399
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4141399)
        
        

        //--TRIMMABLE-BOUNDARY-START(1585495)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchDashboardModelCustomAttributesProvider`, ($self) => class CommunityChurchDashboardModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296552791)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296552791)
            
            //--TRIMMABLE-BOUNDARY-START(8591520087)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591520087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yCMk.LCCCCM.CommunityChurchDashboardModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("CurrentMonthFinance", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("TotalIncome", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yCMk.LCCCCM.CommunityChurchDashboardModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HMotCf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1585495,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $poMtle ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1585495,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591520087)
            
            static $h = 1585495;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591520087),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1585495,
      "h": 8591520087,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591520087)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296552791),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1585495,
      "h": 4296552791,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296552791)
  ],
  "h": 1585495
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchDashboardModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1585495)
        
        

        //--TRIMMABLE-BOUNDARY-START(143703)
        $asm.$cls(`$yCMk.LCCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295110999)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295110999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295110999)
            
            static $h = 143703;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295110999),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 143703,
      "h": 4295110999,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295110999)
  ],
  "h": 143703
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(143703)
        
        

        //--TRIMMABLE-BOUNDARY-START(602455)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptorBuilder`, ($self) => class CommunityChurchBaseDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590537047)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590537047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VrsnXe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":602455,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchBaseDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590537047)
            
            //--TRIMMABLE-BOUNDARY-START(4295569751)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295569751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295569751)
            
            //--TRIMMABLE-BOUNDARY-START(4295569751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295569751)
            
            static $h = 602455;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590537047),
    {
      "r": 65537,
      "n": "Register",
      "d": 602455,
      "h": 8590537047,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590537047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295569751),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 602455,
      "h": 4295569751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295569751)
  ],
  "h": 602455
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBaseDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(602455)
        
        

        //--TRIMMABLE-BOUNDARY-START(3551575)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchServiceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593486167)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593486167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zqwuaa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3551575,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593486167)
            
            //--TRIMMABLE-BOUNDARY-START(4298518871)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298518871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298518871)
            
            //--TRIMMABLE-BOUNDARY-START(4298518871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298518871)
            
            static $h = 3551575;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593486167),
    {
      "r": 65537,
      "n": "Register",
      "d": 3551575,
      "h": 8593486167,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593486167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298518871),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3551575,
      "h": 4298518871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298518871)
  ],
  "h": 3551575
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchServiceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3551575)
        
        

        //--TRIMMABLE-BOUNDARY-START(2699607)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchServiceModelCustomAttributesProvider`, ($self) => class CommunityGroupChurchServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297666903)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297666903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.ServiceModelCustomAttributesProvider$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297666903)
            
            static $h = 2699607;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297666903),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2699607,
      "h": 4297666903,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297666903)
  ],
  "h": 2699607
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2699607)
        
        

        //--TRIMMABLE-BOUNDARY-START(2437463)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchPostModelCustomAttributesProvider`, ($self) => class CommunityGroupChurchPostModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297404759)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297404759)
            
            //--TRIMMABLE-BOUNDARY-START(8592372055)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592372055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yCMk.LCCCCM.CommunityGroupChurchPostModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).$type, $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)), [(() =>
                        {
                            //new $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)()
                            const $t3 = $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates);
                            const $i3 = new $t3();
                            $i3.$ctor$3();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("ServiceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yCMk.LCCCCM.CommunityGroupChurchPostModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $sHFavb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2437463,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $FFotKd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2437463,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupBasePostModelCustomAttributesProvider$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592372055)
            
            static $h = 2437463;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592372055),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2437463,
      "h": 8592372055,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592372055)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297404759),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2437463,
      "h": 4297404759,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297404759)
  ],
  "h": 2437463
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchPostModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2437463)
        
        

        //--TRIMMABLE-BOUNDARY-START(4075863)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchServiceStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594010455)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594010455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $fymMQc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4075863,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594010455)
            
            //--TRIMMABLE-BOUNDARY-START(4299043159)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299043159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299043159)
            
            //--TRIMMABLE-BOUNDARY-START(4299043159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299043159)
            
            static $h = 4075863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594010455),
    {
      "r": 65537,
      "n": "Register",
      "d": 4075863,
      "h": 8594010455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594010455)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299043159),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4075863,
      "h": 4299043159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299043159)
  ],
  "h": 4075863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchServiceStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4075863)
        
        

        //--TRIMMABLE-BOUNDARY-START(2830679)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592765271)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592765271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $tfojLj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2830679,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592765271)
            
            //--TRIMMABLE-BOUNDARY-START(4297797975)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297797975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297797975)
            
            //--TRIMMABLE-BOUNDARY-START(4297797975)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297797975)
            
            static $h = 2830679;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592765271),
    {
      "r": 65537,
      "n": "Register",
      "d": 2830679,
      "h": 8592765271,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592765271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297797975),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2830679,
      "h": 4297797975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297797975)
  ],
  "h": 2830679
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2830679)
        
        

        //--TRIMMABLE-BOUNDARY-START(340311)
        $asm.$cls(`$yCMk.LCCCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295307607)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295307607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$yCMk.LCCCCS.ICommunityChurchRemoteService, $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $Twsrfi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $gxkKUd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $KYcDyd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $VhGfRi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $aXCsHk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $IhTgif ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $tstujd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $uwnSZi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking().$ctor$3(impl);
                }, $dJyNTd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $nOZaya ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $WOtaXh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $jhklBc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $ITFvHk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $nhjVIb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $xFQeTd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking().$ctor$3(impl);
                }, $oUuZJj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":340311,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295307607)
            
            static $h = 340311;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295307607),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 340311,
      "h": 4295307607,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295307607)
  ],
  "h": 340311
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(340311)
        
        

        //--TRIMMABLE-BOUNDARY-START(1519959)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchDashboardModel`, ($self) => class CommunityChurchDashboardModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(146030408023)
            /*int*/ TotalMembers = 0;
            //--TRIMMABLE-BOUNDARY-END(146030408023)
            
            //--TRIMMABLE-BOUNDARY-START(38656225623)
            /*IEnumerable<IncomePostModel>?*/ CurrentMonthIncome = null;
            //--TRIMMABLE-BOUNDARY-END(38656225623)
            
            //--TRIMMABLE-BOUNDARY-START(25771323735)
            /*IEnumerable<ExpenditurePostModel>?*/ CurrentMonthExpenditure = null;
            //--TRIMMABLE-BOUNDARY-END(25771323735)
            
            //--TRIMMABLE-BOUNDARY-START(30066291031)
            /*Dictionary<string, CommunityChurchCollectionExpensesModel>? */ get CurrentMonthFinance()
            {
                return $.$sl.SL.Enumerable.ToDictionary$5($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$LCOv.LCFCPM$1.PostBaseModel), $.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, $.$sl.SL.Enumerable.GroupBy$7($.$LCOv.LCFCPM$1.PostBaseModel, $.$$.S.DateTime, $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostBaseModel, $.$sl.SL.Enumerable.Concat($.$LCOv.LCFCPM$1.PostBaseModel, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostBaseModel), null, [0], null), $.$$.N.InterfaceVarianceStubHandler.Create(this.CurrentMonthIncome ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPMF$1.IncomePostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel))), $.$$.N.InterfaceVarianceStubHandler.Create(this.CurrentMonthExpenditure ?? $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPMF$1.ExpenditurePostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel))), new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostBaseModel, $.$$.S.DateTime))().$ctor(this,  (/*d*/ d) =>
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(d.DateCreated).Date;
                }, $ZzQgdl ??= {"r":65994753,"p":[{"n":"d","p":16771508}],"n":"","d":1519959,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$LCOv.LCFCPM$1.PostBaseModel), $.$$.S.String))().$ctor(this,  (/**/ g) =>
                {
                    return $.$$.S.Int32.ToString.call(g.SL$IGrouping$$$$Key.Day);
                }, $Lpiuoc ??= {"r":1310721,"p":[{"n":"g","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$LCOv.LCFCPM$1.PostBaseModel).$h}],"n":"","d":1519959,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$LCOv.LCFCPM$1.PostBaseModel), $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))().$ctor(this,  (/**/ g) =>
                {
                    return (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Income = $.$sl.SL.Enumerable.Sum$16($.$LCOv.LCFCPMF$1.IncomePostModel, $.$sl.SL.Enumerable.Cast($.$LCOv.LCFCPMF$1.IncomePostModel, $.$sl.SL.Enumerable.Where($.$LCOv.LCFCPM$1.PostBaseModel, g, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostBaseModel, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                        {
                            return $.$is(e, $.$LCOv.LCFCPMF$1.IncomePostModel);
                        }, $krohYc ??= {"r":262145,"p":[{"n":"e","p":16771508}],"n":"","d":1519959,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$LCOv.LCFCPMF$1.IncomePostModel, $.$$.S.Double))().$ctor(this,  (/**/ e) =>
                        {
                            return e.Amount;
                        }, $OQIXfe ??= {"r":1179649,"p":[{"n":"e","p":13298100}],"n":"","d":1519959,"h":0,"f":17825794}));
                        $i1.Expense = $.$sl.SL.Enumerable.Sum$16($.$LCOv.LCFCPMF$1.ExpenditurePostModel, $.$sl.SL.Enumerable.Cast($.$LCOv.LCFCPMF$1.ExpenditurePostModel, $.$sl.SL.Enumerable.Where($.$LCOv.LCFCPM$1.PostBaseModel, g, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.PostBaseModel, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                        {
                            return $.$is(e, $.$LCOv.LCFCPMF$1.ExpenditurePostModel);
                        }, $pHFYhg ??= {"r":262145,"p":[{"n":"e","p":16771508}],"n":"","d":1519959,"h":0,"f":17825794}))), new ($.$$.S.Func$$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel, $.$$.S.Double))().$ctor(this,  (/*e*/ e) =>
                        {
                            return e.Amount;
                        }, $WGIoGc ??= {"r":1179649,"p":[{"n":"e","p":12642740}],"n":"","d":1519959,"h":0,"f":17825794}));
                        return $i1;
                    })();
                }, $igBGHi ??= {"r":1257815,"p":[{"n":"g","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$LCOv.LCFCPM$1.PostBaseModel).$h}],"n":"","d":1519959,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(30066291031)
            
            //--TRIMMABLE-BOUNDARY-START(141735440727)
            /*double */ get TotalIncome()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195833175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.Finances.IncomePostModel>?*/ let __ca1__;
                return ((__ca1__ = this.CurrentMonthIncome) !== null ? $.$sl.SL.Enumerable.Sum$16($.$LCOv.LCFCPMF$1.IncomePostModel, __ca1__, new ($.$$.S.Func$$$($.$LCOv.LCFCPMF$1.IncomePostModel, $.$$.S.Double))().$ctor(this,  (/*m*/ m) =>
                {
                    return m.Amount;
                }, $rCCyrd ??= {"r":1179649,"p":[{"n":"m","p":13298100}],"n":"","d":1519959,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(141735440727)
            
            //--TRIMMABLE-BOUNDARY-START(137440473431)
            /*double */ get TotalExpenditure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605898583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Posts.Models.Finances.ExpenditurePostModel>?*/ let __ca2__;
                return ((__ca2__ = this.CurrentMonthExpenditure) !== null ? $.$sl.SL.Enumerable.Sum$16($.$LCOv.LCFCPMF$1.ExpenditurePostModel, __ca2__, new ($.$$.S.Func$$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel, $.$$.S.Double))().$ctor(this,  (/*m*/ m) =>
                {
                    return m.Amount;
                }, $rnxsQh ??= {"r":1179649,"p":[{"n":"m","p":12642740}],"n":"","d":1519959,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(137440473431)
            
            //--TRIMMABLE-BOUNDARY-START(34361258327)
            /*Dictionary<string, CommunityChurchCollectionExpensesModel>?*/ CurrentMonthFinanceClass = null;
            //--TRIMMABLE-BOUNDARY-END(34361258327)
            
            //--TRIMMABLE-BOUNDARY-START(21476356439)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476356439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476356439)
            
            //--TRIMMABLE-BOUNDARY-START(21476356439)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476356439)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361258327)
                this.CurrentMonthFinanceClass = $.$sl.SL.Enumerable.ToDictionary$5($.$$.S.Int32, $.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, $.$sl.SL.Enumerable.Range(1, 4), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.String))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$$.S.Int32.ToString.call(m);
                }, $SdoKXd ??= {"r":1310721,"p":[{"n":"m","p":655361}],"n":"","d":1519959,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.Int32, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))().$ctor(this,  (/**/ m) =>
                {
                    return (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel()
                        const $t2 = $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Income = $.$$.S.Random.Shared.NextDouble();
                        $i2.Expense = $.$$.S.Random.Shared.NextDouble();
                        return $i2;
                    })();
                }, $YbfaCa ??= {"r":1257815,"p":[{"n":"m","p":655361}],"n":"","d":1519959,"h":0,"f":17825794}));
                //--TRIMMABLE-BOUNDARY-END(34361258327)
                
            }
            static $h = 1519959;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(146030408023),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785767767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145506135,
        "f": 83886081
      },
      "n": "TotalMembers",
      "d": 1519959,
      "h": 146030408023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030408023),
//--TRIMMABLE-BOUNDARY-START(38656225623),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015963991,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555571543,
        "f": 83886081
      },
      "n": "CurrentMonthIncome",
      "d": 1519959,
      "h": 38656225623,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656225623),
//--TRIMMABLE-BOUNDARY-START(25771323735),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246160215,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375702359,
        "f": 83886081
      },
      "n": "CurrentMonthExpenditure",
      "d": 1519959,
      "h": 25771323735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771323735),
//--TRIMMABLE-BOUNDARY-START(30066291031),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836094807,
        "f": 50331649
      },
      "n": "CurrentMonthFinance",
      "d": 1519959,
      "h": 30066291031,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066291031),
//--TRIMMABLE-BOUNDARY-START(141735440727),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195833175,
        "f": 50331649
      },
      "n": "TotalIncome",
      "d": 1519959,
      "h": 141735440727,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141735440727),
//--TRIMMABLE-BOUNDARY-START(137440473431),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605898583,
        "f": 50331649
      },
      "n": "TotalExpenditure",
      "d": 1519959,
      "h": 137440473431,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440473431),
//--TRIMMABLE-BOUNDARY-START(34361258327),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426029399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965636951,
        "f": 83886081
      },
      "n": "CurrentMonthFinanceClass",
      "d": 1519959,
      "h": 34361258327,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361258327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476356439),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1519959,
      "h": 21476356439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476356439)
  ],
  "h": 1519959
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchDashboardModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1519959)
        
        

        //--TRIMMABLE-BOUNDARY-START(1454423)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptorBuilder`, ($self) => class CommunityChurchCollectionExpensesModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591389015)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591389015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $VbQxrg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1454423,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591389015)
            
            //--TRIMMABLE-BOUNDARY-START(4296421719)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296421719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296421719)
            
            //--TRIMMABLE-BOUNDARY-START(4296421719)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296421719)
            
            static $h = 1454423;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591389015),
    {
      "r": 65537,
      "n": "Register",
      "d": 1454423,
      "h": 8591389015,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591389015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296421719),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1454423,
      "h": 4296421719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296421719)
  ],
  "h": 1454423
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCollectionExpensesModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1454423)
        
        

        //--TRIMMABLE-BOUNDARY-START(1978711)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptorBuilder`, ($self) => class CommunityChurchMemberFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591913303)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591913303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lpgOsa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1978711,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591913303)
            
            //--TRIMMABLE-BOUNDARY-START(4296946007)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296946007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296946007)
            
            //--TRIMMABLE-BOUNDARY-START(4296946007)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296946007)
            
            static $h = 1978711;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591913303),
    {
      "r": 65537,
      "n": "Register",
      "d": 1978711,
      "h": 8591913303,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591913303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296946007),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1978711,
      "h": 4296946007,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296946007)
  ],
  "h": 1978711
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchMemberFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1978711)
        
        

        //--TRIMMABLE-BOUNDARY-START(733527)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBranchModelCustomAttributesProvider`, ($self) => class CommunityChurchBranchModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295700823)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295700823)
            
            //--TRIMMABLE-BOUNDARY-START(8590668119)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590668119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yCMk.LCCCCM.CommunityChurchBranchModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.ExcludeFilter = ($.$yCMk.LCCCCM.CommunityChurchBranchPropertyFilter.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Address", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1024);
                            $i4.Exclude = $.$cast((16777208), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yCMk.LCCCCM.CommunityChurchBranchModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wDcjyi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":733527,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $vScCqj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":733527,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$yCMk.LCCCCM.CommunityChurchBaseDataModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590668119)
            
            static $h = 733527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590668119),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 733527,
      "h": 8590668119,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590668119)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295700823),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 733527,
      "h": 4295700823,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295700823)
  ],
  "h": 733527
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBranchModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(733527)
        
        

        //--TRIMMABLE-BOUNDARY-START(3813719)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchPostStatesTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593748311)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593748311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStates");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GlRKNh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3813719,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593748311)
            
            //--TRIMMABLE-BOUNDARY-START(4298781015)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298781015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298781015)
            
            //--TRIMMABLE-BOUNDARY-START(4298781015)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298781015)
            
            static $h = 3813719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593748311),
    {
      "r": 65537,
      "n": "Register",
      "d": 3813719,
      "h": 8593748311,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593748311)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298781015),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3813719,
      "h": 4298781015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298781015)
  ],
  "h": 3813719
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStatesTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchPostStatesTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3813719)
        
        

        //--TRIMMABLE-BOUNDARY-START(1847639)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchMemberFeatureModelCustomAttributesProvider`, ($self) => class CommunityChurchMemberFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296814935)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296814935)
            
            //--TRIMMABLE-BOUNDARY-START(8591782231)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591782231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.ExcludeFilter = ($.$yCMk.LCCCCM.CommunityChurchMemberFeaturePropertyFilter.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NamedLocation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777211), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("HomeAddress", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777213), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Attendances", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Identifier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HsPjhh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1847639,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $AGRNsg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1847639,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelCustomAttributesProvider$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591782231)
            
            static $h = 1847639;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591782231),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1847639,
      "h": 8591782231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591782231)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296814935),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1847639,
      "h": 4296814935,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296814935)
  ],
  "h": 1847639
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchMemberFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1847639)
        
        

        //--TRIMMABLE-BOUNDARY-START(864599)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptorBuilder`, ($self) => class CommunityChurchBranchModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590799191)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590799191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yUxxLc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":864599,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchBranchModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590799191)
            
            //--TRIMMABLE-BOUNDARY-START(4295831895)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295831895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295831895)
            
            //--TRIMMABLE-BOUNDARY-START(4295831895)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295831895)
            
            static $h = 864599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590799191),
    {
      "r": 65537,
      "n": "Register",
      "d": 864599,
      "h": 8590799191,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590799191)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295831895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 864599,
      "h": 4295831895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295831895)
  ],
  "h": 864599
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBranchModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(864599)
        
        

        //--TRIMMABLE-BOUNDARY-START(1192279)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptorBuilder`, ($self) => class CommunityChurchCheckInModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591126871)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591126871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RwZhPh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1192279,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchCheckInModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591126871)
            
            //--TRIMMABLE-BOUNDARY-START(4296159575)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296159575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296159575)
            
            //--TRIMMABLE-BOUNDARY-START(4296159575)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296159575)
            
            static $h = 1192279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591126871),
    {
      "r": 65537,
      "n": "Register",
      "d": 1192279,
      "h": 8591126871,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591126871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296159575),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1192279,
      "h": 4296159575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296159575)
  ],
  "h": 1192279
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCheckInModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1192279)
        
        

        //--TRIMMABLE-BOUNDARY-START(2568535)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchPostModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592503127)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592503127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $weqyPa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2568535,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592503127)
            
            //--TRIMMABLE-BOUNDARY-START(4297535831)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297535831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297535831)
            
            //--TRIMMABLE-BOUNDARY-START(4297535831)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297535831)
            
            static $h = 2568535;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592503127),
    {
      "r": 65537,
      "n": "Register",
      "d": 2568535,
      "h": 8592503127,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592503127)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297535831),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2568535,
      "h": 4297535831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297535831)
  ],
  "h": 2568535
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchPostModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2568535)
        
        

        //--TRIMMABLE-BOUNDARY-START(3289431)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptorBuilder`, ($self) => class CommunityGroupChurchPostSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593224023)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593224023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $IrTVMf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3289431,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593224023)
            
            //--TRIMMABLE-BOUNDARY-START(4298256727)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298256727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298256727)
            
            //--TRIMMABLE-BOUNDARY-START(4298256727)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298256727)
            
            static $h = 3289431;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593224023),
    {
      "r": 65537,
      "n": "Register",
      "d": 3289431,
      "h": 8593224023,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593224023)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298256727),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3289431,
      "h": 4298256727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298256727)
  ],
  "h": 3289431
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchPostSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3289431)
        
        

        //--TRIMMABLE-BOUNDARY-START(1716567)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptorBuilder`, ($self) => class CommunityChurchDashboardModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591651159)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591651159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor()
                        const $t1 = $.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ApNSjk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1716567,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591651159)
            
            //--TRIMMABLE-BOUNDARY-START(4296683863)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296683863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296683863)
            
            //--TRIMMABLE-BOUNDARY-START(4296683863)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296683863)
            
            static $h = 1716567;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591651159),
    {
      "r": 65537,
      "n": "Register",
      "d": 1716567,
      "h": 8591651159,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591651159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296683863),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1716567,
      "h": 4296683863,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296683863)
  ],
  "h": 1716567
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchDashboardModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1716567)
        
        

        //--TRIMMABLE-BOUNDARY-START(2044247)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchMemberFeaturePropertyFilter`, ($self) => class CommunityChurchMemberFeaturePropertyFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591978839)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591978839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return schema.AttributeFilter;
            }
            //--TRIMMABLE-BOUNDARY-END(8591978839)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4297011543)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297011543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297011543)
            
            //--TRIMMABLE-BOUNDARY-START(4297011543)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297011543)
            
            static $h = 2044247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591978839),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 2044247,
      "h": 8591978839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591978839)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297011543),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2044247,
      "h": 4297011543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297011543)
  ],
  "h": 2044247
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeaturePropertyFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchMemberFeaturePropertyFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2044247)
        
        

        //--TRIMMABLE-BOUNDARY-START(2896215)
        $asm.$cls(`$yCMk.LCCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592830807)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592830807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, 2307/*PostTypes.GroupChurch*/);
                $.$LCOv.LCFCPM$1.PostFactory.Register($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, 2307/*PostTypes.GroupChurch*/);
                $.$yCMk.LCCCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$yCMk.LCCCC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592830807)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yCMk.LCCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297863511)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297863511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297863511)
            
            //--TRIMMABLE-BOUNDARY-START(4297863511)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297863511)
            
            static $h = 2896215;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592830807),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2896215,
      "h": 8592830807,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592830807)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297863511),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2896215,
      "h": 4297863511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297863511)
  ],
  "h": 2896215
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2896215)
        
        

        //--TRIMMABLE-BOUNDARY-START(930135)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBranchPropertyFilter`, ($self) => class CommunityChurchBranchPropertyFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590864727)
            /*bool */ Filter(/*object?*/ target, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590864727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let propertyName = typeOrProperty.IsT1 ? typeOrProperty.AsT1.LCFCD$1$IPropertyDescriptor$Name : null;
                return propertyName === "Name" || propertyName === "Address";
            }
            //--TRIMMABLE-BOUNDARY-END(8590864727)
            
            //--TRIMMABLE-BOUNDARY-START(4296968534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Attributes.ISchemaFilterProvider.Filter(object?, LivingThing.Core.Frameworks.Common.OneOf.OneOf<System.Type, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCA$1$ISchemaFilterProvider$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296968534)
            
            //--TRIMMABLE-BOUNDARY-START(4295897431)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295897431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295897431)
            
            //--TRIMMABLE-BOUNDARY-START(4295897431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295897431)
            
            static $h = 930135;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590864727),
    {
      "r": 262145,
      "p": [
        {
          "n": "target",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "Filter",
      "d": 930135,
      "h": 8590864727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590864727)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295897431),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 930135,
      "h": 4295897431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295897431)
  ],
  "h": 930135
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaFilterProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchPropertyFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBranchPropertyFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(930135)
        
        

        //--TRIMMABLE-BOUNDARY-START(1257815)
        $asm.$str(`$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel`, ($self) => class CommunityChurchCollectionExpensesModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38655963479)
            /*double*/ Income = 0;
            //--TRIMMABLE-BOUNDARY-END(38655963479)
            
            //--TRIMMABLE-BOUNDARY-START(17181126999)
            /*double*/ Expense = 0;
            //--TRIMMABLE-BOUNDARY-END(17181126999)
            
            //--TRIMMABLE-BOUNDARY-START(12886159703)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886159703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886159703)
            
            //--TRIMMABLE-BOUNDARY-START(12886159703)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886159703)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Income = this.Income;
                copy.Expense = this.Expense;
                return copy;
            }
            static $h = 1257815;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655963479),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360996183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835832663,
        "f": 83886081
      },
      "n": "Income",
      "d": 1257815,
      "h": 38655963479,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655963479),
//--TRIMMABLE-BOUNDARY-START(17181126999),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771061591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245898071,
        "f": 83886081
      },
      "n": "Expense",
      "d": 1257815,
      "h": 17181126999,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181126999)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886159703),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1257815,
      "h": 12886159703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886159703)
  ],
  "h": 1257815
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCollectionExpensesModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1257815)
        
        

        //--TRIMMABLE-BOUNDARY-START(2240855)
        $asm.$str(`$yCMk.LCCCCM.CommunityChurchServiceTier`, ($self) => class CommunityChurchServiceTier extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Trial = 0;
            static Standard = 1;
            static Gold = 2;
            static Platinum = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2240855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Trial": 0n,
                    "Standard": 1n,
                    "Gold": 2n,
                    "Platinum": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297208151)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297208151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297208151)
            
            //--TRIMMABLE-BOUNDARY-START(4297208151)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297208151)
            
            static $h = 2240855;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477077335),
    {
      "t": 2240855,
      "n": "Trial",
      "d": 2240855,
      "h": 21477077335,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477077335),
//--TRIMMABLE-BOUNDARY-START(17182110039),
    {
      "t": 2240855,
      "n": "Standard",
      "d": 2240855,
      "h": 17182110039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182110039),
//--TRIMMABLE-BOUNDARY-START(8592175447),
    {
      "t": 2240855,
      "n": "Gold",
      "d": 2240855,
      "h": 8592175447,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592175447),
//--TRIMMABLE-BOUNDARY-START(12887142743),
    {
      "t": 2240855,
      "n": "Platinum",
      "d": 2240855,
      "h": 12887142743,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887142743)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297208151),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2240855,
      "h": 4297208151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297208151)
  ],
  "h": 2240855
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchServiceTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2240855)
        
        

        //--TRIMMABLE-BOUNDARY-START(2109783)
        $asm.$str(`$yCMk.LCCCCM.CommunityChurchServiceFeatures`, ($self) => class CommunityChurchServiceFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Standard = 0;
            static Gold = 1;
            static Platinum = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2109783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Standard": 0n,
                    "Gold": 1n,
                    "Platinum": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297077079)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297077079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297077079)
            
            //--TRIMMABLE-BOUNDARY-START(4297077079)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297077079)
            
            static $h = 2109783;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181978967),
    {
      "t": 2109783,
      "n": "Standard",
      "d": 2109783,
      "h": 17181978967,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181978967),
//--TRIMMABLE-BOUNDARY-START(8592044375),
    {
      "t": 2109783,
      "n": "Gold",
      "d": 2109783,
      "h": 8592044375,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592044375),
//--TRIMMABLE-BOUNDARY-START(12887011671),
    {
      "t": 2109783,
      "n": "Platinum",
      "d": 2109783,
      "h": 12887011671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887011671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297077079),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2109783,
      "h": 4297077079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297077079)
  ],
  "h": 2109783
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchServiceFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2109783)
        
        

        //--TRIMMABLE-BOUNDARY-START(1782103)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchMemberFeatureModel`, ($self) => class CommunityChurchMemberFeatureModel extends $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(73016226135)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016226135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (context === null)
                {
                    throw new $.$fPer.LCFCD.InvalidValueException().$ctor$6("Church member feature requires a context");
                }
                return $.$strNN("$"/*DataFeatureModel.PrefixIdentifier*/) + "Church." + $.$strNN($.$dspc(context.LCFCD$IIded$Identifier.Id, $.$$.S.Object, ($t) => $t.ToString));
            }
            //--TRIMMABLE-BOUNDARY-END(73016226135)
            
            //--TRIMMABLE-BOUNDARY-START(12886683991)
            static /*CommunityChurchMemberFeatureModel? */ From(/*IDataModel*/ account, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886683991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let feature = $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, ($.$cast(account, $.$Iaui.LCFCM.DataModel)), $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.GetFeatureKey(context), createIfNotExist);
                return feature;
            }
            //--TRIMMABLE-BOUNDARY-END(12886683991)
            
            //--TRIMMABLE-BOUNDARY-START(17181651287)
            /*string? */ get FullName$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361520471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "FullName", null);
            }
            /*string? */ set FullName$1(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080997207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "FullName");
            }
            //--TRIMMABLE-BOUNDARY-END(17181651287)
            
            //--TRIMMABLE-BOUNDARY-START(85901128023)
            /*INamedLocation? */ get NamedLocation$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131324247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDG.INamedLocation, "NamedLocation", null);
            }
            /*INamedLocation? */ set NamedLocation$1(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260866391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDG.INamedLocation, value, "NamedLocation");
            }
            //--TRIMMABLE-BOUNDARY-END(85901128023)
            
            //--TRIMMABLE-BOUNDARY-START(77311193431)
            /*string? */ get HomeAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951455063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "HomeAddress", null);
            }
            /*string? */ set HomeAddress(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670931799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "HomeAddress");
            }
            //--TRIMMABLE-BOUNDARY-END(77311193431)
            
            //--TRIMMABLE-BOUNDARY-START(8591716695)
            /*IEnumerable<AccountAttendanceProperty>? */ get Attendances()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771585879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$LCOv.LCFCPMA.AccountAttendanceProperty, "Attendances");
            }
            /*IEnumerable<AccountAttendanceProperty>? */ set Attendances(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491062615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$LCOv.LCFCPMA.AccountAttendanceProperty, value, "Attendances");
            }
            //--TRIMMABLE-BOUNDARY-END(8591716695)
            
            //--TRIMMABLE-BOUNDARY-START(124555833687)
            /*string? */ get Title()
            {
                return ($.$cast(this.Parent, $.$LCOv.LCFCPM$1.AccountModel)).Title;
            }
            //--TRIMMABLE-BOUNDARY-END(124555833687)
            
            //--TRIMMABLE-BOUNDARY-START(81606160727)
            /*DataId */ get Identifier()
            {
                return ($.$cast(this.Parent, $.$LCOv.LCFCPM$1.AccountModel)).Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(81606160727)
            
            //--TRIMMABLE-BOUNDARY-START(21483874740)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Models.Attendances.IAccountHasAttendence.Title.get
            get LCFCPMA$IAccountHasAttendence$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34368776628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(21483874740)
            
            //--TRIMMABLE-BOUNDARY-START(12893940148)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Models.Attendances.IAccountHasAttendence.Attendances.get
            get LCFCPMA$IAccountHasAttendence$Attendances()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4304005556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attendances;
            }
            //--TRIMMABLE-BOUNDARY-END(12893940148)
            
            //--TRIMMABLE-BOUNDARY-START(30073809332)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Models.Attendances.IAccountHasAttendence.Attendances.set
            set LCFCPMA$IAccountHasAttendence$Attendances(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4304005556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Attendances = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30073809332)
            
            //--TRIMMABLE-BOUNDARY-START(8609040726)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IIded.Identifier.get
            get LCFCD$IIded$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12904008022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(8609040726)
            
            //--TRIMMABLE-BOUNDARY-START(21480729012)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.MembershipTier.get
            get LCFCPM$IAccountMembershipFeatureModel$$$MembershipTier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51545500084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MembershipTier;
            }
            //--TRIMMABLE-BOUNDARY-END(21480729012)
            
            //--TRIMMABLE-BOUNDARY-START(12890794420)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.FullName.get
            get LCFCPM$IAccountMembershipFeatureModel$$$FullName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300859828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FullName$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12890794420)
            
            //--TRIMMABLE-BOUNDARY-START(38660598196)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.ProfilePicture.get
            get LCFCPM$IAccountMembershipFeatureModel$$$ProfilePicture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60135434676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ProfilePicture;
            }
            //--TRIMMABLE-BOUNDARY-END(38660598196)
            
            //--TRIMMABLE-BOUNDARY-START(30070663604)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.NamedLocation.get
            get LCFCPM$IAccountMembershipFeatureModel$$$NamedLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55840467380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NamedLocation$1;
            }
            //--TRIMMABLE-BOUNDARY-END(30070663604)
            
            //--TRIMMABLE-BOUNDARY-START(47250532788)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Membership.IAccountMembershipFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.Verified.get
            get LCFCPM$IAccountMembershipFeatureModel$$$Verified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64430401972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Verified;
            }
            //--TRIMMABLE-BOUNDARY-END(47250532788)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4296749399)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296749399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296749399)
            
            //--TRIMMABLE-BOUNDARY-START(4296749399)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296749399)
            
            static $h = 1782103;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181651287),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361520471,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080997207,
        "f": 83886081
      },
      "n": "FullName",
      "o": "@$1",
      "d": 1782103,
      "h": 17181651287,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181651287),
//--TRIMMABLE-BOUNDARY-START(85901128023),
    {
      "p": 15108438,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131324247,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260866391,
        "f": 83886081
      },
      "n": "NamedLocation",
      "o": "@$1",
      "d": 1782103,
      "h": 85901128023,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777211,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85901128023),
//--TRIMMABLE-BOUNDARY-START(77311193431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951455063,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670931799,
        "f": 83886081
      },
      "n": "HomeAddress",
      "d": 1782103,
      "h": 77311193431,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777213,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311193431),
//--TRIMMABLE-BOUNDARY-START(8591716695),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771585879,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491062615,
        "f": 83886081
      },
      "n": "Attendances",
      "d": 1782103,
      "h": 8591716695,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591716695),
//--TRIMMABLE-BOUNDARY-START(124555833687),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721258839,
        "f": 50331649
      },
      "n": "Title",
      "d": 1782103,
      "h": 124555833687,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555833687),
//--TRIMMABLE-BOUNDARY-START(81606160727),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541389655,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1782103,
      "h": 81606160727,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606160727)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016226135),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270
        }
      ],
      "n": "GetFeatureKey",
      "d": 1782103,
      "h": 73016226135,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016226135),
//--TRIMMABLE-BOUNDARY-START(12886683991),
    {
      "r": 1782103,
      "p": [
        {
          "n": "account",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 1782103,
      "h": 12886683991,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886683991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296749399),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1782103,
      "h": 4296749399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296749399)
  ],
  "h": 1782103,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "ExcludeFilter",
          "v": 2044247,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$LCOv.LCFCPMA.IAccountHasAttendence, $.$fPer.LCFCD.IIded, $.$LCOv.LCFCPM.IAccountMembershipFeatureModel$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), $.$fPer.LCFCD.IDataFeatureModel$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchMemberFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1782103)
        
        

        //--TRIMMABLE-BOUNDARY-START(1126743)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor`, ($self) => class CommunityChurchCheckInModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCheckInModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296094039)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296094039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchCheckInModel, this, factory);
                    }, $oWrFIa ??= {"r":65537,"n":"","d":1126743,"h":0,"f":17825794}), 0, "CommunityChurchCheckInModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchCheckInModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModelTypeDescriptorBuilder.g.cs", "CommunityChurchCheckInModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296094039)
            
            //--TRIMMABLE-BOUNDARY-START(12886028631)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886028631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Member"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchCheckInModel.$type, $.$discardRef(), "Member", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Member")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Member";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.AccountModel, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchCheckInModel)).Member);
                        }, $sOeMae ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1126743,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Member = value.AsReference($.$LCOv.LCFCPM$1.AccountModel);
                        }, $jZpffa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1126743,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsCheckinIn"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchCheckInModel.$type, $.$discardRef(), "IsCheckinIn", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsCheckinIn")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsCheckinIn";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchCheckInModel)).IsCheckinIn);
                        }, $XJsidj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1126743,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.IsCheckinIn = value.AsBool();
                        }, $DEfmfh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1126743,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886028631)
            
            //--TRIMMABLE-BOUNDARY-START(17180995927)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180995927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Member = _target.Member;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Member"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Member, ($v) => _Member = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                    {
                        _target.Member = _Member;
                    }
                }
                {
                    /*var*/ let _IsCheckinIn = _target.IsCheckinIn;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsCheckinIn"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsCheckinIn, ($v) => _IsCheckinIn = $v, null, true)))
                    {
                        _target.IsCheckinIn = _IsCheckinIn;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180995927)
            
            //--TRIMMABLE-BOUNDARY-START(8591061335)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591061335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchCheckInModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchCheckInModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchCheckInModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchCheckInModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchCheckInModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchCheckInModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591061335)
            
            static $h = 1126743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCheckInModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886028631),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1126743,
      "h": 12886028631,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886028631),
//--TRIMMABLE-BOUNDARY-START(17180995927),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 995671,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1126743,
      "h": 17180995927,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180995927),
//--TRIMMABLE-BOUNDARY-START(8591061335),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 995671,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1126743,
      "h": 8591061335,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591061335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296094039),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1126743,
      "h": 4296094039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296094039)
  ],
  "h": 1126743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCheckInModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCheckInModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCheckInModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1126743)
        
        

        //--TRIMMABLE-BOUNDARY-START(1651031)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor`, ($self) => class CommunityChurchDashboardModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296618327)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296618327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchDashboardModel, this, factory);
                    }, $YQYHyj ??= {"r":65537,"n":"","d":1651031,"h":0,"f":17825794}), 0, "CommunityChurchDashboardModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchDashboardModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModelTypeDescriptorBuilder.g.cs", "CommunityChurchDashboardModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296618327)
            
            //--TRIMMABLE-BOUNDARY-START(12886552919)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886552919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalMembers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "TotalMembers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalMembers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "TotalMembers";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).TotalMembers);
                        }, $RdlYTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TotalMembers = value.AsInt();
                        }, $ZCQeAc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentMonthIncome"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "CurrentMonthIncome", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentMonthIncome")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CurrentMonthIncome";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).CurrentMonthIncome);
                        }, $cMtbQg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentMonthIncome = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel));
                        }, $fJFiAe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentMonthExpenditure"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "CurrentMonthExpenditure", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentMonthExpenditure")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "CurrentMonthExpenditure";
                        $i5.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).CurrentMonthExpenditure);
                        }, $kYxzue ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentMonthExpenditure = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel));
                        }, $LMBAkg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentMonthFinance"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "CurrentMonthFinance", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentMonthFinance")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CurrentMonthFinance";
                        $i7.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).CurrentMonthFinance);
                        }, $XGwDWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalIncome"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "TotalIncome", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalIncome")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "TotalIncome";
                        $i9.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).TotalIncome);
                        }, $HJqUFb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalExpenditure"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "TotalExpenditure", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalExpenditure")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "TotalExpenditure";
                        $i11.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).TotalExpenditure);
                        }, $jIHJYe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CurrentMonthFinanceClass"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchDashboardModel.$type, $.$discardRef(), "CurrentMonthFinanceClass", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CurrentMonthFinanceClass")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "CurrentMonthFinanceClass";
                        $i13.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)).CurrentMonthFinanceClass);
                        }, $KTaEOb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1651031,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CurrentMonthFinanceClass = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel));
                        }, $cVahyc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1651031,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886552919)
            
            //--TRIMMABLE-BOUNDARY-START(17181520215)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181520215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _TotalMembers = _target.TotalMembers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalMembers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalMembers, ($v) => _TotalMembers = $v, $.$$.S.Int32)))
                    {
                        _target.TotalMembers = _TotalMembers;
                    }
                }
                {
                    /*var*/ let _CurrentMonthIncome = _target.CurrentMonthIncome;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentMonthIncome"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), $.$LCOv.LCFCPMF$1.IncomePostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), $.$LCOv.LCFCPMF$1.IncomePostModel, property, $.$ref(() => _CurrentMonthIncome, ($v) => _CurrentMonthIncome = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel))))
                    {
                        _target.CurrentMonthIncome = _CurrentMonthIncome;
                        if (_CurrentMonthIncome !== null)
                        {
                            let $en17 = _CurrentMonthIncome.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPMF$1.IncomePostModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel), $.$LCOv.LCFCPMF$1.IncomePostModel, property, $.$ref(() => _CurrentMonthIncome, ($v) => _CurrentMonthIncome = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.IncomePostModel)));
                    }
                }
                {
                    /*var*/ let _CurrentMonthExpenditure = _target.CurrentMonthExpenditure;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentMonthExpenditure"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), $.$LCOv.LCFCPMF$1.ExpenditurePostModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), $.$LCOv.LCFCPMF$1.ExpenditurePostModel, property, $.$ref(() => _CurrentMonthExpenditure, ($v) => _CurrentMonthExpenditure = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel))))
                    {
                        _target.CurrentMonthExpenditure = _CurrentMonthExpenditure;
                        if (_CurrentMonthExpenditure !== null)
                        {
                            let $en22 = _CurrentMonthExpenditure.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en22.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPMF$1.ExpenditurePostModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel), $.$LCOv.LCFCPMF$1.ExpenditurePostModel, property, $.$ref(() => _CurrentMonthExpenditure, ($v) => _CurrentMonthExpenditure = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMF$1.ExpenditurePostModel)));
                    }
                }
                {
                    /*var*/ let _CurrentMonthFinance = _target.CurrentMonthFinance;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentMonthFinance"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CurrentMonthFinance, ($v) => _CurrentMonthFinance = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))))
                    {
                    }
                }
                {
                    /*var*/ let _TotalIncome = _target.TotalIncome;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalIncome"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TotalIncome, ($v) => _TotalIncome = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _TotalExpenditure = _target.TotalExpenditure;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalExpenditure"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _TotalExpenditure, ($v) => _TotalExpenditure = $v, $.$$.S.Double)))
                    {
                    }
                }
                {
                    /*var*/ let _CurrentMonthFinanceClass = _target.CurrentMonthFinanceClass;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CurrentMonthFinanceClass"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CurrentMonthFinanceClass, ($v) => _CurrentMonthFinanceClass = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel))))
                    {
                        _target.CurrentMonthFinanceClass = _CurrentMonthFinanceClass;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181520215)
            
            //--TRIMMABLE-BOUNDARY-START(8591585623)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591585623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityChurchDashboardModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchDashboardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchDashboardModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchDashboardModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchDashboardModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchDashboardModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchDashboardModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591585623)
            
            static $h = 1651031;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886552919),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1651031,
      "h": 12886552919,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886552919),
//--TRIMMABLE-BOUNDARY-START(17181520215),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1519959,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1651031,
      "h": 17181520215,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181520215),
//--TRIMMABLE-BOUNDARY-START(8591585623),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1519959,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1651031,
      "h": 8591585623,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591585623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296618327),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1651031,
      "h": 4296618327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296618327)
  ],
  "h": 1651031
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchDashboardModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1651031)
        
        

        //--TRIMMABLE-BOUNDARY-START(1388887)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor`, ($self) => class CommunityChurchCollectionExpensesModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296356183)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296356183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, this, factory);
                    }, $QclzBa ??= {"r":65537,"n":"","d":1388887,"h":0,"f":17825794}), 0, "CommunityChurchCollectionExpensesModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchDashboardModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModelTypeDescriptorBuilder.g.cs", "CommunityChurchCollectionExpensesModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296356183)
            
            //--TRIMMABLE-BOUNDARY-START(12886290775)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886290775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Income"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel.$type, $.$discardRef(), "Income", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Income")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Income";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).Income);
                        }, $uCnSqb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1388887,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, target).$v.Income = value.AsDouble();
                        }, $knHBxa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1388887,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Expense"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel.$type, $.$discardRef(), "Expense", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Expense")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Expense";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel)).Expense);
                        }, $jsTYwb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1388887,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, target).$v.Expense = value.AsDouble();
                        }, $saGghj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1388887,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886290775)
            
            //--TRIMMABLE-BOUNDARY-START(17181258071)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181258071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Income = _target.Income;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Income"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Income, ($v) => _Income = $v, $.$$.S.Double)))
                    {
                        _target.Income = _Income;
                    }
                }
                {
                    /*var*/ let _Expense = _target.Expense;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Expense"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Expense, ($v) => _Expense = $v, $.$$.S.Double)))
                    {
                        _target.Expense = _Expense;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181258071)
            
            //--TRIMMABLE-BOUNDARY-START(8591323479)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591323479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591323479)
            
            static $h = 1388887;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886290775),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1388887,
      "h": 12886290775,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886290775),
//--TRIMMABLE-BOUNDARY-START(17181258071),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1257815,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1388887,
      "h": 17181258071,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181258071),
//--TRIMMABLE-BOUNDARY-START(8591323479),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1257815,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1388887,
      "h": 8591323479,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591323479)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296356183),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1388887,
      "h": 4296356183,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296356183)
  ],
  "h": 1388887
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchCollectionExpensesModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchCollectionExpensesModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchCollectionExpensesModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1388887)
        
        

        //--TRIMMABLE-BOUNDARY-START(1913175)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor`, ($self) => class CommunityChurchMemberFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296880471)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296880471);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, this, factory);
                    }, $gPnIol ??= {"r":65537,"n":"","d":1913175,"h":0,"f":17825794}), 0, "CommunityChurchMemberFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchMemberFeatureModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModelTypeDescriptorBuilder.g.cs", "CommunityChurchMemberFeatureModelTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296880471)
            
            //--TRIMMABLE-BOUNDARY-START(12886815063)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886815063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FullName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "FullName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FullName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "FullName";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).FullName$1);
                        }, $vYjUff ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FullName$1 = value.AsReference($.$$.S.String);
                        }, $fYTzzd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NamedLocation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "NamedLocation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NamedLocation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDG.INamedLocation, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "NamedLocation";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDG.INamedLocation, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).NamedLocation$1);
                        }, $Ozafag ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NamedLocation$1 = value.AsReference($.$fPer.LCFCDG.INamedLocation);
                        }, $OyOSZi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HomeAddress"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "HomeAddress", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HomeAddress")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "HomeAddress";
                        $i5.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).HomeAddress);
                        }, $mVLLBd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.HomeAddress = value.AsReference($.$$.S.String);
                        }, $jfdHZf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Attendances"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "Attendances", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Attendances")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Attendances";
                        $i7.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty), ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).Attendances);
                        }, $RqEGxi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Attendances = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty));
                        }, $VMEpGf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Title";
                        $i9.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).Title);
                        }, $QUbwzg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Identifier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel.$type, $.$discardRef(), "Identifier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Identifier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Identifier";
                        $i11.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)).Identifier);
                        }, $opZHef ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1913175,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886815063)
            
            //--TRIMMABLE-BOUNDARY-START(17181782359)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181782359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupMemberFeatureModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModelTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupMemberFeatureModel$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)));
                {
                    /*var*/ let _FullName = _target.FullName$1;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FullName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FullName, ($v) => _FullName = $v, $.$$.S.String)))
                    {
                        _target.FullName$1 = _FullName;
                    }
                }
                {
                    /*var*/ let _NamedLocation = _target.NamedLocation$1;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NamedLocation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDG.INamedLocation));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NamedLocation, ($v) => _NamedLocation = $v, $.$fPer.LCFCDG.INamedLocation)))
                    {
                        _target.NamedLocation$1 = _NamedLocation;
                    }
                }
                {
                    /*var*/ let _HomeAddress = _target.HomeAddress;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HomeAddress"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _HomeAddress, ($v) => _HomeAddress = $v, $.$$.S.String)))
                    {
                        _target.HomeAddress = _HomeAddress;
                    }
                }
                {
                    /*var*/ let _Attendances = _target.Attendances;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Attendances"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty), $.$LCOv.LCFCPMA.AccountAttendanceProperty));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty), $.$LCOv.LCFCPMA.AccountAttendanceProperty, property, $.$ref(() => _Attendances, ($v) => _Attendances = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty))))
                    {
                        _target.Attendances = _Attendances;
                        if (_Attendances !== null)
                        {
                            let $en20 = _Attendances.SCG$IEnumerable$$$GetEnumerator();
                            while ($en20.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en20.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPMA.AccountAttendanceProperty)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty), $.$LCOv.LCFCPMA.AccountAttendanceProperty, property, $.$ref(() => _Attendances, ($v) => _Attendances = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMA.AccountAttendanceProperty)));
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Identifier = _target.Identifier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Identifier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _Identifier, ($v) => _Identifier = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181782359)
            
            //--TRIMMABLE-BOUNDARY-START(8591847767)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591847767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591847767)
            
            static $h = 1913175;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886815063),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1913175,
      "h": 12886815063,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886815063),
//--TRIMMABLE-BOUNDARY-START(17181782359),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1782103,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1913175,
      "h": 17181782359,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181782359),
//--TRIMMABLE-BOUNDARY-START(8591847767),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1782103,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1913175,
      "h": 8591847767,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591847767)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296880471),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1913175,
      "h": 4296880471,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296880471)
  ],
  "h": 1913175
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchMemberFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchMemberFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1913175)
        
        

        //--TRIMMABLE-BOUNDARY-START(3092823)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings`, ($self) => class CommunityGroupChurchPostSettings extends $.$PZCj.LCCGCS$1.CommunityGroupPostSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298060119)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298060119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298060119)
            
            //--TRIMMABLE-BOUNDARY-START(4298060119)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4298060119)
            
            static $h = 3092823;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupPostSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298060119),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3092823,
      "h": 4298060119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298060119)
  ],
  "h": 3092823
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchPostSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3092823)
        
        

        //--TRIMMABLE-BOUNDARY-START(3617111)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchPostStates`, ($self) => class CommunityGroupChurchPostStates extends $.$PZCj.LCCGCS$2.CommunityGroupPostStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298584407)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298584407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298584407)
            
            //--TRIMMABLE-BOUNDARY-START(4298584407)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4298584407)
            
            static $h = 3617111;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupPostStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298584407),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3617111,
      "h": 4298584407,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298584407)
  ],
  "h": 3617111
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchPostStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3617111)
        
        

        //--TRIMMABLE-BOUNDARY-START(3879255)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates`, ($self) => class CommunityGroupChurchServiceStates extends $.$PZCj.LCCGCS$2.CommunityGroupServiceStates
        {
            //--TRIMMABLE-BOUNDARY-START(4298846551)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298846551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298846551)
            
            //--TRIMMABLE-BOUNDARY-START(4298846551)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4298846551)
            
            static $h = 3879255;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$2.CommunityGroupServiceStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298846551),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3879255,
      "h": 4298846551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298846551)
  ],
  "h": 3879255
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchServiceStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3879255)
        
        

        //--TRIMMABLE-BOUNDARY-START(3354967)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings`, ($self) => class CommunityGroupChurchServiceSettings extends $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4298322263)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298322263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298322263)
            
            //--TRIMMABLE-BOUNDARY-START(4298322263)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4298322263)
            
            static $h = 3354967;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298322263),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3354967,
      "h": 4298322263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298322263)
  ],
  "h": 3354967
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchServiceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3354967)
        
        

        //--TRIMMABLE-BOUNDARY-START(3486039)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptor`, ($self) => class CommunityGroupChurchServiceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298453335)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298453335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptor.GenerateProperties($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, this, factory);
                    }, $KQhmzb ??= {"r":65537,"n":"","d":3486039,"h":0,"f":17825794}), 0, "CommunityGroupChurchServiceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Settings_CommunityGroupChurchServiceSettings_LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupChurchServiceSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298453335)
            
            //--TRIMMABLE-BOUNDARY-START(12888387927)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888387927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888387927)
            
            //--TRIMMABLE-BOUNDARY-START(17183355223)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183355223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupServiceSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupServiceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupServiceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183355223)
            
            //--TRIMMABLE-BOUNDARY-START(8593420631)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593420631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593420631)
            
            static $h = 3486039;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888387927),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3486039,
      "h": 12888387927,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888387927),
//--TRIMMABLE-BOUNDARY-START(17183355223),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3354967,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3486039,
      "h": 17183355223,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183355223),
//--TRIMMABLE-BOUNDARY-START(8593420631),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3354967,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3486039,
      "h": 8593420631,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593420631)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298453335),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3486039,
      "h": 4298453335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298453335)
  ],
  "h": 3486039
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchServiceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3486039)
        
        

        //--TRIMMABLE-BOUNDARY-START(4010327)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptor`, ($self) => class CommunityGroupChurchServiceStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298977623)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298977623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptor.GenerateProperties($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, this, factory);
                    }, $DodhKi ??= {"r":65537,"n":"","d":4010327,"h":0,"f":17825794}), 0, "CommunityGroupChurchServiceStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\States_CommunityGroupChurchServiceStates_LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStatesTypeDescriptorBuilder.g.cs", "CommunityGroupChurchServiceStatesTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298977623)
            
            //--TRIMMABLE-BOUNDARY-START(12888912215)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888912215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888912215)
            
            //--TRIMMABLE-BOUNDARY-START(17183879511)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183879511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupServiceStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupServiceStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupServiceStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183879511)
            
            //--TRIMMABLE-BOUNDARY-START(8593944919)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593944919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593944919)
            
            static $h = 4010327;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888912215),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4010327,
      "h": 12888912215,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888912215),
//--TRIMMABLE-BOUNDARY-START(17183879511),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3879255,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4010327,
      "h": 17183879511,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183879511),
//--TRIMMABLE-BOUNDARY-START(8593944919),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3879255,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4010327,
      "h": 8593944919,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593944919)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298977623),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4010327,
      "h": 4298977623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298977623)
  ],
  "h": 4010327
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchServiceStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4010327)
        
        

        //--TRIMMABLE-BOUNDARY-START(3748183)
        $asm.$cls(`$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptor`, ($self) => class CommunityGroupChurchPostStatesTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4298715479)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298715479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptor.GenerateProperties($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates, this, factory);
                    }, $Aicenk ??= {"r":65537,"n":"","d":3748183,"h":0,"f":17825794}), 0, "CommunityGroupChurchPostStatesTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\States_CommunityGroupChurchPostStates_LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStatesTypeDescriptorBuilder.g.cs", "CommunityGroupChurchPostStatesTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298715479)
            
            //--TRIMMABLE-BOUNDARY-START(12888650071)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888650071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888650071)
            
            //--TRIMMABLE-BOUNDARY-START(17183617367)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStates*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183617367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.States.CommunityGroupPostStates?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$2.CommunityGroupPostStatesTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$2.CommunityGroupPostStates));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183617367)
            
            //--TRIMMABLE-BOUNDARY-START(8593682775)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStates?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593682775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStatesTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593682775)
            
            static $h = 3748183;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888650071),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3748183,
      "h": 12888650071,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888650071),
//--TRIMMABLE-BOUNDARY-START(17183617367),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3617111,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3748183,
      "h": 17183617367,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183617367),
//--TRIMMABLE-BOUNDARY-START(8593682775),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3617111,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3748183,
      "h": 8593682775,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593682775)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298715479),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3748183,
      "h": 4298715479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298715479)
  ],
  "h": 3748183
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStatesTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}States${separator}CommunityGroupChurchPostStatesTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3748183)
        
        

        //--TRIMMABLE-BOUNDARY-START(3223895)
        $asm.$cls(`$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptor`, ($self) => class CommunityGroupChurchPostSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298191191)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298191191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptor.GenerateProperties($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, this, factory);
                    }, $fKDFUh ??= {"r":65537,"n":"","d":3223895,"h":0,"f":17825794}), 0, "CommunityGroupChurchPostSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Settings_CommunityGroupChurchPostSettings_LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettingsTypeDescriptorBuilder.g.cs", "CommunityGroupChurchPostSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298191191)
            
            //--TRIMMABLE-BOUNDARY-START(12888125783)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888125783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888125783)
            
            //--TRIMMABLE-BOUNDARY-START(17183093079)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183093079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Settings.CommunityGroupPostSettings?*/ let targetBase = _target;
                $.$PZCj.LCCGCS$1.CommunityGroupPostSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCS$1.CommunityGroupPostSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183093079)
            
            //--TRIMMABLE-BOUNDARY-START(8593158487)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593158487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings().$ctor$5();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593158487)
            
            static $h = 3223895;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888125783),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3223895,
      "h": 12888125783,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888125783),
//--TRIMMABLE-BOUNDARY-START(17183093079),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3092823,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3223895,
      "h": 17183093079,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183093079),
//--TRIMMABLE-BOUNDARY-START(8593158487),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3092823,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3223895,
      "h": 8593158487,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593158487)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298191191),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3223895,
      "h": 4298191191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298191191)
  ],
  "h": 3223895
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Settings${separator}CommunityGroupChurchPostSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3223895)
        
        

        //--TRIMMABLE-BOUNDARY-START(405847)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBaseDataModel`, ($self) => class CommunityChurchBaseDataModel extends $.$LCOv.LCFCPM$1.ServiceDataBasePostModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295373143)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$7();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295373143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295373143)
            
            //--TRIMMABLE-BOUNDARY-START(4295373143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295373143)
            
            static $h = 405847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.ServiceDataBasePostModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295373143),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 405847,
      "h": 4295373143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295373143)
  ],
  "h": 405847
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBaseDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(405847)
        
        

        //--TRIMMABLE-BOUNDARY-START(667991)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBranchModel`, ($self) => class CommunityChurchBranchModel extends $.$yCMk.LCCCCM.CommunityChurchBaseDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(38655373655)
            /*PostTypes */ get Type()
            {
                return 2371/*PostTypes.GroupChurchBranch*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655373655)
            
            //--TRIMMABLE-BOUNDARY-START(8590602583)
            /*string? */ get Address()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180537175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "Address", null);
            }
            /*string? */ set Address(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360406359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Address");
            }
            //--TRIMMABLE-BOUNDARY-END(8590602583)
            
            //--TRIMMABLE-BOUNDARY-START(4295635287)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295635287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295635287)
            
            //--TRIMMABLE-BOUNDARY-START(4295635287)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295635287)
            
            static $h = 667991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yCMk.LCCCCM.CommunityChurchBaseDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655373655),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770471767,
        "f": 50364417
      },
      "n": "Type",
      "d": 667991,
      "h": 38655373655,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655373655),
//--TRIMMABLE-BOUNDARY-START(8590602583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180537175,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360406359,
        "f": 83886081
      },
      "n": "Address",
      "d": 667991,
      "h": 8590602583,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1024,
              "t": 655361
            },
            {
              "n": "Exclude",
              "v": 16777208,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590602583)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295635287),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 667991,
      "h": 4295635287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295635287)
  ],
  "h": 667991,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "ExcludeFilter",
          "v": 930135,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBranchModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(667991)
        
        

        //--TRIMMABLE-BOUNDARY-START(536919)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor`, ($self) => class CommunityChurchBaseDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBaseDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295504215)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295504215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchBaseDataModel, this, factory);
                    }, $oPlRRk ??= {"r":65537,"n":"","d":536919,"h":0,"f":17825794}), 0, "CommunityChurchBaseDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchBaseDataModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModelTypeDescriptorBuilder.g.cs", "CommunityChurchBaseDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295504215)
            
            //--TRIMMABLE-BOUNDARY-START(12885438807)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885438807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$LCOv.LCFCPM$1.ServiceDataBasePostModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885438807)
            
            //--TRIMMABLE-BOUNDARY-START(17180406103)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180406103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.ServiceDataBasePostModel?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.ServiceDataBasePostModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.ServiceDataBasePostModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180406103)
            
            //--TRIMMABLE-BOUNDARY-START(8590471511)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590471511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityChurchBaseDataModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590471511)
            
            static $h = 536919;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBaseDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885438807),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 536919,
      "h": 12885438807,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885438807),
//--TRIMMABLE-BOUNDARY-START(17180406103),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 405847,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 536919,
      "h": 17180406103,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180406103),
//--TRIMMABLE-BOUNDARY-START(8590471511),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 405847,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 536919,
      "h": 8590471511,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590471511)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295504215),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 536919,
      "h": 4295504215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295504215)
  ],
  "h": 536919
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBaseDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBaseDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(536919)
        
        

        //--TRIMMABLE-BOUNDARY-START(799063)
        $asm.$cls(`$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor`, ($self) => class CommunityChurchBranchModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBranchModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295766359)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295766359);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityChurchBranchModel, this, factory);
                    }, $EqbgOk ??= {"r":65537,"n":"","d":799063,"h":0,"f":17825794}), 0, "CommunityChurchBranchModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityChurchBranchModel_LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModelTypeDescriptorBuilder.g.cs", "CommunityChurchBranchModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295766359)
            
            //--TRIMMABLE-BOUNDARY-START(12885700951)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885700951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Address"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchBranchModel.$type, $.$discardRef(), "Address", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Address")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Address";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchBranchModel)).Address);
                        }, $uPHwYi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":799063,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Address = value.AsReference($.$$.S.String);
                        }, $uZOrne ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":799063,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityChurchBranchModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$yCMk.LCCCCM.CommunityChurchBranchModel)).Type);
                        }, $MQIpLg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":799063,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885700951)
            
            //--TRIMMABLE-BOUNDARY-START(17180668247)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180668247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Church.Common.Models.CommunityChurchBaseDataModel?*/ let targetBase = _target;
                $.$yCMk.LCCCCM.CommunityChurchBaseDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$yCMk.LCCCCM.CommunityChurchBaseDataModel));
                {
                    /*var*/ let _Address = _target.Address;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Address"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Address, ($v) => _Address = $v, $.$$.S.String)))
                    {
                        _target.Address = _Address;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180668247)
            
            //--TRIMMABLE-BOUNDARY-START(8590733655)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590733655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityChurchBranchModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityChurchBranchModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBranchModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityChurchBranchModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBranchModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityChurchBranchModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityChurchBranchModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590733655)
            
            static $h = 799063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBranchModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885700951),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 799063,
      "h": 12885700951,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885700951),
//--TRIMMABLE-BOUNDARY-START(17180668247),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 667991,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 799063,
      "h": 17180668247,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180668247),
//--TRIMMABLE-BOUNDARY-START(8590733655),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 667991,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 799063,
      "h": 8590733655,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590733655)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295766359),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 799063,
      "h": 4295766359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295766359)
  ],
  "h": 799063
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityChurchBranchModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityChurchBranchModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityChurchBranchModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(799063)
        
        

        //--TRIMMABLE-BOUNDARY-START(2371927)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchPostModel`, ($self) => class CommunityGroupChurchPostModel extends $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)
        {
            //--TRIMMABLE-BOUNDARY-START(42952044887)
            /*PostTypes */ get Type()
            {
                return 2307/*PostTypes.GroupChurch*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42952044887)
            
            //--TRIMMABLE-BOUNDARY-START(30067142999)
            /*string? */ get ServiceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887273815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, null, "ServiceId", null);
            }
            /*string? */ set ServiceId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657077591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "ServiceId");
            }
            //--TRIMMABLE-BOUNDARY-END(30067142999)
            
            //--TRIMMABLE-BOUNDARY-START(25772175703)
            /*CommunityChurchMemberFeatureModel */ GetMemberInfo(/*AccountModel*/ account)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772175703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$yCMk.LCCCCM.CommunityChurchMemberFeatureModel, account, `Church/${$.$strNN($.$dspc(this.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/MemberInfo`, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25772175703)
            
            //--TRIMMABLE-BOUNDARY-START(8593664436)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostServiceAccountModel.ServiceId.get
            get LCFCP$IPostServiceAccountModel$ServiceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888631732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceId;
            }
            //--TRIMMABLE-BOUNDARY-END(8593664436)
            
            //--TRIMMABLE-BOUNDARY-START(21478566324)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.IPostServiceAccountModel.ServiceId.set
            set LCFCP$IPostServiceAccountModel$ServiceId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888631732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ServiceId = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21478566324)
            
            //--TRIMMABLE-BOUNDARY-START(4297339223)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297339223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297339223)
            
            //--TRIMMABLE-BOUNDARY-START(4297339223)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4297339223)
            
            static $h = 2371927;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952044887),
    {
      "p": 21096884,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477208407,
        "f": 50364417
      },
      "n": "Type",
      "d": 2371927,
      "h": 42952044887,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42952044887),
//--TRIMMABLE-BOUNDARY-START(30067142999),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887273815,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38657077591,
        "f": 83886081
      },
      "n": "ServiceId",
      "d": 2371927,
      "h": 30067142999,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067142999)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772175703),
    {
      "r": 1782103,
      "p": [
        {
          "n": "account",
          "p": 7858612
        }
      ],
      "n": "GetMemberInfo",
      "d": 2371927,
      "h": 25772175703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772175703)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297339223),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 2371927,
      "h": 4297339223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297339223)
  ],
  "h": 2371927,
  "a": [
    {
      "t": $.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).$h,
      "c": Number(BigInt($.$Iaui.LCFCM.DataBaseAttributeSpecificationAttribute$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).$h)|0x100000000n)
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataValidator, $.$fPer.LCFCD.IDataDescriptorValidator, $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD$1.IPropertyDescriptorModifier, $.$fPer.LCFCD.IOpenGraphDataProvider, $.$vWqU.LCFCD.ISEODataProvider, $.$LCOv.LCFCP.IPostSubscribable, $.$LCOv.LCFCP.IPostRatable, $.$YUlm.LCSCM.IShipmentAccount, $.$Iaui.LCFCM.IApplicationAccountModel, $.$LCOv.LCFCP.IPostNamedLocation, $.$PZCj.LCCGCM.ICommunityGroupModel, $.$LCOv.LCFCP.IPostReplyable, $.$LCOv.LCFCP.IPostReactable, $.$LCOv.LCFCP.IPostSharable, $.$LCOv.LCFCP.IPostViewTrackable, $.$LCOv.LCFCP.IPostApplicationScope, $.$LCOv.LCFCP.IGroupAccountModel, $.$LCOv.LCFCP.IPostServiceAccountModel, $.$LCOv.LCFCP.IUserAccountModel, $.$LCOv.LCFCP.IPost, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchPostModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2371927)
        
        

        //--TRIMMABLE-BOUNDARY-START(4206935)
        $asm.$cls(`$yCMk.LCFCR.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking`, ($self) => class ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4299174231)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299174231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299174231)
            
            //--TRIMMABLE-BOUNDARY-START(8594141527)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchPostModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594141527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8594141527)
            
            //--TRIMMABLE-BOUNDARY-START(17184076119)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchPostModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184076119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17184076119)
            
            //--TRIMMABLE-BOUNDARY-START(21479043415)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchPostModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479043415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21479043415)
            
            //--TRIMMABLE-BOUNDARY-START(25774010711)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchPostModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774010711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25774010711)
            
            //--TRIMMABLE-BOUNDARY-START(12889108823)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889108823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12889108823)
            
            static $h = 4206935;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299174231),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4206935,
      "h": 4299174231,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4299174231)
  ],
  "h": 4206935
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.IReadDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService_CommunityGroupChurchPostModel_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4206935)
        
        

        //--TRIMMABLE-BOUNDARY-START(2634071)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchServiceModel`, ($self) => class CommunityGroupChurchServiceModel extends $.$Iaui.LCFCM.ServiceModel$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates)
        {
            //--TRIMMABLE-BOUNDARY-START(30067405143)
            /*DataId*/ GroupAccountId;
            //--TRIMMABLE-BOUNDARY-END(30067405143)
            
            //--TRIMMABLE-BOUNDARY-START(34362372439)
            /*string? */ get ServiceLink()
            {
                return `/Church/${$.$strNN(this.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34362372439)
            
            //--TRIMMABLE-BOUNDARY-START(8592568663)
            //default constructor overload
            $ctor$9()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592568663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592568663)
            
            //--TRIMMABLE-BOUNDARY-START(8592568663)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8592568663)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30067405143)
                this.GroupAccountId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(30067405143)
                
            }
            static $h = 2634071;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ServiceModel$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067405143),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182503255,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952307031,
        "f": 83886081
      },
      "n": "GroupAccountId",
      "d": 2634071,
      "h": 30067405143,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067405143),
//--TRIMMABLE-BOUNDARY-START(34362372439),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772437847,
        "f": 50364417
      },
      "n": "ServiceLink",
      "d": 2634071,
      "h": 34362372439,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362372439)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592568663),
    {
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 2634071,
      "h": 8592568663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592568663)
  ],
  "h": 2634071
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$yCMk.LCCCCM.CommunityChurchServiceTier), $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2634071)
        
        

        //--TRIMMABLE-BOUNDARY-START(2961751)
        $asm.$cls(`$yCMk.LCCCCS.ICommunityChurchRemoteService`, ($self) => class ICommunityChurchRemoteService
        {
            static $h = 2961751;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297929047),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetDashboard",
      "o": "LCCCCS$ICommunityChurchRemoteService$GetDashboard",
      "d": 2961751,
      "h": 4297929047,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297929047)
  ],
  "h": 2961751,
  "a": [
    {
      "t": 3537875,
      "c": 8593472467,
      "a": [
        {
          "v": [$.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel).$h
          ],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Services.ICommunityChurchRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Services${separator}ICommunityChurchRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2961751)
        
        

        //--TRIMMABLE-BOUNDARY-START(2502999)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor`, ($self) => class CommunityGroupChurchPostModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297470295)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297470295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityGroupChurchPostModel, this, factory);
                    }, $lADUyf ??= {"r":65537,"n":"","d":2502999,"h":0,"f":17825794}), 0, "CommunityGroupChurchPostModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityGroupChurchPostModel_LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModelTypeDescriptorBuilder.g.cs", "CommunityGroupChurchPostModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297470295)
            
            //--TRIMMABLE-BOUNDARY-START(12887404887)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887404887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.PostTypes, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$LCOv.LCFCPM$1.PostTypes, ($.$cast(target, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel)).Type);
                        }, $SjyIfe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2502999,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel.$type, $.$discardRef(), "ServiceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceId";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel)).ServiceId);
                        }, $fukBPf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2502999,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceId = value.AsReference($.$$.S.String);
                        }, $HfGFWi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2502999,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887404887)
            
            //--TRIMMABLE-BOUNDARY-START(17182372183)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182372183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Community.Group.Common.Models.CommunityGroupBasePostModel<LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchPostSettings, LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchPostStates>?*/ let targetBase = _target;
                $.$PZCj.LCCGCM.CommunityGroupBasePostModelTypeDescriptor$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$PZCj.LCCGCM.CommunityGroupBasePostModel$$$($.$yCMk.LCCCCS$1.CommunityGroupChurchPostSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchPostStates)));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.PostTypes));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.PostTypes, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _ServiceId = _target.ServiceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceId, ($v) => _ServiceId = $v, $.$$.S.String)))
                    {
                        _target.ServiceId = _ServiceId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182372183)
            
            //--TRIMMABLE-BOUNDARY-START(8592437591)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592437591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityGroupChurchPostModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityGroupChurchPostModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchPostModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592437591)
            
            static $h = 2502999;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887404887),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2502999,
      "h": 12887404887,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887404887),
//--TRIMMABLE-BOUNDARY-START(17182372183),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2371927,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2502999,
      "h": 17182372183,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182372183),
//--TRIMMABLE-BOUNDARY-START(8592437591),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2371927,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2502999,
      "h": 8592437591,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592437591)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297470295),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2502999,
      "h": 4297470295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297470295)
  ],
  "h": 2502999
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchPostModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchPostModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchPostModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2502999)
        
        

        //--TRIMMABLE-BOUNDARY-START(3027287)
        $asm.$cls(`$yCMk.LCCCCS.ICommunityChurchRemoteService_Mocking`, ($self) => class ICommunityChurchRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297994583)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297994583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297994583)
            
            //--TRIMMABLE-BOUNDARY-START(8592961879)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchDashboardModel>> */ LCCCCS$ICommunityChurchRemoteService$GetDashboard(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592961879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$yCMk.LCCCCS.ICommunityChurchRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel).$type;
                    $i1.MethodName = "GetDashboard";
                    return $i1;
                })();
                return this.InvokeAsync($.$yCMk.LCCCCS.ICommunityChurchRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityChurchDashboardModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592961879)
            
            //--TRIMMABLE-BOUNDARY-START(12887929175)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Models.UserServiceSubscriptionModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel>>> */ LCFCCR$ISubscriptionBasedRemoteService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchServiceModel$LoadServices(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887929175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)).$type;
                    $i2.MethodName = "LoadServices";
                    return $i2;
                })();
                return this.InvokeAsync($.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887929175)
            
            //--TRIMMABLE-BOUNDARY-START(17182896471)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchServiceModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182896471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i3.MethodName = "Create";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182896471)
            
            //--TRIMMABLE-BOUNDARY-START(25772831063)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchServiceModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772831063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i4.MethodName = "ReadMany";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25772831063)
            
            //--TRIMMABLE-BOUNDARY-START(30067798359)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchServiceModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067798359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i5.MethodName = "ReadSingle";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30067798359)
            
            //--TRIMMABLE-BOUNDARY-START(34362765655)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Community$Church$Common$Models$CommunityGroupChurchServiceModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362765655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i6.MethodName = "Update";
                    return $i6;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34362765655)
            
            //--TRIMMABLE-BOUNDARY-START(21477863767)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477863767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i7.MethodName = "Delete";
                    return $i7;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21477863767)
            
            static $h = 3027287;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297994583),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3027287,
      "h": 4297994583,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297994583)
  ],
  "h": 3027287
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$yCMk.LCCCCS.ICommunityChurchRemoteService, $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Services.ICommunityChurchRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Services${separator}ICommunityChurchRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3027287)
        
        

        //--TRIMMABLE-BOUNDARY-START(2765143)
        $asm.$cls(`$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor`, ($self) => class CommunityGroupChurchServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297732439)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297732439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor.GenerateProperties($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, this, factory);
                    }, $yxTnSg ??= {"r":65537,"n":"","d":2765143,"h":0,"f":17825794}), 0, "CommunityGroupChurchServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Church.Common\\Models_CommunityGroupChurchServiceModel_LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModelTypeDescriptorBuilder.g.cs", "CommunityGroupChurchServiceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297732439)
            
            //--TRIMMABLE-BOUNDARY-START(12887667031)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887667031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GroupAccountId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, $.$discardRef(), "GroupAccountId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GroupAccountId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "GroupAccountId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)).GroupAccountId);
                        }, $lnslpc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2765143,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GroupAccountId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $LgxPCi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2765143,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel.$type, $.$discardRef(), "ServiceLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceLink";
                        $i3.DelaredOn = "LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)).ServiceLink);
                        }, $WPYdUe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2765143,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887667031)
            
            //--TRIMMABLE-BOUNDARY-START(17182634327)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182634327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.ServiceModel<LivingThing.Core.Community.Church.Common.Models.CommunityChurchServiceTier, LivingThing.Core.Community.Church.Common.Settings.CommunityGroupChurchServiceSettings, LivingThing.Core.Community.Church.Common.States.CommunityGroupChurchServiceStates>?*/ let targetBase = _target;
                $.$Iaui.LCFCM.ServiceModelTypeDescriptor$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.ServiceModel$$$$($.$yCMk.LCCCCM.CommunityChurchServiceTier, $.$yCMk.LCCCCS$1.CommunityGroupChurchServiceSettings, $.$yCMk.LCCCCS$2.CommunityGroupChurchServiceStates)));
                {
                    /*var*/ let _GroupAccountId = _target.GroupAccountId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GroupAccountId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _GroupAccountId, ($v) => _GroupAccountId = $v, null, true)))
                    {
                        _target.GroupAccountId = $.$clone(_GroupAccountId);
                    }
                }
                {
                    /*var*/ let _ServiceLink = _target.ServiceLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceLink, ($v) => _ServiceLink = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182634327)
            
            //--TRIMMABLE-BOUNDARY-START(8592699735)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592699735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel().$ctor$9();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel)))
                {
                    /*var*/ let result = $.$yCMk.LCCCCM.CommunityGroupChurchServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$yCMk.LCCCCM.CommunityGroupChurchServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592699735)
            
            static $h = 2765143;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887667031),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2765143,
      "h": 12887667031,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887667031),
//--TRIMMABLE-BOUNDARY-START(17182634327),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2634071,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2765143,
      "h": 17182634327,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182634327),
//--TRIMMABLE-BOUNDARY-START(8592699735),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2634071,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2765143,
      "h": 8592699735,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592699735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297732439),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2765143,
      "h": 4297732439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297732439)
  ],
  "h": 2765143
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yCMk.LCCCCM.CommunityGroupChurchServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Church.Common.Models.CommunityGroupChurchServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Church${separator}Common${separator}Models${separator}CommunityGroupChurchServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2765143)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Group.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(12631)
