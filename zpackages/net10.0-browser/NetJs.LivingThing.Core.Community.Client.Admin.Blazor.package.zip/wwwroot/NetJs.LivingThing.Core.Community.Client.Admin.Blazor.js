
//--TRIMMABLE-BOUNDARY-START(38822)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc) {
    "use strict";
    let _;
    let $tCxLFf;
    let $YToiNd;
    let $HZZQxf;
    let $XLuxrf;
    let $zDTmMf;
    let $RZLiza;
    let $aLSxBk;
    let $QlCSWa;
    let $jPzKsh;
    let $qhQioj;
    let $nrPQei;
    let $IAtRkk;
    let $Osomnb;
    let $hWYSXc;
    let $PkMOMf;
    let $tiizkd;
    let $NKzzDd;
    let $rDzJhe;
    let $UdcYje;
    let $UepDQc;
    let $clKuig;
    let $PDvbii;
    let $BVpADb;
    let $EZzdwd;
    let $kfWDIf;
    let $ImXnyf;
    let $CMDSoc;
    let $OskAHf;
    let $heIdsk;
    let $VTEkva;
    let $EEbtId;
    let $IKiLxk;
    let $MbnVBc;
    let $qpqlfg;
    let $TTpHPa;
    let $tYyZVc;
    let $CYDKDi;
    let $knYyhd;
    let $hDARMd;
    let $FgcGLg;
    let $itEjMh;
    let $zMFSsa;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Client.Admin.Blazor", 
    {
  "h": 38822,
  "f": "LivingThing.Core.Community.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(432038)
        $asm.$cls(`$Bnua.LCCCA.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590366630)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590366630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$Bnua.LCCCAP.Admin, "LivingThing.Core.Community.Client.Admin", "Pages\\Admin", "Admin", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Admin/Community", "/Admin/Community/{*Page}" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590366630)
            
            //--TRIMMABLE-BOUNDARY-START(4295399334)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295399334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295399334)
            
            //--TRIMMABLE-BOUNDARY-START(4295399334)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295399334)
            
            static $h = 432038;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590366630),
    {
      "r": 65537,
      "n": "Build",
      "d": 432038,
      "h": 8590366630,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590366630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295399334),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 432038,
      "h": 4295399334,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295399334)
  ],
  "h": 432038
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(432038)
        
        

        //--TRIMMABLE-BOUNDARY-START(300966)
        $asm.$cls(`$Bnua.LCCCA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295268262)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295268262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Bnua.LCCCA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295268262)
            
            static $h = 300966;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295268262),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 300966,
      "h": 4295268262,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295268262)
  ],
  "h": 300966
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(300966)
        
        

        //--TRIMMABLE-BOUNDARY-START(104358)
        $asm.$cls(`$Bnua._LCCCAPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295071654)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295071654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295071654)
            
            static $h = 104358;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295071654),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 104358,
      "h": 4295071654,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295071654)
  ],
  "h": 104358
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Client.Admin.Pages.Admin.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}Pages${separator}Admin${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(104358)
        
        

        //--TRIMMABLE-BOUNDARY-START(169894)
        $asm.$cls(`$Bnua._LCCCASC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295137190)
            static /*void */ CreateInputEditor_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::LivingThing.Core.Frameworks.Common.Theme*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295137190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCI$1.InputEditor$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Theme", $.$clone(__arg0));
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295137190)
            
            static $h = 169894;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295137190),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 65309014
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateInputEditor_0",
      "d": 169894,
      "h": 4295137190,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295137190)
  ],
  "h": 169894
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Client.Admin.Shared.CommunityAdminBanners.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}Shared${separator}CommunityAdminBanners${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(169894)
        
        

        //--TRIMMABLE-BOUNDARY-START(366502)
        $asm.$cls(`$Bnua.LCCCA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180235686)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Bnua.LCCCAP.Admin.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Bnua.LCCCAP.Admin().$ctor$3();
                    }, $tCxLFf ??= {"r":2752627,"n":"","d":366502,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Bnua.LCCCAS.CommunityAdminBanners.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Bnua.LCCCAS.CommunityAdminBanners().$ctor$3();
                    }, $YToiNd ??= {"r":2752627,"n":"","d":366502,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180235686)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295333798)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295333798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295333798)
            
            //--TRIMMABLE-BOUNDARY-START(4295333798)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295333798)
            
            static $h = 366502;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180235686),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885268390,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 366502,
      "h": 17180235686,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180235686)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295333798),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 366502,
      "h": 4295333798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295333798)
  ],
  "h": 366502
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(366502)
        
        

        //--TRIMMABLE-BOUNDARY-START(694182)
        $asm.$cls(`$Bnua.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295661478)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295661478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295661478)
            
            //--TRIMMABLE-BOUNDARY-START(4295661478)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295661478)
            
            static $h = 694182;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295661478),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 694182,
      "h": 4295661478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295661478)
  ],
  "h": 694182,
  "a": [
    {
      "t": 628646,
      "c": 4295595942
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(694182)
        
        

        //--TRIMMABLE-BOUNDARY-START(628646)
        $asm.$cls(`$Bnua.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295595942)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295595942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295595942)
            
            //--TRIMMABLE-BOUNDARY-START(4295595942)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295595942)
            
            static $h = 628646;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295595942),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 628646,
      "h": 4295595942,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295595942)
  ],
  "h": 628646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(628646)
        
        

        //--TRIMMABLE-BOUNDARY-START(235430)
        $asm.$cls(`$Bnua.LCCCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590170022)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590170022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590170022)
            
            //--TRIMMABLE-BOUNDARY-START(4295202726)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295202726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295202726)
            
            //--TRIMMABLE-BOUNDARY-START(4295202726)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295202726)
            
            static $h = 235430;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590170022),
    {
      "r": 65537,
      "n": "Execute",
      "d": 235430,
      "h": 8590170022,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590170022)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295202726),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 235430,
      "h": 4295202726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295202726)
  ],
  "h": 235430
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(235430)
        
        

        //--TRIMMABLE-BOUNDARY-START(497574)
        $asm.$cls(`$Bnua.LCCCAP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(115964614566)
            /*string?*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(115964614566)
            
            //--TRIMMABLE-BOUNDARY-START(133144483750)
            /*CommunityRootService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(133144483750)
            
            //--TRIMMABLE-BOUNDARY-START(107374679974)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(107374679974)
            
            //--TRIMMABLE-BOUNDARY-START(103079712678)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079712678)
            
            //--TRIMMABLE-BOUNDARY-START(120259581862)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(120259581862)
            
            //--TRIMMABLE-BOUNDARY-START(120259581862)
            //--TRIMMABLE-BOUNDARY-START(30065268646)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065268646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065268646)
            
            //--TRIMMABLE-BOUNDARY-START(128849516454)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849516454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(128849516454)
            
            //--TRIMMABLE-BOUNDARY-END(120259581862)
            
            //--TRIMMABLE-BOUNDARY-START(38655203238)
            /*bool */ FilterProperties(/*IPropertyDescriptor*/ property, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655203238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(38655203238)
            
            //--TRIMMABLE-BOUNDARY-START(85899843494)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ prefered)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899843494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return prefered;
            }
            //--TRIMMABLE-BOUNDARY-END(85899843494)
            
            //--TRIMMABLE-BOUNDARY-START(90194810790)
            /*ValueTask<object> */ GetPropertyValue(/*IObservableDataDescriptor*/ target, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194810790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90194810790)
            
            //--TRIMMABLE-BOUNDARY-START(98784745382)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784745382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98784745382)
            
            //--TRIMMABLE-BOUNDARY-START(111669647270)
            /*string */ get OptimizedComponentName()
            {
                return "admin";
            }
            //--TRIMMABLE-BOUNDARY-END(111669647270)
            
            //--TRIMMABLE-BOUNDARY-START(171799189414)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799189414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Page":
                    this.Page = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(171799189414)
            
            //--TRIMMABLE-BOUNDARY-START(94489778086)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489778086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ahDc.LCCCS.CommunityRootService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(94489778086)
            
            //--TRIMMABLE-BOUNDARY-START(34360235942)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360235942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    $.$Bnua._LCCCAPA.TypeInference.CreateCascadingValue_0($.$Bnua.LCCCAP.Admin, __builder2, 4, 5, this, 6, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.Application, 7);
                        __builder3.AddComponentParameter(8, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Admin/Community")));
                        __builder3.AddComponentParameter(9, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                        __builder3.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                        __builder3.AddAttribute$3(11, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(12, "<i class=\"mdi mdi-package cl-error\"></i>");
                            }, $HZZQxf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                        }), $XLuxrf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 14);
                            __builder4.AddComponentParameter(15, "Name", "");
                            __builder4.AddComponentParameter(16, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder4.AddComponentParameter(17, "Class", "pd");
                            __builder4.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(19, "Dashboard");
                                }, $zDTmMf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $RZLiza ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(21, "<i class=\"mdi mdi-package\"></i>");
                                }, $aLSxBk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $QlCSWa ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                }, $jPzKsh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $qhQioj ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(23, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 24);
                            __builder4.AddComponentParameter(25, "Name", "Categories");
                            __builder4.AddComponentParameter(26, "Class", "pd");
                            __builder4.AddAttribute$3(27, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(28, "Categories");
                                }, $nrPQei ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $IAtRkk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(29, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(30, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $Osomnb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $hWYSXc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$LCOv.LCFCPMC.CategoryPostModel), 32);
                                    __builder5.AddComponentParameter(33, "ItemName", "Category");
                                    __builder5.AddComponentParameter(34, "Provider", "this");
                                    __builder5.AddAttribute$3(35, "GridView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$2.GridViewContext$$($.$LCOv.LCFCPMC.CategoryPostModel)))().$ctor(this, ( (/*category*/ category) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder6*/ __builder6) =>
                                        {
                                        }, $PkMOMf ??= {"r":65537,"p":[{"n":"__builder6","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                                    }), $tiizkd ??= {"r":6881395,"p":[{"n":"category","p":$.$hDPm.LCFCCD$2.GridViewContext$$($.$LCOv.LCFCPMC.CategoryPostModel).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                                    __builder5.CloseComponent();
                                }, $NKzzDd ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":497574,"h":0,"f":17825794});
                            }), $rDzJhe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":497574,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $UdcYje ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":497574,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }, $UepDQc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":497574,"h":0,"f":17825794}));
                }), $clKuig ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":497574,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34360235942)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475334054)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475334054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475334054)
            
            //--TRIMMABLE-BOUNDARY-START(21475334054)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475334054)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133144483750)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(133144483750)
                
                //--TRIMMABLE-BOUNDARY-START(107374679974)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(107374679974)
                
            }
            static $h = 497574;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964614566),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014941606,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914287526,
        "f": 83886081
      },
      "n": "Page",
      "d": 497574,
      "h": 115964614566,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964614566),
//--TRIMMABLE-BOUNDARY-START(133144483750),
    {
      "p": 16487872,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604876198,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504222118,
        "f": 83886081
      },
      "n": "Service",
      "d": 497574,
      "h": 133144483750,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144483750),
//--TRIMMABLE-BOUNDARY-START(107374679974),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835072422,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324352934,
        "f": 83886081
      },
      "n": "Loading",
      "d": 497574,
      "h": 107374679974,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374679974),
//--TRIMMABLE-BOUNDARY-START(103079712678),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245137830,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734418342,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 497574,
      "h": 103079712678,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079712678),
//--TRIMMABLE-BOUNDARY-START(111669647270),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425007014,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 497574,
      "h": 111669647270,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111669647270)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655203238),
    {
      "r": 262145,
      "p": [
        {
          "n": "property",
          "p": 40733014
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "n": "FilterProperties",
      "d": 497574,
      "h": 38655203238,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655203238),
//--TRIMMABLE-BOUNDARY-START(85899843494),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "prefered",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 497574,
      "h": 85899843494,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(85899843494),
//--TRIMMABLE-BOUNDARY-START(90194810790),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "GetPropertyValue",
      "d": 497574,
      "h": 90194810790,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194810790),
//--TRIMMABLE-BOUNDARY-START(98784745382),
    {
      "r": 181338113,
      "n": "Load",
      "d": 497574,
      "h": 98784745382,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784745382),
//--TRIMMABLE-BOUNDARY-START(171799189414),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 497574,
      "h": 171799189414,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799189414),
//--TRIMMABLE-BOUNDARY-START(94489778086),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 497574,
      "h": 94489778086,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489778086),
//--TRIMMABLE-BOUNDARY-START(34360235942),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 497574,
      "h": 34360235942,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360235942)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475334054),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 497574,
      "h": 21475334054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475334054)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(120259581862),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 497574,
        "h": 30065268646,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 497574,
        "h": 128849516454,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 497574,
      "h": 120259581862,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(120259581862)
  ],
  "h": 497574,
  "a": [
    {
      "t": 917616,
      "c": 17180786800,
      "n": [
        {
          "n": "Roles",
          "v": "SuperAdmin",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Community",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Community/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(497574)
        
        

        //--TRIMMABLE-BOUNDARY-START(563110)
        $asm.$cls(`$Bnua.LCCCAS.CommunityAdminBanners`, ($self) => class CommunityAdminBanners extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(73015007142)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(73015007142)
            
            //--TRIMMABLE-BOUNDARY-START(94489843622)
            /*string*/ Tag = null;
            //--TRIMMABLE-BOUNDARY-END(94489843622)
            
            //--TRIMMABLE-BOUNDARY-START(21475399590)
            /*BannerPostModel?*/ banner = null;
            //--TRIMMABLE-BOUNDARY-END(21475399590)
            
            //--TRIMMABLE-BOUNDARY-START(25770366886)
            /*RemoteDataTable<BannerPostModel>?*/ banners = null;
            //--TRIMMABLE-BOUNDARY-END(25770366886)
            
            //--TRIMMABLE-BOUNDARY-START(17180432294)
            /*Task *//*async*/  AddBanner(/*BannerPostModel*/ _banner)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180432294);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _banner.Tags = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$Iaui.LCFCM.TagModel), [(() =>
                    {
                        //new $.$Iaui.LCFCM.TagModel()
                        const $t1 = $.$Iaui.LCFCM.TagModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = this.Tag;
                        return $i1;
                    })()], null, null);
                    _banner = $.$sl.SL.Enumerable.First$1($.$LCOv.LCFCPM$1.BannerPostModel, (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$LCOv.LCFCPM$1.BannerPostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.BannerPostModel), [ _banner ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable());
                    ($t3 = this.banners.Prepend$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.BannerPostModel), [ _banner ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.banner = new $.$LCOv.LCFCPM$1.BannerPostModel().$ctor$7();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180432294)
            
            //--TRIMMABLE-BOUNDARY-START(68720039846)
            /*string */ get OptimizedComponentName()
            {
                return "communityadminbanners";
            }
            //--TRIMMABLE-BOUNDARY-END(68720039846)
            
            //--TRIMMABLE-BOUNDARY-START(98784810918)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784810918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "Tag":
                    this.Tag = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(98784810918)
            
            //--TRIMMABLE-BOUNDARY-START(64425072550)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425072550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(64425072550)
            
            //--TRIMMABLE-BOUNDARY-START(30065334182)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065334182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$macw.MACF.EditForm, 0);
                __builder.AddComponentParameter(1, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this));
                __builder.AddComponentParameter(2, "class", "bg-card");
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$macf.MACF.EditContext))().$ctor(this, ( (/*___*/ ___) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$mac.MAC.CascadingValue$$($.$hDPm.LCFCI.IViewProvider$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel))), 4);
                        __builder2.AddComponentParameter(5, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCI.IViewProvider$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)), this));
                        __builder2.AddComponentParameter(6, "IsFixed", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$2.RemoteDataTable$$($.$LCOv.LCFCPM$1.BannerPostModel), 8);
                            __builder3.AddComponentParameter(9, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8n | 8388608n | 8192n | 256n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(10, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 200), $.$$.S.Int32));
                            __builder3.AddComponentParameter(11, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 10), $.$$.S.Int32));
                            __builder3.AddComponentParameter(12, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$19(this.Tag, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741845/*PostFilterTypes.Tag*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null))));
                            __builder3.AddComponentParameter(13, "resources-td-class", "mawx-3 clip");
                            __builder3.AddAttribute$3(14, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.BannerPostModel))))().$ctor(this, ( (/*banner*/ banner) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumnsFromSchema$$($.$LCOv.LCFCPM$1.BannerPostModel), 15);
                                    __builder4.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures, 0/*DataTableColumnsFromSchemaFeatures.Default*/ | 1/*DataTableColumnsFromSchemaFeatures.Editable*/ | 2/*DataTableColumnsFromSchemaFeatures.ServerUpdate*/), $.$hDPm.LCFCCD$2.DataTableColumnsFromSchemaFeatures));
                                    __builder4.AddComponentParameter(17, "FilterProperty", new $.$fPer.LCFCD$1.PropertyDescriptorFilter().$ctor(this, ( (/*s*/ s, /*p*/ p) =>
                                    {
                                        return p.LCFCD$1$IPropertyDescriptor$Name !== "Category";
                                    }), $PDvbii ??= {"r":262145,"p":[{"n":"s","p":2394454},{"n":"p","p":40733014}],"n":"","d":563110,"h":0,"f":17825794}));
                                    __builder4.AddComponentParameter(18, "resources-editable-class", "nowrap miwx-3");
                                    __builder4.CloseComponent();
                                    __builder4.AddMarkupContent(19, "\r\n            ");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.BannerPostModel), 20);
                                    __builder4.AddComponentParameter(21, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2147483647/*int.MaxValue*/), $.$$.S.Int32));
                                    __builder4.AddAttribute$3(22, "Header", new ($.$mac.MAC.RenderFragment$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.BannerPostModel)))().$ctor(this, ( (/*__*/ __) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            __builder5.AddContent$4(23, "Featured");
                                        }, $BVpADb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
                                    }), $EZzdwd ??= {"r":6881395,"p":[{"n":"__","p":$.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.BannerPostModel).$h}],"n":"","d":563110,"h":0,"f":17825794}));
                                    __builder4.AddAttribute$3(24, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.BannerPostModel))))().$ctor(this, ( (/*item*/ item) =>
                                    {
                                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                        {
                                            /*var*/ let binder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.Boolean))().$ctor$7(((item.Data.PostFlags & (1n)) == (1n)), new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                                            {
                                                item.Data.PostFlags ^= 1n;
                                                _ = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.BannerPostModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.BannerPostModel), [ item.Data ], null, null));
                                            }, $kfWDIf ??= {"r":65537,"p":[{"n":"v","p":262145}],"n":"","d":563110,"h":0,"f":17825794}));
                                            $.$Bnua._LCCCASC.TypeInference.CreateInputEditor_0($.$$.S.Boolean, __builder5, 25, 26, $.$fPer.LCFC.Theme.Primary, 27, binder.Value, 28, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                                            {
                                                return binder.Value = __value;
                                            }, $ImXnyf ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":563110,"h":0,"f":17825794}), binder.Value)), 29, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                            {
                                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(binder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                            }, $CMDSoc ??= {"r":38797349,"n":"","d":563110,"h":0,"f":17825794})).Invoke()));
                                        }, $OskAHf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
                                    }), $heIdsk ??= {"r":6881395,"p":[{"n":"item","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.BannerPostModel)).$h}],"n":"","d":563110,"h":0,"f":17825794}));
                                    __builder4.CloseComponent();
                                }, $VTEkva ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
                            }), $EEbtId ??= {"r":6881395,"p":[{"n":"banner","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$LCOv.LCFCPM$1.BannerPostModel)).$h}],"n":"","d":563110,"h":0,"f":17825794}));
                            __builder3.AddComponentReferenceCapture(30, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                            {
                                this.banners = $.$cast(__value, $.$hDPm.LCFCCD$2.RemoteDataTable$$($.$LCOv.LCFCPM$1.BannerPostModel));
                            }, $IKiLxk ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":563110,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $MbnVBc ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":563110,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $qpqlfg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
                }), $TTpHPa ??= {"r":6881395,"p":[{"n":"___","p":131188}],"n":"","d":563110,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(31, "\r\n");
                __builder.AddMarkupContent(32, "<h2>Add Banner</h2>\r\n");
                __builder.OpenElement(33, "div");
                __builder.AddAttribute$5(34, "class", "bg-card corner-2 bd pd");
                __builder.OpenComponent$1($.$hDPm.LCFCCF$2.FormBuilder$$($.$LCOv.LCFCPM$1.BannerPostModel), 35);
                __builder.AddComponentParameter(36, "OnSubmit", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$LCOv.LCFCPM$1.BannerPostModel), $.$mac.MAC.EventCallback.Factory.Create$10($.$LCOv.LCFCPM$1.BannerPostModel, this, new ($.$$.S.Func$$$($.$LCOv.LCFCPM$1.BannerPostModel, $.$$.STT.Task))().$ctor(this, this.AddBanner))));
                __builder.AddComponentParameter(37, "Model", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.BannerPostModel, this.banner));
                __builder.AddComponentParameter(38, "ModelChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$LCOv.LCFCPM$1.BannerPostModel), $.$mac.MAC.EventCallback.Factory.Create$6($.$LCOv.LCFCPM$1.BannerPostModel, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$LCOv.LCFCPM$1.BannerPostModel, this, new ($.$$.S.Action$$($.$LCOv.LCFCPM$1.BannerPostModel))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.banner = __value;
                }, $tYyZVc ??= {"r":65537,"p":[{"n":"__value","p":10086836}],"n":"","d":563110,"h":0,"f":17825794}), this.banner))));
                __builder.AddComponentParameter(39, "ModelExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$LCOv.LCFCPM$1.BannerPostModel)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "banner"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $CYDKDi ??= {"r":38797349,"n":"","d":563110,"h":0,"f":17825794})).Invoke())));
                __builder.AddAttribute$3(40, "Submit", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 41);
                    __builder2.AddComponentParameter(42, "type", "submit");
                    __builder2.AddComponentParameter(43, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                    __builder2.AddComponentParameter(44, "Class", "mgt");
                    __builder2.AddAttribute$3(45, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.AddContent$4(46, "Create Banner");
                    }), $knYyhd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":563110,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $hDARMd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":563110,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(30065334182)
            
            //--TRIMMABLE-BOUNDARY-START(60130105254)
            /*RenderFragment */ GetView(/*ContainerContext<IEnumerable<ResourceModel>>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130105254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(47, "div");
                    __builder2.AddAttribute$5(48, "class", "wx-3");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$Iaui.LCFCM.ResourceModel), 49);
                    __builder2.AddComponentParameter(50, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel), value.Data));
                    __builder2.AddComponentParameter(51, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(52, "li-class", "hx-1 wx-2 mg-1 shadow bg-card corner");
                    __builder2.AddAttribute$3(53, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.ResourceModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.ResourceModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 54);
                            __builder3.AddComponentParameter(55, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 3/*MediaFeatures.Responsive*/ | 4/*MediaFeatures.Background*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                            __builder3.AddComponentParameter(56, "Source", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, context.Data));
                            __builder3.AddComponentParameter(57, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                            __builder3.CloseComponent();
                        }, $FgcGLg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
                    }), $itEjMh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$Iaui.LCFCM.ResourceModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$Iaui.LCFCM.ResourceModel)).$h}],"n":"","d":563110,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                }, $zMFSsa ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":563110,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(60130105254)
            
            //--TRIMMABLE-BOUNDARY-START(4360984234)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Interface.IViewProvider<System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>>.GetView(LivingThing.Core.Frameworks.Client.Interface.ContainerContext<System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Models.ResourceModel>>)
            [`LCFCI$IViewProvider$System$Collections$Generic$IEnumerable$LivingThing$Core$Frameworks$Common$Models$ResourceModel$$GetView`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4360984234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4360984234)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885464998)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885464998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885464998)
            
            //--TRIMMABLE-BOUNDARY-START(12885464998)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885464998)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015007142)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(73015007142)
                
            }
            static $h = 563110;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015007142),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245203366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604941734,
        "f": 83886081
      },
      "n": "Server",
      "d": 563110,
      "h": 73015007142,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015007142),
//--TRIMMABLE-BOUNDARY-START(94489843622),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835137958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194876326,
        "f": 83886081
      },
      "n": "Tag",
      "d": 563110,
      "h": 94489843622,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489843622),
//--TRIMMABLE-BOUNDARY-START(68720039846),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655268774,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 563110,
      "h": 68720039846,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720039846)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180432294),
    {
      "r": 178454529,
      "p": [
        {
          "n": "_banner",
          "p": 10086836
        }
      ],
      "n": "AddBanner",
      "d": 563110,
      "h": 17180432294,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(17180432294),
//--TRIMMABLE-BOUNDARY-START(98784810918),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 563110,
      "h": 98784810918,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784810918),
//--TRIMMABLE-BOUNDARY-START(64425072550),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 563110,
      "h": 64425072550,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425072550),
//--TRIMMABLE-BOUNDARY-START(30065334182),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 563110,
      "h": 30065334182,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065334182),
//--TRIMMABLE-BOUNDARY-START(60130105254),
    {
      "r": 6881395,
      "p": [
        {
          "n": "value",
          "p": $.$hDPm.LCFCI.ContainerContext$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)).$h
        }
      ],
      "n": "GetView",
      "d": 563110,
      "h": 60130105254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130105254)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475399590),
    {
      "t": 10086836,
      "n": "banner",
      "d": 563110,
      "h": 21475399590,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475399590),
//--TRIMMABLE-BOUNDARY-START(25770366886),
    {
      "t": $.$hDPm.LCFCCD$2.RemoteDataTable$$($.$LCOv.LCFCPM$1.BannerPostModel).$h,
      "n": "banners",
      "d": 563110,
      "h": 25770366886,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770366886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885464998),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 563110,
      "h": 12885464998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885464998)
  ],
  "h": 563110
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCI.IViewProvider$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.ResourceModel)), $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Client.Admin.Shared.CommunityAdminBanners`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Client${separator}Admin${separator}Shared${separator}CommunityAdminBanners`; }
        });
        //--TRIMMABLE-BOUNDARY-END(563110)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(38822)
