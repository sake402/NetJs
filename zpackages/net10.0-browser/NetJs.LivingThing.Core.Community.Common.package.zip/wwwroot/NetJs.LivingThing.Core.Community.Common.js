
//--TRIMMABLE-BOUNDARY-START(45556)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $OJJQ, $YUlm, $LCOv) {
    "use strict";
    let _;
    let $QjNPaj;
    let $pFLOCh;
    let $YEeDsg;
    let $nEFgXi;
    let $EvhpYh;
    let $NBLtQh;
    let $mgxIcc;
    let $FZsNBg;
    let $JhKfaj;
    let $hQntQe;
    let $frljwa;
    let $bxbOfd;
    let $auqSTj;
    let $XYUzQf;
    let $JcPchj;
    let $Cgkydg;
    let $nNJQWg;
    let $Zgmjae;
    let $wmhHZd;
    let $xCdgub;
    let $QGNUja;
    let $gkIPte;
    let $ucIWfk;
    let $lgHuCd;
    let $WKSoui;
    let $sLNece;
    let $hnGoZf;
    let $LEbiNe;
    let $vgbAVb;
    let $PiVTya;
    let $OxlIwj;
    let $doyszk;
    let $cIEYQf;
    let $IPhWSa;
    let $pDjCNd;
    let $AYnzji;
    let $TUfnlb;
    let $SBUfOf;
    let $QlQYsj;
    let $VBYYTe;
    let $vLcJYa;
    let $THpaLg;
    let $Bgeage;
    let $XgiFXd;
    let $kBJmdg;
    let $YnSfeb;
    let $rixBNe;
    let $USQKhj;
    let $atXrsg;
    let $KGjNte;
    let $oBSrLh;
    let $ceUjXd;
    let $wcNcgg;
    let $OThdTh;
    let $PDYCZa;
    let $gCerPc;
    let $maRvIj;
    let $CllyGe;
    let $NNKzOf;
    let $AOyYlg;
    let $JguNfl;
    let $LLHcCg;
    let $ZTrDOd;
    let $YtOHFb;
    let $Atjadg;
    let $DLvLme;
    let $qbuGde;
    let $Yfuyrf;
    let $MvuXel;
    let $eGZAki;
    let $neKoEj;
    let $NtLTie;
    let $ngGWrd;
    let $SndDbc;
    let $YYhhui;
    let $oHeVjb;
    let $FwEfRd;
    let $daaEoi;
    let $YJqeve;
    let $DIuMri;
    let $IiSlLh;
    let $HBJZDi;
    let $RxyISh;
    let $artYza;
    let $pKpIGj;
    let $jNKKQh;
    let $ERnoxf;
    let $WlczNc;
    let $UIVoek;
    let $MLDesi;
    let $CJdfkd;
    let $wLPoXj;
    let $nFVaTk;
    let $eBKGyf;
    let $ojybpd;
    let $dFTIsf;
    let $fDNSig;
    let $ZxpJJb;
    let $WwOEml;
    let $EFAKef;
    let $mLWBXg;
    let $ZHeChc;
    let $hxgKwf;
    let $MncEcl;
    let $hMCibc;
    let $fVwuYf;
    let $vIYOVb;
    let $tiDvOi;
    let $LYcPci;
    let $wtlenh;
    let $kehHXg;
    let $PDvnxe;
    let $lfXMIk;
    let $tvGiDj;
    let $GMnoOi;
    let $yViqOc;
    let $KDSgId;
    let $TYdOva;
    let $cUFGSa;
    let $xXAQfc;
    let $vGEGge;
    let $BDDJqd;
    let $xOuAUg;
    let $yLtyfd;
    let $PqNnqc;
    let $XGJxji;
    let $gctWbb;
    let $udwOia;
    let $nVzqXc;
    let $SEQEma;
    let $Rfszlb;
    let $lWwwuk;
    let $SLqLxk;
    let $kcOkjc;
    let $Ulrxwc;
    let $Wfgfik;
    let $aYdnAf;
    let $Xqzyra;
    let $mMkUUe;
    let $ilmsre;
    let $RGWfOf;
    let $ebbpml;
    let $fNIKHj;
    let $JPopyb;
    let $daKCcb;
    let $lkiCjf;
    let $gzMHJi;
    let $EPGkIi;
    let $ykmwBj;
    let $lzNQDg;
    let $RCmeEb;
    let $zuxpdd;
    let $qtGedd;
    let $GXpNTg;
    let $RsgNpg;
    let $LLSJae;
    let $dPwyyb;
    let $khTmyh;
    let $hWizRf;
    let $WFayhd;
    let $QPVvCk;
    let $SVbsZj;
    let $AUyYxf;
    let $vPlRWk;
    let $lTinYk;
    let $Nowayj;
    let $DRWNAf;
    let $lSifpd;
    let $kmvHie;
    let $WKpHsd;
    let $upByYa;
    let $irTsMd;
    let $CGNTke;
    let $RJYGzc;
    let $LUXKIa;
    let $LxhVii;
    let $cQpTXk;
    let $SNcZRh;
    let $mJaIMf;
    let $FfivPa;
    let $VVcngc;
    let $NAsBfd;
    let $CzlxCa;
    let $cqBFfj;
    let $akCABk;
    let $DuGgoi;
    let $zUHKWg;
    let $ktAbbd;
    let $QmDZpg;
    let $evNycd;
    let $NaRKGj;
    let $HvOqNf;
    let $qHtFmj;
    let $ArjRPd;
    let $cEQKEg;
    let $VIfbvc;
    let $RNKIha;
    let $TFlMPi;
    let $PIoRHe;
    let $aQMdLd;
    let $UmOCRf;
    let $wfmjGf;
    let $dmMErk;
    let $eCyuYf;
    let $SvEaRh;
    let $ktrChj;
    let $SyzXSc;
    let $zVGuhb;
    let $KVLQha;
    let $ARarke;
    let $NUqKLh;
    let $OAlzPd;
    let $DBIwfl;
    let $keysUk;
    let $svaZSh;
    let $qzoyaj;
    let $ZKpTjl;
    let $XMDHCk;
    let $cbGlMe;
    let $NGNDMe;
    let $hWFLrb;
    let $BZJyMf;
    let $fExJZh;
    let $aWZoJc;
    let $TIlIBh;
    let $bLAArg;
    let $RcMnRa;
    let $gFWXRf;
    let $vyySNj;
    let $qIcZXj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Common", 
    {
  "h": 45556,
  "f": "LivingThing.Core.Community.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(5550580)
        $asm.$cls(`$ydCm.LCCCS.ICommunityRootService`, ($self) => class ICommunityRootService
        {
            static $h = 5550580;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4300517876),
    {
      "p": 1370548,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890452468,
        "f": 50331905
      },
      "n": "ApplicationScope",
      "o": "LCCCS$ICommunityRootService$ApplicationScope",
      "d": 5550580,
      "h": 4300517876,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4300517876)
  ],
  "h": 5550580
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityRootService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityRootService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5550580)
        
        

        //--TRIMMABLE-BOUNDARY-START(2404852)
        $asm.$cls(`$ydCm.LCCCG.IGemStateModel`, ($self) => class IGemStateModel
        {
            static $h = 2404852;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542012404),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362143220,
        "f": 50331905
      },
      "n": "WinnerName",
      "o": "LCCCG$IGemStateModel$WinnerName",
      "d": 2404852,
      "h": 51542012404,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51542012404),
//--TRIMMABLE-BOUNDARY-START(47247045108),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772208628,
        "f": 50331905
      },
      "n": "WinnerId",
      "o": "LCCCG$IGemStateModel$WinnerId",
      "d": 2404852,
      "h": 47247045108,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47247045108),
//--TRIMMABLE-BOUNDARY-START(42952077812),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182274036,
        "f": 50331905
      },
      "n": "WinnerIconId",
      "o": "LCCCG$IGemStateModel$WinnerIconId",
      "d": 2404852,
      "h": 42952077812,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42952077812),
//--TRIMMABLE-BOUNDARY-START(38657110516),
    {
      "p": 635380,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592339444,
        "f": 50331905
      },
      "n": "Reward",
      "o": "LCCCG$IGemStateModel$Reward",
      "d": 2404852,
      "h": 38657110516,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38657110516)
  ],
  "h": 2404852
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.IGemStateModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}IGemStateModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2404852)
        
        

        //--TRIMMABLE-BOUNDARY-START(4502004)
        $asm.$cls(`$ydCm.LCCCM.ICommunityNewsletterRemoteService`, ($self) => class ICommunityNewsletterRemoteService
        {
            static $h = 4502004;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299469300),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "n": "SendWeekly",
      "o": "LCCCM$ICommunityNewsletterRemoteService$SendWeekly",
      "d": 4502004,
      "h": 4299469300,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4299469300)
  ],
  "h": 4502004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.ICommunityNewsletterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}ICommunityNewsletterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4502004)
        
        

        //--TRIMMABLE-BOUNDARY-START(5026292)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationRemoteService`, ($self) => class ICommunityApplicationRemoteService
        {
            static $h = 5026292;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299993588),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "n": "CheckIn",
      "o": "LCCCS$ICommunityApplicationRemoteService$CheckIn",
      "d": 5026292,
      "h": 4299993588,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4299993588),
//--TRIMMABLE-BOUNDARY-START(12889928180),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityMetricsModel)).$h,
      "n": "GetMetrics",
      "o": "LCCCS$ICommunityApplicationRemoteService$GetMetrics",
      "d": 5026292,
      "h": 12889928180,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12889928180),
//--TRIMMABLE-BOUNDARY-START(17184895476),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityTAndC)).$h,
      "p": [
        {
          "n": "app",
          "p": 1310721
        }
      ],
      "n": "GetTermsAndCondition",
      "o": "LCCCS$ICommunityApplicationRemoteService$GetTermsAndCondition",
      "d": 5026292,
      "h": 17184895476,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17184895476),
//--TRIMMABLE-BOUNDARY-START(8594960884),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityFAQ))).$h,
      "p": [
        {
          "n": "app",
          "p": 1310721
        }
      ],
      "n": "GetFAQ",
      "o": "LCCCS$ICommunityApplicationRemoteService$GetFAQ",
      "d": 5026292,
      "h": 8594960884,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8594960884),
//--TRIMMABLE-BOUNDARY-START(21479862772),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.DataId)).$h,
      "p": [
        {
          "n": "gemId",
          "p": 1310721
        },
        {
          "n": "winningPostId",
          "p": 1310721
        }
      ],
      "n": "SetGlobalGemClaimed",
      "o": "LCCCS$ICommunityApplicationRemoteService$SetGlobalGemClaimed",
      "d": 5026292,
      "h": 21479862772,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21479862772)
  ],
  "h": 5026292,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5026292)
        
        

        //--TRIMMABLE-BOUNDARY-START(2535924)
        $asm.$cls(`$ydCm.LCCCG.IHiddenGemState`, ($self) => class IHiddenGemState
        {
            static $h = 2535924;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592470516),
    {
      "p": 2273780,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362274292,
        "f": 50331905
      },
      "n": "Event",
      "o": "LCCCG$IHiddenGemState$Event",
      "d": 2535924,
      "h": 8592470516,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592470516),
//--TRIMMABLE-BOUNDARY-START(12887437812),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952208884,
        "f": 50331905
      },
      "n": "EventCount",
      "o": "LCCCG$IHiddenGemState$EventCount",
      "d": 2535924,
      "h": 12887437812,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887437812),
//--TRIMMABLE-BOUNDARY-START(4297503220),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772339700,
        "f": 50331905
      },
      "n": "CommentText",
      "o": "LCCCG$IHiddenGemState$CommentText",
      "d": 2535924,
      "h": 4297503220,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297503220),
//--TRIMMABLE-BOUNDARY-START(73016979956),
    {
      "p": 2077172,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132078068,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722012660,
        "f": 83886337
      },
      "n": "State",
      "o": "LCCCG$IHiddenGemState$State",
      "d": 2535924,
      "h": 73016979956,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73016979956),
//--TRIMMABLE-BOUNDARY-START(17182405108),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542143476,
        "f": 50331905
      },
      "n": "FoundTime",
      "o": "LCCCG$IHiddenGemState$FoundTime",
      "d": 2535924,
      "h": 17182405108,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17182405108)
  ],
  "h": 2535924
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCG.IGemStateModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.IHiddenGemState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}IHiddenGemState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2535924)
        
        

        //--TRIMMABLE-BOUNDARY-START(5288436)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationServiceCategory`, ($self) => class ICommunityApplicationServiceCategory
        {
            static $h = 5288436;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34365026804),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21480124916,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCCCS$ICommunityApplicationServiceCategory$Id",
      "d": 5288436,
      "h": 34365026804,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34365026804),
//--TRIMMABLE-BOUNDARY-START(4300255732),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890190324,
        "f": 50331905
      },
      "n": "CategoryType",
      "o": "LCCCS$ICommunityApplicationServiceCategory$CategoryType",
      "d": 5288436,
      "h": 4300255732,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4300255732),
//--TRIMMABLE-BOUNDARY-START(38659994100),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$LCOv.LCFCPM$1.PostBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30070059508,
        "f": 50331905
      },
      "n": "Items",
      "o": "LCCCS$ICommunityApplicationServiceCategory$Items",
      "d": 5288436,
      "h": 38659994100,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38659994100)
  ],
  "h": 5288436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceCategory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationServiceCategory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5288436)
        
        

        //--TRIMMABLE-BOUNDARY-START(5353972)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationServiceHasCategories`, ($self) => class ICommunityApplicationServiceHasCategories
        {
            static $h = 5353972;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544961524),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249994228,
        "f": 50331905
      },
      "n": "LoadCategories",
      "o": "LCCCS$ICommunityApplicationServiceHasCategories$LoadCategories",
      "d": 5353972,
      "h": 51544961524,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51544961524),
//--TRIMMABLE-BOUNDARY-START(8595288564),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30070125044,
        "f": 50331905
      },
      "n": "CategoryNames",
      "o": "LCCCS$ICommunityApplicationServiceHasCategories$CategoryNames",
      "d": 5353972,
      "h": 8595288564,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8595288564),
//--TRIMMABLE-BOUNDARY-START(4300321268),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21480190452,
        "f": 50331905
      },
      "n": "CategoryIcon",
      "o": "LCCCS$ICommunityApplicationServiceHasCategories$CategoryIcon",
      "d": 5353972,
      "h": 4300321268,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4300321268),
//--TRIMMABLE-BOUNDARY-START(12890255860),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38660059636,
        "f": 50331905
      },
      "n": "CategoryType",
      "o": "LCCCS$ICommunityApplicationServiceHasCategories$CategoryType",
      "d": 5353972,
      "h": 12890255860,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12890255860)
  ],
  "h": 5353972
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceHasCategories`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationServiceHasCategories`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5353972)
        
        

        //--TRIMMABLE-BOUNDARY-START(5419508)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationServiceHasPosts`, ($self) => class ICommunityApplicationServiceHasPosts
        {
            static $h = 5419508;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30070190580),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8595354100,
        "f": 50331905
      },
      "n": "LoadPosts",
      "o": "LCCCS$ICommunityApplicationServiceHasPosts$LoadPosts",
      "d": 5419508,
      "h": 30070190580,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30070190580),
//--TRIMMABLE-BOUNDARY-START(34365157876),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185288692,
        "f": 50331905
      },
      "n": "PostNames",
      "o": "LCCCS$ICommunityApplicationServiceHasPosts$PostNames",
      "d": 5419508,
      "h": 34365157876,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34365157876),
//--TRIMMABLE-BOUNDARY-START(38660125172),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25775223284,
        "f": 50331905
      },
      "n": "PostType",
      "o": "LCCCS$ICommunityApplicationServiceHasPosts$PostType",
      "d": 5419508,
      "h": 38660125172,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38660125172)
  ],
  "h": 5419508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceHasPosts`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationServiceHasPosts`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5419508)
        
        

        //--TRIMMABLE-BOUNDARY-START(5485044)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationSubService`, ($self) => class ICommunityApplicationSubService
        {
            static $h = 5485044;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21480321524),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8595419636,
        "f": 50331905
      },
      "n": "PostsName",
      "o": "LCCCS$ICommunityApplicationSubService$PostsName",
      "d": 5485044,
      "h": 21480321524,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21480321524),
//--TRIMMABLE-BOUNDARY-START(25775288820),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS.ICommunityApplicationServiceCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185354228,
        "f": 50331905
      },
      "n": "ServiceCategories",
      "o": "LCCCS$ICommunityApplicationSubService$ServiceCategories",
      "d": 5485044,
      "h": 25775288820,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25775288820)
  ],
  "h": 5485044
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationSubService, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationSubService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationSubService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5485044)
        
        

        //--TRIMMABLE-BOUNDARY-START(5157364)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationService<,,>`, (TCategory, TPost, TUserPreference) => $asm.$gt(`$ydCm.LCCCS.ICommunityApplicationService<,,>`, [TCategory, TPost, TUserPreference], ($self) => class ICommunityApplicationService$$$$
        {
            static $H = 5157364;
            static $h = 5157364;
            static $g = 3;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8595091956),
    {
      "p": $.$$.SCG.IEnumerable$$(TCategory).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17185026548,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331905
      },
      "n": "Categories",
      "o": "LCCCS$ICommunityApplicationService$$$$$Categories",
      "d": this.$h,
      "H": 8595091956,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8595091956),
//--TRIMMABLE-BOUNDARY-START(30069928436),
    {
      "p": $.$$.SCG.IEnumerable$$(TPost).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25774961140,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331905
      },
      "n": "Posts",
      "o": "LCCCS$ICommunityApplicationService$$$$$Posts",
      "d": this.$h,
      "H": 30069928436,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30069928436)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300124660),
    {
      "r": 178454529,
      "n": "BackgroundLoading",
      "o": "LCCCS$ICommunityApplicationService$$$$$BackgroundLoading",
      "d": this.$h,
      "H": 4300124660,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4300124660)
  ],
  "s": [
    {
      "h": TCategory?.$h??1572864,
      "n": "TCategory",
      "c": [1698228
      ]
    },
    {
      "h": TPost?.$h??1638400,
      "n": "TPost",
      "c": [16771508
      ]
    },
    {
      "h": TUserPreference?.$h??1703936,
      "n": "TUserPreference",
      "c": [105952
      ]
    }
  ],
  "r": 3,
  "H": 5157364,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationServiceHasPreference$$(TUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationService<${TCategory?.$fullName},${TPost?.$fullName},${TUserPreference?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationService$${TCategory?.$getFullName(separator)}$${TPost?.$getFullName(separator)}$${TUserPreference?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5157364)
        
        

        //--TRIMMABLE-BOUNDARY-START(1290740)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundNotificationModel`, ($self) => class HiddenGemFoundNotificationModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361029108)
            /*DataId*/ GemContainerPostId;
            //--TRIMMABLE-BOUNDARY-END(34361029108)
            
            //--TRIMMABLE-BOUNDARY-START(30066061812)
            /*int*/ FoundGemIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(30066061812)
            
            //--TRIMMABLE-BOUNDARY-START(133145276916)
            /*DataId*/ WinningPostId;
            //--TRIMMABLE-BOUNDARY-END(133145276916)
            
            //--TRIMMABLE-BOUNDARY-START(81605669364)
            /*GlobalHiddenGemRewardSettings?*/ GlobalGem = null;
            //--TRIMMABLE-BOUNDARY-END(81605669364)
            
            //--TRIMMABLE-BOUNDARY-START(85900636660)
            /*string*/ SessionId = null;
            //--TRIMMABLE-BOUNDARY-END(85900636660)
            
            //--TRIMMABLE-BOUNDARY-START(25771094516)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771094516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771094516)
            
            //--TRIMMABLE-BOUNDARY-START(25771094516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25771094516)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361029108)
                this.GemContainerPostId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(34361029108)
                
                //--TRIMMABLE-BOUNDARY-START(133145276916)
                this.WinningPostId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(133145276916)
                
            }
            static $h = 1290740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361029108),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540898292,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080505844,
        "f": 83886081
      },
      "n": "GemContainerPostId",
      "d": 1290740,
      "h": 34361029108,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361029108),
//--TRIMMABLE-BOUNDARY-START(30066061812),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950963700,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490571252,
        "f": 83886081
      },
      "n": "FoundGemIndex",
      "d": 1290740,
      "h": 30066061812,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066061812),
//--TRIMMABLE-BOUNDARY-START(133145276916),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310702068,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850309620,
        "f": 83886081
      },
      "n": "WinningPostId",
      "d": 1290740,
      "h": 133145276916,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145276916),
//--TRIMMABLE-BOUNDARY-START(81605669364),
    {
      "p": 5878260,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130832884,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670440436,
        "f": 83886081
      },
      "n": "GlobalGem",
      "d": 1290740,
      "h": 81605669364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605669364),
//--TRIMMABLE-BOUNDARY-START(85900636660),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720767476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260375028,
        "f": 83886081
      },
      "n": "SessionId",
      "d": 1290740,
      "h": 85900636660,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900636660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771094516),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1290740,
      "h": 25771094516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771094516)
  ],
  "h": 1290740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundNotificationModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1290740)
        
        

        //--TRIMMABLE-BOUNDARY-START(3322356)
        $asm.$cls(`$ydCm.LCCCM.CommunityServiceMetadata`, ($self) => class CommunityServiceMetadata extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38658028020)
            /*int*/ Opened = 0;
            //--TRIMMABLE-BOUNDARY-END(38658028020)
            
            //--TRIMMABLE-BOUNDARY-START(34363060724)
            /*DateTime*/ LastOpened;
            //--TRIMMABLE-BOUNDARY-END(34363060724)
            
            //--TRIMMABLE-BOUNDARY-START(12888224244)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888224244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888224244)
            
            //--TRIMMABLE-BOUNDARY-START(12888224244)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12888224244)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34363060724)
                this.LastOpened = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(34363060724)
                
            }
            static $h = 3322356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38658028020),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068093428,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837897204,
        "f": 83886081
      },
      "n": "Opened",
      "d": 3322356,
      "h": 38658028020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658028020),
//--TRIMMABLE-BOUNDARY-START(34363060724),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478158836,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247962612,
        "f": 83886081
      },
      "n": "LastOpened",
      "d": 3322356,
      "h": 34363060724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363060724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888224244),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3322356,
      "h": 12888224244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888224244)
  ],
  "h": 3322356,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityServiceMetadata`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityServiceMetadata`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3322356)
        
        

        //--TRIMMABLE-BOUNDARY-START(111092)
        $asm.$cls(`$ydCm.LCCCB.BadgesStartup`, ($self) => class BadgesStartup
        {
            //--TRIMMABLE-BOUNDARY-START(4295078388)
            static /*void */ AddBadges(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295078388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ydCm.LCCCB.BadgesStartup.RegisterGenerated(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$LCOv.LCFCPS.IBadgeProvider, $.$ydCm.LCCCB.CommunityInbuiltBadgeProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295078388)
            
            //--TRIMMABLE-BOUNDARY-START(8590045684)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590045684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_CommunityInbuiltBadgeProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$ydCm.LCCCB.CommunityInbuiltBadgeProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$vWqU.LCFCC.IResourcePathResolver, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$vWqU.LCFCC.IResourcePathResolver, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$LCOv.LCFCPS.IBadgeProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$ydCm.LCCCB.BadgesStartup, Get_CommunityInbuiltBadgeProvider, $QjNPaj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_CommunityInbuiltBadgeProvider","d":111092,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(8590045684)
            
            static $h = 111092;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295078388),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddBadges",
      "d": 111092,
      "h": 4295078388,
      "f": 16777256,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295078388),
//--TRIMMABLE-BOUNDARY-START(8590045684),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "RegisterGenerated",
      "d": 111092,
      "h": 8590045684,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590045684)
  ],
  "h": 111092
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Badges.BadgesStartup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Badges${separator}BadgesStartup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(111092)
        
        

        //--TRIMMABLE-BOUNDARY-START(3846644)
        $asm.$cls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModel`, ($self) => class CommunityWeeklyNewsletterModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21478683124)
            /*IEnumerable<GemRewardInfo>*/ GemRewards = null;
            //--TRIMMABLE-BOUNDARY-END(21478683124)
            
            //--TRIMMABLE-BOUNDARY-START(81608225268)
            /*IEnumerable<PostBaseModel>*/ TopPosts = null;
            //--TRIMMABLE-BOUNDARY-END(81608225268)
            
            //--TRIMMABLE-BOUNDARY-START(77313257972)
            /*IEnumerable<TopCreator>*/ TopCreators = null;
            //--TRIMMABLE-BOUNDARY-END(77313257972)
            
            //--TRIMMABLE-BOUNDARY-START(3912180)
            static $_GemRewardInfo;
            static get GemRewardInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3912180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel;
                return $cls.$_GemRewardInfo ??= $asm.$ncls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo`, ($self) => class GemRewardInfo extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21478748660)
                    /*AccountModel?*/ Account = null;
                    //--TRIMMABLE-BOUNDARY-END(21478748660)
                    
                    //--TRIMMABLE-BOUNDARY-START(107378094580)
                    /*double*/ Value = 0;
                    //--TRIMMABLE-BOUNDARY-END(107378094580)
                    
                    //--TRIMMABLE-BOUNDARY-START(103083127284)
                    /*string?*/ Tag = null;
                    //--TRIMMABLE-BOUNDARY-END(103083127284)
                    
                    //--TRIMMABLE-BOUNDARY-START(73018356212)
                    /*bool */ get IsCash()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47248552436);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*string?*/ let __ca1__;
                        return ((__ca1__ = this.Tag) !== null ? $.$$.S.String.Contains$3.call(__ca1__, "Cash") : false);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73018356212)
                    
                    //--TRIMMABLE-BOUNDARY-START(68723388916)
                    /*bool */ get IsAirtime()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38658617844);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*string?*/ let __ca2__;
                        return ((__ca2__ = this.Tag) !== null ? $.$$.S.String.Contains$3.call(__ca2__, "Airtime") : false);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68723388916)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183781364)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17183781364);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183781364)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183781364)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183781364)
                    
                    static $h = 3912180;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478748660),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068683252,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81608290804,
        "f": 83886081
      },
      "n": "Account",
      "d": 3912180,
      "h": 21478748660,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478748660),
//--TRIMMABLE-BOUNDARY-START(107378094580),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428421620,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98788159988,
        "f": 83886081
      },
      "n": "Value",
      "d": 3912180,
      "h": 107378094580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107378094580),
//--TRIMMABLE-BOUNDARY-START(103083127284),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838487028,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90198225396,
        "f": 83886081
      },
      "n": "Tag",
      "d": 3912180,
      "h": 103083127284,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103083127284),
//--TRIMMABLE-BOUNDARY-START(73018356212),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248552436,
        "f": 50331649
      },
      "n": "IsCash",
      "d": 3912180,
      "h": 73018356212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73018356212),
//--TRIMMABLE-BOUNDARY-START(68723388916),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658617844,
        "f": 50331649
      },
      "n": "IsAirtime",
      "d": 3912180,
      "h": 68723388916,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68723388916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183781364),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3912180,
      "h": 17183781364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183781364)
  ],
  "d": 3846644,
  "h": 3912180
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel+GemRewardInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModel${separator}GemRewardInfo`; }
                }, $cls, ($v) => $cls.$_GemRewardInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3912180)
            
            //--TRIMMABLE-BOUNDARY-START(3977716)
            static $_TopCreator;
            static get TopCreator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3977716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel;
                return $cls.$_TopCreator ??= $asm.$ncls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator`, ($self) => class TopCreator extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17183846900)
                    /*AccountModel?*/ Account = null;
                    //--TRIMMABLE-BOUNDARY-END(17183846900)
                    
                    //--TRIMMABLE-BOUNDARY-START(38658683380)
                    /*int*/ Posts = 0;
                    //--TRIMMABLE-BOUNDARY-END(38658683380)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888879604)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12888879604);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888879604)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888879604)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888879604)
                    
                    static $h = 3977716;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183846900),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773781492,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248617972,
        "f": 83886081
      },
      "n": "Account",
      "d": 3977716,
      "h": 17183846900,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183846900),
//--TRIMMABLE-BOUNDARY-START(38658683380),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363716084,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838552564,
        "f": 83886081
      },
      "n": "Posts",
      "d": 3977716,
      "h": 38658683380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658683380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888879604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3977716,
      "h": 12888879604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888879604)
  ],
  "d": 3846644,
  "h": 3977716
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel+TopCreator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModel${separator}TopCreator`; }
                }, $cls, ($v) => $cls.$_TopCreator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3977716)
            
            //--TRIMMABLE-BOUNDARY-START(17183715828)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183715828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183715828)
            
            //--TRIMMABLE-BOUNDARY-START(17183715828)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17183715828)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21478683124)
                this.GemRewards = $.$sl.SL.Enumerable.Empty($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo);
                //--TRIMMABLE-BOUNDARY-END(21478683124)
                
                //--TRIMMABLE-BOUNDARY-START(81608225268)
                this.TopPosts = $.$sl.SL.Enumerable.Empty($.$LCOv.LCFCPM$1.PostBaseModel);
                //--TRIMMABLE-BOUNDARY-END(81608225268)
                
                //--TRIMMABLE-BOUNDARY-START(77313257972)
                this.TopCreators = $.$sl.SL.Enumerable.Empty($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator);
                //--TRIMMABLE-BOUNDARY-END(77313257972)
                
            }
            static $h = 3846644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478683124),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068617716,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838421492,
        "f": 83886081
      },
      "n": "GemRewards",
      "d": 3846644,
      "h": 21478683124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478683124),
//--TRIMMABLE-BOUNDARY-START(81608225268),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248486900,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73018290676,
        "f": 83886081
      },
      "n": "TopPosts",
      "d": 3846644,
      "h": 81608225268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81608225268),
//--TRIMMABLE-BOUNDARY-START(77313257972),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658552308,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64428356084,
        "f": 83886081
      },
      "n": "TopCreators",
      "d": 3846644,
      "h": 77313257972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77313257972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183715828),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3846644,
      "h": 17183715828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183715828)
  ],
  "h": 3846644
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3846644)
        
        

        //--TRIMMABLE-BOUNDARY-START(6140404)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemsSettings`, ($self) => class GlobalHiddenGemsSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42955813364)
            /*IEnumerable<GlobalHiddenGemRewardSettings>?*/ DailySignups = null;
            //--TRIMMABLE-BOUNDARY-END(42955813364)
            
            //--TRIMMABLE-BOUNDARY-START(34365878772)
            /*IEnumerable<GlobalHiddenGemRewardSettings>?*/ CummulativeSignups = null;
            //--TRIMMABLE-BOUNDARY-END(34365878772)
            
            //--TRIMMABLE-BOUNDARY-START(38660846068)
            /*IEnumerable<GlobalHiddenGemRewardSettings>?*/ DailyPosts = null;
            //--TRIMMABLE-BOUNDARY-END(38660846068)
            
            //--TRIMMABLE-BOUNDARY-START(30070911476)
            /*IEnumerable<GlobalHiddenGemRewardSettings>?*/ CummulativePosts = null;
            //--TRIMMABLE-BOUNDARY-END(30070911476)
            
            //--TRIMMABLE-BOUNDARY-START(47250780660)
            /*GlobalHiddenGemRewardSettings?*/ FirstStatusPost = null;
            //--TRIMMABLE-BOUNDARY-END(47250780660)
            
            //--TRIMMABLE-BOUNDARY-START(25775944180)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25775944180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25775944180)
            
            //--TRIMMABLE-BOUNDARY-START(25775944180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25775944180)
            
            static $h = 6140404;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42955813364),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81610519028,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124560191988,
        "f": 83886081
      },
      "n": "DailySignups",
      "d": 6140404,
      "h": 42955813364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42955813364),
//--TRIMMABLE-BOUNDARY-START(34365878772),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64430649844,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107380322804,
        "f": 83886081
      },
      "n": "CummulativeSignups",
      "d": 6140404,
      "h": 34365878772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34365878772),
//--TRIMMABLE-BOUNDARY-START(38660846068),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73020584436,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115970257396,
        "f": 83886081
      },
      "n": "DailyPosts",
      "d": 6140404,
      "h": 38660846068,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38660846068),
//--TRIMMABLE-BOUNDARY-START(30070911476),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55840715252,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98790388212,
        "f": 83886081
      },
      "n": "CummulativePosts",
      "d": 6140404,
      "h": 30070911476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30070911476),
//--TRIMMABLE-BOUNDARY-START(47250780660),
    {
      "p": 5878260,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90200453620,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133150126580,
        "f": 83886081
      },
      "n": "FirstStatusPost",
      "d": 6140404,
      "h": 47250780660,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47250780660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25775944180),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6140404,
      "h": 25775944180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25775944180)
  ],
  "h": 6140404
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemsSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6140404)
        
        

        //--TRIMMABLE-BOUNDARY-START(4043252)
        $asm.$cls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModelCustomAttributesProvider`, ($self) => class CommunityWeeklyNewsletterModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299010548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299010548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4299010548)
            
            static $h = 4043252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299010548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4043252,
      "h": 4299010548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299010548)
  ],
  "h": 4043252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4043252)
        
        

        //--TRIMMABLE-BOUNDARY-START(438772)
        $asm.$cls(`$ydCm.LCCCG.GemIdentifierModelCustomAttributesProvider`, ($self) => class GemIdentifierModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295406068)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295406068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295406068)
            
            static $h = 438772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295406068),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 438772,
      "h": 4295406068,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295406068)
  ],
  "h": 438772
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemIdentifierModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemIdentifierModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(438772)
        
        

        //--TRIMMABLE-BOUNDARY-START(2339316)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemTriggerEventCustomAttributesProvider`, ($self) => class HiddenGemTriggerEventCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297306612)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297306612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297306612)
            
            static $h = 2339316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297306612),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2339316,
      "h": 4297306612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297306612)
  ],
  "h": 2339316
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemTriggerEventCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemTriggerEventCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2339316)
        
        

        //--TRIMMABLE-BOUNDARY-START(2994676)
        $asm.$cls(`$ydCm.LCCCM.CommunityMetricsModel`, ($self) => class CommunityMetricsModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(223341294068)
            /*int*/ TotalMembers = 0;
            //--TRIMMABLE-BOUNDARY-END(223341294068)
            
            //--TRIMMABLE-BOUNDARY-START(227636261364)
            /*int*/ TotalMembersOnline = 0;
            //--TRIMMABLE-BOUNDARY-END(227636261364)
            
            //--TRIMMABLE-BOUNDARY-START(133146980852)
            /*int*/ NewMembersToday = 0;
            //--TRIMMABLE-BOUNDARY-END(133146980852)
            
            //--TRIMMABLE-BOUNDARY-START(231931228660)
            /*int*/ TotalPosts = 0;
            //--TRIMMABLE-BOUNDARY-END(231931228660)
            
            //--TRIMMABLE-BOUNDARY-START(137441948148)
            /*int*/ NewPostsToday = 0;
            //--TRIMMABLE-BOUNDARY-END(137441948148)
            
            //--TRIMMABLE-BOUNDARY-START(236226195956)
            /*IEnumerable<PostTrendModel>?*/ Trending = null;
            //--TRIMMABLE-BOUNDARY-END(236226195956)
            
            //--TRIMMABLE-BOUNDARY-START(124557046260)
            /*IEnumerable<AccountModel>?*/ MembersOnline = null;
            //--TRIMMABLE-BOUNDARY-END(124557046260)
            
            //--TRIMMABLE-BOUNDARY-START(128852013556)
            /*IEnumerable<AccountModel>?*/ NewestMembers = null;
            //--TRIMMABLE-BOUNDARY-END(128852013556)
            
            //--TRIMMABLE-BOUNDARY-START(219046326772)
            /*IEnumerable<AccountModel>?*/ TopCreators = null;
            //--TRIMMABLE-BOUNDARY-END(219046326772)
            
            //--TRIMMABLE-BOUNDARY-START(42952667636)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952667636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952667636)
            
            //--TRIMMABLE-BOUNDARY-START(42952667636)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(42952667636)
            
            static $h = 2994676;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(223341294068),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492275188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188981555700,
        "f": 83886081
      },
      "n": "TotalMembers",
      "d": 2994676,
      "h": 223341294068,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223341294068),
//--TRIMMABLE-BOUNDARY-START(227636261364),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103082209780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197571490292,
        "f": 83886081
      },
      "n": "TotalMembersOnline",
      "d": 2994676,
      "h": 227636261364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227636261364),
//--TRIMMABLE-BOUNDARY-START(133146980852),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722471412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211751924,
        "f": 83886081
      },
      "n": "NewMembersToday",
      "d": 2994676,
      "h": 133146980852,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146980852),
//--TRIMMABLE-BOUNDARY-START(231931228660),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111672144372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206161424884,
        "f": 83886081
      },
      "n": "TotalPosts",
      "d": 2994676,
      "h": 231931228660,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231931228660),
//--TRIMMABLE-BOUNDARY-START(137441948148),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312406004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171801686516,
        "f": 83886081
      },
      "n": "NewPostsToday",
      "d": 2994676,
      "h": 137441948148,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441948148),
//--TRIMMABLE-BOUNDARY-START(236226195956),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120262078964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214751359476,
        "f": 83886081
      },
      "n": "Trending",
      "d": 2994676,
      "h": 236226195956,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236226195956),
//--TRIMMABLE-BOUNDARY-START(124557046260),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542602228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031882740,
        "f": 83886081
      },
      "n": "MembersOnline",
      "d": 2994676,
      "h": 124557046260,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124557046260),
//--TRIMMABLE-BOUNDARY-START(128852013556),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132536820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154621817332,
        "f": 83886081
      },
      "n": "NewestMembers",
      "d": 2994676,
      "h": 128852013556,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128852013556),
//--TRIMMABLE-BOUNDARY-START(219046326772),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902340596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180391621108,
        "f": 83886081
      },
      "n": "TopCreators",
      "d": 2994676,
      "h": 219046326772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219046326772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42952667636),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2994676,
      "h": 42952667636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952667636)
  ],
  "h": 2994676
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityMetricsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityMetricsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2994676)
        
        

        //--TRIMMABLE-BOUNDARY-START(2142708)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemStateCustomAttributesProvider`, ($self) => class HiddenGemStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297110004)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297110004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297110004)
            
            static $h = 2142708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297110004),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2142708,
      "h": 4297110004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297110004)
  ],
  "h": 2142708
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2142708)
        
        

        //--TRIMMABLE-BOUNDARY-START(2470388)
        $asm.$cls(`$ydCm.LCCCG.IGemStateModelCustomAttributesProvider`, ($self) => class IGemStateModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297437684)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297437684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297437684)
            
            static $h = 2470388;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297437684),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2470388,
      "h": 4297437684,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297437684)
  ],
  "h": 2470388
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.IGemStateModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}IGemStateModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2470388)
        
        

        //--TRIMMABLE-BOUNDARY-START(1880564)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemsFeatureModelCustomAttributesProvider`, ($self) => class HiddenGemsFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296847860)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296847860)
            
            //--TRIMMABLE-BOUNDARY-START(8591815156)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591815156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCG.HiddenGemsFeatureModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Gems", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.InputType = $.$cast((-9223372036854775808), $.$fPer.LCFC.InputType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("Gems", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t5 = $.$sca.SCD.RequiredAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$6();
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCG.HiddenGemsFeatureModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $NBLtQh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1880564,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $mgxIcc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1880564,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMS.StatusFeatureModelCustomAttributesProvider$$($.$ydCm.LCCCG.HiddenGemsFeatureModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591815156)
            
            static $h = 1880564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591815156),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1880564,
      "h": 8591815156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591815156)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296847860),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1880564,
      "h": 4296847860,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296847860)
  ],
  "h": 1880564
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemsFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1880564)
        
        

        //--TRIMMABLE-BOUNDARY-START(1094132)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundFeatureModelCustomAttributesProvider`, ($self) => class HiddenGemFoundFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296061428)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296061428)
            
            //--TRIMMABLE-BOUNDARY-START(8591028724)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591028724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCG.HiddenGemFoundFeatureModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EventCount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Reward", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (2048);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCG.HiddenGemFoundFeatureModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $nEFgXi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1094132,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $EvhpYh ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1094132,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPMS.StatusFeatureModelCustomAttributesProvider$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591028724)
            
            static $h = 1094132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591028724),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1094132,
      "h": 8591028724,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591028724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296061428),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1094132,
      "h": 4296061428,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296061428)
  ],
  "h": 1094132
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1094132)
        
        

        //--TRIMMABLE-BOUNDARY-START(5681652)
        $asm.$cls(`$ydCm.LCCCS$1.CommunityGlobalSettingsCustomAttributesProvider`, ($self) => class CommunityGlobalSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300648948)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300648948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCMS.ComponentGlobalSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4300648948)
            
            static $h = 5681652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300648948),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5681652,
      "h": 4300648948,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300648948)
  ],
  "h": 5681652
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.CommunityGlobalSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}CommunityGlobalSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5681652)
        
        

        //--TRIMMABLE-BOUNDARY-START(6205940)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemsSettingsCustomAttributesProvider`, ($self) => class GlobalHiddenGemsSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301173236)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301173236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4301173236)
            
            static $h = 6205940;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301173236),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6205940,
      "h": 4301173236,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4301173236)
  ],
  "h": 6205940
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemsSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6205940)
        
        

        //--TRIMMABLE-BOUNDARY-START(1356276)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundNotificationModelCustomAttributesProvider`, ($self) => class HiddenGemFoundNotificationModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296323572)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296323572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296323572)
            
            static $h = 1356276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296323572),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1356276,
      "h": 4296323572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296323572)
  ],
  "h": 1356276
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundNotificationModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1356276)
        
        

        //--TRIMMABLE-BOUNDARY-START(1618420)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemModelCustomAttributesProvider`, ($self) => class HiddenGemModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296585716)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296585716)
            
            //--TRIMMABLE-BOUNDARY-START(8591553012)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591553012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCG.HiddenGemModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EventCount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Reward", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (2048);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CommentText", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (2048);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t7 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i7 = new $t7();
                        $i7.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i7.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t8 = $.$sca.SCD.RequiredAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$6();
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i7;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCG.HiddenGemModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hQntQe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1618420,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $frljwa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1618420,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$Iaui.LCFCM.DataComplexPropertyModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591553012)
            
            static $h = 1618420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591553012),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1618420,
      "h": 8591553012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591553012)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296585716),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1618420,
      "h": 4296585716,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296585716)
  ],
  "h": 1618420
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1618420)
        
        

        //--TRIMMABLE-BOUNDARY-START(569844)
        $asm.$cls(`$ydCm.LCCCG.GemIdentifierModelTypeDescriptorBuilder`, ($self) => class GemIdentifierModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590504436)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590504436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.GemIdentifierModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Cgkydg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":569844,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.GemIdentifierModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590504436)
            
            //--TRIMMABLE-BOUNDARY-START(4295537140)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295537140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295537140)
            
            //--TRIMMABLE-BOUNDARY-START(4295537140)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295537140)
            
            static $h = 569844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590504436),
    {
      "r": 65537,
      "n": "Register",
      "d": 569844,
      "h": 8590504436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590504436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295537140),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 569844,
      "h": 4295537140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295537140)
  ],
  "h": 569844
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemIdentifierModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemIdentifierModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(569844)
        
        

        //--TRIMMABLE-BOUNDARY-START(700916)
        $asm.$cls(`$ydCm.LCCCG.GemRewardModelCustomAttributesProvider`, ($self) => class GemRewardModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295668212)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295668212)
            
            //--TRIMMABLE-BOUNDARY-START(8590635508)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590635508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCG.GemRewardModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Gem", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (2048);
                            $i3.InputType = $.$cast(21n, $.$fPer.LCFC.InputType);
                            $i3.OptionsReader = ($.$fPer.LCFCA$1.ISchemaOptionReader$$($.$ydCm.LCCCG.GemIdentifierModel).$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCG.GemRewardModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $FZsNBg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":700916,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JhKfaj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":700916,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590635508)
            
            static $h = 700916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590635508),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 700916,
      "h": 8590635508,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590635508)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295668212),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 700916,
      "h": 4295668212,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295668212)
  ],
  "h": 700916
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemRewardModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemRewardModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(700916)
        
        

        //--TRIMMABLE-BOUNDARY-START(2732532)
        $asm.$cls(`$ydCm.LCCCM.AccountProfilePictureModelCustomAttributesProvider`, ($self) => class AccountProfilePictureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297699828)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297699828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297699828)
            
            static $h = 2732532;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297699828),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2732532,
      "h": 4297699828,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297699828)
  ],
  "h": 2732532
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.AccountProfilePictureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}AccountProfilePictureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2732532)
        
        

        //--TRIMMABLE-BOUNDARY-START(6599156)
        $asm.$cls(`$ydCm.LCCC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4301566452)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301566452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ydCm.LCCCG.GemIdentifierModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCG.GemRewardModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCG.HiddenGemModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCM.UpdateProfileModelTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptorBuilder.Register();
                $.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4301566452)
            
            static $h = 6599156;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301566452),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 6599156,
      "h": 4301566452,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4301566452)
  ],
  "h": 6599156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6599156)
        
        

        //--TRIMMABLE-BOUNDARY-START(6402548)
        $asm.$cls(`$ydCm.LCCCS$2.CommunityClientApplicationState`, ($self) => class CommunityClientApplicationState extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(133150388724)
            /*Dictionary<string, CommunityServiceMetadata>*/ ServiceMetadatas = null;
            //--TRIMMABLE-BOUNDARY-END(133150388724)
            
            //--TRIMMABLE-BOUNDARY-START(124560454132)
            /*CommunityUserPreference*/ Preferences = null;
            //--TRIMMABLE-BOUNDARY-END(124560454132)
            
            //--TRIMMABLE-BOUNDARY-START(38661108212)
            /*AccountModel*/ account = null;
            //--TRIMMABLE-BOUNDARY-END(38661108212)
            
            //--TRIMMABLE-BOUNDARY-START(120265486836)
            /*AccountModel */ get MainAccount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73020846580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AuthenticationTicket.IsValid() ? this.account : $.$LCOv.LCFCPM$1.AccountModel.Guest;
            }
            /*AccountModel */ set MainAccount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158920192500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.account = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120265486836)
            
            //--TRIMMABLE-BOUNDARY-START(128855421428)
            /*DataId*/ SelectedAccountId;
            //--TRIMMABLE-BOUNDARY-END(128855421428)
            
            //--TRIMMABLE-BOUNDARY-START(42956075508)
            /*DecodedAuthenticationTicket*/ AuthenticationTicket = null;
            //--TRIMMABLE-BOUNDARY-END(42956075508)
            
            //--TRIMMABLE-BOUNDARY-START(210459800052)
            /*Dictionary<string, List<string>>*/ ViewedPosts = null;
            //--TRIMMABLE-BOUNDARY-END(210459800052)
            
            //--TRIMMABLE-BOUNDARY-START(206164832756)
            /*Dictionary<string, string>*/ Variables = null;
            //--TRIMMABLE-BOUNDARY-END(206164832756)
            
            //--TRIMMABLE-BOUNDARY-START(47251042804)
            /*IEnumerable<PostBaseModel>?*/ CachedFeeds = null;
            //--TRIMMABLE-BOUNDARY-END(47251042804)
            
            //--TRIMMABLE-BOUNDARY-START(34366140916)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366140916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34366140916)
            
            //--TRIMMABLE-BOUNDARY-START(34366140916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34366140916)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133150388724)
                this.ServiceMetadatas = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(133150388724)
                
                //--TRIMMABLE-BOUNDARY-START(124560454132)
                this.Preferences = new $.$ydCm.LCCCM.CommunityUserPreference().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(124560454132)
                
                //--TRIMMABLE-BOUNDARY-START(38661108212)
                this.account = $.$LCOv.LCFCPM$1.AccountModel.Guest;
                //--TRIMMABLE-BOUNDARY-END(38661108212)
                
                //--TRIMMABLE-BOUNDARY-START(128855421428)
                this.SelectedAccountId = $.$default($.$fPer.LCFCD.DataId);
                //--TRIMMABLE-BOUNDARY-END(128855421428)
                
                //--TRIMMABLE-BOUNDARY-START(42956075508)
                this.AuthenticationTicket = $.$GfYa.LCFCA.DecodedAuthenticationTicket.Default;
                //--TRIMMABLE-BOUNDARY-END(42956075508)
                
                //--TRIMMABLE-BOUNDARY-START(210459800052)
                this.ViewedPosts = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(210459800052)
                
                //--TRIMMABLE-BOUNDARY-START(206164832756)
                this.Variables = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(206164832756)
                
            }
            static $h = 6402548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133150388724),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98790650356,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184689996276,
        "f": 83886081
      },
      "n": "ServiceMetadatas",
      "d": 6402548,
      "h": 133150388724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133150388724),
//--TRIMMABLE-BOUNDARY-START(124560454132),
    {
      "p": 3584500,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81610781172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167510127092,
        "f": 83886081
      },
      "n": "Preferences",
      "d": 6402548,
      "h": 124560454132,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124560454132),
//--TRIMMABLE-BOUNDARY-START(120265486836),
    {
      "p": 7858612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73020846580,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158920192500,
        "f": 83886081
      },
      "n": "MainAccount",
      "d": 6402548,
      "h": 120265486836,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120265486836),
//--TRIMMABLE-BOUNDARY-START(128855421428),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90200715764,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176100061684,
        "f": 83886081
      },
      "n": "SelectedAccountId",
      "d": 6402548,
      "h": 128855421428,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128855421428),
//--TRIMMABLE-BOUNDARY-START(42956075508),
    {
      "p": 1130882,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55840977396,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141740323316,
        "f": 83886081
      },
      "n": "AuthenticationTicket",
      "d": 6402548,
      "h": 42956075508,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42956075508),
//--TRIMMABLE-BOUNDARY-START(210459800052),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115970519540,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201869865460,
        "f": 83886081
      },
      "n": "ViewedPosts",
      "d": 6402548,
      "h": 210459800052,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210459800052),
//--TRIMMABLE-BOUNDARY-START(206164832756),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107380584948,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193279930868,
        "f": 83886081
      },
      "n": "Variables",
      "d": 6402548,
      "h": 206164832756,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206164832756),
//--TRIMMABLE-BOUNDARY-START(47251042804),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64430911988,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150330257908,
        "f": 83886081
      },
      "n": "CachedFeeds",
      "d": 6402548,
      "h": 47251042804,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47251042804)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38661108212),
    {
      "t": 7858612,
      "n": "account",
      "d": 6402548,
      "h": 38661108212,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38661108212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34366140916),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6402548,
      "h": 34366140916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34366140916)
  ],
  "h": 6402548,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.States.CommunityClientApplicationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}States${separator}CommunityClientApplicationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6402548)
        
        

        //--TRIMMABLE-BOUNDARY-START(831988)
        $asm.$cls(`$ydCm.LCCCG.GemRewardModelTypeDescriptorBuilder`, ($self) => class GemRewardModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590766580)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590766580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.GemRewardModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.GemRewardModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.GemRewardModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $hnGoZf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":831988,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.GemRewardModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590766580)
            
            //--TRIMMABLE-BOUNDARY-START(4295799284)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295799284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295799284)
            
            //--TRIMMABLE-BOUNDARY-START(4295799284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295799284)
            
            static $h = 831988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590766580),
    {
      "r": 65537,
      "n": "Register",
      "d": 831988,
      "h": 8590766580,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590766580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295799284),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 831988,
      "h": 4295799284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295799284)
  ],
  "h": 831988
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemRewardModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemRewardModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(831988)
        
        

        //--TRIMMABLE-BOUNDARY-START(3650036)
        $asm.$cls(`$ydCm.LCCCM.CommunityUserPreferenceCustomAttributesProvider`, ($self) => class CommunityUserPreferenceCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298617332)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298617332)
            
            //--TRIMMABLE-BOUNDARY-START(8593584628)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593584628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCM.CommunityUserPreferenceCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Saved", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (1);
                            $i4.Title = "Welcome to Zoey";
                            $i4.Description = "Let's get you started.";
                            $i4.InputType = $.$cast(3n, $.$fPer.LCFC.InputType);
                            $i4.Exclude = $.$cast((16), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EnablePreviewFeatures", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (2);
                            $i5.Title = "Show Beta Apps";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCM.CommunityUserPreferenceCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $XYUzQf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3650036,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JcPchj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3650036,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$yleQ.LCFCA.ApplicationBaseUserPreferenceCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593584628)
            
            static $h = 3650036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593584628),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3650036,
      "h": 8593584628,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593584628)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298617332),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3650036,
      "h": 4298617332,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298617332)
  ],
  "h": 3650036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityUserPreferenceCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityUserPreferenceCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3650036)
        
        

        //--TRIMMABLE-BOUNDARY-START(963060)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemAccountEligibilityCustomAttributesProvider`, ($self) => class HiddenGemAccountEligibilityCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295930356)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295930356)
            
            //--TRIMMABLE-BOUNDARY-START(8590897652)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590897652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCG.HiddenGemAccountEligibilityCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCG.HiddenGemAccountEligibilityCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $bxbOfd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":963060,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $auqSTj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":963060,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590897652)
            
            static $h = 963060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590897652),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 963060,
      "h": 8590897652,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590897652)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295930356),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 963060,
      "h": 4295930356,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295930356)
  ],
  "h": 963060
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemAccountEligibilityCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemAccountEligibilityCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(963060)
        
        

        //--TRIMMABLE-BOUNDARY-START(4305396)
        $asm.$cls(`$ydCm.LCCCM.CreatorLaunchPadFeatureModelCustomAttributesProvider`, ($self) => class CreatorLaunchPadFeatureModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299272692)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299272692)
            
            //--TRIMMABLE-BOUNDARY-START(8594239988)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594239988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$sca.SCD.RequiredAttribute.$type, $.$sca.SCD.ValidationAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t3 = $.$sca.SCD.RequiredAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$6();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CreatorName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t4 = $.$sca.SCD.RequiredAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$6();
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Handle", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t5 = $.$sca.SCD.RequiredAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$6();
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Quota", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t6 = $.$sca.SCD.RequiredAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$6();
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Bid", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t7 = $.$sca.SCD.RequiredAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$6();
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SocialSettings", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sca.SCD.RequiredAttribute), [(() =>
                        {
                            //new $.$sca.SCD.RequiredAttribute()
                            const $t8 = $.$sca.SCD.RequiredAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$6();
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$sca.SCD.RequiredAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t9 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i9 = new $t9();
                        $i9.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i9.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Description = "Your real name?\r\n\r\nThis is not displayed on your profile. Used by Zoey team only to verify you.";
                            $i10.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-identifier"], [-1], null);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i9.set_Item("CreatorName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Description = "Your stage name?\r\n\r\nYour creator name will be shown to the community";
                            $i11.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-id-card"], [-1], null);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i9.set_Item("Handle", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Description = "Your profile short name?\r\n\r\nDisplayed with an @ in front of it, is unique to you only on Zoey.";
                            $i12.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-at"], [-1], null);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i9.set_Item("Quota", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Description = "Of the 1M(10M+ engagements) signups quota of Zoey goal, what portion do you want to take upon yourself?";
                            $i13.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-percent"], [-1], null);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i9.set_Item("Bid", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Description = "How much would you have Zoey pay you on delivering this quota?";
                            $i14.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-currency-ngn"], [-1], null);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i9.set_Item("SocialSettings", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Description = "Your current social media profile?\r\n\r\nProvide at least one.";
                            $i15.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-web"], [-1], null);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i9;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ucIWfk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4305396,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $lgHuCd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4305396,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$LCOv.LCFCPM$1.AccountFeatureModelCustomAttributesProvider$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594239988)
            
            static $h = 4305396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594239988),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4305396,
      "h": 8594239988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594239988)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299272692),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4305396,
      "h": 4299272692,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299272692)
  ],
  "h": 4305396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CreatorLaunchPadFeatureModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4305396)
        
        

        //--TRIMMABLE-BOUNDARY-START(3060212)
        $asm.$cls(`$ydCm.LCCCM.CommunityMetricsModelCustomAttributesProvider`, ($self) => class CommunityMetricsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298027508)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298027508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298027508)
            
            static $h = 3060212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298027508),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3060212,
      "h": 4298027508,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298027508)
  ],
  "h": 3060212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityMetricsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityMetricsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3060212)
        
        

        //--TRIMMABLE-BOUNDARY-START(4633076)
        $asm.$cls(`$ydCm.LCCCM.UpdateProfileModelCustomAttributesProvider`, ($self) => class UpdateProfileModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299600372)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299600372)
            
            //--TRIMMABLE-BOUNDARY-START(8594567668)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594567668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCM.UpdateProfileModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ProfilePicture", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Description = "Your profile picture";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-account"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Handle", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Description = "A handle identifies your account uniquely on Zoey network";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-at"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PhoneNumber", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Description = "Verifyable mobile phone number";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-phone"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Location", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Description = "Your residential State/LG";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-map-marker"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BirthDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Description = "Your date of birth";
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-map-marker"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Bio", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.InputType = $.$cast(16n, $.$fPer.LCFC.InputType);
                            $i8.Description = "Tell us something about yourself";
                            $i8.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-calendar"], [-1], null);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCM.UpdateProfileModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $WKSoui ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4633076,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $sLNece ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4633076,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594567668)
            
            static $h = 4633076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594567668),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4633076,
      "h": 8594567668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594567668)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299600372),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4633076,
      "h": 4299600372,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299600372)
  ],
  "h": 4633076
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.UpdateProfileModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}UpdateProfileModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4633076)
        
        

        //--TRIMMABLE-BOUNDARY-START(4174324)
        $asm.$cls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptorBuilder`, ($self) => class CommunityWeeklyNewsletterModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594108916)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594108916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ceUjXd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4174324,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594108916)
            
            //--TRIMMABLE-BOUNDARY-START(4299141620)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299141620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299141620)
            
            //--TRIMMABLE-BOUNDARY-START(4299141620)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299141620)
            
            static $h = 4174324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594108916),
    {
      "r": 65537,
      "n": "Register",
      "d": 4174324,
      "h": 8594108916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594108916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299141620),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4174324,
      "h": 4299141620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299141620)
  ],
  "h": 4174324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4174324)
        
        

        //--TRIMMABLE-BOUNDARY-START(242164)
        $asm.$cls(`$ydCm.LCCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295209460)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295209460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.GemIdentifierModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.GemIdentifierModelCustomAttributesProvider, $.$ydCm.LCCCG.GemIdentifierModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.GemRewardModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.GemRewardModelCustomAttributesProvider, $.$ydCm.LCCCG.GemRewardModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemFoundFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemFoundNotificationModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemModelCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemsFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemsFeatureModelCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemsFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemStateCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemTriggerEvent.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemTriggerEventCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemTriggerEventCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.HiddenGemAccountEligibility.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.HiddenGemAccountEligibilityCustomAttributesProvider, $.$ydCm.LCCCG.HiddenGemAccountEligibilityCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCG.IGemStateModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCG.IGemStateModelCustomAttributesProvider, $.$ydCm.LCCCG.IGemStateModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.CommunityMetricsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.CommunityMetricsModelCustomAttributesProvider, $.$ydCm.LCCCM.CommunityMetricsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.CommunityUserPreference.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceCustomAttributesProvider, $.$ydCm.LCCCM.CommunityUserPreferenceCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelCustomAttributesProvider, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelCustomAttributesProvider, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.AccountProfilePictureModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.AccountProfilePictureModelCustomAttributesProvider, $.$ydCm.LCCCM.AccountProfilePictureModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCM.UpdateProfileModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCM.UpdateProfileModelCustomAttributesProvider, $.$ydCm.LCCCM.UpdateProfileModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCS$1.CommunityGlobalSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCS$1.CommunityGlobalSettingsCustomAttributesProvider, $.$ydCm.LCCCS$1.CommunityGlobalSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsCustomAttributesProvider, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsCustomAttributesProvider, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295209460)
            
            static $h = 242164;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295209460),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 242164,
      "h": 4295209460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295209460)
  ],
  "h": 242164
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(242164)
        
        

        //--TRIMMABLE-BOUNDARY-START(3781108)
        $asm.$cls(`$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptorBuilder`, ($self) => class CommunityUserPreferenceTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593715700)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593715700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.CommunityUserPreference");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kBJmdg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3781108,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.CommunityUserPreference.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593715700)
            
            //--TRIMMABLE-BOUNDARY-START(4298748404)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298748404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298748404)
            
            //--TRIMMABLE-BOUNDARY-START(4298748404)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298748404)
            
            static $h = 3781108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593715700),
    {
      "r": 65537,
      "n": "Register",
      "d": 3781108,
      "h": 8593715700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593715700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298748404),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3781108,
      "h": 4298748404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298748404)
  ],
  "h": 3781108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityUserPreferenceTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityUserPreferenceTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3781108)
        
        

        //--TRIMMABLE-BOUNDARY-START(2601460)
        $asm.$cls(`$ydCm.LCCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297568756)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297568756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$ydCm.LCCCS.ICommunityApplicationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$ydCm.LCCCS.ICommunityApplicationRemoteService_Mocking().$ctor$3(impl);
                }, $gkIPte ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":2601460,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297568756)
            
            static $h = 2601460;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297568756),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 2601460,
      "h": 4297568756,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297568756)
  ],
  "h": 2601460
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2601460)
        
        

        //--TRIMMABLE-BOUNDARY-START(4567540)
        $asm.$cls(`$ydCm.LCCCM.UpdateProfileModel`, ($self) => class UpdateProfileModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107378749940)
            /*AccountProfilePictureModel*/ ProfilePicture;
            //--TRIMMABLE-BOUNDARY-END(107378749940)
            
            //--TRIMMABLE-BOUNDARY-START(94493848052)
            /*AccountHandle*/ Handle;
            //--TRIMMABLE-BOUNDARY-END(94493848052)
            
            //--TRIMMABLE-BOUNDARY-START(103083782644)
            /*PhoneNumber*/ PhoneNumber;
            //--TRIMMABLE-BOUNDARY-END(103083782644)
            
            //--TRIMMABLE-BOUNDARY-START(98788815348)
            /*INamedLocation?*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(98788815348)
            
            //--TRIMMABLE-BOUNDARY-START(38659273204)
            /*DateOnly?*/ BirthDate = null;
            //--TRIMMABLE-BOUNDARY-END(38659273204)
            
            //--TRIMMABLE-BOUNDARY-START(34364305908)
            /*string?*/ Bio = null;
            //--TRIMMABLE-BOUNDARY-END(34364305908)
            
            //--TRIMMABLE-BOUNDARY-START(30069338612)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069338612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30069338612)
            
            //--TRIMMABLE-BOUNDARY-START(30069338612)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30069338612)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(107378749940)
                this.ProfilePicture = $.$default($.$ydCm.LCCCM.AccountProfilePictureModel);
                //--TRIMMABLE-BOUNDARY-END(107378749940)
                
                //--TRIMMABLE-BOUNDARY-START(94493848052)
                this.Handle = $.$default($.$LCOv.LCFCPM$1.AccountHandle);
                //--TRIMMABLE-BOUNDARY-END(94493848052)
                
                //--TRIMMABLE-BOUNDARY-START(103083782644)
                this.PhoneNumber = $.$default($.$fPer.LCFCD.PhoneNumber);
                //--TRIMMABLE-BOUNDARY-END(103083782644)
                
                //--TRIMMABLE-BOUNDARY-START(38659273204)
                this.BirthDate = null;
                //--TRIMMABLE-BOUNDARY-END(38659273204)
                
            }
            static $h = 4567540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107378749940),
    {
      "p": 2666996,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198880756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158918357492,
        "f": 83886081
      },
      "n": "ProfilePicture",
      "d": 4567540,
      "h": 107378749940,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your profile picture",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-account"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107378749940),
//--TRIMMABLE-BOUNDARY-START(94493848052),
    {
      "p": 7793076,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64429076980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133148553716,
        "f": 83886081
      },
      "n": "Handle",
      "d": 4567540,
      "h": 94493848052,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "A handle identifies your account uniquely on Zoey network",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-at"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94493848052),
//--TRIMMABLE-BOUNDARY-START(103083782644),
    {
      "p": 32409942,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608946164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150328422900,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 4567540,
      "h": 103083782644,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Verifyable mobile phone number",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-phone"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103083782644),
//--TRIMMABLE-BOUNDARY-START(98788815348),
    {
      "p": 15108438,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73019011572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141738488308,
        "f": 83886081
      },
      "n": "Location",
      "d": 4567540,
      "h": 98788815348,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your residential State/LG",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-map-marker"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98788815348),
//--TRIMMABLE-BOUNDARY-START(38659273204),
    {
      "p": $.$typeNullable($.$$.S.DateOnly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55839142388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124558619124,
        "f": 83886081
      },
      "n": "BirthDate",
      "d": 4567540,
      "h": 38659273204,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your date of birth",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-map-marker"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38659273204),
//--TRIMMABLE-BOUNDARY-START(34364305908),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249207796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115968684532,
        "f": 83886081
      },
      "n": "Bio",
      "d": 4567540,
      "h": 34364305908,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 16,
              "t": 47614294
            },
            {
              "n": "Description",
              "v": "Tell us something about yourself",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-calendar"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34364305908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30069338612),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4567540,
      "h": 30069338612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30069338612)
  ],
  "h": 4567540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.UpdateProfileModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}UpdateProfileModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4567540)
        
        

        //--TRIMMABLE-BOUNDARY-START(2208244)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemStateExtension`, ($self) => class HiddenGemStateExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297175540)
            static /*bool */ IsHidden(/*this IHiddenGemState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297175540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (state.LCCCG$IHiddenGemState$State === 3/*HiddenGemState.Claimed*/)
                {
                    return false;
                }
                if (state.LCCCG$IHiddenGemState$State > 0/*HiddenGemState.None*/)
                {
                    if ($.$$.S.TimeSpan.op_LessThan($.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, state.LCCCG$IHiddenGemState$FoundTime), $.$$.S.TimeSpan.FromMinutes$2(10n)))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4297175540)
            
            static $h = 2208244;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297175540),
    {
      "r": 262145,
      "p": [
        {
          "n": "state",
          "p": 2535924
        }
      ],
      "n": "IsHidden",
      "d": 2208244,
      "h": 4297175540,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297175540)
  ],
  "h": 2208244
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemStateExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemStateExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2208244)
        
        

        //--TRIMMABLE-BOUNDARY-START(2863604)
        $asm.$cls(`$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptorBuilder`, ($self) => class AccountProfilePictureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592798196)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592798196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.AccountProfilePictureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QlQYsj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2863604,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.AccountProfilePictureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592798196)
            
            //--TRIMMABLE-BOUNDARY-START(4297830900)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297830900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297830900)
            
            //--TRIMMABLE-BOUNDARY-START(4297830900)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297830900)
            
            static $h = 2863604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592798196),
    {
      "r": 65537,
      "n": "Register",
      "d": 2863604,
      "h": 8592798196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592798196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297830900),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2863604,
      "h": 4297830900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297830900)
  ],
  "h": 2863604
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.AccountProfilePictureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}AccountProfilePictureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2863604)
        
        

        //--TRIMMABLE-BOUNDARY-START(4829684)
        $asm.$cls(`$ydCm.LCCC.PostUtility`, ($self) => class PostUtility
        {
            //--TRIMMABLE-BOUNDARY-START(21479666164)
            static /*string? */ GetDisplayName(/*this PostTypes*/ _type, /*IApplicationProxy?*/ app, /*bool*/ pluralize, /*bool*/ readable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479666164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let schema = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$LCOv.LCFCPM$1.PostTypes.$type, $.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, _type), false, true);
                if ((schema?.Title ?? null) === null)
                {
                    /*var*/ let type = $.$LCOv.LCFCPM$1.PostFactory.GetSystemType(_type);
                    if (type !== null)
                    {
                        /*var*/ let _types = $.$LCOv.LCFCPM$1.PostFactory.GetPostTypes$1(type);
                        if ($.$sl.SL.Enumerable.Count$1($.$LCOv.LCFCPM$1.PostTypes, _types) === 1)
                        {
                            return $.$yleQ.LCFCA.ApplicationUtility.GetDisplayName(type, app, pluralize, readable);
                        }
                    }
                }
                /*var*/ let tName = (schema?.Title ?? null);
                if (tName === null)
                {
                    tName = $.$$.S.Enum.ToStringT($.$LCOv.LCFCPM$1.PostTypes, $.$$.S.UInt32, _type);
                    if (app !== null)
                    {
                        tName = $.$$.S.String.Replace$3.call(tName, app.LCFC$INamed$Name, "");
                    }
                }
                if (pluralize)
                {
                    tName = $.$fPer.LCFCS$6.StringExtension.Pluralize(tName);
                }
                if (readable)
                {
                    tName = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(tName);
                }
                return tName;
            }
            //--TRIMMABLE-BOUNDARY-END(21479666164)
            
            //--TRIMMABLE-BOUNDARY-START(8594764276)
            static /*ValueTask<T?> *//*async*/  GetCommunityPostAssociation(T, /*this IServerRemoteService*/ server, /*DataId*/ targetId, /*PostRequestProperties*/ properties, /*RemoteProxyExecutionContext?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594764276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let assoc = (($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, server, new $.$fPer.LCFCD.DataFilter().$ctor$6($.$clone(targetId), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(properties, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), context), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))).AsEnumerable();
                    /*System.Collections.Generic.IEnumerable<T>?*/ let __ca1__;
                    return $.$$.N.AsyncResolver.Result($asnycContext, _ = ((__ca1__ = assoc) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3(T, __ca1__) : null));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8594764276)
            
            //--TRIMMABLE-BOUNDARY-START(12889731572)
            static /*ValueTask<IEnumerable<T>?> *//*async*/  GetCommunityPostAssociations(T, /*this IServerRemoteService*/ server, /*DataId*/ targetsId, /*PostRequestProperties*/ properties, /*RemoteProxyExecutionContext?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)), $.$$.SCG.IEnumerable$$(T), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889731572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let assoc = (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, server, new $.$fPer.LCFCD.DataFilter().$ctor$6($.$clone(targetsId), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(properties, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), context), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable();
                    return $.$$.N.AsyncResolver.Result($asnycContext, assoc);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12889731572)
            
            //--TRIMMABLE-BOUNDARY-START(17184698868)
            static /*ValueTask<IEnumerable<T>?> *//*async*/  GetCommunityPostLogicalAssociations(T, /*this IServerRemoteService*/ server, /*PostRequestProperties*/ properties, /*PostLogicalQueryFilterType*/ logic, /*RemoteProxyExecutionContext*/ context, /*params DataId[]*/ targetsId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)), $.$$.SCG.IEnumerable$$(T), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17184698868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (targetsId.length === 1)
                    {
                        let $t3, $r3;
                        /*var*/ let assoc = (($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, server, new $.$fPer.LCFCD.DataFilter().$ctor$6($.$$.System.Array.$ReadT1.call(targetsId, 0), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(properties, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), context), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))).AsEnumerable();
                        return $.$$.N.AsyncResolver.Result($asnycContext, assoc);
                    }
                    else 
                    {
                        let $t4, $r4;
                        return $.$$.N.AsyncResolver.Result($asnycContext, (($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(properties, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, (() =>
                        {
                            //new $.$LCOv.LCFCPM$1.PostSearchModel()
                            const $t5 = $.$LCOv.LCFCPM$1.PostSearchModel;
                            const $i5 = new $t5();
                            $i5.$ctor$1();
                            $i5.AssociationIds = $.$sl.SL.Enumerable.Where($.$fPer.LCFCD.DataId, targetsId, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataId, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                            {
                                return t.HasValue;
                            }, $XgiFXd ??= {"r":262145,"p":[{"n":"t","p":10455382}],"n":"","d":4829684,"h":0,"f":17825794}));
                            $i5.AssociationIdsLogic = logic;
                            return $i5;
                        })(), 0), context), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)))).AsEnumerable());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17184698868)
            
            //--TRIMMABLE-BOUNDARY-START(4299796980)
            static /*ValueTask<IEnumerable<T>?> *//*async*/  CommunitySearch(T, /*this IServerRemoteService*/ server, /*PostSearchModel*/ search, /*PostRequestProperties*/ properties, /*RemoteProxyExecutionContext?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)), $.$$.SCG.IEnumerable$$(T), async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299796980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let result = (($t6 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany(T, server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741853/*PostFilterTypes.Search*/, $.$LCOv.LCFCPM$1.PostFilterTypes), $.$box(properties, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)).WithAttribute$2($.$LCOv.LCFCPM$1.PostSearchModel, search, 0), context), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)))).AsEnumerable();
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4299796980)
            
            static $h = 4829684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21479666164),
    {
      "r": 1310721,
      "p": [
        {
          "n": "_type",
          "p": 21096884
        },
        {
          "n": "app",
          "p": 1482208,
          "f": 65
        },
        {
          "n": "pluralize",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "readable",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetDisplayName",
      "d": 4829684,
      "h": 21479666164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21479666164),
//--TRIMMABLE-BOUNDARY-START(8594764276),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "targetId",
          "p": 10455382
        },
        {
          "n": "properties",
          "p": 20048308,
          "f": 65,
          "v": 1196268653051967
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetCommunityPostAssociation",
      "d": 4829684,
      "h": 8594764276,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(8594764276),
//--TRIMMABLE-BOUNDARY-START(12889731572),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "targetsId",
          "p": 10455382
        },
        {
          "n": "properties",
          "p": 20048308,
          "f": 65,
          "v": 1196268653051967
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetCommunityPostAssociations",
      "d": 4829684,
      "h": 12889731572,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(12889731572),
//--TRIMMABLE-BOUNDARY-START(17184698868),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "properties",
          "p": 20048308
        },
        {
          "n": "logic",
          "p": 18278836
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "targetsId",
          "p": $.$typeArray($.$fPer.LCFCD.DataId).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetCommunityPostLogicalAssociations",
      "d": 4829684,
      "h": 17184698868,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17184698868),
//--TRIMMABLE-BOUNDARY-START(4299796980),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "search",
          "p": 20179380
        },
        {
          "n": "properties",
          "p": 20048308,
          "f": 65,
          "v": 1196268653051967
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "CommunitySearch",
      "d": 4829684,
      "h": 4299796980,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(4299796980)
  ],
  "h": 4829684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.PostUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}PostUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4829684)
        
        

        //--TRIMMABLE-BOUNDARY-START(5812724)
        $asm.$cls(`$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptorBuilder`, ($self) => class CommunityGlobalSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595747316)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595747316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Settings.CommunityGlobalSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pDjCNd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5812724,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCS$1.CommunityGlobalSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595747316)
            
            //--TRIMMABLE-BOUNDARY-START(4300780020)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300780020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300780020)
            
            //--TRIMMABLE-BOUNDARY-START(4300780020)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300780020)
            
            static $h = 5812724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595747316),
    {
      "r": 65537,
      "n": "Register",
      "d": 5812724,
      "h": 8595747316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595747316)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300780020),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5812724,
      "h": 4300780020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300780020)
  ],
  "h": 5812724
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.CommunityGlobalSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}CommunityGlobalSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5812724)
        
        

        //--TRIMMABLE-BOUNDARY-START(307700)
        $asm.$cls(`$ydCm.LCCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295274996)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295274996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295274996)
            
            static $h = 307700;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295274996),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 307700,
      "h": 4295274996,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295274996)
  ],
  "h": 307700
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(307700)
        
        

        //--TRIMMABLE-BOUNDARY-START(6337012)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptorBuilder`, ($self) => class GlobalHiddenGemsSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596271604)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596271604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NtLTie ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6337012,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596271604)
            
            //--TRIMMABLE-BOUNDARY-START(4301304308)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301304308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301304308)
            
            //--TRIMMABLE-BOUNDARY-START(4301304308)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301304308)
            
            static $h = 6337012;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596271604),
    {
      "r": 65537,
      "n": "Register",
      "d": 6337012,
      "h": 8596271604,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596271604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301304308),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6337012,
      "h": 4301304308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301304308)
  ],
  "h": 6337012
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemsSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6337012)
        
        

        //--TRIMMABLE-BOUNDARY-START(3453428)
        $asm.$cls(`$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptorBuilder`, ($self) => class CommunityServiceMetadataTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593388020)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593388020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.CommunityServiceMetadata");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DLvLme ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3453428,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.CommunityServiceMetadata.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593388020)
            
            //--TRIMMABLE-BOUNDARY-START(4298420724)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298420724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298420724)
            
            //--TRIMMABLE-BOUNDARY-START(4298420724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298420724)
            
            static $h = 3453428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593388020),
    {
      "r": 65537,
      "n": "Register",
      "d": 3453428,
      "h": 8593388020,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593388020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298420724),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3453428,
      "h": 4298420724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298420724)
  ],
  "h": 3453428
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityServiceMetadataTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityServiceMetadataTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3453428)
        
        

        //--TRIMMABLE-BOUNDARY-START(5943796)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsCustomAttributesProvider`, ($self) => class GlobalHiddenGemRewardSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300911092)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300911092)
            
            //--TRIMMABLE-BOUNDARY-START(8595878388)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595878388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(14, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Event", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EventCount", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Reward", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StartTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("EndTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RandomDailyEventAndReward", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LastRandomizedDate", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i9.InputType = $.$cast(4n, $.$fPer.LCFC.InputType);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FoundTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i11.InputType = $.$cast(4n, $.$fPer.LCFC.InputType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("WinnerName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i12.InputType = $.$cast(4n, $.$fPer.LCFC.InputType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("WinnerId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i13.InputType = $.$cast(4n, $.$fPer.LCFC.InputType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("WinnerIconId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777198), $.$fPer.LCFCA$1.SchemaType);
                            $i14.InputType = $.$cast(4n, $.$fPer.LCFC.InputType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Id", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777199), $.$fPer.LCFCA$1.SchemaType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("IsHidden", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $YtOHFb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5943796,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $Atjadg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5943796,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595878388)
            
            static $h = 5943796;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595878388),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5943796,
      "h": 8595878388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595878388)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300911092),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 5943796,
      "h": 4300911092,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300911092)
  ],
  "h": 5943796
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemRewardSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5943796)
        
        

        //--TRIMMABLE-BOUNDARY-START(6533620)
        $asm.$cls(`$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptorBuilder`, ($self) => class CommunityClientApplicationStateTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596468212)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596468212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.States.CommunityClientApplicationState");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $udwOia ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6533620,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596468212)
            
            //--TRIMMABLE-BOUNDARY-START(4301500916)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301500916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301500916)
            
            //--TRIMMABLE-BOUNDARY-START(4301500916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301500916)
            
            static $h = 6533620;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596468212),
    {
      "r": 65537,
      "n": "Register",
      "d": 6533620,
      "h": 8596468212,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596468212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301500916),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6533620,
      "h": 4301500916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301500916)
  ],
  "h": 6533620
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.States.CommunityClientApplicationStateTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}States${separator}CommunityClientApplicationStateTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6533620)
        
        

        //--TRIMMABLE-BOUNDARY-START(6074868)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptorBuilder`, ($self) => class GlobalHiddenGemRewardSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596009460)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596009460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $lkiCjf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6074868,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596009460)
            
            //--TRIMMABLE-BOUNDARY-START(4301042164)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301042164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301042164)
            
            //--TRIMMABLE-BOUNDARY-START(4301042164)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301042164)
            
            static $h = 6074868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596009460),
    {
      "r": 65537,
      "n": "Register",
      "d": 6074868,
      "h": 8596009460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596009460)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301042164),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6074868,
      "h": 4301042164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301042164)
  ],
  "h": 6074868
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemRewardSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6074868)
        
        

        //--TRIMMABLE-BOUNDARY-START(2011636)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptorBuilder`, ($self) => class HiddenGemsFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591946228)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591946228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AOyYlg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2011636,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.HiddenGemsFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591946228)
            
            //--TRIMMABLE-BOUNDARY-START(4296978932)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296978932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296978932)
            
            //--TRIMMABLE-BOUNDARY-START(4296978932)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296978932)
            
            static $h = 2011636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591946228),
    {
      "r": 65537,
      "n": "Register",
      "d": 2011636,
      "h": 8591946228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591946228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296978932),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2011636,
      "h": 4296978932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296978932)
  ],
  "h": 2011636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemsFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2011636)
        
        

        //--TRIMMABLE-BOUNDARY-START(4764148)
        $asm.$cls(`$ydCm.LCCCM.UpdateProfileModelTypeDescriptorBuilder`, ($self) => class UpdateProfileModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594698740)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594698740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.UpdateProfileModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $artYza ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4764148,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.UpdateProfileModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594698740)
            
            //--TRIMMABLE-BOUNDARY-START(4299731444)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299731444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299731444)
            
            //--TRIMMABLE-BOUNDARY-START(4299731444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299731444)
            
            static $h = 4764148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594698740),
    {
      "r": 65537,
      "n": "Register",
      "d": 4764148,
      "h": 8594698740,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594698740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299731444),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4764148,
      "h": 4299731444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299731444)
  ],
  "h": 4764148
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.UpdateProfileModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}UpdateProfileModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4764148)
        
        

        //--TRIMMABLE-BOUNDARY-START(4436468)
        $asm.$cls(`$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptorBuilder`, ($self) => class CreatorLaunchPadFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594371060)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594371060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZxpJJb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4436468,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594371060)
            
            //--TRIMMABLE-BOUNDARY-START(4299403764)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299403764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299403764)
            
            //--TRIMMABLE-BOUNDARY-START(4299403764)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299403764)
            
            static $h = 4436468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594371060),
    {
      "r": 65537,
      "n": "Register",
      "d": 4436468,
      "h": 8594371060,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594371060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299403764),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4436468,
      "h": 4299403764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299403764)
  ],
  "h": 4436468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CreatorLaunchPadFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4436468)
        
        

        //--TRIMMABLE-BOUNDARY-START(1225204)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptorBuilder`, ($self) => class HiddenGemFoundFeatureModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591159796)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591159796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PDvnxe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1225204,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591159796)
            
            //--TRIMMABLE-BOUNDARY-START(4296192500)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296192500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296192500)
            
            //--TRIMMABLE-BOUNDARY-START(4296192500)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296192500)
            
            static $h = 1225204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591159796),
    {
      "r": 65537,
      "n": "Register",
      "d": 1225204,
      "h": 8591159796,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591159796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296192500),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1225204,
      "h": 4296192500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296192500)
  ],
  "h": 1225204
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundFeatureModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1225204)
        
        

        //--TRIMMABLE-BOUNDARY-START(1749492)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemModelTypeDescriptorBuilder`, ($self) => class HiddenGemModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591684084)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591684084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.HiddenGemModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.HiddenGemModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.HiddenGemModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LxhVii ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1749492,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.HiddenGemModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591684084)
            
            //--TRIMMABLE-BOUNDARY-START(4296716788)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296716788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296716788)
            
            //--TRIMMABLE-BOUNDARY-START(4296716788)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296716788)
            
            static $h = 1749492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591684084),
    {
      "r": 65537,
      "n": "Register",
      "d": 1749492,
      "h": 8591684084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591684084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296716788),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1749492,
      "h": 4296716788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296716788)
  ],
  "h": 1749492
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1749492)
        
        

        //--TRIMMABLE-BOUNDARY-START(3191284)
        $asm.$cls(`$ydCm.LCCCM.CommunityMetricsModelTypeDescriptorBuilder`, ($self) => class CommunityMetricsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593125876)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593125876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Models.CommunityMetricsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PIoRHe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3191284,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCM.CommunityMetricsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593125876)
            
            //--TRIMMABLE-BOUNDARY-START(4298158580)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298158580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298158580)
            
            //--TRIMMABLE-BOUNDARY-START(4298158580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298158580)
            
            static $h = 3191284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593125876),
    {
      "r": 65537,
      "n": "Register",
      "d": 3191284,
      "h": 8593125876,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593125876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298158580),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3191284,
      "h": 4298158580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298158580)
  ],
  "h": 3191284
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityMetricsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityMetricsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3191284)
        
        

        //--TRIMMABLE-BOUNDARY-START(1487348)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptorBuilder`, ($self) => class HiddenGemFoundNotificationModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591421940)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591421940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor()
                        const $t1 = $.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cbGlMe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1487348,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591421940)
            
            //--TRIMMABLE-BOUNDARY-START(4296454644)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296454644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296454644)
            
            //--TRIMMABLE-BOUNDARY-START(4296454644)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296454644)
            
            static $h = 1487348;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591421940),
    {
      "r": 65537,
      "n": "Register",
      "d": 1487348,
      "h": 8591421940,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591421940)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296454644),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1487348,
      "h": 4296454644,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296454644)
  ],
  "h": 1487348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundNotificationModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1487348)
        
        

        //--TRIMMABLE-BOUNDARY-START(4895220)
        $asm.$cls(`$ydCm.LCCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594829812)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594829812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ydCm.LCCC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$ydCm.LCCCB.BadgesStartup.AddBadges(services);
                $.$ydCm.LCCC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$ydCm.LCCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$ydCm.LCCC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8594829812)
            
            //--TRIMMABLE-BOUNDARY-START(12889797108)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889797108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12889797108)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4299862516)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299862516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299862516)
            
            //--TRIMMABLE-BOUNDARY-START(4299862516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299862516)
            
            static $h = 4895220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594829812),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 4895220,
      "h": 8594829812,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8594829812),
//--TRIMMABLE-BOUNDARY-START(12889797108),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 4895220,
      "h": 12889797108,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12889797108)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299862516),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4895220,
      "h": 4299862516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299862516)
  ],
  "h": 4895220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4895220)
        
        

        //--TRIMMABLE-BOUNDARY-START(176628)
        $asm.$cls(`$ydCm.LCCCB.CommunityInbuiltBadgeProvider`, ($self) => class CommunityInbuiltBadgeProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295143924)
            /*IResourcePathResolver*/ _resolver = null;
            //--TRIMMABLE-BOUNDARY-END(4295143924)
            
            //--TRIMMABLE-BOUNDARY-START(8590111220)
            $ctor$1(/*IResourcePathResolver*/ resolver)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590111220);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resolver = resolver;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590111220)
            
            //--TRIMMABLE-BOUNDARY-START(12885078516)
            /*IEnumerable<BadgeModel> */ GetBadges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885078516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let badges = $.$sl.SL.Enumerable.Except$1($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$$.S.Enum.GetValues$1($.$LCOv.LCFCPMB.InbuiltBadgeTypes), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPMB.InbuiltBadgeTypes), [0/*InbuiltBadgeTypes.None*/], null, null));
                return $.$sl.SL.Enumerable.Select$1($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$LCOv.LCFCPMB.BadgeModel, badges, new ($.$$.S.Func$$$($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$LCOv.LCFCPMB.BadgeModel))().$ctor(this,  (/*b*/ b) =>
                {
                    return (() =>
                    {
                        //new $.$LCOv.LCFCPMB.BadgeModel()
                        const $t1 = $.$LCOv.LCFCPMB.BadgeModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Inbuilt = b;
                        $i1.Identifier = $.$fPer.LCFCD.DataId.op_Implicit$1(`Zoey/${$.$strNN($.$$.S.Enum.ToStringT($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$$.S.UInt32, b))}`);
                        $i1.Title = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$$.S.UInt32, b));
                        $i1.Description = $.$fPer.LCFCT.EnumExtensions.GetEnumDescription($.$box(b, $.$LCOv.LCFCPMB.InbuiltBadgeTypes));
                        $i1.Icon = this._resolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Resources", `img/badge/${$.$strNN($.$$.S.String.ToLower.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$$.S.UInt32, b)))}-s.png`, false);
                        $i1.Image = this._resolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Resources", `img/badge/${$.$strNN($.$$.S.String.ToLower.call($.$$.S.Enum.ToStringT($.$LCOv.LCFCPMB.InbuiltBadgeTypes, $.$$.S.UInt32, b)))}-b.png`, false);
                        return $i1;
                    })();
                }, $Bgeage ??= {"r":9628084,"p":[{"n":"b","p":9890228}],"n":"","d":176628,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885078516)
            
            //--TRIMMABLE-BOUNDARY-START(4320848308)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Posts.Services.IBadgeProvider.GetBadges()
            LCFCPS$IBadgeProvider$GetBadges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4320848308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBadges(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4320848308)
            
            static $h = 176628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885078516),
    {
      "r": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPMB.BadgeModel).$h,
      "n": "GetBadges",
      "d": 176628,
      "h": 12885078516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885078516)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295143924),
    {
      "t": 3825064,
      "n": "_resolver",
      "d": 176628,
      "h": 4295143924,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295143924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590111220),
    {
      "p": [
        {
          "n": "resolver",
          "p": 3825064
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 176628,
      "h": 8590111220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590111220)
  ],
  "h": 176628
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IBadgeProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Badges.CommunityInbuiltBadgeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Badges${separator}CommunityInbuiltBadgeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(176628)
        
        

        //--TRIMMABLE-BOUNDARY-START(5878260)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings`, ($self) => class GlobalHiddenGemRewardSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(77315289588)
            /*HiddenGemTriggerEvent*/ Event = 0;
            //--TRIMMABLE-BOUNDARY-END(77315289588)
            
            //--TRIMMABLE-BOUNDARY-START(81610256884)
            /*int*/ EventCount = 0;
            //--TRIMMABLE-BOUNDARY-END(81610256884)
            
            //--TRIMMABLE-BOUNDARY-START(236229079540)
            /*GemRewardModel*/ Reward;
            //--TRIMMABLE-BOUNDARY-END(236229079540)
            
            //--TRIMMABLE-BOUNDARY-START(352193196532)
            /*TimeOnly*/ StartTime;
            //--TRIMMABLE-BOUNDARY-END(352193196532)
            
            //--TRIMMABLE-BOUNDARY-START(73020322292)
            /*TimeOnly*/ EndTime;
            //--TRIMMABLE-BOUNDARY-END(73020322292)
            
            //--TRIMMABLE-BOUNDARY-START(231934112244)
            /*bool*/ RandomDailyEventAndReward = false;
            //--TRIMMABLE-BOUNDARY-END(231934112244)
            
            //--TRIMMABLE-BOUNDARY-START(227639144948)
            /*DateTime*/ LastRandomizedDate;
            //--TRIMMABLE-BOUNDARY-END(227639144948)
            
            //--TRIMMABLE-BOUNDARY-START(356488163828)
            /*HiddenGemState*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(356488163828)
            
            //--TRIMMABLE-BOUNDARY-START(85905224180)
            /*DateTime*/ FoundTime;
            //--TRIMMABLE-BOUNDARY-END(85905224180)
            
            //--TRIMMABLE-BOUNDARY-START(373668033012)
            /*string?*/ WinnerName = null;
            //--TRIMMABLE-BOUNDARY-END(373668033012)
            
            //--TRIMMABLE-BOUNDARY-START(369373065716)
            /*string?*/ WinnerId = null;
            //--TRIMMABLE-BOUNDARY-END(369373065716)
            
            //--TRIMMABLE-BOUNDARY-START(365078098420)
            /*string?*/ WinnerIconId = null;
            //--TRIMMABLE-BOUNDARY-END(365078098420)
            
            //--TRIMMABLE-BOUNDARY-START(219049210356)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(219049210356)
            
            //--TRIMMABLE-BOUNDARY-START(223344177652)
            /*bool */ get IsHidden()
            {
                return $.$ydCm.LCCCG.HiddenGemStateExtension.IsHidden(this);
            }
            //--TRIMMABLE-BOUNDARY-END(223344177652)
            
            //--TRIMMABLE-BOUNDARY-START(68725354996)
            /*string?*/ CommentText = null;
            //--TRIMMABLE-BOUNDARY-END(68725354996)
            
            //--TRIMMABLE-BOUNDARY-START(360783131124)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360783131124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Event === 0/*HiddenGemTriggerEvent.None*/)
                {
                    return "Nop";
                }
                /*var*/ let ev = $.$$.S.Math.Max$4(1, this.EventCount);
                /*var*/ let mod = ev % 10;
                /*string*/ let th = "th";
                if (mod === 1)
                {
                    th = "st";
                }
                else if (mod === 2)
                {
                    th = "nd";
                }
                else if (mod === 3)
                {
                    th = "rd";
                }
                return `The ${$.$strNN(ev)}${$.$strNN(th)} person to ${$.$strNN($.$$.S.String.ToLower.call($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$ydCm.LCCCG.HiddenGemTriggerEvent, $.$$.S.UInt32, this.Event))))} ${$.$strNN(($.$$.S.TimeOnly.op_Inequality(this.StartTime, new $.$$.S.TimeOnly()) && $.$$.S.TimeOnly.op_Inequality(this.EndTime, new $.$$.S.TimeOnly()) ? `between ${$.$strNN(this.StartTime.ToString())} and ${$.$strNN(this.EndTime.ToString())} ` : ""))}wins ${$.$strNN((this.Reward.Description ?? `${$.$strNN(this.Reward.Value)} ${$.$strNN(this.Reward.Gem.ToString())}`))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(360783131124)
            
            //--TRIMMABLE-BOUNDARY-START(34362274292)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.Event.get
            get LCCCG$IHiddenGemState$Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592470516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Event;
            }
            //--TRIMMABLE-BOUNDARY-END(34362274292)
            
            //--TRIMMABLE-BOUNDARY-START(42952208884)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.EventCount.get
            get LCCCG$IHiddenGemState$EventCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887437812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EventCount;
            }
            //--TRIMMABLE-BOUNDARY-END(42952208884)
            
            //--TRIMMABLE-BOUNDARY-START(25772339700)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.CommentText.get
            get LCCCG$IHiddenGemState$CommentText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297503220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CommentText;
            }
            //--TRIMMABLE-BOUNDARY-END(25772339700)
            
            //--TRIMMABLE-BOUNDARY-START(60132078068)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.State.get
            get LCCCG$IHiddenGemState$State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016979956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.State;
            }
            //--TRIMMABLE-BOUNDARY-END(60132078068)
            
            //--TRIMMABLE-BOUNDARY-START(68722012660)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.State.set
            set LCCCG$IHiddenGemState$State(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016979956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.State = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68722012660)
            
            //--TRIMMABLE-BOUNDARY-START(51542143476)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.FoundTime.get
            get LCCCG$IHiddenGemState$FoundTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182405108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FoundTime;
            }
            //--TRIMMABLE-BOUNDARY-END(51542143476)
            
            //--TRIMMABLE-BOUNDARY-START(34362143220)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerName.get
            get LCCCG$IGemStateModel$WinnerName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542012404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerName;
            }
            //--TRIMMABLE-BOUNDARY-END(34362143220)
            
            //--TRIMMABLE-BOUNDARY-START(25772208628)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerId.get
            get LCCCG$IGemStateModel$WinnerId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247045108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerId;
            }
            //--TRIMMABLE-BOUNDARY-END(25772208628)
            
            //--TRIMMABLE-BOUNDARY-START(17182274036)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerIconId.get
            get LCCCG$IGemStateModel$WinnerIconId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952077812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerIconId;
            }
            //--TRIMMABLE-BOUNDARY-END(17182274036)
            
            //--TRIMMABLE-BOUNDARY-START(8592339444)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.Reward.get
            get LCCCG$IGemStateModel$Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657110516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reward;
            }
            //--TRIMMABLE-BOUNDARY-END(8592339444)
            
            //--TRIMMABLE-BOUNDARY-START(64430387700)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64430387700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64430387700)
            
            //--TRIMMABLE-BOUNDARY-START(64430387700)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(64430387700)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(236229079540)
                this.Reward = $.$default($.$ydCm.LCCCG.GemRewardModel);
                //--TRIMMABLE-BOUNDARY-END(236229079540)
                
                //--TRIMMABLE-BOUNDARY-START(352193196532)
                this.StartTime = $.$default($.$$.S.TimeOnly);
                //--TRIMMABLE-BOUNDARY-END(352193196532)
                
                //--TRIMMABLE-BOUNDARY-START(73020322292)
                this.EndTime = $.$default($.$$.S.TimeOnly);
                //--TRIMMABLE-BOUNDARY-END(73020322292)
                
                //--TRIMMABLE-BOUNDARY-START(227639144948)
                this.LastRandomizedDate = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(227639144948)
                
                //--TRIMMABLE-BOUNDARY-START(85905224180)
                this.FoundTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(85905224180)
                
                //--TRIMMABLE-BOUNDARY-START(219049210356)
                this.Id = $.$$.S.Guid.NewGuid().ToString();
                //--TRIMMABLE-BOUNDARY-END(219049210356)
                
            }
            static $h = 5878260;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77315289588),
    {
      "p": 2273780,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111675027956,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253408948724,
        "f": 83886081
      },
      "n": "Event",
      "d": 5878260,
      "h": 77315289588,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77315289588),
//--TRIMMABLE-BOUNDARY-START(81610256884),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120264962548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261998883316,
        "f": 83886081
      },
      "n": "EventCount",
      "d": 5878260,
      "h": 81610256884,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81610256884),
//--TRIMMABLE-BOUNDARY-START(236229079540),
    {
      "p": 635380,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171804570100,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304948556276,
        "f": 83886081
      },
      "n": "Reward",
      "d": 5878260,
      "h": 236229079540,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236229079540),
//--TRIMMABLE-BOUNDARY-START(352193196532),
    {
      "p": 186318849,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180394504692,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313538490868,
        "f": 83886081
      },
      "n": "StartTime",
      "d": 5878260,
      "h": 352193196532,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(352193196532),
//--TRIMMABLE-BOUNDARY-START(73020322292),
    {
      "p": 186318849,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103085093364,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244819014132,
        "f": 83886081
      },
      "n": "EndTime",
      "d": 5878260,
      "h": 73020322292,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73020322292),
//--TRIMMABLE-BOUNDARY-START(231934112244),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163214635508,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296358621684,
        "f": 83886081
      },
      "n": "RandomDailyEventAndReward",
      "d": 5878260,
      "h": 231934112244,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231934112244),
//--TRIMMABLE-BOUNDARY-START(227639144948),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154624700916,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287768687092,
        "f": 83886081
      },
      "n": "LastRandomizedDate",
      "d": 5878260,
      "h": 227639144948,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 4,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227639144948),
//--TRIMMABLE-BOUNDARY-START(356488163828),
    {
      "p": 2077172,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188984439284,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322128425460,
        "f": 83886081
      },
      "n": "State",
      "d": 5878260,
      "h": 356488163828,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(356488163828),
//--TRIMMABLE-BOUNDARY-START(85905224180),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128854897140,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270588817908,
        "f": 83886081
      },
      "n": "FoundTime",
      "d": 5878260,
      "h": 85905224180,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 4,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85905224180),
//--TRIMMABLE-BOUNDARY-START(373668033012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214754243060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347898229236,
        "f": 83886081
      },
      "n": "WinnerName",
      "d": 5878260,
      "h": 373668033012,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 4,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(373668033012),
//--TRIMMABLE-BOUNDARY-START(369373065716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206164308468,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339308294644,
        "f": 83886081
      },
      "n": "WinnerId",
      "d": 5878260,
      "h": 369373065716,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 4,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(369373065716),
//--TRIMMABLE-BOUNDARY-START(365078098420),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197574373876,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330718360052,
        "f": 83886081
      },
      "n": "WinnerIconId",
      "d": 5878260,
      "h": 365078098420,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777198,
              "t": 2722134
            },
            {
              "n": "InputType",
              "v": 4,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(365078098420),
//--TRIMMABLE-BOUNDARY-START(219049210356),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137444831732,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279178752500,
        "f": 83886081
      },
      "n": "Id",
      "d": 5878260,
      "h": 219049210356,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777199,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219049210356),
//--TRIMMABLE-BOUNDARY-START(223344177652),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146034766324,
        "f": 50331649
      },
      "n": "IsHidden",
      "d": 5878260,
      "h": 223344177652,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223344177652),
//--TRIMMABLE-BOUNDARY-START(68725354996),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94495158772,
        "f": 50331649
      },
      "n": "CommentText",
      "d": 5878260,
      "h": 68725354996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68725354996)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(360783131124),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 5878260,
      "h": 360783131124,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(360783131124)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64430387700),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5878260,
      "h": 64430387700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64430387700)
  ],
  "h": 5878260
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCG.IHiddenGemState, $.$ydCm.LCCCG.IGemStateModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemRewardSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5878260)
        
        

        //--TRIMMABLE-BOUNDARY-START(4960756)
        $asm.$cls(`$ydCm.LCCCS.CommunityApplicationServiceCategory<>`, (TCategory) => $asm.$gt(`$ydCm.LCCCS.CommunityApplicationServiceCategory<>`, [TCategory], ($self) => class CommunityApplicationServiceCategory$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(98789208564)
            /*IDisplayable*/ parent = null;
            //--TRIMMABLE-BOUNDARY-END(98789208564)
            
            //--TRIMMABLE-BOUNDARY-START(8594895348)
            $ctor$1(/*IDisplayable*/ parent, /*Pager<PostBaseModel>*/ items)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594895348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.parent = parent;
                    this.Items = items;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594895348)
            
            //--TRIMMABLE-BOUNDARY-START(85904306676)
            /*string?*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(85904306676)
            
            //--TRIMMABLE-BOUNDARY-START(90199273972)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55839535604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*string*/ let __ca2__;
                return this.id ?? ((__ca1__ = this.Title) !== null ? ((__ca2__ = $.$$.S.String.Replace.call(__ca1__, /*\\*/ 92, /*-*/ 45)) !== null ? $.$$.S.String.Replace.call(__ca2__, /*/*/ 47, /*-*/ 45) : null) : null);
            }
            /*string */ set Id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124559012340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90199273972)
            
            //--TRIMMABLE-BOUNDARY-START(137443914228)
            /*string?*/ title = null;
            //--TRIMMABLE-BOUNDARY-END(137443914228)
            
            //--TRIMMABLE-BOUNDARY-START(141738881524)
            /*string? */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73019404788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.title ?? this.parent.LCFC$IDisplayable$Title;
            }
            /*string? */ set Title(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133148946932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.title = value;
            }
            //--TRIMMABLE-BOUNDARY-END(141738881524)
            
            //--TRIMMABLE-BOUNDARY-START(17184829940)
            /*string?*/ description = null;
            //--TRIMMABLE-BOUNDARY-END(17184829940)
            
            //--TRIMMABLE-BOUNDARY-START(21479797236)
            /*string? */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659666420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.description ?? this.parent.LCFC$IDescribable$Description;
            }
            /*string? */ set Description(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107379143156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.description = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21479797236)
            
            //--TRIMMABLE-BOUNDARY-START(77314372084)
            /*IconDescriptor*/ icon;
            //--TRIMMABLE-BOUNDARY-END(77314372084)
            
            //--TRIMMABLE-BOUNDARY-START(81609339380)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249601012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.icon.Icon !== null ? this.icon : (this.parent?.LCFC$IDisplayable$Icon ?? null) ?? new $.$fPer.LCFC.IconDescriptor();
            }
            /*IconDescriptor */ set Icon(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115969077748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.icon = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(81609339380)
            
            //--TRIMMABLE-BOUNDARY-START(94494241268)
            /*Pager<PostBaseModel>*/ Items = null;
            //--TRIMMABLE-BOUNDARY-END(94494241268)
            
            //--TRIMMABLE-BOUNDARY-START(12889862644)
            /*Type */ get CategoryType()
            {
                return TCategory.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12889862644)
            
            //--TRIMMABLE-BOUNDARY-START(21480124916)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceCategory.Id.get
            get LCCCS$ICommunityApplicationServiceCategory$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34365026804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(21480124916)
            
            //--TRIMMABLE-BOUNDARY-START(12890190324)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceCategory.CategoryType.get
            get LCCCS$ICommunityApplicationServiceCategory$CategoryType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300255732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CategoryType;
            }
            //--TRIMMABLE-BOUNDARY-END(12890190324)
            
            //--TRIMMABLE-BOUNDARY-START(30070059508)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Services.ICommunityApplicationServiceCategory.Items.get
            get LCCCS$ICommunityApplicationServiceCategory$Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659994100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Items;
            }
            //--TRIMMABLE-BOUNDARY-END(30070059508)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77314372084)
                this.icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(77314372084)
                
            }
            static $H = 4960756;
            static $h = 4960756;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90199273972),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55839535604,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124559012340,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "Id",
      "d": this.$h,
      "H": 90199273972,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90199273972),
//--TRIMMABLE-BOUNDARY-START(141738881524),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73019404788,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133148946932,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "Title",
      "d": this.$h,
      "H": 141738881524,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141738881524),
//--TRIMMABLE-BOUNDARY-START(21479797236),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38659666420,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 107379143156,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "Description",
      "d": this.$h,
      "H": 21479797236,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21479797236),
//--TRIMMABLE-BOUNDARY-START(81609339380),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47249601012,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 115969077748,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "Icon",
      "d": this.$h,
      "H": 81609339380,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81609339380),
//--TRIMMABLE-BOUNDARY-START(94494241268),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$LCOv.LCFCPM$1.PostBaseModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64429470196,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 94494241268,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94494241268),
//--TRIMMABLE-BOUNDARY-START(12889862644),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30069731828,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "CategoryType",
      "d": this.$h,
      "H": 12889862644,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12889862644)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98789208564),
    {
      "t": 46893398,
      "n": "parent",
      "d": this.$h,
      "H": 98789208564,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98789208564),
//--TRIMMABLE-BOUNDARY-START(85904306676),
    {
      "t": 1310721,
      "n": "id",
      "d": this.$h,
      "H": 85904306676,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85904306676),
//--TRIMMABLE-BOUNDARY-START(137443914228),
    {
      "t": 1310721,
      "n": "title",
      "d": this.$h,
      "H": 137443914228,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137443914228),
//--TRIMMABLE-BOUNDARY-START(17184829940),
    {
      "t": 1310721,
      "n": "description",
      "d": this.$h,
      "H": 17184829940,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17184829940),
//--TRIMMABLE-BOUNDARY-START(77314372084),
    {
      "t": 46238038,
      "n": "icon",
      "d": this.$h,
      "H": 77314372084,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77314372084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594895348),
    {
      "p": [
        {
          "n": "parent",
          "p": 46893398
        },
        {
          "n": "items",
          "p": $.$fPer.LCFCD.Pager$$($.$LCOv.LCFCPM$1.PostBaseModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8594895348,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594895348)
  ],
  "s": [
    {
      "h": TCategory?.$h??1572864,
      "n": "TCategory"
    }
  ],
  "r": 1,
  "H": 4960756,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCS.ICommunityApplicationServiceCategory, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.CommunityApplicationServiceCategory<${TCategory?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}CommunityApplicationServiceCategory$${TCategory?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(4960756)
        
        

        //--TRIMMABLE-BOUNDARY-START(3518964)
        $asm.$str(`$ydCm.LCCCM.CommunityTAndC`, ($self) => class CommunityTAndC extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(47248159220)
            /*string*/ Prefix = null;
            //--TRIMMABLE-BOUNDARY-END(47248159220)
            
            //--TRIMMABLE-BOUNDARY-START(81607897588)
            /*IEnumerable<string>*/ Terms = null;
            //--TRIMMABLE-BOUNDARY-END(81607897588)
            
            //--TRIMMABLE-BOUNDARY-START(77312930292)
            /*string*/ Suffix = null;
            //--TRIMMABLE-BOUNDARY-END(77312930292)
            
            //--TRIMMABLE-BOUNDARY-START(17183388148)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183388148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183388148)
            
            //--TRIMMABLE-BOUNDARY-START(17183388148)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17183388148)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Prefix = this.Prefix;
                copy.Terms = this.Terms;
                copy.Suffix = this.Suffix;
                return copy;
            }
            static $h = 3518964;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47248159220),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773322740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838093812,
        "f": 83886081
      },
      "n": "Prefix",
      "d": 3518964,
      "h": 47248159220,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47248159220),
//--TRIMMABLE-BOUNDARY-START(81607897588),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953191924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017962996,
        "f": 83886081
      },
      "n": "Terms",
      "d": 3518964,
      "h": 81607897588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81607897588),
//--TRIMMABLE-BOUNDARY-START(77312930292),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363257332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64428028404,
        "f": 83886081
      },
      "n": "Suffix",
      "d": 3518964,
      "h": 77312930292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312930292)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183388148),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3518964,
      "h": 17183388148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183388148)
  ],
  "h": 3518964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityTAndC`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityTAndC`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3518964)
        
        

        //--TRIMMABLE-BOUNDARY-START(2929140)
        $asm.$str(`$ydCm.LCCCM.CommunityFAQ`, ($self) => class CommunityFAQ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55837503988)
            /*string*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(55837503988)
            
            //--TRIMMABLE-BOUNDARY-START(17182798324)
            /*string*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17182798324)
            
            //--TRIMMABLE-BOUNDARY-START(12887831028)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887831028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887831028)
            
            //--TRIMMABLE-BOUNDARY-START(12887831028)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887831028)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Title = this.Title;
                copy.Description = this.Description;
                return copy;
            }
            static $h = 2929140;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837503988),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362667508,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542536692,
        "f": 83886081
      },
      "n": "Title",
      "d": 2929140,
      "h": 55837503988,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837503988),
//--TRIMMABLE-BOUNDARY-START(17182798324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772732916,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952602100,
        "f": 83886081
      },
      "n": "Description",
      "d": 2929140,
      "h": 17182798324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182798324)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887831028),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2929140,
      "h": 12887831028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887831028)
  ],
  "h": 2929140
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityFAQ`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityFAQ`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2929140)
        
        

        //--TRIMMABLE-BOUNDARY-START(2666996)
        $asm.$str(`$ydCm.LCCCM.AccountProfilePictureModel`, ($self) => class AccountProfilePictureModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21477503476)
            /*ResourceModel?*/ Picture = null;
            //--TRIMMABLE-BOUNDARY-END(21477503476)
            
            //--TRIMMABLE-BOUNDARY-START(8592601588)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592601588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592601588)
            
            //--TRIMMABLE-BOUNDARY-START(8592601588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592601588)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Picture = this.Picture;
                return copy;
            }
            static $h = 2666996;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477503476),
    {
      "p": 15279446,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182536180,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067438068,
        "f": 83886081
      },
      "n": "Picture",
      "d": 2666996,
      "h": 21477503476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477503476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592601588),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2666996,
      "h": 8592601588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592601588)
  ],
  "h": 2666996
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.AccountProfilePictureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}AccountProfilePictureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2666996)
        
        

        //--TRIMMABLE-BOUNDARY-START(635380)
        $asm.$str(`$ydCm.LCCCG.GemRewardModel`, ($self) => class GemRewardModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25770439156)
            /*GemIdentifierModel*/ Gem;
            //--TRIMMABLE-BOUNDARY-END(25770439156)
            
            //--TRIMMABLE-BOUNDARY-START(85899981300)
            /*string?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(85899981300)
            
            //--TRIMMABLE-BOUNDARY-START(21475471860)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(21475471860)
            
            //--TRIMMABLE-BOUNDARY-START(81605014004)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605014004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description ?? `${$.$strNN(this.Value)} ${$.$strNN(this.Gem.ToString())}`;
            }
            //--TRIMMABLE-BOUNDARY-END(81605014004)
            
            //--TRIMMABLE-BOUNDARY-START(17180504564)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180504564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180504564)
            
            //--TRIMMABLE-BOUNDARY-START(17180504564)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180504564)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Gem = this.Gem.$clone();
                copy.Value = this.Value;
                copy.Description = this.Description;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770439156)
                this.Gem = $.$default($.$ydCm.LCCCG.GemIdentifierModel);
                //--TRIMMABLE-BOUNDARY-END(25770439156)
                
            }
            static $h = 635380;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770439156),
    {
      "p": 373236,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950308340,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720112116,
        "f": 83886081
      },
      "n": "Gem",
      "d": 635380,
      "h": 25770439156,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2048,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 21,
              "t": 47614294
            },
            {
              "n": "OptionsReader",
              "v": $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$ydCm.LCCCG.GemIdentifierModel).$h,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770439156),
//--TRIMMABLE-BOUNDARY-START(85899981300),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540242932,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310046708,
        "f": 83886081
      },
      "n": "Value",
      "d": 635380,
      "h": 85899981300,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899981300),
//--TRIMMABLE-BOUNDARY-START(21475471860),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360373748,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130177524,
        "f": 83886081
      },
      "n": "Description",
      "d": 635380,
      "h": 21475471860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475471860)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605014004),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 635380,
      "h": 81605014004,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605014004)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180504564),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 635380,
      "h": 17180504564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180504564)
  ],
  "h": 635380
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemRewardModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemRewardModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(635380)
        
        

        //--TRIMMABLE-BOUNDARY-START(3256820)
        $asm.$str(`$ydCm.LCCCM.CommunityServiceCost`, ($self) => class CommunityServiceCost extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(124557308404)
            /*Dictionary<string, Money>?*/ Miscellaneous = null;
            //--TRIMMABLE-BOUNDARY-END(124557308404)
            
            //--TRIMMABLE-BOUNDARY-START(133147242996)
            /*Money*/ Service;
            //--TRIMMABLE-BOUNDARY-END(133147242996)
            
            //--TRIMMABLE-BOUNDARY-START(30068027892)
            /*Discount*/ Discount;
            //--TRIMMABLE-BOUNDARY-END(30068027892)
            
            //--TRIMMABLE-BOUNDARY-START(25773060596)
            /*Money?*/ Commission = null;
            //--TRIMMABLE-BOUNDARY-END(25773060596)
            
            //--TRIMMABLE-BOUNDARY-START(188981817844)
            /*Money*/ get_Item$1(/*string*/ name)
            {
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca1__;
                return ((__ca1__ = this.Miscellaneous) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$fPer.LCFCDM.Money, __ca1__, name) : new $.$fPer.LCFCDM.Money());
            }
            /*void*/ set_Item$1(/*string*/ name, /*Money*/ value)
            {
                this.Miscellaneous ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money))().$ctor$1();
                this.Miscellaneous.set_Item(name, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(188981817844)
            
            //--TRIMMABLE-BOUNDARY-START(38657962484)
            /*Money */ get Entry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017700852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca2__;
                return ((__ca2__ = this.Miscellaneous) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$fPer.LCFCDM.Money, __ca2__, "Entry") : new $.$fPer.LCFCDM.Money());
            }
            /*Money */ set Entry(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917046772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Miscellaneous ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money))().$ctor$1();
                this.Miscellaneous.set_Item("Entry", $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(38657962484)
            
            //--TRIMMABLE-BOUNDARY-START(128852275700)
            /*Money */ get MiscTotal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787504628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca3__;
                return ((__ca3__ = this.Miscellaneous) !== null ? $.$sl.SL.Enumerable.Aggregate$1($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, __ca3__.Values, new $.$fPer.LCFCDM.Money(), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/**/ a, /**/ b) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                }, $YEeDsg ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":3256820,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money());
            }
            //--TRIMMABLE-BOUNDARY-END(128852275700)
            
            //--TRIMMABLE-BOUNDARY-START(197571752436)
            /*Money */ get Total()
            {
                return $.$fPer.LCFCDM.Money.op_Addition(this.MiscTotal, this.Discount.Apply($.$clone(this.Service), 100));
            }
            //--TRIMMABLE-BOUNDARY-END(197571752436)
            
            //--TRIMMABLE-BOUNDARY-START(34362995188)
            /*Money */ get DiscountAmount()
            {
                return $.$fPer.LCFCDM.Money.op_Subtraction(this.Service, this.Discount.Apply($.$clone(this.Service), 100));
            }
            //--TRIMMABLE-BOUNDARY-END(34362995188)
            
            //--TRIMMABLE-BOUNDARY-START(120262341108)
            /*bool */ HasValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120262341108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Total);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262341108)
            
            //--TRIMMABLE-BOUNDARY-START(193276785140)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276785140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Total.ToString$1(0);
            }
            //--TRIMMABLE-BOUNDARY-END(193276785140)
            
            //--TRIMMABLE-BOUNDARY-START(21478093300)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478093300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478093300)
            
            //--TRIMMABLE-BOUNDARY-START(21478093300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21478093300)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Miscellaneous = this.Miscellaneous;
                copy.Service = this.Service.$clone();
                copy.Discount = this.Discount.$clone();
                copy.Commission = this.Commission?.$clone() ?? null;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133147242996)
                this.Service = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(133147242996)
                
                //--TRIMMABLE-BOUNDARY-START(30068027892)
                this.Discount = $.$default($.$fPer.LCFCDM.Discount);
                //--TRIMMABLE-BOUNDARY-END(30068027892)
                
                //--TRIMMABLE-BOUNDARY-START(25773060596)
                this.Commission = null;
                //--TRIMMABLE-BOUNDARY-END(25773060596)
                
            }
            static $h = 3256820;
            static $z = 41;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124557308404),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197570036,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176096915956,
        "f": 83886081
      },
      "n": "Miscellaneous",
      "d": 3256820,
      "h": 124557308404,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124557308404),
//--TRIMMABLE-BOUNDARY-START(133147242996),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377439220,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184686850548,
        "f": 83886081
      },
      "n": "Service",
      "d": 3256820,
      "h": 133147242996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133147242996),
//--TRIMMABLE-BOUNDARY-START(30068027892),
    {
      "p": 26446166,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837831668,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150327112180,
        "f": 83886081
      },
      "n": "Discount",
      "d": 3256820,
      "h": 30068027892,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068027892),
//--TRIMMABLE-BOUNDARY-START(25773060596),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247897076,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141737177588,
        "f": 83886081
      },
      "n": "Commission",
      "d": 3256820,
      "h": 25773060596,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773060596),
//--TRIMMABLE-BOUNDARY-START(188981817844),
    {
      "p": 27822422,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607635444,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167506981364,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 3256820,
      "h": 188981817844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188981817844),
//--TRIMMABLE-BOUNDARY-START(38657962484),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017700852,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158917046772,
        "f": 83886081
      },
      "n": "Entry",
      "d": 3256820,
      "h": 38657962484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657962484),
//--TRIMMABLE-BOUNDARY-START(128852275700),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787504628,
        "f": 50331649
      },
      "n": "MiscTotal",
      "d": 3256820,
      "h": 128852275700,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128852275700),
//--TRIMMABLE-BOUNDARY-START(197571752436),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967373812,
        "f": 50331649
      },
      "n": "Total",
      "d": 3256820,
      "h": 197571752436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197571752436),
//--TRIMMABLE-BOUNDARY-START(34362995188),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427766260,
        "f": 50331649
      },
      "n": "DiscountAmount",
      "d": 3256820,
      "h": 34362995188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362995188)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120262341108),
    {
      "r": 262145,
      "n": "HasValue",
      "d": 3256820,
      "h": 120262341108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120262341108),
//--TRIMMABLE-BOUNDARY-START(193276785140),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3256820,
      "h": 193276785140,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193276785140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478093300),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3256820,
      "h": 21478093300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478093300)
  ],
  "h": 3256820
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityServiceCost`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityServiceCost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3256820)
        
        

        //--TRIMMABLE-BOUNDARY-START(373236)
        $asm.$str(`$ydCm.LCCCG.GemIdentifierModel`, ($self) => class GemIdentifierModel extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81604751860)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(81604751860)
            
            //--TRIMMABLE-BOUNDARY-START(51539980788)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51539980788)
            
            //--TRIMMABLE-BOUNDARY-START(73014817268)
            static /*string? */ op_Implicit(/*GemIdentifierModel*/ gem)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014817268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return gem.Name;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014817268)
            
            //--TRIMMABLE-BOUNDARY-START(77309784564)
            static /*GemIdentifierModel */ op_Implicit$1(/*string?*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309784564);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$ydCm.LCCCG.GemIdentifierModel()
                        const $t1 = $.$ydCm.LCCCG.GemIdentifierModel;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = name;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309784564)
            
            //--TRIMMABLE-BOUNDARY-START(85899719156)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899719156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return this.Title ?? ((__ca1__ = this.Name) !== null ? $.$sl.SL.Enumerable.LastOrDefault$3($.$$.S.String, $.$$.S.String.Split$1.call(__ca1__, /*.*/ 46, 0)) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(85899719156)
            
            //--TRIMMABLE-BOUNDARY-START(25770177012)
            static /*GemIdentifierModel */ From(/*object*/ gem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770177012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$ydCm.LCCCG.GemIdentifierModel()
                    const $t2 = $.$ydCm.LCCCG.GemIdentifierModel;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Title = (($.$as(gem, $.$fPer.LCFC.IDisplayable))?.LCFC$IDisplayable$Title ?? null);
                    $i2.Name = $.$$.S.Object.GetType.call(gem).FullName;
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(25770177012)
            
            //--TRIMMABLE-BOUNDARY-START(21475209716)
            /*bool */ Equals$2(/*GemIdentifierModel*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475209716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name === other.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21475209716)
            
            //--TRIMMABLE-BOUNDARY-START(47245013492)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245013492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca2__;
                return ((__ca2__ = this.Name) !== null ? $.$$.S.String.GetHashCode.call(__ca2__) : super.GetHashCode());
            }
            //--TRIMMABLE-BOUNDARY-END(47245013492)
            
            //--TRIMMABLE-BOUNDARY-START(17180242420)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180242420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                if ($.$is(obj, $.$ydCm.LCCCG.GemIdentifierModel, { set $v($v){ other = $v; } }))
                {
                    return this.Name === other.Name;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(17180242420)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Community.Common.Gems.GemIdentifierModel>.Equals(LivingThing.Core.Community.Common.Gems.GemIdentifierModel)
            S$IEquatable$LivingThing$Core$Community$Common$Gems$GemIdentifierModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12885275124)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885275124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885275124)
            
            //--TRIMMABLE-BOUNDARY-START(12885275124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885275124)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Title = this.Title;
                copy.Name = this.Name;
                return copy;
            }
            static $h = 373236;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604751860),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950046196,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719849972,
        "f": 83886081
      },
      "n": "Title",
      "d": 373236,
      "h": 81604751860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604751860),
//--TRIMMABLE-BOUNDARY-START(51539980788),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360111604,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129915380,
        "f": 83886081
      },
      "n": "Name",
      "d": 373236,
      "h": 51539980788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539980788)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899719156),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 373236,
      "h": 85899719156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899719156),
//--TRIMMABLE-BOUNDARY-START(25770177012),
    {
      "r": 373236,
      "p": [
        {
          "n": "gem",
          "p": 131073
        }
      ],
      "n": "From",
      "d": 373236,
      "h": 25770177012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770177012),
//--TRIMMABLE-BOUNDARY-START(21475209716),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 373236
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 373236,
      "h": 21475209716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475209716),
//--TRIMMABLE-BOUNDARY-START(47245013492),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 373236,
      "h": 47245013492,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245013492),
//--TRIMMABLE-BOUNDARY-START(17180242420),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 373236,
      "h": 17180242420,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180242420)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885275124),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 373236,
      "h": 12885275124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885275124)
  ],
  "h": 373236
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$ydCm.LCCCG.GemIdentifierModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemIdentifierModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemIdentifierModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(373236)
        
        

        //--TRIMMABLE-BOUNDARY-START(1552884)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemModel`, ($self) => class HiddenGemModel extends $.$Iaui.LCFCM.DataComplexPropertyModel
        {
            //--TRIMMABLE-BOUNDARY-START(12886454772)
            /*HiddenGemTriggerEvent */ get Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656258548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$ydCm.LCCCG.HiddenGemTriggerEvent, "Event", 0);
            }
            /*HiddenGemTriggerEvent */ set Event(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325408244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$ydCm.LCCCG.HiddenGemTriggerEvent, value, "Event");
            }
            //--TRIMMABLE-BOUNDARY-END(12886454772)
            
            //--TRIMMABLE-BOUNDARY-START(17181422068)
            /*int */ get EventCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246193140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, "EventCount", 0);
            }
            /*int */ set EventCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915342836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "EventCount");
            }
            //--TRIMMABLE-BOUNDARY-END(17181422068)
            
            //--TRIMMABLE-BOUNDARY-START(133145539060)
            /*GemRewardModel */ get Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605931508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$ydCm.LCCCG.GemRewardModel, "Reward", new $.$ydCm.LCCCG.GemRewardModel());
            }
            /*GemRewardModel */ set Reward(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685146612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$ydCm.LCCCG.GemRewardModel, $.$clone(value), "Reward");
            }
            //--TRIMMABLE-BOUNDARY-END(133145539060)
            
            //--TRIMMABLE-BOUNDARY-START(8591487476)
            /*string? */ get CommentText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066323956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "CommentText", null);
            }
            /*string? */ set CommentText(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735473652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "CommentText");
            }
            //--TRIMMABLE-BOUNDARY-END(8591487476)
            
            //--TRIMMABLE-BOUNDARY-START(128850571764)
            /*bool */ get Paid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015996916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Boolean, "Paid", false);
            }
            /*bool */ set Paid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095212020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Boolean, value, "Paid");
            }
            //--TRIMMABLE-BOUNDARY-END(128850571764)
            
            //--TRIMMABLE-BOUNDARY-START(223339852276)
            /*HiddenGemState */ get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195866100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$ydCm.LCCCG.HiddenGemState, "State", 0);
            }
            /*HiddenGemState */ set State(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275081204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$ydCm.LCCCG.HiddenGemState, value, "State");
            }
            //--TRIMMABLE-BOUNDARY-END(223339852276)
            
            //--TRIMMABLE-BOUNDARY-START(21476389364)
            /*DateTime */ get FoundTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836127732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.DateTime, "FoundTime", new $.$$.S.DateTime());
            }
            /*DateTime */ set FoundTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505277428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.DateTime, value, "FoundTime");
            }
            //--TRIMMABLE-BOUNDARY-END(21476389364)
            
            //--TRIMMABLE-BOUNDARY-START(120260637172)
            /*bool */ get IsHidden()
            {
                return $.$ydCm.LCCCG.HiddenGemStateExtension.IsHidden(this);
            }
            //--TRIMMABLE-BOUNDARY-END(120260637172)
            
            //--TRIMMABLE-BOUNDARY-START(244814688756)
            /*string? */ get WinnerName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965669876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerName", null);
            }
            /*string? */ set WinnerName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044884980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerName");
            }
            //--TRIMMABLE-BOUNDARY-END(244814688756)
            
            //--TRIMMABLE-BOUNDARY-START(240519721460)
            /*string? */ get WinnerId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375735284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerId", null);
            }
            /*string? */ set WinnerId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454950388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerId");
            }
            //--TRIMMABLE-BOUNDARY-END(240519721460)
            
            //--TRIMMABLE-BOUNDARY-START(236224754164)
            /*string? */ get WinnerIconId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785800692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerIconId", null);
            }
            /*string? */ set WinnerIconId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865015796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerIconId");
            }
            //--TRIMMABLE-BOUNDARY-END(236224754164)
            
            //--TRIMMABLE-BOUNDARY-START(231929786868)
            /*ValueTask<bool> */ Validate(/*IObservableDataDescriptor*/ data, /*SchemaContext*/ schema, /*out IEnumerable<string>?*/ errors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929786868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                errors.$v = null;
                let $switch1 = data.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Name;
                switch($switch1)
                {
                    case "Event":
                    if (this.Event === 0/*HiddenGemTriggerEvent.None*/)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Please chose an event");
                    }
                    break;
                    case "Reward":
                    if (this.Reward.Gem.Name === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Please choose a reward");
                    }
                    break;
                }
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(231929786868)
            
            //--TRIMMABLE-BOUNDARY-START(124555604468)
            /*bool */ IsValid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555604468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Event !== 0/*HiddenGemTriggerEvent.None*/ && this.Reward.Gem.Name !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(124555604468)
            
            //--TRIMMABLE-BOUNDARY-START(227634819572)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634819572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Event === 0/*HiddenGemTriggerEvent.None*/)
                {
                    return $.$$.S.Object.ToString.call(this);
                }
                /*var*/ let ev = $.$$.S.Math.Max$4(1, this.EventCount);
                return `The ${$.$strNN(ev)}${$.$strNN($.$fPer.LCFCS$6.NumberExtension.TH(ev))} person to ${$.$strNN($.$$.S.String.ToLower.call($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$ydCm.LCCCG.HiddenGemTriggerEvent, $.$$.S.UInt32, this.Event))))}${$.$strNN((this.Event === 6/*HiddenGemTriggerEvent.QuizAnswer*/ ? ` (${$.$strNN(this.CommentText)})` : ""))} this post wins ${$.$strNN((this.Reward.Description ?? `${$.$strNN(this.Reward.Value)} ${$.$strNN(this.Reward.Gem.ToString())}`))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(227634819572)
            
            //--TRIMMABLE-BOUNDARY-START(34362274292)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.Event.get
            get LCCCG$IHiddenGemState$Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592470516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Event;
            }
            //--TRIMMABLE-BOUNDARY-END(34362274292)
            
            //--TRIMMABLE-BOUNDARY-START(42952208884)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.EventCount.get
            get LCCCG$IHiddenGemState$EventCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887437812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EventCount;
            }
            //--TRIMMABLE-BOUNDARY-END(42952208884)
            
            //--TRIMMABLE-BOUNDARY-START(25772339700)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.CommentText.get
            get LCCCG$IHiddenGemState$CommentText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297503220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CommentText;
            }
            //--TRIMMABLE-BOUNDARY-END(25772339700)
            
            //--TRIMMABLE-BOUNDARY-START(60132078068)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.State.get
            get LCCCG$IHiddenGemState$State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016979956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.State;
            }
            //--TRIMMABLE-BOUNDARY-END(60132078068)
            
            //--TRIMMABLE-BOUNDARY-START(68722012660)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.State.set
            set LCCCG$IHiddenGemState$State(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016979956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.State = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68722012660)
            
            //--TRIMMABLE-BOUNDARY-START(51542143476)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IHiddenGemState.FoundTime.get
            get LCCCG$IHiddenGemState$FoundTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182405108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FoundTime;
            }
            //--TRIMMABLE-BOUNDARY-END(51542143476)
            
            //--TRIMMABLE-BOUNDARY-START(34362143220)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerName.get
            get LCCCG$IGemStateModel$WinnerName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542012404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerName;
            }
            //--TRIMMABLE-BOUNDARY-END(34362143220)
            
            //--TRIMMABLE-BOUNDARY-START(25772208628)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerId.get
            get LCCCG$IGemStateModel$WinnerId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247045108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerId;
            }
            //--TRIMMABLE-BOUNDARY-END(25772208628)
            
            //--TRIMMABLE-BOUNDARY-START(17182274036)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.WinnerIconId.get
            get LCCCG$IGemStateModel$WinnerIconId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952077812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WinnerIconId;
            }
            //--TRIMMABLE-BOUNDARY-END(17182274036)
            
            //--TRIMMABLE-BOUNDARY-START(8592339444)
            //Generated interface implemetation for LivingThing.Core.Community.Common.Gems.IGemStateModel.Reward.get
            get LCCCG$IGemStateModel$Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657110516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reward;
            }
            //--TRIMMABLE-BOUNDARY-END(8592339444)
            
            //--TRIMMABLE-BOUNDARY-START(4296520180)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296520180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296520180)
            
            //--TRIMMABLE-BOUNDARY-START(4296520180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296520180)
            
            static $h = 1552884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataComplexPropertyModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886454772),
    {
      "p": 2273780,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656258548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325408244,
        "f": 83886081
      },
      "n": "Event",
      "d": 1552884,
      "h": 12886454772,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886454772),
//--TRIMMABLE-BOUNDARY-START(17181422068),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246193140,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915342836,
        "f": 83886081
      },
      "n": "EventCount",
      "d": 1552884,
      "h": 17181422068,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181422068),
//--TRIMMABLE-BOUNDARY-START(133145539060),
    {
      "p": 635380,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605931508,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685146612,
        "f": 83886081
      },
      "n": "Reward",
      "d": 1552884,
      "h": 133145539060,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2048,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145539060),
//--TRIMMABLE-BOUNDARY-START(8591487476),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066323956,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735473652,
        "f": 83886081
      },
      "n": "CommentText",
      "d": 1552884,
      "h": 8591487476,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2048,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591487476),
//--TRIMMABLE-BOUNDARY-START(128850571764),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015996916,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095212020,
        "f": 83886081
      },
      "n": "Paid",
      "d": 1552884,
      "h": 128850571764,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850571764),
//--TRIMMABLE-BOUNDARY-START(223339852276),
    {
      "p": 2077172,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195866100,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193275081204,
        "f": 83886081
      },
      "n": "State",
      "d": 1552884,
      "h": 223339852276,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339852276),
//--TRIMMABLE-BOUNDARY-START(21476389364),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836127732,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505277428,
        "f": 83886081
      },
      "n": "FoundTime",
      "d": 1552884,
      "h": 21476389364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476389364),
//--TRIMMABLE-BOUNDARY-START(120260637172),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426062324,
        "f": 50331649
      },
      "n": "IsHidden",
      "d": 1552884,
      "h": 120260637172,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260637172),
//--TRIMMABLE-BOUNDARY-START(244814688756),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965669876,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044884980,
        "f": 83886081
      },
      "n": "WinnerName",
      "d": 1552884,
      "h": 244814688756,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814688756),
//--TRIMMABLE-BOUNDARY-START(240519721460),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375735284,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454950388,
        "f": 83886081
      },
      "n": "WinnerId",
      "d": 1552884,
      "h": 240519721460,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519721460),
//--TRIMMABLE-BOUNDARY-START(236224754164),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785800692,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201865015796,
        "f": 83886081
      },
      "n": "WinnerIconId",
      "d": 1552884,
      "h": 236224754164,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224754164)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(231929786868),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "data",
          "p": 40536406
        },
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "errors",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 2
        }
      ],
      "n": "Validate",
      "d": 1552884,
      "h": 231929786868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929786868),
//--TRIMMABLE-BOUNDARY-START(124555604468),
    {
      "r": 262145,
      "n": "IsValid",
      "d": 1552884,
      "h": 124555604468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555604468),
//--TRIMMABLE-BOUNDARY-START(227634819572),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1552884,
      "h": 227634819572,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227634819572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296520180),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1552884,
      "h": 4296520180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296520180)
  ],
  "h": 1552884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCG.IHiddenGemState, $.$ydCm.LCCCG.IGemStateModel, $.$Iaui.LCFCM.IMultipleDataComplexPropertyDiscriminateByIndexModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1552884)
        
        

        //--TRIMMABLE-BOUNDARY-START(5222900)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationService<,>`, (TCategory, TPost) => $asm.$gt(`$ydCm.LCCCS.ICommunityApplicationService<,>`, [TCategory, TPost], ($self) => class ICommunityApplicationService$$$
        {
            static $H = 5222900;
            static $h = 5222900;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TCategory?.$h??1572864,
      "n": "TCategory",
      "c": [1698228
      ]
    },
    {
      "h": TPost?.$h??1638400,
      "n": "TPost",
      "c": [16771508
      ]
    }
  ],
  "r": 2,
  "H": 5222900,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ydCm.LCCCS.ICommunityApplicationService$$$$(TCategory, TPost, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationService<${TCategory?.$fullName},${TPost?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationService$${TCategory?.$getFullName(separator)}$${TPost?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5222900)
        
        

        //--TRIMMABLE-BOUNDARY-START(5091828)
        $asm.$cls(`$ydCm.LCCCS.ICommunityApplicationRemoteService_Mocking`, ($self) => class ICommunityApplicationRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4300059124)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300059124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300059124)
            
            //--TRIMMABLE-BOUNDARY-START(8595026420)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCCCS$ICommunityApplicationRemoteService$CheckIn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595026420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$ydCm.LCCCS.ICommunityApplicationRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i1.MethodName = "CheckIn";
                    return $i1;
                })();
                return this.InvokeAsync($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8595026420)
            
            //--TRIMMABLE-BOUNDARY-START(17184961012)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Common.Models.CommunityMetricsModel>> */ LCCCS$ICommunityApplicationRemoteService$GetMetrics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184961012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$ydCm.LCCCS.ICommunityApplicationRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityMetricsModel).$type;
                    $i2.MethodName = "GetMetrics";
                    return $i2;
                })();
                return this.InvokeAsync($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityMetricsModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17184961012)
            
            //--TRIMMABLE-BOUNDARY-START(21479928308)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Community.Common.Models.CommunityTAndC>> */ LCCCS$ICommunityApplicationRemoteService$GetTermsAndCondition(/*string*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479928308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$ydCm.LCCCS.ICommunityApplicationRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityTAndC).$type;
                    $i3.MethodName = "GetTermsAndCondition";
                    return $i3;
                })();
                return this.InvokeAsync($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$ydCm.LCCCM.CommunityTAndC), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, app) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21479928308)
            
            //--TRIMMABLE-BOUNDARY-START(12889993716)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Common.Models.CommunityFAQ>>> */ LCCCS$ICommunityApplicationRemoteService$GetFAQ(/*string*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889993716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$ydCm.LCCCS.ICommunityApplicationRemoteService.$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityFAQ)).$type;
                    $i4.MethodName = "GetFAQ";
                    return $i4;
                })();
                return this.InvokeAsync($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityFAQ)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, app) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12889993716)
            
            //--TRIMMABLE-BOUNDARY-START(25774895604)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.DataId>> */ LCCCS$ICommunityApplicationRemoteService$SetGlobalGemClaimed(/*string*/ gemId, /*string?*/ winningPostId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774895604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$ydCm.LCCCS.ICommunityApplicationRemoteService.$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.DataId).$type;
                    $i5.MethodName = "SetGlobalGemClaimed";
                    return $i5;
                })();
                return this.InvokeAsync($.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.DataId), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, gemId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, winningPostId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25774895604)
            
            static $h = 5091828;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300059124),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5091828,
      "h": 4300059124,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4300059124)
  ],
  "h": 5091828
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$ydCm.LCCCS.ICommunityApplicationRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Services.ICommunityApplicationRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Services${separator}ICommunityApplicationRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5091828)
        
        

        //--TRIMMABLE-BOUNDARY-START(2273780)
        $asm.$str(`$ydCm.LCCCG.HiddenGemTriggerEvent`, ($self) => class HiddenGemTriggerEvent extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Open = 1;
            static CommentOn = 2;
            static AccountCommentOn = 3;
            static ReactTo = 4;
            static Share = 5;
            static QuizAnswer = 6;
            static DailyPost = 1073741823;
            static CummulativelyPost = 1073741824;
            static DailySignup = 1073741825;
            static CummulativelySignup = 1073741826;
            static FirstAccountPost = 1073741827;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2273780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Open": 1n,
                    "CommentOn": 2n,
                    "AccountCommentOn": 3n,
                    "ReactTo": 4n,
                    "Share": 5n,
                    "QuizAnswer": 6n,
                    "DailyPost": 1073741823n,
                    "CummulativelyPost": 1073741824n,
                    "DailySignup": 1073741825n,
                    "CummulativelySignup": 1073741826n,
                    "FirstAccountPost": 1073741827n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297241076)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297241076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297241076)
            
            //--TRIMMABLE-BOUNDARY-START(4297241076)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297241076)
            
            static $h = 2273780;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656979444),
    {
      "t": 2273780,
      "n": "None",
      "d": 2273780,
      "h": 38656979444,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656979444),
//--TRIMMABLE-BOUNDARY-START(42951946740),
    {
      "t": 2273780,
      "n": "Open",
      "d": 2273780,
      "h": 42951946740,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951946740),
//--TRIMMABLE-BOUNDARY-START(12887175668),
    {
      "t": 2273780,
      "n": "CommentOn",
      "d": 2273780,
      "h": 12887175668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887175668),
//--TRIMMABLE-BOUNDARY-START(8592208372),
    {
      "t": 2273780,
      "n": "AccountCommentOn",
      "d": 2273780,
      "h": 8592208372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592208372),
//--TRIMMABLE-BOUNDARY-START(51541881332),
    {
      "t": 2273780,
      "n": "ReactTo",
      "d": 2273780,
      "h": 51541881332,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541881332),
//--TRIMMABLE-BOUNDARY-START(55836848628),
    {
      "t": 2273780,
      "n": "Share",
      "d": 2273780,
      "h": 55836848628,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836848628),
//--TRIMMABLE-BOUNDARY-START(47246914036),
    {
      "t": 2273780,
      "n": "QuizAnswer",
      "d": 2273780,
      "h": 47246914036,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246914036),
//--TRIMMABLE-BOUNDARY-START(25772077556),
    {
      "t": 2273780,
      "n": "DailyPost",
      "d": 2273780,
      "h": 25772077556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772077556),
//--TRIMMABLE-BOUNDARY-START(17182142964),
    {
      "t": 2273780,
      "n": "CummulativelyPost",
      "d": 2273780,
      "h": 17182142964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182142964),
//--TRIMMABLE-BOUNDARY-START(30067044852),
    {
      "t": 2273780,
      "n": "DailySignup",
      "d": 2273780,
      "h": 30067044852,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067044852),
//--TRIMMABLE-BOUNDARY-START(21477110260),
    {
      "t": 2273780,
      "n": "CummulativelySignup",
      "d": 2273780,
      "h": 21477110260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477110260),
//--TRIMMABLE-BOUNDARY-START(34362012148),
    {
      "t": 2273780,
      "n": "FirstAccountPost",
      "d": 2273780,
      "h": 34362012148,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362012148)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297241076),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2273780,
      "h": 4297241076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297241076)
  ],
  "h": 2273780
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemTriggerEvent`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemTriggerEvent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2273780)
        
        

        //--TRIMMABLE-BOUNDARY-START(2077172)
        $asm.$str(`$ydCm.LCCCG.HiddenGemState`, ($self) => class HiddenGemState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Found = 1;
            static Claiming = 2;
            static Claimed = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2077172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Found": 1n,
                    "Claiming": 2n,
                    "Claimed": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297044468)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297044468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297044468)
            
            //--TRIMMABLE-BOUNDARY-START(4297044468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297044468)
            
            static $h = 2077172;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476913652),
    {
      "t": 2077172,
      "n": "None",
      "d": 2077172,
      "h": 21476913652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476913652),
//--TRIMMABLE-BOUNDARY-START(17181946356),
    {
      "t": 2077172,
      "n": "Found",
      "d": 2077172,
      "h": 17181946356,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181946356),
//--TRIMMABLE-BOUNDARY-START(12886979060),
    {
      "t": 2077172,
      "n": "Claiming",
      "d": 2077172,
      "h": 12886979060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886979060),
//--TRIMMABLE-BOUNDARY-START(8592011764),
    {
      "t": 2077172,
      "n": "Claimed",
      "d": 2077172,
      "h": 8592011764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592011764)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297044468),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2077172,
      "h": 4297044468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297044468)
  ],
  "h": 2077172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2077172)
        
        

        //--TRIMMABLE-BOUNDARY-START(897524)
        $asm.$str(`$ydCm.LCCCG.HiddenGemAccountEligibility`, ($self) => class HiddenGemAccountEligibility extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static HasPhoneNumberVerified = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(897524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "HasPhoneNumberVerified": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295864820)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295864820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295864820)
            
            //--TRIMMABLE-BOUNDARY-START(4295864820)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295864820)
            
            static $h = 897524;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885799412),
    {
      "t": 897524,
      "n": "None",
      "d": 897524,
      "h": 12885799412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885799412),
//--TRIMMABLE-BOUNDARY-START(8590832116),
    {
      "t": 897524,
      "n": "HasPhoneNumberVerified",
      "d": 897524,
      "h": 8590832116,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590832116)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295864820),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 897524,
      "h": 4295864820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295864820)
  ],
  "h": 897524,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemAccountEligibility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemAccountEligibility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(897524)
        
        

        //--TRIMMABLE-BOUNDARY-START(4239860)
        $asm.$cls(`$ydCm.LCCCM.CreatorLaunchPadFeatureModel`, ($self) => class CreatorLaunchPadFeatureModel extends $.$LCOv.LCFCPM$1.AccountFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(25774043636)
            static /*CreatorLaunchPadFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25774043636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel, ($.$cast(target, $.$LCOv.LCFCPM$1.AccountModel)), $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(25774043636)
            
            //--TRIMMABLE-BOUNDARY-START(81608618484)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608618484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("$"/*PrefixIdentifier*/)}CreatorLaunchPad`;
            }
            //--TRIMMABLE-BOUNDARY-END(81608618484)
            
            //--TRIMMABLE-BOUNDARY-START(90198553076)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133782004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "Name", null);
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128853258740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "Name");
            }
            //--TRIMMABLE-BOUNDARY-END(90198553076)
            
            //--TRIMMABLE-BOUNDARY-START(21479076340)
            /*string? */ get CreatorName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953912820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "CreatorName", null);
            }
            /*string? */ set CreatorName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111673389556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "CreatorName");
            }
            //--TRIMMABLE-BOUNDARY-END(21479076340)
            
            //--TRIMMABLE-BOUNDARY-START(85903585780)
            /*AccountHandle*/ Handle;
            //--TRIMMABLE-BOUNDARY-END(85903585780)
            
            //--TRIMMABLE-BOUNDARY-START(94493520372)
            /*int */ get Quota()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723716596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, "Quota", 0);
            }
            /*int */ set Quota(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137443193332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "Quota");
            }
            //--TRIMMABLE-BOUNDARY-END(94493520372)
            
            //--TRIMMABLE-BOUNDARY-START(17184109044)
            /*Money */ get Bid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363978228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$fPer.LCFCDM.Money, "Bid", new $.$fPer.LCFCDM.Money());
            }
            /*Money */ set Bid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103083454964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$fPer.LCFCDM.Money, $.$clone(value), "Bid");
            }
            //--TRIMMABLE-BOUNDARY-END(17184109044)
            
            //--TRIMMABLE-BOUNDARY-START(150328095220)
            /*AccountSocialSettings?*/ SocialSettings = null;
            //--TRIMMABLE-BOUNDARY-END(150328095220)
            
            //--TRIMMABLE-BOUNDARY-START(154623062516)
            /*ValueTask<bool> */ Validate(/*IObservableDataDescriptor*/ data, /*SchemaContext*/ schema, /*out IEnumerable<string>?*/ errors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154623062516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                errors.$v = null;
                let $switch1 = data.LCFCD$1$IObservableDataDescriptor$Property.LCFCD$1$IPropertyDescriptor$Name;
                switch($switch1)
                {
                    case "Quota":
                    if (this.Quota < 100)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Minimum quota is 100");
                    }
                    break;
                    case "SocialSettings":
                    if (this.SocialSettings === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("SocialSettings is required");
                    }
                    if (this.SocialSettings.FacebookProfile === null && this.SocialSettings.LinkedInProfile === null && this.SocialSettings.TiktokProfile === null && this.SocialSettings.TwitterProfile === null && this.SocialSettings.YoutubeProfile === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("At least one social profile is required");
                    }
                    break;
                }
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(154623062516)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4311976278)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataDescriptorValidator.Validate(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext, out System.Collections.Generic.IEnumerable<string>?)
            LCFCD$IDataDescriptorValidator$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311976278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311976278)
            
            //--TRIMMABLE-BOUNDARY-START(12889141748)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889141748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889141748)
            
            //--TRIMMABLE-BOUNDARY-START(12889141748)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(12889141748)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85903585780)
                this.Handle = $.$default($.$LCOv.LCFCPM$1.AccountHandle);
                //--TRIMMABLE-BOUNDARY-END(85903585780)
                
            }
            static $h = 4239860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90198553076),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133782004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128853258740,
        "f": 83886081
      },
      "n": "Name",
      "d": 4239860,
      "h": 90198553076,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your real name?\r\n\r\nThis is not displayed on your profile. Used by Zoey team only to verify you.",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-identifier"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90198553076),
//--TRIMMABLE-BOUNDARY-START(21479076340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953912820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111673389556,
        "f": 83886081
      },
      "n": "CreatorName",
      "d": 4239860,
      "h": 21479076340,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your stage name?\r\n\r\nYour creator name will be shown to the community",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-id-card"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479076340),
//--TRIMMABLE-BOUNDARY-START(85903585780),
    {
      "p": 7793076,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543847412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120263324148,
        "f": 83886081
      },
      "n": "Handle",
      "d": 4239860,
      "h": 85903585780,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your profile short name?\r\n\r\nDisplayed with an @ in front of it, is unique to you only on Zoey.",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-at"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85903585780),
//--TRIMMABLE-BOUNDARY-START(94493520372),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723716596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137443193332,
        "f": 83886081
      },
      "n": "Quota",
      "d": 4239860,
      "h": 94493520372,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Of the 1M(10M\u002B engagements) signups quota of Zoey goal, what portion do you want to take upon yourself?",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-percent"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94493520372),
//--TRIMMABLE-BOUNDARY-START(17184109044),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363978228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103083454964,
        "f": 83886081
      },
      "n": "Bid",
      "d": 4239860,
      "h": 17184109044,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "How much would you have Zoey pay you on delivering this quota?",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-currency-ngn"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17184109044),
//--TRIMMABLE-BOUNDARY-START(150328095220),
    {
      "p": 27126196,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77313651188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146033127924,
        "f": 83886081
      },
      "n": "SocialSettings",
      "d": 4239860,
      "h": 150328095220,
      "f": 2097153,
      "a": [
        {
          "t": 2228263,
          "c": 8592162855
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Your current social media profile?\r\n\r\nProvide at least one.",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-web"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150328095220)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25774043636),
    {
      "r": 4239860,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 4239860,
      "h": 25774043636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25774043636),
//--TRIMMABLE-BOUNDARY-START(81608618484),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 4239860,
      "h": 81608618484,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81608618484),
//--TRIMMABLE-BOUNDARY-START(154623062516),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "data",
          "p": 40536406
        },
        {
          "n": "schema",
          "p": 2394454
        },
        {
          "n": "errors",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 2
        }
      ],
      "n": "Validate",
      "d": 4239860,
      "h": 154623062516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154623062516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889141748),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 4239860,
      "h": 12889141748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889141748)
  ],
  "h": 4239860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$fPer.LCFCD.IDataFeatureModel$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel), $.$fPer.LCFCD.IDataDescriptorValidator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CreatorLaunchPadFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4239860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1028596)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundFeatureModel`, ($self) => class HiddenGemFoundFeatureModel extends $.$LCOv.LCFCPMS.StatusFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(8590963188)
            /*HiddenGemTriggerEvent */ get Event()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065799668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$ydCm.LCCCG.HiddenGemTriggerEvent, "Event", 0);
            }
            /*HiddenGemTriggerEvent */ set Event(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785276404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$ydCm.LCCCG.HiddenGemTriggerEvent, value, "Event");
            }
            //--TRIMMABLE-BOUNDARY-END(8590963188)
            
            //--TRIMMABLE-BOUNDARY-START(12885930484)
            /*int */ get EventCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655734260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.Int32, "EventCount", 0);
            }
            /*int */ set EventCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375210996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.Int32, value, "EventCount");
            }
            //--TRIMMABLE-BOUNDARY-END(12885930484)
            
            //--TRIMMABLE-BOUNDARY-START(90195341812)
            /*GemRewardModel */ get Reward()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835603444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$ydCm.LCCCG.GemRewardModel, "Reward", new $.$ydCm.LCCCG.GemRewardModel());
            }
            /*GemRewardModel */ set Reward(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555080180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$ydCm.LCCCG.GemRewardModel, $.$clone(value), "Reward");
            }
            //--TRIMMABLE-BOUNDARY-END(90195341812)
            
            //--TRIMMABLE-BOUNDARY-START(17180897780)
            /*DateTime */ get FoundTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245668852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.DateTime, "FoundTime", new $.$$.S.DateTime());
            }
            /*DateTime */ set FoundTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965145588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.DateTime, value, "FoundTime");
            }
            //--TRIMMABLE-BOUNDARY-END(17180897780)
            
            //--TRIMMABLE-BOUNDARY-START(167504753140)
            /*string? */ get WinnerName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605407220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerName", null);
            }
            /*string? */ set WinnerName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324883956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerName");
            }
            //--TRIMMABLE-BOUNDARY-END(167504753140)
            
            //--TRIMMABLE-BOUNDARY-START(163209785844)
            /*string? */ get WinnerId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015472628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerId", null);
            }
            /*string? */ set WinnerId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734949364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerId");
            }
            //--TRIMMABLE-BOUNDARY-END(163209785844)
            
            //--TRIMMABLE-BOUNDARY-START(158914818548)
            /*string? */ get WinnerIconId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425538036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty($.$$.S.String, "WinnerIconId", null);
            }
            /*string? */ set WinnerIconId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145014772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperty($.$$.S.String, value, "WinnerIconId");
            }
            //--TRIMMABLE-BOUNDARY-END(158914818548)
            
            //--TRIMMABLE-BOUNDARY-START(21475865076)
            static /*HiddenGemFoundFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475865076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$ydCm.LCCCG.HiddenGemFoundFeatureModel, ($.$cast(target, $.$LCOv.LCFCPM$1.PostBaseModel)), $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(21475865076)
            
            //--TRIMMABLE-BOUNDARY-START(85900374516)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900374516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("$"/*PrefixIdentifier*/)}HiddenGemFound`;
            }
            //--TRIMMABLE-BOUNDARY-END(85900374516)
            
            //--TRIMMABLE-BOUNDARY-START(154619851252)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619851252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Event === 0/*HiddenGemTriggerEvent.None*/)
                {
                    return $.$$.S.Object.ToString.call(this);
                }
                /*var*/ let ev = $.$$.S.Math.Max$4(1, this.EventCount);
                /*var*/ let mod = ev % 10;
                /*string*/ let th = "th";
                if (mod === 1)
                {
                    th = "st";
                }
                else if (mod === 2)
                {
                    th = "nd";
                }
                else if (mod === 3)
                {
                    th = "rd";
                }
                return `The ${$.$strNN(ev)}${$.$strNN(th)} person to ${$.$strNN($.$$.S.String.ToLower.call($.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$ydCm.LCCCG.HiddenGemTriggerEvent, $.$$.S.UInt32, this.Event))))} this post wins ${$.$strNN((this.Reward.Description ?? `${$.$strNN(this.Reward.Value)} ${$.$strNN(this.Reward.Gem.ToString())}`))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(154619851252)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4295995892)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295995892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295995892)
            
            //--TRIMMABLE-BOUNDARY-START(4295995892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295995892)
            
            static $h = 1028596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMS.StatusFeatureModel$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590963188),
    {
      "p": 2273780,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065799668,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785276404,
        "f": 83886081
      },
      "n": "Event",
      "d": 1028596,
      "h": 8590963188,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590963188),
//--TRIMMABLE-BOUNDARY-START(12885930484),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655734260,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375210996,
        "f": 83886081
      },
      "n": "EventCount",
      "d": 1028596,
      "h": 12885930484,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885930484),
//--TRIMMABLE-BOUNDARY-START(90195341812),
    {
      "p": 635380,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835603444,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555080180,
        "f": 83886081
      },
      "n": "Reward",
      "d": 1028596,
      "h": 90195341812,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2048,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195341812),
//--TRIMMABLE-BOUNDARY-START(17180897780),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245668852,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965145588,
        "f": 83886081
      },
      "n": "FoundTime",
      "d": 1028596,
      "h": 17180897780,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180897780),
//--TRIMMABLE-BOUNDARY-START(167504753140),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605407220,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324883956,
        "f": 83886081
      },
      "n": "WinnerName",
      "d": 1028596,
      "h": 167504753140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504753140),
//--TRIMMABLE-BOUNDARY-START(163209785844),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015472628,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734949364,
        "f": 83886081
      },
      "n": "WinnerId",
      "d": 1028596,
      "h": 163209785844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209785844),
//--TRIMMABLE-BOUNDARY-START(158914818548),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425538036,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145014772,
        "f": 83886081
      },
      "n": "WinnerIconId",
      "d": 1028596,
      "h": 158914818548,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914818548)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475865076),
    {
      "r": 1028596,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 1028596,
      "h": 21475865076,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475865076),
//--TRIMMABLE-BOUNDARY-START(85900374516),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 1028596,
      "h": 85900374516,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85900374516),
//--TRIMMABLE-BOUNDARY-START(154619851252),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1028596,
      "h": 154619851252,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619851252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295995892),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1028596,
      "h": 4295995892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295995892)
  ],
  "h": 1028596
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$LCOv.LCFCPMS.IStatusFeatureModel, $.$fPer.LCFCD.IOrderableData, $.$fPer.LCFCD.IOrderedData, $.$fPer.LCFCD.IDataFeatureModel$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1028596)
        
        

        //--TRIMMABLE-BOUNDARY-START(3584500)
        $asm.$cls(`$ydCm.LCCCM.CommunityUserPreference`, ($self) => class CommunityUserPreference extends $.$yleQ.LCFCA.ApplicationBaseUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(51543192052)
            /*bool*/ Saved = false;
            //--TRIMMABLE-BOUNDARY-END(51543192052)
            
            //--TRIMMABLE-BOUNDARY-START(4298551796)
            /*string */ get _()
            {
                return "Zoey is a group of apps and services. One app to rule them all.";
            }
            //--TRIMMABLE-BOUNDARY-END(4298551796)
            
            //--TRIMMABLE-BOUNDARY-START(8593519092)
            /*bool*/ _enablePreviewFeatures = false;
            //--TRIMMABLE-BOUNDARY-END(8593519092)
            
            //--TRIMMABLE-BOUNDARY-START(21478420980)
            /*bool */ get EnablePreviewFeatures()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658290164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._enablePreviewFeatures;
            }
            /*bool */ set EnablePreviewFeatures(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133126644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._enablePreviewFeatures !== value)
                {
                    this._enablePreviewFeatures = value;
                    this.RaisePropertyChanged("EnablePreviewFeatures");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478420980)
            
            //--TRIMMABLE-BOUNDARY-START(17183453684)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183453684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183453684)
            
            //--TRIMMABLE-BOUNDARY-START(17183453684)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17183453684)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51543192052)
                this.Saved = true;
                //--TRIMMABLE-BOUNDARY-END(51543192052)
                
            }
            static $h = 3584500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$yleQ.LCFCA.ApplicationBaseUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543192052),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248224756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68723061236,
        "f": 83886081
      },
      "n": "Saved",
      "d": 3584500,
      "h": 51543192052,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543192052),
//--TRIMMABLE-BOUNDARY-START(4298551796),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068355572,
        "f": 50331649
      },
      "n": "_",
      "d": 3584500,
      "h": 4298551796,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Welcome to Zoey",
              "t": 1310721
            },
            {
              "n": "Description",
              "v": "Let\u0027s get you started.",
              "t": 1310721
            },
            {
              "n": "InputType",
              "v": 3,
              "t": 47614294
            },
            {
              "n": "Exclude",
              "v": 16,
              "t": 2722134
            }
          ]
        },
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4298551796),
//--TRIMMABLE-BOUNDARY-START(21478420980),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658290164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133126644,
        "f": 83886081
      },
      "n": "EnablePreviewFeatures",
      "d": 3584500,
      "h": 21478420980,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Title",
              "v": "Show Beta Apps",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478420980)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593519092),
    {
      "t": 262145,
      "n": "_enablePreviewFeatures",
      "d": 3584500,
      "h": 8593519092,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593519092)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183453684),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3584500,
      "h": 17183453684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183453684)
  ],
  "h": 3584500,
  "a": [
    {
      "t": 44665174,
      "c": 4339632470
    },
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3584500)
        
        

        //--TRIMMABLE-BOUNDARY-START(1815028)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemsFeatureModel`, ($self) => class HiddenGemsFeatureModel extends $.$LCOv.LCFCPMS.StatusFeatureModel$$($self)
        {
            //--TRIMMABLE-BOUNDARY-START(12886716916)
            static /*HiddenGemsFeatureModel? */ From(/*IDataModel*/ target, /*IDataModel?*/ context, /*bool?*/ createIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886716916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Iaui.LCFCM.DataPropertiesExtensions.GetFeatures($.$ydCm.LCCCG.HiddenGemsFeatureModel, ($.$cast(target, $.$LCOv.LCFCPM$1.PostBaseModel)), $.$ydCm.LCCCG.HiddenGemsFeatureModel.GetFeatureKey(context), createIfNotExist);
            }
            //--TRIMMABLE-BOUNDARY-END(12886716916)
            
            //--TRIMMABLE-BOUNDARY-START(30066586100)
            static /*string */ GetFeatureKey(/*IDataModel?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066586100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("$"/*PrefixIdentifier*/)}HiddenGems`;
            }
            //--TRIMMABLE-BOUNDARY-END(30066586100)
            
            //--TRIMMABLE-BOUNDARY-START(17181684212)
            /*IEnumerable<HiddenGemModel>? */ get Gems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771618804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperties($.$ydCm.LCCCG.HiddenGemModel, "Gems");
            }
            /*IEnumerable<HiddenGemModel>? */ set Gems(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951487988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetProperties($.$ydCm.LCCCG.HiddenGemModel, value, "Gems");
            }
            //--TRIMMABLE-BOUNDARY-END(17181684212)
            
            //--TRIMMABLE-BOUNDARY-START(34361553396)
            /*bool */ IsValid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361553396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Common.Gems.HiddenGemModel>?*/ let __ca1__;
                return (((__ca1__ = this.Gems) !== null ? $.$sl.SL.Enumerable.Any$1($.$ydCm.LCCCG.HiddenGemModel, __ca1__) : false)) && $.$sl.SL.Enumerable.All($.$ydCm.LCCCG.HiddenGemModel, this.Gems, new ($.$$.S.Func$$$($.$ydCm.LCCCG.HiddenGemModel, $.$$.S.Boolean))().$ctor(this,  (/*g*/ g) =>
                {
                    return g.IsValid();
                }, $pFLOCh ??= {"r":262145,"p":[{"n":"g","p":1552884}],"n":"","d":1815028,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34361553396)
            
            //--TRIMMABLE-BOUNDARY-START(8591749620)
            /*HiddenGemModel */ CreateInstance(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591749620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Common.Gems.HiddenGemModel>?*/ let __ca2__;
                return this.CreateComplexProperty($.$ydCm.LCCCG.HiddenGemModel, "Gems", ((__ca2__ = this.Gems) !== null ? $.$sl.SL.Enumerable.Count$1($.$ydCm.LCCCG.HiddenGemModel, __ca2__) : 0));
            }
            //--TRIMMABLE-BOUNDARY-END(8591749620)
            
            //--TRIMMABLE-BOUNDARY-START(8607009110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel>.GetFeatureKey(LivingThing.Core.Frameworks.Common.Data.IDataModel?)
            static LCFCD$IDataFeatureModel$$$GetFeatureKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8607009110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCG.HiddenGemsFeatureModel.GetFeatureKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8607009110)
            
            //--TRIMMABLE-BOUNDARY-START(4312041814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel>.From(LivingThing.Core.Frameworks.Common.Data.IDataModel, LivingThing.Core.Frameworks.Common.Data.IDataModel?, bool?)
            static LCFCD$IDataFeatureModel$$$From()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312041814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ydCm.LCCCG.HiddenGemsFeatureModel.From(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312041814)
            
            //--TRIMMABLE-BOUNDARY-START(4314335574)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IInstanceActivator<LivingThing.Core.Community.Common.Gems.HiddenGemModel>.CreateInstance(string?)
            LCFCD$IInstanceActivator$LivingThing$Core$Community$Common$Gems$HiddenGemModel$CreateInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4314335574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateInstance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4314335574)
            
            //--TRIMMABLE-BOUNDARY-START(4296782324)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296782324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296782324)
            
            //--TRIMMABLE-BOUNDARY-START(4296782324)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296782324)
            
            static $h = 1815028;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$LCOv.LCFCPMS.StatusFeatureModel$$($.$ydCm.LCCCG.HiddenGemsFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181684212),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771618804,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951487988,
        "f": 83886081
      },
      "n": "Gems",
      "d": 1815028,
      "h": 17181684212,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": -9223372036854775808,
              "t": 47614294
            }
          ]
        },
        {
          "t": 2228263,
          "c": 8592162855
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181684212)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886716916),
    {
      "r": 1815028,
      "p": [
        {
          "n": "target",
          "p": 17533270
        },
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        },
        {
          "n": "createIfNotExist",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 65
        }
      ],
      "n": "From",
      "d": 1815028,
      "h": 12886716916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886716916),
//--TRIMMABLE-BOUNDARY-START(30066586100),
    {
      "r": 1310721,
      "p": [
        {
          "n": "context",
          "p": 17533270,
          "f": 65
        }
      ],
      "n": "GetFeatureKey",
      "d": 1815028,
      "h": 30066586100,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066586100),
//--TRIMMABLE-BOUNDARY-START(34361553396),
    {
      "r": 262145,
      "n": "IsValid",
      "d": 1815028,
      "h": 34361553396,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361553396),
//--TRIMMABLE-BOUNDARY-START(8591749620),
    {
      "r": 1552884,
      "p": [
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CreateInstance",
      "d": 1815028,
      "h": 8591749620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591749620)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296782324),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1815028,
      "h": 4296782324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296782324)
  ],
  "h": 1815028
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.IPropertyDescriptorNotify, $.$LCOv.LCFCPMS.IStatusFeatureModel, $.$fPer.LCFCD.IOrderableData, $.$fPer.LCFCD.IOrderedData, $.$fPer.LCFCD.IDataFeatureModel$$($.$ydCm.LCCCG.HiddenGemsFeatureModel), $.$fPer.LCFCD.IInstanceActivator$$($.$ydCm.LCCCG.HiddenGemModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemsFeatureModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1815028)
        
        

        //--TRIMMABLE-BOUNDARY-START(5616116)
        $asm.$cls(`$ydCm.LCCCS$1.CommunityGlobalSettings`, ($self) => class CommunityGlobalSettings extends $.$Iaui.LCFCMS.ComponentGlobalSettings
        {
            //--TRIMMABLE-BOUNDARY-START(21480452596)
            /*GlobalHiddenGemsSettings?*/ HiddenGems = null;
            //--TRIMMABLE-BOUNDARY-END(21480452596)
            
            //--TRIMMABLE-BOUNDARY-START(8595550708)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595550708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8595550708)
            
            //--TRIMMABLE-BOUNDARY-START(8595550708)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8595550708)
            
            static $h = 5616116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentGlobalSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21480452596),
    {
      "p": 6140404,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17185485300,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30070387188,
        "f": 83886081
      },
      "n": "HiddenGems",
      "d": 5616116,
      "h": 21480452596,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21480452596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595550708),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5616116,
      "h": 8595550708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595550708)
  ],
  "h": 5616116
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IGlobalSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.CommunityGlobalSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}CommunityGlobalSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5616116)
        
        

        //--TRIMMABLE-BOUNDARY-START(4108788)
        $asm.$cls(`$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor`, ($self) => class CommunityWeeklyNewsletterModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299076084)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299076084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel, this, factory);
                    }, $wcNcgg ??= {"r":65537,"n":"","d":4108788,"h":0,"f":17825794}), 0, "CommunityWeeklyNewsletterModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_CommunityWeeklyNewsletterModel_LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModelTypeDescriptorBuilder.g.cs", "CommunityWeeklyNewsletterModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299076084)
            
            //--TRIMMABLE-BOUNDARY-START(12889010676)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889010676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GemRewards"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.$type, $.$discardRef(), "GemRewards", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GemRewards")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "GemRewards";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo), ($.$cast(target, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel)).GemRewards);
                        }, $OThdTh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4108788,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.GemRewards = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo));
                        }, $PDYCZa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4108788,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TopPosts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.$type, $.$discardRef(), "TopPosts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TopPosts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TopPosts";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), ($.$cast(target, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel)).TopPosts);
                        }, $gCerPc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4108788,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.TopPosts = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel));
                        }, $maRvIj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4108788,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TopCreators"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.$type, $.$discardRef(), "TopCreators", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TopCreators")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "TopCreators";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator), ($.$cast(target, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel)).TopCreators);
                        }, $CllyGe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4108788,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.TopCreators = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator));
                        }, $NNKzOf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4108788,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889010676)
            
            //--TRIMMABLE-BOUNDARY-START(17183977972)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183977972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _GemRewards = _target.GemRewards;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GemRewards"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo, property, $.$ref(() => _GemRewards, ($v) => _GemRewards = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo))))
                    {
                        _target.GemRewards = _GemRewards;
                        if (_GemRewards !== null)
                        {
                            let $en8 = _GemRewards.SCG$IEnumerable$$$GetEnumerator();
                            while ($en8.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en8.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo, property, $.$ref(() => _GemRewards, ($v) => _GemRewards = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.GemRewardInfo)));
                    }
                }
                {
                    /*var*/ let _TopPosts = _target.TopPosts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TopPosts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel, property, $.$ref(() => _TopPosts, ($v) => _TopPosts = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel))))
                    {
                        _target.TopPosts = _TopPosts;
                        if (_TopPosts !== null)
                        {
                            let $en13 = _TopPosts.SCG$IEnumerable$$$GetEnumerator();
                            while ($en13.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en13.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.PostBaseModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel, property, $.$ref(() => _TopPosts, ($v) => _TopPosts = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel)));
                    }
                }
                {
                    /*var*/ let _TopCreators = _target.TopCreators;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TopCreators"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator, property, $.$ref(() => _TopCreators, ($v) => _TopCreators = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator))))
                    {
                        _target.TopCreators = _TopCreators;
                        if (_TopCreators !== null)
                        {
                            let $en18 = _TopCreators.SCG$IEnumerable$$$GetEnumerator();
                            while ($en18.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en18.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator), $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator, property, $.$ref(() => _TopCreators, ($v) => _TopCreators = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel.TopCreator)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183977972)
            
            //--TRIMMABLE-BOUNDARY-START(8594043380)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594043380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.CommunityWeeklyNewsletterModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityWeeklyNewsletterModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594043380)
            
            static $h = 4108788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889010676),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4108788,
      "h": 12889010676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889010676),
//--TRIMMABLE-BOUNDARY-START(17183977972),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3846644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4108788,
      "h": 17183977972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183977972),
//--TRIMMABLE-BOUNDARY-START(8594043380),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3846644,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4108788,
      "h": 8594043380,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594043380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299076084),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4108788,
      "h": 4299076084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299076084)
  ],
  "h": 4108788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.CommunityWeeklyNewsletterModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityWeeklyNewsletterModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityWeeklyNewsletterModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4108788)
        
        

        //--TRIMMABLE-BOUNDARY-START(6271476)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor`, ($self) => class GlobalHiddenGemsSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4301238772)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301238772);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor.GenerateProperties($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings, this, factory);
                    }, $ngGWrd ??= {"r":65537,"n":"","d":6271476,"h":0,"f":17825794}), 0, "GlobalHiddenGemsSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Settings_GlobalHiddenGemsSettings_LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettingsTypeDescriptorBuilder.g.cs", "GlobalHiddenGemsSettingsTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301238772)
            
            //--TRIMMABLE-BOUNDARY-START(12891173364)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891173364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DailySignups"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, $.$discardRef(), "DailySignups", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DailySignups")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "DailySignups";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)).DailySignups);
                        }, $SndDbc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6271476,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DailySignups = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                        }, $YYhhui ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6271476,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CummulativeSignups"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, $.$discardRef(), "CummulativeSignups", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CummulativeSignups")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CummulativeSignups";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)).CummulativeSignups);
                        }, $oHeVjb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6271476,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CummulativeSignups = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                        }, $FwEfRd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6271476,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DailyPosts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, $.$discardRef(), "DailyPosts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DailyPosts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "DailyPosts";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)).DailyPosts);
                        }, $daaEoi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6271476,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DailyPosts = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                        }, $YJqeve ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6271476,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CummulativePosts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, $.$discardRef(), "CummulativePosts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CummulativePosts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CummulativePosts";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)).CummulativePosts);
                        }, $DIuMri ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6271476,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CummulativePosts = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                        }, $IiSlLh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6271476,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FirstStatusPost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings.$type, $.$discardRef(), "FirstStatusPost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FirstStatusPost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "FirstStatusPost";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)).FirstStatusPost);
                        }, $HBJZDi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6271476,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FirstStatusPost = value.AsReference($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings);
                        }, $RxyISh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6271476,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12891173364)
            
            //--TRIMMABLE-BOUNDARY-START(17186140660)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186140660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _DailySignups = _target.DailySignups;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DailySignups"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _DailySignups, ($v) => _DailySignups = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings))))
                    {
                        _target.DailySignups = _DailySignups;
                        if (_DailySignups !== null)
                        {
                            let $en12 = _DailySignups.SCG$IEnumerable$$$GetEnumerator();
                            while ($en12.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en12.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _DailySignups, ($v) => _DailySignups = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    }
                }
                {
                    /*var*/ let _CummulativeSignups = _target.CummulativeSignups;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CummulativeSignups"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _CummulativeSignups, ($v) => _CummulativeSignups = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings))))
                    {
                        _target.CummulativeSignups = _CummulativeSignups;
                        if (_CummulativeSignups !== null)
                        {
                            let $en17 = _CummulativeSignups.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _CummulativeSignups, ($v) => _CummulativeSignups = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    }
                }
                {
                    /*var*/ let _DailyPosts = _target.DailyPosts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DailyPosts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _DailyPosts, ($v) => _DailyPosts = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings))))
                    {
                        _target.DailyPosts = _DailyPosts;
                        if (_DailyPosts !== null)
                        {
                            let $en22 = _DailyPosts.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en22.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _DailyPosts, ($v) => _DailyPosts = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    }
                }
                {
                    /*var*/ let _CummulativePosts = _target.CummulativePosts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CummulativePosts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _CummulativePosts, ($v) => _CummulativePosts = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings))))
                    {
                        _target.CummulativePosts = _CummulativePosts;
                        if (_CummulativePosts !== null)
                        {
                            let $en27 = _CummulativePosts.SCG$IEnumerable$$$GetEnumerator();
                            while ($en27.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en27.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, property, $.$ref(() => _CummulativePosts, ($v) => _CummulativePosts = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)));
                    }
                }
                {
                    /*var*/ let _FirstStatusPost = _target.FirstStatusPost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FirstStatusPost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _FirstStatusPost, ($v) => _FirstStatusPost = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                    {
                        _target.FirstStatusPost = _FirstStatusPost;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186140660)
            
            //--TRIMMABLE-BOUNDARY-START(8596206068)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596206068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)))
                {
                    /*var*/ let result = $.$ydCm.LCCCS$1.GlobalHiddenGemsSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596206068)
            
            static $h = 6271476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891173364),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6271476,
      "h": 12891173364,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891173364),
//--TRIMMABLE-BOUNDARY-START(17186140660),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6140404,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6271476,
      "h": 17186140660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186140660),
//--TRIMMABLE-BOUNDARY-START(8596206068),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6140404,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6271476,
      "h": 8596206068,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596206068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301238772),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6271476,
      "h": 4301238772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301238772)
  ],
  "h": 6271476
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemsSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemsSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6271476)
        
        

        //--TRIMMABLE-BOUNDARY-START(3387892)
        $asm.$cls(`$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor`, ($self) => class CommunityServiceMetadataTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityServiceMetadata)
        {
            //--TRIMMABLE-BOUNDARY-START(4298355188)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298355188);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.CommunityServiceMetadata, this, factory);
                    }, $qbuGde ??= {"r":65537,"n":"","d":3387892,"h":0,"f":17825794}), 0, "CommunityServiceMetadataTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_CommunityServiceMetadata_LivingThing.Core.Community.Common.Models.CommunityServiceMetadataTypeDescriptorBuilder.g.cs", "CommunityServiceMetadataTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298355188)
            
            //--TRIMMABLE-BOUNDARY-START(12888289780)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888289780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Opened"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityServiceMetadata.$type, $.$discardRef(), "Opened", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Opened")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Opened";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityServiceMetadata";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityServiceMetadata)).Opened);
                        }, $Yfuyrf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3387892,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Opened = value.AsInt();
                        }, $MvuXel ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3387892,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastOpened"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityServiceMetadata.$type, $.$discardRef(), "LastOpened", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastOpened")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "LastOpened";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityServiceMetadata";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$ydCm.LCCCM.CommunityServiceMetadata)).LastOpened);
                        }, $eGZAki ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3387892,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.LastOpened = value.AsDateTime();
                        }, $neKoEj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3387892,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888289780)
            
            //--TRIMMABLE-BOUNDARY-START(17183257076)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityServiceMetadata*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183257076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Opened = _target.Opened;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Opened"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Opened, ($v) => _Opened = $v, $.$$.S.Int32)))
                    {
                        _target.Opened = _Opened;
                    }
                }
                {
                    /*var*/ let _LastOpened = _target.LastOpened;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastOpened"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _LastOpened, ($v) => _LastOpened = $v, null, true)))
                    {
                        _target.LastOpened = _LastOpened;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183257076)
            
            //--TRIMMABLE-BOUNDARY-START(8593322484)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityServiceMetadata?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593322484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.CommunityServiceMetadata().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.CommunityServiceMetadata, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityServiceMetadata)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.CommunityServiceMetadataTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityServiceMetadata));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.CommunityServiceMetadata, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityServiceMetadata));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593322484)
            
            static $h = 3387892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityServiceMetadata); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888289780),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3387892,
      "h": 12888289780,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888289780),
//--TRIMMABLE-BOUNDARY-START(17183257076),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3322356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3387892,
      "h": 17183257076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183257076),
//--TRIMMABLE-BOUNDARY-START(8593322484),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3322356,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3387892,
      "h": 8593322484,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593322484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298355188),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3387892,
      "h": 4298355188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298355188)
  ],
  "h": 3387892
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.CommunityServiceMetadata), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityServiceMetadataTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityServiceMetadataTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3387892)
        
        

        //--TRIMMABLE-BOUNDARY-START(6468084)
        $asm.$cls(`$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor`, ($self) => class CommunityClientApplicationStateTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$2.CommunityClientApplicationState)
        {
            //--TRIMMABLE-BOUNDARY-START(4301435380)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301435380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor.GenerateProperties($.$ydCm.LCCCS$2.CommunityClientApplicationState, this, factory);
                    }, $nVzqXc ??= {"r":65537,"n":"","d":6468084,"h":0,"f":17825794}), 0, "CommunityClientApplicationStateTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\States_CommunityClientApplicationState_LivingThing.Core.Community.Common.States.CommunityClientApplicationStateTypeDescriptorBuilder.g.cs", "CommunityClientApplicationStateTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301435380)
            
            //--TRIMMABLE-BOUNDARY-START(12891369972)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891369972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceMetadatas"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "ServiceMetadatas", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceMetadatas")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ServiceMetadatas";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata), ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).ServiceMetadatas);
                        }, $SEQEma ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.ServiceMetadatas = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata));
                        }, $Rfszlb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Preferences"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "Preferences", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Preferences")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCM.CommunityUserPreference, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Preferences";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ydCm.LCCCM.CommunityUserPreference, ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).Preferences);
                        }, $lWwwuk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Preferences = value.AsReference($.$ydCm.LCCCM.CommunityUserPreference);
                        }, $SLqLxk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MainAccount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "MainAccount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MainAccount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MainAccount";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPM$1.AccountModel, ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).MainAccount);
                        }, $kcOkjc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MainAccount = value.AsReference($.$LCOv.LCFCPM$1.AccountModel);
                        }, $Ulrxwc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SelectedAccountId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "SelectedAccountId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SelectedAccountId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "SelectedAccountId";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).SelectedAccountId);
                        }, $Wfgfik ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SelectedAccountId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $aYdnAf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AuthenticationTicket"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "AuthenticationTicket", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AuthenticationTicket")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$GfYa.LCFCA.DecodedAuthenticationTicket, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "AuthenticationTicket";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$GfYa.LCFCA.DecodedAuthenticationTicket, ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).AuthenticationTicket);
                        }, $Xqzyra ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.AuthenticationTicket = value.AsReference($.$GfYa.LCFCA.DecodedAuthenticationTicket);
                        }, $mMkUUe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ViewedPosts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "ViewedPosts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ViewedPosts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "ViewedPosts";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)), ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).ViewedPosts);
                        }, $ilmsre ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.ViewedPosts = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)));
                        }, $RGWfOf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Variables"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "Variables", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Variables")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Variables";
                        $i13.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String), ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).Variables);
                        }, $ebbpml ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Variables = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String));
                        }, $fNIKHj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CachedFeeds"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$2.CommunityClientApplicationState.$type, $.$discardRef(), "CachedFeeds", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CachedFeeds")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "CachedFeeds";
                        $i15.DelaredOn = "LivingThing.Core.Community.Common.States.CommunityClientApplicationState";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), ($.$cast(target, $.$ydCm.LCCCS$2.CommunityClientApplicationState)).CachedFeeds);
                        }, $JPopyb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6468084,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.CachedFeeds = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel));
                        }, $daKCcb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6468084,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12891369972)
            
            //--TRIMMABLE-BOUNDARY-START(17186337268)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.States.CommunityClientApplicationState*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186337268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ServiceMetadatas = _target.ServiceMetadatas;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceMetadatas"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ServiceMetadatas, ($v) => _ServiceMetadatas = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$ydCm.LCCCM.CommunityServiceMetadata))))
                    {
                        _target.ServiceMetadatas = _ServiceMetadatas;
                    }
                }
                {
                    /*var*/ let _Preferences = _target.Preferences;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Preferences"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCM.CommunityUserPreference));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Preferences, ($v) => _Preferences = $v, $.$ydCm.LCCCM.CommunityUserPreference)))
                    {
                        _target.Preferences = _Preferences;
                    }
                }
                {
                    /*var*/ let _MainAccount = _target.MainAccount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MainAccount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _MainAccount, ($v) => _MainAccount = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                    {
                        _target.MainAccount = _MainAccount;
                    }
                }
                {
                    /*var*/ let _SelectedAccountId = _target.SelectedAccountId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SelectedAccountId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _SelectedAccountId, ($v) => _SelectedAccountId = $v, null, true)))
                    {
                        _target.SelectedAccountId = $.$clone(_SelectedAccountId);
                    }
                }
                {
                    /*var*/ let _AuthenticationTicket = _target.AuthenticationTicket;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AuthenticationTicket"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _AuthenticationTicket, ($v) => _AuthenticationTicket = $v, $.$GfYa.LCFCA.DecodedAuthenticationTicket)))
                    {
                        _target.AuthenticationTicket = _AuthenticationTicket;
                    }
                }
                {
                    /*var*/ let _ViewedPosts = _target.ViewedPosts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ViewedPosts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String))));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ViewedPosts, ($v) => _ViewedPosts = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)))))
                    {
                        _target.ViewedPosts = _ViewedPosts;
                    }
                }
                {
                    /*var*/ let _Variables = _target.Variables;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Variables"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Variables, ($v) => _Variables = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))))
                    {
                        _target.Variables = _Variables;
                    }
                }
                {
                    /*var*/ let _CachedFeeds = _target.CachedFeeds;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CachedFeeds"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel, property, $.$ref(() => _CachedFeeds, ($v) => _CachedFeeds = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel))))
                    {
                        _target.CachedFeeds = _CachedFeeds;
                        if (_CachedFeeds !== null)
                        {
                            let $en32 = _CachedFeeds.SCG$IEnumerable$$$GetEnumerator();
                            while ($en32.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en32.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.PostBaseModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel), $.$LCOv.LCFCPM$1.PostBaseModel, property, $.$ref(() => _CachedFeeds, ($v) => _CachedFeeds = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostBaseModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186337268)
            
            //--TRIMMABLE-BOUNDARY-START(8596402676)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.States.CommunityClientApplicationState?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596402676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCS$2.CommunityClientApplicationState().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCS$2.CommunityClientApplicationState, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$2.CommunityClientApplicationState)))
                {
                    /*var*/ let result = $.$ydCm.LCCCS$2.CommunityClientApplicationStateTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$2.CommunityClientApplicationState));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCS$2.CommunityClientApplicationState, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$2.CommunityClientApplicationState));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596402676)
            
            static $h = 6468084;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$2.CommunityClientApplicationState); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891369972),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6468084,
      "h": 12891369972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891369972),
//--TRIMMABLE-BOUNDARY-START(17186337268),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6402548,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6468084,
      "h": 17186337268,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186337268),
//--TRIMMABLE-BOUNDARY-START(8596402676),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6402548,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6468084,
      "h": 8596402676,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596402676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301435380),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6468084,
      "h": 4301435380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301435380)
  ],
  "h": 6468084
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCS$2.CommunityClientApplicationState), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.States.CommunityClientApplicationStateTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}States${separator}CommunityClientApplicationStateTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6468084)
        
        

        //--TRIMMABLE-BOUNDARY-START(4698612)
        $asm.$cls(`$ydCm.LCCCM.UpdateProfileModelTypeDescriptor`, ($self) => class UpdateProfileModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.UpdateProfileModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299665908)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299665908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.UpdateProfileModel, this, factory);
                    }, $pKpIGj ??= {"r":65537,"n":"","d":4698612,"h":0,"f":17825794}), 0, "UpdateProfileModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_UpdateProfileModel_LivingThing.Core.Community.Common.Models.UpdateProfileModelTypeDescriptorBuilder.g.cs", "UpdateProfileModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299665908)
            
            //--TRIMMABLE-BOUNDARY-START(12889600500)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889600500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProfilePicture"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "ProfilePicture", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProfilePicture")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCM.AccountProfilePictureModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ProfilePicture";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$ydCm.LCCCM.AccountProfilePictureModel, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).ProfilePicture);
                        }, $jNKKQh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ProfilePicture = value.AsValue($.$ydCm.LCCCM.AccountProfilePictureModel);
                        }, $ERnoxf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Handle"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "Handle", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Handle")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountHandle, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Handle";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$LCOv.LCFCPM$1.AccountHandle, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).Handle);
                        }, $WlczNc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Handle = value.AsValue($.$LCOv.LCFCPM$1.AccountHandle);
                        }, $UIVoek ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.PhoneNumber, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PhoneNumber";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.PhoneNumber, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).PhoneNumber);
                        }, $MLDesi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsValue($.$fPer.LCFCD.PhoneNumber);
                        }, $CJdfkd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Location"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "Location", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Location")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDG.INamedLocation, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Location";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDG.INamedLocation, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).Location);
                        }, $wLPoXj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Location = value.AsReference($.$fPer.LCFCDG.INamedLocation);
                        }, $nFVaTk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BirthDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "BirthDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BirthDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateOnly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "BirthDate";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateOnly, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).BirthDate);
                        }, $eBKGyf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BirthDate = value.AsNullableValue($.$$.S.DateOnly);
                        }, $ojybpd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bio"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.UpdateProfileModel.$type, $.$discardRef(), "Bio", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bio")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Bio";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Models.UpdateProfileModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCM.UpdateProfileModel)).Bio);
                        }, $dFTIsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4698612,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Bio = value.AsReference($.$$.S.String);
                        }, $fDNSig ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4698612,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889600500)
            
            //--TRIMMABLE-BOUNDARY-START(17184567796)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.UpdateProfileModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184567796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ProfilePicture = _target.ProfilePicture;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProfilePicture"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCM.AccountProfilePictureModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCM.AccountProfilePictureModel, () => _ProfilePicture, ($v) => _ProfilePicture = $v, null, true)))
                    {
                        _target.ProfilePicture = $.$clone(_ProfilePicture);
                    }
                }
                {
                    /*var*/ let _Handle = _target.Handle;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Handle"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountHandle));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.AccountHandle, () => _Handle, ($v) => _Handle = $v, null, true)))
                    {
                        _target.Handle = $.$clone(_Handle);
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.PhoneNumber));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.PhoneNumber, () => _PhoneNumber, ($v) => _PhoneNumber = $v, null, true)))
                    {
                        _target.PhoneNumber = $.$clone(_PhoneNumber);
                    }
                }
                {
                    /*var*/ let _Location = _target.Location;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Location"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDG.INamedLocation));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Location, ($v) => _Location = $v, $.$fPer.LCFCDG.INamedLocation)))
                    {
                        _target.Location = _Location;
                    }
                }
                {
                    /*var*/ let _BirthDate = _target.BirthDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BirthDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateOnly)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateOnly), () => _BirthDate, ($v) => _BirthDate = $v, null, true)))
                    {
                        _target.BirthDate = $.$clone(_BirthDate);
                    }
                }
                {
                    /*var*/ let _Bio = _target.Bio;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bio"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Bio, ($v) => _Bio = $v, $.$$.S.String)))
                    {
                        _target.Bio = _Bio;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184567796)
            
            //--TRIMMABLE-BOUNDARY-START(8594633204)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.UpdateProfileModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594633204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.UpdateProfileModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.UpdateProfileModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.UpdateProfileModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.UpdateProfileModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.UpdateProfileModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.UpdateProfileModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.UpdateProfileModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594633204)
            
            static $h = 4698612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.UpdateProfileModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889600500),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4698612,
      "h": 12889600500,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889600500),
//--TRIMMABLE-BOUNDARY-START(17184567796),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4567540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4698612,
      "h": 17184567796,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184567796),
//--TRIMMABLE-BOUNDARY-START(8594633204),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4567540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4698612,
      "h": 8594633204,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594633204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299665908),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4698612,
      "h": 4299665908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299665908)
  ],
  "h": 4698612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.UpdateProfileModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.UpdateProfileModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}UpdateProfileModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4698612)
        
        

        //--TRIMMABLE-BOUNDARY-START(3125748)
        $asm.$cls(`$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor`, ($self) => class CommunityMetricsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityMetricsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298093044)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298093044);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.CommunityMetricsModel, this, factory);
                    }, $aQMdLd ??= {"r":65537,"n":"","d":3125748,"h":0,"f":17825794}), 0, "CommunityMetricsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_CommunityMetricsModel_LivingThing.Core.Community.Common.Models.CommunityMetricsModelTypeDescriptorBuilder.g.cs", "CommunityMetricsModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298093044)
            
            //--TRIMMABLE-BOUNDARY-START(12888027636)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888027636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalMembers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "TotalMembers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalMembers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "TotalMembers";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).TotalMembers);
                        }, $UmOCRf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TotalMembers = value.AsInt();
                        }, $wfmjGf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalMembersOnline"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "TotalMembersOnline", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalMembersOnline")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TotalMembersOnline";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).TotalMembersOnline);
                        }, $dmMErk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TotalMembersOnline = value.AsInt();
                        }, $eCyuYf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NewMembersToday"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "NewMembersToday", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NewMembersToday")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "NewMembersToday";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).NewMembersToday);
                        }, $SvEaRh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NewMembersToday = value.AsInt();
                        }, $ktrChj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TotalPosts"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "TotalPosts", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TotalPosts")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "TotalPosts";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).TotalPosts);
                        }, $SyzXSc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TotalPosts = value.AsInt();
                        }, $zVGuhb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NewPostsToday"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "NewPostsToday", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NewPostsToday")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "NewPostsToday";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).NewPostsToday);
                        }, $KVLQha ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NewPostsToday = value.AsInt();
                        }, $ARarke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Trending"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "Trending", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Trending")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Trending";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel), ($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).Trending);
                        }, $NUqKLh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Trending = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel));
                        }, $OAlzPd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MembersOnline"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "MembersOnline", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MembersOnline")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "MembersOnline";
                        $i13.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), ($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).MembersOnline);
                        }, $DBIwfl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MembersOnline = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel));
                        }, $keysUk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NewestMembers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "NewestMembers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NewestMembers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "NewestMembers";
                        $i15.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), ($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).NewestMembers);
                        }, $svaZSh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NewestMembers = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel));
                        }, $qzoyaj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TopCreators"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityMetricsModel.$type, $.$discardRef(), "TopCreators", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TopCreators")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "TopCreators";
                        $i17.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityMetricsModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), ($.$cast(target, $.$ydCm.LCCCM.CommunityMetricsModel)).TopCreators);
                        }, $ZKpTjl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3125748,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TopCreators = value.AsReference($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel));
                        }, $XMDHCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3125748,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888027636)
            
            //--TRIMMABLE-BOUNDARY-START(17182994932)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityMetricsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182994932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _TotalMembers = _target.TotalMembers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalMembers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalMembers, ($v) => _TotalMembers = $v, $.$$.S.Int32)))
                    {
                        _target.TotalMembers = _TotalMembers;
                    }
                }
                {
                    /*var*/ let _TotalMembersOnline = _target.TotalMembersOnline;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalMembersOnline"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalMembersOnline, ($v) => _TotalMembersOnline = $v, $.$$.S.Int32)))
                    {
                        _target.TotalMembersOnline = _TotalMembersOnline;
                    }
                }
                {
                    /*var*/ let _NewMembersToday = _target.NewMembersToday;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NewMembersToday"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _NewMembersToday, ($v) => _NewMembersToday = $v, $.$$.S.Int32)))
                    {
                        _target.NewMembersToday = _NewMembersToday;
                    }
                }
                {
                    /*var*/ let _TotalPosts = _target.TotalPosts;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TotalPosts"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _TotalPosts, ($v) => _TotalPosts = $v, $.$$.S.Int32)))
                    {
                        _target.TotalPosts = _TotalPosts;
                    }
                }
                {
                    /*var*/ let _NewPostsToday = _target.NewPostsToday;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NewPostsToday"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _NewPostsToday, ($v) => _NewPostsToday = $v, $.$$.S.Int32)))
                    {
                        _target.NewPostsToday = _NewPostsToday;
                    }
                }
                {
                    /*var*/ let _Trending = _target.Trending;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Trending"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel), $.$LCOv.LCFCPM$1.PostTrendModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel), $.$LCOv.LCFCPM$1.PostTrendModel, property, $.$ref(() => _Trending, ($v) => _Trending = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel))))
                    {
                        _target.Trending = _Trending;
                        if (_Trending !== null)
                        {
                            let $en25 = _Trending.SCG$IEnumerable$$$GetEnumerator();
                            while ($en25.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en25.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.PostTrendModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel), $.$LCOv.LCFCPM$1.PostTrendModel, property, $.$ref(() => _Trending, ($v) => _Trending = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.PostTrendModel)));
                    }
                }
                {
                    /*var*/ let _MembersOnline = _target.MembersOnline;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MembersOnline"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _MembersOnline, ($v) => _MembersOnline = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel))))
                    {
                        _target.MembersOnline = _MembersOnline;
                        if (_MembersOnline !== null)
                        {
                            let $en30 = _MembersOnline.SCG$IEnumerable$$$GetEnumerator();
                            while ($en30.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en30.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _MembersOnline, ($v) => _MembersOnline = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    }
                }
                {
                    /*var*/ let _NewestMembers = _target.NewestMembers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NewestMembers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _NewestMembers, ($v) => _NewestMembers = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel))))
                    {
                        _target.NewestMembers = _NewestMembers;
                        if (_NewestMembers !== null)
                        {
                            let $en35 = _NewestMembers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en35.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _NewestMembers, ($v) => _NewestMembers = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    }
                }
                {
                    /*var*/ let _TopCreators = _target.TopCreators;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TopCreators"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _TopCreators, ($v) => _TopCreators = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel))))
                    {
                        _target.TopCreators = _TopCreators;
                        if (_TopCreators !== null)
                        {
                            let $en40 = _TopCreators.SCG$IEnumerable$$$GetEnumerator();
                            while ($en40.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en40.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$LCOv.LCFCPM$1.AccountModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel), $.$LCOv.LCFCPM$1.AccountModel, property, $.$ref(() => _TopCreators, ($v) => _TopCreators = $v, $.$$.SCG.IEnumerable$$($.$LCOv.LCFCPM$1.AccountModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182994932)
            
            //--TRIMMABLE-BOUNDARY-START(8593060340)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityMetricsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593060340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.CommunityMetricsModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.CommunityMetricsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityMetricsModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.CommunityMetricsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityMetricsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.CommunityMetricsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityMetricsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593060340)
            
            static $h = 3125748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityMetricsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888027636),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3125748,
      "h": 12888027636,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888027636),
//--TRIMMABLE-BOUNDARY-START(17182994932),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2994676,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3125748,
      "h": 17182994932,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182994932),
//--TRIMMABLE-BOUNDARY-START(8593060340),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2994676,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3125748,
      "h": 8593060340,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593060340)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298093044),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3125748,
      "h": 4298093044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298093044)
  ],
  "h": 3125748
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.CommunityMetricsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityMetricsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityMetricsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3125748)
        
        

        //--TRIMMABLE-BOUNDARY-START(1421812)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor`, ($self) => class HiddenGemFoundNotificationModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundNotificationModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296389108)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296389108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.HiddenGemFoundNotificationModel, this, factory);
                    }, $NGNDMe ??= {"r":65537,"n":"","d":1421812,"h":0,"f":17825794}), 0, "HiddenGemFoundNotificationModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_HiddenGemFoundNotificationModel_LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModelTypeDescriptorBuilder.g.cs", "HiddenGemFoundNotificationModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296389108)
            
            //--TRIMMABLE-BOUNDARY-START(12886323700)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886323700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GemContainerPostId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, $.$discardRef(), "GemContainerPostId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GemContainerPostId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "GemContainerPostId";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)).GemContainerPostId);
                        }, $hWFLrb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1421812,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GemContainerPostId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $BZJyMf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1421812,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FoundGemIndex"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, $.$discardRef(), "FoundGemIndex", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FoundGemIndex")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "FoundGemIndex";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)).FoundGemIndex);
                        }, $fExJZh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1421812,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FoundGemIndex = value.AsInt();
                        }, $aWZoJc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1421812,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinningPostId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, $.$discardRef(), "WinningPostId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinningPostId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.DataId, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "WinningPostId";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.DataId, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)).WinningPostId);
                        }, $TIlIBh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1421812,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinningPostId = value.AsValue($.$fPer.LCFCD.DataId);
                        }, $bLAArg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1421812,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("GlobalGem"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, $.$discardRef(), "GlobalGem", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("GlobalGem")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "GlobalGem";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)).GlobalGem);
                        }, $RcMnRa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1421812,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.GlobalGem = value.AsReference($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings);
                        }, $gFWXRf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1421812,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SessionId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel.$type, $.$discardRef(), "SessionId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SessionId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "SessionId";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)).SessionId);
                        }, $vyySNj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1421812,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SessionId = value.AsReference($.$$.S.String);
                        }, $qIcZXj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1421812,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886323700)
            
            //--TRIMMABLE-BOUNDARY-START(17181290996)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181290996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _GemContainerPostId = _target.GemContainerPostId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GemContainerPostId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _GemContainerPostId, ($v) => _GemContainerPostId = $v, null, true)))
                    {
                        _target.GemContainerPostId = $.$clone(_GemContainerPostId);
                    }
                }
                {
                    /*var*/ let _FoundGemIndex = _target.FoundGemIndex;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FoundGemIndex"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _FoundGemIndex, ($v) => _FoundGemIndex = $v, $.$$.S.Int32)))
                    {
                        _target.FoundGemIndex = _FoundGemIndex;
                    }
                }
                {
                    /*var*/ let _WinningPostId = _target.WinningPostId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinningPostId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.DataId));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.DataId, () => _WinningPostId, ($v) => _WinningPostId = $v, null, true)))
                    {
                        _target.WinningPostId = $.$clone(_WinningPostId);
                    }
                }
                {
                    /*var*/ let _GlobalGem = _target.GlobalGem;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("GlobalGem"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _GlobalGem, ($v) => _GlobalGem = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                    {
                        _target.GlobalGem = _GlobalGem;
                    }
                }
                {
                    /*var*/ let _SessionId = _target.SessionId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SessionId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _SessionId, ($v) => _SessionId = $v, $.$$.S.String)))
                    {
                        _target.SessionId = _SessionId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181290996)
            
            //--TRIMMABLE-BOUNDARY-START(8591356404)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591356404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.HiddenGemFoundNotificationModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundNotificationModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591356404)
            
            static $h = 1421812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundNotificationModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886323700),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1421812,
      "h": 12886323700,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886323700),
//--TRIMMABLE-BOUNDARY-START(17181290996),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1290740,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1421812,
      "h": 17181290996,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181290996),
//--TRIMMABLE-BOUNDARY-START(8591356404),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1290740,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1421812,
      "h": 8591356404,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591356404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296389108),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1421812,
      "h": 4296389108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296389108)
  ],
  "h": 1421812
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundNotificationModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundNotificationModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundNotificationModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1421812)
        
        

        //--TRIMMABLE-BOUNDARY-START(6009332)
        $asm.$cls(`$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor`, ($self) => class GlobalHiddenGemRewardSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300976628)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300976628);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor.GenerateProperties($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, this, factory);
                    }, $gzMHJi ??= {"r":65537,"n":"","d":6009332,"h":0,"f":17825794}), 0, "GlobalHiddenGemRewardSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Settings_GlobalHiddenGemRewardSettings_LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettingsTypeDescriptorBuilder.g.cs", "GlobalHiddenGemRewardSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300976628)
            
            //--TRIMMABLE-BOUNDARY-START(12890911220)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890911220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.HiddenGemTriggerEvent, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Event";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).Event);
                        }, $EPGkIi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent);
                        }, $ykmwBj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EventCount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "EventCount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EventCount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EventCount";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).EventCount);
                        }, $lzNQDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.EventCount = value.AsInt();
                        }, $RCmeEb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reward"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "Reward", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reward")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.GemRewardModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Reward";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$ydCm.LCCCG.GemRewardModel, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).Reward);
                        }, $zuxpdd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Reward = value.AsValue($.$ydCm.LCCCG.GemRewardModel);
                        }, $qtGedd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "StartTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "StartTime";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$10(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).StartTime);
                        }, $GXpNTg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.StartTime = value.AsTimeOnly();
                        }, $RsgNpg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EndTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "EndTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EndTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.TimeOnly, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "EndTime";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$10(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).EndTime);
                        }, $LLSJae ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.EndTime = value.AsTimeOnly();
                        }, $dPwyyb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RandomDailyEventAndReward"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "RandomDailyEventAndReward", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RandomDailyEventAndReward")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "RandomDailyEventAndReward";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).RandomDailyEventAndReward);
                        }, $khTmyh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RandomDailyEventAndReward = value.AsBool();
                        }, $hWizRf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastRandomizedDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "LastRandomizedDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastRandomizedDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "LastRandomizedDate";
                        $i13.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).LastRandomizedDate);
                        }, $WFayhd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastRandomizedDate = value.AsDateTime();
                        }, $QPVvCk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.HiddenGemState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "State";
                        $i15.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ydCm.LCCCG.HiddenGemState, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).State);
                        }, $SVbsZj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$ydCm.LCCCG.HiddenGemState);
                        }, $AUyYxf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FoundTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "FoundTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FoundTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "FoundTime";
                        $i17.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).FoundTime);
                        }, $vPlRWk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FoundTime = value.AsDateTime();
                        }, $lTinYk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "WinnerName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "WinnerName";
                        $i19.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).WinnerName);
                        }, $Nowayj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.WinnerName = value.AsReference($.$$.S.String);
                        }, $DRWNAf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "WinnerId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "WinnerId";
                        $i21.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).WinnerId);
                        }, $lSifpd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerId = value.AsReference($.$$.S.String);
                        }, $kmvHie ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerIconId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "WinnerIconId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerIconId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "WinnerIconId";
                        $i23.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).WinnerIconId);
                        }, $WKpHsd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerIconId = value.AsReference($.$$.S.String);
                        }, $upByYa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Id";
                        $i25.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).Id);
                        }, $irTsMd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $CGNTke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsHidden"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "IsHidden", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsHidden")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "IsHidden";
                        $i27.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).IsHidden);
                        }, $RJYGzc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CommentText"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings.$type, $.$discardRef(), "CommentText", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CommentText")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "CommentText";
                        $i29.DelaredOn = "LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)).CommentText);
                        }, $LUXKIa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6009332,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12890911220)
            
            //--TRIMMABLE-BOUNDARY-START(17185878516)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185878516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.HiddenGemTriggerEvent));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.HiddenGemTriggerEvent, () => _Event, ($v) => _Event = $v, null, true)))
                    {
                        _target.Event = _Event;
                    }
                }
                {
                    /*var*/ let _EventCount = _target.EventCount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EventCount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _EventCount, ($v) => _EventCount = $v, $.$$.S.Int32)))
                    {
                        _target.EventCount = _EventCount;
                    }
                }
                {
                    /*var*/ let _Reward = _target.Reward;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reward"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.GemRewardModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _Reward, ($v) => _Reward = $v, null, true)))
                    {
                        _target.Reward = $.$clone(_Reward);
                    }
                }
                {
                    /*var*/ let _StartTime = _target.StartTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeOnly, () => _StartTime, ($v) => _StartTime = $v, null, true)))
                    {
                        _target.StartTime = _StartTime;
                    }
                }
                {
                    /*var*/ let _EndTime = _target.EndTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EndTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.TimeOnly));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeOnly, () => _EndTime, ($v) => _EndTime = $v, null, true)))
                    {
                        _target.EndTime = _EndTime;
                    }
                }
                {
                    /*var*/ let _RandomDailyEventAndReward = _target.RandomDailyEventAndReward;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RandomDailyEventAndReward"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _RandomDailyEventAndReward, ($v) => _RandomDailyEventAndReward = $v, null, true)))
                    {
                        _target.RandomDailyEventAndReward = _RandomDailyEventAndReward;
                    }
                }
                {
                    /*var*/ let _LastRandomizedDate = _target.LastRandomizedDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastRandomizedDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _LastRandomizedDate, ($v) => _LastRandomizedDate = $v, null, true)))
                    {
                        _target.LastRandomizedDate = _LastRandomizedDate;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.HiddenGemState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.HiddenGemState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _FoundTime = _target.FoundTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FoundTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _FoundTime, ($v) => _FoundTime = $v, null, true)))
                    {
                        _target.FoundTime = _FoundTime;
                    }
                }
                {
                    /*var*/ let _WinnerName = _target.WinnerName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerName, ($v) => _WinnerName = $v, $.$$.S.String)))
                    {
                        _target.WinnerName = _WinnerName;
                    }
                }
                {
                    /*var*/ let _WinnerId = _target.WinnerId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerId, ($v) => _WinnerId = $v, $.$$.S.String)))
                    {
                        _target.WinnerId = _WinnerId;
                    }
                }
                {
                    /*var*/ let _WinnerIconId = _target.WinnerIconId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerIconId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerIconId, ($v) => _WinnerIconId = $v, $.$$.S.String)))
                    {
                        _target.WinnerIconId = _WinnerIconId;
                    }
                }
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _IsHidden = _target.IsHidden;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsHidden"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsHidden, ($v) => _IsHidden = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _CommentText = _target.CommentText;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CommentText"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CommentText, ($v) => _CommentText = $v, $.$$.S.String)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185878516)
            
            //--TRIMMABLE-BOUNDARY-START(8595943924)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595943924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings)))
                {
                    /*var*/ let result = $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595943924)
            
            static $h = 6009332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890911220),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6009332,
      "h": 12890911220,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890911220),
//--TRIMMABLE-BOUNDARY-START(17185878516),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5878260,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6009332,
      "h": 17185878516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185878516),
//--TRIMMABLE-BOUNDARY-START(8595943924),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5878260,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6009332,
      "h": 8595943924,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595943924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300976628),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6009332,
      "h": 4300976628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300976628)
  ],
  "h": 6009332
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemRewardSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.GlobalHiddenGemRewardSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}GlobalHiddenGemRewardSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6009332)
        
        

        //--TRIMMABLE-BOUNDARY-START(2798068)
        $asm.$cls(`$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor`, ($self) => class AccountProfilePictureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.AccountProfilePictureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297765364)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297765364);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.AccountProfilePictureModel, this, factory);
                    }, $VBYYTe ??= {"r":65537,"n":"","d":2798068,"h":0,"f":17825794}), 0, "AccountProfilePictureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_UpdateProfileModel_LivingThing.Core.Community.Common.Models.AccountProfilePictureModelTypeDescriptorBuilder.g.cs", "AccountProfilePictureModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297765364)
            
            //--TRIMMABLE-BOUNDARY-START(12887699956)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887699956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Picture"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.AccountProfilePictureModel.$type, $.$discardRef(), "Picture", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Picture")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.ResourceModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Picture";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.AccountProfilePictureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.ResourceModel, ($.$cast(target, $.$ydCm.LCCCM.AccountProfilePictureModel)).Picture);
                        }, $vLcJYa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2798068,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCM.AccountProfilePictureModel, target).$v.Picture = value.AsReference($.$Iaui.LCFCM.ResourceModel);
                        }, $THpaLg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2798068,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887699956)
            
            //--TRIMMABLE-BOUNDARY-START(17182667252)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.AccountProfilePictureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182667252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Picture = _target.Picture;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Picture"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.ResourceModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Picture, ($v) => _Picture = $v, $.$Iaui.LCFCM.ResourceModel)))
                    {
                        _target.Picture = _Picture;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182667252)
            
            //--TRIMMABLE-BOUNDARY-START(8592732660)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.AccountProfilePictureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592732660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.AccountProfilePictureModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCM.AccountProfilePictureModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.AccountProfilePictureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCM.AccountProfilePictureModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.AccountProfilePictureModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCM.AccountProfilePictureModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592732660)
            
            static $h = 2798068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.AccountProfilePictureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887699956),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2798068,
      "h": 12887699956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887699956),
//--TRIMMABLE-BOUNDARY-START(17182667252),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2666996,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2798068,
      "h": 17182667252,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182667252),
//--TRIMMABLE-BOUNDARY-START(8592732660),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2666996,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2798068,
      "h": 8592732660,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592732660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297765364),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2798068,
      "h": 4297765364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297765364)
  ],
  "h": 2798068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.AccountProfilePictureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.AccountProfilePictureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}AccountProfilePictureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2798068)
        
        

        //--TRIMMABLE-BOUNDARY-START(504308)
        $asm.$cls(`$ydCm.LCCCG.GemIdentifierModelTypeDescriptor`, ($self) => class GemIdentifierModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.GemIdentifierModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295471604)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295471604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.GemIdentifierModel, this, factory);
                    }, $nNJQWg ??= {"r":65537,"n":"","d":504308,"h":0,"f":17825794}), 0, "GemIdentifierModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_GemIdentifierModel_LivingThing.Core.Community.Common.Gems.GemIdentifierModelTypeDescriptorBuilder.g.cs", "GemIdentifierModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295471604)
            
            //--TRIMMABLE-BOUNDARY-START(12885406196)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885406196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.GemIdentifierModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Title";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.GemIdentifierModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.GemIdentifierModel)).Title);
                        }, $Zgmjae ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":504308,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCG.GemIdentifierModel, target).$v.Title = value.AsReference($.$$.S.String);
                        }, $wmhHZd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":504308,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.GemIdentifierModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Name";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Gems.GemIdentifierModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.GemIdentifierModel)).Name);
                        }, $xCdgub ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":504308,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCG.GemIdentifierModel, target).$v.Name = value.AsReference($.$$.S.String);
                        }, $QGNUja ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":504308,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885406196)
            
            //--TRIMMABLE-BOUNDARY-START(17180373492)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.GemIdentifierModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180373492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                        _target.Title = _Title;
                    }
                }
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180373492)
            
            //--TRIMMABLE-BOUNDARY-START(8590438900)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.GemIdentifierModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590438900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.GemIdentifierModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemIdentifierModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.GemIdentifierModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemIdentifierModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.GemIdentifierModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemIdentifierModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590438900)
            
            static $h = 504308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.GemIdentifierModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885406196),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 504308,
      "h": 12885406196,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885406196),
//--TRIMMABLE-BOUNDARY-START(17180373492),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 373236,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 504308,
      "h": 17180373492,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180373492),
//--TRIMMABLE-BOUNDARY-START(8590438900),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 373236,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 504308,
      "h": 8590438900,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590438900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295471604),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 504308,
      "h": 4295471604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295471604)
  ],
  "h": 504308
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.GemIdentifierModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemIdentifierModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemIdentifierModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(504308)
        
        

        //--TRIMMABLE-BOUNDARY-START(766452)
        $asm.$cls(`$ydCm.LCCCG.GemRewardModelTypeDescriptor`, ($self) => class GemRewardModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.GemRewardModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295733748)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295733748);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.GemRewardModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.GemRewardModel, this, factory);
                    }, $LEbiNe ??= {"r":65537,"n":"","d":766452,"h":0,"f":17825794}), 0, "GemRewardModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_GemRewardModel_LivingThing.Core.Community.Common.Gems.GemRewardModelTypeDescriptorBuilder.g.cs", "GemRewardModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295733748)
            
            //--TRIMMABLE-BOUNDARY-START(12885668340)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885668340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gem"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.GemRewardModel.$type, $.$discardRef(), "Gem", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gem")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.GemIdentifierModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Gem";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.GemRewardModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$ydCm.LCCCG.GemIdentifierModel, ($.$cast(target, $.$ydCm.LCCCG.GemRewardModel)).Gem);
                        }, $vgbAVb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":766452,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCG.GemRewardModel, target).$v.Gem = value.AsValue($.$ydCm.LCCCG.GemIdentifierModel);
                        }, $PiVTya ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":766452,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.GemRewardModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Value";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Gems.GemRewardModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.GemRewardModel)).Value);
                        }, $OxlIwj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":766452,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCG.GemRewardModel, target).$v.Value = value.AsReference($.$$.S.String);
                        }, $doyszk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":766452,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.GemRewardModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Description";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Gems.GemRewardModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.GemRewardModel)).Description);
                        }, $cIEYQf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":766452,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.GemRewardModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$ydCm.LCCCG.GemRewardModel, target).$v.Description = value.AsReference($.$$.S.String);
                        }, $IPhWSa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":766452,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885668340)
            
            //--TRIMMABLE-BOUNDARY-START(17180635636)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.GemRewardModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180635636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Gem = _target.Gem;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gem"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.GemIdentifierModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemIdentifierModel, () => _Gem, ($v) => _Gem = $v, null, true)))
                    {
                        _target.Gem = $.$clone(_Gem);
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.String)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180635636)
            
            //--TRIMMABLE-BOUNDARY-START(8590701044)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.GemRewardModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590701044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.GemRewardModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.GemRewardModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.GemRewardModel, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590701044)
            
            static $h = 766452;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.GemRewardModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885668340),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 766452,
      "h": 12885668340,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885668340),
//--TRIMMABLE-BOUNDARY-START(17180635636),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 635380,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 766452,
      "h": 17180635636,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180635636),
//--TRIMMABLE-BOUNDARY-START(8590701044),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 635380,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 766452,
      "h": 8590701044,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590701044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295733748),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 766452,
      "h": 4295733748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295733748)
  ],
  "h": 766452
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.GemRewardModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.GemRewardModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}GemRewardModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(766452)
        
        

        //--TRIMMABLE-BOUNDARY-START(1683956)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemModelTypeDescriptor`, ($self) => class HiddenGemModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296651252)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296651252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.HiddenGemModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.HiddenGemModel, this, factory);
                    }, $cQpTXk ??= {"r":65537,"n":"","d":1683956,"h":0,"f":17825794}), 0, "HiddenGemModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_HiddenGemModel_LivingThing.Core.Community.Common.Gems.HiddenGemModelTypeDescriptorBuilder.g.cs", "HiddenGemModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296651252)
            
            //--TRIMMABLE-BOUNDARY-START(12886585844)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886585844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.HiddenGemTriggerEvent, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Event";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).Event);
                        }, $SNcZRh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent);
                        }, $mJaIMf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EventCount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "EventCount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EventCount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EventCount";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).EventCount);
                        }, $FfivPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.EventCount = value.AsInt();
                        }, $VVcngc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reward"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "Reward", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reward")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.GemRewardModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Reward";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$ydCm.LCCCG.GemRewardModel, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).Reward);
                        }, $NAsBfd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Reward = value.AsValue($.$ydCm.LCCCG.GemRewardModel);
                        }, $CzlxCa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CommentText"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "CommentText", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CommentText")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "CommentText";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).CommentText);
                        }, $cqBFfj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CommentText = value.AsReference($.$$.S.String);
                        }, $akCABk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Paid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "Paid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Paid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Paid";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).Paid);
                        }, $DuGgoi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Paid = value.AsBool();
                        }, $zUHKWg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.HiddenGemState, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "State";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ydCm.LCCCG.HiddenGemState, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).State);
                        }, $ktAbbd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$ydCm.LCCCG.HiddenGemState);
                        }, $QmDZpg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FoundTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "FoundTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FoundTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "FoundTime";
                        $i13.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).FoundTime);
                        }, $evNycd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.FoundTime = value.AsDateTime();
                        }, $NaRKGj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsHidden"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "IsHidden", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsHidden")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "IsHidden";
                        $i15.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).IsHidden);
                        }, $HvOqNf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "WinnerName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "WinnerName";
                        $i17.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).WinnerName);
                        }, $qHtFmj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerName = value.AsReference($.$$.S.String);
                        }, $ArjRPd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "WinnerId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "WinnerId";
                        $i19.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).WinnerId);
                        }, $cEQKEg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerId = value.AsReference($.$$.S.String);
                        }, $VIfbvc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerIconId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemModel.$type, $.$discardRef(), "WinnerIconId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerIconId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "WinnerIconId";
                        $i21.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemModel)).WinnerIconId);
                        }, $RNKIha ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1683956,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerIconId = value.AsReference($.$$.S.String);
                        }, $TFlMPi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1683956,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.DataComplexPropertyModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886585844)
            
            //--TRIMMABLE-BOUNDARY-START(17181553140)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181553140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataComplexPropertyModel?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataComplexPropertyModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataComplexPropertyModel));
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.HiddenGemTriggerEvent));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.HiddenGemTriggerEvent, () => _Event, ($v) => _Event = $v, null, true)))
                    {
                        _target.Event = _Event;
                    }
                }
                {
                    /*var*/ let _EventCount = _target.EventCount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EventCount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _EventCount, ($v) => _EventCount = $v, $.$$.S.Int32)))
                    {
                        _target.EventCount = _EventCount;
                    }
                }
                {
                    /*var*/ let _Reward = _target.Reward;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reward"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.GemRewardModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _Reward, ($v) => _Reward = $v, null, true)))
                    {
                        _target.Reward = $.$clone(_Reward);
                    }
                }
                {
                    /*var*/ let _CommentText = _target.CommentText;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CommentText"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CommentText, ($v) => _CommentText = $v, $.$$.S.String)))
                    {
                        _target.CommentText = _CommentText;
                    }
                }
                {
                    /*var*/ let _Paid = _target.Paid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Paid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Paid, ($v) => _Paid = $v, null, true)))
                    {
                        _target.Paid = _Paid;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.HiddenGemState));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.HiddenGemState, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _FoundTime = _target.FoundTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FoundTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _FoundTime, ($v) => _FoundTime = $v, null, true)))
                    {
                        _target.FoundTime = _FoundTime;
                    }
                }
                {
                    /*var*/ let _IsHidden = _target.IsHidden;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsHidden"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsHidden, ($v) => _IsHidden = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _WinnerName = _target.WinnerName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerName, ($v) => _WinnerName = $v, $.$$.S.String)))
                    {
                        _target.WinnerName = _WinnerName;
                    }
                }
                {
                    /*var*/ let _WinnerId = _target.WinnerId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerId, ($v) => _WinnerId = $v, $.$$.S.String)))
                    {
                        _target.WinnerId = _WinnerId;
                    }
                }
                {
                    /*var*/ let _WinnerIconId = _target.WinnerIconId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerIconId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerIconId, ($v) => _WinnerIconId = $v, $.$$.S.String)))
                    {
                        _target.WinnerIconId = _WinnerIconId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181553140)
            
            //--TRIMMABLE-BOUNDARY-START(8591618548)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591618548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCG.HiddenGemModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.HiddenGemModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.HiddenGemModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.HiddenGemModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591618548)
            
            static $h = 1683956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886585844),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1683956,
      "h": 12886585844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886585844),
//--TRIMMABLE-BOUNDARY-START(17181553140),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1552884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1683956,
      "h": 17181553140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181553140),
//--TRIMMABLE-BOUNDARY-START(8591618548),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1552884,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1683956,
      "h": 8591618548,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591618548)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296651252),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1683956,
      "h": 4296651252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296651252)
  ],
  "h": 1683956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.HiddenGemModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1683956)
        
        

        //--TRIMMABLE-BOUNDARY-START(4370932)
        $asm.$cls(`$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor`, ($self) => class CreatorLaunchPadFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299338228)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299338228);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel, this, factory);
                    }, $WwOEml ??= {"r":65537,"n":"","d":4370932,"h":0,"f":17825794}), 0, "CreatorLaunchPadFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_CreatorLaunchPadFeatureModel_LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModelTypeDescriptorBuilder.g.cs", "CreatorLaunchPadFeatureModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299338228)
            
            //--TRIMMABLE-BOUNDARY-START(12889272820)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889272820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).Name);
                        }, $EFAKef ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $mLWBXg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CreatorName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "CreatorName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CreatorName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CreatorName";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).CreatorName);
                        }, $ZHeChc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CreatorName = value.AsReference($.$$.S.String);
                        }, $hxgKwf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Handle"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "Handle", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Handle")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPM$1.AccountHandle, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Handle";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$LCOv.LCFCPM$1.AccountHandle, ($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).Handle);
                        }, $MncEcl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Handle = value.AsValue($.$LCOv.LCFCPM$1.AccountHandle);
                        }, $hMCibc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Quota"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "Quota", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Quota")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Quota";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).Quota);
                        }, $fVwuYf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Quota = value.AsInt();
                        }, $vIYOVb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "Bid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Bid";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).Bid);
                        }, $tiDvOi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Bid = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $LYcPci ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SocialSettings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel.$type, $.$discardRef(), "SocialSettings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SocialSettings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$LCOv.LCFCPS$1.AccountSocialSettings, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "SocialSettings";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$LCOv.LCFCPS$1.AccountSocialSettings, ($.$cast(target, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)).SocialSettings);
                        }, $wtlenh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4370932,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SocialSettings = value.AsReference($.$LCOv.LCFCPS$1.AccountSocialSettings);
                        }, $kehHXg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4370932,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889272820)
            
            //--TRIMMABLE-BOUNDARY-START(17184240116)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184240116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.AccountFeatureModel<LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPM$1.AccountFeatureModelTypeDescriptor$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPM$1.AccountFeatureModel$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)));
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _CreatorName = _target.CreatorName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CreatorName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CreatorName, ($v) => _CreatorName = $v, $.$$.S.String)))
                    {
                        _target.CreatorName = _CreatorName;
                    }
                }
                {
                    /*var*/ let _Handle = _target.Handle;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Handle"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPM$1.AccountHandle));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$LCOv.LCFCPM$1.AccountHandle, () => _Handle, ($v) => _Handle = $v, null, true)))
                    {
                        _target.Handle = $.$clone(_Handle);
                    }
                }
                {
                    /*var*/ let _Quota = _target.Quota;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Quota"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Quota, ($v) => _Quota = $v, $.$$.S.Int32)))
                    {
                        _target.Quota = _Quota;
                    }
                }
                {
                    /*var*/ let _Bid = _target.Bid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Bid, ($v) => _Bid = $v, null, true)))
                    {
                        _target.Bid = $.$clone(_Bid);
                    }
                }
                {
                    /*var*/ let _SocialSettings = _target.SocialSettings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SocialSettings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$LCOv.LCFCPS$1.AccountSocialSettings));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _SocialSettings, ($v) => _SocialSettings = $v, $.$LCOv.LCFCPS$1.AccountSocialSettings)))
                    {
                        _target.SocialSettings = _SocialSettings;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184240116)
            
            //--TRIMMABLE-BOUNDARY-START(8594305524)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594305524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.CreatorLaunchPadFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CreatorLaunchPadFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594305524)
            
            static $h = 4370932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889272820),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4370932,
      "h": 12889272820,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889272820),
//--TRIMMABLE-BOUNDARY-START(17184240116),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4239860,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4370932,
      "h": 17184240116,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184240116),
//--TRIMMABLE-BOUNDARY-START(8594305524),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4239860,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4370932,
      "h": 8594305524,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594305524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299338228),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4370932,
      "h": 4299338228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299338228)
  ],
  "h": 4370932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.CreatorLaunchPadFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CreatorLaunchPadFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CreatorLaunchPadFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4370932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1159668)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor`, ($self) => class HiddenGemFoundFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296126964)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296126964);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.HiddenGemFoundFeatureModel, this, factory);
                    }, $lfXMIk ??= {"r":65537,"n":"","d":1159668,"h":0,"f":17825794}), 0, "HiddenGemFoundFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_HiddenGemFoundFeatureModel_LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModelTypeDescriptorBuilder.g.cs", "HiddenGemFoundFeatureModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296126964)
            
            //--TRIMMABLE-BOUNDARY-START(12886061556)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886061556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Event"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "Event", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Event")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.HiddenGemTriggerEvent, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Event";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).Event);
                        }, $tvGiDj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Event = value.AsEnumValue($.$ydCm.LCCCG.HiddenGemTriggerEvent);
                        }, $GMnoOi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EventCount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "EventCount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EventCount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EventCount";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).EventCount);
                        }, $yViqOc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EventCount = value.AsInt();
                        }, $KDSgId ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reward"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "Reward", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reward")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCG.GemRewardModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Reward";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$ydCm.LCCCG.GemRewardModel, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).Reward);
                        }, $TYdOva ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Reward = value.AsValue($.$ydCm.LCCCG.GemRewardModel);
                        }, $cUFGSa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FoundTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "FoundTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FoundTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "FoundTime";
                        $i7.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).FoundTime);
                        }, $xXAQfc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FoundTime = value.AsDateTime();
                        }, $vGEGge ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "WinnerName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "WinnerName";
                        $i9.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).WinnerName);
                        }, $BDDJqd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerName = value.AsReference($.$$.S.String);
                        }, $xOuAUg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "WinnerId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "WinnerId";
                        $i11.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).WinnerId);
                        }, $yLtyfd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerId = value.AsReference($.$$.S.String);
                        }, $PqNnqc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WinnerIconId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel.$type, $.$discardRef(), "WinnerIconId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WinnerIconId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "WinnerIconId";
                        $i13.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)).WinnerIconId);
                        }, $XGJxji ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1159668,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WinnerIconId = value.AsReference($.$$.S.String);
                        }, $gctWbb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1159668,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMS.StatusFeatureModelTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886061556)
            
            //--TRIMMABLE-BOUNDARY-START(17181028852)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181028852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Statuses.StatusFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMS.StatusFeatureModelTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMS.StatusFeatureModel$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel)));
                {
                    /*var*/ let _Event = _target.Event;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Event"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.HiddenGemTriggerEvent));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.HiddenGemTriggerEvent, () => _Event, ($v) => _Event = $v, null, true)))
                    {
                        _target.Event = _Event;
                    }
                }
                {
                    /*var*/ let _EventCount = _target.EventCount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EventCount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _EventCount, ($v) => _EventCount = $v, $.$$.S.Int32)))
                    {
                        _target.EventCount = _EventCount;
                    }
                }
                {
                    /*var*/ let _Reward = _target.Reward;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reward"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCG.GemRewardModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$ydCm.LCCCG.GemRewardModel, () => _Reward, ($v) => _Reward = $v, null, true)))
                    {
                        _target.Reward = $.$clone(_Reward);
                    }
                }
                {
                    /*var*/ let _FoundTime = _target.FoundTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FoundTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _FoundTime, ($v) => _FoundTime = $v, null, true)))
                    {
                        _target.FoundTime = _FoundTime;
                    }
                }
                {
                    /*var*/ let _WinnerName = _target.WinnerName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerName, ($v) => _WinnerName = $v, $.$$.S.String)))
                    {
                        _target.WinnerName = _WinnerName;
                    }
                }
                {
                    /*var*/ let _WinnerId = _target.WinnerId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerId, ($v) => _WinnerId = $v, $.$$.S.String)))
                    {
                        _target.WinnerId = _WinnerId;
                    }
                }
                {
                    /*var*/ let _WinnerIconId = _target.WinnerIconId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WinnerIconId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WinnerIconId, ($v) => _WinnerIconId = $v, $.$$.S.String)))
                    {
                        _target.WinnerIconId = _WinnerIconId;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181028852)
            
            //--TRIMMABLE-BOUNDARY-START(8591094260)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591094260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCG.HiddenGemFoundFeatureModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.HiddenGemFoundFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemFoundFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591094260)
            
            static $h = 1159668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886061556),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1159668,
      "h": 12886061556,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886061556),
//--TRIMMABLE-BOUNDARY-START(17181028852),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1028596,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1159668,
      "h": 17181028852,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181028852),
//--TRIMMABLE-BOUNDARY-START(8591094260),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1028596,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1159668,
      "h": 8591094260,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591094260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296126964),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1159668,
      "h": 4296126964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296126964)
  ],
  "h": 1159668
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.HiddenGemFoundFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemFoundFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemFoundFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1159668)
        
        

        //--TRIMMABLE-BOUNDARY-START(3715572)
        $asm.$cls(`$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor`, ($self) => class CommunityUserPreferenceTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(4298682868)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298682868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor.GenerateProperties($.$ydCm.LCCCM.CommunityUserPreference, this, factory);
                    }, $YnSfeb ??= {"r":65537,"n":"","d":3715572,"h":0,"f":17825794}), 0, "CommunityUserPreferenceTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Models_CommunityUserPreference_LivingThing.Core.Community.Common.Models.CommunityUserPreferenceTypeDescriptorBuilder.g.cs", "CommunityUserPreferenceTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298682868)
            
            //--TRIMMABLE-BOUNDARY-START(12888617460)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888617460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("_"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityUserPreference.$type, $.$discardRef(), "_", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("_")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "_";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityUserPreference";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$ydCm.LCCCM.CommunityUserPreference))._);
                        }, $rixBNe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3715572,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EnablePreviewFeatures"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityUserPreference.$type, $.$discardRef(), "EnablePreviewFeatures", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EnablePreviewFeatures")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "EnablePreviewFeatures";
                        $i3.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityUserPreference";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCM.CommunityUserPreference)).EnablePreviewFeatures);
                        }, $USQKhj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3715572,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EnablePreviewFeatures = value.AsBool();
                        }, $atXrsg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3715572,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Saved"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCM.CommunityUserPreference.$type, $.$discardRef(), "Saved", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Saved")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Saved";
                        $i5.DelaredOn = "LivingThing.Core.Community.Common.Models.CommunityUserPreference";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$ydCm.LCCCM.CommunityUserPreference)).Saved);
                        }, $KGjNte ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3715572,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Saved = value.AsBool();
                        }, $oBSrLh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3715572,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888617460)
            
            //--TRIMMABLE-BOUNDARY-START(17183584756)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityUserPreference*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183584756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference?*/ let targetBase = _target;
                $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$yleQ.LCFCA.ApplicationBaseUserPreference));
                {
                    /*var*/ let __ = _target._;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("_"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => __, ($v) => __ = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _EnablePreviewFeatures = _target.EnablePreviewFeatures;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EnablePreviewFeatures"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _EnablePreviewFeatures, ($v) => _EnablePreviewFeatures = $v, null, true)))
                    {
                        _target.EnablePreviewFeatures = _EnablePreviewFeatures;
                    }
                }
                {
                    /*var*/ let _Saved = _target.Saved;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Saved"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Saved, ($v) => _Saved = $v, null, true)))
                    {
                        _target.Saved = _Saved;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183584756)
            
            //--TRIMMABLE-BOUNDARY-START(8593650164)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Models.CommunityUserPreference?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593650164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCM.CommunityUserPreference().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCM.CommunityUserPreference, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityUserPreference)))
                {
                    /*var*/ let result = $.$ydCm.LCCCM.CommunityUserPreferenceTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityUserPreference));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCM.CommunityUserPreference, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCM.CommunityUserPreference));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593650164)
            
            static $h = 3715572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCM.CommunityUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888617460),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3715572,
      "h": 12888617460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888617460),
//--TRIMMABLE-BOUNDARY-START(17183584756),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3584500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3715572,
      "h": 17183584756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183584756),
//--TRIMMABLE-BOUNDARY-START(8593650164),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3584500,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3715572,
      "h": 8593650164,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593650164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298682868),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3715572,
      "h": 4298682868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298682868)
  ],
  "h": 3715572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCM.CommunityUserPreference), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Models.CommunityUserPreferenceTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Models${separator}CommunityUserPreferenceTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3715572)
        
        

        //--TRIMMABLE-BOUNDARY-START(1946100)
        $asm.$cls(`$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor`, ($self) => class HiddenGemsFeatureModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemsFeatureModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296913396)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296913396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor.GenerateProperties($.$ydCm.LCCCG.HiddenGemsFeatureModel, this, factory);
                    }, $JguNfl ??= {"r":65537,"n":"","d":1946100,"h":0,"f":17825794}), 0, "HiddenGemsFeatureModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Gems_HiddenGemsFeatureModel_LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModelTypeDescriptorBuilder.g.cs", "HiddenGemsFeatureModelTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296913396)
            
            //--TRIMMABLE-BOUNDARY-START(12886847988)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886847988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gems"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCG.HiddenGemsFeatureModel.$type, $.$discardRef(), "Gems", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gems")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Gems";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel), ($.$cast(target, $.$ydCm.LCCCG.HiddenGemsFeatureModel)).Gems);
                        }, $LLHcCg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1946100,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Gems = value.AsReference($.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel));
                        }, $ZTrDOd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1946100,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$LCOv.LCFCPMS.StatusFeatureModelTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemsFeatureModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886847988)
            
            //--TRIMMABLE-BOUNDARY-START(17181815284)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181815284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Posts.Models.Statuses.StatusFeatureModel<LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel>?*/ let targetBase = _target;
                $.$LCOv.LCFCPMS.StatusFeatureModelTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemsFeatureModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$LCOv.LCFCPMS.StatusFeatureModel$$($.$ydCm.LCCCG.HiddenGemsFeatureModel)));
                {
                    /*var*/ let _Gems = _target.Gems;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gems"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel), $.$ydCm.LCCCG.HiddenGemModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel), $.$ydCm.LCCCG.HiddenGemModel, property, $.$ref(() => _Gems, ($v) => _Gems = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel))))
                    {
                        _target.Gems = _Gems;
                        if (_Gems !== null)
                        {
                            let $en6 = _Gems.SCG$IEnumerable$$$GetEnumerator();
                            while ($en6.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en6.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ydCm.LCCCG.HiddenGemModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel), $.$ydCm.LCCCG.HiddenGemModel, property, $.$ref(() => _Gems, ($v) => _Gems = $v, $.$$.SCG.IEnumerable$$($.$ydCm.LCCCG.HiddenGemModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181815284)
            
            //--TRIMMABLE-BOUNDARY-START(8591880692)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591880692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCG.HiddenGemsFeatureModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCG.HiddenGemsFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemsFeatureModel)))
                {
                    /*var*/ let result = $.$ydCm.LCCCG.HiddenGemsFeatureModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemsFeatureModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCG.HiddenGemsFeatureModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCG.HiddenGemsFeatureModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591880692)
            
            static $h = 1946100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCG.HiddenGemsFeatureModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886847988),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1946100,
      "h": 12886847988,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886847988),
//--TRIMMABLE-BOUNDARY-START(17181815284),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1815028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1946100,
      "h": 17181815284,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181815284),
//--TRIMMABLE-BOUNDARY-START(8591880692),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1815028,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1946100,
      "h": 8591880692,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591880692)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296913396),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1946100,
      "h": 4296913396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296913396)
  ],
  "h": 1946100
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCG.HiddenGemsFeatureModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Gems.HiddenGemsFeatureModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Gems${separator}HiddenGemsFeatureModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1946100)
        
        

        //--TRIMMABLE-BOUNDARY-START(5747188)
        $asm.$cls(`$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor`, ($self) => class CommunityGlobalSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.CommunityGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4300714484)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300714484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor.GenerateProperties($.$ydCm.LCCCS$1.CommunityGlobalSettings, this, factory);
                    }, $AYnzji ??= {"r":65537,"n":"","d":5747188,"h":0,"f":17825794}), 0, "CommunityGlobalSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Common\\Settings_CommunityGlobalSettings_LivingThing.Core.Community.Common.Settings.CommunityGlobalSettingsTypeDescriptorBuilder.g.cs", "CommunityGlobalSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300714484)
            
            //--TRIMMABLE-BOUNDARY-START(12890649076)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890649076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("HiddenGems"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ydCm.LCCCS$1.CommunityGlobalSettings.$type, $.$discardRef(), "HiddenGems", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("HiddenGems")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "HiddenGems";
                        $i1.DelaredOn = "LivingThing.Core.Community.Common.Settings.CommunityGlobalSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings, ($.$cast(target, $.$ydCm.LCCCS$1.CommunityGlobalSettings)).HiddenGems);
                        }, $TUfnlb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5747188,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.HiddenGems = value.AsReference($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings);
                        }, $SBUfOf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5747188,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890649076)
            
            //--TRIMMABLE-BOUNDARY-START(17185616372)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.CommunityGlobalSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185616372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.Settings.ComponentGlobalSettings?*/ let targetBase = _target;
                $.$Iaui.LCFCMS.ComponentGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCMS.ComponentGlobalSettings));
                {
                    /*var*/ let _HiddenGems = _target.HiddenGems;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("HiddenGems"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$ydCm.LCCCS$1.GlobalHiddenGemsSettings));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _HiddenGems, ($v) => _HiddenGems = $v, $.$ydCm.LCCCS$1.GlobalHiddenGemsSettings)))
                    {
                        _target.HiddenGems = _HiddenGems;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185616372)
            
            //--TRIMMABLE-BOUNDARY-START(8595681780)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Community.Common.Settings.CommunityGlobalSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595681780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ydCm.LCCCS$1.CommunityGlobalSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ydCm.LCCCS$1.CommunityGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.CommunityGlobalSettings)))
                {
                    /*var*/ let result = $.$ydCm.LCCCS$1.CommunityGlobalSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.CommunityGlobalSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ydCm.LCCCS$1.CommunityGlobalSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ydCm.LCCCS$1.CommunityGlobalSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595681780)
            
            static $h = 5747188;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ydCm.LCCCS$1.CommunityGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890649076),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5747188,
      "h": 12890649076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890649076),
//--TRIMMABLE-BOUNDARY-START(17185616372),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5616116,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5747188,
      "h": 17185616372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185616372),
//--TRIMMABLE-BOUNDARY-START(8595681780),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5616116,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5747188,
      "h": 8595681780,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595681780)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300714484),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5747188,
      "h": 4300714484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300714484)
  ],
  "h": 5747188
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ydCm.LCCCS$1.CommunityGlobalSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Common.Settings.CommunityGlobalSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Common${separator}Settings${separator}CommunityGlobalSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5747188)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts"));
})();
//--TRIMMABLE-BOUNDARY-END(45556)
