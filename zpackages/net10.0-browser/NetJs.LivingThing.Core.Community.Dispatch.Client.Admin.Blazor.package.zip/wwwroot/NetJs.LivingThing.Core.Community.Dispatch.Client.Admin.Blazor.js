
//--TRIMMABLE-BOUNDARY-START(60278)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $xrPB, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $UcdF, $JRhp, $bRsy, $Gjye, $SXZI, $TLvC) {
    "use strict";
    let _;
    let $tmREGd;
    let $vjEQqk;
    let $LHrGdk;
    let $gGiiKk;
    let $uthTqf;
    let $Gcpjse;
    let $TQGqFe;
    let $Ougttk;
    let $SxsVwa;
    let $lbTGcj;
    let $NMNsOh;
    let $PVTQnb;
    let $eibqwd;
    let $eEBPUi;
    let $TAvjgc;
    let $OOCeli;
    let $LwxVej;
    let $FOrNRb;
    let $qNZFUe;
    let $ebmcuc;
    let $fbfYAe;
    let $JJNVtf;
    let $ZkiHPe;
    let $aCgwth;
    let $kWqpVg;
    let $irjrRi;
    let $UxATpj;
    let $mzDShl;
    let $wGNvcl;
    let $MCNFja;
    let $GLVnWe;
    let $KXreui;
    let $UXoodl;
    let $SxqLef;
    let $XBUiMf;
    let $mKhBAe;
    let $JLSvgb;
    let $BbfIAk;
    let $baRnje;
    let $ukQzLg;
    let $JtRUfl;
    let $TQmszh;
    let $IElDfa;
    let $sUvkde;
    let $PRJBXb;
    let $xafxvf;
    let $gfIIdc;
    let $zVGRee;
    let $mPVHPg;
    let $XUTQpg;
    let $KjaFke;
    let $ZguRci;
    let $STrpkf;
    let $VXBbYf;
    let $gbuFgb;
    let $EEjLEb;
    let $DopFfe;
    let $gIgNcf;
    let $cVAAsk;
    let $dnKgZk;
    let $VpKNxf;
    let $okscfe;
    let $HOQAki;
    let $dRWrIe;
    let $heOnlf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Dispatch.Client.Admin.Blazor", 
    {
  "h": 60278,
  "f": "LivingThing.Core.Community.Dispatch.Client.Admin.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Dispatch.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Dispatch.Client.Admin.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(125814)
        $asm.$cls(`$OfMV._LCCDCAPA.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295093110)
            static /*void */ CreateCascadingValue_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TValue*/ __arg0, /*int*/ __seq1, /*global::Microsoft.AspNetCore.Components.RenderFragment*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$mac.MAC.CascadingValue$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Value", $.$box(__arg0, TValue));
                __builder.AddComponentParameter(__seq1, "ChildContent", __arg1);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295093110)
            
            static $h = 125814;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295093110),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 6881395
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateCascadingValue_0",
      "d": 125814,
      "h": 4295093110,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295093110)
  ],
  "h": 125814
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Dispatch.Client.Admin.Pages.Admin.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Pages${separator}Admin${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125814)
        
        

        //--TRIMMABLE-BOUNDARY-START(846710)
        $asm.$cls(`$OfMV.LCCDCAS.AdminTableDataTableFilterBuilder<>`, (T) => $asm.$gt(`$OfMV.LCCDCAS.AdminTableDataTableFilterBuilder<>`, [T], ($self) => class AdminTableDataTableFilterBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590781302)
            /*DataFilter */ Build(/*DataFilter*/ filter, /*IEnumerable<OneOf<SchemaAttributeBase, IPropertyDescriptor>>*/ schemas, /*SchemaContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590781302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LCOv.LCFCP.PostUtility.DatabaseSelectWithFilter$1(T, filter, $.$with(context, ($clone) =>
                {
                    $clone.Type = 4/*SchemaType.DataTable*/;
                }));
            }
            //--TRIMMABLE-BOUNDARY-END(8590781302)
            
            //--TRIMMABLE-BOUNDARY-START(4312435030)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataListFilterBuilder<T>.Build(LivingThing.Core.Frameworks.Common.Data.DataFilter, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Common.Attributes.SchemaAttributeBase, LivingThing.Core.Frameworks.Common.DataDescriptor.IPropertyDescriptor>>, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCD$IDataListFilterBuilder$$$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4312435030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4312435030)
            
            //--TRIMMABLE-BOUNDARY-START(4295814006)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295814006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295814006)
            
            //--TRIMMABLE-BOUNDARY-START(4295814006)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295814006)
            
            static $H = 846710;
            static $h = 846710;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590781302),
    {
      "r": 9734486,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "schemas",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCA$1.SchemaAttributeBase, $.$fPer.LCFCD$1.IPropertyDescriptor)).$h
        },
        {
          "n": "context",
          "p": 2394454
        }
      ],
      "n": "Build",
      "d": this.$h,
      "H": 8590781302,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590781302)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295814006),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295814006,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295814006)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 846710,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataListFilterBuilder$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminTableDataTableFilterBuilder<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminTableDataTableFilterBuilder$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(846710)
        
        

        //--TRIMMABLE-BOUNDARY-START(322422)
        $asm.$cls(`$OfMV.LCCDCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590257014)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590257014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$OfMV.LCCDCAS.AdminApproveOutlet, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$OfMV.LCCDCAS.AdminQuoteWaybillForPackage, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$OfMV.LCCDCAS.AdminCollectCashPaymentForPackage, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$OfMV.LCCDCAS.AdminPackageConfirmArrival, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$OfMV.LCCDCAS.AdminPackageDroppedOff, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$OfMV.LCCDCAS.AdminShipmentBeginTransit, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$OfMV.LCCDCAS.AdminShipmentArrivedOutlet, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCD.IDataListFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$OfMV.LCCDCAS.AdminTableDataTableFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCD.IDataListFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), $.$OfMV.LCCDCAS.AdminTableDataTableFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCD.IDataListFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$OfMV.LCCDCAS.AdminTableDataTableFilterBuilder$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590257014)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OfMV.LCCDCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295289718)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295289718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295289718)
            
            //--TRIMMABLE-BOUNDARY-START(4295289718)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295289718)
            
            static $h = 322422;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590257014),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 322422,
      "h": 8590257014,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590257014)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295289718),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 322422,
      "h": 4295289718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295289718)
  ],
  "h": 322422
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(322422)
        
        

        //--TRIMMABLE-BOUNDARY-START(977782)
        $asm.$cls(`$OfMV.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295945078)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295945078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295945078)
            
            //--TRIMMABLE-BOUNDARY-START(4295945078)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295945078)
            
            static $h = 977782;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295945078),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 977782,
      "h": 4295945078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295945078)
  ],
  "h": 977782,
  "a": [
    {
      "t": 912246,
      "c": 4295879542
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(977782)
        
        

        //--TRIMMABLE-BOUNDARY-START(912246)
        $asm.$cls(`$OfMV.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295879542)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295879542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295879542)
            
            //--TRIMMABLE-BOUNDARY-START(4295879542)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295879542)
            
            static $h = 912246;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295879542),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 912246,
      "h": 4295879542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295879542)
  ],
  "h": 912246
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(912246)
        
        

        //--TRIMMABLE-BOUNDARY-START(191350)
        $asm.$cls(`$OfMV.LCCDCA._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590125942)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590125942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590125942)
            
            //--TRIMMABLE-BOUNDARY-START(4295158646)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295158646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295158646)
            
            //--TRIMMABLE-BOUNDARY-START(4295158646)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295158646)
            
            static $h = 191350;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590125942),
    {
      "r": 65537,
      "n": "Execute",
      "d": 191350,
      "h": 8590125942,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590125942)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295158646),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 191350,
      "h": 4295158646,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295158646)
  ],
  "h": 191350
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191350)
        
        

        //--TRIMMABLE-BOUNDARY-START(781174)
        $asm.$cls(`$OfMV.LCCDCAS.AdminShipmentBeginTransit`, ($self) => class AdminShipmentBeginTransit extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835356022)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(55835356022)
            
            //--TRIMMABLE-BOUNDARY-START(8590715766)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590715766);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590715766)
            
            //--TRIMMABLE-BOUNDARY-START(60130323318)
            /*string? */ get Title()
            {
                return "Start Shipment";
            }
            //--TRIMMABLE-BOUNDARY-END(60130323318)
            
            //--TRIMMABLE-BOUNDARY-START(17180650358)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180650358)
            
            //--TRIMMABLE-BOUNDARY-START(51540388726)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-truck-cargo-container"/*MaterialDesignIconNames.TruckCargoContainer*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540388726)
            
            //--TRIMMABLE-BOUNDARY-START(12885683062)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchShipmentModel>, DashboardDetails<CommunityDispatchShipmentModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchShipmentModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885683062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), data))
                {
                    return false;
                }
                return $.$sl.SL.Enumerable.All($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                {
                    return d.LCFCR$IReactiveObservable$$$Value.State < 3/*ShipmentState.Shipped*/;
                }, $gGiiKk ??= {"r":262145,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel).$h}],"n":"","d":781174,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885683062)
            
            //--TRIMMABLE-BOUNDARY-START(21475617654)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchShipmentModel>, DashboardDetails<CommunityDispatchShipmentModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchShipmentModel>>*/ datas)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475617654);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = datas.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let data = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            let $t4, $r4;
                            let $t5, $r5;
                            data.LCFCR$IReactiveObservable$$$Value.State = 3/*ShipmentState.Shipped*/;
                            /*var*/ let packages = ($t2 = $.$ydCm.LCCC.PostUtility.GetCommunityPostAssociations($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, data.LCFCR$IReactiveObservable$$$Value.Identifier, 1196268653051967n | 4194304n, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            let $en3 = packages.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let $package = $en3.SCG$IEnumerator$$$Current;
                                {
                                    $package.State = 9/*CommunityDispatchPackageState.InTransit*/;
                                }
                            }
                            ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), [ data.LCFCR$IReactiveObservable$$$Value ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$sl.SL.Enumerable.ToArray($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, packages)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475617654)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 781174;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130323318),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245421430,
        "f": 50331649
      },
      "n": "Title",
      "d": 781174,
      "h": 60130323318,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130323318),
//--TRIMMABLE-BOUNDARY-START(17180650358),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065552246,
        "f": 50331649
      },
      "n": "Description",
      "d": 781174,
      "h": 17180650358,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180650358),
//--TRIMMABLE-BOUNDARY-START(51540388726),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655486838,
        "f": 50331649
      },
      "n": "Icon",
      "d": 781174,
      "h": 51540388726,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540388726)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885683062),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 781174,
      "h": 12885683062,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885683062),
//--TRIMMABLE-BOUNDARY-START(21475617654),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        },
        {
          "n": "datas",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        }
      ],
      "n": "Execute",
      "d": 781174,
      "h": 21475617654,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475617654)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835356022),
    {
      "t": 1309651,
      "n": "Server",
      "d": 781174,
      "h": 55835356022,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835356022)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590715766),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 781174,
      "h": 8590715766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590715766)
  ],
  "h": 781174
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminShipmentBeginTransit`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminShipmentBeginTransit`; }
        });
        //--TRIMMABLE-BOUNDARY-END(781174)
        
        

        //--TRIMMABLE-BOUNDARY-START(387958)
        $asm.$cls(`$OfMV.LCCDCAS.AdminApproveOutlet`, ($self) => class AdminApproveOutlet extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55834962806)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(55834962806)
            
            //--TRIMMABLE-BOUNDARY-START(64424897398)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(64424897398)
            
            //--TRIMMABLE-BOUNDARY-START(8590322550)
            $ctor$1(/*IServerRemoteService*/ server, /*IUIClientService*/ uI)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590322550);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.UI = uI;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590322550)
            
            //--TRIMMABLE-BOUNDARY-START(60129930102)
            /*string? */ get Title()
            {
                return "Approve Outlet";
            }
            //--TRIMMABLE-BOUNDARY-END(60129930102)
            
            //--TRIMMABLE-BOUNDARY-START(17180257142)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180257142)
            
            //--TRIMMABLE-BOUNDARY-START(51539995510)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-handshake"/*MaterialDesignIconNames.Handshake*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51539995510)
            
            //--TRIMMABLE-BOUNDARY-START(12885289846)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchOutletModel>, DashboardDetails<CommunityDispatchOutletModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchOutletModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885289846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12885289846)
            
            //--TRIMMABLE-BOUNDARY-START(21475224438)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchOutletModel>, DashboardDetails<CommunityDispatchOutletModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchOutletModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475224438);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ok = ($t1 = this.UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Confirm("Approve outlet?", "You must have ensured that the agent outlet is suitable for Camel and meets all Camel policy", "Yes", "No"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (ok)
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        /*var*/ let values = $.$sl.SL.Enumerable.ToArray($.$bRsy.LCCDCM.CommunityDispatchOutletModel, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$bRsy.LCCDCM.CommunityDispatchOutletModel, data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$bRsy.LCCDCM.CommunityDispatchOutletModel))().$ctor(this,  (/**/ d) =>
                        {
                            return d.LCFCR$IReactiveObservable$$$Value;
                        }, $tmREGd ??= {"r":2349867,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel).$h}],"n":"","d":387958,"h":0,"f":17825794})));
                        let $i2 = 0;
                        let $arr2 = values;
                        while ($i2 < $arr2.length)
                        {
                            let o = $arr2[$i2++];
                            o.IsApproved = true;
                        }
                        ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchOutletModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), values), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*service*/ service) =>
                        {
                            return service.LCCDCS$ICommunityDispatchRemoteService$NotifyOutletApproved(values);
                        }, $vjEQqk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"service","p":6544171}],"n":"","d":387958,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475224438)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 387958;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129930102),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245028214,
        "f": 50331649
      },
      "n": "Title",
      "d": 387958,
      "h": 60129930102,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129930102),
//--TRIMMABLE-BOUNDARY-START(17180257142),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065159030,
        "f": 50331649
      },
      "n": "Description",
      "d": 387958,
      "h": 17180257142,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180257142),
//--TRIMMABLE-BOUNDARY-START(51539995510),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655093622,
        "f": 50331649
      },
      "n": "Icon",
      "d": 387958,
      "h": 51539995510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539995510)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885289846),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 387958,
      "h": 12885289846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885289846),
//--TRIMMABLE-BOUNDARY-START(21475224438),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel)).$h
        }
      ],
      "n": "Execute",
      "d": 387958,
      "h": 21475224438,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475224438)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834962806),
    {
      "t": 1309651,
      "n": "Server",
      "d": 387958,
      "h": 55834962806,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834962806),
//--TRIMMABLE-BOUNDARY-START(64424897398),
    {
      "t": 65492650,
      "n": "UI",
      "d": 387958,
      "h": 64424897398,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424897398)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590322550),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "uI",
          "p": 65492650
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 387958,
      "h": 8590322550,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590322550)
  ],
  "h": 387958
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminApproveOutlet`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminApproveOutlet`; }
        });
        //--TRIMMABLE-BOUNDARY-END(387958)
        
        

        //--TRIMMABLE-BOUNDARY-START(715638)
        $asm.$cls(`$OfMV.LCCDCAS.AdminShipmentArrivedOutlet`, ($self) => class AdminShipmentArrivedOutlet extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835290486)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(55835290486)
            
            //--TRIMMABLE-BOUNDARY-START(8590650230)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590650230);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590650230)
            
            //--TRIMMABLE-BOUNDARY-START(60130257782)
            /*string? */ get Title()
            {
                return "Shipment Arrived";
            }
            //--TRIMMABLE-BOUNDARY-END(60130257782)
            
            //--TRIMMABLE-BOUNDARY-START(17180584822)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180584822)
            
            //--TRIMMABLE-BOUNDARY-START(51540323190)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-truck-delivery"/*MaterialDesignIconNames.TruckDelivery*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540323190)
            
            //--TRIMMABLE-BOUNDARY-START(12885617526)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchShipmentModel>, DashboardDetails<CommunityDispatchShipmentModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchShipmentModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885617526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), data))
                {
                    return false;
                }
                return $.$sl.SL.Enumerable.All($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                {
                    return d.LCFCR$IReactiveObservable$$$Value.State === 3/*ShipmentState.Shipped*/;
                }, $LHrGdk ??= {"r":262145,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel).$h}],"n":"","d":715638,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885617526)
            
            //--TRIMMABLE-BOUNDARY-START(21475552118)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchShipmentModel>, DashboardDetails<CommunityDispatchShipmentModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchShipmentModel>>*/ datas)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475552118);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = datas.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let data = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            let $t4, $r4;
                            let $t5, $r5;
                            data.LCFCR$IReactiveObservable$$$Value.State = 4/*ShipmentState.Arrived*/;
                            /*var*/ let packages = ($t2 = $.$ydCm.LCCC.PostUtility.GetCommunityPostAssociations($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, data.LCFCR$IReactiveObservable$$$Value.Identifier, 1196268653051967n | 4194304n, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            let $en3 = packages.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let $package = $en3.SCG$IEnumerator$$$Current;
                                {
                                    $package.State = 10/*CommunityDispatchPackageState.ShipmentArrived*/;
                                }
                            }
                            ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), [ data.LCFCR$IReactiveObservable$$$Value ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$sl.SL.Enumerable.ToArray($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, packages)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475552118)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 715638;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130257782),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245355894,
        "f": 50331649
      },
      "n": "Title",
      "d": 715638,
      "h": 60130257782,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130257782),
//--TRIMMABLE-BOUNDARY-START(17180584822),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065486710,
        "f": 50331649
      },
      "n": "Description",
      "d": 715638,
      "h": 17180584822,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180584822),
//--TRIMMABLE-BOUNDARY-START(51540323190),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655421302,
        "f": 50331649
      },
      "n": "Icon",
      "d": 715638,
      "h": 51540323190,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540323190)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885617526),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 715638,
      "h": 12885617526,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885617526),
//--TRIMMABLE-BOUNDARY-START(21475552118),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        },
        {
          "n": "datas",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel)).$h
        }
      ],
      "n": "Execute",
      "d": 715638,
      "h": 21475552118,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475552118)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835290486),
    {
      "t": 1309651,
      "n": "Server",
      "d": 715638,
      "h": 55835290486,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835290486)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590650230),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 715638,
      "h": 8590650230,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590650230)
  ],
  "h": 715638
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminShipmentArrivedOutlet`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminShipmentArrivedOutlet`; }
        });
        //--TRIMMABLE-BOUNDARY-END(715638)
        
        

        //--TRIMMABLE-BOUNDARY-START(519030)
        $asm.$cls(`$OfMV.LCCDCAS.AdminPackageConfirmArrival`, ($self) => class AdminPackageConfirmArrival extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835093878)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(55835093878)
            
            //--TRIMMABLE-BOUNDARY-START(8590453622)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590453622);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590453622)
            
            //--TRIMMABLE-BOUNDARY-START(60130061174)
            /*string? */ get Title()
            {
                return "Confirm Package";
            }
            //--TRIMMABLE-BOUNDARY-END(60130061174)
            
            //--TRIMMABLE-BOUNDARY-START(17180388214)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180388214)
            
            //--TRIMMABLE-BOUNDARY-START(51540126582)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-truck-delivery"/*MaterialDesignIconNames.TruckDelivery*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540126582)
            
            //--TRIMMABLE-BOUNDARY-START(12885420918)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885420918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data))
                {
                    return false;
                }
                return $.$sl.SL.Enumerable.All($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return a.LCFCR$IReactiveObservable$$$Value.State === 10/*CommunityDispatchPackageState.ShipmentArrived*/;
                }, $Ougttk ??= {"r":262145,"p":[{"n":"a","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h}],"n":"","d":519030,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885420918)
            
            //--TRIMMABLE-BOUNDARY-START(21475355510)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475355510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let values = $.$sl.SL.Enumerable.ToArray($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel))().$ctor(this,  (/*d*/ d) =>
                    {
                        return d.LCFCR$IReactiveObservable$$$Value;
                    }, $SxsVwa ??= {"r":1432363,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h}],"n":"","d":519030,"h":0,"f":17825794})));
                    let $i1 = 0;
                    let $arr1 = values;
                    while ($i1 < $arr1.length)
                    {
                        let value = $arr1[$i1++];
                        value.State = 11/*CommunityDispatchPackageState.ConfirmedArrived*/;
                    }
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), values), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/**/ server) =>
                    {
                        return server.LCCDCS$ICommunityDispatchRemoteService$NotifyPackageArrival(values);
                    }, $lbTGcj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":6544171}],"n":"","d":519030,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475355510)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 519030;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130061174),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245159286,
        "f": 50331649
      },
      "n": "Title",
      "d": 519030,
      "h": 60130061174,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130061174),
//--TRIMMABLE-BOUNDARY-START(17180388214),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065290102,
        "f": 50331649
      },
      "n": "Description",
      "d": 519030,
      "h": 17180388214,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180388214),
//--TRIMMABLE-BOUNDARY-START(51540126582),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655224694,
        "f": 50331649
      },
      "n": "Icon",
      "d": 519030,
      "h": 51540126582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540126582)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885420918),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 519030,
      "h": 12885420918,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885420918),
//--TRIMMABLE-BOUNDARY-START(21475355510),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "Execute",
      "d": 519030,
      "h": 21475355510,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475355510)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835093878),
    {
      "t": 1309651,
      "n": "Server",
      "d": 519030,
      "h": 55835093878,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835093878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590453622),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 519030,
      "h": 8590453622,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590453622)
  ],
  "h": 519030
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminPackageConfirmArrival`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminPackageConfirmArrival`; }
        });
        //--TRIMMABLE-BOUNDARY-END(519030)
        
        

        //--TRIMMABLE-BOUNDARY-START(584566)
        $asm.$cls(`$OfMV.LCCDCAS.AdminPackageDroppedOff`, ($self) => class AdminPackageDroppedOff extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835159414)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(55835159414)
            
            //--TRIMMABLE-BOUNDARY-START(64425094006)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(64425094006)
            
            //--TRIMMABLE-BOUNDARY-START(8590519158)
            $ctor$1(/*IServerRemoteService*/ server, /*IUIClientService*/ uI)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590519158);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.UI = uI;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590519158)
            
            //--TRIMMABLE-BOUNDARY-START(60130126710)
            /*string? */ get Title()
            {
                return "Receive Package";
            }
            //--TRIMMABLE-BOUNDARY-END(60130126710)
            
            //--TRIMMABLE-BOUNDARY-START(17180453750)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180453750)
            
            //--TRIMMABLE-BOUNDARY-START(51540192118)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-handshake"/*MaterialDesignIconNames.Handshake*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540192118)
            
            //--TRIMMABLE-BOUNDARY-START(12885486454)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885486454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sl.SL.Enumerable.Any$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data))
                {
                    return false;
                }
                return $.$sl.SL.Enumerable.All($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                {
                    return d.LCFCR$IReactiveObservable$$$Value.State === 5/*CommunityDispatchPackageState.Ordered*/;
                }, $uthTqf ??= {"r":262145,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h}],"n":"","d":584566,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(12885486454)
            
            //--TRIMMABLE-BOUNDARY-START(21475421046)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475421046);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ok = ($t1 = this.UI.LCFCI$IUIClientService$ClientPrompt.LCFCC$IUIPromptService$Confirm("Package received?", "You are confirming to have received this package from the sender.\r\n\r\nAnd has done initial assessment on the declarations made on the package", "Yes", "No"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (ok)
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        /*var*/ let values = $.$sl.SL.Enumerable.ToArray($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, data, new ($.$$.S.Func$$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel))().$ctor(this,  (/*d*/ d) =>
                        {
                            return d.LCFCR$IReactiveObservable$$$Value;
                        }, $Gcpjse ??= {"r":1432363,"p":[{"n":"d","p":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h}],"n":"","d":584566,"h":0,"f":17825794})));
                        let $i2 = 0;
                        let $arr2 = values;
                        while ($i2 < $arr2.length)
                        {
                            let value = $arr2[$i2++];
                            value.State = 7/*CommunityDispatchPackageState.DroppedOff*/;
                        }
                        ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), values), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*service*/ service) =>
                        {
                            return service.LCCDCS$ICommunityDispatchRemoteService$NotifyPackageCreated(values);
                        }, $TQGqFe ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"service","p":6544171}],"n":"","d":584566,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475421046)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 584566;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130126710),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245224822,
        "f": 50331649
      },
      "n": "Title",
      "d": 584566,
      "h": 60130126710,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130126710),
//--TRIMMABLE-BOUNDARY-START(17180453750),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065355638,
        "f": 50331649
      },
      "n": "Description",
      "d": 584566,
      "h": 17180453750,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180453750),
//--TRIMMABLE-BOUNDARY-START(51540192118),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655290230,
        "f": 50331649
      },
      "n": "Icon",
      "d": 584566,
      "h": 51540192118,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540192118)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885486454),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 584566,
      "h": 12885486454,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885486454),
//--TRIMMABLE-BOUNDARY-START(21475421046),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "Execute",
      "d": 584566,
      "h": 21475421046,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475421046)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835159414),
    {
      "t": 1309651,
      "n": "Server",
      "d": 584566,
      "h": 55835159414,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835159414),
//--TRIMMABLE-BOUNDARY-START(64425094006),
    {
      "t": 65492650,
      "n": "UI",
      "d": 584566,
      "h": 64425094006,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425094006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590519158),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "uI",
          "p": 65492650
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 584566,
      "h": 8590519158,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590519158)
  ],
  "h": 584566
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminPackageDroppedOff`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminPackageDroppedOff`; }
        });
        //--TRIMMABLE-BOUNDARY-END(584566)
        
        

        //--TRIMMABLE-BOUNDARY-START(453494)
        $asm.$cls(`$OfMV.LCCDCAS.AdminCollectCashPaymentForPackage`, ($self) => class AdminCollectCashPaymentForPackage extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719930230)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(68719930230)
            
            //--TRIMMABLE-BOUNDARY-START(55835028342)
            /*IMessagePipeFactory*/ messagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(55835028342)
            
            //--TRIMMABLE-BOUNDARY-START(60129995638)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(60129995638)
            
            //--TRIMMABLE-BOUNDARY-START(8590388086)
            $ctor$1(/*IUIClientService*/ uI, /*IMessagePipeFactory*/ messagePipe, /*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590388086);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UI = uI;
                    this.messagePipe = messagePipe;
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590388086)
            
            //--TRIMMABLE-BOUNDARY-START(64424962934)
            /*string? */ get Title()
            {
                return "Collect Cash";
            }
            //--TRIMMABLE-BOUNDARY-END(64424962934)
            
            //--TRIMMABLE-BOUNDARY-START(17180322678)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180322678)
            
            //--TRIMMABLE-BOUNDARY-START(51540061046)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cash-check"/*MaterialDesignIconNames.CashCheck*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540061046)
            
            //--TRIMMABLE-BOUNDARY-START(12885355382)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885355382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data) !== 1)
                {
                    return false;
                }
                return $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data).LCFCR$IReactiveObservable$$$Value.PaymentReference === null;
            }
            //--TRIMMABLE-BOUNDARY-END(12885355382)
            
            //--TRIMMABLE-BOUNDARY-START(21475289974)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ datas)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475289974);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let data = $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), datas);
                    /*var*/ let totalCost = data.LCFCR$IReactiveObservable$$$Value.Costs.TotalOutStanding;
                    /*var*/ let paidCash = ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$bRsy.LCCDCM.CommunityDispatchPackageCostPaidCashModel, this.UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Cash received for ${$.$strNN(data.LCFCR$IReactiveObservable$$$Value.Name)}`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Admin, you are confirming that you have received a cash payment of ${$.$strNN(totalCost.ToString())} quoted on this package.\r\n\r\nA deviation from this could attract sanctions`, true), null, null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (paidCash.EntryPaymentReference !== null)
                    {
                        data.LCFCR$IReactiveObservable$$$Value.Costs.EntryPaymentReference = paidCash.EntryPaymentReference;
                    }
                    if (paidCash.TotalPaymentReference !== null)
                    {
                        data.LCFCR$IReactiveObservable$$$Value.Costs.TotalPaymentReference = paidCash.TotalPaymentReference;
                    }
                    if (data.LCFCR$IReactiveObservable$$$Value.State < 4/*CommunityDispatchPackageState.Paid*/)
                    {
                        data.LCFCR$IReactiveObservable$$$Value.State = 4/*CommunityDispatchPackageState.Paid*/;
                    }
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), [ data.LCFCR$IReactiveObservable$$$Value ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    let pipe = null;
                    try
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        pipe = ($t3 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.messagePipe, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(data.LCFCR$IReactiveObservable$$$Value.Name), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        ($t4 = pipe.LCFCM$IMessagePipe$FeedAsync($.$bRsy.LCCDCM.CommunityDispatchPackageCostPaidCashModel, paidCash, null, null, false, 0), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    finally
                    {
                        pipe?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475289974)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 453494;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424962934),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245093750,
        "f": 50331649
      },
      "n": "Title",
      "d": 453494,
      "h": 64424962934,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424962934),
//--TRIMMABLE-BOUNDARY-START(17180322678),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065224566,
        "f": 50331649
      },
      "n": "Description",
      "d": 453494,
      "h": 17180322678,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180322678),
//--TRIMMABLE-BOUNDARY-START(51540061046),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655159158,
        "f": 50331649
      },
      "n": "Icon",
      "d": 453494,
      "h": 51540061046,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540061046)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885355382),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 453494,
      "h": 12885355382,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885355382),
//--TRIMMABLE-BOUNDARY-START(21475289974),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "datas",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "Execute",
      "d": 453494,
      "h": 21475289974,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475289974)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719930230),
    {
      "t": 65492650,
      "n": "UI",
      "d": 453494,
      "h": 68719930230,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68719930230),
//--TRIMMABLE-BOUNDARY-START(55835028342),
    {
      "t": 407004,
      "n": "messagePipe",
      "d": 453494,
      "h": 55835028342,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835028342),
//--TRIMMABLE-BOUNDARY-START(60129995638),
    {
      "t": 1309651,
      "n": "server",
      "d": 453494,
      "h": 60129995638,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129995638)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590388086),
    {
      "p": [
        {
          "n": "uI",
          "p": 65492650
        },
        {
          "n": "messagePipe",
          "p": 407004
        },
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 453494,
      "h": 8590388086,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590388086)
  ],
  "h": 453494
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminCollectCashPaymentForPackage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminCollectCashPaymentForPackage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(453494)
        
        

        //--TRIMMABLE-BOUNDARY-START(650102)
        $asm.$cls(`$OfMV.LCCDCAS.AdminQuoteWaybillForPackage`, ($self) => class AdminQuoteWaybillForPackage extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68720126838)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(68720126838)
            
            //--TRIMMABLE-BOUNDARY-START(55835224950)
            /*IMessagePipeFactory*/ messagePipe = null;
            //--TRIMMABLE-BOUNDARY-END(55835224950)
            
            //--TRIMMABLE-BOUNDARY-START(60130192246)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(60130192246)
            
            //--TRIMMABLE-BOUNDARY-START(8590584694)
            $ctor$1(/*IUIClientService*/ uI, /*IMessagePipeFactory*/ messagePipe, /*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590584694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.UI = uI;
                    this.messagePipe = messagePipe;
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590584694)
            
            //--TRIMMABLE-BOUNDARY-START(64425159542)
            /*string? */ get Title()
            {
                return "Quote Price for Package";
            }
            //--TRIMMABLE-BOUNDARY-END(64425159542)
            
            //--TRIMMABLE-BOUNDARY-START(17180519286)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180519286)
            
            //--TRIMMABLE-BOUNDARY-START(51540257654)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-cash"/*MaterialDesignIconNames.Cash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540257654)
            
            //--TRIMMABLE-BOUNDARY-START(12885551990)
            /*bool */ CanCommand(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885551990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Count$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data) === 1 && $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), data).LCFCR$IReactiveObservable$$$Value.State === 1/*CommunityDispatchPackageState.WaitingForQuote*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12885551990)
            
            //--TRIMMABLE-BOUNDARY-START(21475486582)
            /*ValueTask *//*async*/  Execute(/*OneOf<DashboardTable<CommunityDispatchInterStatePackageModel>, DashboardDetails<CommunityDispatchInterStatePackageModel>>*/ source, /*IEnumerable<IObservableDataDescriptor<CommunityDispatchInterStatePackageModel>>*/ datas)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475486582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let data = $.$sl.SL.Enumerable.Single$1($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), datas);
                    /*var*/ let quote = ($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation, this.UI.LCFCI$IUIClientService$Drawer, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Quote for ${$.$strNN(data.LCFCR$IReactiveObservable$$$Value.Name)}`, false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Admin, do your due diligence before providing a quote for a package.\r\n\r\nUnder or Over quoting will attract sanctions`, true), new $.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation(), null, null, 0, 4131, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    data.LCFCR$IReactiveObservable$$$Value.Costs.Schemes = quote.Schemes;
                    data.LCFCR$IReactiveObservable$$$Value.State = 2/*CommunityDispatchPackageState.Quoted*/;
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), [ data.LCFCR$IReactiveObservable$$$Value ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    let pipe = null;
                    try
                    {
                        let $t3, $r3;
                        let $t4, $r4;
                        pipe = ($t3 = $.$UrvY.LCFCM.MessagePipeFactoryExtension.Join(this.messagePipe, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(data.LCFCR$IReactiveObservable$$$Value.Name), new $.$kVHt.LCFCH.WebSocketClientMetadata()), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        ($t4 = pipe.LCFCM$IMessagePipe$FeedAsync($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation, $.$clone(quote), null, null, false, 0), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    finally
                    {
                        pipe?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475486582)
            
            //--TRIMMABLE-BOUNDARY-START(4307965610)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.CanCommand(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$CanCommand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4307965610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanCommand(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4307965610)
            
            //--TRIMMABLE-BOUNDARY-START(8602932906)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableDataCommandProvider<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.Execute(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardTable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>, LivingThing.Core.Frameworks.Client.Components.Dashboard.DashboardDetails<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>>)
            LCFCCD$IDashboardTableDataCommandProvider$$$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8602932906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8602932906)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 650102;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425159542),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245290358,
        "f": 50331649
      },
      "n": "Title",
      "d": 650102,
      "h": 64425159542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425159542),
//--TRIMMABLE-BOUNDARY-START(17180519286),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065421174,
        "f": 50331649
      },
      "n": "Description",
      "d": 650102,
      "h": 17180519286,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180519286),
//--TRIMMABLE-BOUNDARY-START(51540257654),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655355766,
        "f": 50331649
      },
      "n": "Icon",
      "d": 650102,
      "h": 51540257654,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540257654)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885551990),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "data",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "CanCommand",
      "d": 650102,
      "h": 12885551990,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885551990),
//--TRIMMABLE-BOUNDARY-START(21475486582),
    {
      "r": 181338113,
      "p": [
        {
          "n": "source",
          "p": $.$fPer.LCFCO.OneOf$$$($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD.DashboardDetails$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        },
        {
          "n": "datas",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "Execute",
      "d": 650102,
      "h": 21475486582,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475486582)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68720126838),
    {
      "t": 65492650,
      "n": "UI",
      "d": 650102,
      "h": 68720126838,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720126838),
//--TRIMMABLE-BOUNDARY-START(55835224950),
    {
      "t": 407004,
      "n": "messagePipe",
      "d": 650102,
      "h": 55835224950,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835224950),
//--TRIMMABLE-BOUNDARY-START(60130192246),
    {
      "t": 1309651,
      "n": "server",
      "d": 650102,
      "h": 60130192246,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130192246)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590584694),
    {
      "p": [
        {
          "n": "uI",
          "p": 65492650
        },
        {
          "n": "messagePipe",
          "p": 407004
        },
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 650102,
      "h": 8590584694,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590584694)
  ],
  "h": 650102
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCCD.IDashboardTableDataCommandProvider$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Services.AdminQuoteWaybillForPackage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Services${separator}AdminQuoteWaybillForPackage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(650102)
        
        

        //--TRIMMABLE-BOUNDARY-START(256886)
        $asm.$cls(`$OfMV.LCCDCAP.Admin`, ($self) => class Admin extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(188978817910)
            /*string*/ Page = null;
            //--TRIMMABLE-BOUNDARY-END(188978817910)
            
            //--TRIMMABLE-BOUNDARY-START(227633523574)
            /*CommunityDispatchService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(227633523574)
            
            //--TRIMMABLE-BOUNDARY-START(223338556278)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(223338556278)
            
            //--TRIMMABLE-BOUNDARY-START(210453654390)
            /*IUIRenderingProvider*/ Rendering = null;
            //--TRIMMABLE-BOUNDARY-END(210453654390)
            
            //--TRIMMABLE-BOUNDARY-START(300647967606)
            /*IUIClientService*/ UI = null;
            //--TRIMMABLE-BOUNDARY-END(300647967606)
            
            //--TRIMMABLE-BOUNDARY-START(158914046838)
            /*NavigationManager*/ Navigation = null;
            //--TRIMMABLE-BOUNDARY-END(158914046838)
            
            //--TRIMMABLE-BOUNDARY-START(154619079542)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(154619079542)
            
            //--TRIMMABLE-BOUNDARY-START(150324112246)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(150324112246)
            
            //--TRIMMABLE-BOUNDARY-START(133144243062)
            /*T? */ GetProperty(TTable, T, /*IObservableDataDescriptor?*/ target, /*T?*/ prefered)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144243062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ft;
                if ($.$is(prefered, $.$hDPm.LCFCCD$1.DataListFeatures, { set $v($v){ ft = $v; } }))
                {
                    return $.$cast($.$box((ft | 131072n | 34359738368n), $.$hDPm.LCFCCD$1.DataListFeatures), T);
                }
                let filter;
                if ($.$is(prefered, $.$fPer.LCFCD.DataFilter, { set $v($v){ filter = $v; } }))
                {
                    let ided;
                    if ($.$is((target?.LCFCD$1$IObservableDataDescriptor$Parent?.LCFCD$IValueProvider$Value ?? null), $.$fPer.LCFCD.IIded, { set $v($v){ ided = $v; } }))
                    {
                        filter = $.$with(filter, ($clone) =>
                        {
                            $clone.DataId = $.$fPer.LCFCD.CompositeDataId.op_Implicit$1(ided.LCFCD$IIded$Identifier);
                        });
                        filter = filter.WithFilterEnum($.$LCOv.LCFCPM$1.PostFilterTypes, 1073741837/*PostFilterTypes.HasAssociation*/);
                    }
                    return $.$cast(filter.WithFilterEnum($.$LCOv.LCFCPM$1.PostRequestProperties, 1196268653051967n | 4194304n), T);
                }
                if ($.$is(prefered, $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)))
                {
                    return $.$default(T);
                }
                return prefered;
            }
            //--TRIMMABLE-BOUNDARY-END(133144243062)
            
            //--TRIMMABLE-BOUNDARY-START(137439210358)
            /*ValueTask<object> */ GetPropertyValue(/*IObservableDataDescriptor*/ target, /*IPropertyDescriptor*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439210358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(137439210358)
            
            //--TRIMMABLE-BOUNDARY-START(141734177654)
            /*RenderFragment? */ GetUIRenderFragment(T, /*IObservableDataDescriptor?*/ target, /*T?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734177654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let toolbar;
                if (target === null && $.$is(context, $.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)), { set $v($v){ toolbar = $v; } }))
                {
                    return this.GetPackageToolbar($.$clone(toolbar));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(141734177654)
            
            //--TRIMMABLE-BOUNDARY-START(214748621686)
            /*IEnumerable<CommunityDispatchInterStatePackageModel>*/ selectedPackages = null;
            //--TRIMMABLE-BOUNDARY-END(214748621686)
            
            //--TRIMMABLE-BOUNDARY-START(167503981430)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<CommunityDispatchInterStatePackageModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503981430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selectedPackages = $.$sl.SL.Enumerable.ToList($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, selection.SelectedItems, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.LCFCCD$1$IDataListItemContext$$$Data;
                }, $NMNsOh ??= {"r":1432363,"p":[{"n":"s","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h}],"n":"","d":256886,"h":0,"f":17825794})));
                ($.$cast(selection.DataList, $.$hDPm.LCFCCD$1.DataListBase$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)))).Menu?.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Community.Dispatch.Client.Admin.Blazor\\Admin.razor.cs", "OnSelected", 90);
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(167503981430)
            
            //--TRIMMABLE-BOUNDARY-START(219043588982)
            /*IEnumerable<CommunityDispatchShipmentModel>?*/ selectedShipments = null;
            //--TRIMMABLE-BOUNDARY-END(219043588982)
            
            //--TRIMMABLE-BOUNDARY-START(197568752502)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(197568752502)
            
            //--TRIMMABLE-BOUNDARY-START(197568752502)
            //--TRIMMABLE-BOUNDARY-START(47244897142)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244897142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(47244897142)
            
            //--TRIMMABLE-BOUNDARY-START(206158687094)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158687094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(206158687094)
            
            //--TRIMMABLE-BOUNDARY-END(197568752502)
            
            //--TRIMMABLE-BOUNDARY-START(180388883318)
            /*ValueTask<bool> */ OnSelected$3(/*DataListSelection<CommunityDispatchShipmentModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388883318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selectedShipments = $.$sl.SL.Enumerable.ToList($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, $.$sl.SL.Enumerable.Select$1($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$bRsy.LCCDCM.CommunityDispatchShipmentModel, selection.SelectedItems, new ($.$$.S.Func$$$($.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$bRsy.LCCDCM.CommunityDispatchShipmentModel))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.LCFCCD$1$IDataListItemContext$$$Data;
                }, $PVTQnb ??= {"r":5626667,"p":[{"n":"s","p":$.$hDPm.LCFCCD$1.IDataListItemContext$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel).$h}],"n":"","d":256886,"h":0,"f":17825794})));
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(180388883318)
            
            //--TRIMMABLE-BOUNDARY-START(184683850614)
            /*ValueTask<bool> */ OnSelected$4(/*DataListSelection<CommunityDispatchTrackerModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683850614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(184683850614)
            
            //--TRIMMABLE-BOUNDARY-START(171798948726)
            /*ValueTask<bool> */ OnSelected$1(/*DataListSelection<CommunityDispatchOutletModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798948726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(171798948726)
            
            //--TRIMMABLE-BOUNDARY-START(176093916022)
            /*ValueTask<bool> */ OnSelected$2(/*DataListSelection<CommunityDispatchRouteModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093916022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(176093916022)
            
            //--TRIMMABLE-BOUNDARY-START(193273785206)
            /*ValueTask<T?> */ PrepareItemFor(T, /*T?*/ item, /*SchemaContext*/ schema)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273785206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let id;
                if (($.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 4096/*SchemaType.Details*/ || $.$fPer.LCFCA$1.SchemaContext.op_Implicit(schema) === 1/*SchemaType.Form*/) && $.$is(item, $.$fPer.LCFCD.IIded, { set $v($v){ id = $v; } }))
                {
                    return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle(T, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$6(id.LCFCD$IIded$Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1213860839096383n | 4194304n | 16777216n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null)), null);
                }
                return $.$$.STT.ValueTask.FromResult(T, item);
            }
            //--TRIMMABLE-BOUNDARY-END(193273785206)
            
            //--TRIMMABLE-BOUNDARY-START(163209014134)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209014134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Rendering.LCFCC$IUIRenderingProvider$IsPreRendering)
                    {
                        let $t1, $r1;
                        ($t1 = this.Service.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209014134)
            
            //--TRIMMABLE-BOUNDARY-START(51539864438)
            /*ValueTask */ AddSelectedPackagesToShipment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539864438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        if ($.$sl.SL.Enumerable.Any($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.selectedPackages, new ($.$$.S.Func$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                        {
                            return a.State !== 7/*CommunityDispatchPackageState.DroppedOff*/;
                        }, $eibqwd ??= {"r":262145,"p":[{"n":"a","p":1432363}],"n":"","d":256886,"h":0,"f":17825794})))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("A package must be marked dropped off to add to a shipment. Mark the package as received before adding to shipment.");
                        }
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>?*/ let __ca1__;
                        /*var*/ let usableShipment = ((__ca1__ = this.selectedShipments) !== null ? $.$sl.SL.Enumerable.Where($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, __ca1__, new ($.$$.S.Func$$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.State < 3/*ShipmentState.Shipped*/;
                        }, $eEBPUi ??= {"r":262145,"p":[{"n":"s","p":5626667}],"n":"","d":256886,"h":0,"f":17825794})) : null);
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>?*/ let __ca2__;
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>*/ let __ca3__;
                        if (((__ca2__ = usableShipment) !== null ? $.$sl.SL.Enumerable.Count$1($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, __ca2__) : null) === 1 && (((__ca3__ = this.selectedPackages) !== null ? $.$sl.SL.Enumerable.Any$1($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, __ca3__) : false)))
                        {
                            let $t3, $r3;
                            /*var*/ let shipment = $.$sl.SL.Enumerable.Single$1($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, usableShipment);
                            shipment.Packages = this.selectedPackages;
                            ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchShipmentModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), [ shipment ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            let $en4 = $.$sl.SL.Enumerable.Where($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.selectedPackages, new ($.$$.S.Func$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                            {
                                return p.State === 5/*CommunityDispatchPackageState.Ordered*/;
                            }, $TAvjgc ??= {"r":262145,"p":[{"n":"p","p":1432363}],"n":"","d":256886,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                            while ($en4.SC$1$IEnumerator$MoveNext())
                            {
                                let $package = $en4.SCG$IEnumerator$$$Current;
                                {
                                    let $t5, $r5;
                                    $package.State = 8/*CommunityDispatchPackageState.Sorting*/;
                                    ($t5 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.Server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), [ $package ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                }
                            }
                        }
                    });
                }, $OOCeli ??= {"r":181338113,"n":"","d":256886,"h":0,"f":17829890}), true, null, null, false, null);
            }
            //--TRIMMABLE-BOUNDARY-END(51539864438)
            
            //--TRIMMABLE-BOUNDARY-START(146029144950)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029144950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(146029144950)
            
            //--TRIMMABLE-BOUNDARY-START(55834831734)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834831734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    $.$OfMV._LCCDCAPA.TypeInference.CreateCascadingValue_0($.$OfMV.LCCDCAP.Admin, __builder2, 4, 5, this, 6, new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$lJUR.LCFCS.Application, 7);
                        __builder3.AddComponentParameter(8, "BasePath", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("Admin/Dispatch")));
                        __builder3.AddComponentParameter(9, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.BaseViewModel, this.Service));
                        __builder3.AddComponentParameter(10, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationFeatures, 1125027/*ApplicationFeatures.Default*/ | 128/*ApplicationFeatures.ToolBarBorder*/ | 2048/*ApplicationFeatures.LeftSideBarBorder*/), $.$lJUR.LCFCS.ApplicationFeatures));
                        __builder3.AddAttribute$3(11, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                            {
                                __builder4.AddMarkupContent(12, "<i class=\"mdi mdi-package cl-error\"></i>");
                            }, $LwxVej ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                        }), $FOrNRb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageComponent).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                        __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 14);
                            __builder4.AddComponentParameter(15, "Name", "");
                            __builder4.AddComponentParameter(16, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2("**"/*RoutePath.ZeroOrMorePathSegment*/)));
                            __builder4.AddComponentParameter(17, "Class", "pd");
                            __builder4.AddAttribute$3(18, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(19, "Dashboard");
                                }, $qNZFUe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $ebmcuc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(20, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(21, "<i class=\"mdi mdi-package\"></i>");
                                }, $fbfYAe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $JJNVtf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(22, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                }, $ZkiHPe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $aCgwth ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(23, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 24);
                            __builder4.AddComponentParameter(25, "Name", "Routes");
                            __builder4.AddComponentParameter(26, "Class", "pd");
                            __builder4.AddAttribute$3(27, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(28, "Routes");
                                }, $kWqpVg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $irjrRi ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(29, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(30, "<i class=\"mdi mdi-road-variant\"></i>");
                                }, $UxATpj ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $mzDShl ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(31, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchRouteModel), 32);
                                    __builder5.AddComponentParameter(33, "ItemName", "Route");
                                    __builder5.AddComponentParameter(34, "Provider", "this");
                                    __builder5.CloseComponent();
                                }, $wGNvcl ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $MCNFja ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(35, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 36);
                            __builder4.AddComponentParameter(37, "Name", "Outlets");
                            __builder4.AddComponentParameter(38, "Class", "pd");
                            __builder4.AddAttribute$3(39, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(40, "Outlets");
                                }, $GLVnWe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $KXreui ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(41, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(42, "<i class=\"mdi mdi-store\"></i>");
                                }, $UXoodl ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $SxqLef ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(43, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), 44);
                                    __builder5.AddComponentParameter(45, "ItemName", "Outlet");
                                    __builder5.AddComponentParameter(46, "Provider", "this");
                                    __builder5.CloseComponent();
                                }, $XBUiMf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $mKhBAe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(47, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 48);
                            __builder4.AddComponentParameter(49, "Name", "Trackers");
                            __builder4.AddComponentParameter(50, "Class", "pd");
                            __builder4.AddAttribute$3(51, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(52, "Trackers");
                                }, $JLSvgb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $BbfIAk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(53, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(54, "<i class=\"mdi mdi-map-marker\"></i>");
                                }, $baRnje ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $ukQzLg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(55, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchTrackerModel), 56);
                                    __builder5.AddComponentParameter(57, "ItemName", "Tracker");
                                    __builder5.AddComponentParameter(58, "Provider", "this");
                                    __builder5.CloseComponent();
                                }, $JtRUfl ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $TQmszh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(59, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 60);
                            __builder4.AddComponentParameter(61, "Name", "InterstatePackages");
                            __builder4.AddComponentParameter(62, "Class", "pd");
                            __builder4.AddAttribute$3(63, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(64, "InterState Packages");
                                }, $IElDfa ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $sUvkde ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(65, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(66, "<i class=\"mdi mdi-gift-outline\"></i>");
                                }, $PRJBXb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $xafxvf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(67, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), 68);
                                    __builder5.AddComponentParameter(69, "ItemName", "Packages");
                                    __builder5.AddComponentParameter(70, "Provider", "this");
                                    __builder5.AddComponentParameter(71, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(72, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 8388608n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                                    __builder5.CloseComponent();
                                }, $gfIIdc ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $zVGRee ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(73, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 74);
                            __builder4.AddComponentParameter(75, "Name", "LocalPackages");
                            __builder4.AddComponentParameter(76, "Class", "pd");
                            __builder4.AddAttribute$3(77, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(78, "Local Packages");
                                }, $mPVHPg ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $XUTQpg ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(79, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(80, "<i class=\"mdi mdi-gift-outline\"></i>");
                                }, $KjaFke ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $ZguRci ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(81, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), 82);
                                    __builder5.AddComponentParameter(83, "ItemName", "Packages");
                                    __builder5.AddComponentParameter(84, "Provider", "this");
                                    __builder5.AddComponentParameter(85, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(86, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1196268653051967n | 4194304n | 8388608n, $.$LCOv.LCFCPM$1.PostRequestProperties) ], null, null))));
                                    __builder5.CloseComponent();
                                }, $STrpkf ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $VXBbYf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                            __builder4.AddMarkupContent(87, "\r\n                ");
                            __builder4.OpenComponent$1($.$lJUR.LCFCS.ApplicationPage, 88);
                            __builder4.AddComponentParameter(89, "Name", "Shipments");
                            __builder4.AddComponentParameter(90, "Class", "pd");
                            __builder4.AddAttribute$3(91, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddContent$4(92, "Shipments");
                                }, $gbuFgb ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $EEjLEb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(93, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.AddMarkupContent(94, "<i class=\"mdi mdi-truck-cargo-container\"></i>");
                                }, $DopFfe ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $gIgNcf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.AddAttribute$3(95, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder5*/ __builder5) =>
                                {
                                    __builder5.OpenComponent$1($.$hDPm.LCFCCD.DashboardTable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), 96);
                                    __builder5.AddComponentParameter(97, "DashboardTableFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD.DashboardTableFeatures, 7616/*DashboardTableFeatures.Default*/ | 16/*DashboardTableFeatures.ForceEditorToDrawer*/), $.$hDPm.LCFCCD.DashboardTableFeatures));
                                    __builder5.AddComponentParameter(98, "ItemName", "Shipment");
                                    __builder5.AddComponentParameter(99, "Provider", "this");
                                    __builder5.CloseComponent();
                                }, $cVAAsk ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
                            }), $dnKgZk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$$.S.Object)).$h}],"n":"","d":256886,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $VpKNxf ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":256886,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }, $okscfe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":256886,"h":0,"f":17825794}));
                }), $HOQAki ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":256886,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(55834831734)
            
            //--TRIMMABLE-BOUNDARY-START(128849275766)
            /*RenderFragment */ GetPackageToolbar(/*DataListToolBarContext<CommunityDispatchInterStatePackageModel, DataTableColumn<CommunityDispatchInterStatePackageModel>>*/ toolbar)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849275766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(100, "div");
                    __builder2.AddAttribute$5(101, "class", "flex");
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>?*/ let __ca1__;
                    if ((((__ca1__ = toolbar.DataList.Selected) !== null ? $.$sl.SL.Enumerable.Any$1($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, __ca1__) : false)) && ($.$sl.SL.Enumerable.Any($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, this.selectedPackages, new ($.$$.S.Func$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                    {
                        return a.State === 7/*CommunityDispatchPackageState.DroppedOff*/;
                    }, $dRWrIe ??= {"r":262145,"p":[{"n":"a","p":1432363}],"n":"","d":256886,"h":0,"f":17825794}))))
                    {
                        __builder2.OpenElement(102, "button");
                        __builder2.AddAttribute$5(103, "class", "pdx-3 pdy-2 shadow bg-primary corner");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 104, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.AddSelectedPackagesToShipment)));
                        __builder2.AddContent$4(105, "Add to Shipment");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }, $heOnlf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":256886,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(128849275766)
            
            //--TRIMMABLE-BOUNDARY-START(4308162218)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableProvider.GetProperty<TTable, TValue>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, TValue?)
            LCFCCD$IDashboardTableProvider$GetProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308162218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProperty(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308162218)
            
            //--TRIMMABLE-BOUNDARY-START(4308227754)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.Dashboard.IDashboardTableUIProvider.GetUIRenderFragment<T>(LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor?, T)
            LCFCCD$IDashboardTableUIProvider$GetUIRenderFragment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4308227754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetUIRenderFragment(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4308227754)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchInterStatePackageModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Dispatch$Common$Models$CommunityDispatchInterStatePackageModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchShipmentModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Dispatch$Common$Models$CommunityDispatchShipmentModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchTrackerModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchTrackerModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Dispatch$Common$Models$CommunityDispatchTrackerModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$4(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchOutletModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Dispatch$Common$Models$CommunityDispatchOutletModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchRouteModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchRouteModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$Community$Dispatch$Common$Models$CommunityDispatchRouteModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4313077418)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListPrepareItemController.PrepareItemFor<T>(T?, LivingThing.Core.Frameworks.Common.Attributes.SchemaContext)
            LCFCCD$1$IDataListPrepareItemController$PrepareItemFor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313077418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PrepareItemFor(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313077418)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(38654962550)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654962550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654962550)
            
            //--TRIMMABLE-BOUNDARY-START(38654962550)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(38654962550)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(227633523574)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(227633523574)
                
                //--TRIMMABLE-BOUNDARY-START(223338556278)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(223338556278)
                
                //--TRIMMABLE-BOUNDARY-START(210453654390)
                this.Rendering = null;
                //--TRIMMABLE-BOUNDARY-END(210453654390)
                
                //--TRIMMABLE-BOUNDARY-START(300647967606)
                this.UI = null;
                //--TRIMMABLE-BOUNDARY-END(300647967606)
                
                //--TRIMMABLE-BOUNDARY-START(158914046838)
                this.Navigation = null;
                //--TRIMMABLE-BOUNDARY-END(158914046838)
                
                //--TRIMMABLE-BOUNDARY-START(154619079542)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(154619079542)
                
                //--TRIMMABLE-BOUNDARY-START(214748621686)
                this.selectedPackages = $.$sl.SL.Enumerable.Empty($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel);
                //--TRIMMABLE-BOUNDARY-END(214748621686)
                
            }
            static $h = 256886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(188978817910),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194570102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993261942,
        "f": 83886081
      },
      "n": "Page",
      "d": 256886,
      "h": 188978817910,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978817910),
//--TRIMMABLE-BOUNDARY-START(227633523574),
    {
      "p": 2089582,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964373878,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763065718,
        "f": 83886081
      },
      "n": "Service",
      "d": 256886,
      "h": 227633523574,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227633523574),
//--TRIMMABLE-BOUNDARY-START(223338556278),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374439286,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173131126,
        "f": 83886081
      },
      "n": "Server",
      "d": 256886,
      "h": 223338556278,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338556278),
//--TRIMMABLE-BOUNDARY-START(210453654390),
    {
      "p": 5463464,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784504694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583196534,
        "f": 83886081
      },
      "n": "Rendering",
      "d": 256886,
      "h": 210453654390,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453654390),
//--TRIMMABLE-BOUNDARY-START(300647967606),
    {
      "p": 65492650,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554308470,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353000310,
        "f": 83886081
      },
      "n": "UI",
      "d": 256886,
      "h": 300647967606,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(300647967606),
//--TRIMMABLE-BOUNDARY-START(158914046838),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604635510,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403327350,
        "f": 83886081
      },
      "n": "Navigation",
      "d": 256886,
      "h": 158914046838,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914046838),
//--TRIMMABLE-BOUNDARY-START(154619079542),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014700918,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813392758,
        "f": 83886081
      },
      "n": "Loading",
      "d": 256886,
      "h": 154619079542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619079542),
//--TRIMMABLE-BOUNDARY-START(150324112246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424766326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223458166,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 256886,
      "h": 150324112246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324112246)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133144243062),
    {
      "r": (TTable, T) => T.$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "prefered",
          "p": (TTable, T) => T.$h
        }
      ],
      "g": [
        "TTable",
        "T"
      ],
      "n": "GetProperty",
      "d": 256886,
      "h": 133144243062,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(133144243062),
//--TRIMMABLE-BOUNDARY-START(137439210358),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "property",
          "p": 40733014
        }
      ],
      "n": "GetPropertyValue",
      "d": 256886,
      "h": 137439210358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439210358),
//--TRIMMABLE-BOUNDARY-START(141734177654),
    {
      "r": 6881395,
      "p": [
        {
          "n": "target",
          "p": 40536406
        },
        {
          "n": "context",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetUIRenderFragment",
      "d": 256886,
      "h": 141734177654,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(141734177654),
//--TRIMMABLE-BOUNDARY-START(167503981430),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 256886,
      "h": 167503981430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167503981430),
//--TRIMMABLE-BOUNDARY-START(180388883318),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$3",
      "d": 256886,
      "h": 180388883318,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180388883318),
//--TRIMMABLE-BOUNDARY-START(184683850614),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bRsy.LCCDCM.CommunityDispatchTrackerModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$4",
      "d": 256886,
      "h": 184683850614,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184683850614),
//--TRIMMABLE-BOUNDARY-START(171798948726),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$1",
      "d": 256886,
      "h": 171798948726,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171798948726),
//--TRIMMABLE-BOUNDARY-START(176093916022),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$bRsy.LCCDCM.CommunityDispatchRouteModel).$h
        }
      ],
      "n": "OnSelected",
      "o": "@$2",
      "d": 256886,
      "h": 176093916022,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176093916022),
//--TRIMMABLE-BOUNDARY-START(193273785206),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "item",
          "p": (T) => T.$h
        },
        {
          "n": "schema",
          "p": 2394454
        }
      ],
      "g": [
        "T"
      ],
      "n": "PrepareItemFor",
      "d": 256886,
      "h": 193273785206,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(193273785206),
//--TRIMMABLE-BOUNDARY-START(163209014134),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 256886,
      "h": 163209014134,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(163209014134),
//--TRIMMABLE-BOUNDARY-START(51539864438),
    {
      "r": 181338113,
      "n": "AddSelectedPackagesToShipment",
      "d": 256886,
      "h": 51539864438,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539864438),
//--TRIMMABLE-BOUNDARY-START(146029144950),
    {
      "r": 181338113,
      "n": "Load",
      "d": 256886,
      "h": 146029144950,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029144950),
//--TRIMMABLE-BOUNDARY-START(55834831734),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 256886,
      "h": 55834831734,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55834831734),
//--TRIMMABLE-BOUNDARY-START(128849275766),
    {
      "r": 6881395,
      "p": [
        {
          "n": "toolbar",
          "p": $.$hDPm.LCFCCD$1.DataListToolBarContext$$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel, $.$hDPm.LCFCCD$2.DataTableColumn$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel)).$h
        }
      ],
      "n": "GetPackageToolbar",
      "d": 256886,
      "h": 128849275766,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849275766)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(214748621686),
    {
      "t": $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel).$h,
      "n": "selectedPackages",
      "d": 256886,
      "h": 214748621686,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(214748621686),
//--TRIMMABLE-BOUNDARY-START(219043588982),
    {
      "t": $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel).$h,
      "n": "selectedShipments",
      "d": 256886,
      "h": 219043588982,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(219043588982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654962550),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 256886,
      "h": 38654962550,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654962550)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(197568752502),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 256886,
        "h": 47244897142,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 256886,
        "h": 206158687094,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 256886,
      "h": 197568752502,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(197568752502)
  ],
  "h": 256886,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Dispatch",
          "t": 1310721
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Admin/Dispatch/{*Page}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCCD.IDashboardTableProvider, $.$hDPm.LCFCCD.IDashboardTableUIProvider, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bRsy.LCCDCM.CommunityDispatchShipmentModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bRsy.LCCDCM.CommunityDispatchTrackerModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bRsy.LCCDCM.CommunityDispatchTrackerModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bRsy.LCCDCM.CommunityDispatchOutletModel), $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$bRsy.LCCDCM.CommunityDispatchRouteModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$bRsy.LCCDCM.CommunityDispatchRouteModel), $.$hDPm.LCFCCD$1.IDataListPrepareItemController, $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Client.Admin.Pages.Admin`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Client${separator}Admin${separator}Pages${separator}Admin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(256886)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Community.Article.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Community.Dispatch.Common", "NetJs.LivingThing.Core.Community.Dispatch.Schemes.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Client.Blazor", "NetJs.LivingThing.Core.Community.Dispatch.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(60278)
