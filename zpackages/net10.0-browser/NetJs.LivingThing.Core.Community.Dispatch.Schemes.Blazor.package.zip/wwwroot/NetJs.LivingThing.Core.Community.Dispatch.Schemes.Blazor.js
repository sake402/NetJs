
//--TRIMMABLE-BOUNDARY-START(22049)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $UcdF, $JRhp, $bRsy) {
    "use strict";
    let _;
    let $cBNYmf;
    let $elQSsd;
    let $EQARVe;
    let $QojXVj;
    let $MoDhLk;
    let $kNpEah;
    let $OphPje;
    let $Nqrjtk;
    let $ghtpol;
    let $DKBwwg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Dispatch.Schemes.Blazor", 
    {
  "h": 22049,
  "f": "LivingThing.Core.Community.Dispatch.Schemes.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Dispatch.Schemes.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Dispatch.Schemes.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(349729)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchInterStateDeliveryScheme`, ($self) => class CommunityDispatchInterStateDeliveryScheme extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964466721)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(115964466721)
            
            //--TRIMMABLE-BOUNDARY-START(8590284321)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590284321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590284321)
            
            //--TRIMMABLE-BOUNDARY-START(103079564833)
            /*IEnumerable<IAccountRequirementVerifier>?*/ $Requirements = null;
            /*IEnumerable<IAccountRequirementVerifier>? */ get Requirements()
            {
                return this.$Requirements;
            }
             /*IEnumerable<IAccountRequirementVerifier>? */ set Requirements(value)
            {
                this.$Requirements = value;
            }
            //--TRIMMABLE-BOUNDARY-END(103079564833)
            
            //--TRIMMABLE-BOUNDARY-START(107374532129)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Success);
            }
            //--TRIMMABLE-BOUNDARY-END(107374532129)
            
            //--TRIMMABLE-BOUNDARY-START(12885251617)
            /*bool */ CanHandle(/*CommunityDispatchPackageModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885251617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$is($package, $.$bRsy.LCCDCM.CommunityDispatchInterStatePackageModel);
            }
            //--TRIMMABLE-BOUNDARY-END(12885251617)
            
            //--TRIMMABLE-BOUNDARY-START(81604728353)
            /*Pager<ICommunityHandymanWorkServiceCategory>? */ GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604728353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604728353)
            
            //--TRIMMABLE-BOUNDARY-START(85899695649)
            /*Pager<ICommunityHandymanServiceRequestModel>? */ GetServiceRequests()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899695649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, $.$UcdF.LCCHCM.ICommunityHandymanServiceRequestModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(85899695649)
            
            //--TRIMMABLE-BOUNDARY-START(4301445931)
            //Generated interface implemetation for LivingThing.Core.Community.Dispatch.Common.Services.ICommunityDispatchPackageScheme.CanHandle(LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchPackageModel)
            LCCDCS$ICommunityDispatchPackageScheme$CanHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301445931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanHandle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4301445931)
            
            //--TRIMMABLE-BOUNDARY-START(8597198528)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.Requirements.get
            get LCCHCS$ICommunityHandymanWorkServiceCategory$Requirements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21482100416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Requirements;
            }
            //--TRIMMABLE-BOUNDARY-END(8597198528)
            
            //--TRIMMABLE-BOUNDARY-START(12892165824)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.GetCategories()
            LCCHCS$ICommunityHandymanWorkServiceCategory$GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12892165824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCategories(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12892165824)
            
            //--TRIMMABLE-BOUNDARY-START(17187133120)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.GetServiceRequests()
            LCCHCS$ICommunityHandymanWorkServiceCategory$GetServiceRequests()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17187133120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceRequests(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17187133120)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8609040726)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IIded.Identifier.get
            get LCFCD$IIded$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12904008022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(8609040726)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            static $h = 349729;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079564833),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129891873,
        "f": 50331777
      },
      "n": "Requirements",
      "d": 349729,
      "h": 103079564833,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103079564833),
//--TRIMMABLE-BOUNDARY-START(98784597537),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539957281,
        "f": 50331905
      },
      "n": "Name",
      "d": 349729,
      "h": 98784597537,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98784597537),
//--TRIMMABLE-BOUNDARY-START(94489630241),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950022689,
        "f": 50331905
      },
      "n": "Identifier",
      "d": 349729,
      "h": 94489630241,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94489630241),
//--TRIMMABLE-BOUNDARY-START(111669499425),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309761057,
        "f": 50331905
      },
      "n": "Title",
      "d": 349729,
      "h": 111669499425,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(111669499425),
//--TRIMMABLE-BOUNDARY-START(17180218913),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770153505,
        "f": 50331905
      },
      "n": "Description",
      "d": 349729,
      "h": 17180218913,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180218913),
//--TRIMMABLE-BOUNDARY-START(90194662945),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360088097,
        "f": 50331905
      },
      "n": "Icon",
      "d": 349729,
      "h": 90194662945,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90194662945),
//--TRIMMABLE-BOUNDARY-START(107374532129),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719826465,
        "f": 50331777
      },
      "n": "Theme",
      "d": 349729,
      "h": 107374532129,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107374532129)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885251617),
    {
      "r": 262145,
      "p": [
        {
          "n": "package",
          "p": 4053803
        }
      ],
      "n": "CanHandle",
      "d": 349729,
      "h": 12885251617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885251617),
//--TRIMMABLE-BOUNDARY-START(81604728353),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory).$h,
      "n": "GetCategories",
      "d": 349729,
      "h": 81604728353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604728353),
//--TRIMMABLE-BOUNDARY-START(85899695649),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$UcdF.LCCHCM.ICommunityHandymanServiceRequestModel).$h,
      "n": "GetServiceRequests",
      "d": 349729,
      "h": 85899695649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899695649)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115964466721),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 349729,
      "h": 115964466721,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(115964466721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590284321),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 349729,
      "h": 8590284321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590284321)
  ],
  "h": 349729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchInterStateDeliveryScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchInterStateDeliveryScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(349729)
        
        

        //--TRIMMABLE-BOUNDARY-START(480801)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme`, ($self) => class CommunityDispatchLocalDeliveryScheme extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167504205345)
            /*IClientUnitOfWork*/ unitOfWork = null;
            //--TRIMMABLE-BOUNDARY-END(167504205345)
            
            //--TRIMMABLE-BOUNDARY-START(158914270753)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Primary);
            }
            //--TRIMMABLE-BOUNDARY-END(158914270753)
            
            //--TRIMMABLE-BOUNDARY-START(146029368865)
            /*IEnumerable<IAccountRequirementVerifier>?*/ $Requirements = null;
            /*IEnumerable<IAccountRequirementVerifier>? */ get Requirements()
            {
                return this.$Requirements;
            }
             /*IEnumerable<IAccountRequirementVerifier>? */ set Requirements(value)
            {
                this.$Requirements = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146029368865)
            
            //--TRIMMABLE-BOUNDARY-START(17180349985)
            /*bool */ get AutoVerifies()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180349985)
            
            //--TRIMMABLE-BOUNDARY-START(154619303457)
            /*Pager<IShipmentModel> */ get Shipments()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, $.$YUlm.LCSCM.IShipmentModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), null));
            }
            //--TRIMMABLE-BOUNDARY-END(154619303457)
            
            //--TRIMMABLE-BOUNDARY-START(8590415393)
            $ctor$1(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590415393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.unitOfWork = unitOfWork;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590415393)
            
            //--TRIMMABLE-BOUNDARY-START(21475317281)
            /*bool */ CanHandle(/*CommunityDispatchPackageModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475317281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$is($package, $.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel);
            }
            //--TRIMMABLE-BOUNDARY-END(21475317281)
            
            //--TRIMMABLE-BOUNDARY-START(115964597793)
            /*Pager<ICommunityHandymanWorkServiceCategory>? */ GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964597793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964597793)
            
            //--TRIMMABLE-BOUNDARY-START(124554532385)
            /*Pager<ICommunityHandymanServiceRequestModel>? */ GetServiceRequests()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554532385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.Cast$1($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, $.$UcdF.LCCHCM.ICommunityHandymanServiceRequestModel, $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(124554532385)
            
            //--TRIMMABLE-BOUNDARY-START(34360219169)
            /*Task<Money> *//*async*/  EstimateCost(/*GeoLocation*/ pickupLocation, /*GeoLocation*/ deliveryLocation)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCDM.Money), $.$fPer.LCFCDM.Money, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360219169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let temp = new $.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel().$ctor$9();
                    temp.Delivery.Route = (() =>
                    {
                        //new $.$fPer.LCFCDG.GeoLocationRoute()
                        const $t1 = $.$fPer.LCFCDG.GeoLocationRoute;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Geometries = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCDG.GeoLocation), [pickupLocation, deliveryLocation], [-1], null);
                        return $i1;
                    })();
                    temp.DeliveryScheme.Scheme = this.Identifier.ToString();
                    /*var*/ let wayBill = $.$sl.SL.Enumerable.First$1($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation, (($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCCDCS$ICommunityDispatchRemoteService$CalculateWaybill($.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), [temp], null, null), $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchPackageModel)));
                    }, $Nqrjtk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation)).$h,"p":[{"n":"s","p":6544171}],"n":"","d":480801,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable());
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Single$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$AvdQ.LCFCP.ServiceCost), wayBill.Schemes).Value.Total);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360219169)
            
            //--TRIMMABLE-BOUNDARY-START(128849499681)
            /*Task<IShipmentModel?> *//*async*/  GetShipmentAsync(/*DataId*/ id)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$YUlm.LCSCM.IShipmentModel), $.$YUlm.LCSCM.IShipmentModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849499681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadSingle($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new $.$fPer.LCFCD.DataFilter().$ctor$12($.$clone(id)), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128849499681)
            
            //--TRIMMABLE-BOUNDARY-START(25770284577)
            /*Task<IEnumerable<IShipmentModel>> *//*async*/  CreateShipmentAsync(/*IEnumerable<IShipmentPackageModel>*/ packages, /*string*/ shipmentLabel)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel), async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770284577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*List<CommunityDispatchLocalPackageModel>*/ let dispatches = new ($.$$.SCG.List$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel))().$ctor$1();
                    let $en4 = packages.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let $package = $en4.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let dispatch = (() =>
                            {
                                //new $.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel()
                                const $t5 = $.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel;
                                const $i5 = new $t5();
                                $i5.$ctor$9();
                                $i5.PaymentPoint = 1/*CommunityDispatchPackageWayBillPayment.WalletOrCard*/;
                                return $i5;
                            })();
                            dispatch.DeliveryScheme.Scheme = $.$fPer.LCFCS$6.StringExtension.UnQuote(this.Identifier.ToString());
                            dispatch.Delivery.Route = (() =>
                            {
                                //new $.$fPer.LCFCDG.GeoLocationRoute()
                                const $t6 = $.$fPer.LCFCDG.GeoLocationRoute;
                                const $i6 = new $t6();
                                $i6.$ctor$1();
                                $i6.Geometries = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCDG.GeoLocation), [$.$firstOf($package.LCSCM$IShipmentPackageModel$PickupLocation, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Pickup Location required") }), $.$firstOf($package.LCSCM$IShipmentPackageModel$DeliveryLocation, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("Delivery Location required") })], [-1], null);
                                return $i6;
                            })();
                            dispatch.ObjectId = $package.LCSCM$IShipmentPackageModel$SKU;
                            dispatch.Costs.TotalPaymentReference = $package.LCSCM$IShipmentPackageModel$PaymentReference;
                            dispatch.ServiceRequestChannel = 3/*CommunityHandymanServiceRequestChannel.PayCowry*/;
                            dispatch.ServiceRequestState = 1/*CommunityHandymanServiceRequestState.Submitted*/;
                            dispatches.Add(dispatch);
                        }
                    }
                    /*var*/ let wayBills = ($t7 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$bRsy.LCCDCS.ICommunityDispatchRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCCDCS$ICommunityDispatchRemoteService$CalculateWaybill($.$$.N.InterfaceVarianceStubHandler.Create(dispatches, $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchPackageModel)));
                    }, $ghtpol ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$bRsy.LCCDCM.CommunityDispatchPackageCostQuotation)).$h,"p":[{"n":"s","p":6544171}],"n":"","d":480801,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    /*int*/ let i = 0;
                    let $en8 = wayBills.GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let wayBill = $en8.SCG$IEnumerator$$$Current;
                        {
                            dispatches.get_Item(i).Costs.Schemes = wayBill.Schemes;
                            dispatches.get_Item(i).Costs.FinalCost = $.$sl.SL.Enumerable.Single$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$AvdQ.LCFCP.ServiceCost), wayBill.Schemes).Value.Total;
                            i++;
                        }
                    }
                    ($t9 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$3($.$UcdF.LCCHCS.ICommunityHandymanRemoteService, this.unitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceMethod$$($.$UcdF.LCCHCS.ICommunityHandymanRemoteService))().$ctor(this,  (/*service*/ service) =>
                    {
                        return service.LCCHCS$ICommunityHandymanRemoteService$SubmitServiceRequest($.$$.N.InterfaceVarianceStubHandler.Create(dispatches, $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), $.$$.SCG.IEnumerable$$($.$UcdF.LCCHCM.ICommunityHandymanServiceRequestModel)));
                    }, $DKBwwg ??= {"r":178454529,"p":[{"n":"service","p":6870720}],"n":"","d":480801,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(dispatches, $.$$.SCG.IEnumerable$$($.$bRsy.LCCDCM.CommunityDispatchLocalPackageModel), $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25770284577)
            
            //--TRIMMABLE-BOUNDARY-START(12885382689)
            /*Task */ AddPackagesToShipment(/*IShipmentModel*/ shipment, /*IEnumerable<IShipmentPackageModel>*/ packages)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885382689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12885382689)
            
            //--TRIMMABLE-BOUNDARY-START(120259565089)
            /*Task<GeoLocation> */ GetLocationAsync(/*DataId*/ shipmentId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259565089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120259565089)
            
            //--TRIMMABLE-BOUNDARY-START(150324336161)
            /*Task<bool> */ SetPackageDelivered(/*DataId*/ shipmentId, /*DataId*/ packageId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324336161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(150324336161)
            
            //--TRIMMABLE-BOUNDARY-START(4301445931)
            //Generated interface implemetation for LivingThing.Core.Community.Dispatch.Common.Services.ICommunityDispatchPackageScheme.CanHandle(LivingThing.Core.Community.Dispatch.Common.Models.CommunityDispatchPackageModel)
            LCCDCS$ICommunityDispatchPackageScheme$CanHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301445931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanHandle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4301445931)
            
            //--TRIMMABLE-BOUNDARY-START(8597198528)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.Requirements.get
            get LCCHCS$ICommunityHandymanWorkServiceCategory$Requirements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21482100416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Requirements;
            }
            //--TRIMMABLE-BOUNDARY-END(8597198528)
            
            //--TRIMMABLE-BOUNDARY-START(12892165824)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.GetCategories()
            LCCHCS$ICommunityHandymanWorkServiceCategory$GetCategories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12892165824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCategories(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12892165824)
            
            //--TRIMMABLE-BOUNDARY-START(17187133120)
            //Generated interface implemetation for LivingThing.Core.Community.Handyman.Common.Services.ICommunityHandymanWorkServiceCategory.GetServiceRequests()
            LCCHCS$ICommunityHandymanWorkServiceCategory$GetServiceRequests()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17187133120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceRequests(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17187133120)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8609040726)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IIded.Identifier.get
            get LCFCD$IIded$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12904008022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(8609040726)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(12887361657)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.EstimateCost(LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation, LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation)
            LCSCS$IShippingService$EstimateCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887361657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EstimateCost(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12887361657)
            
            //--TRIMMABLE-BOUNDARY-START(21477296249)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.Shipments.get
            get LCSCS$IShippingService$Shipments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657165433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Shipments;
            }
            //--TRIMMABLE-BOUNDARY-END(21477296249)
            
            //--TRIMMABLE-BOUNDARY-START(30067230841)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.GetShipmentAsync(LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$GetShipmentAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067230841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetShipmentAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30067230841)
            
            //--TRIMMABLE-BOUNDARY-START(8592394361)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.CreateShipmentAsync(System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel>, string)
            LCSCS$IShippingService$CreateShipmentAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592394361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateShipmentAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8592394361)
            
            //--TRIMMABLE-BOUNDARY-START(4297427065)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.AddPackagesToShipment(LivingThing.Core.Shipping.Common.Models.IShipmentModel, System.Collections.Generic.IEnumerable<LivingThing.Core.Shipping.Common.Models.IShipmentPackageModel>)
            LCSCS$IShippingService$AddPackagesToShipment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297427065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddPackagesToShipment(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297427065)
            
            //--TRIMMABLE-BOUNDARY-START(25772263545)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.GetLocationAsync(LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$GetLocationAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772263545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLocationAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25772263545)
            
            //--TRIMMABLE-BOUNDARY-START(34362198137)
            //Generated interface implemetation for LivingThing.Core.Shipping.Common.Services.IShippingService.SetPackageDelivered(LivingThing.Core.Frameworks.Common.Data.DataId, LivingThing.Core.Frameworks.Common.Data.DataId)
            LCSCS$IShippingService$SetPackageDelivered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362198137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetPackageDelivered(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34362198137)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            static $h = 480801;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914270753),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079695905,
        "f": 50331777
      },
      "n": "Theme",
      "d": 480801,
      "h": 158914270753,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(158914270753),
//--TRIMMABLE-BOUNDARY-START(146029368865),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899826721,
        "f": 50331777
      },
      "n": "Requirements",
      "d": 480801,
      "h": 146029368865,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(146029368865),
//--TRIMMABLE-BOUNDARY-START(17180349985),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950153761,
        "f": 50331777
      },
      "n": "AutoVerifies",
      "d": 480801,
      "h": 17180349985,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17180349985),
//--TRIMMABLE-BOUNDARY-START(141734401569),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309892129,
        "f": 50331905
      },
      "n": "Name",
      "d": 480801,
      "h": 141734401569,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141734401569),
//--TRIMMABLE-BOUNDARY-START(137439434273),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719957537,
        "f": 50331905
      },
      "n": "Identifier",
      "d": 480801,
      "h": 137439434273,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137439434273),
//--TRIMMABLE-BOUNDARY-START(163209238049),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669630497,
        "f": 50331905
      },
      "n": "Title",
      "d": 480801,
      "h": 163209238049,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163209238049),
//--TRIMMABLE-BOUNDARY-START(30065251873),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540088353,
        "f": 50331905
      },
      "n": "Description",
      "d": 480801,
      "h": 30065251873,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065251873),
//--TRIMMABLE-BOUNDARY-START(133144466977),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130022945,
        "f": 50331905
      },
      "n": "Icon",
      "d": 480801,
      "h": 133144466977,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144466977),
//--TRIMMABLE-BOUNDARY-START(154619303457),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489761313,
        "f": 50331649
      },
      "n": "Shipments",
      "d": 480801,
      "h": 154619303457,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619303457)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475317281),
    {
      "r": 262145,
      "p": [
        {
          "n": "package",
          "p": 4053803
        }
      ],
      "n": "CanHandle",
      "d": 480801,
      "h": 21475317281,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475317281),
//--TRIMMABLE-BOUNDARY-START(115964597793),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory).$h,
      "n": "GetCategories",
      "d": 480801,
      "h": 115964597793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964597793),
//--TRIMMABLE-BOUNDARY-START(124554532385),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$UcdF.LCCHCM.ICommunityHandymanServiceRequestModel).$h,
      "n": "GetServiceRequests",
      "d": 480801,
      "h": 124554532385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554532385),
//--TRIMMABLE-BOUNDARY-START(34360219169),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "pickupLocation",
          "p": 13928790
        },
        {
          "n": "deliveryLocation",
          "p": 13928790
        }
      ],
      "n": "EstimateCost",
      "d": 480801,
      "h": 34360219169,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34360219169),
//--TRIMMABLE-BOUNDARY-START(128849499681),
    {
      "r": $.$$.STT.Task$$($.$YUlm.LCSCM.IShipmentModel).$h,
      "p": [
        {
          "n": "id",
          "p": 10455382
        }
      ],
      "n": "GetShipmentAsync",
      "d": 480801,
      "h": 128849499681,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(128849499681),
//--TRIMMABLE-BOUNDARY-START(25770284577),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentModel)).$h,
      "p": [
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        },
        {
          "n": "shipmentLabel",
          "p": 1310721
        }
      ],
      "n": "CreateShipmentAsync",
      "d": 480801,
      "h": 25770284577,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25770284577),
//--TRIMMABLE-BOUNDARY-START(12885382689),
    {
      "r": 178454529,
      "p": [
        {
          "n": "shipment",
          "p": 821369
        },
        {
          "n": "packages",
          "p": $.$$.SCG.IEnumerable$$($.$YUlm.LCSCM.IShipmentPackageModel).$h
        }
      ],
      "n": "AddPackagesToShipment",
      "d": 480801,
      "h": 12885382689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885382689),
//--TRIMMABLE-BOUNDARY-START(120259565089),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDG.GeoLocation).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        }
      ],
      "n": "GetLocationAsync",
      "d": 480801,
      "h": 120259565089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259565089),
//--TRIMMABLE-BOUNDARY-START(150324336161),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "shipmentId",
          "p": 10455382
        },
        {
          "n": "packageId",
          "p": 10455382
        }
      ],
      "n": "SetPackageDelivered",
      "d": 480801,
      "h": 150324336161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324336161)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167504205345),
    {
      "t": 63657642,
      "n": "unitOfWork",
      "d": 480801,
      "h": 167504205345,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(167504205345)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590415393),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 480801,
      "h": 8590415393,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590415393)
  ],
  "h": 480801
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable, $.$YUlm.LCSCS.IShippingService, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchLocalDeliveryScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchLocalDeliveryScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(480801)
        
        

        //--TRIMMABLE-BOUNDARY-START(546337)
        $asm.$cls(`$Gjye.LCCDS.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590480929)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590480929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$YUlm.LCSCS.IShippingService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Gjye.LCCDS.CommunityDispatchLocalAgentScheme, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchLocalAgentScheme, x);
                }, $cBNYmf ??= {"r":6478635,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$YUlm.LCSCS.IShippingService))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchLocalAgentScheme, x);
                }, $elQSsd ??= {"r":2459769,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Gjye.LCCDS.CommunityDispatchInterStateAgentScheme, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchInterStateAgentScheme, x);
                }, $EQARVe ??= {"r":6478635,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$YUlm.LCSCS.IShippingService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Gjye.LCCDS.CommunityDispatchBicycleScheme, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchBicycleScheme, x);
                }, $QojXVj ??= {"r":6478635,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$YUlm.LCSCS.IShippingService))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchBicycleScheme, x);
                }, $MoDhLk ??= {"r":2459769,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$YUlm.LCSCS.IShippingService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Gjye.LCCDS.CommunityDispatchBikeScheme, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchBikeScheme, x);
                }, $kNpEah ??= {"r":6478635,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$YUlm.LCSCS.IShippingService))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Gjye.LCCDS.CommunityDispatchBikeScheme, x);
                }, $OphPje ??= {"r":2459769,"p":[{"n":"x","p":327718}],"n":"","d":546337,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590480929)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Gjye.LCCDS.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295513633)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295513633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295513633)
            
            //--TRIMMABLE-BOUNDARY-START(4295513633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295513633)
            
            static $h = 546337;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590480929),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 546337,
      "h": 8590480929,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590480929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295513633),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 546337,
      "h": 4295513633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295513633)
  ],
  "h": 546337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(546337)
        
        

        //--TRIMMABLE-BOUNDARY-START(677409)
        $asm.$cls(`$Gjye.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295644705)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295644705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295644705)
            
            //--TRIMMABLE-BOUNDARY-START(4295644705)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295644705)
            
            static $h = 677409;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295644705),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 677409,
      "h": 4295644705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295644705)
  ],
  "h": 677409,
  "a": [
    {
      "t": 611873,
      "c": 4295579169
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(677409)
        
        

        //--TRIMMABLE-BOUNDARY-START(611873)
        $asm.$cls(`$Gjye.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295579169)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295579169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295579169)
            
            //--TRIMMABLE-BOUNDARY-START(4295579169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295579169)
            
            static $h = 611873;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295579169),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 611873,
      "h": 4295579169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295579169)
  ],
  "h": 611873
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(611873)
        
        

        //--TRIMMABLE-BOUNDARY-START(284193)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchInterStateAgentScheme`, ($self) => class CommunityDispatchInterStateAgentScheme extends $.$Gjye.LCCDS.CommunityDispatchInterStateDeliveryScheme
        {
            //--TRIMMABLE-BOUNDARY-START(4295251489)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295251489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295251489)
            
            //--TRIMMABLE-BOUNDARY-START(64424793633)
            /*string */ get Name()
            {
                return "InterStateAgent"/*CommunityDispatchPackageModel.InterStateSchemeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64424793633)
            
            //--TRIMMABLE-BOUNDARY-START(68719760929)
            /*string? */ get Title()
            {
                return "InterState Delivery"/*CommunityDispatchPackageModel.InterStateSchemeTitle*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68719760929)
            
            //--TRIMMABLE-BOUNDARY-START(8590218785)
            /*string? */ get Description()
            {
                return "Package delivery by Camel agent going to a package destination";
            }
            //--TRIMMABLE-BOUNDARY-END(8590218785)
            
            //--TRIMMABLE-BOUNDARY-START(55834859041)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.unitOfWork.LCFCI$IClientUnitOfWork$ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Dispatch.Resources", "img/agent.png", false));
            }
            //--TRIMMABLE-BOUNDARY-END(55834859041)
            
            //--TRIMMABLE-BOUNDARY-START(60129826337)
            /*DataId */ get Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1("/Camel/InterStateAgent"/*CommunityDispatchPackageModel.InterStateAgentIdentifier*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60129826337)
            
            static $h = 284193;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Gjye.LCCDS.CommunityDispatchInterStateDeliveryScheme; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424793633),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949957153,
        "f": 50364417
      },
      "n": "Name",
      "d": 284193,
      "h": 64424793633,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424793633),
//--TRIMMABLE-BOUNDARY-START(68719760929),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539891745,
        "f": 50364417
      },
      "n": "Title",
      "d": 284193,
      "h": 68719760929,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68719760929),
//--TRIMMABLE-BOUNDARY-START(8590218785),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180153377,
        "f": 50364417
      },
      "n": "Description",
      "d": 284193,
      "h": 8590218785,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590218785),
//--TRIMMABLE-BOUNDARY-START(55834859041),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770087969,
        "f": 50364417
      },
      "n": "Icon",
      "d": 284193,
      "h": 55834859041,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55834859041),
//--TRIMMABLE-BOUNDARY-START(60129826337),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360022561,
        "f": 50364417
      },
      "n": "Identifier",
      "d": 284193,
      "h": 60129826337,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60129826337)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295251489),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 284193,
      "h": 4295251489,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295251489)
  ],
  "h": 284193
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchInterStateAgentScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchInterStateAgentScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(284193)
        
        

        //--TRIMMABLE-BOUNDARY-START(218657)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchBikeScheme`, ($self) => class CommunityDispatchBikeScheme extends $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme
        {
            //--TRIMMABLE-BOUNDARY-START(4295185953)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295185953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295185953)
            
            //--TRIMMABLE-BOUNDARY-START(73014662689)
            /*string */ get Name()
            {
                return "Bike"/*CommunityDispatchPackageModel.BikeSchemeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73014662689)
            
            //--TRIMMABLE-BOUNDARY-START(81604597281)
            /*string? */ get Title()
            {
                return "Bike Delivery"/*CommunityDispatchPackageModel.BikeSchemeTitle*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81604597281)
            
            //--TRIMMABLE-BOUNDARY-START(8590153249)
            /*string? */ get Description()
            {
                return "Package delivery via dispatch bike";
            }
            //--TRIMMABLE-BOUNDARY-END(8590153249)
            
            //--TRIMMABLE-BOUNDARY-START(64424728097)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.unitOfWork.LCFCI$IClientUnitOfWork$ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Dispatch.Resources", "img/bike.png", false));
            }
            //--TRIMMABLE-BOUNDARY-END(64424728097)
            
            //--TRIMMABLE-BOUNDARY-START(68719695393)
            /*DataId */ get Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1("/Camel/Bike"/*CommunityDispatchPackageModel.BikeRiderIdentifier*/);
            }
            //--TRIMMABLE-BOUNDARY-END(68719695393)
            
            //--TRIMMABLE-BOUNDARY-START(77309629985)
            /*IEnumerable<IAccountRequirementVerifier>? */ get Requirements()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCP.IAccountRequirementVerifier), [(() =>
                {
                    //new $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier()
                    const $t1 = $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier;
                    const $i1 = new $t1();
                    $i1.$ctor$1(this.unitOfWork, "Rider's card", "Upload the front and back page of your rider's ID card.", "RiderCard");
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-card"/*MaterialDesignIconNames.Card*/);
                    return $i1;
                })(), (() =>
                {
                    //new $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier()
                    const $t2 = $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier;
                    const $i2 = new $t2();
                    $i2.$ctor$1(this.unitOfWork, "State Hackney Permit", "Upload the front page of your Hackney permit for the state you are.", "HackneyPermit");
                    $i2.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-gate"/*MaterialDesignIconNames.Gate*/);
                    return $i2;
                })(), (() =>
                {
                    //new $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier()
                    const $t3 = $.$ahDc.LCCCSA.CommunityDocumentUploadRequirementVerifier;
                    const $i3 = new $t3();
                    $i3.$ctor$1(this.unitOfWork, "Bike Insurance", "Upload the front page of your bike insurance documet", "BikeInsurance");
                    $i3.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-bike"/*MaterialDesignIconNames.Bike*/);
                    return $i3;
                })()], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(77309629985)
            
            static $h = 218657;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014662689),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949891617,
        "f": 50364417
      },
      "n": "Name",
      "d": 218657,
      "h": 73014662689,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014662689),
//--TRIMMABLE-BOUNDARY-START(81604597281),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129760801,
        "f": 50364417
      },
      "n": "Title",
      "d": 218657,
      "h": 81604597281,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604597281),
//--TRIMMABLE-BOUNDARY-START(8590153249),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180087841,
        "f": 50364417
      },
      "n": "Description",
      "d": 218657,
      "h": 8590153249,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590153249),
//--TRIMMABLE-BOUNDARY-START(64424728097),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770022433,
        "f": 50364417
      },
      "n": "Icon",
      "d": 218657,
      "h": 64424728097,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424728097),
//--TRIMMABLE-BOUNDARY-START(68719695393),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359957025,
        "f": 50364417
      },
      "n": "Identifier",
      "d": 218657,
      "h": 68719695393,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68719695393),
//--TRIMMABLE-BOUNDARY-START(77309629985),
    {
      "p": $.$$.SCG.IEnumerable$$($.$LCOv.LCFCP.IAccountRequirementVerifier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539826209,
        "f": 50364417
      },
      "n": "Requirements",
      "d": 218657,
      "h": 77309629985,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309629985)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295185953),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 218657,
      "h": 4295185953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295185953)
  ],
  "h": 218657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable, $.$YUlm.LCSCS.IShippingService, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchBikeScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchBikeScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(218657)
        
        

        //--TRIMMABLE-BOUNDARY-START(415265)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchLocalAgentScheme`, ($self) => class CommunityDispatchLocalAgentScheme extends $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme
        {
            //--TRIMMABLE-BOUNDARY-START(4295382561)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295382561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295382561)
            
            //--TRIMMABLE-BOUNDARY-START(73014859297)
            /*string */ get Name()
            {
                return "LocalAgent"/*CommunityDispatchPackageModel.LocalSchemeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73014859297)
            
            //--TRIMMABLE-BOUNDARY-START(81604793889)
            /*string? */ get Title()
            {
                return "Agent Delivery"/*CommunityDispatchPackageModel.LocalSchemeTitle*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81604793889)
            
            //--TRIMMABLE-BOUNDARY-START(8590349857)
            /*string? */ get Description()
            {
                return "Package delivery by Camel agent going to a package destination";
            }
            //--TRIMMABLE-BOUNDARY-END(8590349857)
            
            //--TRIMMABLE-BOUNDARY-START(64424924705)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.unitOfWork.LCFCI$IClientUnitOfWork$ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Dispatch.Resources", "img/agent.png", false));
            }
            //--TRIMMABLE-BOUNDARY-END(64424924705)
            
            //--TRIMMABLE-BOUNDARY-START(77309826593)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1($.$fPer.LCFC.Theme.Success);
            }
            //--TRIMMABLE-BOUNDARY-END(77309826593)
            
            //--TRIMMABLE-BOUNDARY-START(68719892001)
            /*DataId */ get Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1("/Camel/LocalAgent"/*CommunityDispatchPackageModel.LocalAgentIdentifier*/);
            }
            //--TRIMMABLE-BOUNDARY-END(68719892001)
            
            static $h = 415265;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014859297),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950088225,
        "f": 50364417
      },
      "n": "Name",
      "d": 415265,
      "h": 73014859297,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014859297),
//--TRIMMABLE-BOUNDARY-START(81604793889),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129957409,
        "f": 50364417
      },
      "n": "Title",
      "d": 415265,
      "h": 81604793889,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604793889),
//--TRIMMABLE-BOUNDARY-START(8590349857),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180284449,
        "f": 50364417
      },
      "n": "Description",
      "d": 415265,
      "h": 8590349857,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590349857),
//--TRIMMABLE-BOUNDARY-START(64424924705),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770219041,
        "f": 50364417
      },
      "n": "Icon",
      "d": 415265,
      "h": 64424924705,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424924705),
//--TRIMMABLE-BOUNDARY-START(77309826593),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540022817,
        "f": 50364417
      },
      "n": "Theme",
      "d": 415265,
      "h": 77309826593,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309826593),
//--TRIMMABLE-BOUNDARY-START(68719892001),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360153633,
        "f": 50364417
      },
      "n": "Identifier",
      "d": 415265,
      "h": 68719892001,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68719892001)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295382561),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 415265,
      "h": 4295382561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295382561)
  ],
  "h": 415265
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable, $.$YUlm.LCSCS.IShippingService, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchLocalAgentScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchLocalAgentScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(415265)
        
        

        //--TRIMMABLE-BOUNDARY-START(153121)
        $asm.$cls(`$Gjye.LCCDS.CommunityDispatchBicycleScheme`, ($self) => class CommunityDispatchBicycleScheme extends $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme
        {
            //--TRIMMABLE-BOUNDARY-START(4295120417)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295120417);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295120417)
            
            //--TRIMMABLE-BOUNDARY-START(68719629857)
            /*string */ get Name()
            {
                return "Bicycle"/*CommunityDispatchPackageModel.BicycleSchemeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68719629857)
            
            //--TRIMMABLE-BOUNDARY-START(73014597153)
            /*string? */ get Title()
            {
                return "Bicycle Delivery"/*CommunityDispatchPackageModel.BicycleSchemeTitle*/;
            }
            //--TRIMMABLE-BOUNDARY-END(73014597153)
            
            //--TRIMMABLE-BOUNDARY-START(12885055009)
            /*string? */ get Description()
            {
                return "Package delivery via bicycle";
            }
            //--TRIMMABLE-BOUNDARY-END(12885055009)
            
            //--TRIMMABLE-BOUNDARY-START(60129695265)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit(this.unitOfWork.LCFCI$IClientUnitOfWork$ResourcePathResolver.LCFCC$IResourcePathResolver$Resolve("LivingThing.Core.Community.Dispatch.Resources", "img/bicycle.png", false));
            }
            //--TRIMMABLE-BOUNDARY-END(60129695265)
            
            //--TRIMMABLE-BOUNDARY-START(64424662561)
            /*DataId */ get Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1("/Camel/Bicycle"/*CommunityDispatchPackageModel.BicycleRiderIdentifier*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64424662561)
            
            //--TRIMMABLE-BOUNDARY-START(8590087713)
            /*bool */ CanHandle(/*CommunityDispatchPackageModel*/ $package)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590087713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (super.CanHandle($package))
                {
                    if ($package.Delivery.PickupLocation === null)
                    {
                        return true;
                    }
                    if ($package.Delivery.DeliveryLocation === null)
                    {
                        return true;
                    }
                    return ($package.Delivery.DeliveryLocation !== null && $package.Delivery.PickupLocation !== null && $.$fPer.LCFCDM.Length.op_LessThan($package.Delivery.PickupLocation.DistanceTo($package.Delivery.DeliveryLocation), new $.$fPer.LCFCDM.Length().$ctor$3(5, 7/*LengthUnitTypes.km*/)));
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8590087713)
            
            static $h = 153121;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Gjye.LCCDS.CommunityDispatchLocalDeliveryScheme; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719629857),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244793377,
        "f": 50364417
      },
      "n": "Name",
      "d": 153121,
      "h": 68719629857,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68719629857),
//--TRIMMABLE-BOUNDARY-START(73014597153),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834727969,
        "f": 50364417
      },
      "n": "Title",
      "d": 153121,
      "h": 73014597153,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014597153),
//--TRIMMABLE-BOUNDARY-START(12885055009),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474989601,
        "f": 50364417
      },
      "n": "Description",
      "d": 153121,
      "h": 12885055009,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885055009),
//--TRIMMABLE-BOUNDARY-START(60129695265),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064924193,
        "f": 50364417
      },
      "n": "Icon",
      "d": 153121,
      "h": 60129695265,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60129695265),
//--TRIMMABLE-BOUNDARY-START(64424662561),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654858785,
        "f": 50364417
      },
      "n": "Identifier",
      "d": 153121,
      "h": 64424662561,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424662561)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590087713),
    {
      "r": 262145,
      "p": [
        {
          "n": "package",
          "p": 4053803
        }
      ],
      "n": "CanHandle",
      "d": 153121,
      "h": 8590087713,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590087713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295120417),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 153121,
      "h": 4295120417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295120417)
  ],
  "h": 153121
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bRsy.LCCDCS.ICommunityDispatchPackageScheme, $.$UcdF.LCCHCS.ICommunityHandymanWorkServiceCategory, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IIded, $.$vWqU.LCFCC.IThemable, $.$YUlm.LCSCS.IShippingService, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes.CommunityDispatchBicycleScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}CommunityDispatchBicycleScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(153121)
        
        

        //--TRIMMABLE-BOUNDARY-START(87585)
        $asm.$cls(`$Gjye.LCCDS._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590022177)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590022177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590022177)
            
            //--TRIMMABLE-BOUNDARY-START(4295054881)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295054881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295054881)
            
            //--TRIMMABLE-BOUNDARY-START(4295054881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295054881)
            
            static $h = 87585;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590022177),
    {
      "r": 65537,
      "n": "Execute",
      "d": 87585,
      "h": 8590022177,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590022177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295054881),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 87585,
      "h": 4295054881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295054881)
  ],
  "h": 87585
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Dispatch.Schemes._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Dispatch${separator}Schemes${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(87585)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Handyman.Common", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Community.Dispatch.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(22049)
