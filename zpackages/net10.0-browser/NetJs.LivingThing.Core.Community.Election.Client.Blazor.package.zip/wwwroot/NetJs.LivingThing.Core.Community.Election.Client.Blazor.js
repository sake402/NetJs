
//--TRIMMABLE-BOUNDARY-START(49198)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $wZnq, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $yleQ, $nYKj, $AvdQ, $xPgy, $ljzt, $TLYN, $hDPm, $wtdm, $sZVd, $lJUR, $dgLE, $cnlM, $OJJQ, $YUlm, $LCOv, $ydCm, $DJRY, $EVvT, $MdeX, $Jxyt, $SeJP, $mskq, $ySWu, $ahDc, $TBFc) {
    "use strict";
    let _;
    let $WRfkZa;
    let $BNiHMe;
    let $JVKWpb;
    let $XwsTrk;
    let $ZDLgab;
    let $trTOEg;
    let $Rjddnf;
    let $FagaBe;
    let $xuzjJh;
    let $hEzoWd;
    let $mdWcha;
    let $ROHLQb;
    let $JruJuc;
    let $iOSYdj;
    let $Mcizdi;
    let $Ueawlh;
    let $edjlHd;
    let $JxRUqk;
    let $SKshae;
    let $UEcsWi;
    let $luvXYh;
    let $oEXwIb;
    let $YPsumh;
    let $eAvOWj;
    let $STjkYc;
    let $iSXOxk;
    let $UDeGvj;
    let $WgSHRe;
    let $XXsbfk;
    let $VjSafi;
    let $ByeGWi;
    let $WDcClf;
    let $eOHeha;
    let $ECmcti;
    let $HMASze;
    let $TkPLub;
    let $zaWDId;
    let $ROdJZi;
    let $enFbIi;
    let $BgYple;
    let $BQPTYc;
    let $wqrmJb;
    let $NWQjFg;
    let $TCajoh;
    let $dqJIfa;
    let $oNcMEe;
    let $FfMCfb;
    let $rZqYzb;
    let $wKBgLf;
    let $HXaDJf;
    let $DZUfNh;
    let $PVZEva;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Community.Election.Client.Blazor", 
    {
  "h": 49198,
  "f": "LivingThing.Core.Community.Election.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Community.Election.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Community.Election.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(376878)
        $asm.$cls(`$Jsis.LCCEC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295344174)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295344174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$Jsis.LCCEC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295344174)
            
            static $h = 376878;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295344174),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 376878,
      "h": 4295344174,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295344174)
  ],
  "h": 376878
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(376878)
        
        

        //--TRIMMABLE-BOUNDARY-START(114734)
        $asm.$cls(`$Jsis._LCCECSC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295082030)
            static /*void */ CreateCommunityPostHeader_0(TPostModel, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TPostModel*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Community.Client.Shared.Posts.CommunityPostHeaderFeatures*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295082030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostHeader$$(TPostModel), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TPostModel));
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$ahDc.LCCCSP.CommunityPostHeaderFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295082030)
            
            static $h = 114734;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295082030),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TPostModel) => TPostModel.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 30709184
        }
      ],
      "g": [
        "TPostModel"
      ],
      "n": "CreateCommunityPostHeader_0",
      "d": 114734,
      "h": 4295082030,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295082030)
  ],
  "h": 114734
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Election.Client.Shared.CandidateView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}CandidateView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(114734)
        
        

        //--TRIMMABLE-BOUNDARY-START(180270)
        $asm.$cls(`$Jsis._LCCECSE.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295147566)
            static /*void */ CreateEditable_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<TValue>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295147566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295147566)
            
            //--TRIMMABLE-BOUNDARY-START(8590114862)
            static /*void */ CreateEditable_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4, /*int*/ __seq5, /*global::Microsoft.AspNetCore.Components.RenderFragment<TValue>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590114862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.AddComponentParameter(__seq5, "ChildContent", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590114862)
            
            static $h = 180270;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295147566),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.RenderFragment$$(TValue).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_0",
      "d": 180270,
      "h": 4295147566,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295147566),
//--TRIMMABLE-BOUNDARY-START(8590114862),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$mac.MAC.RenderFragment$$(TValue).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_1",
      "d": 180270,
      "h": 8590114862,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590114862)
  ],
  "h": 180270
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Election.Client.Shared.ElectionView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}ElectionView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180270)
        
        

        //--TRIMMABLE-BOUNDARY-START(245806)
        $asm.$cls(`$Jsis._LCCECSP.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295213102)
            static /*void */ CreateCommunityPostHeader_0(TPostModel, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*TPostModel*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Community.Client.Shared.Posts.CommunityPostHeaderFeatures*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295213102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ahDc.LCCCSP.CommunityPostHeader$$(TPostModel), seq);
                __builder.AddComponentParameter(__seq0, "ViewModel", $.$box(__arg0, TPostModel));
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$ahDc.LCCCSP.CommunityPostHeaderFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295213102)
            
            static $h = 245806;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213102),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (TPostModel) => TPostModel.$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 30709184
        }
      ],
      "g": [
        "TPostModel"
      ],
      "n": "CreateCommunityPostHeader_0",
      "d": 245806,
      "h": 4295213102,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295213102)
  ],
  "h": 245806
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Community.Election.Client.Shared.PositionView.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}PositionView${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(245806)
        
        

        //--TRIMMABLE-BOUNDARY-START(442414)
        $asm.$cls(`$Jsis.LCCEC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180311598)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Jsis.LCCECP.CommunityElectionApp.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Jsis.LCCECP.CommunityElectionApp().$ctor$6();
                    }, $WRfkZa ??= {"r":2752627,"n":"","d":442414,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Jsis.LCCECS$1.CandidateCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Jsis.LCCECS$1.CandidateCard().$ctor$5();
                    }, $BNiHMe ??= {"r":2752627,"n":"","d":442414,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Jsis.LCCECS$1.CandidateView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Jsis.LCCECS$1.CandidateView().$ctor$4();
                    }, $JVKWpb ??= {"r":2752627,"n":"","d":442414,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Jsis.LCCECS$1.ElectionView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Jsis.LCCECS$1.ElectionView().$ctor$5();
                    }, $XwsTrk ??= {"r":2752627,"n":"","d":442414,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$Jsis.LCCECS$1.PositionView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$Jsis.LCCECS$1.PositionView().$ctor$4();
                    }, $ZDLgab ??= {"r":2752627,"n":"","d":442414,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180311598)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295409710)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295409710)
            
            //--TRIMMABLE-BOUNDARY-START(4295409710)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295409710)
            
            static $h = 442414;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180311598),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885344302,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 442414,
      "h": 17180311598,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180311598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295409710),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 442414,
      "h": 4295409710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295409710)
  ],
  "h": 442414
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442414)
        
        

        //--TRIMMABLE-BOUNDARY-START(573486)
        $asm.$cls(`$Jsis.LCCEC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590508078)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590508078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ahDc.LCCC.Startup.AddCommunityService$1($.$Jsis.LCCECS.CommunityElectionService, $.$LCOv.LCFCPMC.CategoryPostModel, $.$TBFc.LCCECM.CommunityElectionPostModel, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$ahDc.LCCCS.ICommunityClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$sZVd.LCFCA.IClientApplication, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Jsis.LCCECS.CommunityElectionApplication, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$sZVd.LCFCA.IClientApplication))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionApplication, x);
                }, $trTOEg ??= {"r":1409747,"p":[{"n":"x","p":327718}],"n":"","d":573486,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$ahDc.LCCCS.ICommunityClientApplication))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionApplication, x);
                }, $Rjddnf ??= {"r":17470912,"p":[{"n":"x","p":327718}],"n":"","d":573486,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ahDc.LCCCF.ICommunityMainFeedProvider, $.$Jsis.LCCECS.CommunityElectionFeedProvider, services);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$TBFc.LCCECM.CommunityElectionPostModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$TBFc.LCCECM.CommunityElectionPositionModel, services, null);
                $.$lJUR.LCFCS.Startup.AddServerDataFromPathProvider$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, services, null);
                $.$Jsis.LCCEC._Startup.AddGeneratedComponentOptimizers(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$LCOv.LCFCPS.IPostFeatureProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$LCOv.LCFCPS.IAccountFeatureProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$Jsis.LCCECS.CommunityElectionFeatureProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$LCOv.LCFCPS.IAccountFeatureProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionFeatureProvider, x);
                }, $FagaBe ??= {"r":25160116,"p":[{"n":"x","p":327718}],"n":"","d":573486,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$LCOv.LCFCPS.IPostFeatureProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionFeatureProvider, x);
                }, $xuzjJh ??= {"r":26208692,"p":[{"n":"x","p":327718}],"n":"","d":573486,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590508078)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Jsis.LCCEC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295540782)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295540782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295540782)
            
            //--TRIMMABLE-BOUNDARY-START(4295540782)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295540782)
            
            static $h = 573486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590508078),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 573486,
      "h": 8590508078,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590508078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295540782),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 573486,
      "h": 4295540782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295540782)
  ],
  "h": 573486
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573486)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163310)
        $asm.$cls(`$Jsis.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296130606)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296130606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296130606)
            
            //--TRIMMABLE-BOUNDARY-START(4296130606)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296130606)
            
            static $h = 1163310;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296130606),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1163310,
      "h": 4296130606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296130606)
  ],
  "h": 1163310
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163310)
        
        

        //--TRIMMABLE-BOUNDARY-START(1228846)
        $asm.$cls(`$Jsis.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296196142)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296196142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296196142)
            
            //--TRIMMABLE-BOUNDARY-START(4296196142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296196142)
            
            static $h = 1228846;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296196142),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1228846,
      "h": 4296196142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296196142)
  ],
  "h": 1228846,
  "a": [
    {
      "t": 1163310,
      "c": 4296130606
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1228846)
        
        

        //--TRIMMABLE-BOUNDARY-START(311342)
        $asm.$cls(`$Jsis.LCCEC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590245934)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590245934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590245934)
            
            //--TRIMMABLE-BOUNDARY-START(4295278638)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295278638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278638)
            
            //--TRIMMABLE-BOUNDARY-START(4295278638)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278638)
            
            static $h = 311342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590245934),
    {
      "r": 65537,
      "n": "Execute",
      "d": 311342,
      "h": 8590245934,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590245934)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278638),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 311342,
      "h": 4295278638,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295278638)
  ],
  "h": 311342
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311342)
        
        

        //--TRIMMABLE-BOUNDARY-START(704558)
        $asm.$cls(`$Jsis.LCCECS.CommunityElectionFeatureProvider`, ($self) => class CommunityElectionFeatureProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60130246702)
            /*string? */ get Title()
            {
                return "Election";
            }
            //--TRIMMABLE-BOUNDARY-END(60130246702)
            
            //--TRIMMABLE-BOUNDARY-START(51540312110)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-vote"/*MaterialDesignIconNames.Vote*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540312110)
            
            //--TRIMMABLE-BOUNDARY-START(8590639150)
            /*string? */ get Description()
            {
                return "Nominate and vote for a member";
            }
            //--TRIMMABLE-BOUNDARY-END(8590639150)
            
            //--TRIMMABLE-BOUNDARY-START(55835279406)
            /*string? */ get Name()
            {
                return "Election";
            }
            //--TRIMMABLE-BOUNDARY-END(55835279406)
            
            //--TRIMMABLE-BOUNDARY-START(47245344814)
            /*RenderFragment? */ GetFeatureView(TPost, /*TPost*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245344814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(47245344814)
            
            //--TRIMMABLE-BOUNDARY-START(4313290176)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunityPostFeatureViewProvider.GetFeatureView<TPost>(TPost)
            LCCCS$ICommunityPostFeatureViewProvider$GetFeatureView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313290176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFeatureView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313290176)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4295671854)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295671854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295671854)
            
            //--TRIMMABLE-BOUNDARY-START(4295671854)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295671854)
            
            static $h = 704558;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130246702),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950377518,
        "f": 50331649
      },
      "n": "Title",
      "d": 704558,
      "h": 60130246702,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130246702),
//--TRIMMABLE-BOUNDARY-START(51540312110),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770508334,
        "f": 50331649
      },
      "n": "Icon",
      "d": 704558,
      "h": 51540312110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540312110),
//--TRIMMABLE-BOUNDARY-START(8590639150),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180573742,
        "f": 50331649
      },
      "n": "Description",
      "d": 704558,
      "h": 8590639150,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590639150),
//--TRIMMABLE-BOUNDARY-START(55835279406),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360442926,
        "f": 50331649
      },
      "n": "Name",
      "d": 704558,
      "h": 55835279406,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835279406)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245344814),
    {
      "r": 6881395,
      "p": [
        {
          "n": "post",
          "p": (TPost) => TPost.$h
        }
      ],
      "g": [
        "TPost"
      ],
      "n": "GetFeatureView",
      "d": 704558,
      "h": 47245344814,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47245344814)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295671854),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 704558,
      "h": 4295671854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295671854)
  ],
  "h": 704558
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$LCOv.LCFCPS.IAccountFeatureProvider$$($.$TBFc.LCCECM.CommunityElectionFeatureModel), $.$LCOv.LCFCPS.IPostFeatureProvider$$($.$TBFc.LCCECM.CommunityElectionFeatureModel), $.$ahDc.LCCCS.ICommunityAccountFeatureViewProvider, $.$ahDc.LCCCS.ICommunityPostFeatureViewProvider, $.$LCOv.LCFCPS.IAccountFeatureProvider, $.$LCOv.LCFCPS.IPostFeatureProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Services.CommunityElectionFeatureProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Services${separator}CommunityElectionFeatureProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(704558)
        
        

        //--TRIMMABLE-BOUNDARY-START(966702)
        $asm.$cls(`$Jsis.LCCECS$1.CandidateView`, ($self) => class CandidateView extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)
        {
            //--TRIMMABLE-BOUNDARY-START(115965083694)
            /*string */ get OptimizedComponentName()
            {
                return "candidateview";
            }
            //--TRIMMABLE-BOUNDARY-END(115965083694)
            
            //--TRIMMABLE-BOUNDARY-START(176094625838)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094625838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Scope":
                    this.Scope = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094625838)
            
            //--TRIMMABLE-BOUNDARY-START(85900312622)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900312622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(85900312622)
            
            //--TRIMMABLE-BOUNDARY-START(137439920174)
            /*CommunityElectionService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(137439920174)
            
            //--TRIMMABLE-BOUNDARY-START(38655672366)
            /*CommunityElectionPostModel?*/ election = null;
            //--TRIMMABLE-BOUNDARY-END(38655672366)
            
            //--TRIMMABLE-BOUNDARY-START(133144952878)
            /*PostBaseModel?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(133144952878)
            
            //--TRIMMABLE-BOUNDARY-START(98785214510)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(98785214510)
            
            //--TRIMMABLE-BOUNDARY-START(94490247214)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94490247214)
            
            //--TRIMMABLE-BOUNDARY-START(107375149102)
            /*IEnumerable<CommunityElectionCandidateModel>?*/ nominations = null;
            //--TRIMMABLE-BOUNDARY-END(107375149102)
            
            //--TRIMMABLE-BOUNDARY-START(120260050990)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(120260050990)
            
            //--TRIMMABLE-BOUNDARY-START(120260050990)
            //--TRIMMABLE-BOUNDARY-START(30065737774)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065737774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065737774)
            
            //--TRIMMABLE-BOUNDARY-START(128849985582)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849985582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(128849985582)
            
            //--TRIMMABLE-BOUNDARY-END(120260050990)
            
            //--TRIMMABLE-BOUNDARY-START(111670116398)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670116398);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.election = $.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$TBFc.LCCECM.CommunityElectionPostModel, this.RequiredParameter, null);
                    ($t3 = this.RequiredParameter.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (this.election === null)
                    {
                        this.election = this.RequiredParameter.Election;
                    }
                    if (this.election !== null)
                    {
                        let $t4, $r4;
                        this.nominations = ($t4 = $.$ydCm.LCCC.PostUtility.GetCommunityPostLogicalAssociations($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, 0/*PostLogicalQueryFilterType.And*/, $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.RequiredParameter.NomineeAccount.Identifier ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>?*/ let __ca1__;
                        this.nominations = ((__ca1__ = this.nominations) !== null ? $.$sl.SL.Enumerable.Except$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, __ca1__, $.$$.SRC.RuntimeHelpers.CreateArray($.$TBFc.LCCECM.CommunityElectionCandidateModel.$type, [ this.RequiredParameter ], null, null)) : null);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670116398)
            
            //--TRIMMABLE-BOUNDARY-START(103080181806)
            /*Task */ Nominate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080181806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Nominate(this.election, this.Scope, null, this.RequiredParameter);
            }
            //--TRIMMABLE-BOUNDARY-END(103080181806)
            
            //--TRIMMABLE-BOUNDARY-START(180389593134)
            /*Task */ Vote()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389593134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Vote(this.election, this.Scope, null, this.RequiredParameter);
            }
            //--TRIMMABLE-BOUNDARY-END(180389593134)
            
            //--TRIMMABLE-BOUNDARY-START(90195279918)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195279918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(90195279918)
            
            //--TRIMMABLE-BOUNDARY-START(34360705070)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360705070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Parameter === null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 1);
                    __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                    __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        $.$Jsis._LCCECSC.TypeInference.CreateCommunityPostHeader_0($.$TBFc.LCCECM.CommunityElectionCandidateModel, __builder2, 5, 6, this.RequiredParameter, 7, 0/*CommunityPostHeaderFeatures.Default*/ | 1/*CommunityPostHeaderFeatures.Banner*/);
                        __builder2.AddMarkupContent(8, "\r\n\r\n        ");
                        __builder2.OpenElement(9, "div");
                        __builder2.AddAttribute$5(10, "class", "pd");
                        __builder2.OpenElement(11, "h1");
                        __builder2.AddAttribute$5(12, "class", "mg-0");
                        __builder2.AddContent$4(13, this.election !== null ? $.$strNN(this.election.Title) + ": " : null);
                        __builder2.AddContent$4(14, this.RequiredParameter.Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(15, "\r\n            ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 16);
                        __builder2.AddComponentParameter(17, "Class", "mgt");
                        __builder2.AddComponentParameter(18, "Enable", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Boolean), this.Service.CommunityService.MainAccount.Equals$1(this.RequiredParameter.NomineeAccount)), $.$$.S.Boolean));
                        __builder2.AddComponentParameter(19, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.RequiredParameter.Post));
                        __builder2.AddComponentParameter(20, "ValueChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.String), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.RequiredParameter.Post = __value;
                        }, $UDeGvj ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":966702,"h":0,"f":17825794}), this.RequiredParameter.Post))));
                        __builder2.AddComponentParameter(21, "ValueExpression", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$sle.SLE.Expression$$($.$$.S.Func$$($.$$.S.String)), ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                        {
                            return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "RequiredParameter"), "Post"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                        }, $WgSHRe ??= {"r":38797349,"n":"","d":966702,"h":0,"f":17825794})).Invoke())));
                        __builder2.CloseComponent();
                        /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>?*/ let __ca1__;
                        if ((__ca1__ = this.nominations) !== null ? $.$sl.SL.Enumerable.Any$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, __ca1__) : false)
                        {
                            __builder2.AddMarkupContent(22, "<div class=\"flex mgb mgt-10\"><h3 class=\"mgy-a fill\">\r\n                        Past Nominations\r\n                    </h3></div>\r\n                ");
                            __builder2.OpenElement(23, "div");
                            __builder2.AddAttribute$5(24, "class", "grid colm-1 gap-1");
                            let $en5 = this.nominations.SCG$IEnumerable$$$GetEnumerator();
                            while ($en5.SC$1$IEnumerator$MoveNext())
                            {
                                let candidate = $en5.SCG$IEnumerator$$$Current;
                                {
                                    __builder2.OpenComponent$1($.$Jsis.LCCECS$1.CandidateCard, 25);
                                    __builder2.AddComponentParameter(26, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionCandidateModel, candidate));
                                    __builder2.AddComponentParameter(27, "Election", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionPostModel, this.election));
                                    __builder2.CloseComponent();
                                }
                            }
                            __builder2.CloseElement();
                        }
                        __builder2.AddMarkupContent(28, "<div class=\"flex mgb mgt-10\"><h3 class=\"mgy-a fill\">\r\n                    Photo Gallery\r\n                </h3></div>\r\n            ");
                        __builder2.OpenElement(29, "div");
                        __builder2.AddAttribute$5(30, "class", "pos-rel");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.MediaGroup, 31);
                        __builder2.AddComponentParameter(32, "Class", "mgt");
                        __builder2.AddComponentParameter(33, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                        __builder2.AddComponentParameter(34, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$6(this.RequiredParameter.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(2/*ResourceFilterType.UsedBy*/, $.$Iaui.LCFCM.ResourceFilterType) ], null, null))));
                        __builder2.AddComponentParameter(35, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), $.$ahDc.LCCC.Utility.GridGap$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$$.S.Int32));
                        __builder2.AddComponentParameter(36, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), $.$ahDc.LCCC.Utility.GridWidth$1(this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Box)), $.$$.S.Int32));
                        __builder2.AddComponentParameter(37, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 32n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddComponentParameter(38, "MediaGroupFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaGroupFeatures, 0/*MediaGroupFeatures.Default*/ | 2/*MediaGroupFeatures.Upload*/), $.$hDPm.LCFCCM$3.MediaGroupFeatures));
                        __builder2.AddComponentParameter(39, "MediaFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ | 4/*MediaFeatures.Background*/ | 16/*MediaFeatures.EnterFullScreen*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                        __builder2.AddAttribute$3(40, "FullScreenView", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCM$3.MediaContext))().$ctor(this, ( (/*view*/ view) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$ahDc.LCCCS$1.CommunityMedia, 41);
                                __builder3.AddComponentParameter(42, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$Iaui.LCFCM.ResourceModel, view.Resource));
                                __builder3.AddComponentParameter(43, "MediaView", (view.View));
                                __builder3.CloseComponent();
                            }, $XXsbfk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":966702,"h":0,"f":17825794});
                        }), $VjSafi ??= {"r":6881395,"p":[{"n":"view","p":35083946}],"n":"","d":966702,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(44, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                        }), $ByeGWi ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":966702,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                        if (this.election !== null)
                        {
                            if (this.election.State === 0/*CommunityElectionState.Pending*/)
                            {
                                __builder2.OpenElement(45, "button");
                                __builder2.AddAttribute$5(46, "class", "pd corner bg-primary wf mgt");
                                __builder2.AddAttribute$5(47, "title", `Nominate someone for a ${$.$strNN((this.election.PositionLabel ?? "Position"))}`);
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 48, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Nominate)));
                                __builder2.AddContent$4(49, "Nominate");
                                __builder2.CloseElement();
                            }
                            else if (this.election.State === 1/*CommunityElectionState.Ongoing*/)
                            {
                                __builder2.OpenElement(50, "button");
                                __builder2.AddAttribute$5(51, "class", "pd corner bg-primary wf mgt");
                                __builder2.AddAttribute$5(52, "title", `Vote someone for a ${$.$strNN((this.election.PositionLabel ?? "Position"))}`);
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 53, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Vote)));
                                __builder2.AddContent$4(54, "Vote");
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                    }), $WDcClf ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":966702,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360705070)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21475803182)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475803182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475803182)
            
            //--TRIMMABLE-BOUNDARY-START(21475803182)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21475803182)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137439920174)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(137439920174)
                
                //--TRIMMABLE-BOUNDARY-START(98785214510)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(98785214510)
                
            }
            static $h = 966702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$TBFc.LCCECM.CommunityElectionCandidateModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965083694),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425476142,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 966702,
      "h": 115965083694,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965083694),
//--TRIMMABLE-BOUNDARY-START(137439920174),
    {
      "p": 835630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605345326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799658542,
        "f": 83886081
      },
      "n": "Service",
      "d": 966702,
      "h": 137439920174,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439920174),
//--TRIMMABLE-BOUNDARY-START(133144952878),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015410734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209723950,
        "f": 83886081
      },
      "n": "Scope",
      "d": 966702,
      "h": 133144952878,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144952878),
//--TRIMMABLE-BOUNDARY-START(98785214510),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835541550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619789358,
        "f": 83886081
      },
      "n": "Loading",
      "d": 966702,
      "h": 98785214510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785214510),
//--TRIMMABLE-BOUNDARY-START(94490247214),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245606958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029854766,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 966702,
      "h": 94490247214,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490247214)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094625838),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 966702,
      "h": 176094625838,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094625838),
//--TRIMMABLE-BOUNDARY-START(85900312622),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 966702,
      "h": 85900312622,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900312622),
//--TRIMMABLE-BOUNDARY-START(111670116398),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 966702,
      "h": 111670116398,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(111670116398),
//--TRIMMABLE-BOUNDARY-START(103080181806),
    {
      "r": 178454529,
      "n": "Nominate",
      "d": 966702,
      "h": 103080181806,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080181806),
//--TRIMMABLE-BOUNDARY-START(180389593134),
    {
      "r": 178454529,
      "n": "Vote",
      "d": 966702,
      "h": 180389593134,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389593134),
//--TRIMMABLE-BOUNDARY-START(90195279918),
    {
      "r": 181338113,
      "n": "Load",
      "d": 966702,
      "h": 90195279918,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195279918),
//--TRIMMABLE-BOUNDARY-START(34360705070),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 966702,
      "h": 34360705070,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360705070)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655672366),
    {
      "t": 1632809,
      "n": "election",
      "d": 966702,
      "h": 38655672366,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655672366),
//--TRIMMABLE-BOUNDARY-START(107375149102),
    {
      "t": $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h,
      "n": "nominations",
      "d": 966702,
      "h": 107375149102,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107375149102)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475803182),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 966702,
      "h": 21475803182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475803182)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(120260050990),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 966702,
        "h": 30065737774,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 966702,
        "h": 128849985582,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 966702,
      "h": 120260050990,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(120260050990)
  ],
  "h": 966702
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Shared.CandidateView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}CandidateView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(966702)
        
        

        //--TRIMMABLE-BOUNDARY-START(1097774)
        $asm.$cls(`$Jsis.LCCECS$1.PositionView`, ($self) => class PositionView extends $.$lJUR.LCFCS.ApplicationPageBase$$($.$TBFc.LCCECM.CommunityElectionPositionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(137440051246)
            /*CommunityElectionService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(137440051246)
            
            //--TRIMMABLE-BOUNDARY-START(42950770734)
            /*CommunityElectionPostModel?*/ election = null;
            //--TRIMMABLE-BOUNDARY-END(42950770734)
            
            //--TRIMMABLE-BOUNDARY-START(133145083950)
            /*PostBaseModel?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(133145083950)
            
            //--TRIMMABLE-BOUNDARY-START(103080312878)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(103080312878)
            
            //--TRIMMABLE-BOUNDARY-START(98785345582)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(98785345582)
            
            //--TRIMMABLE-BOUNDARY-START(120260182062)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(120260182062)
            
            //--TRIMMABLE-BOUNDARY-START(120260182062)
            //--TRIMMABLE-BOUNDARY-START(30065868846)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065868846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065868846)
            
            //--TRIMMABLE-BOUNDARY-START(128850116654)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850116654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(128850116654)
            
            //--TRIMMABLE-BOUNDARY-END(120260182062)
            
            //--TRIMMABLE-BOUNDARY-START(38655803438)
            /*IEnumerable<CommunityElectionCandidateModel>?*/ candidates = null;
            //--TRIMMABLE-BOUNDARY-END(38655803438)
            
            //--TRIMMABLE-BOUNDARY-START(111670247470)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670247470);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.election = $.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$TBFc.LCCECM.CommunityElectionPostModel, this.RequiredParameter, null);
                    if (this.election !== null)
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$TBFc.LCCECM.CommunityElectionPostModel, this.election, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "*" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        this.candidates = ($t3 = $.$ydCm.LCCC.PostUtility.GetCommunityPostLogicalAssociations($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, 0/*PostLogicalQueryFilterType.And*/, $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.election.Identifier, this.RequiredParameter.Identifier ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670247470)
            
            //--TRIMMABLE-BOUNDARY-START(107375280174)
            /*Task */ Nominate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375280174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Nominate(this.election, this.Scope, this.RequiredParameter, null);
            }
            //--TRIMMABLE-BOUNDARY-END(107375280174)
            
            //--TRIMMABLE-BOUNDARY-START(180389724206)
            /*Task */ Vote()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389724206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Vote(this.election, this.Scope, this.RequiredParameter, null);
            }
            //--TRIMMABLE-BOUNDARY-END(180389724206)
            
            //--TRIMMABLE-BOUNDARY-START(94490378286)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490378286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(94490378286)
            
            //--TRIMMABLE-BOUNDARY-START(115965214766)
            /*string */ get OptimizedComponentName()
            {
                return "positionview";
            }
            //--TRIMMABLE-BOUNDARY-END(115965214766)
            
            //--TRIMMABLE-BOUNDARY-START(176094756910)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094756910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch4 = parameter.Name;
                switch($switch4)
                {
                    case "Scope":
                    this.Scope = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094756910)
            
            //--TRIMMABLE-BOUNDARY-START(90195410990)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195410990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90195410990)
            
            //--TRIMMABLE-BOUNDARY-START(34360836142)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360836142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Parameter === null)
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                    __builder.CloseComponent();
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 1);
                    __builder.AddComponentParameter(2, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                    __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                    __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                    {
                        $.$Jsis._LCCECSP.TypeInference.CreateCommunityPostHeader_0($.$TBFc.LCCECM.CommunityElectionPositionModel, __builder2, 5, 6, this.RequiredParameter, 7, 0/*CommunityPostHeaderFeatures.Default*/ | 1/*CommunityPostHeaderFeatures.Banner*/);
                        __builder2.AddMarkupContent(8, "\r\n\r\n\r\n        ");
                        __builder2.OpenElement(9, "div");
                        __builder2.AddAttribute$5(10, "class", "pd");
                        __builder2.OpenElement(11, "h1");
                        __builder2.AddAttribute$5(12, "class", "mg-0");
                        __builder2.AddContent$4(13, this.election !== null ? $.$strNN(this.election.Title) + ": " : null);
                        __builder2.AddContent$4(14, this.RequiredParameter.Title);
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(15, "\r\n            ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 16);
                        __builder2.AddComponentParameter(17, "Class", "mgt");
                        __builder2.AddComponentParameter(18, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.RequiredParameter.Post));
                        __builder2.CloseComponent();
                        if (this.election !== null)
                        {
                            __builder2.OpenElement(19, "div");
                            __builder2.AddAttribute$5(20, "class", "flex mgb mgt-10");
                            __builder2.OpenElement(21, "h3");
                            __builder2.AddAttribute$5(22, "class", "mgy-a fill");
                            __builder2.AddContent$4(23, $.$fPer.LCFCS$6.StringExtension.Pluralize((this.election.CandidateLabel ?? "Candidate")));
                            __builder2.AddContent$4(24, " in ");
                            __builder2.AddContent$4(25, this.election.Title);
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(26, "\r\n                ");
                            __builder2.OpenElement(27, "div");
                            __builder2.AddAttribute$5(28, "class", "grid colm-1 gap-1");
                            if (this.candidates !== null)
                            {
                                let $en5 = this.candidates.SCG$IEnumerable$$$GetEnumerator();
                                while ($en5.SC$1$IEnumerator$MoveNext())
                                {
                                    let candidate = $en5.SCG$IEnumerator$$$Current;
                                    {
                                        __builder2.OpenComponent$1($.$Jsis.LCCECS$1.CandidateCard, 29);
                                        __builder2.AddComponentParameter(30, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionCandidateModel, candidate));
                                        __builder2.AddComponentParameter(31, "Election", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionPostModel, this.election));
                                        __builder2.CloseComponent();
                                    }
                                }
                            }
                            __builder2.CloseElement();
                            if (this.election.State === 0/*CommunityElectionState.Pending*/)
                            {
                                __builder2.OpenElement(32, "button");
                                __builder2.AddAttribute$5(33, "class", "pd corner bg-primary wf mgt");
                                __builder2.AddAttribute$5(34, "title", `Nominate someone for a ${$.$strNN((this.election.PositionLabel ?? "Position"))}`);
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 35, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Nominate)));
                                __builder2.AddContent$4(36, "Nominate");
                                __builder2.CloseElement();
                            }
                            else if (this.election.State === 1/*CommunityElectionState.Ongoing*/)
                            {
                                __builder2.OpenElement(37, "button");
                                __builder2.AddAttribute$5(38, "class", "pd corner bg-primary wf mgt");
                                __builder2.AddAttribute$5(39, "title", `Vote someone for a ${$.$strNN((this.election.PositionLabel ?? "Position"))}`);
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 40, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Vote)));
                                __builder2.AddContent$4(41, "Vote");
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                    }), $ROHLQb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1097774,"h":0,"f":17825794}));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360836142)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475934254)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475934254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475934254)
            
            //--TRIMMABLE-BOUNDARY-START(21475934254)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(21475934254)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137440051246)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(137440051246)
                
                //--TRIMMABLE-BOUNDARY-START(103080312878)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(103080312878)
                
            }
            static $h = 1097774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lJUR.LCFCS.ApplicationPageBase$$($.$TBFc.LCCECM.CommunityElectionPositionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137440051246),
    {
      "p": 835630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900443694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799789614,
        "f": 83886081
      },
      "n": "Service",
      "d": 1097774,
      "h": 137440051246,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440051246),
//--TRIMMABLE-BOUNDARY-START(133145083950),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310509102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209855022,
        "f": 83886081
      },
      "n": "Scope",
      "d": 1097774,
      "h": 133145083950,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145083950),
//--TRIMMABLE-BOUNDARY-START(103080312878),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130639918,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619920430,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1097774,
      "h": 103080312878,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080312878),
//--TRIMMABLE-BOUNDARY-START(98785345582),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540705326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029985838,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1097774,
      "h": 98785345582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785345582),
//--TRIMMABLE-BOUNDARY-START(115965214766),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720574510,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1097774,
      "h": 115965214766,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965214766)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111670247470),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1097774,
      "h": 111670247470,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(111670247470),
//--TRIMMABLE-BOUNDARY-START(107375280174),
    {
      "r": 178454529,
      "n": "Nominate",
      "d": 1097774,
      "h": 107375280174,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107375280174),
//--TRIMMABLE-BOUNDARY-START(180389724206),
    {
      "r": 178454529,
      "n": "Vote",
      "d": 1097774,
      "h": 180389724206,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389724206),
//--TRIMMABLE-BOUNDARY-START(94490378286),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1097774,
      "h": 94490378286,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490378286),
//--TRIMMABLE-BOUNDARY-START(176094756910),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1097774,
      "h": 176094756910,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094756910),
//--TRIMMABLE-BOUNDARY-START(90195410990),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1097774,
      "h": 90195410990,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195410990),
//--TRIMMABLE-BOUNDARY-START(34360836142),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1097774,
      "h": 34360836142,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360836142)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950770734),
    {
      "t": 1632809,
      "n": "election",
      "d": 1097774,
      "h": 42950770734,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950770734),
//--TRIMMABLE-BOUNDARY-START(38655803438),
    {
      "t": $.$$.SCG.IEnumerable$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h,
      "n": "candidates",
      "d": 1097774,
      "h": 38655803438,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655803438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475934254),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1097774,
      "h": 21475934254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475934254)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(120260182062),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1097774,
        "h": 30065868846,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1097774,
        "h": 128850116654,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 1097774,
      "h": 120260182062,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(120260182062)
  ],
  "h": 1097774
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Shared.PositionView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}PositionView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1097774)
        
        

        //--TRIMMABLE-BOUNDARY-START(901166)
        $asm.$cls(`$Jsis.LCCECS$1.CandidateCard`, ($self) => class CandidateCard extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)
        {
            //--TRIMMABLE-BOUNDARY-START(17180770350)
            /*CommunityElectionPostModel?*/ Election = null;
            //--TRIMMABLE-BOUNDARY-END(17180770350)
            
            //--TRIMMABLE-BOUNDARY-START(38655606830)
            /*string */ get OptimizedComponentName()
            {
                return "candidatecard";
            }
            //--TRIMMABLE-BOUNDARY-END(38655606830)
            
            //--TRIMMABLE-BOUNDARY-START(51540508718)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540508718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Election":
                    this.Election = $.$cast(parameter.Value, $.$TBFc.LCCECM.CommunityElectionPostModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540508718)
            
            //--TRIMMABLE-BOUNDARY-START(12885803054)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885803054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 0);
                __builder.AddComponentParameter(1, "href", this.ViewModel.Link);
                __builder.AddComponentParameter(2, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, this.ViewModel));
                __builder.AddComponentParameter(3, "Class", "text-center stack bd pd corner bg-card");
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(5, "div");
                    __builder2.AddAttribute$5(6, "class", "mgx-a hx-07 wx-07 round bd bg-fill");
                    __builder2.AddAttribute$5(7, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath((this.ViewModel.Icon?.FullPath ?? null), true, false, false)))) + ");");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(8, "\r\n    ");
                    __builder2.OpenElement(9, "b");
                    __builder2.AddAttribute$5(10, "class", "mgt-a");
                    __builder2.AddContent$4(11, this.ViewModel.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n    ");
                    __builder2.OpenElement(13, "small");
                    __builder2.AddAttribute$5(14, "class", "mgb-a");
                    __builder2.AddContent$4(15, this.ViewModel.Role);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(16, "\r\n    ");
                    __builder2.OpenElement(17, "div");
                    __builder2.AddAttribute$5(18, "class", "flex flex-center-x mgt-1 fw-bold");
                    __builder2.OpenElement(19, "div");
                    __builder2.AddAttribute$5(20, "class", "flex");
                    __builder2.AddAttribute$5(21, "title", "Nominations");
                    __builder2.AddMarkupContent(22, "<i class=\"mdi mdi-thumb-up cl-primary\"></i>\r\n            ");
                    __builder2.OpenElement(23, "small");
                    __builder2.AddAttribute$5(24, "class", "mgx-1 mgy-a");
                    __builder2.AddContent$3(25, $.$box(this.ViewModel.Nominations, $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (this.Election !== null && this.Election.Candidates !== null && (this.Election.State === 1/*CommunityElectionState.Ongoing*/ || this.Election.State === 2/*CommunityElectionState.Ended*/))
                    {
                        /*var*/ let total = $.$sl.SL.Enumerable.Sum$17($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.Election.Candidates, new ($.$$.S.Func$$$($.$TBFc.LCCECM.CommunityElectionCandidateModel, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c.Votes;
                        }, $hEzoWd ??= {"r":655361,"p":[{"n":"c","p":322089}],"n":"","d":901166,"h":0,"f":17825794}));
                        __builder2.OpenElement(26, "div");
                        __builder2.AddAttribute$5(27, "class", "mgl-2 flex");
                        __builder2.AddAttribute$5(28, "title", "Votes");
                        __builder2.AddMarkupContent(29, "<i class=\"mdi mdi-vote cl-primary\"></i>\r\n                ");
                        __builder2.OpenElement(30, "small");
                        __builder2.AddAttribute$5(31, "class", "mgx-1 mgy-a");
                        __builder2.AddContent$3(32, $.$box(this.ViewModel.Votes, $.$$.S.Int32));
                        if (total > 0)
                        {
                            __builder2.AddContent$4(33, ", ");
                            __builder2.AddContent$3(34, $.$box($.trunc(((this.ViewModel.Votes * 100) | 0) / total), $.$$.S.Int32));
                            __builder2.AddContent$4(35, " %");
                        }
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }), $mdWcha ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":901166,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885803054)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590835758)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590835758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590835758)
            
            //--TRIMMABLE-BOUNDARY-START(8590835758)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590835758)
            
            static $h = 901166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$TBFc.LCCECM.CommunityElectionCandidateModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180770350),
    {
      "p": 1632809,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770704942,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245541422,
        "f": 83886081
      },
      "n": "Election",
      "d": 901166,
      "h": 17180770350,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180770350),
//--TRIMMABLE-BOUNDARY-START(38655606830),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360639534,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 901166,
      "h": 38655606830,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655606830)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540508718),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 901166,
      "h": 51540508718,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540508718),
//--TRIMMABLE-BOUNDARY-START(12885803054),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 901166,
      "h": 12885803054,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885803054)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590835758),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 901166,
      "h": 8590835758,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590835758)
  ],
  "h": 901166
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Shared.CandidateCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}CandidateCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901166)
        
        

        //--TRIMMABLE-BOUNDARY-START(770094)
        $asm.$cls(`$Jsis.LCCECS.CommunityElectionFeedProvider`, ($self) => class CommunityElectionFeedProvider extends $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$TBFc.LCCECM.CommunityElectionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295737390)
            $ctor$2(/*IClientUnitOfWork*/ unitOfWork)
            {
                super.$ctor$1(unitOfWork);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295737390);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295737390)
            
            //--TRIMMABLE-BOUNDARY-START(8590704686)
            /*RenderFragment */ GetFeedActivityDescription(/*CommunityElectionPostModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590704686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.AsRenderFragment$1(`created an Election`, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590704686)
            
            static $h = 770094;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCF.CommunityMainFeedProvider$$($.$TBFc.LCCECM.CommunityElectionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590704686),
    {
      "r": 6881395,
      "p": [
        {
          "n": "model",
          "p": 1632809
        }
      ],
      "n": "GetFeedActivityDescription",
      "d": 770094,
      "h": 8590704686,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590704686)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295737390),
    {
      "p": [
        {
          "n": "unitOfWork",
          "p": 63657642
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 770094,
      "h": 4295737390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295737390)
  ],
  "h": 770094
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCF.ICommunityMainFeedProvider$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$ahDc.LCCCF.ICommunityMainFeedProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Services.CommunityElectionFeedProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Services${separator}CommunityElectionFeedProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(770094)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032238)
        $asm.$cls(`$Jsis.LCCECS$1.ElectionView`, ($self) => class ElectionView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$TBFc.LCCECM.CommunityElectionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(120260116526)
            /*string */ get OptimizedComponentName()
            {
                return "electionview";
            }
            //--TRIMMABLE-BOUNDARY-END(120260116526)
            
            //--TRIMMABLE-BOUNDARY-START(184684625966)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684625966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Scope":
                    this.Scope = $.$cast(parameter.Value, $.$LCOv.LCFCPM$1.PostBaseModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(184684625966)
            
            //--TRIMMABLE-BOUNDARY-START(90195345454)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195345454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Service = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(90195345454)
            
            //--TRIMMABLE-BOUNDARY-START(146029920302)
            /*CommunityElectionService*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(146029920302)
            
            //--TRIMMABLE-BOUNDARY-START(141734953006)
            /*PostBaseModel?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(141734953006)
            
            //--TRIMMABLE-BOUNDARY-START(103080247342)
            /*LoadState*/ Loading;
            //--TRIMMABLE-BOUNDARY-END(103080247342)
            
            //--TRIMMABLE-BOUNDARY-START(98785280046)
            /*string?*/ LoadErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(98785280046)
            
            //--TRIMMABLE-BOUNDARY-START(124555083822)
            /*PropertyChangedEventHandler?*/ PropertyChanged$1 = null;
            //--TRIMMABLE-BOUNDARY-END(124555083822)
            
            //--TRIMMABLE-BOUNDARY-START(124555083822)
            //--TRIMMABLE-BOUNDARY-START(30065803310)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065803310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Combine$2(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065803310)
            
            //--TRIMMABLE-BOUNDARY-START(133145018414)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145018414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1 = $.$$.S.Delegate.Remove(this.PropertyChanged$1, value);
            }
            //--TRIMMABLE-BOUNDARY-END(133145018414)
            
            //--TRIMMABLE-BOUNDARY-END(124555083822)
            
            //--TRIMMABLE-BOUNDARY-START(94490312750)
            /*ValueTask */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490312750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(94490312750)
            
            //--TRIMMABLE-BOUNDARY-START(115965149230)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965149230);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$TBFc.LCCECM.CommunityElectionPostModel, this.ViewModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "*" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.ViewModel.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n | 4194304n, false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965149230)
            
            //--TRIMMABLE-BOUNDARY-START(34360770606)
            /*Task *//*async*/  AddPosition()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360770606);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let selected = ($t5 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$TBFc.LCCECM.CommunityElectionPositionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Select ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`, false), null, 0, 2147483647, $.$$.ST$1.CancellationToken.None, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t6 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i6 = new $t6();
                        $i6.$ctor$2();
                        $i6.Theme = $.$fPer.LCFC.Theme.Primary;
                        return $i6;
                    })(), this.Scope === null ? new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$6(this.Scope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), 35184372092928n | 65536n | 536870912n | 8n, null), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>*/ let __ca1__;
                    if ((__ca1__ = selected) !== null ? $.$sl.SL.Enumerable.Any$1($.$TBFc.LCCECM.CommunityElectionPositionModel, __ca1__) : false)
                    {
                        let $t7, $r7;
                        this.ViewModel.Positions = $.$sl.SL.Enumerable.ToList($.$TBFc.LCCECM.CommunityElectionPositionModel, $.$sl.SL.Enumerable.Concat($.$TBFc.LCCECM.CommunityElectionPositionModel, (this.ViewModel.Positions ?? $.$sl.SL.Enumerable.Empty($.$TBFc.LCCECM.CommunityElectionPositionModel)), selected));
                        ($t7 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                            {
                                let $t8, $r8;
                                let $t9, $r9;
                                ($t8 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$TBFc.LCCECM.CommunityElectionPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionPostModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                ($t9 = this.ViewModel.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, true), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                            });
                        }, $eOHeha ??= {"r":181338113,"n":"","d":1032238,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                        {
                            return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                        }, $ECmcti ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1032238,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360770606)
            
            //--TRIMMABLE-BOUNDARY-START(107375214638)
            /*Task *//*async*/  NewPosition()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375214638);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let position = ($t10 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$TBFc.LCCECM.CommunityElectionPositionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Create New ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`, false), null, null, null, null, 0, 4131, null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t11 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                        return $i11;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    this.ViewModel.Positions = $.$sl.SL.Enumerable.ToList($.$TBFc.LCCECM.CommunityElectionPositionModel, $.$sl.SL.Enumerable.Concat($.$TBFc.LCCECM.CommunityElectionPositionModel, (this.ViewModel.Positions ?? $.$sl.SL.Enumerable.Empty($.$TBFc.LCCECM.CommunityElectionPositionModel)), $.$$.SRC.RuntimeHelpers.CreateArray($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, [ position ], null, null)));
                    ($t12 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t13, $r13;
                            let $t15, $r15;
                            ($t13 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$TBFc.LCCECM.CommunityElectionPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionPostModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                            if (this.Scope !== null)
                            {
                                let $t14, $r14;
                                this.Scope.SetAssociations($.$TBFc.LCCECM.CommunityElectionPositionModel, $.$$.SRC.RuntimeHelpers.CreateArray($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, [ position ], null, null), null, false);
                                ($t14 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$LCOv.LCFCPM$1.PostBaseModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$LCOv.LCFCPM$1.PostBaseModel), [ this.Scope ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            }
                            ($t15 = this.ViewModel.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, true), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                        });
                    }, $HMASze ??= {"r":181338113,"n":"","d":1032238,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                    }, $TkPLub ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1032238,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375214638)
            
            //--TRIMMABLE-BOUNDARY-START(42950705198)
            /*Task *//*async*/  EditPosition(/*CommunityElectionPositionModel*/ position)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    let $t17, $r17;
                    let $t19, $r19;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950705198);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t16 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$TBFc.LCCECM.CommunityElectionPositionModel, position, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "*" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    ($t17 = $.$hDPm.LCFCI.ViewPresenterExtensions.Form($.$hDPm.LCFCI.ViewConfiguration, $.$TBFc.LCCECM.CommunityElectionPositionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Edit ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`, false), null, position, null, null, 0, 4131, null, null, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t18 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i18 = new $t18();
                        $i18.$ctor$2();
                        $i18.PageBackgroundTheme = $.$fPer.LCFC.Theme.Card;
                        return $i18;
                    })()), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                    ($t19 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t20, $r20;
                            ($t20 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$TBFc.LCCECM.CommunityElectionPositionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionPositionModel), [ position ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                        });
                    }, $zaWDId ??= {"r":181338113,"n":"","d":1032238,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/**/ pn) =>
                    {
                        return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                    }, $ROdJZi ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1032238,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950705198)
            
            //--TRIMMABLE-BOUNDARY-START(137439985710)
            /*Task *//*async*/  RemovePosition(/*CommunityElectionPositionModel*/ position)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t21, $r21;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439985710);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ViewModel.Positions = $.$sl.SL.Enumerable.ToList($.$TBFc.LCCECM.CommunityElectionPositionModel, $.$sl.SL.Enumerable.Except$1($.$TBFc.LCCECM.CommunityElectionPositionModel, (this.ViewModel.Positions ?? $.$sl.SL.Enumerable.Empty($.$TBFc.LCCECM.CommunityElectionPositionModel)), $.$$.SRC.RuntimeHelpers.CreateArray($.$TBFc.LCCECM.CommunityElectionPositionModel.$type, [ position ], null, null)));
                    ($t21 = $.$vWqU.LCFCC.LoadingExtension.Load(this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t22, $r22;
                            let $t23, $r23;
                            ($t22 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$TBFc.LCCECM.CommunityElectionPostModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionPostModel), [ this.ViewModel ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                            ($t23 = this.ViewModel.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, true), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                        });
                    }, $enFbIi ??= {"r":181338113,"n":"","d":1032238,"h":0,"f":17829890}), true, new ($.$$.S.Action$$($.$so.SC$1.PropertyChangedEventArgs))().$ctor(this,  (/*pn*/ pn) =>
                    {
                        return (this.PropertyChanged$1?.Invoke(this, pn) ?? null);
                    }, $BgYple ??= {"r":65537,"p":[{"n":"pn","p":1310738}],"n":"","d":1032238,"h":0,"f":17825794}), null, false, null), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137439985710)
            
            //--TRIMMABLE-BOUNDARY-START(111670181934)
            /*Task */ Nominate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670181934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Nominate(this.ViewModel, this.Scope, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(111670181934)
            
            //--TRIMMABLE-BOUNDARY-START(188979593262)
            /*Task */ Vote()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979593262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service.Vote(this.ViewModel, this.Scope, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188979593262)
            
            //--TRIMMABLE-BOUNDARY-START(38655737902)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655737902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCL$2.Loading, 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.ILoadableViewModel, this));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCL$2.LoadingFeatures, 336/*LoadingFeatures.Default*/ | 1/*LoadingFeatures.Overlay*/), $.$hDPm.LCFCCL$2.LoadingFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(4, "h1");
                    __builder2.AddAttribute$5(5, "class", "mg-0");
                    __builder2.AddContent$4(6, this.ViewModel.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(7, "\r\n    ");
                    __builder2.OpenElement(8, "em");
                    __builder2.AddContent$4(9, this.ViewModel.Summary);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(10, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$1.MarkDown, 11);
                    __builder2.AddComponentParameter(12, "Class", "mgt");
                    __builder2.AddComponentParameter(13, "Value", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Post));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(14, "\r\n\r\n    ");
                    __builder2.OpenElement(15, "div");
                    __builder2.AddAttribute$5(16, "class", "grid gap-1 colm-2 mgt");
                    __builder2.OpenElement(17, "div");
                    __builder2.AddAttribute$5(18, "class", "flex bg-card sd pd corner");
                    __builder2.AddMarkupContent(19, "<i class=\"mdi mdi-calendar fsz-35 cl-chart1\"></i>\r\n            ");
                    __builder2.OpenElement(20, "div");
                    __builder2.AddAttribute$5(21, "class", "mgl-2 stack");
                    __builder2.AddMarkupContent(22, "<span>Start Date</span>\r\n                ");
                    __builder2.OpenElement(23, "h3");
                    __builder2.AddAttribute$5(24, "class", "mg-0");
                    __builder2.AddContent$4(25, (this.ToLocalTime$1(this.ViewModel.StartDate)?.ToString$3("dd MMM, yyyy HH:mm") ?? null));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(26, "\r\n        ");
                    __builder2.OpenElement(27, "div");
                    __builder2.AddAttribute$5(28, "class", "flex bg-card sd pd corner");
                    __builder2.AddMarkupContent(29, "<i class=\"mdi mdi-calendar fsz-35 cl-chart1\"></i>\r\n            ");
                    __builder2.OpenElement(30, "div");
                    __builder2.AddAttribute$5(31, "class", "mgl-2 stack");
                    __builder2.AddMarkupContent(32, "<span>End Date</span>\r\n                ");
                    __builder2.OpenElement(33, "h3");
                    __builder2.AddAttribute$5(34, "class", "mg-0");
                    __builder2.AddContent$4(35, (this.ToLocalTime$1(this.ViewModel.EndDate)?.ToString$3("dd MMM, yyyy HH:mm") ?? null));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(36, "\r\n        ");
                    __builder2.OpenElement(37, "div");
                    __builder2.AddAttribute$5(38, "class", "flex bg-card sd pd corner");
                    __builder2.AddMarkupContent(39, "<i class=\"mdi mdi-police-badge fsz-35 cl-chart1\"></i>\r\n            ");
                    __builder2.OpenElement(40, "div");
                    __builder2.AddAttribute$5(41, "class", "mgl-2 stack");
                    __builder2.AddMarkupContent(42, "<span>Awards</span>\r\n                ");
                    __builder2.OpenElement(43, "h3");
                    __builder2.AddAttribute$5(44, "class", "mg-0");
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPositionModel>?*/ let __ca1__;
                    __builder2.AddContent$3(45, $.$box(($.$box((__ca1__ = this.ViewModel.Positions) !== null ? $.$sl.SL.Enumerable.Count$1($.$TBFc.LCCECM.CommunityElectionPositionModel, __ca1__) : null, $.$$.S.Int32)), $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(46, "\r\n        ");
                    __builder2.OpenElement(47, "div");
                    __builder2.AddAttribute$5(48, "class", "flex bg-card sd pd corner");
                    __builder2.AddMarkupContent(49, "<i class=\"mdi mdi-account fsz-35 cl-chart1\"></i>\r\n            ");
                    __builder2.OpenElement(50, "div");
                    __builder2.AddAttribute$5(51, "class", "mgl-2 stack");
                    __builder2.AddMarkupContent(52, "<span>Nominees</span>\r\n                ");
                    __builder2.OpenElement(53, "h3");
                    __builder2.AddAttribute$5(54, "class", "mg-0");
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>?*/ let __ca2__;
                    __builder2.AddContent$3(55, $.$box(($.$box((__ca2__ = this.ViewModel.Candidates) !== null ? $.$sl.SL.Enumerable.Count$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, __ca2__) : null, $.$$.S.Int32)), $.$$.S.Int32));
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(56, "\r\n        ");
                    __builder2.OpenElement(57, "div");
                    __builder2.AddAttribute$5(58, "class", "flex bg-card sd pd corner");
                    __builder2.AddMarkupContent(59, "<i class=\"mdi mdi-cash fsz-35 cl-chart1\"></i>\r\n            ");
                    __builder2.OpenElement(60, "div");
                    __builder2.AddAttribute$5(61, "class", "mgl-2 stack");
                    __builder2.AddMarkupContent(62, "<span>Nomination Fee</span>\r\n                ");
                    __builder2.OpenElement(63, "h3");
                    __builder2.AddAttribute$5(64, "class", "mg-0");
                    __builder2.AddContent$4(65, (this.ViewModel.NominationFee?.ToString$1(0) ?? null) ?? "Free");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(66, "\r\n    ");
                    __builder2.OpenElement(67, "div");
                    __builder2.AddAttribute$5(68, "class", "flex mgb mgt-10");
                    $.$Jsis._LCCECSE.TypeInference.CreateEditable_0($.$$.S.String, __builder2, 69, 70, "h3", 71, "mgy-a fill", 72, this.ViewModel.PositionLabel, 73, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.ViewModel.PositionLabel = __value;
                    }, $BQPTYc ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1032238,"h":0,"f":17825794}), this.ViewModel.PositionLabel)), 74, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "PositionLabel"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $wqrmJb ??= {"r":38797349,"n":"","d":1032238,"h":0,"f":17825794})).Invoke()), 75, new ($.$mac.MAC.RenderFragment$$($.$$.S.String))().$ctor(this,  (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(76, $.$fPer.LCFCS$6.StringExtension.Pluralize((this.ViewModel.PositionLabel ?? "Position")));
                        }, $NWQjFg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032238,"h":0,"f":17825794});
                    }, $TCajoh ??= {"r":6881395,"p":[{"n":"context","p":1310721}],"n":"","d":1032238,"h":0,"f":17825794}));
                    if (this.Service.CommunityService.IsOwnedByCurrentUser(this.ViewModel))
                    {
                        __builder2.OpenElement(77, "button");
                        __builder2.AddAttribute$5(78, "class", "mdi mdi-plus bg-primary corner pdx-2");
                        __builder2.AddAttribute$5(79, "title", "Create New Poistion");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 80, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.NewPosition)));
                        __builder2.AddContent$4(81, "New");
                        __builder2.CloseElement();
                        __builder2.AddMarkupContent(82, "\r\n            ");
                        __builder2.OpenElement(83, "button");
                        __builder2.AddAttribute$5(84, "class", "mdi mdi-plus bg-success corner pdx-2 mgl");
                        __builder2.AddAttribute$5(85, "title", "Add Existing Position");
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 86, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.AddPosition)));
                        __builder2.AddContent$4(87, "Add");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    if (this.ViewModel.Positions !== null)
                    {
                        let $en24 = this.ViewModel.Positions.SCG$IEnumerable$$$GetEnumerator();
                        while ($en24.SC$1$IEnumerator$MoveNext())
                        {
                            let _position = $en24.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let position = _position;
                                $.$fPer.LCFCP$1.PropertyExtension.AttachProperty($.$TBFc.LCCECM.CommunityElectionPostModel, position, this.ViewModel, null);
                                __builder2.OpenElement(88, "div");
                                __builder2.AddAttribute$5(89, "class", "d-block pd corner bd bg-card flex mgy");
                                __builder2.OpenElement(90, "div");
                                __builder2.AddAttribute$5(91, "class", "flex wf");
                                __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageLink, 92);
                                __builder2.AddComponentParameter(93, "href", position.Link);
                                __builder2.AddComponentParameter(94, "Parameter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Object, position));
                                __builder2.AddComponentParameter(95, "Class", "flex fill");
                                __builder2.AddAttribute$3(96, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(97, "div");
                                    __builder3.AddAttribute$5(98, "class", "mgx-a hx-07 wx-07 round bd bg-fill");
                                    __builder3.AddAttribute$5(99, "style", $.$strNN($.$strNN("background-image:" + " url(") + $.$strNN((this.ResolvePath((position.Icon?.FullPath ?? null), true, false, false)))) + ");");
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(100, "\r\n                        ");
                                    __builder3.OpenElement(101, "div");
                                    __builder3.AddAttribute$5(102, "class", "stack mgy-a mgl fill");
                                    __builder3.OpenElement(103, "h4");
                                    __builder3.AddAttribute$5(104, "class", "mg-0");
                                    __builder3.AddContent$4(105, position.Title);
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(106, "\r\n                            ");
                                    __builder3.OpenElement(107, "p");
                                    __builder3.AddAttribute$5(108, "class", "mgb-0");
                                    __builder3.AddContent$4(109, position.Summary);
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }), $dqJIfa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032238,"h":0,"f":17825794}));
                                __builder2.CloseComponent();
                                __builder2.AddMarkupContent(110, "\r\n                    ");
                                __builder2.OpenElement(111, "div");
                                __builder2.AddAttribute$5(112, "class", "stack");
                                if ((position.VotingFee?.Value ?? null) > 0)
                                {
                                    __builder2.OpenElement(113, "h4");
                                    __builder2.AddAttribute$5(114, "class", "mg-0 cl-primary");
                                    __builder2.AddContent$3(115, position.VotingFee);
                                    __builder2.CloseElement();
                                }
                                if (this.Service.CommunityService.IsOwnedByCurrentUser(this.ViewModel))
                                {
                                    __builder2.OpenElement(116, "div");
                                    __builder2.AddAttribute$5(117, "class", "flex mgy-1");
                                    __builder2.OpenElement(118, "button");
                                    __builder2.AddAttribute$5(119, "class", "mdi mdi-pencil bg-transparent");
                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 120, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        return this.EditPosition(position);
                                    }, $oNcMEe ??= {"r":178454529,"n":"","d":1032238,"h":0,"f":17825794})));
                                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 121, "onclick", true);
                                    __builder2.CloseElement();
                                    __builder2.AddMarkupContent(122, "\r\n                                ");
                                    __builder2.OpenElement(123, "button");
                                    __builder2.AddAttribute$5(124, "class", "mgl-1 mdi mdi-delete cl-error bg-transparent");
                                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 125, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                    {
                                        return this.RemovePosition(position);
                                    }, $FfMCfb ??= {"r":178454529,"n":"","d":1032238,"h":0,"f":17825794})));
                                    $.$macw.MACW.WebRenderTreeBuilderExtensions.AddEventStopPropagationAttribute(__builder2, 126, "onclick", true);
                                    __builder2.CloseElement();
                                    __builder2.CloseElement();
                                }
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                    }
                    __builder2.OpenElement(127, "div");
                    __builder2.AddAttribute$5(128, "class", "flex mgb mgt-10");
                    $.$Jsis._LCCECSE.TypeInference.CreateEditable_1($.$$.S.String, __builder2, 129, 130, "h3", 131, "mgy-a fill", 132, this.ViewModel.CandidateLabel, 133, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                    {
                        return this.ViewModel.CandidateLabel = __value;
                    }, $rZqYzb ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1032238,"h":0,"f":17825794}), this.ViewModel.CandidateLabel)), 134, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                    {
                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "ViewModel"), "CandidateLabel"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                    }, $wKBgLf ??= {"r":38797349,"n":"","d":1032238,"h":0,"f":17825794})).Invoke()), 135, new ($.$mac.MAC.RenderFragment$$($.$$.S.String))().$ctor(this,  (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$4(136, $.$fPer.LCFCS$6.StringExtension.Pluralize((this.ViewModel.CandidateLabel ?? "Candidate")));
                        }, $HXaDJf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1032238,"h":0,"f":17825794});
                    }, $DZUfNh ??= {"r":6881395,"p":[{"n":"context","p":1310721}],"n":"","d":1032238,"h":0,"f":17825794}));
                    if (this.ViewModel.State === 0/*CommunityElectionState.Pending*/)
                    {
                        __builder2.OpenElement(137, "button");
                        __builder2.AddAttribute$5(138, "class", "mdi mdi-plus bg-success corner pdx-2");
                        __builder2.AddAttribute$5(139, "title", `Nominate someone for a ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 140, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Nominate)));
                        __builder2.AddMarkupContent(141, "\r\n                Nominate\r\n            ");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(142, "\r\n    ");
                    __builder2.OpenElement(143, "div");
                    __builder2.AddAttribute$5(144, "class", "grid colm-1 gap-1");
                    if (this.ViewModel.Candidates !== null)
                    {
                        let $en25 = this.ViewModel.Candidates.SCG$IEnumerable$$$GetEnumerator();
                        while ($en25.SC$1$IEnumerator$MoveNext())
                        {
                            let candidate = $en25.SCG$IEnumerator$$$Current;
                            {
                                $.$fPer.LCFCP$1.PropertyExtension.AttachProperty($.$TBFc.LCCECM.CommunityElectionPostModel, candidate, this.ViewModel, null);
                                __builder2.OpenComponent$1($.$Jsis.LCCECS$1.CandidateCard, 145);
                                __builder2.AddComponentParameter(146, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionCandidateModel, candidate));
                                __builder2.AddComponentParameter(147, "Election", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionPostModel, this.ViewModel));
                                __builder2.CloseComponent();
                            }
                        }
                    }
                    __builder2.CloseElement();
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>?*/ let __ca3__;
                    if (!(((__ca3__ = this.ViewModel.Candidates) !== null ? $.$sl.SL.Enumerable.Any$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, __ca3__) : false)))
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 148);
                        __builder2.AddComponentParameter(149, "Message", "Nominees will appear here");
                        __builder2.CloseComponent();
                    }
                    if (this.ViewModel.State === 0/*CommunityElectionState.Pending*/)
                    {
                        __builder2.OpenElement(150, "button");
                        __builder2.AddAttribute$5(151, "class", "pd corner bg-primary wf mgt");
                        __builder2.AddAttribute$5(152, "title", `Nominate someone for a ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 153, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Nominate)));
                        __builder2.AddContent$4(154, "Nominate");
                        __builder2.CloseElement();
                    }
                    else if (this.ViewModel.State === 1/*CommunityElectionState.Ongoing*/)
                    {
                        __builder2.OpenElement(155, "button");
                        __builder2.AddAttribute$5(156, "class", "pd corner bg-primary wf mgt");
                        __builder2.AddAttribute$5(157, "title", `Vote someone for a ${$.$strNN((this.ViewModel.PositionLabel ?? "Position"))}`);
                        __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 158, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.Vote)));
                        __builder2.AddContent$4(159, "Vote");
                        __builder2.CloseElement();
                    }
                }), $PVZEva ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1032238,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(38655737902)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21478202792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Load()
            LCFCC$ILoadableViewModel$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478202792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478202792)
            
            //--TRIMMABLE-BOUNDARY-START(17183235496)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.get
            get LCFCC$ILoadableViewModel$Loading()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Loading;
            }
            //--TRIMMABLE-BOUNDARY-END(17183235496)
            
            //--TRIMMABLE-BOUNDARY-START(47248006568)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.Loading.set
            set LCFCC$ILoadableViewModel$Loading(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068137384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Loading = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248006568)
            
            //--TRIMMABLE-BOUNDARY-START(8593300904)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.get
            get LCFCC$ILoadableViewModel$LoadErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadErrorMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(8593300904)
            
            //--TRIMMABLE-BOUNDARY-START(38658071976)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ILoadableViewModel.LoadErrorMessage.set
            set LCFCC$ILoadableViewModel$LoadErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773170088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LoadErrorMessage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38658071976)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged$1;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(21475868718)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475868718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475868718)
            
            //--TRIMMABLE-BOUNDARY-START(21475868718)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(21475868718)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(146029920302)
                this.Service = null;
                //--TRIMMABLE-BOUNDARY-END(146029920302)
                
                //--TRIMMABLE-BOUNDARY-START(103080247342)
                this.Loading = $.$default($.$vWqU.LCFCC.LoadState);
                //--TRIMMABLE-BOUNDARY-END(103080247342)
                
            }
            static $h = 1032238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$TBFc.LCCECM.CommunityElectionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260116526),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720508974,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1032238,
      "h": 120260116526,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120260116526),
//--TRIMMABLE-BOUNDARY-START(146029920302),
    {
      "p": 835630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900378158,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389658670,
        "f": 83886081
      },
      "n": "Service",
      "d": 1032238,
      "h": 146029920302,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029920302),
//--TRIMMABLE-BOUNDARY-START(141734953006),
    {
      "p": 16771508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310443566,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799724078,
        "f": 83886081
      },
      "n": "Scope",
      "d": 1032238,
      "h": 141734953006,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734953006),
//--TRIMMABLE-BOUNDARY-START(103080247342),
    {
      "p": 6446504,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130574382,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209789486,
        "f": 83886081
      },
      "n": "Loading",
      "d": 1032238,
      "h": 103080247342,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080247342),
//--TRIMMABLE-BOUNDARY-START(98785280046),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540639790,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619854894,
        "f": 83886081
      },
      "n": "LoadErrorMessage",
      "d": 1032238,
      "h": 98785280046,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785280046)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(184684625966),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1032238,
      "h": 184684625966,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684625966),
//--TRIMMABLE-BOUNDARY-START(90195345454),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1032238,
      "h": 90195345454,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195345454),
//--TRIMMABLE-BOUNDARY-START(94490312750),
    {
      "r": 181338113,
      "n": "Load",
      "d": 1032238,
      "h": 94490312750,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490312750),
//--TRIMMABLE-BOUNDARY-START(115965149230),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 1032238,
      "h": 115965149230,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(115965149230),
//--TRIMMABLE-BOUNDARY-START(34360770606),
    {
      "r": 178454529,
      "n": "AddPosition",
      "d": 1032238,
      "h": 34360770606,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360770606),
//--TRIMMABLE-BOUNDARY-START(107375214638),
    {
      "r": 178454529,
      "n": "NewPosition",
      "d": 1032238,
      "h": 107375214638,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107375214638),
//--TRIMMABLE-BOUNDARY-START(42950705198),
    {
      "r": 178454529,
      "p": [
        {
          "n": "position",
          "p": 1370665
        }
      ],
      "n": "EditPosition",
      "d": 1032238,
      "h": 42950705198,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(42950705198),
//--TRIMMABLE-BOUNDARY-START(137439985710),
    {
      "r": 178454529,
      "p": [
        {
          "n": "position",
          "p": 1370665
        }
      ],
      "n": "RemovePosition",
      "d": 1032238,
      "h": 137439985710,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(137439985710),
//--TRIMMABLE-BOUNDARY-START(111670181934),
    {
      "r": 178454529,
      "n": "Nominate",
      "d": 1032238,
      "h": 111670181934,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111670181934),
//--TRIMMABLE-BOUNDARY-START(188979593262),
    {
      "r": 178454529,
      "n": "Vote",
      "d": 1032238,
      "h": 188979593262,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188979593262),
//--TRIMMABLE-BOUNDARY-START(38655737902),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1032238,
      "h": 38655737902,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655737902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475868718),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1032238,
      "h": 21475868718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475868718)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(124555083822),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 1032238,
        "h": 30065803310,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 1032238,
        "h": 133145018414,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "o": "@$1",
      "d": 1032238,
      "h": 124555083822,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(124555083822)
  ],
  "h": 1032238
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Shared.ElectionView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Shared${separator}ElectionView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032238)
        
        

        //--TRIMMABLE-BOUNDARY-START(639022)
        $asm.$cls(`$Jsis.LCCECS.CommunityElectionApplication`, ($self) => class CommunityElectionApplication extends $.$ahDc.LCCCS.CommunityBaseApplication
        {
            //--TRIMMABLE-BOUNDARY-START(12885540910)
            $ctor$5(/*CommunityElectionService*/ service)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885540910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._Service = service;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885540910)
            
            //--TRIMMABLE-BOUNDARY-START(137439592494)
            /*string */ get Name()
            {
                return "Election";
            }
            //--TRIMMABLE-BOUNDARY-END(137439592494)
            
            //--TRIMMABLE-BOUNDARY-START(158914428974)
            /*string */ get Title()
            {
                return "Election";
            }
            //--TRIMMABLE-BOUNDARY-END(158914428974)
            
            //--TRIMMABLE-BOUNDARY-START(21475475502)
            /*string */ get Description()
            {
                return "Create an election, make people vote for their choice, all online.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475475502)
            
            //--TRIMMABLE-BOUNDARY-START(133144625198)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-vote"/*MaterialDesignIconNames.Vote*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144625198)
            
            //--TRIMMABLE-BOUNDARY-START(154619461678)
            /*ThemePack */ get Theme()
            {
                return $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                {
                    //new $.$fPer.LCFC.Theme()
                    const $t1 = $.$fPer.LCFC.Theme;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.BackgroundColor = "#2E969B";
                    $i1.ForegroundColor = "#FFF";
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(154619461678)
            
            //--TRIMMABLE-BOUNDARY-START(30065410094)
            /*ApplicationServiceFeatures */ get Features()
            {
                return 97/*ApplicationServiceFeatures.DefaultInDevelopment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065410094)
            
            //--TRIMMABLE-BOUNDARY-START(17180508206)
            /*Type? */ get ApplicationViewType()
            {
                return $.$Jsis.LCCECP.CommunityElectionApp.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(17180508206)
            
            //--TRIMMABLE-BOUNDARY-START(128849657902)
            /*RenderFragment */ GetApplicationView(TAccount, /*CommunityApplicationViewType*/ type, /*TAccount*/ account, /*PostBaseModel?*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849657902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$hDPm.LCFC.FragmentView.From$1($.$Jsis.LCCECP.CommunityElectionApp, (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                    const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.set_Item("ParentScope", scope);
                    return $i2;
                })(), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(128849657902)
            
            //--TRIMMABLE-BOUNDARY-START(25770442798)
            /*Theme */ ExpandTheme(/*Theme*/ theme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770442798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ThemePack.op_Implicit(this.Theme);
            }
            //--TRIMMABLE-BOUNDARY-END(25770442798)
            
            //--TRIMMABLE-BOUNDARY-START(146029527086)
            /*RenderFragment? */ SearchView(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029527086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029527086)
            
            //--TRIMMABLE-BOUNDARY-START(141734559790)
            /*int */ get Order()
            {
                return 12000;
            }
            //--TRIMMABLE-BOUNDARY-END(141734559790)
            
            //--TRIMMABLE-BOUNDARY-START(4295606318)
            /*CommunityElectionService*/ _Service = null;
            //--TRIMMABLE-BOUNDARY-END(4295606318)
            
            //--TRIMMABLE-BOUNDARY-START(150324494382)
            /*IApplicationService */ get Service()
            {
                return this._Service;
            }
            //--TRIMMABLE-BOUNDARY-END(150324494382)
            
            //--TRIMMABLE-BOUNDARY-START(163209396270)
            /*ValueRange<PostTypes> */ get TypeRange()
            {
                return new ($.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes))().$ctor$3(10752/*PostTypes.Election*/, 10758/*PostTypes.ElectionEnd*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209396270)
            
            //--TRIMMABLE-BOUNDARY-START(4313814464)
            //Generated interface implemetation for LivingThing.Core.Community.Client.Services.ICommunitySearchResultViewProvider<LivingThing.Core.Community.Election.Common.Models.CommunityElectionPostModel>.SearchView(string)
            LCCCS$ICommunitySearchResultViewProvider$$$SearchView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313814464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SearchView(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313814464)
            
            static $h = 639022;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseApplication; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439592494),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605017646,
        "f": 50364417
      },
      "n": "Name",
      "d": 639022,
      "h": 137439592494,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439592494),
//--TRIMMABLE-BOUNDARY-START(158914428974),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964756014,
        "f": 50364417
      },
      "n": "Title",
      "d": 639022,
      "h": 158914428974,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914428974),
//--TRIMMABLE-BOUNDARY-START(21475475502),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835213870,
        "f": 50364417
      },
      "n": "Description",
      "d": 639022,
      "h": 21475475502,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475475502),
//--TRIMMABLE-BOUNDARY-START(133144625198),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015083054,
        "f": 50364417
      },
      "n": "Icon",
      "d": 639022,
      "h": 133144625198,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144625198),
//--TRIMMABLE-BOUNDARY-START(154619461678),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374821422,
        "f": 50364417
      },
      "n": "Theme",
      "d": 639022,
      "h": 154619461678,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619461678),
//--TRIMMABLE-BOUNDARY-START(30065410094),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425148462,
        "f": 50364417
      },
      "n": "Features",
      "d": 639022,
      "h": 30065410094,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065410094),
//--TRIMMABLE-BOUNDARY-START(17180508206),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245279278,
        "f": 50364417
      },
      "n": "ApplicationViewType",
      "d": 639022,
      "h": 17180508206,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180508206),
//--TRIMMABLE-BOUNDARY-START(141734559790),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194952238,
        "f": 50364417
      },
      "n": "Order",
      "d": 639022,
      "h": 141734559790,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734559790),
//--TRIMMABLE-BOUNDARY-START(4295606318),
    {
      "p": 835630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655344686,
        "f": 50331650
      },
      "n": "_Service",
      "d": 639022,
      "h": 4295606318,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295606318),
//--TRIMMABLE-BOUNDARY-START(150324494382),
    {
      "p": 1809888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784886830,
        "f": 50364417
      },
      "n": "Service",
      "d": 639022,
      "h": 150324494382,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324494382),
//--TRIMMABLE-BOUNDARY-START(163209396270),
    {
      "p": $.$fPer.LCFCD.ValueRange$$($.$LCOv.LCFCPM$1.PostTypes).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554690606,
        "f": 50364417
      },
      "n": "TypeRange",
      "d": 639022,
      "h": 163209396270,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209396270)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849657902),
    {
      "r": 6881395,
      "p": [
        {
          "n": "type",
          "p": 15439296
        },
        {
          "n": "account",
          "p": (TAccount) => TAccount.$h
        },
        {
          "n": "scope",
          "p": 16771508,
          "f": 65
        }
      ],
      "g": [
        "TAccount"
      ],
      "n": "GetApplicationView",
      "d": 639022,
      "h": 128849657902,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(128849657902),
//--TRIMMABLE-BOUNDARY-START(25770442798),
    {
      "r": 65309014,
      "p": [
        {
          "n": "theme",
          "p": 65309014
        }
      ],
      "n": "ExpandTheme",
      "d": 639022,
      "h": 25770442798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770442798),
//--TRIMMABLE-BOUNDARY-START(146029527086),
    {
      "r": 6881395,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "SearchView",
      "d": 639022,
      "h": 146029527086,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029527086)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885540910),
    {
      "p": [
        {
          "n": "service",
          "p": 835630
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 639022,
      "h": 12885540910,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885540910)
  ],
  "h": 639022
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ahDc.LCCCS.ICommunityClientApplication$$$$$($.$LCOv.LCFCPMC.NoCategoryPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$GfYa.LCFCA.IAuthenticationClient, $.$ahDc.LCCCS.IDefaultClientApplication, $.$ahDc.LCCCS.ICommunityApplication$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityApplicationPage$$($.$$.S.Object), $.$ahDc.LCCCS.ICommunityClientApplication, $.$ahDc.LCCCS.ICommunityClientApplicationPage, $.$sZVd.LCFCA.IClientApplication, $.$sZVd.LCFCA.IClientApplicationPage, $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$ahDc.LCCCS.ICommunitySearchApplication$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication$$$($.$TBFc.LCCECM.CommunityElectionPostModel, $.$$.S.Object), $.$ahDc.LCCCS.ICommunitySearchResultViewProvider$$($.$TBFc.LCCECM.CommunityElectionPostModel), $.$ahDc.LCCCS.ICommunitySearchApplication ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Services.CommunityElectionApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Services${separator}CommunityElectionApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(639022)
        
        

        //--TRIMMABLE-BOUNDARY-START(507950)
        $asm.$cls(`$Jsis.LCCECP.CommunityElectionApp`, ($self) => class CommunityElectionApp extends $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$TBFc.LCCECM.CommunityElectionUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(128849526830)
            /*string */ get OptimizedComponentName()
            {
                return "communityelectionapp communitydefaultpages";
            }
            //--TRIMMABLE-BOUNDARY-END(128849526830)
            
            //--TRIMMABLE-BOUNDARY-START(115964624942)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964624942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.ElectionService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionService, serviceProvider);
                this.ElectionApplication = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionApplication, serviceProvider);
                this.FeatureProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$Jsis.LCCECS.CommunityElectionFeatureProvider, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(115964624942)
            
            //--TRIMMABLE-BOUNDARY-START(42950180910)
            /*CommunityElectionService*/ ElectionService = null;
            //--TRIMMABLE-BOUNDARY-END(42950180910)
            
            //--TRIMMABLE-BOUNDARY-START(38655213614)
            /*CommunityElectionApplication*/ ElectionApplication = null;
            //--TRIMMABLE-BOUNDARY-END(38655213614)
            
            //--TRIMMABLE-BOUNDARY-START(30065279022)
            /*ICommunityClientApplication */ get Application()
            {
                return this.ElectionApplication;
            }
            //--TRIMMABLE-BOUNDARY-END(30065279022)
            
            //--TRIMMABLE-BOUNDARY-START(51540115502)
            /*CommunityElectionFeatureProvider*/ FeatureProvider = null;
            //--TRIMMABLE-BOUNDARY-END(51540115502)
            
            //--TRIMMABLE-BOUNDARY-START(47245148206)
            /*CommunityElectionFeatureModel*/ feature = null;
            //--TRIMMABLE-BOUNDARY-END(47245148206)
            
            //--TRIMMABLE-BOUNDARY-START(120259592238)
            /*bool*/ loaded = false;
            //--TRIMMABLE-BOUNDARY-END(120259592238)
            
            //--TRIMMABLE-BOUNDARY-START(163209265198)
            /*UseDefaultPage */ get UsePage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669657646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.UsePage & ~4096/*UseDefaultPage.Recent*/;
            }
            //--TRIMMABLE-BOUNDARY-END(163209265198)
            
            //--TRIMMABLE-BOUNDARY-START(124554559534)
            /*Task *//*async*/  OnInitializedAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554559534);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = super.OnInitializedAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (this.ParentScope !== null)
                    {
                        let $t2, $r2;
                        ($t2 = $.$vWqU.LCFCR.DataModelExtension.EnsureHasProperties($.$LCOv.LCFCPM$1.PostBaseModel, this.ParentScope, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$strNN("$"/*DataFeatureModel.PrefixIdentifier*/) + $.$strNN(this.FeatureProvider.Name) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    this.loaded = true;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124554559534)
            
            //--TRIMMABLE-BOUNDARY-START(21475344430)
            /*Task */ AddFeature()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475344430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ahDc.LCCC.Utility.AddFeature(this.UnitOfWork, this.ParentScope);
            }
            //--TRIMMABLE-BOUNDARY-END(21475344430)
            
            //--TRIMMABLE-BOUNDARY-START(34360246318)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360246318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ParentScope !== null && !$.$Iaui.LCFCM.DataPropertiesExtensions.HasFeatures($.$TBFc.LCCECM.CommunityElectionFeatureModel, this.ParentScope, (this.FeatureProvider).LCFCPS$IPostFeatureProvider$FeaturePrefix))
                {
                    __builder.OpenElement(0, "div");
                    __builder.AddAttribute$5(1, "class", "flex hv-10");
                    __builder.OpenElement(2, "div");
                    __builder.AddAttribute$5(3, "class", "mg-a stack text-center");
                    __builder.AddMarkupContent(4, "<i class=\"mdi mdi-vote fsz-100 cl-primary\"></i>\r\n            ");
                    __builder.AddMarkupContent(5, "<h4 class=\"mgx-a mgy-0\">Not Enabled</h4>\r\n            ");
                    __builder.OpenElement(6, "p");
                    __builder.AddContent$4(7, "Election was not enabled on ");
                    __builder.AddContent$4(8, this.ParentScope.Title);
                    __builder.AddContent$4(9, ".");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(10, "\r\n            ");
                    __builder.OpenElement(11, "p");
                    __builder.AddContent$4(12, "Click ");
                    __builder.AddMarkupContent(13, "<b>Add Feature</b> to enable election on ");
                    __builder.AddContent$4(14, this.ParentScope.Title);
                    __builder.AddContent$4(15, ".");
                    __builder.CloseElement();
                    __builder.AddMarkupContent(16, "\r\n            ");
                    __builder.OpenElement(17, "button");
                    __builder.AddAttribute$5(18, "class", "pd bg-primary corner fw-bold mgt");
                    __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 19, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.AddFeature)));
                    __builder.AddContent$4(20, "Add Feature");
                    __builder.CloseElement();
                    __builder.CloseElement();
                    __builder.CloseElement();
                }
                else 
                {
                    __builder.AddContent$1(21, this.GetApp());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360246318)
            
            //--TRIMMABLE-BOUNDARY-START(133144494126)
            /*RenderFragment */ PostView(TPostModel, /*TPostModel*/ post)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144494126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let election;
                if ($.$is(post, $.$TBFc.LCCECM.CommunityElectionPostModel, { set $v($v){ election = $v; } }))
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$Jsis.LCCECS$1.ElectionView, 22);
                        __builder2.AddComponentParameter(23, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$TBFc.LCCECM.CommunityElectionPostModel, election));
                        __builder2.AddComponentParameter(24, "Scope", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.PostBaseModel, this.ParentScope));
                        __builder2.CloseComponent();
                    }, $JruJuc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
                }
                return super.PostView(TPostModel, post);
            }
            //--TRIMMABLE-BOUNDARY-END(133144494126)
            
            //--TRIMMABLE-BOUNDARY-START(25770311726)
            /*RenderFragment */ get AppendPages()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(25, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$TBFc.LCCECM.CommunityElectionPositionModel), 26);
                    __builder2.AddComponentParameter(27, "Name", "Position");
                    __builder2.AddComponentParameter(28, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Position/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(29, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(30, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel)))().$ctor(this, ( (/*e*/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~15/*CommunityLayoutFeatures.Pad*/, null, null, true);
                    }), $iOSYdj ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(31, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(32, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$TBFc.LCCECM.CommunityElectionPositionModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$TBFc.LCCECM.CommunityElectionPositionModel, $.$$.S.Object))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e.Title;
                            }, $Mcizdi ??= {"r":131073,"p":[{"n":"e","p":1370665}],"n":"","d":507950,"h":0,"f":17825794}), true));
                        }, $Ueawlh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
                    }), $edjlHd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel)).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(33, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$Jsis.LCCECS$1.PositionView, 34);
                            __builder3.AddComponentParameter(35, "Scope", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$LCOv.LCFCPM$1.PostBaseModel, this.ParentScope));
                            __builder3.CloseComponent();
                        }, $JxRUqk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
                    }), $SKshae ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionPositionModel)).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(36, "\r\n        ");
                    __builder2.OpenComponent$1($.$lJUR.LCFCS.ApplicationPageFactoryT$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), 37);
                    __builder2.AddComponentParameter(38, "Name", "Candidate");
                    __builder2.AddComponentParameter(39, "Route", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCR$3.RoutePath, $.$fPer.LCFCR$3.RoutePath.op_Implicit$2(`Candidate/${$.$strNN("***"/*RoutePath.OneOrMorePathSegment*/)}`)));
                    __builder2.AddComponentParameter(40, "PageFeatures", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$lJUR.LCFCS.ApplicationPageFeatures, 8961/*ApplicationPageFeatures.DefaultT*/), $.$lJUR.LCFCS.ApplicationPageFeatures));
                    __builder2.AddComponentParameter(41, "ConfigureContext", new ($.$$.S.Action$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)))().$ctor(this, ( (/**/ e) =>
                    {
                        return $.$fPer.LCFCD.DictionaryWorkSpaceExtension.Set($.$ahDc.LCCCSL.CommunityLayoutFeatures, e.LCFCD$IWorkspaceContainer$Workspace, 31/*CommunityLayoutFeatures.Default*/ & ~12/*CommunityLayoutFeatures.PadX*/, null, null, true);
                    }), $UEcsWi ??= {"r":65537,"p":[{"n":"e","p":$.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(42, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.AddContent$1(43, $.$hDPm.LCFC.FragmentView.ToViewAsync$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, context.Data.LCFCS$IApplicationPageContext$$$RouteParameter, new ($.$$.S.Func$$$($.$TBFc.LCCECM.CommunityElectionCandidateModel, $.$$.S.Object))().$ctor(this,  (/**/ e) =>
                            {
                                return e.Title;
                            }, $luvXYh ??= {"r":131073,"p":[{"n":"e","p":322089}],"n":"","d":507950,"h":0,"f":17825794}), true));
                        }, $oEXwIb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
                    }), $YPsumh ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.AddAttribute$3(44, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$Jsis.LCCECS$1.CandidateView, 45);
                            __builder3.CloseComponent();
                        }, $eAvOWj ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
                    }), $STjkYc ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$lJUR.LCFCS.IApplicationPageContext$$($.$TBFc.LCCECM.CommunityElectionCandidateModel)).$h}],"n":"","d":507950,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(46, "\r\n    ");
                }, $iSXOxk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":507950,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(25770311726)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180377134)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180377134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180377134)
            
            //--TRIMMABLE-BOUNDARY-START(17180377134)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(17180377134)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950180910)
                this.ElectionService = null;
                //--TRIMMABLE-BOUNDARY-END(42950180910)
                
                //--TRIMMABLE-BOUNDARY-START(38655213614)
                this.ElectionApplication = null;
                //--TRIMMABLE-BOUNDARY-END(38655213614)
                
                //--TRIMMABLE-BOUNDARY-START(51540115502)
                this.FeatureProvider = null;
                //--TRIMMABLE-BOUNDARY-END(51540115502)
                
                //--TRIMMABLE-BOUNDARY-START(47245148206)
                this.feature = null;
                //--TRIMMABLE-BOUNDARY-END(47245148206)
                
            }
            static $h = 507950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS$1.CommunityDefaultPages$$$$$($.$TBFc.LCCECM.CommunityElectionCategoryModel, $.$TBFc.LCCECM.CommunityElectionPostModel, $.$LCOv.LCFCPM$1.GenericPostModel, $.$TBFc.LCCECM.CommunityElectionUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128849526830),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079723054,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 507950,
      "h": 128849526830,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849526830),
//--TRIMMABLE-BOUNDARY-START(42950180910),
    {
      "p": 835630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899853870,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324363310,
        "f": 83886081
      },
      "n": "ElectionService",
      "d": 507950,
      "h": 42950180910,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950180910),
//--TRIMMABLE-BOUNDARY-START(38655213614),
    {
      "p": 639022,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309919278,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734428718,
        "f": 83886081
      },
      "n": "ElectionApplication",
      "d": 507950,
      "h": 38655213614,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655213614),
//--TRIMMABLE-BOUNDARY-START(30065279022),
    {
      "p": 17470912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719984686,
        "f": 50364420
      },
      "n": "Application",
      "d": 507950,
      "h": 30065279022,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30065279022),
//--TRIMMABLE-BOUNDARY-START(51540115502),
    {
      "p": 704558,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489788462,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914297902,
        "f": 83886081
      },
      "n": "FeatureProvider",
      "d": 507950,
      "h": 51540115502,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540115502),
//--TRIMMABLE-BOUNDARY-START(163209265198),
    {
      "p": 34379200,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669657646,
        "f": 50364420
      },
      "n": "UsePage",
      "d": 507950,
      "h": 163209265198,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(163209265198),
//--TRIMMABLE-BOUNDARY-START(25770311726),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130050094,
        "f": 50364420
      },
      "n": "AppendPages",
      "d": 507950,
      "h": 25770311726,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25770311726)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964624942),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 507950,
      "h": 115964624942,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964624942),
//--TRIMMABLE-BOUNDARY-START(124554559534),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 507950,
      "h": 124554559534,
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(124554559534),
//--TRIMMABLE-BOUNDARY-START(21475344430),
    {
      "r": 178454529,
      "n": "AddFeature",
      "d": 507950,
      "h": 21475344430,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475344430),
//--TRIMMABLE-BOUNDARY-START(34360246318),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 507950,
      "h": 34360246318,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360246318),
//--TRIMMABLE-BOUNDARY-START(133144494126),
    {
      "r": 6881395,
      "p": [
        {
          "n": "post",
          "p": (TPostModel) => TPostModel.$h
        }
      ],
      "g": [
        "TPostModel"
      ],
      "n": "PostView",
      "d": 507950,
      "h": 133144494126,
      "f": 16941060
    },
//--TRIMMABLE-BOUNDARY-END(133144494126)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245148206),
    {
      "t": 846377,
      "n": "feature",
      "d": 507950,
      "h": 47245148206,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245148206),
//--TRIMMABLE-BOUNDARY-START(120259592238),
    {
      "t": 262145,
      "n": "loaded",
      "d": 507950,
      "h": 120259592238,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120259592238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180377134),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 507950,
      "h": 17180377134,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180377134)
  ],
  "h": 507950
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Pages.CommunityElectionApp`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Pages${separator}CommunityElectionApp`; }
        });
        //--TRIMMABLE-BOUNDARY-END(507950)
        
        

        //--TRIMMABLE-BOUNDARY-START(835630)
        $asm.$cls(`$Jsis.LCCECS.CommunityElectionService`, ($self) => class CommunityElectionService extends $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$TBFc.LCCECM.CommunityElectionPostModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295802926)
            $ctor$6(/*CommunityRootService*/ service)
            {
                super.$ctor$5(service);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295802926);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295802926)
            
            //--TRIMMABLE-BOUNDARY-START(12885737518)
            /*Task<CommunityElectionPositionModel> *//*async*/  GetPosition(/*CommunityElectionPostModel*/ election, /*PostBaseModel?*/ scope)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$TBFc.LCCECM.CommunityElectionPositionModel), $.$TBFc.LCCECM.CommunityElectionPositionModel, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885737518);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Single$1($.$TBFc.LCCECM.CommunityElectionPositionModel, (($t1 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$TBFc.LCCECM.CommunityElectionPositionModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `Select ${$.$strNN((election.PositionLabel ?? "Position"))}`, false), null, 1, 1, null, (() =>
                    {
                        //new $.$hDPm.LCFCI.ViewConfiguration()
                        const $t2 = $.$hDPm.LCFCI.ViewConfiguration;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Theme = $.$fPer.LCFC.Theme.Primary;
                        return $i2;
                    })(), scope === null ? new $.$fPer.LCFCD.DataFilter().$ctor$14($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741826/*PostFilterTypes.Account*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$6(scope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), 35184372092928n | 65536n | 536870912n | 8n, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885737518)
            
            //--TRIMMABLE-BOUNDARY-START(8590770222)
            /*Task<CommunityElectionCandidateModel> *//*async*/  GetCandidate(/*CommunityElectionPostModel*/ election, /*PostBaseModel?*/ scope, /*CommunityElectionPositionModel*/ position)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$TBFc.LCCECM.CommunityElectionCandidateModel), $.$TBFc.LCCECM.CommunityElectionCandidateModel, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590770222);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*string?*/ let err = null;
                    /*AccountModel*/ let account;
                    do
                    {
                        let $t3, $r3;
                        account = $.$sl.SL.Enumerable.Single$1($.$LCOv.LCFCPM$1.AccountModel, (($t3 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$LCOv.LCFCPM$1.AccountModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(err)}Select Account`, err !== null), null, 1, 1, $.$$.ST$1.CancellationToken.None, (() =>
                        {
                            //new $.$hDPm.LCFCI.ViewConfiguration()
                            const $t4 = $.$hDPm.LCFCI.ViewConfiguration;
                            const $i4 = new $t4();
                            $i4.$ctor$2();
                            $i4.Theme = $.$fPer.LCFC.Theme.Primary;
                            return $i4;
                        })(), $.$is(scope, $.$LCOv.LCFCP.IUserAccountModel) ? new $.$fPer.LCFCD.DataFilter().$ctor$6(scope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741828/*PostFilterTypes.Subscribers*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$1(), 35184372092928n | 65536n | 536870912n | 8n, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))));
                        if (!election.SelfNomination)
                        {
                            if (account.Equals$1(this.CommunityService.MainAccount))
                            {
                                err = "This election doesn't allow you to nominate yourself.\r\n";
                                continue;
                            }
                        }
                        break;
                    }
                    while(true);
                    /*var*/ let candidates = ($t5 = $.$ydCm.LCCC.PostUtility.GetCommunityPostLogicalAssociations($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, 0/*PostLogicalQueryFilterType.And*/, $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ account.Identifier, position.Identifier, election.Identifier ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionCandidateModel>?*/ let __ca1__;
                    /*var*/ let candidate = ((__ca1__ = candidates) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$TBFc.LCCECM.CommunityElectionCandidateModel, __ca1__) : null);
                    if (candidate === null)
                    {
                        candidate = (() =>
                        {
                            //new $.$TBFc.LCCECM.CommunityElectionCandidateModel()
                            const $t6 = $.$TBFc.LCCECM.CommunityElectionCandidateModel;
                            const $i6 = new $t6();
                            $i6.$ctor$6();
                            $i6.Name = account.Name;
                            $i6.NomineeAccount = account;
                            $i6.Position = position;
                            $i6.Election = election;
                            $i6.Icon = account.Icon;
                            return $i6;
                        })();
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, candidate);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590770222)
            
            //--TRIMMABLE-BOUNDARY-START(17180704814)
            /*Task *//*async*/  Nominate(/*CommunityElectionPostModel*/ election, /*PostBaseModel?*/ scope, /*CommunityElectionPositionModel?*/ position, /*CommunityElectionCandidateModel?*/ candidate)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t12, $r12;
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180704814);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (election.SingleNomination)
                    {
                    }
                    /*string?*/ let err = null;
                    /*AccountModel*/ let account;
                    do
                    {
                        let $t7, $r7;
                        account = $.$sl.SL.Enumerable.Single$1($.$LCOv.LCFCPM$1.AccountModel, (($t7 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$LCOv.LCFCPM$1.AccountModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(err)}Select Account`, err !== null), null, 1, 1, $.$$.ST$1.CancellationToken.None, (() =>
                        {
                            //new $.$hDPm.LCFCI.ViewConfiguration()
                            const $t8 = $.$hDPm.LCFCI.ViewConfiguration;
                            const $i8 = new $t8();
                            $i8.$ctor$2();
                            $i8.Theme = $.$fPer.LCFC.Theme.Primary;
                            return $i8;
                        })(), $.$is(scope, $.$LCOv.LCFCP.IUserAccountModel) ? new $.$fPer.LCFCD.DataFilter().$ctor$6(scope.Identifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741828/*PostFilterTypes.Subscribers*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)) : new $.$fPer.LCFCD.DataFilter().$ctor$1(), 35184372092928n | 65536n | 536870912n | 8n, null), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)))));
                        if (!election.SelfNomination)
                        {
                            if (account.Equals$1(this.CommunityService.MainAccount))
                            {
                                err = "This election doesn't allow you to nominate yourself.\r\n";
                                continue;
                            }
                        }
                        break;
                    }
                    while(true);
                    if (position === null)
                    {
                        let $t9, $r9;
                        position = ($t9 = this.GetPosition(election, scope), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                    if (candidate === null)
                    {
                        let $t10, $r10;
                        candidate = ($t10 = this.GetCandidate(election, scope, position), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                    if ((election.NominationFee?.Value ?? null) > 0)
                    {
                        let $t11, $r11;
                        /*var*/ let _ref = `Election/Nomination/${$.$strNN($.$dspc(election.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN($.$dspc(this.CommunityService.MainAccount.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN($.$dspc(account.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}`;
                        /*var*/ let payment = ($t11 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$$.S.Nullable$$($.$fPer.LCFCDM.Money).Value$get.call(election.NominationFee), "Nomination Fee", _ref, `Nomination fee for ${$.$strNN(account.Title)} on ${$.$strNN(election.Title)} by ${$.$strNN(this.CommunityService.MainAccount.ToString())}`, `This election requires a nomination fee of ${$.$strNN(election.NominationFee.ToString())}`, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                    candidate.Nominations++;
                    /*var*/ let remoteCandidate = $.$sl.SL.Enumerable.Single$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, (($t12 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CreateOrUpdate($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionCandidateModel), [ candidate ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)))).AsEnumerable());
                    ($t13 = election.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, true), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    if (candidate.Identifier.Empty)
                    {
                        let $t14, $r14;
                        ($t14 = $.$vWqU.LCFCR.ServerRemoteServiceExtension.SendEmail(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, `${$.$strNN(election.Title)} Election`, "You are nominated", (() =>
                        {
                            //new $.$UrvY.LCFCM.MessageBody()
                            const $t15 = $.$UrvY.LCFCM.MessageBody;
                            const $i15 = new $t15();
                            $i15.$ctor$2();
                            $i15.Message = `Congratulations ${$.$strNN(account.Title)}.\r\n\r\nYou have been nominated for **${$.$strNN(position.Title)}** in **${$.$strNN(election.Title)}** election.\r\n\r\nWe have also created a page for you for this nomination. Visit ${$.$strNN($.$fPer.LCFC.PathUtility.ToUrl("https", this.UnitOfWork.LCFCI$IClientUnitOfWork$Context.LCFC$IApplicationContextProvider$RemoteHost, remoteCandidate.Link))} and login to edit and add more info to your nomination.\r\n\r\nPlease note that nomination doesn't mean you won. It just meant that we have now entered you as a nominee for the contest. Election will take place on ${$.$strNN((election.StartDate?.ToString$3("yyyy/MM/dd HH:mm:ss"/*DataConverter.DateTimeFormat*/) ?? null))} to select the final winner.`;
                            $i15.Formatting = 1/*MessageFormatting.Markdown*/;
                            return $i15;
                        })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ account.User.Email ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                    }
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Nomination Successful", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `You have successfully nominated **${$.$strNN(account.Title)}** for **${$.$strNN(position.Title)}**`, true), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180704814)
            
            //--TRIMMABLE-BOUNDARY-START(21475672110)
            /*Task *//*async*/  Vote(/*CommunityElectionPostModel*/ election, /*PostBaseModel?*/ scope, /*CommunityElectionPositionModel?*/ position, /*CommunityElectionCandidateModel?*/ candidate)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t20, $r20;
                    let $t23, $r23;
                    let $t24, $r24;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475672110);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (position === null)
                    {
                        let $t16, $r16;
                        position = ($t16 = this.GetPosition(election, scope), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                    }
                    if (candidate === null)
                    {
                        /*string?*/ let err = null;
                        do
                        {
                            let $t17, $r17;
                            candidate = $.$sl.SL.Enumerable.Single$1($.$TBFc.LCCECM.CommunityElectionCandidateModel, (($t17 = $.$hDPm.LCFCI.ViewPresenterExtensions.Select($.$hDPm.LCFCI.ViewConfiguration, $.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$Overlay, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `${$.$strNN(err)}Select Candidate`, err !== null), null, 1, 1, $.$$.ST$1.CancellationToken.None, (() =>
                            {
                                //new $.$hDPm.LCFCI.ViewConfiguration()
                                const $t18 = $.$hDPm.LCFCI.ViewConfiguration;
                                const $i18 = new $t18();
                                $i18.$ctor$2();
                                $i18.Theme = $.$fPer.LCFC.Theme.Primary;
                                return $i18;
                            })(), new $.$fPer.LCFCD.DataFilter().$ctor$2(new $.$fPer.LCFCD.CompositeDataId().$ctor$3(2/*CompositeDataIdRelationship.And*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ election.Identifier, position.Identifier ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Enum), [ $.$box(1073741837/*PostFilterTypes.HasAssociation*/, $.$LCOv.LCFCPM$1.PostFilterTypes) ], null, null)), 35184372092928n | 65536n | 536870912n | 8n, null), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)))));
                            if (election.DisableSelfVote || position.DisableSelfVote)
                            {
                                let $t19, $r19;
                                ($t19 = candidate.EnsureHasAssociations(this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, false), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                                if (candidate.NomineeAccount.Equals$1(this.CommunityService.MainAccount))
                                {
                                    err = "This election doesn't allow you to vote yourself.\r\n";
                                    continue;
                                }
                            }
                            break;
                        }
                        while(true);
                    }
                    /*var*/ let votes = ($t20 = $.$ydCm.LCCC.PostUtility.GetCommunityPostLogicalAssociations($.$TBFc.LCCECM.CommunityElectionVoteModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, 1196268653051967n, 0/*PostLogicalQueryFilterType.And*/, $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCD.DataId), [ this.CommunityService.MainAccount.Identifier, position.Identifier, election.Identifier ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Community.Election.Common.Models.CommunityElectionVoteModel>?*/ let __ca2__;
                    /*var*/ let vote = ((__ca2__ = votes) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$TBFc.LCCECM.CommunityElectionVoteModel, __ca2__) : null);
                    if (vote !== null)
                    {
                        _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "You already voted", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `You have voted already for **${$.$strNN(position.Title)}**`, true), null, null);
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if ((position.VotingFee?.Value ?? null) > 0)
                    {
                        let $t21, $r21;
                        /*var*/ let _ref = `Election/Vote/${$.$strNN($.$dspc(election.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN($.$dspc(this.CommunityService.MainAccount.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}/${$.$strNN($.$dspc(position.Identifier.Id, $.$$.S.Object, ($t) => $t.ToString))}`;
                        /*var*/ let payment = ($t21 = this.UnitOfWork.LCFCI$IClientUnitOfWork$Payment.LCFCI$IUIPaymentProcessorProvider$ProcessPayment($.$$.S.Nullable$$($.$fPer.LCFCDM.Money).Value$get.call(position.VotingFee), "Nomination Fee", _ref, `Voting fee for ${$.$strNN(position.Title)} on ${$.$strNN(election.Title)} by ${$.$strNN(this.CommunityService.MainAccount.ToString())}`, `This position requires a voting fee of ${$.$strNN(position.VotingFee.ToString())}`, null, null, null, null, null), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                    }
                    candidate.Votes++;
                    vote = (() =>
                    {
                        //new $.$TBFc.LCCECM.CommunityElectionVoteModel()
                        const $t22 = $.$TBFc.LCCECM.CommunityElectionVoteModel;
                        const $i22 = new $t22();
                        $i22.$ctor$6();
                        $i22.Name = `Vote for ${$.$strNN(candidate.Title)} by ${$.$strNN(this.CommunityService.MainAccount.Title)} for ${$.$strNN(position.Title)} in ${$.$strNN(election.Title)}`;
                        $i22.Position = position;
                        $i22.Candidate = candidate;
                        return $i22;
                    })();
                    /*var*/ let remoteVote = $.$sl.SL.Enumerable.Single$1($.$TBFc.LCCECM.CommunityElectionVoteModel, (($t23 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create($.$TBFc.LCCECM.CommunityElectionVoteModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionVoteModel), [ vote ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)))).AsEnumerable());
                    ($t24 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update($.$TBFc.LCCECM.CommunityElectionCandidateModel, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, $.$fPer.LCFCD.DataFilter.Default, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$TBFc.LCCECM.CommunityElectionCandidateModel), [ candidate ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                    _ = $.$hDPm.LCFCI.ViewPresenterExtensions.SnackBar($.$hDPm.LCFCI.ViewConfiguration, this.UnitOfWork.LCFCI$IClientUnitOfWork$UI.LCFCI$IUIClientService$ClientPrompt, $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, "Vote Successful", false), $.$hDPm.LCFC.FragmentView.AsRenderFragment$3($.$$.S.Object, `You have successfully voted **${$.$strNN(candidate.Title)}** for **${$.$strNN(position.Title)}**`, true), null, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475672110)
            
            static $h = 835630;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ahDc.LCCCS.CommunityBaseService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$TBFc.LCCECM.CommunityElectionPostModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885737518),
    {
      "r": $.$$.STT.Task$$($.$TBFc.LCCECM.CommunityElectionPositionModel).$h,
      "p": [
        {
          "n": "election",
          "p": 1632809
        },
        {
          "n": "scope",
          "p": 16771508
        }
      ],
      "n": "GetPosition",
      "d": 835630,
      "h": 12885737518,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(12885737518),
//--TRIMMABLE-BOUNDARY-START(8590770222),
    {
      "r": $.$$.STT.Task$$($.$TBFc.LCCECM.CommunityElectionCandidateModel).$h,
      "p": [
        {
          "n": "election",
          "p": 1632809
        },
        {
          "n": "scope",
          "p": 16771508
        },
        {
          "n": "position",
          "p": 1370665
        }
      ],
      "n": "GetCandidate",
      "d": 835630,
      "h": 8590770222,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(8590770222),
//--TRIMMABLE-BOUNDARY-START(17180704814),
    {
      "r": 178454529,
      "p": [
        {
          "n": "election",
          "p": 1632809
        },
        {
          "n": "scope",
          "p": 16771508
        },
        {
          "n": "position",
          "p": 1370665
        },
        {
          "n": "candidate",
          "p": 322089
        }
      ],
      "n": "Nominate",
      "d": 835630,
      "h": 17180704814,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17180704814),
//--TRIMMABLE-BOUNDARY-START(21475672110),
    {
      "r": 178454529,
      "p": [
        {
          "n": "election",
          "p": 1632809
        },
        {
          "n": "scope",
          "p": 16771508
        },
        {
          "n": "position",
          "p": 1370665
        },
        {
          "n": "candidate",
          "p": 322089
        }
      ],
      "n": "Vote",
      "d": 835630,
      "h": 21475672110,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21475672110)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295802926),
    {
      "p": [
        {
          "n": "service",
          "p": 16487872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 835630,
      "h": 4295802926,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295802926)
  ],
  "h": 835630
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$ydCm.LCCCS.ICommunityApplicationService$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$TBFc.LCCECM.CommunityElectionPostModel), $.$ydCm.LCCCS.ICommunityApplicationService$$$$($.$LCOv.LCFCPMC.CategoryPostModel, $.$TBFc.LCCECM.CommunityElectionPostModel, $.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$ydCm.LCCCS.ICommunityApplicationServiceHasCategories, $.$ydCm.LCCCS.ICommunityApplicationServiceHasPosts, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Community.Election.Client.Services.CommunityElectionService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Community${separator}Election${separator}Client${separator}Services${separator}CommunityElectionService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(835630)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.QrCodeGenerator", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Bills.Common", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.Bills.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Wallet", "NetJs.LivingThing.Core.Shipping.Common", "NetJs.LivingThing.Core.Frameworks.Common.Posts", "NetJs.LivingThing.Core.Community.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", "NetJs.LivingThing.Core.Frameworks.Client.MarkdownPlus.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Posts.Blazor", "NetJs.LivingThing.Core.Wallet.Client.Blazor", "NetJs.LivingThing.VTU.Common", "NetJs.LivingThing.VTU.Client.Blazor", "NetJs.LivingThing.Core.Community.Client.Blazor", "NetJs.LivingThing.Core.Community.Election.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(49198)
